theory polyeq_4
  imports polyeq_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, a, b, c, p, q for "RealXREAL-0M1"
reserve m, n for "ElementSUBSET-1M1-of NATNUMBERSK1"
mtheorem polyeq_4_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (b /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_4:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a >XXREAL-0R4 0NUMBERSK6 & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & x  |^NEWTONK1 n =HIDDENR1 a implies x =HIDDENR1 n -rootPOWERK1 a or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a"
sorry

mtheorem polyeq_4_th_5:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
sorry

mtheorem polyeq_4_th_6:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,0NUMBERSK6,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_7:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
sorry

mtheorem polyeq_4_th_8:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((((a <>HIDDENR2 0NUMBERSK6 & b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6) & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies ((x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) or x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
sorry

mtheorem polyeq_4_th_9:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2) & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
sorry

mtheorem polyeq_4_th_10:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((a <>HIDDENR2 0NUMBERSK6 & b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
sorry

mtheorem polyeq_4_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((a ^2SQUARE-1K1 -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) & a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((((a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
sorry

mtheorem polyeq_4_th_12:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K4(a,b,b,a,x) =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
sorry

mdef polyeq_4_def_1 ("PolynomPOLYEQ-4K1'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "e be ComplexXCMPLX-0M1", "f be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"func PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) \<rightarrow> setHIDDENM2 equals
  ((((a *XCMPLX-0K3 x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 d *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 e *XCMPLX-0K3 x)+XCMPLX-0K2 f"
proof-
  (*coherence*)
    show "((((a *XCMPLX-0K3 x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 d *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 e *XCMPLX-0K3 x)+XCMPLX-0K2 f be setHIDDENM2"
       sorry
qed "sorry"

mtheorem polyeq_4_cl_1:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "e be ComplexXCMPLX-0M1", "f be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem polyeq_4_cl_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "d be RealXREAL-0M1", "e be RealXREAL-0M1", "f be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_4_th_13:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6) & PolynomPOLYEQ-4K1(a,b,c,c,b,a,x) =HIDDENR1 0NUMBERSK6 implies ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & y2 =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies (((x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem polyeq_4_th_14:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (x +XCMPLX-0K2 y =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6 implies x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M or x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem polyeq_4_th_15:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6) & n be oddABIANV2 implies x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem polyeq_4_th_16:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6) & p >XXREAL-0R4 0NUMBERSK6) & q >XXREAL-0R4 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M implies ((((((x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem polyeq_4_th_17:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 a & x  |^NEWTONK1 n -XCMPLX-0K6 y  |^NEWTONK1 n =HIDDENR1 b) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & a +XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6) & a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 implies ((x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem polyeq_4_th_18:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6) & n be oddABIANV2) & a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b) or x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_19:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((((a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & p /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6) & p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies ((x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b) or x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b)) or x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_20:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 q) & n be oddABIANV2) & p *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6 implies x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
sorry

mtheorem polyeq_4_th_21:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((((a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 q) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6 implies x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
sorry

mtheorem polyeq_4_th_22:
" for a be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & a to-powerPOWERK2 x =HIDDENR1 \<one>\<^sub>M implies x =HIDDENR1 0NUMBERSK6"
sorry

mtheorem polyeq_4_th_23:
" for a be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & a to-powerPOWERK2 x =HIDDENR1 a implies x =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem polyeq_4_th_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6) & logPOWERK3(a,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem polyeq_4_th_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6) & logPOWERK3(a,x) =HIDDENR1 \<one>\<^sub>M implies x =HIDDENR1 a"
sorry

end
