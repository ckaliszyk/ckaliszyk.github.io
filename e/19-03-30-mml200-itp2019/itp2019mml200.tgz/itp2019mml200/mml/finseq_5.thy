theory finseq_5
  imports rfinseq nat_d partfun2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, j, k, n for "NatNAT-1M1"
mtheorem finseq_5_th_1:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i <=XXREAL-0R1 n implies (n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry

mtheorem finseq_5_th_2:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies (n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
sorry

mtheorem finseq_5_th_3:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 rngFUNCT-1K2 f) & f .FUNCT-1K1 x =HIDDENR1 y"
sorry

mtheorem finseq_5_th_4:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 iff ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x})"
sorry

mtheorem finseq_5_th_5:
" for f be FunctionFUNCT-1M1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (f be one-to-oneFUNCT-1V2 & y1 inHIDDENR3 rngFUNCT-1K2 f) & f \<inverse>FUNCT-1K6 {TARSKIK1 y1} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y2} implies y1 =HIDDENR1 y2"
sorry

mtheorem finseq_5_cl_1:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K10 x*> as-term-is trivialZFMISC-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 x*> be trivialZFMISC-1V1"
     sorry
qed "sorry"

mtheorem finseq_5_cl_2:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <*FINSEQ-1K11 x,y *> as-term-is  non trivialZFMISC-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 x,y *> be  non trivialZFMISC-1V1"
sorry
qed "sorry"

mtheorem finseq_5_cl_3:
"cluster one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem finseq_5_th_6:
" for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
sorry

mtheorem finseq_5_th_7:
" for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds  ex i be NatNAT-1M1 st i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f"
  using nat_1_th_6 sorry

mtheorem finseq_5_th_8:
" for x be objectHIDDENM1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f) =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f"
sorry

mtheorem finseq_5_th_9:
" for f be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds  for q be setHIDDENM2 holds (p inTARSKIR2 rngFUNCT-1K2 f & q inTARSKIR2 rngFUNCT-1K2 f) & p ..FINSEQ-4K4 f =XBOOLE-0R4 q ..FINSEQ-4K4 f implies p =XBOOLE-0R4 q"
sorry

mtheorem finseq_5_th_10:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & g =FUNCT-1R1 f  |RELAT-1K8 SegFINSEQ-1K2 n implies f  |RELAT-1K8 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 g ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)"
sorry

mtheorem finseq_5_th_11:
" for i be NatNAT-1M1 holds  for f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies (f .FUNCT-1K1 i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
sorry

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f, g for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem finseq_5_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 g & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> i) implies f =FINSEQ-1R1 g"
sorry

mtheorem finseq_5_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> k) implies f =FINSEQ-1R1 g"
sorry

mtheorem finseq_5_th_14:
" for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M implies f =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
  using finseq_1_th_40 sorry

mtheorem finseq_5_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
sorry

mlemma finseq_5_lm_1:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f implies (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> g).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
  using finseq_1_def_7 sorry

mtheorem finseq_5_th_16:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
sorry

mtheorem finseq_5_th_17:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) <=XXREAL-0R1 i"
sorry

mtheorem finseq_5_th_18:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds domFINSEQ-1K5 (f  |FINSEQ-1K17 i) c=TARSKIR1 domFINSEQ-1K5 f"
sorry

mtheorem finseq_5_th_19:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds rngFUNCT-1K2 (f  |FINSEQ-1K17 i) c=TARSKIR1 rngFUNCT-1K2 f"
sorry

mtheorem finseq_5_th_20:
" for f be FinSequenceFINSEQ-1M1 holds f be  non emptyXBOOLE-0V1 implies f  |FINSEQ-1K17 \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
sorry

mtheorem finseq_5_th_21:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f implies f =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
sorry

mlemma finseq_5_lm_2:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
sorry

mtheorem finseq_5_cl_5:
  mlet "i be NatNAT-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
    using finseq_5_lm_2 sorry
qed "sorry"

mtheorem finseq_5_th_22:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f ^FINSEQ-1K8 g) |FINSEQ-1K17 i =FINSEQ-1R1 f  |FINSEQ-1K17 i"
sorry

mtheorem finseq_5_th_23:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g) |FINSEQ-1K17 lenFINSEQ-1K4 f =FINSEQ-1R1 f"
sorry

mtheorem finseq_5_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
sorry

mtheorem finseq_5_th_25:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
sorry

reserve D for "setHIDDENM2"
reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_th_26:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
sorry

mtheorem finseq_5_th_27:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds ( for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies (f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)) & (i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +XCMPLX-0K2 i))"
sorry

mtheorem finseq_5_th_28:
" for f be FinSequenceFINSEQ-1M1 holds f /^RFINSEQK1 (0NUMBERSK6) =FINSEQ-1R1 f"
sorry

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f, g for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
sorry

mtheorem finseq_5_th_30:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f implies f /^RFINSEQK1 i =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 lenFINSEQ-1K4 f*>"
sorry

mtheorem finseq_5_th_31:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i & i inTARSKIR2 domFINSEQ-1K5 f implies (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> j"
sorry

mtheorem finseq_5_th_32:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f <=XXREAL-0R1 i implies f /^RFINSEQK1 i be emptyXBOOLE-0V1"
sorry

mtheorem finseq_5_th_33:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (f /^RFINSEQK1 n) c=TARSKIR1 rngFUNCT-1K2 f"
sorry

mlemma finseq_5_lm_3:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 implies f /^RFINSEQK2\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
sorry

mtheorem finseq_5_cl_6:
  mlet "i be NatNAT-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster f /^RFINSEQK2\<^bsub>(D)\<^esub> i as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f /^RFINSEQK2\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
    using finseq_5_lm_3 sorry
qed "sorry"

mtheorem finseq_5_th_34:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 (f  |FINSEQ-1K17 n) missesXBOOLE-0R1 rngFUNCT-1K2 (f /^RFINSEQK1 n)"
sorry

mtheorem finseq_5_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f  |--FINSEQ-4K6 p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f"
sorry

mtheorem finseq_5_th_36:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =FINSEQ-1R1 g /^RFINSEQK1 i"
sorry

mtheorem finseq_5_th_37:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g)/^RFINSEQK1 lenFINSEQ-1K4 f =FINSEQ-1R1 g"
sorry

mtheorem finseq_5_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
sorry

mtheorem finseq_5_th_39:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f <=XXREAL-0R1 i"
sorry

mtheorem finseq_5_th_40:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) implies p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
sorry

mtheorem finseq_5_th_41:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f & f be one-to-oneFUNCT-1V2 implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
sorry

mdef finseq_5_def_1 (" _ -:FINSEQ-5K1\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be setHIDDENM2"
"func f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
proof-
  (*coherence*)
    show "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) be FinSequenceFINSEQ-1M3-of D"
       sorry
qed "sorry"

mtheorem finseq_5_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
sorry

mtheorem finseq_5_th_43:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f) implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
sorry

mtheorem finseq_5_th_44:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
sorry

mtheorem finseq_5_th_45:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
sorry

mtheorem finseq_5_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for x be setHIDDENM2 holds (x inTARSKIR2 rngFUNCT-1K2 f & p inTARSKIR2 rngFUNCT-1K2 f) & x ..FINSEQ-4K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 f implies x inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_5_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be  non emptyXBOOLE-0V1"
sorry

mtheorem finseq_5_th_48:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
  using finseq_5_th_19 sorry

mtheorem finseq_5_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mdef finseq_5_def_2 (" _ :-FINSEQ-5K2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D"
"func f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
proof-
  (*coherence*)
    show "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f) be FinSequenceFINSEQ-1M3-of D"
       sorry
qed "sorry"

mtheorem finseq_5_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies ( ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
sorry

mtheorem finseq_5_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
sorry

mtheorem finseq_5_th_51:
" for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies j +NAT-1K1 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
sorry

mtheorem finseq_5_cl_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be FinSequenceFINSEQ-1M3-of D"
"cluster f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_5_th_52:
" for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 p ..FINSEQ-4K4 f)"
sorry

mtheorem finseq_5_th_53:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
  using finseq_5_th_15 sorry

mtheorem finseq_5_th_54:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
sorry

mtheorem finseq_5_th_55:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
sorry

mtheorem finseq_5_th_56:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & f be one-to-oneFUNCT-1V2 implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p be one-to-oneFUNCT-1V2"
sorry

reserve i for "NatNAT-1M1"
mdef finseq_5_def_3 ("RevFINSEQ-5K3  _ " [228]228 ) where
  mlet "f be FinSequenceFINSEQ-1M1"
"func RevFINSEQ-5K3 f \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem FINSEQ_5K3_involutiveness:
" for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (RevFINSEQ-5K3 f) =HIDDENR1 f"
sorry

mtheorem finseq_5_th_57:
" for f be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (RevFINSEQ-5K3 f) & rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
sorry

mtheorem finseq_5_th_58:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem finseq_5_th_59:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f & i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M implies j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
sorry

mtheorem finseq_5_cl_9:
  mlet "f be emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster RevFINSEQ-5K3 f as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem finseq_5_th_60:
" for x be objectHIDDENM1 holds RevFINSEQ-5K3 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
sorry

mtheorem finseq_5_th_61:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds RevFINSEQ-5K3 (<*FINSEQ-1K11 x1,x2 *>) =FINSEQ-1R1 <*FINSEQ-1K11 x2,x1 *>"
sorry

mtheorem finseq_5_th_62:
" for f be FinSequenceFINSEQ-1M1 holds f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f & f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_5_cl_10:
  mlet "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M1"
"cluster RevFINSEQ-5K3 f as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem finseq_5_th_63:
" for f be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f"
sorry

mtheorem finseq_5_th_64:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 RevFINSEQ-5K3 g ^FINSEQ-1K8 RevFINSEQ-5K3 f"
sorry

syntax FINSEQ_5K4 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("RevFINSEQ-5K4\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "RevFINSEQ-5K4\<^bsub>(D)\<^esub> f" \<rightharpoonup> "RevFINSEQ-5K3 f"

mtheorem finseq_5_add_1:
  mlet "D be setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D"
"cluster RevFINSEQ-5K3 f as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

mtheorem finseq_5_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =XBOOLE-0R4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
sorry

mtheorem finseq_5_th_66:
" for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f & i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
sorry

mdef finseq_5_def_4 ("InsFINSEQ-5K5\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D", "n be NatNAT-1M1"
"func InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
proof-
  (*coherence*)
    show "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) be FinSequenceFINSEQ-1M3-of D"
       sorry
qed "sorry"

mtheorem finseq_5_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,0NUMBERSK6,p) =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
sorry

mtheorem finseq_5_th_68:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) =FINSEQ-1R1 f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
sorry

mtheorem finseq_5_th_69:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_5_th_70:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =XBOOLE-0R4 {TARSKIK1 p} \\/XBOOLE-0K2 rngFUNCT-1K2 f"
sorry

mtheorem finseq_5_cl_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "n be NatNAT-1M1", "p be ElementSUBSET-1M1-of D"
"cluster InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_5_th_71:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p))"
sorry

mtheorem finseq_5_th_72:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
sorry

mtheorem finseq_5_th_73:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds n <=XXREAL-0R1 lenFINSEQ-1K4 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p"
sorry

mtheorem finseq_5_th_74:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 i"
sorry

mtheorem finseq_5_th_75:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & f be  non emptyXBOOLE-0V1 implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_5_th_76:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 &  not p inTARSKIR2 rngFUNCT-1K2 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) be one-to-oneFUNCT-1V2"
sorry

(*begin*)
mtheorem finseq_5_th_77:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i1 be NatNAT-1M1 holds  for i2 be NatNAT-1M1 holds i1 <=XXREAL-0R1 i2 implies (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1) |FINSEQ-1K18\<^bsub>(D)\<^esub> i2 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 & (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i2) |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1"
sorry

mtheorem finseq_5_th_78:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be NatNAT-1M1 holds <*>FINSEQ-1K7 D  |FINSEQ-1K18\<^bsub>(D)\<^esub> i =FINSEQ-1R1 <*>FINSEQ-1K7 D"
   sorry

mtheorem finseq_5_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds RevFINSEQ-5K4\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D =FINSEQ-1R1 <*>FINSEQ-1K7 D"
   sorry

mtheorem finseq_5_cl_12:
"cluster  non trivialZFMISC-1V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be  non trivialZFMISC-1V1"
sorry
qed "sorry"

mtheorem finseq_5_th_80:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for l1 be NatNAT-1M1 holds  for l2 be NatNAT-1M1 holds (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
sorry

reserve D for "setHIDDENM2"
reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_th_81:
" for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f >=XXREAL-0R2 \<two>\<^sub>M implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K11 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M *>"
sorry

mtheorem finseq_5_th_82:
" for k be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k ^FINSEQ-1K8 (<*FINSEQ-1K10 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)*>)"
sorry

mtheorem finseq_5_th_83:
" for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 p implies p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 p  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)*>)"
sorry

mtheorem finseq_5_th_84:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies p =FINSEQ-1R1 (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (n -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 n*>))^FINSEQ-1K8 (p /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
sorry

mtheorem finseq_5_th_85:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 DelFINSEQ-3K2(f,\<one>\<^sub>M)"
sorry

mtheorem finseq_5_th_86:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f =FINSEQ-1R1 (<*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (DelFINSEQ-3K2(f,\<one>\<^sub>M))"
sorry

end
