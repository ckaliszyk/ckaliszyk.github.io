theory finsop_1
  imports finseq_4 setwiseo
   "../mizar_extension/E_number"
begin
(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve d, d1, d2, d3 for "ElementSUBSET-1M1-of D"
reserve F, G, H, H1, H2 for "FinSequenceFINSEQ-1M3-of D"
reserve f, f1, f2 for "sequenceNAT-1M2-of D"
reserve g for "BinOpBINOP-1M2-of D"
reserve k, n, i, l for "NatNAT-1M1"
reserve P for "PermutationFUNCT-2M2-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
mdef finsop_1_def_1 (" _ \<inverse>**\<inverse>FINSOP-1K1\<^bsub>'( _ ')\<^esub>  _ " [148,0,148]148 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FinSequenceFINSEQ-1M3-of D", "g be BinOpBINOP-1M2-of D"
"assume g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M func g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F \<rightarrow> ElementSUBSET-1M1-of D means
  \<lambda>it. it =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g if g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 otherwise \<lambda>it.  ex f be sequenceNAT-1M2-of D st (f .NAT-1K8\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 n & n <XXREAL-0R3 lenFINSEQ-1K4 F implies f .NAT-1K8\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 g .BINOP-1K1(f .NAT-1K8\<^bsub>(D)\<^esub> n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & it =XBOOLE-0R4 f .NAT-1K8\<^bsub>(D)\<^esub> lenFINSEQ-1K4 F"
proof-
  (*existence*)
    show "g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of D st it =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g)) & ( not (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6) implies ( ex it be ElementSUBSET-1M1-of D st  ex f be sequenceNAT-1M2-of D st (f .NAT-1K8\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 n & n <XXREAL-0R3 lenFINSEQ-1K4 F implies f .NAT-1K8\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 g .BINOP-1K1(f .NAT-1K8\<^bsub>(D)\<^esub> n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & it =XBOOLE-0R4 f .NAT-1K8\<^bsub>(D)\<^esub> lenFINSEQ-1K4 F))"
sorry
  (*uniqueness*)
    show "g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies ( for it1 be ElementSUBSET-1M1-of D holds  for it2 be ElementSUBSET-1M1-of D holds (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 implies (it1 =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g & it2 =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g implies it1 =HIDDENR1 it2)) & ( not (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6) implies (( ex f be sequenceNAT-1M2-of D st (f .NAT-1K8\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 n & n <XXREAL-0R3 lenFINSEQ-1K4 F implies f .NAT-1K8\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 g .BINOP-1K1(f .NAT-1K8\<^bsub>(D)\<^esub> n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & it1 =XBOOLE-0R4 f .NAT-1K8\<^bsub>(D)\<^esub> lenFINSEQ-1K4 F) & ( ex f be sequenceNAT-1M2-of D st (f .NAT-1K8\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 n & n <XXREAL-0R3 lenFINSEQ-1K4 F implies f .NAT-1K8\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 g .BINOP-1K1(f .NAT-1K8\<^bsub>(D)\<^esub> n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & it2 =XBOOLE-0R4 f .NAT-1K8\<^bsub>(D)\<^esub> lenFINSEQ-1K4 F) implies it1 =HIDDENR1 it2)))"
sorry
  (*consistency*)
    show "g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies ( for it be ElementSUBSET-1M1-of D holds  True )"
sorry
qed "sorry"

mtheorem finsop_1_th_1:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies ( ex f be sequenceNAT-1M2-of D st (f .NAT-1K8\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 n & n <XXREAL-0R3 lenFINSEQ-1K4 F implies f .NAT-1K8\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 g .BINOP-1K1(f .NAT-1K8\<^bsub>(D)\<^esub> n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 f .NAT-1K8\<^bsub>(D)\<^esub> lenFINSEQ-1K4 F)"
  using finsop_1_def_1 sorry

mtheorem finsop_1_th_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M & ( ex f be sequenceNAT-1M2-of D st (f .NAT-1K8\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 n & n <XXREAL-0R3 lenFINSEQ-1K4 F implies f .NAT-1K8\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 g .BINOP-1K1(f .NAT-1K8\<^bsub>(D)\<^esub> n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & d =XBOOLE-0R4 f .NAT-1K8\<^bsub>(D)\<^esub> lenFINSEQ-1K4 F) implies d =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F"
  using finsop_1_def_1 sorry

syntax FINSOP_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +*FINSOP-1K2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "F +*FINSOP-1K2\<^bsub>(A)\<^esub> p" \<rightharpoonup> "F +*FUNCT-4K1 p"

mtheorem finsop_1_add_1:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be sequenceNAT-1M2-of A", "p be FinSequenceFINSEQ-1M3-of A"
"cluster F +*FUNCT-4K1 p as-term-is sequenceNAT-1M2-of A"
proof
(*coherence*)
  show "F +*FUNCT-4K1 p be sequenceNAT-1M2-of A"
sorry
qed "sorry"

abbreviation(input) FINSOP_1K3("findomFINSOP-1K3  _ " [164]164) where
  "findomFINSOP-1K3 f \<equiv> domRELAT-1K1 f"

abbreviation(input) FINSOP_1K4("findomFINSOP-1K4  _ " [164]164) where
  "findomFINSOP-1K4 f \<equiv> domRELAT-1K1 f"

mtheorem finsop_1_add_2:
  mlet "f be FinSequenceFINSEQ-1M1"
"cluster domRELAT-1K1 f as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
proof
(*coherence*)
  show "domRELAT-1K1 f be ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
sorry
qed "sorry"

mlemma finsop_1_lm_1:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds (lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M & g be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & g be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 F,(NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g)+*FINSOP-1K2\<^bsub>(D)\<^esub> F)"
sorry

mlemma finsop_1_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds ((lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 & g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & g be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & g be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 F,(NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g)+*FINSOP-1K2\<^bsub>(D)\<^esub> F)"
sorry

mtheorem finsop_1_th_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds ((g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M) & g be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & g be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 F,(NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g)+*FINSOP-1K2\<^bsub>(D)\<^esub> F)"
sorry

mlemma finsop_1_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for g be BinOpBINOP-1M2-of D holds g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g"
sorry

mlemma finsop_1_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-1K13\<^bsub>(D)\<^esub> d*> =XBOOLE-0R4 d"
sorry

mlemma finsop_1_lm_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>) =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F,d)"
sorry

mlemma finsop_1_lm_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>) =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F,d)"
sorry

mtheorem finsop_1_th_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>) =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F,d)"
sorry

mtheorem finsop_1_th_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds g be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M & lenFINSEQ-1K4 G >=XXREAL-0R2 \<one>\<^sub>M) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F ^FINSEQ-1K9\<^bsub>(D)\<^esub> G =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F,g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G)"
sorry

mtheorem finsop_1_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds g be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(d,g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F)"
sorry

mlemma finsop_1_lm_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds g be associativeBINOP-1V2\<^bsub>(D)\<^esub> & g be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies ( for f be PermutationFUNCT-2M2-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F holds (lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 G) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G implies G .FUNCT-1K1 i =XBOOLE-0R4 F .FUNCT-1K1 (f .FUNCT-1K1 i)) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G)"
sorry

mlemma finsop_1_lm_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds  for P be PermutationFUNCT-2M2-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F holds (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6) & G =FUNCT-1R1 F *FUNCT-1K3 P implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G"
sorry

mtheorem finsop_1_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds  for P be PermutationFUNCT-2M2-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F holds (g be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M)) & G =FUNCT-1R1 F *FUNCT-1K3 P implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G"
sorry

mlemma finsop_1_lm_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds (((g be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be one-to-oneFUNCT-1V2) & G be one-to-oneFUNCT-1V2) & rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G) & lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G"
sorry

mlemma finsop_1_lm_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds (((lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6 & g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be one-to-oneFUNCT-1V2) & G be one-to-oneFUNCT-1V2) & rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G"
sorry

mtheorem finsop_1_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds ((((g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M) & g be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub>) & F be one-to-oneFUNCT-1V2) & G be one-to-oneFUNCT-1V2) & rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G"
sorry

mlemma finsop_1_lm_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds lenFINSEQ-1K4 F =XBOOLE-0R4 \<one>\<^sub>M implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M"
sorry

mlemma finsop_1_lm_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for H be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds ((((g be associativeBINOP-1V2\<^bsub>(D)\<^esub> & g be commutativeBINOP-1V1\<^bsub>(D)\<^esub>) & lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M) & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 G) & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 H) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies H .FUNCT-1K1 k =XBOOLE-0R4 g .BINOP-1K1(F .FUNCT-1K1 k,G .FUNCT-1K1 k)) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> H =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F,g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G)"
sorry

mlemma finsop_1_lm_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for H be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds ((g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & lenFINSEQ-1K4 F =XBOOLE-0R4 0NUMBERSK6) & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 G) & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 H implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G,g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> H)"
sorry

mtheorem finsop_1_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for G be FinSequenceFINSEQ-1M3-of D holds  for H be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds (((g be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub> & (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 F >=XXREAL-0R2 \<one>\<^sub>M)) & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 G) & lenFINSEQ-1K4 F =XBOOLE-0R4 lenFINSEQ-1K4 H) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies F .FUNCT-1K1 k =XBOOLE-0R4 g .BINOP-1K1(G .FUNCT-1K1 k,H .FUNCT-1K1 k)) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G,g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> H)"
sorry

mtheorem finsop_1_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for g be BinOpBINOP-1M2-of D holds g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> g"
  using finsop_1_lm_3 sorry

mtheorem finsop_1_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-1K13\<^bsub>(D)\<^esub> d*> =XBOOLE-0R4 d"
  using finsop_1_lm_4 sorry

mtheorem finsop_1_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *> =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)"
sorry

mtheorem finsop_1_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *> =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-4K2\<^bsub>(D)\<^esub> d2,d1 *>"
sorry

mtheorem finsop_1_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *> =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),d3)"
sorry

mtheorem finsop_1_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g be commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *> =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*FINSEQ-4K3\<^bsub>(D)\<^esub> d2,d1,d3 *>"
sorry

mtheorem finsop_1_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> \<one>\<^sub>M  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d"
sorry

mtheorem finsop_1_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> \<two>\<^sub>M  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(d,d)"
sorry

mtheorem finsop_1_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds g be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or k <>HIDDENR2 0NUMBERSK6 & l <>HIDDENR2 0NUMBERSK6) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (k +XCMPLX-0K2 l) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 g .BINOP-1K4\<^bsub>(D)\<^esub>(g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> k  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> l  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
sorry

mtheorem finsop_1_th_19:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for g be BinOpBINOP-1M2-of D holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds g be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (g be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or k <>HIDDENR2 0NUMBERSK6 & l <>HIDDENR2 0NUMBERSK6) implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (k *XCMPLX-0K3 l) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> l  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> k  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
sorry

mtheorem finsop_1_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds lenFINSEQ-1K4 F =XBOOLE-0R4 \<one>\<^sub>M implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 F .FUNCT-1K1 \<one>\<^sub>M"
  using finsop_1_lm_11 sorry

mtheorem finsop_1_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FinSequenceFINSEQ-1M3-of D holds  for g be BinOpBINOP-1M2-of D holds lenFINSEQ-1K4 F =XBOOLE-0R4 \<two>\<^sub>M implies g \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 g .BINOP-1K1(F .FUNCT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 \<two>\<^sub>M)"
sorry

end
