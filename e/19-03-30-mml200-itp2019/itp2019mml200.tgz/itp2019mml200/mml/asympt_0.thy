theory asympt_0
  imports xxreal_2 limfunc1 pre_ff
   "../mizar_extension/E_number"
begin
(*begin*)
reserve c, c1, d for "RealXREAL-0M1"
reserve k for "NatNAT-1M1"
reserve n, m, N, n1, N1, N2, N3, N4, N5, M for "ElementSUBSET-1M1-of NATNUMBERSK1"
theorem asympt_0_sch_1:
  fixes mf0 nf0 Xf0 Ff1 
  assumes
[ty]: "mf0 be NatNAT-1M1" and
  [ty]: "nf0 be NatNAT-1M1" and
  [ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Xf0" and
   A1: "mf0 <=XXREAL-0R1 nf0"
  shows "{Ff1(i) where i be ElementSUBSET-1M1-of NATNUMBERSK1 : mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0 } be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of Xf0"
sorry

theorem asympt_0_sch_2:
  fixes Nf0 Xf0 Ff1 
  assumes
[ty]: "Nf0 be NatNAT-1M1" and
  [ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Xf0"
  shows "{Ff1(n) where n be ElementSUBSET-1M1-of NATNUMBERSK1 : n <=XXREAL-0R1 Nf0 } be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of Xf0"
sorry

theorem asympt_0_sch_3:
  fixes Nf0 Xf0 Ff1 
  assumes
[ty]: "Nf0 be NatNAT-1M1" and
  [ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Xf0" and
   A1: "Nf0 >XXREAL-0R4 0NUMBERSK6"
  shows "{Ff1(n) where n be ElementSUBSET-1M1-of NATNUMBERSK1 : n <XXREAL-0R3 Nf0 } be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of Xf0"
sorry

mdef asympt_0_def_1 ("logbaseASYMPT-0V1" 70 ) where
"attr logbaseASYMPT-0V1 for RealXREAL-0M1 means
  (\<lambda>c. c >XXREAL-0R4 0NUMBERSK6 & c <>HIDDENR2 \<one>\<^sub>M)"..

mtheorem asympt_0_cl_1:
"cluster positiveXXREAL-0V2 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be positiveXXREAL-0V2"
sorry
qed "sorry"

mtheorem asympt_0_cl_2:
"cluster negativeXXREAL-0V3 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be negativeXXREAL-0V3"
sorry
qed "sorry"

mtheorem asympt_0_cl_3:
"cluster logbaseASYMPT-0V1 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be logbaseASYMPT-0V1"
sorry
qed "sorry"

mtheorem asympt_0_cl_4:
"cluster  non negativeXXREAL-0V3 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be  non negativeXXREAL-0V3"
    using xxreal_0_def_7 sorry
qed "sorry"

mtheorem asympt_0_cl_5:
"cluster  non positiveXXREAL-0V2 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be  non positiveXXREAL-0V2"
    using xxreal_0_def_6 sorry
qed "sorry"

mtheorem asympt_0_cl_6:
"cluster  non logbaseASYMPT-0V1 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be  non logbaseASYMPT-0V1"
sorry
qed "sorry"

mdef asympt_0_def_2 ("eventually-nonnegativeASYMPT-0V2" 70 ) where
"attr eventually-nonnegativeASYMPT-0V2 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6)"..

mdef asympt_0_def_3 ("positiveASYMPT-0V3" 70 ) where
"attr positiveASYMPT-0V3 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6)"..

mdef asympt_0_def_4 ("eventually-positiveASYMPT-0V4" 70 ) where
"attr eventually-positiveASYMPT-0V4 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6)"..

mdef asympt_0_def_5 ("eventually-nonzeroASYMPT-0V5" 70 ) where
"attr eventually-nonzeroASYMPT-0V5 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6)"..

mdef asympt_0_def_6 ("eventually-nondecreasingASYMPT-0V6" 70 ) where
"attr eventually-nondecreasingASYMPT-0V6 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"..

mtheorem asympt_0_cl_7:
"cluster eventually-nonnegativeASYMPT-0V2\<bar>eventually-nonzeroASYMPT-0V5\<bar>positiveASYMPT-0V3\<bar>eventually-positiveASYMPT-0V4\<bar>eventually-nondecreasingASYMPT-0V6 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be eventually-nonnegativeASYMPT-0V2\<bar>eventually-nonzeroASYMPT-0V5\<bar>positiveASYMPT-0V3\<bar>eventually-positiveASYMPT-0V4\<bar>eventually-nondecreasingASYMPT-0V6"
sorry
qed "sorry"

mtheorem asympt_0_cl_8:
"cluster positiveASYMPT-0V3 also-is eventually-positiveASYMPT-0V4 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be positiveASYMPT-0V3 implies it be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

mtheorem asympt_0_cl_9:
"cluster eventually-positiveASYMPT-0V4 also-is eventually-nonnegativeASYMPT-0V2\<bar>eventually-nonzeroASYMPT-0V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be eventually-positiveASYMPT-0V4 implies it be eventually-nonnegativeASYMPT-0V2\<bar>eventually-nonzeroASYMPT-0V5"
sorry
qed "sorry"

mtheorem asympt_0_cl_10:
"cluster eventually-nonnegativeASYMPT-0V2\<bar>eventually-nonzeroASYMPT-0V5 also-is eventually-positiveASYMPT-0V4 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be eventually-nonnegativeASYMPT-0V2\<bar>eventually-nonzeroASYMPT-0V5 implies it be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

abbreviation(input) ASYMPT_0K1(" _ +ASYMPT-0K1  _ " [132,132]132) where
  "f +ASYMPT-0K1 g \<equiv> f +VALUED-1K1 g"

mtheorem asympt_0_add_1:
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
"cluster f +VALUED-1K1 g as-term-is eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "f +VALUED-1K1 g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
sorry
qed "sorry"

abbreviation(input) ASYMPT_0K2(" _ '(#')ASYMPT-0K2  _ " [164,164]164) where
  "c (#)ASYMPT-0K2 f \<equiv> c (#)VALUED-1K25 f"

mtheorem asympt_0_add_2:
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster c (#)VALUED-1K25 f as-term-is eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "c (#)VALUED-1K25 f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
sorry
qed "sorry"

abbreviation(input) ASYMPT_0K3(" _ +ASYMPT-0K3  _ " [132,132]132) where
  "c +ASYMPT-0K3 f \<equiv> c +VALUED-1K7 f"

mtheorem asympt_0_add_3:
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "c be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1"
"cluster c +VALUED-1K7 f as-term-is eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "c +VALUED-1K7 f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
sorry
qed "sorry"

abbreviation(input) ASYMPT_0K4(" _ +ASYMPT-0K4  _ " [132,132]132) where
  "c +ASYMPT-0K4 f \<equiv> c +VALUED-1K7 f"

mtheorem asympt_0_add_4:
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster c +VALUED-1K7 f as-term-is eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "c +VALUED-1K7 f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1"
sorry
qed "sorry"

mdef asympt_0_def_7 ("maxASYMPT-0K5'( _ , _ ')" [0,0]228 ) where
  mlet "f be Real-SequenceSEQ-1M1", "g be Real-SequenceSEQ-1M1"
"func maxASYMPT-0K5(f,g) \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 maxXXREAL-0K5(f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 maxXXREAL-0K5(f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 maxXXREAL-0K5(f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 maxXXREAL-0K5(f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem ASYMPT_0K5_commutativity:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds maxASYMPT-0K5(f,g) =HIDDENR1 maxASYMPT-0K5(g,f)"
sorry

mtheorem asympt_0_cl_11:
  mlet "f be Real-SequenceSEQ-1M1", "g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
"cluster maxASYMPT-0K5(f,g) as-term-is eventually-nonnegativeASYMPT-0V2"
proof
(*coherence*)
  show "maxASYMPT-0K5(f,g) be eventually-nonnegativeASYMPT-0V2"
sorry
qed "sorry"

mtheorem asympt_0_cl_12:
  mlet "f be Real-SequenceSEQ-1M1", "g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1"
"cluster maxASYMPT-0K5(f,g) as-term-is eventually-positiveASYMPT-0V4"
proof
(*coherence*)
  show "maxASYMPT-0K5(f,g) be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

mdef asympt_0_def_8 (" _ majorizesASYMPT-0R1  _ " [50,50]50 ) where
  mlet "f be Real-SequenceSEQ-1M1", "g be Real-SequenceSEQ-1M1"
"pred g majorizesASYMPT-0R1 f means
   ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"..

mlemma asympt_0_lm_1:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /REAL-1K6 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem asympt_0_th_1:
" for f be Real-SequenceSEQ-1M1 holds  for N be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds N <=XXREAL-0R1 n & n <=XXREAL-0R1 m implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
sorry

mtheorem asympt_0_th_2:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) <>HIDDENR2 0NUMBERSK6 implies g /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergentSEQ-2V5 & limSEQ-2K1 (g /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 (limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g))\<inverse>XCMPLX-0K5"
sorry

mtheorem asympt_0_th_3:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f be convergentSEQ-2V5 implies 0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 f"
sorry

mtheorem asympt_0_th_4:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds (f be convergentSEQ-2V5 & g be convergentSEQ-2V5) & g majorizesASYMPT-0R1 f implies limSEQ-2K1 f <=XXREAL-0R1 limSEQ-2K1 g"
sorry

mtheorem asympt_0_th_5:
" for f be Real-SequenceSEQ-1M1 holds  for g be eventually-nonzeroASYMPT-0V5\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be divergent-to+inftyLIMFUNC1V1 implies g /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergentSEQ-2V5 & limSEQ-2K1 (g /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 0NUMBERSK6"
sorry

(*begin*)
mdef asympt_0_def_9 ("Big-OhASYMPT-0K6  _ " [164]164 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
"func Big-OhASYMPT-0K6 f \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) } be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem asympt_0_th_6:
" for x be setHIDDENM2 holds  for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds x inTARSKIR2 Big-OhASYMPT-0K6 f implies x be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
sorry

mtheorem asympt_0_th_7:
" for f be positiveASYMPT-0V3\<bar>Real-SequenceSEQ-1M1 holds  for t be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds t inTARSKIR2 Big-OhASYMPT-0K6 f iff ( ex c be RealXREAL-0M1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mtheorem asympt_0_th_8:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for t be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds t inTARSKIR2 Big-OhASYMPT-0K6 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) implies ( ex c be RealXREAL-0M1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mtheorem asympt_0_th_9:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-OhASYMPT-0K6 (f +ASYMPT-0K1 g) =XBOOLE-0R4 Big-OhASYMPT-0K6 maxASYMPT-0K5(f,g)"
sorry

mtheorem asympt_0_th_10:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 f"
sorry

mtheorem asympt_0_th_11:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 g implies Big-OhASYMPT-0K6 f c=TARSKIR1 Big-OhASYMPT-0K6 g"
sorry

mtheorem asympt_0_th_12:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for h be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 g & g inTARSKIR2 Big-OhASYMPT-0K6 h implies f inTARSKIR2 Big-OhASYMPT-0K6 h"
sorry

mlemma asympt_0_lm_2:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 g & g inTARSKIR2 Big-OhASYMPT-0K6 f iff Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 g"
sorry

mtheorem asympt_0_th_13:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 (c (#)ASYMPT-0K2 f)"
sorry

mtheorem asympt_0_th_14:
" for c be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1 holds  for x be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds x inTARSKIR2 Big-OhASYMPT-0K6 f implies x inTARSKIR2 Big-OhASYMPT-0K6 (c +ASYMPT-0K3 f)"
sorry

mlemma asympt_0_lm_3:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) >XXREAL-0R4 0NUMBERSK6 implies f inTARSKIR2 Big-OhASYMPT-0K6 g"
sorry

mtheorem asympt_0_th_15:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) >XXREAL-0R4 0NUMBERSK6 implies Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 g"
sorry

mtheorem asympt_0_th_16:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) =COMPLEX1R1 0NUMBERSK6 implies f inTARSKIR2 Big-OhASYMPT-0K6 g &  not g inTARSKIR2 Big-OhASYMPT-0K6 f"
sorry

mtheorem asympt_0_th_17:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be divergent-to+inftyLIMFUNC1V1 implies  not f inTARSKIR2 Big-OhASYMPT-0K6 g & g inTARSKIR2 Big-OhASYMPT-0K6 f"
sorry

(*begin*)
mdef asympt_0_def_10 ("Big-OmegaASYMPT-0K7  _ " [164]164 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
"func Big-OmegaASYMPT-0K7 f \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st d >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st d >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) } be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem asympt_0_th_18:
" for x be setHIDDENM2 holds  for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds x inTARSKIR2 Big-OmegaASYMPT-0K7 f implies x be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
sorry

mtheorem asympt_0_th_19:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OmegaASYMPT-0K7 g iff g inTARSKIR2 Big-OhASYMPT-0K6 f"
sorry

mtheorem asympt_0_th_20:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OmegaASYMPT-0K7 f"
sorry

mtheorem asympt_0_th_21:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for h be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OmegaASYMPT-0K7 g & g inTARSKIR2 Big-OmegaASYMPT-0K7 h implies f inTARSKIR2 Big-OmegaASYMPT-0K7 h"
sorry

mtheorem asympt_0_th_22:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) >XXREAL-0R4 0NUMBERSK6 implies Big-OmegaASYMPT-0K7 f =XBOOLE-0R4 Big-OmegaASYMPT-0K7 g"
sorry

mtheorem asympt_0_th_23:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) =COMPLEX1R1 0NUMBERSK6 implies g inTARSKIR2 Big-OmegaASYMPT-0K7 f &  not f inTARSKIR2 Big-OmegaASYMPT-0K7 g"
sorry

mtheorem asympt_0_th_24:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be divergent-to+inftyLIMFUNC1V1 implies  not g inTARSKIR2 Big-OmegaASYMPT-0K7 f & f inTARSKIR2 Big-OmegaASYMPT-0K7 g"
sorry

mtheorem asympt_0_th_25:
" for f be positiveASYMPT-0V3\<bar>Real-SequenceSEQ-1M1 holds  for t be positiveASYMPT-0V3\<bar>Real-SequenceSEQ-1M1 holds t inTARSKIR2 Big-OmegaASYMPT-0K7 f iff ( ex d be RealXREAL-0M1 st d >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mtheorem asympt_0_th_26:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-OmegaASYMPT-0K7 (f +ASYMPT-0K1 g) =XBOOLE-0R4 Big-OmegaASYMPT-0K7 maxASYMPT-0K5(f,g)"
sorry

mdef asympt_0_def_11 ("Big-ThetaASYMPT-0K8  _ " [164]164 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1"
"func Big-ThetaASYMPT-0K8 f \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  (Big-OhASYMPT-0K6 f)/\\XBOOLE-0K3 (Big-OmegaASYMPT-0K7 f)"
proof-
  (*coherence*)
    show "(Big-OhASYMPT-0K6 f)/\\XBOOLE-0K3 (Big-OmegaASYMPT-0K7 f) be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem asympt_0_th_27:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-ThetaASYMPT-0K8 f =XBOOLE-0R4 {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st (c >XXREAL-0R4 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) }"
sorry

mtheorem asympt_0_th_28:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-ThetaASYMPT-0K8 f"
sorry

mtheorem asympt_0_th_29:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-ThetaASYMPT-0K8 g implies g inTARSKIR2 Big-ThetaASYMPT-0K8 f"
sorry

mtheorem asympt_0_th_30:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for h be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-ThetaASYMPT-0K8 g & g inTARSKIR2 Big-ThetaASYMPT-0K8 h implies f inTARSKIR2 Big-ThetaASYMPT-0K8 h"
sorry

mtheorem asympt_0_th_31:
" for f be positiveASYMPT-0V3\<bar>Real-SequenceSEQ-1M1 holds  for t be positiveASYMPT-0V3\<bar>Real-SequenceSEQ-1M1 holds t inTARSKIR2 Big-ThetaASYMPT-0K8 f iff ( ex c be RealXREAL-0M1 st  ex d be RealXREAL-0M1 st (c >XXREAL-0R4 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mtheorem asympt_0_th_32:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-ThetaASYMPT-0K8 (f +ASYMPT-0K1 g) =XBOOLE-0R4 Big-ThetaASYMPT-0K8 maxASYMPT-0K5(f,g)"
sorry

mtheorem asympt_0_th_33:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) >XXREAL-0R4 0NUMBERSK6 implies f inTARSKIR2 Big-ThetaASYMPT-0K8 g"
sorry

mtheorem asympt_0_th_34:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g) =COMPLEX1R1 0NUMBERSK6 implies f inTARSKIR2 Big-OhASYMPT-0K6 g &  not f inTARSKIR2 Big-ThetaASYMPT-0K8 g"
sorry

mtheorem asympt_0_th_35:
" for f be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 holds f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g be divergent-to+inftyLIMFUNC1V1 implies f inTARSKIR2 Big-OmegaASYMPT-0K7 g &  not f inTARSKIR2 Big-ThetaASYMPT-0K8 g"
sorry

(*begin*)
mdef asympt_0_def_12 ("Big-OhASYMPT-0K9'( _ , _ ')" [0,0]164 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "X be setHIDDENM2"
"func Big-OhASYMPT-0K9(f,X) \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N & n inTARSKIR2 X implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N & n inTARSKIR2 X implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) } be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

mdef asympt_0_def_13 ("Big-OmegaASYMPT-0K10'( _ , _ ')" [0,0]164 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "X be setHIDDENM2"
"func Big-OmegaASYMPT-0K10(f,X) \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st d >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N & n inTARSKIR2 X implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st d >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N & n inTARSKIR2 X implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) } be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

mdef asympt_0_def_14 ("Big-ThetaASYMPT-0K11'( _ , _ ')" [0,0]164 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "X be setHIDDENM2"
"func Big-ThetaASYMPT-0K11(f,X) \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st (c >XXREAL-0R4 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N & n inTARSKIR2 X implies d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex c be RealXREAL-0M1 st  ex d be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st (c >XXREAL-0R4 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N & n inTARSKIR2 X implies d *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) } be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem asympt_0_th_36:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for X be setHIDDENM2 holds Big-ThetaASYMPT-0K11(f,X) =XBOOLE-0R4 (Big-OhASYMPT-0K9(f,X))/\\XBOOLE-0K3 (Big-OmegaASYMPT-0K10(f,X))"
sorry

mdef asympt_0_def_15 (" _ taken-everyASYMPT-0K12  _ " [164,164]164 ) where
  mlet "f be Real-SequenceSEQ-1M1", "b be NatNAT-1M1"
"func f taken-everyASYMPT-0K12 b \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (b *XCMPLX-0K3 n)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (b *XCMPLX-0K3 n)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (b *XCMPLX-0K3 n)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (b *XCMPLX-0K3 n)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef asympt_0_def_16 (" _ is-smooth-wrtASYMPT-0R2  _ " [50,50]50 ) where
  mlet "f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1", "b be NatNAT-1M1"
"pred f is-smooth-wrtASYMPT-0R2 b means
  f be eventually-nondecreasingASYMPT-0V6 & f taken-everyASYMPT-0K12 b inTARSKIR2 Big-OhASYMPT-0K6 f"..

mdef asympt_0_def_17 ("smoothASYMPT-0V7" 70 ) where
"attr smoothASYMPT-0V7 for eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for b be ElementSUBSET-1M1-of NATNUMBERSK1 holds b >=XXREAL-0R2 \<two>\<^sub>M implies f is-smooth-wrtASYMPT-0R2 b)"..

mtheorem asympt_0_th_37:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds ( ex b be ElementSUBSET-1M1-of NATNUMBERSK1 st b >=XXREAL-0R2 \<two>\<^sub>M & f is-smooth-wrtASYMPT-0R2 b) implies f be smoothASYMPT-0V7"
sorry

mtheorem asympt_0_th_38:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for t be eventually-nonnegativeASYMPT-0V2\<bar>eventually-nondecreasingASYMPT-0V6\<bar>Real-SequenceSEQ-1M1 holds  for b be NatNAT-1M1 holds (f be smoothASYMPT-0V7 & b >=XXREAL-0R2 \<two>\<^sub>M) & t inTARSKIR2 Big-OhASYMPT-0K9(f,{b  |^NEWTONK1 n where n be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  }) implies t inTARSKIR2 Big-OhASYMPT-0K6 f"
sorry

mtheorem asympt_0_th_39:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for t be eventually-nonnegativeASYMPT-0V2\<bar>eventually-nondecreasingASYMPT-0V6\<bar>Real-SequenceSEQ-1M1 holds  for b be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f be smoothASYMPT-0V7 & b >=XXREAL-0R2 \<two>\<^sub>M) & t inTARSKIR2 Big-OmegaASYMPT-0K10(f,{b  |^NEWTONK11 n where n be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  }) implies t inTARSKIR2 Big-OmegaASYMPT-0K7 f"
sorry

mtheorem asympt_0_th_40:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for t be eventually-nonnegativeASYMPT-0V2\<bar>eventually-nondecreasingASYMPT-0V6\<bar>Real-SequenceSEQ-1M1 holds  for b be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f be smoothASYMPT-0V7 & b >=XXREAL-0R2 \<two>\<^sub>M) & t inTARSKIR2 Big-ThetaASYMPT-0K11(f,{b  |^NEWTONK11 n where n be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  }) implies t inTARSKIR2 Big-ThetaASYMPT-0K8 f"
sorry

(*begin*)
mdef asympt_0_def_18 (" _ +ASYMPT-0K13\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2)", "G be FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2)"
"func F +ASYMPT-0K13\<^bsub>(X)\<^esub> G \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) :  ex f be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st  ex g be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st (f inTARSKIR2 F & g inTARSKIR2 G) & ( for n be ElementSUBSET-1M1-of X holds t .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n +REAL-1K3 g .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) :  ex f be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st  ex g be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st (f inTARSKIR2 F & g inTARSKIR2 G) & ( for n be ElementSUBSET-1M1-of X holds t .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n +REAL-1K3 g .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n) } be FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2)"
sorry
qed "sorry"

mdef asympt_0_def_19 ("maxASYMPT-0K14\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]228 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2)", "G be FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2)"
"func maxASYMPT-0K14\<^bsub>(X)\<^esub>(F,G) \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) :  ex f be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st  ex g be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st (f inTARSKIR2 F & g inTARSKIR2 G) & ( for n be ElementSUBSET-1M1-of X holds t .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 maxXXREAL-0K5(f .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n,g .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n)) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) :  ex f be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st  ex g be ElementFUNCT-2M4\<^bsub>(X,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(X,REALNUMBERSK2) st (f inTARSKIR2 F & g inTARSKIR2 G) & ( for n be ElementSUBSET-1M1-of X holds t .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 maxXXREAL-0K5(f .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n,g .FUNCT-2K3\<^bsub>(X,REALNUMBERSK2)\<^esub> n)) } be FUNCTION-DOMAINFUNCT-2M3-of(X,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem asympt_0_th_41:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-OhASYMPT-0K6 f +ASYMPT-0K13\<^bsub>(NATNUMBERSK1)\<^esub> Big-OhASYMPT-0K6 g =XBOOLE-0R4 Big-OhASYMPT-0K6 (f +ASYMPT-0K1 g)"
sorry

mtheorem asympt_0_th_42:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds maxASYMPT-0K14\<^bsub>(NATNUMBERSK1)\<^esub>(Big-OhASYMPT-0K6 f,Big-OhASYMPT-0K6 g) =XBOOLE-0R4 Big-OhASYMPT-0K6 maxASYMPT-0K5(f,g)"
sorry

mdef asympt_0_def_20 (" _ to-powerASYMPT-0K15  _ " [220,220]220 ) where
  mlet "F be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)", "G be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
"func F to-powerASYMPT-0K15 G \<rightarrow> FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) equals
  {t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex f be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) st  ex g be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st (f inTARSKIR2 F & g inTARSKIR2 G) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) }"
proof-
  (*coherence*)
    show "{t where t be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) :  ex f be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) st  ex g be ElementFUNCT-2M4\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(NATNUMBERSK1,REALNUMBERSK2) st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st (f inTARSKIR2 F & g inTARSKIR2 G) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) } be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2)"
sorry
qed "sorry"

end
