theory funct_7
  imports rewrite1 valued_1 axioms
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, x, y for "objectHIDDENM1"
reserve A, B for "setHIDDENM2"
reserve l, m, n for "NatNAT-1M1"
mtheorem funct_7_th_1:
" for f be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds rngFUNCT-1K2 f c=TARSKIR1 X implies idPARTFUN1K6 X *FUNCT-1K3 f =FUNCT-1R1 f"
sorry

mtheorem funct_7_th_2:
" for X be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 implies ( for B be SubsetSUBSET-1M2-of X holds  for C be SubsetSUBSET-1M2-of Y holds C c=TARSKIR1 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> C c=TARSKIR1 B)"
sorry

mtheorem funct_7_th_3:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 implies ( for x be ElementSUBSET-1M1-of X holds  for A be SubsetSUBSET-1M2-of X holds f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A implies x inTARSKIR2 A)"
sorry

mtheorem funct_7_th_4:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 implies ( for x be ElementSUBSET-1M1-of X holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of Y holds f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\SUBSET-1K7\<^bsub>(Y)\<^esub> B implies x inTARSKIR2 A \\SUBSET-1K7\<^bsub>(X)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> B)"
sorry

mtheorem funct_7_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 implies ( for y be ElementSUBSET-1M1-of Y holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of Y holds y inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\SUBSET-1K7\<^bsub>(Y)\<^esub> B implies f \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 A \\SUBSET-1K7\<^bsub>(X)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> B)"
sorry

mtheorem funct_7_th_6:
" for f be FunctionFUNCT-1M1 holds  for a be setHIDDENM2 holds a inTARSKIR2 domRELAT-1K1 f implies f  |RELAT-1K8 {TARSKIK1 a} =FUNCT-1R1 a .-->FUNCOP-1K17 f .FUNCT-1K1 a"
sorry

mtheorem funct_7_cl_1:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster x .-->FUNCOP-1K17 y as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "x .-->FUNCOP-1K17 y be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem funct_7_cl_2:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"cluster (x,y)-->FUNCT-4K6(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "(x,y)-->FUNCT-4K6(a,b) be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem funct_7_th_7:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies i .-->FUNCOP-1K17 M .FUNCT-1K1 i =FUNCT-1R1 M  |RELAT-1K8 {TARSKIK1 i}"
sorry

mtheorem funct_7_th_8:
" for I be setHIDDENM2 holds  for J be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of [:ZFMISC-1K2 I,J :] holds  for i be setHIDDENM2 holds  for j be setHIDDENM2 holds i inTARSKIR2 I & j inTARSKIR2 J implies (i,j):->FUNCOP-1K19 (M .BINOP-1K1(i,j)) =FUNCT-1R1 M  |RELAT-1K8 ([:ZFMISC-1K2 {TARSKIK1 i},{TARSKIK1 j} :])"
sorry

mtheorem funct_7_th_9:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f implies f *FUNCT-1K3 (g +*FUNCT-4K1 h) =FUNCT-1R1 (f *FUNCT-1K3 g)+*FUNCT-4K1 (f *FUNCT-1K3 h)"
sorry

mtheorem funct_7_th_10:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (g +*FUNCT-4K1 h)*FUNCT-1K3 f =FUNCT-1R1 (g *FUNCT-1K3 f)+*FUNCT-4K1 (h *FUNCT-1K3 f)"
sorry

mtheorem funct_7_th_11:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f missesXBOOLE-0R1 domRELAT-1K1 g implies (h +*FUNCT-4K1 g)*FUNCT-1K3 f =FUNCT-1R1 h *FUNCT-1K3 f"
sorry

mtheorem funct_7_th_12:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for y be setHIDDENM2 holds A meetsXBOOLE-0R5 rngFUNCT-1K2 (idPARTFUN1K6 B +*FUNCT-4K1 (A -->FUNCOP-1K7 y)) implies y inTARSKIR2 A"
sorry

mtheorem funct_7_th_13:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for A be setHIDDENM2 holds x <>HIDDENR2 y implies  not x inTARSKIR2 rngFUNCT-1K2 (idPARTFUN1K6 A +*FUNCT-4K1 (x .-->FUNCOP-1K17 y))"
sorry

mtheorem funct_7_th_14:
" for X be setHIDDENM2 holds  for a be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X \\/XBOOLE-0K2 {TARSKIK1 a} implies f =FUNCT-1R1 f  |RELAT-1K8 X +*FUNCT-4K1 (a .-->FUNCOP-1K17 f .FUNCT-1K1 a)"
sorry

mtheorem funct_7_th_15:
" for f be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds (f +*FUNCT-4K1 (X -->FUNCOP-1K7 y))+*FUNCT-4K1 (X -->FUNCOP-1K7 z) =FUNCT-1R1 f +*FUNCT-4K1 (X -->FUNCOP-1K7 z)"
sorry

mtheorem funct_7_th_16:
"INTNUMBERSK5 <>HIDDENR2 INTNUMBERSK5 * FINSEQ-2K3"
sorry

mtheorem funct_7_th_17:
"{}XBOOLE-0K1 * FINSEQ-2K3 =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
sorry

mtheorem funct_7_th_18:
" for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> inTARSKIR2 A * FINSEQ-2K3 iff x inHIDDENR3 A"
sorry

mtheorem funct_7_th_19:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A * FINSEQ-2K3 c=TARSKIR1 B * FINSEQ-2K3 implies A c=TARSKIR1 B"
sorry

mtheorem funct_7_th_20:
" for A be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 A & m <XXREAL-0R3 n implies m inTARSKIR2 A) implies A be CardinalCARD-1M1"
sorry

mtheorem funct_7_th_21:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of A holds  ex C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of X st  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of X holds B c=TARSKIR1 C implies B =XBOOLE-0R4 C"
sorry

mtheorem funct_7_th_22:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M implies ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 q iff i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p)"
sorry

mtheorem funct_7_cl_3:
"cluster Function-yieldingFUNCOP-1V1\<bar> non emptyXBOOLE-0V1\<bar>non-emptyFUNCT-1V4 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be Function-yieldingFUNCOP-1V1\<bar> non emptyXBOOLE-0V1\<bar>non-emptyFUNCT-1V4"
sorry
qed "sorry"

mtheorem funct_7_cl_4:
"cluster emptyXBOOLE-0V1 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem funct_7_cl_5:
  mlet "n be NatNAT-1M1", "f be FunctionFUNCT-1M1"
"cluster n  |->FINSEQ-2K2 f as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 f be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem funct_7_cl_6:
  mlet "p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1", "q be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be Function-yieldingFUNCOP-1V1"
sorry
qed "sorry"

mtheorem funct_7_th_23:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q be Function-yieldingFUNCOP-1V1 implies p be Function-yieldingFUNCOP-1V1 & q be Function-yieldingFUNCOP-1V1"
sorry

(*begin*)
theorem funct_7_sch_1:
  fixes Xf0 Yf0 Zf0 Ff2 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Zf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be ElementSUBSET-1M1-of Xf0 \<Longrightarrow> x2 be ElementSUBSET-1M1-of Yf0 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds Ff2(x,y) inHIDDENR3 Zf0"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds f .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y) =HIDDENR1 Ff2(x,y)"
sorry

theorem funct_7_sch_2:
  fixes Af0 Df0 Ff1 Gf1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: "Af0 be finiteFINSET-1V1" and
   A2: " for d1 be ElementSUBSET-1M1-of Df0 holds  for d2 be ElementSUBSET-1M1-of Df0 holds Gf1(d1) =HIDDENR1 Gf1(d2) implies d1 =XBOOLE-0R4 d2"
  shows "{Ff1(d) where d be ElementSUBSET-1M1-of Df0 : Gf1(d) inHIDDENR3 Af0 } be finiteFINSET-1V1"
sorry

theorem funct_7_sch_3:
  fixes Af0 Df0 Gf1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: " for x be setHIDDENM2 holds x inTARSKIR2 Af0 implies ( ex d be ElementSUBSET-1M1-of Df0 st x =HIDDENR1 Gf1(d))" and
   A2: " for d1 be ElementSUBSET-1M1-of Df0 holds  for d2 be ElementSUBSET-1M1-of Df0 holds Gf1(d1) =HIDDENR1 Gf1(d2) implies d1 =XBOOLE-0R4 d2"
  shows "(Af0,{d where d be ElementSUBSET-1M1-of Df0 : Gf1(d) inHIDDENR3 Af0 })are-equipotentWELLORD2R2"
sorry

theorem funct_7_sch_4:
  fixes Af0 Df0 Gf1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: "Af0 c=TARSKIR1 Df0" and
   A2: " for d1 be ElementSUBSET-1M1-of Df0 holds  for d2 be ElementSUBSET-1M1-of Df0 holds Gf1(d1) =HIDDENR1 Gf1(d2) implies d1 =XBOOLE-0R4 d2"
  shows "(Af0,{Gf1(d) where d be ElementSUBSET-1M1-of Df0 : d inTARSKIR2 Af0 })are-equipotentWELLORD2R2"
sorry

theorem funct_7_sch_5:
  fixes Pp1 
  assumes
    A1: "Pp1({}XBOOLE-0K1)" and
   A2: " for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds Pp1(p) implies ( for f be FunctionFUNCT-1M1 holds Pp1(p ^FINSEQ-1K8 (<*FINSEQ-1K10 f*>)))"
  shows " for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds Pp1(p)"
sorry

(*begin*)
(*\$CD*)
mdef funct_7_def_2 ("'( _ , _ ')equal-outsideFUNCT-7R1  _ " [0,0,50]50 ) where
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1", "A be setHIDDENM2"
"pred (f,g)equal-outsideFUNCT-7R1 A means
  f  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 A) =FUNCT-1R1 g  |RELAT-1K8 (domRELAT-1K1 g \\SUBSET-1K6 A)"..

(*\$CT*)
mtheorem funct_7_th_25:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f,f)equal-outsideFUNCT-7R1 A"
   sorry

mtheorem funct_7_th_26:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f,g)equal-outsideFUNCT-7R1 A implies (g,f)equal-outsideFUNCT-7R1 A"
   sorry

mtheorem funct_7_th_27:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f,g)equal-outsideFUNCT-7R1 A & (g,h)equal-outsideFUNCT-7R1 A implies (f,h)equal-outsideFUNCT-7R1 A"
   sorry

mtheorem funct_7_th_28:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f,g)equal-outsideFUNCT-7R1 A implies domRELAT-1K1 f \\SUBSET-1K6 A =XBOOLE-0R4 domRELAT-1K1 g \\SUBSET-1K6 A"
sorry

mtheorem funct_7_th_29:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds domRELAT-1K1 g c=TARSKIR1 A implies (f,f +*FUNCT-4K1 g)equal-outsideFUNCT-7R1 A"
sorry

mdef funct_7_def_3 (" _ +*FUNCT-7K1'( _ , _ ')" [164,0,0]164 ) where
  mlet "f be FunctionFUNCT-1M1", "i be objectHIDDENM1", "x be objectHIDDENM1"
"func f +*FUNCT-7K1(i,x) \<rightarrow> FunctionFUNCT-1M1 equals
  f +*FUNCT-4K1 (i .-->FUNCOP-1K17 x) if i inHIDDENR3 domRELAT-1K1 f otherwise f"
proof-
  (*coherence*)
    show "(i inHIDDENR3 domRELAT-1K1 f implies f +*FUNCT-4K1 (i .-->FUNCOP-1K17 x) be FunctionFUNCT-1M1) & ( not i inHIDDENR3 domRELAT-1K1 f implies f be FunctionFUNCT-1M1)"
       sorry
  (*consistency*)
    show " for it be FunctionFUNCT-1M1 holds  True "
       sorry
qed "sorry"

mtheorem funct_7_th_30:
" for f be FunctionFUNCT-1M1 holds  for d be objectHIDDENM1 holds  for i be objectHIDDENM1 holds domRELAT-1K1 (f +*FUNCT-7K1(i,d)) =XBOOLE-0R4 domRELAT-1K1 f"
sorry

mtheorem funct_7_cl_7:
  mlet "f be emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1", "i be objectHIDDENM1", "x be objectHIDDENM1"
"cluster f +*FUNCT-7K1(i,x) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f +*FUNCT-7K1(i,x) be emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem funct_7_cl_8:
  mlet "f be  non emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1", "i be objectHIDDENM1", "x be objectHIDDENM1"
"cluster f +*FUNCT-7K1(i,x) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f +*FUNCT-7K1(i,x) be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem funct_7_th_31:
" for f be FunctionFUNCT-1M1 holds  for d be objectHIDDENM1 holds  for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies (f +*FUNCT-7K1(i,d)).FUNCT-1K1 i =HIDDENR1 d"
sorry

mtheorem funct_7_th_32:
" for f be FunctionFUNCT-1M1 holds  for d be objectHIDDENM1 holds  for i be objectHIDDENM1 holds  for j be objectHIDDENM1 holds i <>HIDDENR2 j implies (f +*FUNCT-7K1(i,d)).FUNCT-1K1 j =XBOOLE-0R4 f .FUNCT-1K1 j"
sorry

mtheorem funct_7_th_33:
" for f be FunctionFUNCT-1M1 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for i be setHIDDENM2 holds  for j be setHIDDENM2 holds i <>HIDDENR2 j implies (f +*FUNCT-7K1(i,d))+*FUNCT-7K1(j,e) =FUNCT-1R1 (f +*FUNCT-7K1(j,e))+*FUNCT-7K1(i,d)"
sorry

mtheorem funct_7_th_34:
" for f be FunctionFUNCT-1M1 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for i be setHIDDENM2 holds (f +*FUNCT-7K1(i,d))+*FUNCT-7K1(i,e) =FUNCT-1R1 f +*FUNCT-7K1(i,e)"
sorry

mtheorem funct_7_th_35:
" for f be FunctionFUNCT-1M1 holds  for i be setHIDDENM2 holds f +*FUNCT-7K1(i,f .FUNCT-1K1 i) =FUNCT-1R1 f"
sorry

mtheorem funct_7_cl_9:
  mlet "f be FinSequenceFINSEQ-1M1", "i be objectHIDDENM1", "x be objectHIDDENM1"
"cluster f +*FUNCT-7K1(i,x) as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f +*FUNCT-7K1(i,x) be FinSequence-likeFINSEQ-1V1"
sorry
qed "sorry"

syntax FUNCT_7K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +*FUNCT-7K2\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [164,0,0,0]164)
translations "f +*FUNCT-7K2\<^bsub>(D)\<^esub>(i,d)" \<rightharpoonup> "f +*FUNCT-7K1(i,d)"

mtheorem funct_7_add_1:
  mlet "D be setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "i be NatNAT-1M1", "d be ElementSUBSET-1M1-of D"
"cluster f +*FUNCT-7K1(i,d) as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "f +*FUNCT-7K1(i,d) be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

mtheorem funct_7_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies (f +*FUNCT-7K2\<^bsub>(D)\<^esub>(i,d))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 d"
sorry

mtheorem funct_7_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i <>HIDDENR2 j & j inTARSKIR2 domFINSEQ-1K5 f implies (f +*FUNCT-7K2\<^bsub>(D)\<^esub>(i,d))/.PARTFUN1K7\<^bsub>(D)\<^esub> j =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
sorry

mtheorem funct_7_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for i be NatNAT-1M1 holds f +*FUNCT-7K2\<^bsub>(D)\<^esub>(i,f /.PARTFUN1K7\<^bsub>(D)\<^esub> i) =FINSEQ-1R1 f"
sorry

(*begin*)
mdef funct_7_def_4 ("composeFUNCT-7K3'( _ , _ ')" [0,0]164 ) where
  mlet "X be setHIDDENM2", "p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1"
"func composeFUNCT-7K3(p,X) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it.  ex f be ManySortedFunctionPBOOLEM2-of NATNUMBERSK1 st (it =FUNCT-1R1 f .FUNCT-1K1 lenFINSEQ-1K4 p & f .FUNCT-1K1 (0NUMBERSK6) =FUNCT-1R1 idPARTFUN1K6 X) & ( for i be NatNAT-1M1 holds i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g =FUNCT-1R1 f .FUNCT-1K1 i & h =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 h *FUNCT-1K3 g))"
proof-
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds ( ex f be ManySortedFunctionPBOOLEM2-of NATNUMBERSK1 st (it1 =FUNCT-1R1 f .FUNCT-1K1 lenFINSEQ-1K4 p & f .FUNCT-1K1 (0NUMBERSK6) =FUNCT-1R1 idPARTFUN1K6 X) & ( for i be NatNAT-1M1 holds i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g =FUNCT-1R1 f .FUNCT-1K1 i & h =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 h *FUNCT-1K3 g))) & ( ex f be ManySortedFunctionPBOOLEM2-of NATNUMBERSK1 st (it2 =FUNCT-1R1 f .FUNCT-1K1 lenFINSEQ-1K4 p & f .FUNCT-1K1 (0NUMBERSK6) =FUNCT-1R1 idPARTFUN1K6 X) & ( for i be NatNAT-1M1 holds i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g =FUNCT-1R1 f .FUNCT-1K1 i & h =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 h *FUNCT-1K3 g))) implies it1 =HIDDENR1 it2"
sorry
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st  ex f be ManySortedFunctionPBOOLEM2-of NATNUMBERSK1 st (it =FUNCT-1R1 f .FUNCT-1K1 lenFINSEQ-1K4 p & f .FUNCT-1K1 (0NUMBERSK6) =FUNCT-1R1 idPARTFUN1K6 X) & ( for i be NatNAT-1M1 holds i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g =FUNCT-1R1 f .FUNCT-1K1 i & h =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 h *FUNCT-1K3 g))"
sorry
qed "sorry"

mdef funct_7_def_5 ("applyFUNCT-7K4'( _ , _ ')" [0,0]164 ) where
  mlet "p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1", "x be objectHIDDENM1"
"func applyFUNCT-7K4(p,x) \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. (lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M & it .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & ( for i be NatNAT-1M1 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & f =FUNCT-1R1 p .FUNCT-1K1 i implies it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (it .FUNCT-1K1 i))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M & it .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & ( for i be NatNAT-1M1 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & f =FUNCT-1R1 p .FUNCT-1K1 i implies it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (it .FUNCT-1K1 i))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds ((lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M & it1 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & ( for i be NatNAT-1M1 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & f =FUNCT-1R1 p .FUNCT-1K1 i implies it1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (it1 .FUNCT-1K1 i))) & ((lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M & it2 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & ( for i be NatNAT-1M1 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & f =FUNCT-1R1 p .FUNCT-1K1 i implies it2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (it2 .FUNCT-1K1 i))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

reserve X, Y for "setHIDDENM2"
reserve x for "objectHIDDENM1"
reserve p, q for "Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1"
reserve f, g, h for "FunctionFUNCT-1M1"
mtheorem funct_7_th_39:
" for X be setHIDDENM2 holds composeFUNCT-7K3({}XBOOLE-0K1,X) =FUNCT-1R1 idPARTFUN1K6 X"
sorry

mtheorem funct_7_th_40:
" for x be objectHIDDENM1 holds applyFUNCT-7K4({}XBOOLE-0K1,x) =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
sorry

mtheorem funct_7_th_41:
" for X be setHIDDENM2 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for f be FunctionFUNCT-1M1 holds composeFUNCT-7K3(p ^FINSEQ-1K8 (<*FINSEQ-1K10 f*>),X) =FUNCT-1R1 f *FUNCT-1K3 (composeFUNCT-7K3(p,X))"
sorry

mtheorem funct_7_th_42:
" for x be objectHIDDENM1 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for f be FunctionFUNCT-1M1 holds applyFUNCT-7K4(p ^FINSEQ-1K8 (<*FINSEQ-1K10 f*>),x) =FINSEQ-1R1 (applyFUNCT-7K4(p,x))^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 ((applyFUNCT-7K4(p,x)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))*>)"
sorry

mtheorem funct_7_th_43:
" for X be setHIDDENM2 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for f be FunctionFUNCT-1M1 holds composeFUNCT-7K3((<*FINSEQ-1K10 f*>)^FINSEQ-1K8 p,X) =FUNCT-1R1 (composeFUNCT-7K3(p,f .:FUNCT-1K5 X))*FUNCT-1K3 f  |RELAT-1K8 X"
sorry

mtheorem funct_7_th_44:
" for x be objectHIDDENM1 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for f be FunctionFUNCT-1M1 holds applyFUNCT-7K4((<*FINSEQ-1K10 f*>)^FINSEQ-1K8 p,x) =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (applyFUNCT-7K4(p,f .FUNCT-1K1 x))"
sorry

mtheorem funct_7_th_45:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds composeFUNCT-7K3(<*FINSEQ-1K10 f*>,X) =FUNCT-1R1 f *FUNCT-1K3 idPARTFUN1K6 X"
sorry

mtheorem funct_7_th_46:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 X implies composeFUNCT-7K3(<*FINSEQ-1K10 f*>,X) =FUNCT-1R1 f"
sorry

mtheorem funct_7_th_47:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds applyFUNCT-7K4(<*FINSEQ-1K10 f*>,x) =FINSEQ-1R1 <*FINSEQ-1K11 x,f .FUNCT-1K1 x *>"
sorry

mtheorem funct_7_th_48:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for q be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (composeFUNCT-7K3(p,X)) c=TARSKIR1 Y implies composeFUNCT-7K3(p ^FINSEQ-1K8 q,X) =FUNCT-1R1 (composeFUNCT-7K3(q,Y))*FUNCT-1K3 (composeFUNCT-7K3(p,X))"
sorry

mtheorem funct_7_th_49:
" for x be objectHIDDENM1 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for q be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds (applyFUNCT-7K4(p ^FINSEQ-1K8 q,x)).FUNCT-1K1 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 q) +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (applyFUNCT-7K4(q,(applyFUNCT-7K4(p,x)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem funct_7_th_50:
" for x be objectHIDDENM1 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds  for q be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds applyFUNCT-7K4(p ^FINSEQ-1K8 q,x) =FINSEQ-1R1 (applyFUNCT-7K4(p,x))$^REWRITE1K1 (applyFUNCT-7K4(q,(applyFUNCT-7K4(p,x)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)))"
sorry

mtheorem funct_7_th_51:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds composeFUNCT-7K3(<*FINSEQ-1K11 f,g *>,X) =FUNCT-1R1 (g *FUNCT-1K3 f)*FUNCT-1K3 idPARTFUN1K6 X"
sorry

mtheorem funct_7_th_52:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 X or domRELAT-1K1 (g *FUNCT-1K3 f) c=TARSKIR1 X implies composeFUNCT-7K3(<*FINSEQ-1K11 f,g *>,X) =FUNCT-1R1 g *FUNCT-1K3 f"
sorry

mtheorem funct_7_th_53:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds applyFUNCT-7K4(<*FINSEQ-1K11 f,g *>,x) =FINSEQ-1R1 <*FINSEQ-1K12 x,f .FUNCT-1K1 x,g .FUNCT-1K1 (f .FUNCT-1K1 x) *>"
sorry

mtheorem funct_7_th_54:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds composeFUNCT-7K3(<*FINSEQ-1K12 f,g,h *>,X) =FUNCT-1R1 ((h *FUNCT-1K3 g)*FUNCT-1K3 f)*FUNCT-1K3 idPARTFUN1K6 X"
sorry

mtheorem funct_7_th_55:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (domRELAT-1K1 f c=TARSKIR1 X or domRELAT-1K1 (g *FUNCT-1K3 f) c=TARSKIR1 X) or domRELAT-1K1 ((h *FUNCT-1K3 g)*FUNCT-1K3 f) c=TARSKIR1 X implies composeFUNCT-7K3(<*FINSEQ-1K12 f,g,h *>,X) =FUNCT-1R1 (h *FUNCT-1K3 g)*FUNCT-1K3 f"
sorry

mtheorem funct_7_th_56:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds applyFUNCT-7K4(<*FINSEQ-1K12 f,g,h *>,x) =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (<*FINSEQ-1K12 f .FUNCT-1K1 x,g .FUNCT-1K1 (f .FUNCT-1K1 x),h .FUNCT-1K1 (g .FUNCT-1K1 (f .FUNCT-1K1 x)) *>)"
sorry

mdef funct_7_def_6 ("firstdomFUNCT-7K5  _ " [164]164 ) where
  mlet "F be FinSequenceFINSEQ-1M1"
"func firstdomFUNCT-7K5 F \<rightarrow> setHIDDENM2 means
  \<lambda>it. it be emptyXBOOLE-0V1 if F be emptyXBOOLE-0V1 otherwise \<lambda>it. it =XBOOLE-0R4 proj1XTUPLE-0K12 (F .FUNCT-1K1 \<one>\<^sub>M)"
proof-
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
  (*existence*)
    show "(F be emptyXBOOLE-0V1 implies ( ex it be setHIDDENM2 st it be emptyXBOOLE-0V1)) & ( not F be emptyXBOOLE-0V1 implies ( ex it be setHIDDENM2 st it =XBOOLE-0R4 proj1XTUPLE-0K12 (F .FUNCT-1K1 \<one>\<^sub>M)))"
       sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (F be emptyXBOOLE-0V1 implies (it1 be emptyXBOOLE-0V1 & it2 be emptyXBOOLE-0V1 implies it1 =HIDDENR1 it2)) & ( not F be emptyXBOOLE-0V1 implies (it1 =XBOOLE-0R4 proj1XTUPLE-0K12 (F .FUNCT-1K1 \<one>\<^sub>M) & it2 =XBOOLE-0R4 proj1XTUPLE-0K12 (F .FUNCT-1K1 \<one>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
qed "sorry"

mdef funct_7_def_7 ("lastrngFUNCT-7K6  _ " [164]164 ) where
  mlet "F be FinSequenceFINSEQ-1M1"
"func lastrngFUNCT-7K6 F \<rightarrow> setHIDDENM2 means
  \<lambda>it. it be emptyXBOOLE-0V1 if F be emptyXBOOLE-0V1 otherwise \<lambda>it. it =XBOOLE-0R4 proj2XTUPLE-0K13 (F .FUNCT-1K1 lenFINSEQ-1K4 F)"
proof-
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
  (*existence*)
    show "(F be emptyXBOOLE-0V1 implies ( ex it be setHIDDENM2 st it be emptyXBOOLE-0V1)) & ( not F be emptyXBOOLE-0V1 implies ( ex it be setHIDDENM2 st it =XBOOLE-0R4 proj2XTUPLE-0K13 (F .FUNCT-1K1 lenFINSEQ-1K4 F)))"
       sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (F be emptyXBOOLE-0V1 implies (it1 be emptyXBOOLE-0V1 & it2 be emptyXBOOLE-0V1 implies it1 =HIDDENR1 it2)) & ( not F be emptyXBOOLE-0V1 implies (it1 =XBOOLE-0R4 proj2XTUPLE-0K13 (F .FUNCT-1K1 lenFINSEQ-1K4 F) & it2 =XBOOLE-0R4 proj2XTUPLE-0K13 (F .FUNCT-1K1 lenFINSEQ-1K4 F) implies it1 =HIDDENR1 it2))"
       sorry
qed "sorry"

mtheorem funct_7_th_57:
"firstdomFUNCT-7K5 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1 & lastrngFUNCT-7K6 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
  using funct_7_def_6 funct_7_def_7 sorry

mtheorem funct_7_th_58:
" for f be FunctionFUNCT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds firstdomFUNCT-7K5 ((<*FINSEQ-1K10 f*>)^FINSEQ-1K8 p) =XBOOLE-0R4 domRELAT-1K1 f & lastrngFUNCT-7K6 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 f*>)) =XBOOLE-0R4 rngFUNCT-1K2 f"
sorry

mtheorem funct_7_th_59:
" for X be setHIDDENM2 holds  for p be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (composeFUNCT-7K3(p,X)) c=TARSKIR1 lastrngFUNCT-7K6 p"
sorry

mdef funct_7_def_8 ("FuncSeq-likeFUNCT-7V1" 70 ) where
"attr FuncSeq-likeFUNCT-7V1 for FinSequenceFINSEQ-1M1 means
  (\<lambda>IT.  ex p be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 IT +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 IT implies IT .FUNCT-1K1 i inTARSKIR2 FuncsFUNCT-2K1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))))"..

mtheorem funct_7_th_60:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q be FuncSeq-likeFUNCT-7V1 implies p be FuncSeq-likeFUNCT-7V1 & q be FuncSeq-likeFUNCT-7V1"
sorry

mtheorem funct_7_cl_10:
"cluster FuncSeq-likeFUNCT-7V1 also-is Function-yieldingFUNCOP-1V1 for FinSequenceFINSEQ-1M1"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M1 holds it be FuncSeq-likeFUNCT-7V1 implies it be Function-yieldingFUNCOP-1V1"
sorry
qed "sorry"

mtheorem funct_7_cl_11:
"cluster emptyXBOOLE-0V1 also-is FuncSeq-likeFUNCT-7V1 for FinSequenceFINSEQ-1M1"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M1 holds it be emptyXBOOLE-0V1 implies it be FuncSeq-likeFUNCT-7V1"
sorry
qed "sorry"

mtheorem funct_7_cl_12:
  mlet "f be FunctionFUNCT-1M1"
"cluster <*FINSEQ-1K10 f*> as-term-is FuncSeq-likeFUNCT-7V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 f*> be FuncSeq-likeFUNCT-7V1"
sorry
qed "sorry"

mtheorem funct_7_cl_13:
"cluster FuncSeq-likeFUNCT-7V1\<bar> non emptyXBOOLE-0V1\<bar>non-emptyFUNCT-1V4 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be FuncSeq-likeFUNCT-7V1\<bar> non emptyXBOOLE-0V1\<bar>non-emptyFUNCT-1V4"
sorry
qed "sorry"

syntax FUNCT_7M1 :: "Ty" ("FuncSequenceFUNCT-7M1" 70)
translations "FuncSequenceFUNCT-7M1" \<rightharpoonup> "FuncSeq-likeFUNCT-7V1\<bar>FinSequenceFINSEQ-1M1"

mtheorem funct_7_th_61:
" for X be setHIDDENM2 holds  for p be FuncSequenceFUNCT-7M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 (composeFUNCT-7K3(p,X)) =XBOOLE-0R4 (firstdomFUNCT-7K5 p)/\\XBOOLE-0K3 X"
sorry

mtheorem funct_7_th_62:
" for p be FuncSequenceFUNCT-7M1 holds domRELAT-1K1 (composeFUNCT-7K3(p,firstdomFUNCT-7K5 p)) =XBOOLE-0R4 firstdomFUNCT-7K5 p"
sorry

mtheorem funct_7_th_63:
" for p be FuncSequenceFUNCT-7M1 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 firstdomFUNCT-7K5 p implies (<*FINSEQ-1K10 f*>)^FINSEQ-1K8 p be FuncSequenceFUNCT-7M1"
sorry

mtheorem funct_7_th_64:
" for p be FuncSequenceFUNCT-7M1 holds  for f be FunctionFUNCT-1M1 holds lastrngFUNCT-7K6 p c=TARSKIR1 domRELAT-1K1 f implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 f*>) be FuncSequenceFUNCT-7M1"
sorry

mtheorem funct_7_th_65:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for p be FuncSequenceFUNCT-7M1 holds x inHIDDENR3 firstdomFUNCT-7K5 p & x inHIDDENR3 X implies (applyFUNCT-7K4(p,x)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (composeFUNCT-7K3(p,X)).FUNCT-1K1 x"
sorry

mdef funct_7_def_9 ("FuncSequenceFUNCT-7M2-of'( _ , _ ')" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"assume Y be emptyXBOOLE-0V1 implies X be emptyXBOOLE-0V1 mode FuncSequenceFUNCT-7M2-of(X,Y) \<rightarrow> FuncSequenceFUNCT-7M1 means
  (\<lambda>it. firstdomFUNCT-7K5 it =XBOOLE-0R4 X & lastrngFUNCT-7K6 it c=TARSKIR1 Y)"
proof-
  (*existence*)
    show "(Y be emptyXBOOLE-0V1 implies X be emptyXBOOLE-0V1) implies ( ex it be FuncSequenceFUNCT-7M1 st firstdomFUNCT-7K5 it =XBOOLE-0R4 X & lastrngFUNCT-7K6 it c=TARSKIR1 Y)"
sorry
qed "sorry"

syntax FUNCT_7K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("composeFUNCT-7K7\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164)
translations "composeFUNCT-7K7\<^bsub>(Y)\<^esub>(F,X)" \<rightharpoonup> "composeFUNCT-7K3(F,X)"

mtheorem funct_7_add_2:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be setHIDDENM2", "F be FuncSequenceFUNCT-7M2-of(X,Y)"
"cluster composeFUNCT-7K3(F,X) as-term-is FunctionFUNCT-2M1-of(X,Y)"
proof
(*coherence*)
  show "composeFUNCT-7K3(F,X) be FunctionFUNCT-2M1-of(X,Y)"
sorry
qed "sorry"

mdef funct_7_def_10 ("FuncSequenceFUNCT-7M3-of  _ " [70]70 ) where
  mlet "q be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"mode FuncSequenceFUNCT-7M3-of q \<rightarrow> FinSequenceFINSEQ-1M1 means
  (\<lambda>it. lenFINSEQ-1K4 it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i inTARSKIR2 FuncsFUNCT-2K1(q .FUNCT-1K1 i,q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i inTARSKIR2 FuncsFUNCT-2K1(q .FUNCT-1K1 i,q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)))"
sorry
qed "sorry"

mtheorem funct_7_cl_14:
  mlet "q be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster note-that FuncSeq-likeFUNCT-7V1\<bar>non-emptyFUNCT-1V4 for FuncSequenceFUNCT-7M3-of q"
proof
(*coherence*)
  show " for it be FuncSequenceFUNCT-7M3-of q holds it be FuncSeq-likeFUNCT-7V1\<bar>non-emptyFUNCT-1V4"
sorry
qed "sorry"

mtheorem funct_7_th_66:
" for q be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds  for p be FuncSequenceFUNCT-7M3-of q holds p <>HIDDENR2 {}XBOOLE-0K1 implies firstdomFUNCT-7K5 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M & lastrngFUNCT-7K6 p c=TARSKIR1 q .FUNCT-1K1 lenFINSEQ-1K4 q"
sorry

mtheorem funct_7_th_67:
" for q be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds  for p be FuncSequenceFUNCT-7M3-of q holds domRELAT-1K1 (composeFUNCT-7K3(p,q .FUNCT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M & rngFUNCT-1K2 (composeFUNCT-7K3(p,q .FUNCT-1K1 \<one>\<^sub>M)) c=TARSKIR1 q .FUNCT-1K1 lenFINSEQ-1K4 q"
sorry

mtheorem funct_7_cl_15:
  mlet "X be setHIDDENM2", "f be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 X,X :])", "n be NatNAT-1M1"
"cluster f .FUNCT-1K1 n as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 n be Relation-likeRELAT-1V1"
sorry
qed "sorry"

mlemma funct_7_lm_1:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds rngRELSET-1K2\<^bsub>(X)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
sorry

mlemma funct_7_lm_2:
" for f be RelationRELAT-1M1 holds  for n be NatNAT-1M1 holds  for p1 be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]) holds  for p2 be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]) holds ((p1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(fieldRELAT-1K3 f,fieldRELAT-1K3 f)\<^esub> idPARTFUN1K6 (fieldRELAT-1K3 f) & ( for k be NatNAT-1M1 holds p1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 f *RELAT-1K6 p1 .FUNCT-1K1 k)) & p2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(fieldRELAT-1K3 f,fieldRELAT-1K3 f)\<^esub> idPARTFUN1K6 (fieldRELAT-1K3 f)) & ( for k be NatNAT-1M1 holds p2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 f *RELAT-1K6 p2 .FUNCT-1K1 k) implies p1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> p2"
sorry

mdef funct_7_def_11 ("iterFUNCT-7K8'( _ , _ ')" [0,0]164 ) where
  mlet "f be RelationRELAT-1M1", "n be NatNAT-1M1"
"func iterFUNCT-7K8(f,n) \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it.  ex p be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]) st (it =RELAT-1R1 p .FUNCT-1K1 n & p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(fieldRELAT-1K3 f,fieldRELAT-1K3 f)\<^esub> idPARTFUN1K6 (fieldRELAT-1K3 f)) & ( for k be NatNAT-1M1 holds p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 f *RELAT-1K6 p .FUNCT-1K1 k)"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st  ex p be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]) st (it =RELAT-1R1 p .FUNCT-1K1 n & p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(fieldRELAT-1K3 f,fieldRELAT-1K3 f)\<^esub> idPARTFUN1K6 (fieldRELAT-1K3 f)) & ( for k be NatNAT-1M1 holds p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 f *RELAT-1K6 p .FUNCT-1K1 k)"
sorry
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds ( ex p be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]) st (it1 =RELAT-1R1 p .FUNCT-1K1 n & p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(fieldRELAT-1K3 f,fieldRELAT-1K3 f)\<^esub> idPARTFUN1K6 (fieldRELAT-1K3 f)) & ( for k be NatNAT-1M1 holds p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 f *RELAT-1K6 p .FUNCT-1K1 k)) & ( ex p be sequenceNAT-1M2-of boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]) st (it2 =RELAT-1R1 p .FUNCT-1K1 n & p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(fieldRELAT-1K3 f,fieldRELAT-1K3 f)\<^esub> idPARTFUN1K6 (fieldRELAT-1K3 f)) & ( for k be NatNAT-1M1 holds p .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,boolSETFAM-1K9 ([:ZFMISC-1K2 fieldRELAT-1K3 f,fieldRELAT-1K3 f :]))\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 f *RELAT-1K6 p .FUNCT-1K1 k)) implies it1 =HIDDENR1 it2"
      using funct_7_lm_2 sorry
qed "sorry"

mtheorem funct_7_cl_16:
  mlet "f be FunctionFUNCT-1M1", "n be NatNAT-1M1"
"cluster iterFUNCT-7K8(f,n) as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "iterFUNCT-7K8(f,n) be Function-likeFUNCT-1V1"
sorry
qed "sorry"

reserve m, n, k for "NatNAT-1M1"
reserve R for "RelationRELAT-1M1"
mlemma funct_7_lm_3:
" for R be RelationRELAT-1M1 holds idPARTFUN1K6 (fieldRELAT-1K3 R) *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 idPARTFUN1K6 (fieldRELAT-1K3 R) =RELAT-1R1 R"
  using relat_1_th_51 relat_1_th_53 xboole_1_th_7 sorry

mtheorem funct_7_th_68:
" for R be RelationRELAT-1M1 holds iterFUNCT-7K8(R,0NUMBERSK6) =RELAT-1R1 idPARTFUN1K6 (fieldRELAT-1K3 R)"
sorry

mlemma funct_7_lm_4:
" for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 R implies iterFUNCT-7K8(R,0NUMBERSK6) =RELAT-1R1 idPARTFUN1K6 (domRELAT-1K1 R)"
sorry

mtheorem funct_7_th_69:
" for R be RelationRELAT-1M1 holds  for n be NatNAT-1M1 holds iterFUNCT-7K8(R,n +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 R *RELAT-1K6 (iterFUNCT-7K8(R,n))"
sorry

mtheorem funct_7_th_70:
" for R be RelationRELAT-1M1 holds iterFUNCT-7K8(R,\<one>\<^sub>M) =RELAT-1R1 R"
sorry

mtheorem funct_7_th_71:
" for R be RelationRELAT-1M1 holds  for n be NatNAT-1M1 holds iterFUNCT-7K8(R,n +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 (iterFUNCT-7K8(R,n))*RELAT-1K6 R"
sorry

mtheorem funct_7_th_72:
" for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (iterFUNCT-7K8(R,n)) c=TARSKIR1 fieldRELAT-1K3 R & rngRELAT-1K2 (iterFUNCT-7K8(R,n)) c=TARSKIR1 fieldRELAT-1K3 R"
sorry

mtheorem funct_7_th_73:
" for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies domRELAT-1K1 (iterFUNCT-7K8(R,n)) c=TARSKIR1 domRELAT-1K1 R & rngRELAT-1K2 (iterFUNCT-7K8(R,n)) c=TARSKIR1 rngRELAT-1K2 R"
sorry

mtheorem funct_7_th_74:
" for R be RelationRELAT-1M1 holds  for n be NatNAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 R implies domRELAT-1K1 (iterFUNCT-7K8(R,n)) =XBOOLE-0R4 domRELAT-1K1 R & rngRELAT-1K2 (iterFUNCT-7K8(R,n)) c=TARSKIR1 domRELAT-1K1 R"
sorry

mtheorem funct_7_th_75:
" for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds idPARTFUN1K6 (fieldRELAT-1K3 R) *RELAT-1K6 (iterFUNCT-7K8(R,n)) =RELAT-1R1 iterFUNCT-7K8(R,n)"
sorry

mtheorem funct_7_th_76:
" for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds (iterFUNCT-7K8(R,n))*RELAT-1K6 idPARTFUN1K6 (fieldRELAT-1K3 R) =RELAT-1R1 iterFUNCT-7K8(R,n)"
sorry

mtheorem funct_7_th_77:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds (iterFUNCT-7K8(R,m))*RELAT-1K6 (iterFUNCT-7K8(R,n)) =RELAT-1R1 iterFUNCT-7K8(R,n +XCMPLX-0K2 m)"
sorry

mlemma funct_7_lm_5:
" for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds iterFUNCT-7K8(iterFUNCT-7K8(R,m),k) =RELAT-1R1 iterFUNCT-7K8(R,m *XCMPLX-0K3 k) implies iterFUNCT-7K8(iterFUNCT-7K8(R,m),k +NAT-1K1 \<one>\<^sub>M) =RELAT-1R1 iterFUNCT-7K8(R,m *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem funct_7_th_78:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies iterFUNCT-7K8(iterFUNCT-7K8(R,m),n) =RELAT-1R1 iterFUNCT-7K8(R,m *XCMPLX-0K3 n)"
sorry

mtheorem funct_7_th_79:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for R be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 R implies iterFUNCT-7K8(iterFUNCT-7K8(R,m),n) =RELAT-1R1 iterFUNCT-7K8(R,m *XCMPLX-0K3 n)"
sorry

mtheorem funct_7_th_80:
" for n be NatNAT-1M1 holds iterFUNCT-7K8({}XBOOLE-0K1,n) =FUNCT-1R1 {}XBOOLE-0K1"
sorry

mtheorem funct_7_th_81:
" for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds iterFUNCT-7K8(idPARTFUN1K6 X,n) =FUNCT-1R1 idPARTFUN1K6 X"
sorry

mtheorem funct_7_th_82:
" for R be RelationRELAT-1M1 holds rngRELAT-1K2 R missesXBOOLE-0R1 domRELAT-1K1 R implies iterFUNCT-7K8(R,\<two>\<^sub>M) =RELAT-1R1 {}XBOOLE-0K1"
sorry

mtheorem funct_7_th_83:
" for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f be FunctionFUNCT-2M1-of(X,X) holds iterFUNCT-7K8(f,n) be FunctionFUNCT-2M1-of(X,X)"
sorry

mtheorem funct_7_th_84:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds iterFUNCT-7K8(f,0NUMBERSK6) =FUNCT-1R1 idPARTFUN1K6 X"
sorry

mtheorem funct_7_th_85:
" for X be setHIDDENM2 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for f be FunctionFUNCT-2M1-of(X,X) holds iterFUNCT-7K8(iterFUNCT-7K8(f,m),n) =FUNCT-1R1 iterFUNCT-7K8(f,m *XCMPLX-0K3 n)"
sorry

mtheorem funct_7_th_86:
" for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(X,X) holds iterFUNCT-7K8(f,n) be PartFuncPARTFUN1M1-of(X,X)"
sorry

mtheorem funct_7_th_87:
" for a be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for n be NatNAT-1M1 holds (n <>HIDDENR2 0NUMBERSK6 & a inHIDDENR3 X) & f =FUNCT-1R1 X -->FUNCOP-1K7 a implies iterFUNCT-7K8(f,n) =FUNCT-1R1 f"
sorry

mtheorem funct_7_th_88:
" for f be FunctionFUNCT-1M1 holds  for n be NatNAT-1M1 holds iterFUNCT-7K8(f,n) =FUNCT-1R1 composeFUNCT-7K3(n  |->FINSEQ-2K2 f,fieldRELAT-1K3 f)"
sorry

(*begin*)
mtheorem funct_7_th_89:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds g c=RELAT-1R2 f &  not x inTARSKIR2 domRELAT-1K1 g implies g c=RELAT-1R2 f +*FUNCT-7K1(x,y)"
sorry

mtheorem funct_7_th_90:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A & (f,g)equal-outsideFUNCT-7R1 A implies f =FUNCT-1R1 g"
sorry

mtheorem funct_7_th_91:
" for f be FunctionFUNCT-1M1 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for A be setHIDDENM2 holds a inTARSKIR2 A implies (f,f +*FUNCT-7K1(a,b))equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_92:
" for f be FunctionFUNCT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for A be setHIDDENM2 holds a inHIDDENR3 A or (f +*FUNCT-7K1(a,b)) |RELAT-1K8 A =FUNCT-1R1 f  |RELAT-1K8 A"
sorry

mtheorem funct_7_th_93:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for A be setHIDDENM2 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (f +*FUNCT-7K1(a,b)) |RELAT-1K8 A =FUNCT-1R1 (g +*FUNCT-7K1(a,b)) |RELAT-1K8 A"
sorry

mtheorem funct_7_th_94:
" for f be FunctionFUNCT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (f +*FUNCT-4K1 (a .-->FUNCOP-1K17 b)).FUNCT-1K1 a =HIDDENR1 b"
sorry

mtheorem funct_7_th_95:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds (<*FINSEQ-1K10 a*>)+*FUNCT-7K1(\<one>\<^sub>M,b) =FINSEQ-1R1 <*FINSEQ-1K10 b*>"
sorry

mtheorem funct_7_th_96:
" for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f +*FUNCT-4K1 (x .-->FUNCOP-1K17 f .FUNCT-1K1 x) =FUNCT-1R1 f"
sorry

reserve i, j for "NatNAT-1M1"
mtheorem funct_7_th_97:
" for w be FinSequenceFINSEQ-1M1 holds  for r be objectHIDDENM1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds lenFINSEQ-1K4 (w +*FUNCT-7K1(i,r)) =XBOOLE-0R4 lenFINSEQ-1K4 w"
sorry

mtheorem funct_7_th_98:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for w be FinSequenceFINSEQ-1M3-of D holds  for r be ElementSUBSET-1M1-of D holds i inTARSKIR2 domFINSEQ-1K5 w implies w +*FUNCT-7K2\<^bsub>(D)\<^esub>(i,r) =FINSEQ-1R1 (w  |FINSEQ-1K18\<^bsub>(D)\<^esub> (i -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> r*>))^FINSEQ-1K9\<^bsub>(D)\<^esub> (w /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
sorry

reserve F for "FunctionFUNCT-1M1"
reserve e, x, y, z for "objectHIDDENM1"
mdef funct_7_def_12 ("SwapFUNCT-7K9'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "F be FunctionFUNCT-1M1", "x be objectHIDDENM1", "y be objectHIDDENM1"
"func SwapFUNCT-7K9(F,x,y) \<rightarrow> setHIDDENM2 equals
  (F +*FUNCT-7K1(x,F .FUNCT-1K1 y))+*FUNCT-7K1(y,F .FUNCT-1K1 x) if x inHIDDENR3 domRELAT-1K1 F & y inHIDDENR3 domRELAT-1K1 F otherwise F"
proof-
  (*coherence*)
    show "(x inHIDDENR3 domRELAT-1K1 F & y inHIDDENR3 domRELAT-1K1 F implies (F +*FUNCT-7K1(x,F .FUNCT-1K1 y))+*FUNCT-7K1(y,F .FUNCT-1K1 x) be setHIDDENM2) & ( not (x inHIDDENR3 domRELAT-1K1 F & y inHIDDENR3 domRELAT-1K1 F) implies F be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem funct_7_cl_17:
  mlet "F be FunctionFUNCT-1M1", "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster SwapFUNCT-7K9(F,x,y) as-term-is Relation-likeRELAT-1V1\<bar>Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "SwapFUNCT-7K9(F,x,y) be Relation-likeRELAT-1V1\<bar>Function-likeFUNCT-1V1"
sorry
qed "sorry"

mtheorem funct_7_th_99:
" for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds domRELAT-1K1 (SwapFUNCT-7K9(F,x,y)) =XBOOLE-0R4 domRELAT-1K1 F"
sorry

mtheorem funct_7_th_100:
" for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds rngFUNCT-1K2 (F +*FUNCT-7K1(x,y)) c=TARSKIR1 rngFUNCT-1K2 F \\/XBOOLE-0K2 {TARSKIK1 y}"
sorry

mtheorem funct_7_th_101:
" for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds rngFUNCT-1K2 F c=TARSKIR1 rngFUNCT-1K2 (F +*FUNCT-7K1(x,y)) \\/XBOOLE-0K2 {TARSKIK1 F .FUNCT-1K1 x }"
sorry

mtheorem funct_7_th_102:
" for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies y inHIDDENR3 rngFUNCT-1K2 (F +*FUNCT-7K1(x,y))"
sorry

mtheorem funct_7_th_103:
" for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds rngFUNCT-1K2 (SwapFUNCT-7K9(F,x,y)) =XBOOLE-0R4 rngFUNCT-1K2 F"
sorry

theorem funct_7_sch_6:
  fixes Af0 Df0 Gf1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: "Af0 c=TARSKIR1 Df0" and
   A2: " for d1 be ElementSUBSET-1M1-of Df0 holds  for d2 be ElementSUBSET-1M1-of Df0 holds (d1 inTARSKIR2 Af0 & d2 inTARSKIR2 Af0) & Gf1(d1) =HIDDENR1 Gf1(d2) implies d1 =XBOOLE-0R4 d2"
  shows "(Af0,{Gf1(d) where d be ElementSUBSET-1M1-of Df0 : d inTARSKIR2 Af0 })are-equipotentWELLORD2R2"
sorry

mtheorem funct_7_th_104:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f,g)equal-outsideFUNCT-7R1 A implies (f +*FUNCT-4K1 h,g +*FUNCT-4K1 h)equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_105:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f,g)equal-outsideFUNCT-7R1 A implies (h +*FUNCT-4K1 f,h +*FUNCT-4K1 g)equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_106:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f +*FUNCT-4K1 h =FUNCT-1R1 g +*FUNCT-4K1 h iff (f,g)equal-outsideFUNCT-7R1 domRELAT-1K1 h"
sorry

mtheorem funct_7_th_107:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for a be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies f .FUNCT-1K1 a =XBOOLE-0R4 (f *FUNCT-1K3 (idPARTFUN1K6 (domRELAT-1K1 f) +*FUNCT-7K1(x,y))).FUNCT-1K1 a"
sorry

mtheorem funct_7_th_108:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (x inTARSKIR2 domRELAT-1K1 f implies y inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y) implies f =FUNCT-1R1 f *FUNCT-1K3 (idPARTFUN1K6 (domRELAT-1K1 f) +*FUNCT-7K1(x,y))"
sorry

(*\$CT*)
mtheorem funct_7_th_110:
" for X be setHIDDENM2 holds  for p be PermutationFUNCT-2M2-of X holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds (p +*FUNCT-7K1(x,p .FUNCT-1K1 y))+*FUNCT-7K1(y,p .FUNCT-1K1 x) be PermutationFUNCT-2M2-of X"
sorry

mtheorem funct_7_th_111:
" for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f & y inTARSKIR2 domRELAT-1K1 f implies ( ex p be PermutationFUNCT-2M2-of domRELAT-1K1 f st (f +*FUNCT-7K1(x,f .FUNCT-1K1 y))+*FUNCT-7K1(y,f .FUNCT-1K1 x) =FUNCT-1R1 f *FUNCT-1K3 p)"
sorry

mtheorem funct_7_th_112:
" for f be FunctionFUNCT-1M1 holds  for d be setHIDDENM2 holds  for r be setHIDDENM2 holds d inTARSKIR2 domRELAT-1K1 f implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (f +*FUNCT-4K1 (d .-->FUNCOP-1K17 r))"
sorry

mtheorem funct_7_th_113:
" for f be FinSequenceFINSEQ-1M3-of INTNUMBERSK5 holds  for g be FinSequenceFINSEQ-1M3-of INTNUMBERSK5 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 f) & g =FINSEQ-1R1 (f +*FUNCT-7K2\<^bsub>(INTNUMBERSK5)\<^esub>(m,f /.PARTFUN1K7\<^bsub>(INTNUMBERSK5)\<^esub> n))+*FUNCT-7K2\<^bsub>(INTNUMBERSK5)\<^esub>(n,f /.PARTFUN1K7\<^bsub>(INTNUMBERSK5)\<^esub> m) implies ((f .FUNCT-1K1 m =XBOOLE-0R4 g .FUNCT-1K1 n & f .FUNCT-1K1 n =XBOOLE-0R4 g .FUNCT-1K1 m) & ( for k be setHIDDENM2 holds (k <>HIDDENR2 m & k <>HIDDENR2 n) & k inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 k =XBOOLE-0R4 g .FUNCT-1K1 k)) & (f,g)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem funct_7_th_114:
" for f be FunctionFUNCT-1M1 holds  for a be setHIDDENM2 holds  for A be setHIDDENM2 holds  for b be setHIDDENM2 holds  for B be setHIDDENM2 holds  for c be setHIDDENM2 holds  for C be setHIDDENM2 holds a <>HIDDENR2 b & a <>HIDDENR2 c implies (((f +*FUNCT-4K1 (a .-->FUNCOP-1K17 A))+*FUNCT-4K1 (b .-->FUNCOP-1K17 B))+*FUNCT-4K1 (c .-->FUNCOP-1K17 C)).FUNCT-1K1 a =XBOOLE-0R4 A"
sorry

mtheorem funct_7_th_115:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds b inTARSKIR2 B implies f +*FUNCT-7K1(a,b) be FunctionFUNCT-2M1-of(A,B)"
sorry

mtheorem funct_7_th_116:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds rngFUNCT-1K2 f c=TARSKIR1 A implies f +~FUNCT-4K8(x,y) =FUNCT-1R1 (idPARTFUN1K6 A +*FUNCT-7K1(x,y))*FUNCT-1K3 f"
sorry

mtheorem funct_7_th_117:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (f +*FUNCT-4K1 g)+~FUNCT-4K8(x,y) =FUNCT-1R1 (f +~FUNCT-4K8(x,y))+*FUNCT-4K1 (g +~FUNCT-4K8(x,y))"
sorry

mdef funct_7_def_13 (" _ followed-byFUNCT-7K10  _ " [164,164]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func a followed-byFUNCT-7K10 b \<rightarrow> setHIDDENM2 equals
  (NATNUMBERSK1 -->FUNCOP-1K7 b)+*FUNCT-7K1(0NUMBERSK6,a)"
proof-
  (*coherence*)
    show "(NATNUMBERSK1 -->FUNCOP-1K7 b)+*FUNCT-7K1(0NUMBERSK6,a) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funct_7_cl_18:
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"cluster a followed-byFUNCT-7K10 b as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "a followed-byFUNCT-7K10 b be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

reserve a, b, c for "setHIDDENM2"
mtheorem funct_7_th_118:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds domRELAT-1K1 (a followed-byFUNCT-7K10 b) =XBOOLE-0R4 NATNUMBERSK1"
sorry

syntax FUNCT_7K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ followed-byFUNCT-7K11\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "a followed-byFUNCT-7K11\<^bsub>(X)\<^esub> b" \<rightharpoonup> "a followed-byFUNCT-7K10 b"

mtheorem funct_7_add_3:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "a be ElementSUBSET-1M1-of X", "b be ElementSUBSET-1M1-of X"
"cluster a followed-byFUNCT-7K10 b as-term-is sequenceNAT-1M2-of X"
proof
(*coherence*)
  show "a followed-byFUNCT-7K10 b be sequenceNAT-1M2-of X"
sorry
qed "sorry"

mtheorem funct_7_th_119:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds (a followed-byFUNCT-7K10 b).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 a"
sorry

mtheorem funct_7_th_120:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (a followed-byFUNCT-7K10 b).FUNCT-1K1 n =XBOOLE-0R4 b"
sorry

mdef funct_7_def_14 ("'( _ , _ ')followed-byFUNCT-7K12  _ " [0,0,164]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func (a,b)followed-byFUNCT-7K12 c \<rightarrow> setHIDDENM2 equals
  (NATNUMBERSK1 -->FUNCOP-1K7 c)+*FUNCT-4K1 ((0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(a,b))"
proof-
  (*coherence*)
    show "(NATNUMBERSK1 -->FUNCOP-1K7 c)+*FUNCT-4K1 ((0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(a,b)) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funct_7_cl_19:
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster (a,b)followed-byFUNCT-7K12 c as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "(a,b)followed-byFUNCT-7K12 c be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem funct_7_th_121:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds domRELAT-1K1 ((a,b)followed-byFUNCT-7K12 c) =XBOOLE-0R4 NATNUMBERSK1"
sorry

mtheorem funct_7_th_122:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds ((a,b)followed-byFUNCT-7K12 c).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 a"
sorry

mtheorem funct_7_th_123:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds ((a,b)followed-byFUNCT-7K12 c).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 b"
sorry

mtheorem funct_7_th_124:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies ((a,b)followed-byFUNCT-7K12 c).FUNCT-1K1 n =XBOOLE-0R4 c"
sorry

mtheorem funct_7_th_125:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds (a,b)followed-byFUNCT-7K12 c =FUNCT-1R1 (a followed-byFUNCT-7K10 c)+*FUNCT-7K1(\<one>\<^sub>M,b)"
sorry

syntax FUNCT_7K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("'( _ , _ ')followed-byFUNCT-7K13\<^bsub>'( _ ')\<^esub>  _ " [0,0,0,164]164)
translations "(a,b)followed-byFUNCT-7K13\<^bsub>(X)\<^esub> c" \<rightharpoonup> "(a,b)followed-byFUNCT-7K12 c"

mtheorem funct_7_add_4:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "a be ElementSUBSET-1M1-of X", "b be ElementSUBSET-1M1-of X", "c be ElementSUBSET-1M1-of X"
"cluster (a,b)followed-byFUNCT-7K12 c as-term-is sequenceNAT-1M2-of X"
proof
(*coherence*)
  show "(a,b)followed-byFUNCT-7K12 c be sequenceNAT-1M2-of X"
sorry
qed "sorry"

mtheorem funct_7_th_126:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds rngFUNCT-1K2 (a followed-byFUNCT-7K10 b) =XBOOLE-0R4 {TARSKIK2 a,b }"
sorry

mtheorem funct_7_th_127:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds rngFUNCT-1K2 ((a,b)followed-byFUNCT-7K12 c) =XBOOLE-0R4 {ENUMSET1K1 a,b,c }"
sorry

syntax FUNCT_7K14 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +*FUNCT-7K14\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [164,0,0,0,0]164)
translations "f +*FUNCT-7K14\<^bsub>(A,B)\<^esub>(x,y)" \<rightharpoonup> "f +*FUNCT-7K1(x,y)"

mtheorem funct_7_add_5:
  mlet "A be setHIDDENM2", "B be setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,B)", "x be setHIDDENM2", "y be ElementSUBSET-1M1-of B"
"cluster f +*FUNCT-7K1(x,y) as-term-is FunctionFUNCT-2M1-of(A,B)"
proof
(*coherence*)
  show "f +*FUNCT-7K1(x,y) be FunctionFUNCT-2M1-of(A,B)"
sorry
qed "sorry"

mtheorem funct_7_th_128:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds  for x be ElementSUBSET-1M1-of A holds  for y be setHIDDENM2 holds (f +*FUNCT-7K1(x,y)).FUNCT-1K1 x =XBOOLE-0R4 y"
sorry

mtheorem funct_7_th_129:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds  for g be FunctionFUNCT-2M1-of(A,B) holds  for x be ElementSUBSET-1M1-of A holds ( for y be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,B)\<^esub> y <>HIDDENR2 g .FUNCT-2K3\<^bsub>(A,B)\<^esub> y implies y =XBOOLE-0R4 x) implies f =FUNCT-2R2\<^bsub>(A,B)\<^esub> g +*FUNCT-7K14\<^bsub>(A,B)\<^esub>(x,f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x)"
sorry

mtheorem funct_7_th_130:
" for A be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds (f,f +*FUNCT-4K1 g)equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_131:
" for A be setHIDDENM2 holds  for f be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for g be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds (f,g)equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_132:
" for A be setHIDDENM2 holds  for f be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for g be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (h +*FUNCT-4K1 f,h +*FUNCT-4K1 g)equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_133:
" for m be NatNAT-1M1 holds  for I be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds cardCARD-1K1 (ShiftVALUED-1K64(I,m)) =XBOOLE-0R4 cardCARD-1K1 I"
sorry

mtheorem funct_7_th_134:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & domRELAT-1K1 f c=TARSKIR1 A \\/XBOOLE-0K2 B) & f  |RELAT-1K8 B =FUNCT-1R1 g  |RELAT-1K8 B implies (f,g)equal-outsideFUNCT-7R1 A"
  using relat_1_th_153 xboole_1_th_43 sorry

mtheorem funct_7_th_135:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ((domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & B c=TARSKIR1 domRELAT-1K1 f) & A missesXBOOLE-0R1 B) & (f,g)equal-outsideFUNCT-7R1 A implies f  |RELAT-1K8 B =FUNCT-1R1 g  |RELAT-1K8 B"
  using relat_1_th_153 xboole_1_th_86 sorry

reserve A, B, I for "setHIDDENM2"
reserve X, Y for "ManySortedSetPBOOLEM1-of I"
mtheorem funct_7_th_136:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds I c=TARSKIR1 A \\/XBOOLE-0K2 B & X  |RELAT-1K8 B =FUNCT-1R1 Y  |RELAT-1K8 B implies (X,Y)equal-outsideFUNCT-7R1 A"
sorry

mtheorem funct_7_th_137:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (B c=TARSKIR1 I & A missesXBOOLE-0R1 B) & (X,Y)equal-outsideFUNCT-7R1 A implies X  |RELAT-1K8 B =FUNCT-1R1 Y  |RELAT-1K8 B"
sorry

mtheorem funct_7_cl_20:
  mlet "V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be V -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1", "y be ElementSUBSET-1M1-of V"
"cluster f +*FUNCT-7K1(x,y) as-term-is V -valuedRELAT-1V5"
proof
(*coherence*)
  show "f +*FUNCT-7K1(x,y) be V -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem funct_7_th_138:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds f c=RELAT-1R2 g &  not x inHIDDENR3 domRELAT-1K1 f implies f c=RELAT-1R2 g +*FUNCT-7K1(x,y)"
sorry

mtheorem funct_7_th_139:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for l1 be ElementSUBSET-1M1-of I holds  for l2 be ElementSUBSET-1M1-of I holds  for i1 be setHIDDENM2 holds  for i2 be setHIDDENM2 holds X +*FUNCT-4K1 ((l1,l2)-->FUNCT-4K6(i1,i2)) =FUNCT-1R1 (X +*FUNCT-7K1(l1,i1))+*FUNCT-7K1(l2,i2)"
sorry

theorem funct_7_sch_7:
  fixes Af0 af0 bf0 ff0 xf0 Ff1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "af0 be ElementSUBSET-1M1-of Af0" and
  [ty]: "bf0 be ElementSUBSET-1M1-of Af0" and
  [ty]: "ff0 be Af0 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1" and
  [ty]: "xf0 be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: "Ff1(bf0) =HIDDENR1 Ff1(af0)" and
   A2: "bf0 =XBOOLE-0R4 ff0 .FUNCT-1K1 xf0"
  shows "{Ff1(i) where i be ElementSUBSET-1M1-of Af0 : i inTARSKIR2 rngRELSET-1K2\<^bsub>(Af0)\<^esub> ff0 } =XBOOLE-0R4 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 rngRELSET-1K2\<^bsub>(Af0)\<^esub> (ff0 +*FUNCT-7K1(xf0,af0)) }"
sorry

end
