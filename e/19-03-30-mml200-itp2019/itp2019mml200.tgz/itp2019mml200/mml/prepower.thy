theory prepower
  imports newton rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem prepower_cl_1:
  mlet "i be IntegerINT-1M1"
"cluster  |.INT-2K1 i.| as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show " |.INT-2K1 i.| be naturalORDINAL1V7"
     sorry
qed "sorry"

reserve a, b, c for "RealXREAL-0M1"
reserve m, n, m1, m2 for "NatNAT-1M1"
reserve k, l for "IntegerINT-1M1"
reserve p, q for "RationalRAT-1M1"
reserve s1, s2 for "Real-SequenceSEQ-1M1"
mtheorem prepower_th_1:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 a) implies limSEQ-2K1 s1 >=XXREAL-0R2 a"
sorry

mtheorem prepower_th_2:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 a) implies limSEQ-2K1 s1 <=XXREAL-0R1 a"
sorry

mdef prepower_def_1 (" _ GeoSeqPREPOWERK1" [220]220 ) where
  mlet "a be RealXREAL-0M1"
"func a GeoSeqPREPOWERK1 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for m be NatNAT-1M1 holds it .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for m be NatNAT-1M1 holds it .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for m be NatNAT-1M1 holds it1 .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m) & ( for m be NatNAT-1M1 holds it2 .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem prepower_th_3:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 =FUNCT-1R1 a GeoSeqPREPOWERK1 iff s1 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for m be NatNAT-1M1 holds s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a)"
sorry

mtheorem prepower_th_4:
" for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ( for m be NatNAT-1M1 holds a GeoSeqPREPOWERK1 .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6)"
sorry

mtheorem prepower_th_5:
" for a be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <>HIDDENR2 a implies 0NUMBERSK6 <>HIDDENR2 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_6:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_7:
" for a be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_8:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (b /XCMPLX-0K7 a) |^NEWTONK1 n =COMPLEX1R1 b  |^NEWTONK1 n /XCMPLX-0K7 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies a  |^NEWTONK1 n <=XXREAL-0R1 b  |^NEWTONK1 n"
sorry

mlemma prepower_lm_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b) & \<one>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
sorry

mtheorem prepower_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 b) & \<one>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
sorry

mtheorem prepower_th_11:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M implies a  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem prepower_th_12:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M <=XXREAL-0R1 a & \<one>\<^sub>M <=XXREAL-0R1 n implies a <=XXREAL-0R1 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_13:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 a & \<two>\<^sub>M <=XXREAL-0R1 n implies a <XXREAL-0R3 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_14:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 \<one>\<^sub>M) & \<one>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <=XXREAL-0R1 a"
sorry

mtheorem prepower_th_15:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M) & \<two>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <XXREAL-0R3 a"
sorry

mtheorem prepower_th_16:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a"
sorry

mtheorem prepower_th_17:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
sorry

mtheorem prepower_th_18:
" for m be NatNAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 m) implies s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m"
sorry

mdef prepower_def_2 (" _ -RootPREPOWERK2  _ " [220,220]220 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "a be RealXREAL-0M1"
"assume \<one>\<^sub>M <=XXREAL-0R1 n func n -RootPREPOWERK2 a \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6 if a >XXREAL-0R4 0NUMBERSK6,
  \<lambda>it. it =COMPLEX1R1 0NUMBERSK6 if a =COMPLEX1R1 0NUMBERSK6"
proof-
  (*consistency*)
    show "\<one>\<^sub>M <=XXREAL-0R1 n implies ( for it be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a =COMPLEX1R1 0NUMBERSK6 implies (it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6 iff it =COMPLEX1R1 0NUMBERSK6))"
sorry
  (*existence*)
    show "\<one>\<^sub>M <=XXREAL-0R1 n implies (a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6)) & (a =COMPLEX1R1 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6))"
sorry
  (*uniqueness*)
    show "\<one>\<^sub>M <=XXREAL-0R1 n implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 implies ((it1  |^NEWTONK1 n =COMPLEX1R1 a & it1 >XXREAL-0R4 0NUMBERSK6) & (it2  |^NEWTONK1 n =COMPLEX1R1 a & it2 >XXREAL-0R4 0NUMBERSK6) implies it1 =HIDDENR1 it2)) & (a =COMPLEX1R1 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2)))"
sorry
qed "sorry"

mtheorem prepower_cl_2:
  mlet "n be NatNAT-1M1", "a be RealXREAL-0M1"
"cluster n -RootPREPOWERK2 a as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "n -RootPREPOWERK2 a be realXREAL-0V1"
     sorry
qed "sorry"

mlemma prepower_lm_2:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
sorry

mtheorem prepower_th_19:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
sorry

mtheorem prepower_th_20:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_21:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies \<one>\<^sub>M -RootPREPOWERK2 a =COMPLEX1R1 a"
sorry

mtheorem prepower_th_22:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
sorry

mtheorem prepower_th_23:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
sorry

mtheorem prepower_th_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (a /XCMPLX-0K7 b) =COMPLEX1R1 n -RootPREPOWERK2 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
sorry

mtheorem prepower_th_25:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (m -RootPREPOWERK2 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a"
sorry

mtheorem prepower_th_26:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
sorry

mtheorem prepower_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 b) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a <=XXREAL-0R1 n -RootPREPOWERK2 b"
sorry

mtheorem prepower_th_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & a <XXREAL-0R3 b) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 b"
sorry

mtheorem prepower_th_29:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -RootPREPOWERK2 a"
sorry

mtheorem prepower_th_30:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<one>\<^sub>M) & n >=XXREAL-0R2 \<one>\<^sub>M implies a <=XXREAL-0R1 n -RootPREPOWERK2 a & n -RootPREPOWERK2 a <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem prepower_th_31:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
sorry

mtheorem prepower_th_32:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies \<two>\<^sub>M -RootPREPOWERK2 a =COMPLEX1R1 sqrtSQUARE-1K3 a"
sorry

mlemma prepower_lm_3:
" for s be Real-SequenceSEQ-1M1 holds  for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_33:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
sorry

mdef prepower_def_3 (" _ #ZPREPOWERK3  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "k be IntegerINT-1M1"
"func a #ZPREPOWERK3 k \<rightarrow> numberORDINAL1M2 equals
  a  |^NEWTONK1 ( |.INT-2K1 k.|) if k >=XXREAL-0R2 0NUMBERSK6,
  (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 if k <XXREAL-0R3 0NUMBERSK6"
proof-
  (*consistency*)
    show " for it be numberORDINAL1M2 holds k >=XXREAL-0R2 0NUMBERSK6 & k <XXREAL-0R3 0NUMBERSK6 implies (it =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 k.|) iff it =HIDDENR1 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5)"
       sorry
  (*coherence*)
    show "(k >=XXREAL-0R2 0NUMBERSK6 implies a  |^NEWTONK1 ( |.INT-2K1 k.|) be numberORDINAL1M2) & (k <XXREAL-0R3 0NUMBERSK6 implies (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 be numberORDINAL1M2)"
      using tarski_th_1 sorry
qed "sorry"

mtheorem prepower_cl_3:
  mlet "a be RealXREAL-0M1", "k be IntegerINT-1M1"
"cluster a #ZPREPOWERK3 k as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "a #ZPREPOWERK3 k be realXREAL-0V1"
sorry
qed "sorry"

mtheorem prepower_th_34:
" for a be RealXREAL-0M1 holds a #ZPREPOWERK3 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_35:
" for a be RealXREAL-0M1 holds a #ZPREPOWERK3 \<one>\<^sub>M =COMPLEX1R1 a"
sorry

mtheorem prepower_th_36:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a #ZPREPOWERK3 n =COMPLEX1R1 a  |^NEWTONK1 n"
sorry

mlemma prepower_lm_4:
"\<one>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 \<one>\<^sub>M"
   sorry

mtheorem prepower_th_37:
" for k be IntegerINT-1M1 holds \<one>\<^sub>M #ZPREPOWERK3 k =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_38:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem prepower_th_39:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem prepower_th_40:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds (a *XCMPLX-0K3 b)#ZPREPOWERK3 k =COMPLEX1R1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
sorry

mtheorem prepower_th_41:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a #ZPREPOWERK3 (-XCMPLX-0K4 k) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
sorry

mtheorem prepower_th_42:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
sorry

mtheorem prepower_th_43:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_44:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =COMPLEX1R1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
sorry

mtheorem prepower_th_45:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =COMPLEX1R1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
sorry

mtheorem prepower_th_46:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies (n -RootPREPOWERK2 a)#ZPREPOWERK3 k =COMPLEX1R1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
sorry

mdef prepower_def_4 (" _ #QPREPOWERK4  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "p be RationalRAT-1M1"
"func a #QPREPOWERK4 p \<rightarrow> numberORDINAL1M2 equals
  denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p)"
proof-
  (*coherence*)
    show "denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) be numberORDINAL1M2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem prepower_cl_4:
  mlet "a be RealXREAL-0M1", "p be RationalRAT-1M1"
"cluster a #QPREPOWERK4 p as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "a #QPREPOWERK4 p be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem prepower_th_47:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds p =COMPLEX1R1 0NUMBERSK6 implies a #QPREPOWERK4 p =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_48:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & p =COMPLEX1R1 \<one>\<^sub>M implies a #QPREPOWERK4 p =COMPLEX1R1 a"
sorry

mlemma prepower_lm_5:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem prepower_th_49:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies a #QPREPOWERK4 n =COMPLEX1R1 a  |^NEWTONK1 n"
sorry

mtheorem prepower_th_50:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & p =COMPLEX1R1 n \<inverse>XCMPLX-0K5 implies a #QPREPOWERK4 p =COMPLEX1R1 n -RootPREPOWERK2 a"
sorry

mtheorem prepower_th_51:
" for p be RationalRAT-1M1 holds \<one>\<^sub>M #QPREPOWERK4 p =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_52:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem prepower_th_53:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p *XCMPLX-0K3 a #QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p +XCMPLX-0K2 q)"
sorry

mtheorem prepower_th_54:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK4 (-XCMPLX-0K4 p)"
sorry

mtheorem prepower_th_55:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p -XCMPLX-0K6 q)"
sorry

mtheorem prepower_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK4 p *XCMPLX-0K3 b #QPREPOWERK4 p"
sorry

mtheorem prepower_th_57:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
sorry

mtheorem prepower_th_58:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)#QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK4 p /XCMPLX-0K7 b #QPREPOWERK4 p"
sorry

mtheorem prepower_th_59:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #QPREPOWERK4 p)#QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p *XCMPLX-0K3 q)"
sorry

mtheorem prepower_th_60:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p >=XXREAL-0R2 0NUMBERSK6 implies a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem prepower_th_61:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p <=XXREAL-0R1 0NUMBERSK6 implies a #QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_62:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & p >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem prepower_th_63:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p >=XXREAL-0R2 q implies a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
sorry

mtheorem prepower_th_64:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & p >XXREAL-0R4 q implies a #QPREPOWERK4 p >XXREAL-0R4 a #QPREPOWERK4 q"
sorry

mtheorem prepower_th_65:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & p >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem prepower_th_66:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <=XXREAL-0R1 \<one>\<^sub>M) & p <=XXREAL-0R1 0NUMBERSK6 implies a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem prepower_cl_5:
"cluster REALNUMBERSK2 -valuedRELAT-1V5 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be REALNUMBERSK2 -valuedRELAT-1V5"
sorry
qed "sorry"

(*\$CD*)
syntax PREPOWERM1 :: "Ty" ("Rational-SequencePREPOWERM1" 70)
translations "Rational-SequencePREPOWERM1" \<rightharpoonup> "RATRAT-1K1 -valuedRELAT-1V5\<bar>Real-SequenceSEQ-1M1"

mtheorem prepower_th_67:
" for a be RealXREAL-0M1 holds  ex s be Rational-SequencePREPOWERM1 st (s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 a) & ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 a)"
sorry

mtheorem prepower_th_68:
" for a be RealXREAL-0M1 holds  ex s be Rational-SequencePREPOWERM1 st (s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 a) & ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n >=XXREAL-0R2 a)"
sorry

mdef prepower_def_6 (" _ #QPREPOWERK5  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "s be Rational-SequencePREPOWERM1"
"func a #QPREPOWERK5 s \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mlemma prepower_lm_6:
" for s be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds s be convergentSEQ-2V5 & a >=XXREAL-0R2 \<one>\<^sub>M implies a #QPREPOWERK5 s be convergentSEQ-2V5"
sorry

mtheorem prepower_th_69:
" for a be RealXREAL-0M1 holds  for s be Rational-SequencePREPOWERM1 holds s be convergentSEQ-2V5 & a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK5 s be convergentSEQ-2V5"
sorry

mlemma prepower_lm_7:
" for s1 be Rational-SequencePREPOWERM1 holds  for s2 be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds ((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2) & a >=XXREAL-0R2 \<one>\<^sub>M implies limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
sorry

mtheorem prepower_th_70:
" for s1 be Rational-SequencePREPOWERM1 holds  for s2 be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds ((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2) & a >XXREAL-0R4 0NUMBERSK6 implies (a #QPREPOWERK5 s1 be convergentSEQ-2V5 & a #QPREPOWERK5 s2 be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
sorry

mdef prepower_def_7 (" _ #RPREPOWERK6  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"assume a >XXREAL-0R4 0NUMBERSK6 func a #RPREPOWERK6 b \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it"
proof-
  (*existence*)
    show "a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st  ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it)"
sorry
  (*uniqueness*)
    show "a >XXREAL-0R4 0NUMBERSK6 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it1) & ( ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem prepower_th_71:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_72:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 \<one>\<^sub>M =COMPLEX1R1 a"
sorry

mtheorem prepower_th_73:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M #RPREPOWERK6 a =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_74:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 p =COMPLEX1R1 a #QPREPOWERK4 p"
sorry

mtheorem prepower_th_75:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (b +XCMPLX-0K2 c) =COMPLEX1R1 a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 c"
sorry

mlemma prepower_lm_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >=XXREAL-0R2 0NUMBERSK6"
sorry

mlemma prepower_lm_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem prepower_th_76:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
sorry

mtheorem prepower_th_77:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (b -XCMPLX-0K6 c) =COMPLEX1R1 a #RPREPOWERK6 b /XCMPLX-0K7 a #RPREPOWERK6 c"
sorry

mtheorem prepower_th_78:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c *XCMPLX-0K3 b #RPREPOWERK6 c"
sorry

mtheorem prepower_th_79:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
sorry

mtheorem prepower_th_80:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c /XCMPLX-0K7 b #RPREPOWERK6 c"
sorry

mtheorem prepower_th_81:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem prepower_th_82:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & c >=XXREAL-0R2 b implies a #RPREPOWERK6 c >=XXREAL-0R2 a #RPREPOWERK6 b"
sorry

mtheorem prepower_th_83:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & c >XXREAL-0R4 b implies a #RPREPOWERK6 c >XXREAL-0R4 a #RPREPOWERK6 b"
sorry

mtheorem prepower_th_84:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <=XXREAL-0R1 \<one>\<^sub>M) & c >=XXREAL-0R2 b implies a #RPREPOWERK6 c <=XXREAL-0R1 a #RPREPOWERK6 b"
sorry

mtheorem prepower_th_85:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b >=XXREAL-0R2 0NUMBERSK6 implies a #RPREPOWERK6 b >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem prepower_th_86:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem prepower_th_87:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b <=XXREAL-0R1 0NUMBERSK6 implies a #RPREPOWERK6 b <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem prepower_th_88:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b <XXREAL-0R3 0NUMBERSK6 implies a #RPREPOWERK6 b <XXREAL-0R3 \<one>\<^sub>M"
sorry

mlemma prepower_lm_10:
" for p be RationalRAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds (((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6) & p >=XXREAL-0R2 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p) implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
sorry

mtheorem prepower_th_89:
" for p be RationalRAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p) implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
sorry

mlemma prepower_lm_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b)#QPREPOWERK4 p =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 p)"
sorry

mlemma prepower_lm_12:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ((a >=XXREAL-0R2 \<one>\<^sub>M & s1 be convergentSEQ-2V5) & s2 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)) implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
sorry

mtheorem prepower_th_90:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & s1 be convergentSEQ-2V5) & s2 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)) implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
sorry

mtheorem prepower_th_91:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 c)"
sorry

(*begin*)
reserve r, u for "RealXREAL-0M1"
reserve k for "NatNAT-1M1"
mtheorem prepower_th_92:
" for r be RealXREAL-0M1 holds  for u be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 & u >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st u /XCMPLX-0K7 \<two>\<^sub>M  |^NEWTONK1 k <=XXREAL-0R1 r)"
sorry

mtheorem prepower_th_93:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for k be NatNAT-1M1 holds k >=XXREAL-0R2 n & r >=XXREAL-0R2 \<one>\<^sub>M implies r  |^NEWTONK1 k >=XXREAL-0R2 r  |^NEWTONK1 n"
sorry

mtheorem prepower_th_94:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n dividesNAT-DR1 m & n dividesNAT-DR1 l implies n dividesINT-1R1 m -XCMPLX-0K6 l"
sorry

mtheorem prepower_th_95:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m dividesNAT-DR1 n iff m dividesINT-1R1 n"
   sorry

mtheorem prepower_th_96:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
sorry

mtheorem prepower_th_97:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies a gcdINT-2K3 b =COMPLEX1R1 a gcdINT-2K3 (b -XCMPLX-0K6 a)"
sorry

mtheorem prepower_th_98:
" for a be RealXREAL-0M1 holds  for l be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 l >=XXREAL-0R2 0NUMBERSK6"
  using prepower_lm_5 sorry

mtheorem prepower_th_99:
" for a be RealXREAL-0M1 holds  for l be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 l =COMPLEX1R1 a #ZPREPOWERK3 l"
sorry

mtheorem prepower_th_100:
" for l be IntegerINT-1M1 holds l <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
sorry

end
