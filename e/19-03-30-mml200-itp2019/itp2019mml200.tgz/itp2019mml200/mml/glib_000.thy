theory glib_000
  imports domain_1 pboole finseq_4 nat_d binop_2 ordinal3
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem glib_000_cl_1:
"cluster finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4"
sorry
qed "sorry"

syntax GLIB_000M1 :: "Ty" ("GraphStructGLIB-000M1" 70)
translations "GraphStructGLIB-000M1" \<rightharpoonup> "finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"

mdef glib_000_def_1 ("VertexSelectorGLIB-000K1" 164 ) where
"func VertexSelectorGLIB-000K1 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_2 ("EdgeSelectorGLIB-000K2" 164 ) where
"func EdgeSelectorGLIB-000K2 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<two>\<^sub>M"
proof-
  (*coherence*)
    show "\<two>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_3 ("SourceSelectorGLIB-000K3" 164 ) where
"func SourceSelectorGLIB-000K3 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<three>\<^sub>M"
proof-
  (*coherence*)
    show "\<three>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_4 ("TargetSelectorGLIB-000K4" 164 ) where
"func TargetSelectorGLIB-000K4 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<four>\<^sub>M"
proof-
  (*coherence*)
    show "\<four>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_5 ("-GraphSelectorsGLIB-000K5" 164 ) where
"func -GraphSelectorsGLIB-000K5 \<rightarrow>  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 equals
  {DOMAIN-1K9\<^bsub>(NATNUMBERSK1)\<^esub> VertexSelectorGLIB-000K1,EdgeSelectorGLIB-000K2,SourceSelectorGLIB-000K3,TargetSelectorGLIB-000K4 }"
proof-
  (*coherence*)
    show "{DOMAIN-1K9\<^bsub>(NATNUMBERSK1)\<^esub> VertexSelectorGLIB-000K1,EdgeSelectorGLIB-000K2,SourceSelectorGLIB-000K3,TargetSelectorGLIB-000K4 } be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_6 ("the-Vertices-ofGLIB-000K6  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Vertices-ofGLIB-000K6 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (VertexSelectorGLIB-000K1)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (VertexSelectorGLIB-000K1) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_7 ("the-Edges-ofGLIB-000K7  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Edges-ofGLIB-000K7 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (EdgeSelectorGLIB-000K2)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (EdgeSelectorGLIB-000K2) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_8 ("the-Source-ofGLIB-000K8  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Source-ofGLIB-000K8 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (SourceSelectorGLIB-000K3)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (SourceSelectorGLIB-000K3) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_9 ("the-Target-ofGLIB-000K9  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Target-ofGLIB-000K9 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (TargetSelectorGLIB-000K4)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (TargetSelectorGLIB-000K4) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_10 ("[Graph-like]GLIB-000V1" 70 ) where
"attr [Graph-like]GLIB-000V1 for GraphStructGLIB-000M1 means
  (\<lambda>G. (((((VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G) & SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G) & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G) & the-Vertices-ofGLIB-000K6 G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2) & the-Source-ofGLIB-000K8 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)) & the-Target-ofGLIB-000K9 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G))"..

mtheorem glib_000_cl_2:
"cluster [Graph-like]GLIB-000V1 for GraphStructGLIB-000M1"
proof
(*existence*)
  show " ex it be GraphStructGLIB-000M1 st it be [Graph-like]GLIB-000V1"
sorry
qed "sorry"

syntax GLIB_000M2 :: "Ty" ("-GraphGLIB-000M2" 70)
translations "-GraphGLIB-000M2" \<rightharpoonup> "[Graph-like]GLIB-000V1\<bar>GraphStructGLIB-000M1"

mtheorem glib_000_cl_3:
  mlet "G be -GraphGLIB-000M2"
"cluster the-Vertices-ofGLIB-000K6 G as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G be  non emptyXBOOLE-0V1"
    using glib_000_def_10 sorry
qed "sorry"

abbreviation(input) GLIB_000K10("the-Source-ofGLIB-000K10  _ " [164]164) where
  "the-Source-ofGLIB-000K10 G \<equiv> the-Source-ofGLIB-000K8 G"

mtheorem glib_000_add_1:
  mlet "G be -GraphGLIB-000M2"
"cluster the-Source-ofGLIB-000K8 G as-term-is FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
proof
(*coherence*)
  show "the-Source-ofGLIB-000K8 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
    using glib_000_def_10 sorry
qed "sorry"

abbreviation(input) GLIB_000K11("the-Target-ofGLIB-000K11  _ " [164]164) where
  "the-Target-ofGLIB-000K11 G \<equiv> the-Target-ofGLIB-000K9 G"

mtheorem glib_000_add_2:
  mlet "G be -GraphGLIB-000M2"
"cluster the-Target-ofGLIB-000K9 G as-term-is FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
proof
(*coherence*)
  show "the-Target-ofGLIB-000K9 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
    using glib_000_def_10 sorry
qed "sorry"

mdef glib_000_def_11 ("createGraphGLIB-000K12'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,V)", "T be FunctionFUNCT-2M1-of(E,V)"
"func createGraphGLIB-000K12(V,E,S,T) \<rightarrow> -GraphGLIB-000M2 equals
  <*FINSEQ-4K7 V,E,S,T *>"
proof-
  (*coherence*)
    show "<*FINSEQ-4K7 V,E,S,T *> be -GraphGLIB-000M2"
sorry
qed "sorry"

mdef glib_000_def_12 (" _ .setGLIB-000K13'( _ , _ ')" [260,0,0]260 ) where
  mlet "G be GraphStructGLIB-000M1", "n be NatNAT-1M1", "x be setHIDDENM2"
"func G .setGLIB-000K13(n,x) \<rightarrow> GraphStructGLIB-000M1 equals
  G +*FUNCT-4K1 (n .-->FUNCOP-1K17 x)"
proof-
  (*coherence*)
    show "G +*FUNCT-4K1 (n .-->FUNCOP-1K17 x) be GraphStructGLIB-000M1"
sorry
qed "sorry"

mlemma glib_000_lm_1:
" for GS be GraphStructGLIB-000M1 holds GS be [Graph-like]GLIB-000V1 iff ((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & the-Vertices-ofGLIB-000K6 GS be  non emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)"
sorry

mtheorem glib_000_cl_4:
  mlet "G be -GraphGLIB-000M2"
"cluster G  |RELAT-1K8 (-GraphSelectorsGLIB-000K5) as-term-is [Graph-like]GLIB-000V1"
proof
(*coherence*)
  show "G  |RELAT-1K8 (-GraphSelectorsGLIB-000K5) be [Graph-like]GLIB-000V1"
sorry
qed "sorry"

mdef glib_000_def_13 (" _ JoinsGLIB-000R1'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "x be objectHIDDENM1", "y be objectHIDDENM1", "e be objectHIDDENM1"
"pred e JoinsGLIB-000R1(x,y,G) means
  e inHIDDENR3 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 x & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 y or (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 y & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 x)"..

mdef glib_000_def_14 (" _ DJoinsGLIB-000R2'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "x be objectHIDDENM1", "y be objectHIDDENM1", "e be objectHIDDENM1"
"pred e DJoinsGLIB-000R2(x,y,G) means
  (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 x) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 y"..

mdef glib_000_def_15 (" _ SJoinsGLIB-000R3'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2", "e be objectHIDDENM1"
"pred e SJoinsGLIB-000R3(X,Y,G) means
  e inHIDDENR3 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 Y or (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 Y & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)"..

mdef glib_000_def_16 (" _ DSJoinsGLIB-000R4'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2", "e be objectHIDDENM1"
"pred e DSJoinsGLIB-000R4(X,Y,G) means
  (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 Y"..

mdef glib_000_def_17 ("finiteGLIB-000V2" 70 ) where
"attr finiteGLIB-000V2 for -GraphGLIB-000M2 means
  (\<lambda>G. the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1 & the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1)"..

mdef glib_000_def_18 ("looplessGLIB-000V3" 70 ) where
"attr looplessGLIB-000V3 for -GraphGLIB-000M2 means
  (\<lambda>G.  not ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e))"..

mdef glib_000_def_19 ("trivialGLIB-000V4" 70 ) where
"attr trivialGLIB-000V4 for -GraphGLIB-000M2 means
  (\<lambda>G. cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M)"..

mdef glib_000_def_20 ("non-multiGLIB-000V5" 70 ) where
"attr non-multiGLIB-000V5 for -GraphGLIB-000M2 means
  (\<lambda>G.  for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,G) & e2 JoinsGLIB-000R1(v1,v2,G) implies e1 =HIDDENR1 e2)"..

mdef glib_000_def_21 ("non-DmultiGLIB-000V6" 70 ) where
"attr non-DmultiGLIB-000V6 for -GraphGLIB-000M2 means
  (\<lambda>G.  for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 DJoinsGLIB-000R2(v1,v2,G) & e2 DJoinsGLIB-000R2(v1,v2,G) implies e1 =HIDDENR1 e2)"..

mdef glib_000_def_22 ("simpleGLIB-000V7" 70 ) where
"attr simpleGLIB-000V7 for -GraphGLIB-000M2 means
  (\<lambda>G. G be looplessGLIB-000V3 & G be non-multiGLIB-000V5)"..

mdef glib_000_def_23 ("DsimpleGLIB-000V8" 70 ) where
"attr DsimpleGLIB-000V8 for -GraphGLIB-000M2 means
  (\<lambda>G. G be looplessGLIB-000V3 & G be non-DmultiGLIB-000V6)"..

mlemma glib_000_lm_2:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1 implies G be simpleGLIB-000V7"
sorry

mtheorem glib_000_cl_5:
"cluster non-multiGLIB-000V5 also-is non-DmultiGLIB-000V6 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be non-multiGLIB-000V5 implies it be non-DmultiGLIB-000V6"
sorry
qed "sorry"

mtheorem glib_000_cl_6:
"cluster simpleGLIB-000V7 also-is looplessGLIB-000V3\<bar>non-multiGLIB-000V5 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be simpleGLIB-000V7 implies it be looplessGLIB-000V3\<bar>non-multiGLIB-000V5"
     sorry
qed "sorry"

mtheorem glib_000_cl_7:
"cluster looplessGLIB-000V3\<bar>non-multiGLIB-000V5 also-is simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be looplessGLIB-000V3\<bar>non-multiGLIB-000V5 implies it be simpleGLIB-000V7"
     sorry
qed "sorry"

mtheorem glib_000_cl_8:
"cluster looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6 also-is DsimpleGLIB-000V8 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6 implies it be DsimpleGLIB-000V8"
     sorry
qed "sorry"

mtheorem glib_000_cl_9:
"cluster DsimpleGLIB-000V8 also-is looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be DsimpleGLIB-000V8 implies it be looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6"
     sorry
qed "sorry"

mtheorem glib_000_cl_10:
"cluster trivialGLIB-000V4\<bar>looplessGLIB-000V3 also-is finiteFINSET-1V1 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be trivialGLIB-000V4\<bar>looplessGLIB-000V3 implies it be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem glib_000_cl_11:
"cluster trivialGLIB-000V4\<bar>non-DmultiGLIB-000V6 also-is finiteFINSET-1V1 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be trivialGLIB-000V4\<bar>non-DmultiGLIB-000V6 implies it be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem glib_000_cl_12:
"cluster trivialGLIB-000V4\<bar>simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*existence*)
  show " ex it be -GraphGLIB-000M2 st it be trivialGLIB-000V4\<bar>simpleGLIB-000V7"
sorry
qed "sorry"

mtheorem glib_000_cl_13:
"cluster finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*existence*)
  show " ex it be -GraphGLIB-000M2 st it be finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>simpleGLIB-000V7"
sorry
qed "sorry"

mtheorem glib_000_cl_14:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster the-Vertices-ofGLIB-000K6 G as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1"
    using glib_000_def_17 sorry
qed "sorry"

mtheorem glib_000_cl_15:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster the-Edges-ofGLIB-000K7 G as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
    using glib_000_def_17 sorry
qed "sorry"

mtheorem glib_000_cl_16:
  mlet "G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
"cluster the-Vertices-ofGLIB-000K6 G as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem glib_000_cl_17:
  mlet "V be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "E be finiteFINSET-1V1\<bar>setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,V)", "T be FunctionFUNCT-2M1-of(E,V)"
"cluster createGraphGLIB-000K12(V,E,S,T) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "createGraphGLIB-000K12(V,E,S,T) be finiteFINSET-1V1"
    using finseq_4_th_76 sorry
qed "sorry"

mtheorem glib_000_cl_18:
  mlet "V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be emptyXBOOLE-0V1\<bar>setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,V)", "T be FunctionFUNCT-2M1-of(E,V)"
"cluster createGraphGLIB-000K12(V,E,S,T) as-term-is simpleGLIB-000V7"
proof
(*coherence*)
  show "createGraphGLIB-000K12(V,E,S,T) be simpleGLIB-000V7"
sorry
qed "sorry"

mtheorem glib_000_cl_19:
  mlet "v be setHIDDENM2", "E be setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,{TARSKIK1 v})", "T be FunctionFUNCT-2M1-of(E,{TARSKIK1 v})"
"cluster createGraphGLIB-000K12({TARSKIK1 v},E,S,T) as-term-is trivialGLIB-000V4"
proof
(*coherence*)
  show "createGraphGLIB-000K12({TARSKIK1 v},E,S,T) be trivialGLIB-000V4"
sorry
qed "sorry"

mdef glib_000_def_24 (" _ .order'(')GLIB-000K14" [260]260 ) where
  mlet "G be -GraphGLIB-000M2"
"func G .order()GLIB-000K14 \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K15(" _ .order'(')GLIB-000K15" [260]260) where
  "G .order()GLIB-000K15 \<equiv> G .order()GLIB-000K14"

mtheorem glib_000_add_3:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster G .order()GLIB-000K14 as-term-is  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "G .order()GLIB-000K14 be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

mdef glib_000_def_25 (" _ .size'(')GLIB-000K16" [260]260 ) where
  mlet "G be -GraphGLIB-000M2"
"func G .size()GLIB-000K16 \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (the-Edges-ofGLIB-000K7 G)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (the-Edges-ofGLIB-000K7 G) be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K17(" _ .size'(')GLIB-000K17" [260]260) where
  "G .size()GLIB-000K17 \<equiv> G .size()GLIB-000K16"

mtheorem glib_000_add_4:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster G .size()GLIB-000K16 as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "G .size()GLIB-000K16 be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

mdef glib_000_def_26 (" _ .edgesIntoGLIB-000K18  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesIntoGLIB-000K18 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be setHIDDENM2 holds e inTARSKIR2 it1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) & ( for e be setHIDDENM2 holds e inTARSKIR2 it2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef glib_000_def_27 (" _ .edgesOutOfGLIB-000K19  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesOutOfGLIB-000K19 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be setHIDDENM2 holds e inTARSKIR2 it1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & ( for e be setHIDDENM2 holds e inTARSKIR2 it2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef glib_000_def_28 (" _ .edgesInOutGLIB-000K20  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesInOutGLIB-000K20 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesIntoGLIB-000K18 X \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X"
proof-
  (*coherence*)
    show "G .edgesIntoGLIB-000K18 X \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_29 (" _ .edgesBetweenGLIB-000K21  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesBetweenGLIB-000K21 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesIntoGLIB-000K18 X /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X"
proof-
  (*coherence*)
    show "G .edgesIntoGLIB-000K18 X /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_30 (" _ .edgesBetweenGLIB-000K22'( _ , _ ')" [260,0,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2"
"func G .edgesBetweenGLIB-000K22(X,Y) \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e SJoinsGLIB-000R3(X,Y,G)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e SJoinsGLIB-000R3(X,Y,G)"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be objectHIDDENM1 holds e inHIDDENR3 it1 iff e SJoinsGLIB-000R3(X,Y,G)) & ( for e be objectHIDDENM1 holds e inHIDDENR3 it2 iff e SJoinsGLIB-000R3(X,Y,G)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef glib_000_def_31 (" _ .edgesDBetweenGLIB-000K23'( _ , _ ')" [260,0,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2"
"func G .edgesDBetweenGLIB-000K23(X,Y) \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e DSJoinsGLIB-000R4(X,Y,G)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e DSJoinsGLIB-000R4(X,Y,G)"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be objectHIDDENM1 holds e inHIDDENR3 it1 iff e DSJoinsGLIB-000R4(X,Y,G)) & ( for e be objectHIDDENM1 holds e inHIDDENR3 it2 iff e DSJoinsGLIB-000R4(X,Y,G)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

theorem glib_000_sch_1:
  fixes Pp1 
  assumes
    A1: " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .order()GLIB-000K15 =XBOOLE-0R4 \<one>\<^sub>M implies Pp1(G)" and
   A2: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ( for Gk be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk .order()GLIB-000K15 =XBOOLE-0R4 k implies Pp1(Gk)) implies ( for Gk1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk1 .order()GLIB-000K15 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies Pp1(Gk1))"
  shows " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Pp1(G)"
sorry

theorem glib_000_sch_2:
  fixes Pp1 
  assumes
    A1: " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .size()GLIB-000K17 =XBOOLE-0R4 0NUMBERSK6 implies Pp1(G)" and
   A2: " for k be NatNAT-1M1 holds ( for Gk be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk .size()GLIB-000K17 =XBOOLE-0R4 k implies Pp1(Gk)) implies ( for Gk1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk1 .size()GLIB-000K17 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies Pp1(Gk1))"
  shows " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Pp1(G)"
sorry

mdef glib_000_def_32 ("SubgraphGLIB-000M3-of  _ " [70]70 ) where
  mlet "G be -GraphGLIB-000M2"
"mode SubgraphGLIB-000M3-of G \<rightarrow> -GraphGLIB-000M2 means
  (\<lambda>it. (the-Vertices-ofGLIB-000K6 it c=TARSKIR1 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 it c=TARSKIR1 the-Edges-ofGLIB-000K7 G) & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 it implies (the-Source-ofGLIB-000K10 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e))"
proof-
  (*existence*)
    show " ex it be -GraphGLIB-000M2 st (the-Vertices-ofGLIB-000K6 it c=TARSKIR1 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 it c=TARSKIR1 the-Edges-ofGLIB-000K7 G) & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 it implies (the-Source-ofGLIB-000K10 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)"
sorry
qed "sorry"

syntax GLIB_000K24 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("the-Vertices-ofGLIB-000K24\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2" \<rightharpoonup> "the-Vertices-ofGLIB-000K6 G2"

mtheorem glib_000_add_5:
  mlet "G1 be -GraphGLIB-000M2", "G2 be SubgraphGLIB-000M3-of G1"
"cluster the-Vertices-ofGLIB-000K6 G2 as-term-is  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1"
    using glib_000_def_32 sorry
qed "sorry"

syntax GLIB_000K25 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("the-Edges-ofGLIB-000K25\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2" \<rightharpoonup> "the-Edges-ofGLIB-000K7 G2"

mtheorem glib_000_add_6:
  mlet "G1 be -GraphGLIB-000M2", "G2 be SubgraphGLIB-000M3-of G1"
"cluster the-Edges-ofGLIB-000K7 G2 as-term-is SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1"
proof
(*coherence*)
  show "the-Edges-ofGLIB-000K7 G2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1"
    using glib_000_def_32 sorry
qed "sorry"

mtheorem glib_000_cl_20:
  mlet "G be -GraphGLIB-000M2"
"cluster trivialGLIB-000V4\<bar>simpleGLIB-000V7 for SubgraphGLIB-000M3-of G"
proof
(*existence*)
  show " ex it be SubgraphGLIB-000M3-of G st it be trivialGLIB-000V4\<bar>simpleGLIB-000V7"
sorry
qed "sorry"

mlemma glib_000_lm_3:
" for G be -GraphGLIB-000M2 holds G be SubgraphGLIB-000M3-of G"
sorry

mlemma glib_000_lm_4:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for e be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G2) implies e JoinsGLIB-000R1(x,y,G1)"
sorry

mtheorem glib_000_cl_21:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster note-that finiteGLIB-000V2 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be finiteGLIB-000V2"
sorry
qed "sorry"

mtheorem glib_000_cl_22:
  mlet "G be looplessGLIB-000V3\<bar>-GraphGLIB-000M2"
"cluster note-that looplessGLIB-000V3 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be looplessGLIB-000V3"
sorry
qed "sorry"

mtheorem glib_000_cl_23:
  mlet "G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
"cluster note-that trivialGLIB-000V4 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be trivialGLIB-000V4"
sorry
qed "sorry"

mtheorem glib_000_cl_24:
  mlet "G be non-multiGLIB-000V5\<bar>-GraphGLIB-000M2"
"cluster note-that non-multiGLIB-000V5 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be non-multiGLIB-000V5"
sorry
qed "sorry"

mdef glib_000_def_33 ("spanningGLIB-000V9\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "G1 be -GraphGLIB-000M2"
"attr spanningGLIB-000V9\<^bsub>(G1)\<^esub> for SubgraphGLIB-000M3-of G1 means
  (\<lambda>G2. the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1)"..

mtheorem glib_000_cl_25:
  mlet "G be -GraphGLIB-000M2"
"cluster spanningGLIB-000V9\<^bsub>(G)\<^esub> for SubgraphGLIB-000M3-of G"
proof
(*existence*)
  show " ex it be SubgraphGLIB-000M3-of G st it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
sorry
qed "sorry"

mdef glib_000_def_34 (" _ ==GLIB-000R5  _ " [50,50]50 ) where
  mlet "G1 be -GraphGLIB-000M2", "G2 be -GraphGLIB-000M2"
"pred G1 ==GLIB-000R5 G2 means
  ((the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2) & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"..

mtheorem GLIB_000R5_reflexivity:
" for G2 be -GraphGLIB-000M2 holds G2 ==GLIB-000R5 G2"
sorry

mtheorem GLIB_000R5_symmetry:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 implies G2 ==GLIB-000R5 G1"
sorry

syntax GLIB_000R6 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ !=GLIB-000R6  _ " [50,50]50)
translations "G1 !=GLIB-000R6 G2" \<rightharpoonup> " not G1 ==GLIB-000R5 G2"

mdef glib_000_def_35 (" _ c=GLIB-000R7  _ " [50,50]50 ) where
  mlet "G1 be -GraphGLIB-000M2", "G2 be -GraphGLIB-000M2"
"pred G1 c=GLIB-000R7 G2 means
  G1 be SubgraphGLIB-000M3-of G2"..

mtheorem GLIB_000R7_reflexivity:
" for G2 be -GraphGLIB-000M2 holds G2 c=GLIB-000R7 G2"
sorry

mdef glib_000_def_36 (" _ c<GLIB-000R8  _ " [50,50]50 ) where
  mlet "G1 be -GraphGLIB-000M2", "G2 be -GraphGLIB-000M2"
"pred G1 c<GLIB-000R8 G2 means
  G1 c=GLIB-000R7 G2 & G1 !=GLIB-000R6 G2"..

mtheorem GLIB_000R8_irreflexivity:
" for G2 be -GraphGLIB-000M2 holds  not G2 c<GLIB-000R8 G2"
sorry

mdef glib_000_def_37 ("inducedSubgraphGLIB-000M4-of'( _ , _ , _ ')" [0,0,0]70 ) where
  mlet "G be -GraphGLIB-000M2", "V be setHIDDENM2", "E be setHIDDENM2"
"mode inducedSubgraphGLIB-000M4-of(G,V,E) \<rightarrow> SubgraphGLIB-000M3-of G means
  (\<lambda>it. the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> it =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> it =XBOOLE-0R4 E if V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V otherwise \<lambda>it. it ==GLIB-000R5 G)"
proof-
  (*existence*)
    show "(V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V implies ( ex it be SubgraphGLIB-000M3-of G st the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> it =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> it =XBOOLE-0R4 E)) & ( not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V) implies ( ex it be SubgraphGLIB-000M3-of G st it ==GLIB-000R5 G))"
sorry
  (*consistency*)
    show " for it be SubgraphGLIB-000M3-of G holds  True "
       sorry
qed "sorry"

syntax GLIB_000M5 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("inducedSubgraphGLIB-000M5-of'( _ , _ ')" [0,0]70)
translations "inducedSubgraphGLIB-000M5-of(G,V)" \<rightharpoonup> "inducedSubgraphGLIB-000M4-of(G,V,G .edgesBetweenGLIB-000K21 V)"

mtheorem glib_000_cl_26:
  mlet "G be -GraphGLIB-000M2", "V be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G", "E be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of G .edgesBetweenGLIB-000K21 V"
"cluster note-that finiteGLIB-000V2 for inducedSubgraphGLIB-000M4-of(G,V,E)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,V,E) holds it be finiteGLIB-000V2"
    using glib_000_def_37 sorry
qed "sorry"

mtheorem glib_000_cl_27:
  mlet "G be -GraphGLIB-000M2", "v be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G", "E be SubsetSUBSET-1M2-of G .edgesBetweenGLIB-000K21 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
"cluster note-that trivialGLIB-000V4 for inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E) holds it be trivialGLIB-000V4"
sorry
qed "sorry"

mtheorem glib_000_cl_28:
  mlet "G be -GraphGLIB-000M2", "v be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G"
"cluster note-that finiteGLIB-000V2\<bar>trivialGLIB-000V4 for inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},{}XBOOLE-0K1)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},{}XBOOLE-0K1) holds it be finiteGLIB-000V2\<bar>trivialGLIB-000V4"
sorry
qed "sorry"

mtheorem glib_000_cl_29:
  mlet "G be -GraphGLIB-000M2", "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
"cluster note-that simpleGLIB-000V7 for inducedSubgraphGLIB-000M4-of(G,V,{}XBOOLE-0K1)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,V,{}XBOOLE-0K1) holds it be simpleGLIB-000V7"
sorry
qed "sorry"

mlemma glib_000_lm_5:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X iff e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
sorry

mlemma glib_000_lm_6:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
sorry

mtheorem glib_000_cl_30:
  mlet "G be -GraphGLIB-000M2", "E be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,E)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,E) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
sorry
qed "sorry"

mtheorem glib_000_cl_31:
  mlet "G be -GraphGLIB-000M2"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,{}XBOOLE-0K1)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,{}XBOOLE-0K1) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
sorry
qed "sorry"

abbreviation(input) GLIB_000M6("removeVertexGLIB-000M6-of'( _ , _ ')" [0,0]70) where
  "removeVertexGLIB-000M6-of(G,v) \<equiv> inducedSubgraphGLIB-000M5-of(G,the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {TARSKIK1 v})"

abbreviation(input) GLIB_000M7("removeVerticesGLIB-000M7-of'( _ , _ ')" [0,0]70) where
  "removeVerticesGLIB-000M7-of(G,V) \<equiv> inducedSubgraphGLIB-000M5-of(G,the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 V)"

syntax GLIB_000M8 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("removeEdgeGLIB-000M8-of'( _ , _ ')" [0,0]70)
translations "removeEdgeGLIB-000M8-of(G,e)" \<rightharpoonup> "inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 {TARSKIK1 e})"

syntax GLIB_000M9 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("removeEdgesGLIB-000M9-of'( _ , _ ')" [0,0]70)
translations "removeEdgesGLIB-000M9-of(G,E)" \<rightharpoonup> "inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 E)"

mtheorem glib_000_cl_32:
  mlet "G be -GraphGLIB-000M2", "e be setHIDDENM2"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for removeEdgeGLIB-000M8-of(G,e)"
proof
(*coherence*)
  show " for it be removeEdgeGLIB-000M8-of(G,e) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
     sorry
qed "sorry"

mtheorem glib_000_cl_33:
  mlet "G be -GraphGLIB-000M2", "E be setHIDDENM2"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for removeEdgesGLIB-000M9-of(G,E)"
proof
(*coherence*)
  show " for it be removeEdgesGLIB-000M9-of(G,E) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
     sorry
qed "sorry"

abbreviation(input) GLIB_000M10("VertexGLIB-000M10-of  _ " [70]70) where
  "VertexGLIB-000M10-of G \<equiv> ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G"

mdef glib_000_def_38 (" _ .edgesIn'(')GLIB-000K26\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesIntoGLIB-000K18 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  (*coherence*)
    show "G .edgesIntoGLIB-000K18 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_39 (" _ .edgesOut'(')GLIB-000K27\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesOutOfGLIB-000K19 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  (*coherence*)
    show "G .edgesOutOfGLIB-000K19 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_40 (" _ .edgesInOut'(')GLIB-000K28\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesInOutGLIB-000K20 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  (*coherence*)
    show "G .edgesInOutGLIB-000K20 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mlemma glib_000_lm_7:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be setHIDDENM2 holds e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
sorry

mlemma glib_000_lm_8:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be setHIDDENM2 holds e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
sorry

mdef glib_000_def_41 (" _ .adjGLIB-000K29\<^bsub>'( _ ')\<^esub>  _ " [260,0,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G", "e be objectHIDDENM1"
"func v .adjGLIB-000K29\<^bsub>(G)\<^esub> e \<rightarrow> VertexGLIB-000M10-of G equals
  (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e if e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v,
  (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e if (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v otherwise v"
proof-
  (*coherence*)
    show "(e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e be VertexGLIB-000M10-of G) & (((e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e be VertexGLIB-000M10-of G) & ( not (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not ((e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) implies v be VertexGLIB-000M10-of G))"
      using funct_2_th_5 sorry
  (*consistency*)
    show " for it be VertexGLIB-000M10-of G holds (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) & ((e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) implies (it =HIDDENR1 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e iff it =HIDDENR1 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)"
       sorry
qed "sorry"

mdef glib_000_def_42 (" _ .inDegree'(')GLIB-000K30\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "cardCARD-1K1 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> be CardinalCARD-1M1"
       sorry
qed "sorry"

mdef glib_000_def_43 (" _ .outDegree'(')GLIB-000K31\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "cardCARD-1K1 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K32(" _ .inDegree'(')GLIB-000K32\<^bsub>'( _ ')\<^esub>" [260,0]260) where
  "v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> \<equiv> v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub>"

mtheorem glib_000_add_7:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"cluster v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

abbreviation(input) GLIB_000K33(" _ .outDegree'(')GLIB-000K33\<^bsub>'( _ ')\<^esub>" [260,0]260) where
  "v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub> \<equiv> v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub>"

mtheorem glib_000_add_8:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"cluster v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

mdef glib_000_def_44 (" _ .degree'(')GLIB-000K34\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .degree()GLIB-000K34\<^bsub>(G)\<^esub> \<rightarrow> CardinalCARD-1M1 equals
  v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> +`CARD-2K1 v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> +`CARD-2K1 v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K35(" _ .degree'(')GLIB-000K35\<^bsub>'( _ ')\<^esub>" [260,0]260) where
  "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> \<equiv> v .degree()GLIB-000K34\<^bsub>(G)\<^esub>"

mtheorem glib_000_def_45:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"redefine func v .degree()GLIB-000K35\<^bsub>(G)\<^esub> \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds it =HIDDENR1 v .degree()GLIB-000K35\<^bsub>(G)\<^esub> iff it =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
sorry
qed "sorry"

mtheorem glib_000_add_9:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"cluster v .degree()GLIB-000K34\<^bsub>(G)\<^esub> as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

mdef glib_000_def_46 (" _ .inNeighbors'(')GLIB-000K36\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G equals
  (the-Source-ofGLIB-000K10 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "(the-Source-ofGLIB-000K10 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
       sorry
qed "sorry"

mdef glib_000_def_47 (" _ .outNeighbors'(')GLIB-000K37\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G equals
  (the-Target-ofGLIB-000K11 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "(the-Target-ofGLIB-000K11 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
       sorry
qed "sorry"

mdef glib_000_def_48 (" _ .allNeighbors'(')GLIB-000K38\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G equals
  v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
       sorry
qed "sorry"

mdef glib_000_def_49 ("isolatedGLIB-000V10\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "G be -GraphGLIB-000M2"
"attr isolatedGLIB-000V10\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v. v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1)"..

abbreviation(input) GLIB_000V11("isolatedGLIB-000V11\<^bsub>'( _ ')\<^esub>" [0]70) where
  "isolatedGLIB-000V11\<^bsub>(G)\<^esub> \<equiv> isolatedGLIB-000V10\<^bsub>(G)\<^esub>"

mtheorem glib_000_def_50:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"redefine attr isolatedGLIB-000V11\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v. v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6)"
proof
(*compatibility*)
  show " for v be VertexGLIB-000M10-of G holds v be isolatedGLIB-000V11\<^bsub>(G)\<^esub> iff v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
sorry
qed "sorry"

mdef glib_000_def_51 ("endvertexGLIB-000V12\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "G be -GraphGLIB-000M2"
"attr endvertexGLIB-000V12\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v.  ex e be objectHIDDENM1 st v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} &  not e JoinsGLIB-000R1(v,v,G))"..

abbreviation(input) GLIB_000V13("endvertexGLIB-000V13\<^bsub>'( _ ')\<^esub>" [0]70) where
  "endvertexGLIB-000V13\<^bsub>(G)\<^esub> \<equiv> endvertexGLIB-000V12\<^bsub>(G)\<^esub>"

mtheorem glib_000_def_52:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"redefine attr endvertexGLIB-000V13\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v. v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M)"
proof
(*compatibility*)
  show " for v be VertexGLIB-000M10-of G holds v be endvertexGLIB-000V13\<^bsub>(G)\<^esub> iff v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
sorry
qed "sorry"

mlemma glib_000_lm_9:
" for F be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for n be objectHIDDENM1 holds n be NatNAT-1M1 iff n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
sorry

mdef glib_000_def_53 ("Graph-yieldingGLIB-000V14" 70 ) where
"attr Graph-yieldingGLIB-000V14 for FunctionFUNCT-1M1 means
  (\<lambda>F.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be -GraphGLIB-000M2)"..

abbreviation(input) GLIB_000V15("Graph-yieldingGLIB-000V15" 70) where
  "Graph-yieldingGLIB-000V15 \<equiv> Graph-yieldingGLIB-000V14"

mtheorem glib_000_def_54:
  mlet "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"redefine attr Graph-yieldingGLIB-000V15 for ManySortedSetPBOOLEM1-of NATNUMBERSK1 means
  (\<lambda>F.  for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)"
proof
(*compatibility*)
  show " for F be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds F be Graph-yieldingGLIB-000V15 iff ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)"
sorry
qed "sorry"

mdef glib_000_def_55 ("haltingGLIB-000V16" 70 ) where
"attr haltingGLIB-000V16 for ManySortedSetPBOOLEM1-of NATNUMBERSK1 means
  (\<lambda>F.  ex n be NatNAT-1M1 st F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"..

mdef glib_000_def_56 (" _ .Lifespan'(')GLIB-000K39" [260]260 ) where
  mlet "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"func F .Lifespan()GLIB-000K39 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. F .FUNCT-1K1 it =XBOOLE-0R4 F .FUNCT-1K1 (it +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it <=XXREAL-0R1 n) if F be haltingGLIB-000V16 otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show "(F be haltingGLIB-000V16 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st F .FUNCT-1K1 it =XBOOLE-0R4 F .FUNCT-1K1 (it +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it <=XXREAL-0R1 n))) & ( not F be haltingGLIB-000V16 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it =XBOOLE-0R4 0NUMBERSK6))"
sorry
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (F be haltingGLIB-000V16 implies ((F .FUNCT-1K1 it1 =XBOOLE-0R4 F .FUNCT-1K1 (it1 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it1 <=XXREAL-0R1 n)) & (F .FUNCT-1K1 it2 =XBOOLE-0R4 F .FUNCT-1K1 (it2 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it2 <=XXREAL-0R1 n)) implies it1 =HIDDENR1 it2)) & ( not F be haltingGLIB-000V16 implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
sorry
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds  True "
       sorry
qed "sorry"

mdef glib_000_def_57 (" _ .Result'(')GLIB-000K40" [260]260 ) where
  mlet "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"func F .Result()GLIB-000K40 \<rightarrow> setHIDDENM2 equals
  F .FUNCT-1K1 F .Lifespan()GLIB-000K39"
proof-
  (*coherence*)
    show "F .FUNCT-1K1 F .Lifespan()GLIB-000K39 be setHIDDENM2"
       sorry
qed "sorry"

mtheorem glib_000_cl_34:
  mlet "G be -GraphGLIB-000M2"
"cluster NATNUMBERSK1 -->FUNCOP-1K7 G as-term-is Graph-yieldingGLIB-000V15"
proof
(*coherence*)
  show "NATNUMBERSK1 -->FUNCOP-1K7 G be Graph-yieldingGLIB-000V15"
sorry
qed "sorry"

mtheorem glib_000_cl_35:
"cluster Graph-yieldingGLIB-000V15 for ManySortedSetPBOOLEM1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st it be Graph-yieldingGLIB-000V15"
sorry
qed "sorry"

syntax GLIB_000M11 :: "Ty" ("GraphSeqGLIB-000M11" 70)
translations "GraphSeqGLIB-000M11" \<rightharpoonup> "Graph-yieldingGLIB-000V15\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1"

mtheorem glib_000_cl_36:
"cluster note-that  non emptyXBOOLE-0V1 for GraphSeqGLIB-000M11"
proof
(*coherence*)
  show " for it be GraphSeqGLIB-000M11 holds it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem glib_000_cl_37:
"cluster  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14"
sorry
qed "sorry"

mtheorem glib_000_cl_38:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
    using glib_000_def_53 sorry
qed "sorry"

mtheorem glib_000_cl_39:
  mlet "GSq be GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
    using glib_000_def_54 sorry
qed "sorry"

mtheorem glib_000_cl_40:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
    using glib_000_def_53 sorry
qed "sorry"

mtheorem glib_000_cl_41:
  mlet "GSq be GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
    using glib_000_def_54 sorry
qed "sorry"

mtheorem glib_000_cl_42:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is [Graph-like]GLIB-000V1"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be [Graph-like]GLIB-000V1"
    using glib_000_def_53 sorry
qed "sorry"

mtheorem glib_000_cl_43:
  mlet "GSq be GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is [Graph-like]GLIB-000V1"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be [Graph-like]GLIB-000V1"
    using glib_000_def_54 sorry
qed "sorry"

mdef glib_000_def_58 ("finiteGLIB-000V17" 70 ) where
"attr finiteGLIB-000V17 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be finiteGLIB-000V2))"..

mdef glib_000_def_59 ("looplessGLIB-000V18" 70 ) where
"attr looplessGLIB-000V18 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be looplessGLIB-000V3))"..

mdef glib_000_def_60 ("trivialGLIB-000V19" 70 ) where
"attr trivialGLIB-000V19 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be trivialGLIB-000V4))"..

mdef glib_000_def_61 ("non-trivialGLIB-000V20" 70 ) where
"attr non-trivialGLIB-000V20 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be  non trivialGLIB-000V4))"..

mdef glib_000_def_62 ("non-multiGLIB-000V21" 70 ) where
"attr non-multiGLIB-000V21 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be non-multiGLIB-000V5))"..

mdef glib_000_def_63 ("non-DmultiGLIB-000V22" 70 ) where
"attr non-DmultiGLIB-000V22 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be non-DmultiGLIB-000V6))"..

mdef glib_000_def_64 ("simpleGLIB-000V23" 70 ) where
"attr simpleGLIB-000V23 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be simpleGLIB-000V7))"..

mdef glib_000_def_65 ("DsimpleGLIB-000V24" 70 ) where
"attr DsimpleGLIB-000V24 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be DsimpleGLIB-000V8))"..

mtheorem glib_000_cl_44:
"cluster emptyXBOOLE-0V1 also-is finiteGLIB-000V17\<bar>looplessGLIB-000V18\<bar>trivialGLIB-000V19\<bar>non-trivialGLIB-000V20\<bar>non-multiGLIB-000V21\<bar>non-DmultiGLIB-000V22\<bar>simpleGLIB-000V23\<bar>DsimpleGLIB-000V24 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be finiteGLIB-000V17\<bar>looplessGLIB-000V18\<bar>trivialGLIB-000V19\<bar>non-trivialGLIB-000V20\<bar>non-multiGLIB-000V21\<bar>non-DmultiGLIB-000V22\<bar>simpleGLIB-000V23\<bar>DsimpleGLIB-000V24"
sorry
qed "sorry"

abbreviation(input) GLIB_000V25("finiteGLIB-000V25" 70) where
  "finiteGLIB-000V25 \<equiv> finiteGLIB-000V17"

mtheorem glib_000_def_66:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr finiteGLIB-000V25 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be finiteGLIB-000V25 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V26("looplessGLIB-000V26" 70) where
  "looplessGLIB-000V26 \<equiv> looplessGLIB-000V18"

mtheorem glib_000_def_67:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr looplessGLIB-000V26 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be looplessGLIB-000V26 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V27("trivialGLIB-000V27" 70) where
  "trivialGLIB-000V27 \<equiv> trivialGLIB-000V19"

mtheorem glib_000_def_68:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr trivialGLIB-000V27 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be trivialGLIB-000V27 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V28("non-trivialGLIB-000V28" 70) where
  "non-trivialGLIB-000V28 \<equiv> non-trivialGLIB-000V20"

mtheorem glib_000_def_69:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr non-trivialGLIB-000V28 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be non-trivialGLIB-000V28 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V29("non-multiGLIB-000V29" 70) where
  "non-multiGLIB-000V29 \<equiv> non-multiGLIB-000V21"

mtheorem glib_000_def_70:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr non-multiGLIB-000V29 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be non-multiGLIB-000V29 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V30("non-DmultiGLIB-000V30" 70) where
  "non-DmultiGLIB-000V30 \<equiv> non-DmultiGLIB-000V22"

mtheorem glib_000_def_71:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr non-DmultiGLIB-000V30 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be non-DmultiGLIB-000V30 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V31("simpleGLIB-000V31" 70) where
  "simpleGLIB-000V31 \<equiv> simpleGLIB-000V23"

mtheorem glib_000_def_72:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr simpleGLIB-000V31 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be simpleGLIB-000V31 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V32("DsimpleGLIB-000V32" 70) where
  "DsimpleGLIB-000V32 \<equiv> DsimpleGLIB-000V24"

mtheorem glib_000_def_73:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr DsimpleGLIB-000V32 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be DsimpleGLIB-000V32 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V33("finiteGLIB-000V33" 70) where
  "finiteGLIB-000V33 \<equiv> finiteGLIB-000V17"

mtheorem glib_000_def_74:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr finiteGLIB-000V33 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be finiteGLIB-000V33 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V34("looplessGLIB-000V34" 70) where
  "looplessGLIB-000V34 \<equiv> looplessGLIB-000V18"

mtheorem glib_000_def_75:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr looplessGLIB-000V34 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be looplessGLIB-000V34 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V35("trivialGLIB-000V35" 70) where
  "trivialGLIB-000V35 \<equiv> trivialGLIB-000V19"

mtheorem glib_000_def_76:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr trivialGLIB-000V35 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be trivialGLIB-000V35 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V36("non-trivialGLIB-000V36" 70) where
  "non-trivialGLIB-000V36 \<equiv> non-trivialGLIB-000V20"

mtheorem glib_000_def_77:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr non-trivialGLIB-000V36 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be non-trivialGLIB-000V36 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V37("non-multiGLIB-000V37" 70) where
  "non-multiGLIB-000V37 \<equiv> non-multiGLIB-000V21"

mtheorem glib_000_def_78:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr non-multiGLIB-000V37 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be non-multiGLIB-000V37 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V38("non-DmultiGLIB-000V38" 70) where
  "non-DmultiGLIB-000V38 \<equiv> non-DmultiGLIB-000V22"

mtheorem glib_000_def_79:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr non-DmultiGLIB-000V38 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be non-DmultiGLIB-000V38 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V39("simpleGLIB-000V39" 70) where
  "simpleGLIB-000V39 \<equiv> simpleGLIB-000V23"

mtheorem glib_000_def_80:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr simpleGLIB-000V39 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be simpleGLIB-000V39 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V40("DsimpleGLIB-000V40" 70) where
  "DsimpleGLIB-000V40 \<equiv> DsimpleGLIB-000V24"

mtheorem glib_000_def_81:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr DsimpleGLIB-000V40 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be DsimpleGLIB-000V40 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)"
sorry
qed "sorry"

abbreviation(input) GLIB_000V41("haltingGLIB-000V41" 70) where
  "haltingGLIB-000V41 \<equiv> haltingGLIB-000V16"

mtheorem glib_000_def_82:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr haltingGLIB-000V41 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  ex n be NatNAT-1M1 st GSq .FUNCT-1K1 n =FUNCT-1R1 GSq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be haltingGLIB-000V41 iff ( ex n be NatNAT-1M1 st GSq .FUNCT-1K1 n =FUNCT-1R1 GSq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
qed "sorry"

mtheorem glib_000_cl_45:
"cluster haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>trivialGLIB-000V35\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40 for GraphSeqGLIB-000M11"
proof
(*existence*)
  show " ex it be GraphSeqGLIB-000M11 st it be haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>trivialGLIB-000V35\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40"
sorry
qed "sorry"

mtheorem glib_000_cl_46:
"cluster haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>non-trivialGLIB-000V36\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40 for GraphSeqGLIB-000M11"
proof
(*existence*)
  show " ex it be GraphSeqGLIB-000M11 st it be haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>non-trivialGLIB-000V36\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40"
sorry
qed "sorry"

mtheorem glib_000_cl_47:
  mlet "GF be finiteGLIB-000V25\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is finiteGLIB-000V2"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be finiteGLIB-000V2"
    using glib_000_def_66 sorry
qed "sorry"

mtheorem glib_000_cl_48:
  mlet "GSq be finiteGLIB-000V33\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is finiteGLIB-000V2"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be finiteGLIB-000V2"
    using glib_000_def_74 sorry
qed "sorry"

mtheorem glib_000_cl_49:
  mlet "GF be looplessGLIB-000V26\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is looplessGLIB-000V3"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be looplessGLIB-000V3"
    using glib_000_def_67 sorry
qed "sorry"

mtheorem glib_000_cl_50:
  mlet "GSq be looplessGLIB-000V34\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is looplessGLIB-000V3 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be looplessGLIB-000V3"
    using glib_000_def_75 sorry
qed "sorry"

mtheorem glib_000_cl_51:
  mlet "GF be trivialGLIB-000V27\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is trivialGLIB-000V4"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be trivialGLIB-000V4"
    using glib_000_def_68 sorry
qed "sorry"

mtheorem glib_000_cl_52:
  mlet "GSq be trivialGLIB-000V35\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is trivialGLIB-000V4 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be trivialGLIB-000V4"
    using glib_000_def_76 sorry
qed "sorry"

mtheorem glib_000_cl_53:
  mlet "GF be non-trivialGLIB-000V28\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is  non trivialGLIB-000V4"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be  non trivialGLIB-000V4"
    using glib_000_def_69 sorry
qed "sorry"

mtheorem glib_000_cl_54:
  mlet "GSq be non-trivialGLIB-000V36\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is  non trivialGLIB-000V4 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be  non trivialGLIB-000V4"
    using glib_000_def_77 sorry
qed "sorry"

mtheorem glib_000_cl_55:
  mlet "GF be non-multiGLIB-000V29\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is non-multiGLIB-000V5"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be non-multiGLIB-000V5"
    using glib_000_def_70 sorry
qed "sorry"

mtheorem glib_000_cl_56:
  mlet "GSq be non-multiGLIB-000V37\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is non-multiGLIB-000V5 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be non-multiGLIB-000V5"
    using glib_000_def_78 sorry
qed "sorry"

mtheorem glib_000_cl_57:
  mlet "GF be non-DmultiGLIB-000V30\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is non-DmultiGLIB-000V6"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be non-DmultiGLIB-000V6"
    using glib_000_def_71 sorry
qed "sorry"

mtheorem glib_000_cl_58:
  mlet "GSq be non-DmultiGLIB-000V38\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is non-DmultiGLIB-000V6 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be non-DmultiGLIB-000V6"
    using glib_000_def_79 sorry
qed "sorry"

mtheorem glib_000_cl_59:
  mlet "GF be simpleGLIB-000V31\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is simpleGLIB-000V7"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be simpleGLIB-000V7"
    using glib_000_def_72 sorry
qed "sorry"

mtheorem glib_000_cl_60:
  mlet "GSq be simpleGLIB-000V39\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be simpleGLIB-000V7"
    using glib_000_def_80 sorry
qed "sorry"

mtheorem glib_000_cl_61:
  mlet "GF be DsimpleGLIB-000V32\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is DsimpleGLIB-000V8"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be DsimpleGLIB-000V8"
    using glib_000_def_73 sorry
qed "sorry"

mtheorem glib_000_cl_62:
  mlet "GSq be DsimpleGLIB-000V40\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is DsimpleGLIB-000V8 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be DsimpleGLIB-000V8"
    using glib_000_def_81 sorry
qed "sorry"

mtheorem glib_000_cl_63:
"cluster non-multiGLIB-000V21 also-is non-DmultiGLIB-000V22 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be non-multiGLIB-000V21 implies it be non-DmultiGLIB-000V22"
sorry
qed "sorry"

mtheorem glib_000_cl_64:
"cluster simpleGLIB-000V23 also-is looplessGLIB-000V18\<bar>non-multiGLIB-000V21 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be simpleGLIB-000V23 implies it be looplessGLIB-000V18\<bar>non-multiGLIB-000V21"
sorry
qed "sorry"

mtheorem glib_000_cl_65:
"cluster looplessGLIB-000V18\<bar>non-multiGLIB-000V21 also-is simpleGLIB-000V23 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be looplessGLIB-000V18\<bar>non-multiGLIB-000V21 implies it be simpleGLIB-000V23"
sorry
qed "sorry"

mtheorem glib_000_cl_66:
"cluster looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22 also-is DsimpleGLIB-000V24 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22 implies it be DsimpleGLIB-000V24"
sorry
qed "sorry"

mtheorem glib_000_cl_67:
"cluster DsimpleGLIB-000V24 also-is looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be DsimpleGLIB-000V24 implies it be looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22"
sorry
qed "sorry"

mtheorem glib_000_cl_68:
"cluster trivialGLIB-000V19\<bar>looplessGLIB-000V18 also-is finiteGLIB-000V17 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be trivialGLIB-000V19\<bar>looplessGLIB-000V18 implies it be finiteGLIB-000V17"
sorry
qed "sorry"

mtheorem glib_000_cl_69:
"cluster trivialGLIB-000V19\<bar>non-DmultiGLIB-000V22 also-is finiteGLIB-000V17 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be trivialGLIB-000V19\<bar>non-DmultiGLIB-000V22 implies it be finiteGLIB-000V17"
sorry
qed "sorry"

(*begin*)
reserve GS for "GraphStructGLIB-000M1"
reserve G, G1, G2, G3 for "-GraphGLIB-000M2"
reserve e, x, x1, x2, y, y1, y2, E, V, X, Y for "setHIDDENM2"
reserve n, n1, n2 for "NatNAT-1M1"
reserve v, v1, v2 for "VertexGLIB-000M10-of G"
mtheorem glib_000_th_1:
"((VertexSelectorGLIB-000K1 =XBOOLE-0R4 \<one>\<^sub>M & EdgeSelectorGLIB-000K2 =XBOOLE-0R4 \<two>\<^sub>M) & SourceSelectorGLIB-000K3 =XBOOLE-0R4 \<three>\<^sub>M) & TargetSelectorGLIB-000K4 =XBOOLE-0R4 \<four>\<^sub>M"
   sorry

mtheorem glib_000_th_2:
" for G be -GraphGLIB-000M2 holds -GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
sorry

mtheorem glib_000_th_3:
" for GS be GraphStructGLIB-000M1 holds ((the-Vertices-ofGLIB-000K6 GS =XBOOLE-0R4 GS .FUNCT-1K1 (VertexSelectorGLIB-000K1) & the-Edges-ofGLIB-000K7 GS =XBOOLE-0R4 GS .FUNCT-1K1 (EdgeSelectorGLIB-000K2)) & the-Source-ofGLIB-000K8 GS =XBOOLE-0R4 GS .FUNCT-1K1 (SourceSelectorGLIB-000K3)) & the-Target-ofGLIB-000K9 GS =XBOOLE-0R4 GS .FUNCT-1K1 (TargetSelectorGLIB-000K4)"
   sorry

mtheorem glib_000_th_4:
" for G be -GraphGLIB-000M2 holds ((domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Source-ofGLIB-000K10 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Target-ofGLIB-000K11 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G) & rngRELSET-1K2\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> (the-Source-ofGLIB-000K10 G) c=TARSKIR1 the-Vertices-ofGLIB-000K6 G) & rngRELSET-1K2\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> (the-Target-ofGLIB-000K11 G) c=TARSKIR1 the-Vertices-ofGLIB-000K6 G"
  using funct_2_def_1 sorry

mtheorem glib_000_th_5:
" for GS be GraphStructGLIB-000M1 holds GS be [Graph-like]GLIB-000V1 iff ((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & the-Vertices-ofGLIB-000K6 GS be  non emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)"
  using glib_000_lm_1 sorry

mtheorem glib_000_th_6:
" for V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be setHIDDENM2 holds  for S be FunctionFUNCT-2M1-of(E,V) holds  for T be FunctionFUNCT-2M1-of(E,V) holds ((the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V,E,S,T)) =XBOOLE-0R4 V & the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V,E,S,T)) =XBOOLE-0R4 E) & the-Source-ofGLIB-000K10 (createGraphGLIB-000K12(V,E,S,T)) =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V,E,S,T)),the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V,E,S,T)),E,V)\<^esub> S) & the-Target-ofGLIB-000K11 (createGraphGLIB-000K12(V,E,S,T)) =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V,E,S,T)),the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V,E,S,T)),E,V)\<^esub> T"
  using finseq_4_th_76 sorry

mtheorem glib_000_th_7:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS .setGLIB-000K13(n,x) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 {TARSKIK1 n}"
sorry

mtheorem glib_000_th_8:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds GS .setGLIB-000K13(n,x) .FUNCT-1K1 n =XBOOLE-0R4 x"
sorry

mtheorem glib_000_th_9:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds n1 <>HIDDENR2 n2 implies GS .FUNCT-1K1 n2 =XBOOLE-0R4 GS .setGLIB-000K13(n1,x) .FUNCT-1K1 n2"
sorry

mtheorem glib_000_th_10:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds  not n inTARSKIR2 -GraphSelectorsGLIB-000K5 implies (((the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G .setGLIB-000K13(n,x) & the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G .setGLIB-000K13(n,x)) & the-Source-ofGLIB-000K10 G =XBOOLE-0R4 the-Source-ofGLIB-000K8 G .setGLIB-000K13(n,x)) & the-Target-ofGLIB-000K11 G =XBOOLE-0R4 the-Target-ofGLIB-000K9 G .setGLIB-000K13(n,x)) & G .setGLIB-000K13(n,x) be -GraphGLIB-000M2"
sorry

mtheorem glib_000_th_11:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds ((the-Vertices-ofGLIB-000K6 GS .setGLIB-000K13(VertexSelectorGLIB-000K1,x) =XBOOLE-0R4 x & the-Edges-ofGLIB-000K7 GS .setGLIB-000K13(EdgeSelectorGLIB-000K2,x) =XBOOLE-0R4 x) & the-Source-ofGLIB-000K8 GS .setGLIB-000K13(SourceSelectorGLIB-000K3,x) =XBOOLE-0R4 x) & the-Target-ofGLIB-000K9 GS .setGLIB-000K13(TargetSelectorGLIB-000K4,x) =XBOOLE-0R4 x"
  using glib_000_th_8 sorry

mtheorem glib_000_th_12:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds n1 <>HIDDENR2 n2 implies ((n1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) & n2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y)) & (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n1 =XBOOLE-0R4 x) & (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n2 =XBOOLE-0R4 y"
sorry

mtheorem glib_000_th_13:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) implies x inHIDDENR3 the-Vertices-ofGLIB-000K6 G & y inHIDDENR3 the-Vertices-ofGLIB-000K6 G"
  using funct_2_th_5 sorry

mtheorem glib_000_th_14:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) implies e JoinsGLIB-000R1(y,x,G)"
   sorry

mtheorem glib_000_th_15:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds e JoinsGLIB-000R1(x1,y1,G) & e JoinsGLIB-000R1(x2,y2,G) implies x1 =HIDDENR1 x2 & y1 =HIDDENR1 y2 or x1 =HIDDENR1 y2 & y1 =HIDDENR1 x2"
   sorry

mtheorem glib_000_th_16:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) iff e DJoinsGLIB-000R2(x,y,G) or e DJoinsGLIB-000R2(y,x,G)"
   sorry

mtheorem glib_000_th_17:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) & (x inHIDDENR3 X & y inHIDDENR3 Y or x inHIDDENR3 Y & y inHIDDENR3 X) implies e SJoinsGLIB-000R3(X,Y,G)"
   sorry

mtheorem glib_000_th_18:
" for G be -GraphGLIB-000M2 holds G be looplessGLIB-000V3 iff ( for v be objectHIDDENM1 holds  not ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,v,G)))"
sorry

mtheorem glib_000_th_19:
" for G be looplessGLIB-000V3\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =XBOOLE-0R4 cardCARD-1K1 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
sorry

mtheorem glib_000_th_20:
" for G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be  non emptyXBOOLE-0V1"
sorry

mtheorem glib_000_th_21:
" for G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  ex v1 be VertexGLIB-000M10-of G st  ex v2 be VertexGLIB-000M10-of G st v1 <>HIDDENR2 v2"
sorry

mtheorem glib_000_th_22:
" for G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
sorry

mtheorem glib_000_th_23:
" for G be trivialGLIB-000V4\<bar>looplessGLIB-000V3\<bar>-GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem glib_000_th_24:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1 implies G be simpleGLIB-000V7"
sorry

mtheorem glib_000_th_25:
" for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .order()GLIB-000K15 >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem glib_000_th_26:
" for G be -GraphGLIB-000M2 holds G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M iff G be trivialGLIB-000V4"
   sorry

mtheorem glib_000_th_27:
" for G be -GraphGLIB-000M2 holds G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M iff ( ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
sorry

mtheorem glib_000_th_28:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) iff e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
sorry

mtheorem glib_000_th_29:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds G .edgesIntoGLIB-000K18 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X & G .edgesOutOfGLIB-000K19 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X"
  using xboole_0_def_3 sorry

mtheorem glib_000_th_30:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
sorry

mtheorem glib_000_th_31:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X iff e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
  using glib_000_lm_5 sorry

mtheorem glib_000_th_32:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & e JoinsGLIB-000R1(x,y,G) implies e inHIDDENR3 G .edgesBetweenGLIB-000K21 X"
  using glib_000_lm_5 sorry

mtheorem glib_000_th_33:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X"
sorry

mtheorem glib_000_th_34:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
sorry

mtheorem glib_000_th_35:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)"
sorry

mtheorem glib_000_th_36:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesBetweenGLIB-000K21 Y"
sorry

mtheorem glib_000_th_37:
" for G be -GraphGLIB-000M2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies G .edgesBetweenGLIB-000K22(X1,Y1) c=TARSKIR1 G .edgesBetweenGLIB-000K22(X2,Y2)"
sorry

mtheorem glib_000_th_38:
" for G be -GraphGLIB-000M2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies G .edgesDBetweenGLIB-000K23(X1,Y1) c=TARSKIR1 G .edgesDBetweenGLIB-000K23(X2,Y2)"
sorry

mtheorem glib_000_th_39:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}) & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)"
sorry

mtheorem glib_000_th_40:
" for G be -GraphGLIB-000M2 holds G be SubgraphGLIB-000M3-of G"
  using glib_000_lm_3 sorry

mtheorem glib_000_th_41:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1 iff ((the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2) & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
sorry

mtheorem glib_000_th_42:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds (x inTARSKIR2 the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 implies x inTARSKIR2 the-Vertices-ofGLIB-000K6 G1) & (x inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 implies x inTARSKIR2 the-Edges-ofGLIB-000K7 G1)"
   sorry

mtheorem glib_000_th_43:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for G3 be SubgraphGLIB-000M3-of G2 holds G3 be SubgraphGLIB-000M3-of G1"
sorry

mtheorem glib_000_th_44:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 implies G1 be SubgraphGLIB-000M3-of G2"
sorry

mtheorem glib_000_th_45:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds the-Source-ofGLIB-000K10 G2 =FUNCT-1R1 (the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) & the-Target-ofGLIB-000K11 G2 =FUNCT-1R1 (the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
sorry

mtheorem glib_000_th_46:
" for G be -GraphGLIB-000M2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for E1 be setHIDDENM2 holds  for E2 be setHIDDENM2 holds  for G1 be inducedSubgraphGLIB-000M4-of(G,V1,E1) holds  for G2 be inducedSubgraphGLIB-000M4-of(G,V2,E2) holds ((V2 c=TARSKIR1 V1 & E2 c=TARSKIR1 E1) & V2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G) & E2 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V2 implies G2 be SubgraphGLIB-000M3-of G1"
sorry

mtheorem glib_000_th_47:
" for G1 be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G1 holds  for G2 be removeVertexGLIB-000M6-of(G1,v) holds the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v} & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v})"
sorry

mtheorem glib_000_th_48:
" for G1 be finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G1 holds  for G2 be removeVertexGLIB-000M6-of(G1,v) holds G2 .order()GLIB-000K15 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 G1 .order()GLIB-000K15 & G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 v .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 G1 .size()GLIB-000K17"
sorry

mtheorem glib_000_th_49:
" for G1 be -GraphGLIB-000M2 holds  for V be setHIDDENM2 holds  for G2 be removeVerticesGLIB-000M7-of(G1,V) holds V c<XBOOLE-0R2 the-Vertices-ofGLIB-000K6 G1 implies the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V)"
sorry

mtheorem glib_000_th_50:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for V be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 holds  for G2 be removeVerticesGLIB-000M7-of(G1,V) holds V <>HIDDENR2 the-Vertices-ofGLIB-000K6 G1 implies G2 .order()GLIB-000K15 +NAT-1K1 cardCARD-1K4 V =XBOOLE-0R4 G1 .order()GLIB-000K15 & G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 G1 .edgesInOutGLIB-000K20 V =XBOOLE-0R4 G1 .size()GLIB-000K17"
sorry

mtheorem glib_000_th_51:
" for G1 be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for G2 be removeEdgeGLIB-000M8-of(G1,e) holds the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 {TARSKIK1 e}"
sorry

mtheorem glib_000_th_52:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for G2 be removeEdgeGLIB-000M8-of(G1,e) holds G1 .order()GLIB-000K15 =XBOOLE-0R4 G2 .order()GLIB-000K15 & (e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 implies G2 .size()GLIB-000K17 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 G1 .size()GLIB-000K17)"
sorry

mtheorem glib_000_th_53:
" for G1 be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for G2 be removeEdgesGLIB-000M9-of(G1,E) holds the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 E"
sorry

mtheorem glib_000_th_54:
" for G1 be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for G2 be removeEdgesGLIB-000M9-of(G1,E) holds G1 .order()GLIB-000K14 =XBOOLE-0R4 G2 .order()GLIB-000K14"
  using glib_000_th_53 sorry

mtheorem glib_000_th_55:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for E be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1 holds  for G2 be removeEdgesGLIB-000M9-of(G1,E) holds G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 E =XBOOLE-0R4 G1 .size()GLIB-000K17"
sorry

mtheorem glib_000_th_56:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
  using glib_000_lm_7 sorry

mtheorem glib_000_th_57:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> iff ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G))"
sorry

mtheorem glib_000_th_58:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
  using glib_000_lm_8 sorry

mtheorem glib_000_th_59:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> iff ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G))"
sorry

mtheorem glib_000_th_60:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
   sorry

mtheorem glib_000_th_61:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v)"
sorry

mtheorem glib_000_th_62:
" for G be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds e JoinsGLIB-000R1(v1,x,G) implies e inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
  using glib_000_th_61 sorry

mtheorem glib_000_th_63:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds e JoinsGLIB-000R1(v1,v2,G) implies e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> or e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
sorry

mtheorem glib_000_th_64:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> iff ( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G))"
sorry

mtheorem glib_000_th_65:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e inHIDDENR3 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> & e JoinsGLIB-000R1(x,y,G) implies v =HIDDENR1 x or v =HIDDENR1 y"
sorry

mtheorem glib_000_th_66:
" for G be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds e JoinsGLIB-000R1(v1,v2,G) implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
sorry

mtheorem glib_000_th_67:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> iff e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
sorry

mtheorem glib_000_th_68:
" for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds e JoinsGLIB-000R1(v1,v2,G) implies \<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
sorry

mtheorem glib_000_th_69:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> iff ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G))"
sorry

mtheorem glib_000_th_70:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> iff ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G))"
sorry

mtheorem glib_000_th_71:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub> iff ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G))"
sorry

mtheorem glib_000_th_72:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for e be objectHIDDENM1 holds (((e JoinsGLIB-000R1(x,y,G2) implies e JoinsGLIB-000R1(x,y,G1)) & (e DJoinsGLIB-000R2(x,y,G2) implies e DJoinsGLIB-000R2(x,y,G1))) & (e SJoinsGLIB-000R3(x,y,G2) implies e SJoinsGLIB-000R3(x,y,G1))) & (e DSJoinsGLIB-000R4(x,y,G2) implies e DSJoinsGLIB-000R4(x,y,G1))"
sorry

mtheorem glib_000_th_73:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 implies (((e JoinsGLIB-000R1(x,y,G1) implies e JoinsGLIB-000R1(x,y,G2)) & (e DJoinsGLIB-000R2(x,y,G1) implies e DJoinsGLIB-000R2(x,y,G2))) & (e SJoinsGLIB-000R3(x,y,G1) implies e SJoinsGLIB-000R3(x,y,G2))) & (e DSJoinsGLIB-000R4(x,y,G1) implies e DSJoinsGLIB-000R4(x,y,G2))"
  using glib_000_def_32 sorry

mtheorem glib_000_th_74:
" for G1 be -GraphGLIB-000M2 holds  for G2 be spanningGLIB-000V9\<^bsub>(G1)\<^esub>\<bar>SubgraphGLIB-000M3-of G1 holds  for G3 be spanningGLIB-000V9\<^bsub>(G2)\<^esub>\<bar>SubgraphGLIB-000M3-of G2 holds G3 be spanningGLIB-000V9\<^bsub>(G1)\<^esub>\<bar>SubgraphGLIB-000M3-of G1"
sorry

mtheorem glib_000_th_75:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds G2 .order()GLIB-000K15 <=XXREAL-0R1 G1 .order()GLIB-000K15 & G2 .size()GLIB-000K17 <=XXREAL-0R1 G1 .size()GLIB-000K17"
sorry

mtheorem glib_000_th_76:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for X be setHIDDENM2 holds ((G2 .edgesIntoGLIB-000K18 X c=TARSKIR1 G1 .edgesIntoGLIB-000K18 X & G2 .edgesOutOfGLIB-000K19 X c=TARSKIR1 G1 .edgesOutOfGLIB-000K19 X) & G2 .edgesInOutGLIB-000K20 X c=TARSKIR1 G1 .edgesInOutGLIB-000K20 X) & G2 .edgesBetweenGLIB-000K21 X c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 X"
sorry

mtheorem glib_000_th_77:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds G2 .edgesBetweenGLIB-000K22(X,Y) c=TARSKIR1 G1 .edgesBetweenGLIB-000K22(X,Y) & G2 .edgesDBetweenGLIB-000K23(X,Y) c=TARSKIR1 G1 .edgesDBetweenGLIB-000K23(X,Y)"
sorry

mtheorem glib_000_th_78:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> & v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>) & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
sorry

mtheorem glib_000_th_79:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) & v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)) & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
sorry

mtheorem glib_000_th_80:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds  for e be setHIDDENM2 holds v1 =XBOOLE-0R4 v2 & e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
sorry

mtheorem glib_000_th_81:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .inDegree()GLIB-000K32\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .inDegree()GLIB-000K32\<^bsub>(G1)\<^esub> & v2 .outDegree()GLIB-000K33\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .outDegree()GLIB-000K33\<^bsub>(G1)\<^esub>) & v2 .degree()GLIB-000K35\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G1)\<^esub>"
sorry

mtheorem glib_000_th_82:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> & v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub>) & v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub>"
sorry

mtheorem glib_000_th_83:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub> implies v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>"
sorry

mtheorem glib_000_th_84:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub> implies v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub> or v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>"
sorry

mtheorem glib_000_th_85:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G2 ==GLIB-000R5 G3 implies G1 ==GLIB-000R5 G3"
   sorry

mtheorem glib_000_th_86:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 implies G1 ==GLIB-000R5 G2"
sorry

mtheorem glib_000_th_87:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 iff G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1"
  using glib_000_th_41 sorry

mtheorem glib_000_th_88:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds G1 ==GLIB-000R5 G2 implies (((e JoinsGLIB-000R1(x,y,G1) implies e JoinsGLIB-000R1(x,y,G2)) & (e DJoinsGLIB-000R2(x,y,G1) implies e DJoinsGLIB-000R2(x,y,G2))) & (e SJoinsGLIB-000R3(X,Y,G1) implies e SJoinsGLIB-000R3(X,Y,G2))) & (e DSJoinsGLIB-000R4(X,Y,G1) implies e DSJoinsGLIB-000R4(X,Y,G2))"
   sorry

mtheorem glib_000_th_89:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 implies ((((((G1 be finiteGLIB-000V2 implies G2 be finiteGLIB-000V2) & (G1 be looplessGLIB-000V3 implies G2 be looplessGLIB-000V3)) & (G1 be trivialGLIB-000V4 implies G2 be trivialGLIB-000V4)) & (G1 be non-multiGLIB-000V5 implies G2 be non-multiGLIB-000V5)) & (G1 be non-DmultiGLIB-000V6 implies G2 be non-DmultiGLIB-000V6)) & (G1 be simpleGLIB-000V7 implies G2 be simpleGLIB-000V7)) & (G1 be DsimpleGLIB-000V8 implies G2 be DsimpleGLIB-000V8)"
sorry

mtheorem glib_000_th_90:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds G1 ==GLIB-000R5 G2 implies (((((G1 .order()GLIB-000K14 =XBOOLE-0R4 G2 .order()GLIB-000K14 & G1 .size()GLIB-000K16 =XBOOLE-0R4 G2 .size()GLIB-000K16) & G1 .edgesIntoGLIB-000K18 X =XBOOLE-0R4 G2 .edgesIntoGLIB-000K18 X) & G1 .edgesOutOfGLIB-000K19 X =XBOOLE-0R4 G2 .edgesOutOfGLIB-000K19 X) & G1 .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G2 .edgesInOutGLIB-000K20 X) & G1 .edgesBetweenGLIB-000K21 X =XBOOLE-0R4 G2 .edgesBetweenGLIB-000K21 X) & G1 .edgesDBetweenGLIB-000K23(X,Y) =XBOOLE-0R4 G2 .edgesDBetweenGLIB-000K23(X,Y)"
sorry

mtheorem glib_000_th_91:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G3 be SubgraphGLIB-000M3-of G1 implies G3 be SubgraphGLIB-000M3-of G2"
sorry

mtheorem glib_000_th_92:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G1 be SubgraphGLIB-000M3-of G3 implies G2 be SubgraphGLIB-000M3-of G3"
sorry

mtheorem glib_000_th_93:
" for G be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for V be setHIDDENM2 holds  for G1 be inducedSubgraphGLIB-000M4-of(G,V,E) holds  for G2 be inducedSubgraphGLIB-000M4-of(G,V,E) holds G1 ==GLIB-000R5 G2"
sorry

mtheorem glib_000_th_94:
" for G1 be -GraphGLIB-000M2 holds  for G2 be inducedSubgraphGLIB-000M5-of(G1,the-Vertices-ofGLIB-000K6 G1) holds G1 ==GLIB-000R5 G2"
sorry

mtheorem glib_000_th_95:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for V be setHIDDENM2 holds  for E be setHIDDENM2 holds  for G3 be inducedSubgraphGLIB-000M4-of(G1,V,E) holds G1 ==GLIB-000R5 G2 implies G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
sorry

mtheorem glib_000_th_96:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2 implies ((((((((v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> & v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>) & v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>) & v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e) & v1 .inDegree()GLIB-000K30\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inDegree()GLIB-000K30\<^bsub>(G2)\<^esub>) & v1 .outDegree()GLIB-000K31\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outDegree()GLIB-000K31\<^bsub>(G2)\<^esub>) & v1 .degree()GLIB-000K34\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .degree()GLIB-000K34\<^bsub>(G2)\<^esub>) & v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub>) & v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub>) & v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub>"
sorry

mtheorem glib_000_th_97:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2 implies (v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub> implies v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>) & (v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub> implies v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub>)"
sorry

mtheorem glib_000_th_98:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds G1 c<GLIB-000R8 G2 implies the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 or the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
sorry

mtheorem glib_000_th_99:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds G1 c<GLIB-000R8 G2 implies ( ex v be objectHIDDENM1 st v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1) or ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 &  not e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1)"
sorry

end
