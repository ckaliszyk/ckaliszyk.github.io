theory pre_ff
  imports power finseq_4 recdef_1
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem pre_ff_reduce_1:
  mlet "n be NatNAT-1M1", "k be NatNAT-1M1"
"reduce InSUBSET-1K10([TARSKIK4 n,k ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]) to [TARSKIK4 n,k ]"
proof
(*reducibility*)
  show "InSUBSET-1K10([TARSKIK4 n,k ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]) =HIDDENR1 [TARSKIK4 n,k ]"
sorry
qed "sorry"

mdef pre_ff_def_1 ("FibPRE-FFK1  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func FibPRE-FFK1 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it.  ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])"
proof-
  (*existence*)
    show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])"
sorry
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it1 =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])) & ( ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it2 =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem pre_ff_th_1:
"(FibPRE-FFK1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & FibPRE-FFK1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds FibPRE-FFK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FibPRE-FFK1 n +NAT-1K1 FibPRE-FFK1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem pre_ff_th_2:
" for i be IntegerINT-1M1 holds i divINT-1K5 \<one>\<^sub>M =HIDDENR1 i"
sorry

mtheorem pre_ff_th_3:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds j >XXREAL-0R4 0NUMBERSK6 & i divINT-1K5 j =HIDDENR1 0NUMBERSK6 implies i <XXREAL-0R3 j"
sorry

mtheorem pre_ff_th_4:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 i & i <XXREAL-0R3 j implies i divINT-1K5 j =HIDDENR1 0NUMBERSK6"
sorry

mtheorem pre_ff_th_5:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  for k be IntegerINT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 implies (i divINT-1K5 j)divINT-1K5 k =HIDDENR1 i divINT-1K5 j *XCMPLX-0K3 k"
sorry

mtheorem pre_ff_th_6:
" for i be IntegerINT-1M1 holds i modINT-1K6 \<two>\<^sub>M =HIDDENR1 0NUMBERSK6 or i modINT-1K6 \<two>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem pre_ff_th_7:
" for i be IntegerINT-1M1 holds i be ElementSUBSET-1M1-of NATNUMBERSK1 implies i divINT-1K5 \<two>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry

mtheorem pre_ff_th_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c >=XXREAL-0R2 \<one>\<^sub>M implies c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
sorry

mtheorem pre_ff_th_9:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r >=XXREAL-0R2 s implies [\\INT-1K2 r/] >=XXREAL-0R2 [\\INT-1K2 s/]"
sorry

mtheorem pre_ff_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) & c >=XXREAL-0R2 b implies logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(a,b)"
sorry

mtheorem pre_ff_th_11:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M <>HIDDENR2 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
sorry

mtheorem pre_ff_th_12:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
sorry

mtheorem pre_ff_th_13:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
sorry

mtheorem pre_ff_th_14:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n)/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
sorry

mlemma pre_ff_lm_1:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  ex y be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 st ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies y =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies y =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
sorry

mlemma pre_ff_lm_2:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  for y1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  for y2 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds (( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y1 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y1 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))) & (( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y2 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y2 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))) implies y1 =FINSEQ-1R1 y2"
sorry

mdef pre_ff_def_2 ("FuscPRE-FFK2  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func FuscPRE-FFK2 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6 if n =XBOOLE-0R4 0NUMBERSK6 otherwise \<lambda>it.  ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))"
proof-
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds  True "
       sorry
  (*existence*)
    show "(n =XBOOLE-0R4 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it =XBOOLE-0R4 0NUMBERSK6)) & ( not n =XBOOLE-0R4 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))))"
sorry
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n =XBOOLE-0R4 0NUMBERSK6 implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not n =XBOOLE-0R4 0NUMBERSK6 implies (( ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it1 =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))) & ( ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it2 =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))) implies it1 =HIDDENR1 it2))"
sorry
qed "sorry"

mtheorem pre_ff_th_15:
"(FuscPRE-FFK2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & FuscPRE-FFK2 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =XBOOLE-0R4 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem pre_ff_th_16:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n"
sorry

mtheorem pre_ff_th_17:
" for n be NatNAT-1M1 holds n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem pre_ff_th_18:
" for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds B =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (0NUMBERSK6)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 \<one>\<^sub>M)"
  using pre_ff_th_15 sorry

mtheorem pre_ff_th_19:
" for n be NatNAT-1M1 holds  for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds  for N be NatNAT-1M1 holds FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)) implies FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 (B +XCMPLX-0K2 A)*XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem pre_ff_th_20:
" for n be NatNAT-1M1 holds  for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds  for N be NatNAT-1M1 holds FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) implies FuscPRE-FFK2 N =XBOOLE-0R4 (A +XCMPLX-0K2 B)*XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

end
