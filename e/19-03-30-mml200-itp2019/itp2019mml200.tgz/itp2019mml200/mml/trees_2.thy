theory trees_2
  imports real_1 trees_1 orders_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, a, b, c, X, X1, X2, Y, Z for "setHIDDENM2"
reserve W, W1, W2 for "TreeTREES-1M1"
reserve w, w9 for "ElementTREES-1M2-of W"
reserve f for "FunctionFUNCT-1M1"
reserve D, D9 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve i, k, k1, k2, l, m, n for "NatNAT-1M1"
reserve v, v1, v2 for "FinSequenceFINSEQ-1M1"
reserve p, q, r, r1, r2 for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mtheorem trees_2_th_1:
" for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds v1 is-a-prefix-ofTREES-1R2 v & v2 is-a-prefix-ofTREES-1R2 v implies (v1,v2)are-c=-comparableXBOOLE-0R3"
sorry

mtheorem trees_2_th_2:
" for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds v1 is-a-proper-prefix-ofTREES-1R3 v & v2 is-a-prefix-ofTREES-1R2 v implies (v1,v2)are-c=-comparableXBOOLE-0R3"
  using trees_2_th_1 sorry

mtheorem trees_2_th_3:
" for k be NatNAT-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 v1 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies ( ex v2 be FinSequenceFINSEQ-1M1 st  ex x be setHIDDENM2 st v1 =FINSEQ-1R1 v2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) & lenFINSEQ-1K4 v2 =XBOOLE-0R4 k)"
sorry

mtheorem trees_2_th_4:
" for x be setHIDDENM2 holds  for v be FinSequenceFINSEQ-1M1 holds ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
sorry

theorem trees_2_sch_1:
  fixes Tf0 Pp1 
  assumes
[ty]: "Tf0 be TreeTREES-1M1" and
   A1: "Pp1({}XBOOLE-0K1)" and
   A2: " for t be ElementTREES-1M2-of Tf0 holds  for n be NatNAT-1M1 holds Pp1(t) & t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Tf0 implies Pp1(t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
  shows " for t be ElementTREES-1M2-of Tf0 holds Pp1(t)"
sorry

mtheorem trees_2_th_5:
" for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2) implies W1 =XBOOLE-0R4 W2"
sorry

abbreviation(input) TREES_2R1(" _ =TREES-2R1  _ " [50,50]50) where
  "W1 =TREES-2R1 W2 \<equiv> W1 =HIDDENR1 W2"

mtheorem trees_2_def_1:
  mlet "W1 be TreeTREES-1M1", "W2 be TreeTREES-1M1"
"redefine pred W1 =TREES-2R1 W2 means
   for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2"
proof
(*compatibility*)
  show "W1 =TREES-2R1 W2 iff ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2)"
    using trees_2_th_5 sorry
qed "sorry"

mtheorem trees_2_th_6:
" for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W implies W =TREES-2R1 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
sorry

mtheorem trees_2_th_7:
" for W be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 W & q inTARSKIR2 W) &  not p is-a-prefix-ofTREES-1R2 q implies q inTARSKIR2 W with-replacementTREES-1K5(p,W1)"
sorry

mtheorem trees_2_th_8:
" for W be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 W & q inTARSKIR2 W) &  not (p,q)are-c=-comparableXBOOLE-0R3 implies (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2) =TREES-2R1 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
sorry

mdef trees_2_def_2 ("finite-orderTREES-2V1" 70 ) where
"attr finite-orderTREES-2V1 for TreeTREES-1M1 means
  (\<lambda>IT.  ex n be NatNAT-1M1 st  for t be ElementTREES-1M2-of IT holds  not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 IT)"..

mtheorem trees_2_cl_1:
"cluster finite-orderTREES-2V1 for TreeTREES-1M1"
proof
(*existence*)
  show " ex it be TreeTREES-1M1 st it be finite-orderTREES-2V1"
sorry
qed "sorry"

mdef trees_2_def_3 ("ChainTREES-2M1-of  _ " [70]70 ) where
  mlet "W be TreeTREES-1M1"
"mode ChainTREES-2M1-of W \<rightarrow> SubsetSUBSET-1M2-of W means
  (\<lambda>it.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it & q inTARSKIR2 it implies (p,q)are-c=-comparableXBOOLE-0R3)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of W st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it & q inTARSKIR2 it implies (p,q)are-c=-comparableXBOOLE-0R3"
sorry
qed "sorry"

mdef trees_2_def_4 ("LevelTREES-2M2-of  _ " [70]70 ) where
  mlet "W be TreeTREES-1M1"
"mode LevelTREES-2M2-of W \<rightarrow> SubsetSUBSET-1M2-of W means
  (\<lambda>it.  ex n be NatNAT-1M1 st it =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n })"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of W st  ex n be NatNAT-1M1 st it =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
sorry
qed "sorry"

mdef trees_2_def_5 ("succTREES-2K1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "W be TreeTREES-1M1", "w be ElementTREES-1M2-of W"
"func succTREES-2K1\<^bsub>(W)\<^esub> w \<rightarrow> SubsetSUBSET-1M2-of W equals
  {w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W }"
proof-
  (*coherence*)
    show "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } be SubsetSUBSET-1M2-of W"
sorry
qed "sorry"

mtheorem trees_2_th_9:
" for W be TreeTREES-1M1 holds  for L be LevelTREES-2M2-of W holds L be AntiChain-of-PrefixesTREES-1M6-of W"
sorry

mtheorem trees_2_th_10:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds succTREES-2K1\<^bsub>(W)\<^esub> w be AntiChain-of-PrefixesTREES-1M6-of W"
sorry

mtheorem trees_2_th_11:
" for W be TreeTREES-1M1 holds  for A be AntiChain-of-PrefixesTREES-1M6-of W holds  for C be ChainTREES-2M1-of W holds  ex w be ElementTREES-1M2-of W st A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w}"
sorry

mdef trees_2_def_6 (" _ -levelTREES-2K2  _ " [164,164]164 ) where
  mlet "W be TreeTREES-1M1", "n be NatNAT-1M1"
"func W -levelTREES-2K2 n \<rightarrow> LevelTREES-2M2-of W equals
  {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
proof-
  (*coherence*)
    show "{w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n } be LevelTREES-2M2-of W"
sorry
qed "sorry"

mtheorem trees_2_th_12:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds  for n be NatNAT-1M1 holds w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w iff w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W"
   sorry

mtheorem trees_2_th_13:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds w =FINSEQ-1R1 {}XBOOLE-0K1 implies W -levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w"
sorry

mtheorem trees_2_th_14:
" for W be TreeTREES-1M1 holds W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
sorry

mtheorem trees_2_th_15:
" for W be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
sorry

mtheorem trees_2_th_16:
" for W be TreeTREES-1M1 holds  for L be LevelTREES-2M2-of W holds  ex n be NatNAT-1M1 st L =XBOOLE-0R4 W -levelTREES-2K2 n"
sorry

theorem trees_2_sch_2:
  fixes Af0 Xf0 Ff1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "cardCARD-1K1 ({Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }) c=ORDINAL1R1 cardCARD-1K1 Xf0"
sorry

theorem trees_2_sch_3:
  fixes Af0 Xf0 Yf0 Ff1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: "Yf0 =XBOOLE-0R4 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
  shows "cardCARD-1K4 Yf0 <=XXREAL-0R1 cardCARD-1K4 Xf0"
sorry

mtheorem trees_2_th_17:
" for W be TreeTREES-1M1 holds W be finite-orderTREES-2V1 implies ( ex n be NatNAT-1M1 st  for w be ElementTREES-1M2-of W holds  ex B be finiteFINSET-1V1\<bar>setHIDDENM2 st B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 B <=XXREAL-0R1 n)"
sorry

mtheorem trees_2_th_18:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds W be finite-orderTREES-2V1 implies succTREES-2K1\<^bsub>(W)\<^esub> w be finiteFINSET-1V1"
sorry

mtheorem trees_2_cl_2:
  mlet "W be finite-orderTREES-2V1\<bar>TreeTREES-1M1", "w be ElementTREES-1M2-of W"
"cluster succTREES-2K1\<^bsub>(W)\<^esub> w as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "succTREES-2K1\<^bsub>(W)\<^esub> w be finiteFINSET-1V1"
    using trees_2_th_18 sorry
qed "sorry"

mtheorem trees_2_th_19:
" for W be TreeTREES-1M1 holds {}XBOOLE-0K1 be ChainTREES-2M1-of W"
sorry

mtheorem trees_2_th_20:
" for W be TreeTREES-1M1 holds {TARSKIK1 {}XBOOLE-0K1 } be ChainTREES-2M1-of W"
sorry

mtheorem trees_2_cl_3:
  mlet "W be TreeTREES-1M1"
"cluster  non emptyXBOOLE-0V1 for ChainTREES-2M1-of W"
proof
(*existence*)
  show " ex it be ChainTREES-2M1-of W st it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef trees_2_def_7 ("Branch-likeTREES-2V2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "W be TreeTREES-1M1"
"attr Branch-likeTREES-2V2\<^bsub>(W)\<^esub> for ChainTREES-2M1-of W means
  (\<lambda>IT. ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 IT implies ProperPrefixesTREES-1K1 p c=TARSKIR1 IT) &  not ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 W & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 IT implies q is-a-proper-prefix-ofTREES-1R3 p)))"..

mtheorem trees_2_cl_4:
  mlet "W be TreeTREES-1M1"
"cluster Branch-likeTREES-2V2\<^bsub>(W)\<^esub> for ChainTREES-2M1-of W"
proof
(*existence*)
  show " ex it be ChainTREES-2M1-of W st it be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>"
sorry
qed "sorry"

syntax TREES_2M3 :: " Set \<Rightarrow> Ty" ("BranchTREES-2M3-of  _ " [70]70)
translations "BranchTREES-2M3-of W" \<rightharpoonup> "Branch-likeTREES-2V2\<^bsub>(W)\<^esub>\<bar>ChainTREES-2M1-of W"

mtheorem trees_2_cl_5:
  mlet "W be TreeTREES-1M1"
"cluster Branch-likeTREES-2V2\<^bsub>(W)\<^esub> also-is  non emptyXBOOLE-0V1 for ChainTREES-2M1-of W"
proof
(*coherence*)
  show " for it be ChainTREES-2M1-of W holds it be Branch-likeTREES-2V2\<^bsub>(W)\<^esub> implies it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

reserve C for "ChainTREES-2M1-of W"
reserve B for "BranchTREES-2M3-of W"
mtheorem trees_2_th_21:
" for W be TreeTREES-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for C be ChainTREES-2M1-of W holds v1 inTARSKIR2 C & v2 inTARSKIR2 C implies v1 inTARSKIR2 ProperPrefixesTREES-1K1 v2 or v2 is-a-prefix-ofTREES-1R2 v1"
sorry

mtheorem trees_2_th_22:
" for W be TreeTREES-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for C be ChainTREES-2M1-of W holds (v1 inTARSKIR2 C & v2 inTARSKIR2 C) & v is-a-prefix-ofTREES-1R2 v2 implies v1 inTARSKIR2 ProperPrefixesTREES-1K1 v or v is-a-prefix-ofTREES-1R2 v1"
sorry

mtheorem trees_2_cl_6:
  mlet "W be TreeTREES-1M1"
"cluster finiteFINSET-1V1 for ChainTREES-2M1-of W"
proof
(*existence*)
  show " ex it be ChainTREES-2M1-of W st it be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem trees_2_th_23:
" for W be TreeTREES-1M1 holds  for n be NatNAT-1M1 holds  for C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of W holds cardCARD-1K4 C >XXREAL-0R4 n implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 n)"
sorry

mtheorem trees_2_th_24:
" for W be TreeTREES-1M1 holds  for C be ChainTREES-2M1-of W holds {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p } be ChainTREES-2M1-of W"
sorry

mtheorem trees_2_th_25:
" for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for B be BranchTREES-2M3-of W holds p is-a-prefix-ofTREES-1R2 q & q inTARSKIR2 B implies p inTARSKIR2 B"
sorry

mtheorem trees_2_th_26:
" for W be TreeTREES-1M1 holds  for B be BranchTREES-2M3-of W holds {}XBOOLE-0K1 inTARSKIR2 B"
sorry

mtheorem trees_2_th_27:
" for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for C be ChainTREES-2M1-of W holds (p inTARSKIR2 C & q inTARSKIR2 C) & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q implies p is-a-prefix-ofTREES-1R2 q"
sorry

mtheorem trees_2_th_28:
" for W be TreeTREES-1M1 holds  for C be ChainTREES-2M1-of W holds  ex B be BranchTREES-2M3-of W st C c=TARSKIR1 B"
sorry

theorem trees_2_sch_4:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex n be NatNAT-1M1 st Pp2(x,n))"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex n be NatNAT-1M1 st (f .FUNCT-1K1 x =XBOOLE-0R4 n & Pp2(x,n)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies n <=XXREAL-0R1 m)))"
sorry

mlemma trees_2_lm_1:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds k inTARSKIR2 X implies k <=XXREAL-0R1 n)"
sorry

theorem trees_2_sch_5:
  fixes Xf0 af0 Qp1 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "af0 be objectHIDDENM1" and
   A1: "af0 inHIDDENR3 Xf0 & Qp1(af0)" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Qp1(x) implies ( ex y be objectHIDDENM1 st (y inHIDDENR3 Xf0 & Pp2(x,y)) & Qp1(y))"
  shows " ex f be FunctionFUNCT-1M1 st ((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & rngFUNCT-1K2 f c=TARSKIR1 Xf0) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 af0) & ( for k be NatNAT-1M1 holds Pp2(f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Qp1(f .FUNCT-1K1 k))"
sorry

mtheorem trees_2_th_29:
" for T be TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds  ex C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T st cardCARD-1K4 C =XBOOLE-0R4 n) & ( for t be ElementTREES-1M2-of T holds succTREES-2K1\<^bsub>(T)\<^esub> t be finiteFINSET-1V1) implies ( ex B be ChainTREES-2M1-of T st  not B be finiteFINSET-1V1)"
sorry

(*\$N Koenig Lemma*)
mtheorem trees_2_th_30:
" for T be finite-orderTREES-2V1\<bar>TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds  ex C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T st cardCARD-1K4 C =XBOOLE-0R4 n) implies ( ex B be ChainTREES-2M1-of T st  not B be finiteFINSET-1V1)"
sorry

mdef trees_2_def_8 ("DecoratedTree-likeTREES-2V3" 70 ) where
"attr DecoratedTree-likeTREES-2V3 for RelationRELAT-1M1 means
  (\<lambda>IT. domRELAT-1K1 IT be TreeTREES-1M1)"..

mtheorem trees_2_cl_7:
"cluster DecoratedTree-likeTREES-2V3 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be DecoratedTree-likeTREES-2V3"
sorry
qed "sorry"

syntax TREES_2M4 :: "Ty" ("DecoratedTreeTREES-2M4" 70)
translations "DecoratedTreeTREES-2M4" \<rightharpoonup> "DecoratedTree-likeTREES-2V3\<bar>FunctionFUNCT-1M1"

reserve T, T1, T2 for "DecoratedTreeTREES-2M4"
mtheorem trees_2_cl_8:
  mlet "T be DecoratedTreeTREES-2M4"
"cluster domRELAT-1K1 T as-term-is  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
proof
(*coherence*)
  show "domRELAT-1K1 T be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
    using trees_2_def_8 sorry
qed "sorry"

mtheorem trees_2_cl_9:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster DecoratedTree-likeTREES-2V3\<bar>D -valuedRELAT-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be DecoratedTree-likeTREES-2V3\<bar>D -valuedRELAT-1V5"
sorry
qed "sorry"

syntax TREES_2M5 :: " Set \<Rightarrow> Ty" ("DecoratedTreeTREES-2M5-of  _ " [70]70)
translations "DecoratedTreeTREES-2M5-of D" \<rightharpoonup> "D -valuedRELAT-1V5\<bar>DecoratedTreeTREES-2M4"

syntax TREES_2K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .TREES-2K3\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200)
translations "T .TREES-2K3\<^bsub>(D)\<^esub> t" \<rightharpoonup> "T .FUNCT-1K1 t"

mtheorem trees_2_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "t be ElementTREES-1M2-of domRELAT-1K1 T"
"cluster T .FUNCT-1K1 t as-term-is ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show "T .FUNCT-1K1 t be ElementSUBSET-1M1-of D"
sorry
qed "sorry"

mtheorem trees_2_th_31:
" for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p) implies T1 =FUNCT-1R1 T2"
sorry

theorem trees_2_sch_6:
  fixes Tf0 Pp2 
  assumes
[ty]: "Tf0 be TreeTREES-1M1" and
   A1: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Tf0 implies ( ex x be setHIDDENM2 st Pp2(p,x))"
  shows " ex T be DecoratedTreeTREES-2M4 st domRELAT-1K1 T =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Tf0 implies Pp2(p,T .FUNCT-1K1 p))"
sorry

theorem trees_2_sch_7:
  fixes Tf0 ff1 
  assumes
[ty]: "Tf0 be TreeTREES-1M1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> ff1(x1) be setHIDDENM2"
  shows " ex T be DecoratedTreeTREES-2M4 st domRELAT-1K1 T =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Tf0 implies T .FUNCT-1K1 p =XBOOLE-0R4 ff1(p))"
sorry

mdef trees_2_def_9 ("LeavesTREES-2K4  _ " [164]164 ) where
  mlet "T be DecoratedTreeTREES-2M4"
"func LeavesTREES-2K4 T \<rightarrow> setHIDDENM2 equals
  T .:FUNCT-1K5 (LeavesTREES-1K3 domRELAT-1K1 T)"
proof-
  (*coherence*)
    show "T .:FUNCT-1K5 (LeavesTREES-1K3 domRELAT-1K1 T) be setHIDDENM2"
       sorry
qed "sorry"

mdef trees_2_def_10 (" _  |TREES-2K5  _ " [200,200]200 ) where
  mlet "T be DecoratedTreeTREES-2M4", "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
"func T  |TREES-2K5 p \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))"
proof-
  (*existence*)
    show " ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))"
sorry
  (*uniqueness*)
    show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) & (domRELAT-1K1 it2 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_2_th_32:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies rngFUNCT-1K2 (T  |TREES-2K5 p) c=TARSKIR1 rngFUNCT-1K2 T"
sorry

syntax TREES_2K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("LeavesTREES-2K6\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "LeavesTREES-2K6\<^bsub>(D)\<^esub> T" \<rightharpoonup> "LeavesTREES-2K4 T"

mtheorem trees_2_add_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D"
"cluster LeavesTREES-2K4 T as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "LeavesTREES-2K4 T be SubsetSUBSET-1M2-of D"
sorry
qed "sorry"

mtheorem trees_2_cl_10:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "p be ElementTREES-1M2-of domRELAT-1K1 T"
"cluster T  |TREES-2K5 p as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "T  |TREES-2K5 p be D -valuedRELAT-1V5"
sorry
qed "sorry"

mdef trees_2_def_11 (" _ with-replacementTREES-2K7'( _ , _ ')" [164,0,0]164 ) where
  mlet "T be DecoratedTreeTREES-2M4", "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "T1 be DecoratedTreeTREES-2M4"
"assume p inTARSKIR2 domRELAT-1K1 T func T with-replacementTREES-2K7(p,T1) \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  (*existence*)
    show "p inTARSKIR2 domRELAT-1K1 T implies ( ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
sorry
  (*uniqueness*)
    show "p inTARSKIR2 domRELAT-1K1 T implies ( for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) & (domRELAT-1K1 it2 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem trees_2_cl_11:
  mlet "W be TreeTREES-1M1", "x be setHIDDENM2"
"cluster W -->FUNCOP-1K7 x as-term-is DecoratedTree-likeTREES-2V3"
proof
(*coherence*)
  show "W -->FUNCOP-1K7 x be DecoratedTree-likeTREES-2V3"
    using funcop_1_th_13 sorry
qed "sorry"

mtheorem trees_2_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D implies x be TreeTREES-1M1) implies unionTARSKIK3 D be TreeTREES-1M1"
sorry

mtheorem trees_2_th_34:
" for X be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FunctionFUNCT-1M1) & X be c=-linearORDINAL1V6 implies unionTARSKIK3 X be Relation-likeRELAT-1V1\<bar>Function-likeFUNCT-1V1"
sorry

mtheorem trees_2_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D implies x be DecoratedTreeTREES-2M4) & D be c=-linearORDINAL1V6 implies unionTARSKIK3 D be DecoratedTreeTREES-2M4"
sorry

mtheorem trees_2_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D9 implies x be DecoratedTreeTREES-2M5-of D) & D9 be c=-linearORDINAL1V6 implies unionTARSKIK3 D9 be DecoratedTreeTREES-2M5-of D"
sorry

theorem trees_2_sch_8:
  fixes Df0 df0 Ff1 Sf0 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "df0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty]: "Sf0 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Df0,NATNUMBERSK1 :],Df0)" and
   A1: " for d be ElementSUBSET-1M1-of Df0 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <=XXREAL-0R1 k2 & k2 inTARSKIR2 Ff1(d) implies k1 inTARSKIR2 Ff1(d)"
  shows " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
sorry

theorem trees_2_sch_9:
  fixes Df0 df0 Ff1 Sf0 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "df0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be NatNAT-1M1" and
  [ty]: "Sf0 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Df0,NATNUMBERSK1 :],Df0)"
  shows " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
sorry

(*begin*)
mtheorem trees_2_cl_12:
  mlet "Tr be finiteFINSET-1V1\<bar>TreeTREES-1M1", "v be ElementTREES-1M2-of Tr"
"cluster succTREES-2K1\<^bsub>(Tr)\<^esub> v as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "succTREES-2K1\<^bsub>(Tr)\<^esub> v be finiteFINSET-1V1"
     sorry
qed "sorry"

mdef trees_2_def_12 ("branchdegTREES-2K8\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "Tr be finiteFINSET-1V1\<bar>TreeTREES-1M1", "v be ElementTREES-1M2-of Tr"
"func branchdegTREES-2K8\<^bsub>(Tr)\<^esub> v \<rightarrow> setHIDDENM2 equals
  cardCARD-1K4 (succTREES-2K1\<^bsub>(Tr)\<^esub> v)"
proof-
  (*coherence*)
    show "cardCARD-1K4 (succTREES-2K1\<^bsub>(Tr)\<^esub> v) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem trees_2_cl_13:
"cluster finiteFINSET-1V1 for DecoratedTreeTREES-2M4"
proof
(*existence*)
  show " ex it be DecoratedTreeTREES-2M4 st it be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem trees_2_cl_14:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster finiteFINSET-1V1 for DecoratedTreeTREES-2M5-of D"
proof
(*existence*)
  show " ex it be DecoratedTreeTREES-2M5-of D st it be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem trees_2_cl_15:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for RelationRELSET-1M1-of(a,b)"
proof
(*existence*)
  show " ex it be RelationRELSET-1M1-of(a,b) st it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

reserve w for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mtheorem trees_2_th_37:
" for Z1 be TreeTREES-1M1 holds  for Z2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Z1 implies ( for v be ElementTREES-1M2-of Z1 with-replacementTREES-1K5(p,Z2) holds  for w be ElementTREES-1M2-of Z2 holds v =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> w implies (succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> v,succTREES-2K1\<^bsub>(Z2)\<^esub> w)are-equipotentTARSKIR3)"
sorry

theorem trees_2_sch_10:
  fixes Df0 df0 Sf0 Qp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "df0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Sf0 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Df0,NATNUMBERSK1 :],Df0)" and
   A1: " for d be ElementSUBSET-1M1-of Df0 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <=XXREAL-0R1 k2 & Qp2(k2,d) implies Qp2(k1,d)"
  shows " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
sorry

mtheorem trees_2_th_38:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds T1 -levelTREES-2K2 n =XBOOLE-0R4 T2 -levelTREES-2K2 n) implies T1 =TREES-2R1 T2"
sorry

mtheorem trees_2_th_39:
" for n be NatNAT-1M1 holds (TrivialInfiniteTreeTREES-1K8)-levelTREES-2K2 n =XBOOLE-0R4 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
sorry

mtheorem trees_2_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for B be c=-linearORDINAL1V6\<bar>SubsetSUBSET-1M2-of PFuncsPARTFUN1K4(X,Y) holds unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
sorry

end
