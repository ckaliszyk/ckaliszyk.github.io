theory comptrig
  imports fcont_2 sin_cos2 comseq_3 binarith abian
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "RealXREAL-0M1"
theorem comptrig_sch_1:
  fixes Pp1 
  assumes
    A1: " ex k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st Pp1(k)" and
   A2: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds k <>HIDDENR2 \<one>\<^sub>M & Pp1(k) implies ( ex n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st n <XXREAL-0R3 k & Pp1(n))"
  shows "Pp1(\<one>\<^sub>M)"
sorry

mtheorem comptrig_th_1:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
sorry

mtheorem comptrig_th_2:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
sorry

mtheorem comptrig_th_3:
" for z be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
sorry

mtheorem comptrig_th_4:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds x >=XXREAL-0R2 0NUMBERSK6 & n <>HIDDENR2 0NUMBERSK6 implies n -rootPOWERK1 x  |^NEWTONK1 n =COMPLEX1R1 x"
sorry

mtheorem comptrig_cl_1:
"cluster PISIN-COSK29 as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "PISIN-COSK29 be  non negativeXXREAL-0V3"
sorry
qed "sorry"

(*begin*)
mlemma
"PISIN-COSK29 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
  using sin_cos_def_28 sorry

mlemma comptrig_lm_1:
"0NUMBERSK6 <XXREAL-0R3 PISIN-COSK29"
  using xxreal_1_th_4 sorry

mlemma comptrig_lm_2:
"0NUMBERSK6 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using xreal_1_th_6 sorry

mlemma comptrig_lm_3:
"0NUMBERSK6 +XCMPLX-0K2 PISIN-COSK29 <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29"
  using comptrig_lm_1 xreal_1_th_6 sorry

mlemma comptrig_lm_4:
"0NUMBERSK6 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using comptrig_lm_1 xreal_1_th_6 sorry

mlemma comptrig_lm_5:
"(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using comptrig_lm_2 xreal_1_th_6 sorry

mlemma
"(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
   sorry

mlemma comptrig_lm_6:
"(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  using comptrig_lm_5 xreal_1_th_6 sorry

mlemma comptrig_lm_7:
"0NUMBERSK6 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  using comptrig_lm_1 sorry

mtheorem comptrig_th_5:
"(((((((((0NUMBERSK6 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M & (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29) & 0NUMBERSK6 <XXREAL-0R3 PISIN-COSK29) & -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) & PISIN-COSK29 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) & -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 0NUMBERSK6) & 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & PISIN-COSK29 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) & (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & 0NUMBERSK6 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  using comptrig_lm_2 comptrig_lm_3 comptrig_lm_4 xreal_1_th_6 sorry

mtheorem comptrig_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,c .[ implies (x inHIDDENR3 ].RCOMP-1K2 a,b .[ or x =COMPLEX1R1 b) or x inHIDDENR3 ].RCOMP-1K2 b,c .["
sorry

mtheorem comptrig_th_7:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_8:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .] implies (sinSIN-COSK17).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem comptrig_th_9:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem comptrig_th_10:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .] implies (sinSIN-COSK17).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_11:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_12:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .] implies (cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem comptrig_th_13:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem comptrig_th_14:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .] implies (cosSIN-COSK19).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_15:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_16:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .] implies (cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem comptrig_th_17:
" for x be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6 or x =COMPLEX1R1 PISIN-COSK29"
sorry

mtheorem comptrig_th_18:
" for x be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & cosSIN-COSK20 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
sorry

mtheorem comptrig_th_19:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be increasingRFUNCT-2V1"
sorry

mtheorem comptrig_th_20:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be decreasingRFUNCT-2V2"
sorry

mtheorem comptrig_th_21:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) be decreasingRFUNCT-2V2"
sorry

mtheorem comptrig_th_22:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingRFUNCT-2V1"
sorry

mtheorem comptrig_th_23:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be increasingRFUNCT-2V1"
sorry

mtheorem comptrig_th_24:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be decreasingRFUNCT-2V2"
sorry

mtheorem comptrig_th_25:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be decreasingRFUNCT-2V2"
sorry

mtheorem comptrig_th_26:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be increasingRFUNCT-2V1"
sorry

mtheorem comptrig_th_27:
" for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] & (cosSIN-COSK19).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

mtheorem comptrig_th_28:
"rngFUNCT-1K2 (sinSIN-COSK17) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

mtheorem comptrig_th_29:
"rngFUNCT-1K2 (cosSIN-COSK19) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

mtheorem comptrig_th_30:
"rngFUNCT-1K2 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

mtheorem comptrig_th_31:
"rngFUNCT-1K2 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

mtheorem comptrig_th_32:
"rngFUNCT-1K2 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

mtheorem comptrig_th_33:
"rngFUNCT-1K2 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
sorry

(*begin*)
mdef comptrig_def_1 ("ArgCOMPTRIGK1  _ " [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func ArgCOMPTRIGK1 z \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it) & it <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) if z <>HIDDENR2 0NUMBERSK6 otherwise \<lambda>it. it =COMPLEX1R1 0NUMBERSK6"
proof-
  (*existence*)
    show "(z <>HIDDENR2 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it) & it <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))) & ( not z <>HIDDENR2 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6))"
sorry
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (z <>HIDDENR2 0NUMBERSK6 implies (((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it1) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it1))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it1) & it1 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & ((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it2) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it2))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it2) & it2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) implies it1 =HIDDENR1 it2)) & ( not z <>HIDDENR2 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem comptrig_th_34:
" for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
sorry

mtheorem comptrig_th_35:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_36:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 x =COMPLEX1R1 PISIN-COSK29"
sorry

mtheorem comptrig_th_37:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem comptrig_th_38:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
sorry

mtheorem comptrig_th_39:
"ArgCOMPTRIGK1 \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
  using comptrig_th_35 sorry

mtheorem comptrig_th_40:
"ArgCOMPTRIGK1 (<i>COMPLEX1K8) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem comptrig_th_41:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ iff ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_42:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ iff ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_43:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ iff ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem comptrig_th_44:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ iff ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem comptrig_th_45:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_46:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem comptrig_th_47:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem comptrig_th_48:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <=XXREAL-0R1 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_49:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem comptrig_th_50:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem comptrig_th_51:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem comptrig_th_52:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <=XXREAL-0R1 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_53:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem comptrig_th_54:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be NatNAT-1M1 holds z <>HIDDENR2 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6 implies z  |^NEWTONK1 n =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem comptrig_th_55:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem comptrig_th_56:
" for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies z =COMPLEX1R1 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
sorry

mdef comptrig_def_2 ("CRootCOMPTRIGM1-of'( _ , _ ')" [0,0]70 ) where
  mlet "x be ComplexXCMPLX-0M1", "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
"mode CRootCOMPTRIGM1-of(n,x) \<rightarrow> ComplexXCMPLX-0M1 means
  (\<lambda>it. it  |^NEWTONK1 n =COMPLEX1R1 x)"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st it  |^NEWTONK1 n =COMPLEX1R1 x"
sorry
qed "sorry"

mtheorem comptrig_th_57:
" for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for k be NatNAT-1M1 holds n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,x)"
sorry

mtheorem comptrig_th_58:
" for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for v be CRootCOMPTRIGM1-of(\<one>\<^sub>M,x) holds v =COMPLEX1R1 x"
sorry

mtheorem comptrig_th_59:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for v be CRootCOMPTRIGM1-of(n,0NUMBERSK6) holds v =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_60:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for v be CRootCOMPTRIGM1-of(n,x) holds v =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_61:
" for a be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & cosSIN-COSK20 a =COMPLEX1R1 \<one>\<^sub>M implies a =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem comptrig_th_62:
" for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

end
