theory sin_cos6
  imports fdiff_2 complex2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, r2, s, x for "RealXREAL-0M1"
reserve i for "IntegerINT-1M1"
mtheorem sin_cos6_th_1:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 s implies [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_2:
" for f be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds f  |RELAT-1K8 X be one-to-oneFUNCT-1V2 & Y c=TARSKIR1 X implies f  |RELAT-1K8 Y be one-to-oneFUNCT-1V2"
sorry

(*begin*)
mtheorem sin_cos6_th_3:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 sinSIN-COSK18 r"
sorry

mtheorem sin_cos6_th_4:
" for r be RealXREAL-0M1 holds sinSIN-COSK18 r <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_5:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 cosSIN-COSK20 r"
sorry

mtheorem sin_cos6_th_6:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 r <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mlemma sin_cos6_lm_1:
"[.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
   sorry

mlemma sin_cos6_lm_2:
"[.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
   sorry

mlemma sin_cos6_lm_3:
"[.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
   sorry

mlemma sin_cos6_lm_4:
"[.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
   sorry

mlemma sin_cos6_lm_5:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_cl_1:
"cluster PISIN-COSK29 as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "PISIN-COSK29 be positiveXXREAL-0V2"
sorry
qed "sorry"

mlemma sin_cos6_lm_6:
"(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<one>\<^sub>M"
  using xreal_1_th_76 sorry

mlemma sin_cos6_lm_7:
"\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  using xreal_1_th_68 sorry

mlemma sin_cos6_lm_8:
"0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 \<one>\<^sub>M"
  using xreal_1_th_6 sorry

mlemma sin_cos6_lm_9:
"(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  using xreal_1_th_68 sorry

mlemma sin_cos6_lm_10:
"\<one>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  using xreal_1_th_68 sorry

mtheorem sin_cos6_th_7:
"sinSIN-COSK18 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_8:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (sinSIN-COSK17).FUNCT-1K1 r =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
sorry

mtheorem sin_cos6_th_9:
"cosSIN-COSK20 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_10:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (cosSIN-COSK19).FUNCT-1K1 r =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 (r +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i)"
sorry

mtheorem sin_cos6_th_11:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_12:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_13:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_14:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_15:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_16:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_17:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_18:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_19:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_20:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos6_th_21:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
sorry

mtheorem sin_cos6_th_22:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & cosSIN-COSK20 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i or r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i"
sorry

mtheorem sin_cos6_th_23:
" for r be RealXREAL-0M1 holds sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
sorry

mtheorem sin_cos6_th_24:
" for r be RealXREAL-0M1 holds sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
sorry

mtheorem sin_cos6_th_25:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
sorry

mtheorem sin_cos6_th_26:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ([\\INT-1K2 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /])"
sorry

mtheorem sin_cos6_th_27:
" for r be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
sorry

mtheorem sin_cos6_th_28:
" for r be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 r =XBOOLE-0R4 \<one>\<^sub>M implies r =HIDDENR1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos6_th_29:
" for r be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & cosSIN-COSK20 r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies r =HIDDENR1 PISIN-COSK29"
sorry

mtheorem sin_cos6_th_30:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_31:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_32:
" for r be RealXREAL-0M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_33:
" for r be RealXREAL-0M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_34:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies cosSIN-COSK20 r <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_35:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_36:
" for r be RealXREAL-0M1 holds PISIN-COSK29 <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_37:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_38:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_39:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_40:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies sinSIN-COSK18 r <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_41:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_42:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_43:
" for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <XXREAL-0R3 r & r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i implies cosSIN-COSK20 r >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos6_th_44:
" for r be RealXREAL-0M1 holds cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 r) =XBOOLE-0R4 \<one>\<^sub>M implies r inHIDDENR3 INTINT-1K1"
sorry

mtheorem sin_cos6_th_45:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_30 relat_1_th_115 sorry

mtheorem sin_cos6_th_46:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
sorry

mtheorem sin_cos6_th_47:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_31 relat_1_th_115 sorry

mtheorem sin_cos6_th_48:
"(sinSIN-COSK17).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
sorry

mtheorem sin_cos6_th_49:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_32 relat_1_th_115 sorry

mtheorem sin_cos6_th_50:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
sorry

mtheorem sin_cos6_th_51:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_33 relat_1_th_115 sorry

mtheorem sin_cos6_th_52:
"(cosSIN-COSK19).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) =XBOOLE-0R4 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
sorry

mlemma sin_cos6_lm_11:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .] implies r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .]"
sorry

mlemma sin_cos6_lm_12:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2 implies r +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i +XCMPLX-0K2 \<one>\<^sub>M) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
sorry

mlemma sin_cos6_lm_13:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .] implies r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .]"
sorry

mlemma sin_cos6_lm_14:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds r inHIDDENR3 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2 implies r -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ([.RCOMP-1K1 p1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M),p2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
sorry

mtheorem sin_cos6_th_53:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
sorry

mtheorem sin_cos6_th_54:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
sorry

mtheorem sin_cos6_th_55:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be decreasingRFUNCT-2V2"
sorry

mtheorem sin_cos6_th_56:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be increasingRFUNCT-2V1"
sorry

mtheorem sin_cos6_th_57:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
sorry

mtheorem sin_cos6_th_58:
" for i be IntegerINT-1M1 holds (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
sorry

mtheorem sin_cos6_cl_2:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_1 sin_cos6_th_57 sorry
qed "sorry"

mtheorem sin_cos6_cl_3:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_2 sin_cos6_th_58 sorry
qed "sorry"

mtheorem sin_cos6_cl_4:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_5:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_6:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_7:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_8:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_9:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_10:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_11:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,0NUMBERSK6 .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_12:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_13:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_14:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_15:
"cluster (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_th_59:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
sorry

mtheorem sin_cos6_th_60:
" for i be IntegerINT-1M1 holds (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i .]) be one-to-oneFUNCT-1V2"
sorry

mtheorem sin_cos6_cl_16:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_3 sin_cos6_th_59 sorry
qed "sorry"

mtheorem sin_cos6_cl_17:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
    using sin_cos6_lm_4 sin_cos6_th_60 sorry
qed "sorry"

mtheorem sin_cos6_cl_18:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_19:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_20:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_21:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_22:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_23:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_24:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_25:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_26:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_cl_27:
"cluster (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be one-to-oneFUNCT-1V2"
sorry
qed "sorry"

mtheorem sin_cos6_th_61:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds (((((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i <=XXREAL-0R1 s) & s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i) & sinSIN-COSK18 r =XBOOLE-0R4 sinSIN-COSK18 s) & cosSIN-COSK20 r =XBOOLE-0R4 cosSIN-COSK20 s implies r =HIDDENR1 s"
sorry

(*begin*)
mdef sin_cos6_def_1 ("arcsinSIN-COS6K1" 164 ) where
"func arcsinSIN-COS6K1 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  ((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
proof-
  (*coherence*)
    show "((sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef sin_cos6_def_2 ("arcsinSIN-COS6K2  _ " [164]164 ) where
  mlet "r be objectHIDDENM1"
"func arcsinSIN-COS6K2 r \<rightarrow> numberORDINAL1M2 equals
  (arcsinSIN-COS6K1).FUNCT-1K1 r"
proof-
  (*coherence*)
    show "(arcsinSIN-COS6K1).FUNCT-1K1 r be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos6_cl_28:
  mlet "r be objectHIDDENM1"
"cluster arcsinSIN-COS6K2 r as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "arcsinSIN-COS6K2 r be realXREAL-0V1"
     sorry
qed "sorry"

mlemma sin_cos6_lm_15:
"(arcsinSIN-COS6K1)\<inverse>FUNCT-1K4 =FUNCT-1R1 (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  using funct_1_th_43 sorry

mtheorem sin_cos6_th_62:
"rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
sorry

mtheorem sin_cos6_cl_29:
"cluster arcsinSIN-COS6K1 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "arcsinSIN-COS6K1 be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mtheorem sin_cos6_th_63:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_30 funct_1_th_33 sorry

mtheorem sin_cos6_th_64:
"(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) *FUNCT-1K3 (arcsinSIN-COS6K1) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_30 funct_1_th_39 sorry

mtheorem sin_cos6_th_65:
"(arcsinSIN-COS6K1)*RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_30 funct_1_th_39 sorry

mtheorem sin_cos6_th_66:
"(sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) *RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  using sin_cos6_lm_15 sin_cos6_th_62 funct_1_th_39 sorry

mtheorem sin_cos6_th_67:
"(arcsinSIN-COS6K1)*FUNCT-1K3 (sinSIN-COSK17) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  using sin_cos6_lm_15 sin_cos6_th_62 funct_1_th_39 sorry

mtheorem sin_cos6_th_68:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies sinSIN-COSK18 (arcsinSIN-COS6K2 r) =HIDDENR1 r"
sorry

mtheorem sin_cos6_th_69:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies arcsinSIN-COS6K2 (sinSIN-COSK18 r) =HIDDENR1 r"
sorry

mtheorem sin_cos6_th_70:
"arcsinSIN-COS6K2 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos6_th_7 sin_cos6_th_69 sorry

mtheorem sin_cos6_th_71:
"arcsinSIN-COS6K2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
  using sin_cos6_th_69 sin_cos_th_31 sorry

mtheorem sin_cos6_th_72:
"arcsinSIN-COS6K2 \<one>\<^sub>M =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos6_th_69 sin_cos_th_77 sorry

mtheorem sin_cos6_th_73:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arcsinSIN-COS6K2 r =HIDDENR1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
  using sin_cos6_th_7 sin_cos6_th_68 sorry

mtheorem sin_cos6_th_74:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arcsinSIN-COS6K2 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 0NUMBERSK6"
  using sin_cos6_th_68 sin_cos_th_31 sorry

mtheorem sin_cos6_th_75:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies r =HIDDENR1 \<one>\<^sub>M"
  using sin_cos6_th_68 sin_cos_th_77 sorry

mtheorem sin_cos6_th_76:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos6_th_77:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 arcsinSIN-COS6K2 r & arcsinSIN-COS6K2 r <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos6_th_78:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arcsinSIN-COS6K2 r =HIDDENR1 -XCMPLX-0K4 arcsinSIN-COS6K2 (-XCMPLX-0K4 r)"
sorry

mtheorem sin_cos6_th_79:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 s & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 s"
sorry

mtheorem sin_cos6_th_80:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds s <=XXREAL-0R1 0NUMBERSK6 & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 -XCMPLX-0K4 s"
sorry

mtheorem sin_cos6_th_81:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies cosSIN-COSK20 (arcsinSIN-COS6K2 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
sorry

mtheorem sin_cos6_th_82:
"(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be increasingRFUNCT-2V1"
sorry

mtheorem sin_cos6_th_83:
" for r be RealXREAL-0M1 holds arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies diffFDIFF-1K1(arcsinSIN-COS6K1,r) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
sorry

mtheorem sin_cos6_th_84:
"(arcsinSIN-COS6K1) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be continuousFCONT-1V1"
sorry

(*begin*)
mdef sin_cos6_def_3 ("arccosSIN-COS6K3" 164 ) where
"func arccosSIN-COS6K3 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  ((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
proof-
  (*coherence*)
    show "((cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef sin_cos6_def_4 ("arccosSIN-COS6K4  _ " [164]164 ) where
  mlet "r be objectHIDDENM1"
"func arccosSIN-COS6K4 r \<rightarrow> numberORDINAL1M2 equals
  (arccosSIN-COS6K3).FUNCT-1K1 r"
proof-
  (*coherence*)
    show "(arccosSIN-COS6K3).FUNCT-1K1 r be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos6_cl_30:
  mlet "r be objectHIDDENM1"
"cluster arccosSIN-COS6K4 r as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "arccosSIN-COS6K4 r be realXREAL-0V1"
     sorry
qed "sorry"

mlemma sin_cos6_lm_16:
"(arccosSIN-COS6K3)\<inverse>FUNCT-1K4 =FUNCT-1R1 (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  using funct_1_th_43 sorry

mtheorem sin_cos6_th_85:
"rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
sorry

mtheorem sin_cos6_cl_31:
"cluster arccosSIN-COS6K3 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "arccosSIN-COS6K3 be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mtheorem sin_cos6_th_86:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  using comptrig_th_32 funct_1_th_33 sorry

mtheorem sin_cos6_th_87:
"(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) *FUNCT-1K3 (arccosSIN-COS6K3) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_32 funct_1_th_39 sorry

mtheorem sin_cos6_th_88:
"(arccosSIN-COS6K3)*RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  using comptrig_th_32 funct_1_th_39 sorry

mtheorem sin_cos6_th_89:
"(cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) *RELSET-1K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  using sin_cos6_lm_16 sin_cos6_th_85 funct_1_th_39 sorry

mtheorem sin_cos6_th_90:
"(arccosSIN-COS6K3)*FUNCT-1K3 (cosSIN-COSK19) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) =FUNCT-1R1 idPARTFUN1K6 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  using sin_cos6_lm_16 sin_cos6_th_85 funct_1_th_39 sorry

mtheorem sin_cos6_th_91:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies cosSIN-COSK20 (arccosSIN-COS6K4 r) =HIDDENR1 r"
sorry

mtheorem sin_cos6_th_92:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & r <=XXREAL-0R1 PISIN-COSK29 implies arccosSIN-COS6K4 (cosSIN-COSK20 r) =HIDDENR1 r"
sorry

mtheorem sin_cos6_th_93:
"arccosSIN-COS6K4 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 PISIN-COSK29"
  using sin_cos6_th_92 sin_cos_th_77 sorry

mtheorem sin_cos6_th_94:
"arccosSIN-COS6K4 (0NUMBERSK6) =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using sin_cos6_lm_6 sin_cos6_th_92 sin_cos_th_77 sorry

mtheorem sin_cos6_th_95:
"arccosSIN-COS6K4 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
  using sin_cos6_th_92 sin_cos_th_31 sorry

mtheorem sin_cos6_th_96:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arccosSIN-COS6K4 r =XBOOLE-0R4 0NUMBERSK6 implies r =HIDDENR1 \<one>\<^sub>M"
  using sin_cos6_th_91 sin_cos_th_31 sorry

mtheorem sin_cos6_th_97:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies r =HIDDENR1 0NUMBERSK6"
  using sin_cos6_th_91 sin_cos_th_77 sorry

mtheorem sin_cos6_th_98:
" for r be RealXREAL-0M1 holds (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M) & arccosSIN-COS6K4 r =HIDDENR1 PISIN-COSK29 implies r =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
  using sin_cos6_th_91 sin_cos_th_77 sorry

mtheorem sin_cos6_th_99:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <=XXREAL-0R1 PISIN-COSK29"
sorry

mtheorem sin_cos6_th_100:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 arccosSIN-COS6K4 r & arccosSIN-COS6K4 r <XXREAL-0R3 PISIN-COSK29"
sorry

mtheorem sin_cos6_th_101:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 r =XBOOLE-0R4 PISIN-COSK29 -XCMPLX-0K6 arccosSIN-COS6K4 (-XCMPLX-0K4 r)"
sorry

mtheorem sin_cos6_th_102:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 s & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 s"
sorry

mtheorem sin_cos6_th_103:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds s <=XXREAL-0R1 0NUMBERSK6 & r ^2SQUARE-1K1 +XCMPLX-0K2 s ^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 -XCMPLX-0K4 s"
sorry

mtheorem sin_cos6_th_104:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies sinSIN-COSK18 (arccosSIN-COS6K4 r) =HIDDENR1 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1)"
sorry

mtheorem sin_cos6_th_105:
"(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be decreasingRFUNCT-2V2"
sorry

mtheorem sin_cos6_th_106:
" for r be RealXREAL-0M1 holds arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 r & r <XXREAL-0R3 \<one>\<^sub>M implies diffFDIFF-1K1(arccosSIN-COS6K3,r) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 r ^2SQUARE-1K1))"
sorry

mtheorem sin_cos6_th_107:
"(arccosSIN-COS6K3) |RELSET-1K5\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]) be continuousFCONT-1V1"
sorry

mtheorem sin_cos6_th_108:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arcsinSIN-COS6K2 r +XCMPLX-0K2 arccosSIN-COS6K4 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos6_th_109:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 (-XCMPLX-0K4 r) -XCMPLX-0K6 arcsinSIN-COS6K2 r =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos6_th_110:
" for r be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 r & r <=XXREAL-0R1 \<one>\<^sub>M implies arccosSIN-COS6K4 r -XCMPLX-0K6 arcsinSIN-COS6K2 (-XCMPLX-0K4 r) =XBOOLE-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

end
