theory mboolean
  imports setfam_1 pre_circ
begin
(*begin*)
reserve x, y for "objectHIDDENM1"
reserve I for "setHIDDENM2"
reserve A, B, X, Y for "ManySortedSetPBOOLEM1-of I"
mdef mboolean_def_1 ("boolMBOOLEANK1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"func boolMBOOLEANK1\<^bsub>(I)\<^esub> A \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
sorry
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem mboolean_cl_1:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> A as-term-is non-emptyRELAT-1V2"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> A be non-emptyRELAT-1V2"
sorry
qed "sorry"

mlemma mboolean_lm_1:
" for i be setHIDDENM2 holds  for I be setHIDDENM2 holds  for X be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds i inTARSKIR2 I implies domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =XBOOLE-0R4 I"
sorry

mlemma mboolean_lm_2:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
sorry

mlemma mboolean_lm_3:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
sorry

mlemma mboolean_lm_4:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
sorry

mlemma mboolean_lm_5:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
sorry

mtheorem mboolean_th_1:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y iff ( for A be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> X iff A c=PBOOLER2\<^bsub>(I)\<^esub> Y)"
sorry

mtheorem mboolean_th_2:
" for I be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
sorry

mtheorem mboolean_th_3:
" for I be setHIDDENM2 holds  for x be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 boolZFMISC-1K1 x"
sorry

mtheorem mboolean_th_4:
" for x be objectHIDDENM1 holds  for I be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
sorry

mtheorem mboolean_th_5:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_6:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_7:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B)"
sorry

mtheorem mboolean_th_8:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) implies ( for i be setHIDDENM2 holds i inTARSKIR2 I implies (A .FUNCT-1K1 i,B .FUNCT-1K1 i)are-c=-comparableXBOOLE-0R3)"
sorry

mtheorem mboolean_th_9:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_10:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)"
sorry

mtheorem mboolean_th_11:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B iff X c=PBOOLER2\<^bsub>(I)\<^esub> A & X missesPBOOLER5\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_12:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B)"
sorry

mtheorem mboolean_th_13:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B iff X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B & X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_14:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A or Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_15:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_16:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A & Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_17:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
sorry

mtheorem mboolean_th_18:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A iff X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_19:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds (Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |])"
sorry

(*begin*)
mdef mboolean_def_2 ("unionMBOOLEANK2\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"func unionMBOOLEANK2\<^bsub>(I)\<^esub> A \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
sorry
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem mboolean_cl_2:
  mlet "I be setHIDDENM2"
"cluster unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I as-term-is empty-yieldingRELAT-1V3"
proof
(*coherence*)
  show "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3"
sorry
qed "sorry"

mlemma mboolean_lm_6:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
sorry

mlemma mboolean_lm_7:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
sorry

mtheorem mboolean_th_20:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X iff ( ex Y be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X)"
sorry

mtheorem mboolean_th_21:
" for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem mboolean_th_22:
" for I be setHIDDENM2 holds  for x be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 unionTARSKIK3 x"
sorry

mtheorem mboolean_th_23:
" for x be objectHIDDENM1 holds  for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 x"
sorry

mtheorem mboolean_th_24:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 x,y }"
sorry

mtheorem mboolean_th_25:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_26:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_27:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_28:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_29:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) =PBOOLER7\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_30:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A)"
sorry

mtheorem mboolean_th_31:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A & X inPBOOLER1\<^bsub>(I)\<^esub> Y implies X c=PBOOLER2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_32:
" for I be setHIDDENM2 holds  for Z be ManySortedSetPBOOLEM1-of I holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> Z"
sorry

mtheorem mboolean_th_33:
" for I be setHIDDENM2 holds  for B be ManySortedSetPBOOLEM1-of I holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem mboolean_th_34:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be non-emptyRELAT-1V2 & ( for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X <>HIDDENR2 Y & X inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & Y inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
sorry

mtheorem mboolean_th_35:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & ( for Y be ManySortedSetPBOOLEM1-of I holds Y inPBOOLER1\<^bsub>(I)\<^esub> B implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mboolean_th_36:
" for I be setHIDDENM2 holds  for A be finite-yieldingFINSET-1V3\<bar>non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A & Y inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y or Y c=PBOOLER2\<^bsub>(I)\<^esub> X) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A inPBOOLER1\<^bsub>(I)\<^esub> A"
sorry

end
