theory asympt_1
  imports funct_7 series_1 asympt_0 euler_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve c, c1, c2, d, d1, d2, e, y for "RealXREAL-0M1"
reserve k, n, m, N, n1, N0, N1, N2, N3, M for "ElementSUBSET-1M1-of NATNUMBERSK1"
mlemma asympt_1_lm_1:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 n >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem asympt_1_th_1:
" for t be Real-SequenceSEQ-1M1 holds  for t1 be Real-SequenceSEQ-1M1 holds (t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((\<one>\<two>\<^sub>M *NAT-1K2 n to-powerSERIES-1K5 \<three>\<^sub>M)*XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) -XCMPLX-0K6 \<five>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1)+XCMPLX-0K2 (logPOWERK3(\<two>\<^sub>M,n))^2SQUARE-1K1)+XCMPLX-0K2 \<three>\<six>\<^sub>M)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies t1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerSERIES-1K5 \<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> t & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> t1) & s inTARSKIR2 Big-OhASYMPT-0K6 s1)"
sorry

mlemma asympt_1_lm_2:
" for a be logbaseASYMPT-0V1\<bar>RealXREAL-0M1 holds  for f be Real-SequenceSEQ-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(a,n)) implies f be eventually-positiveASYMPT-0V4"
sorry

mtheorem asympt_1_th_2:
" for a be logbaseASYMPT-0V1\<bar>RealXREAL-0M1 holds  for b be logbaseASYMPT-0V1\<bar>RealXREAL-0M1 holds  for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds ((a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 \<one>\<^sub>M) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(a,n))) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(b,n)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g) & Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 s1)"
sorry

mdef asympt_1_def_1 ("seq-a^ASYMPT-1K1'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1"
"func seq-a^ASYMPT-1K1(a,b,c) \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 n +XCMPLX-0K2 c)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 n +XCMPLX-0K2 c)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 n +XCMPLX-0K2 c)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 n +XCMPLX-0K2 c)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem asympt_1_cl_1:
  mlet "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1"
"cluster seq-a^ASYMPT-1K1(a,b,c) as-term-is eventually-positiveASYMPT-0V4"
proof
(*coherence*)
  show "seq-a^ASYMPT-1K1(a,b,c) be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

mlemma asympt_1_lm_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & c >XXREAL-0R4 0NUMBERSK6) & c <>HIDDENR2 \<one>\<^sub>M implies a to-powerPOWERK2 b =COMPLEX1R1 c to-powerPOWERK2 (b *XCMPLX-0K3 logPOWERK3(c,a))"
sorry

mtheorem asympt_1_th_3:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies  not seq-a^ASYMPT-1K1(b,\<one>\<^sub>M,0NUMBERSK6) inTARSKIR2 Big-OhASYMPT-0K6 (seq-a^ASYMPT-1K1(a,\<one>\<^sub>M,0NUMBERSK6))"
sorry

mdef asympt_1_def_2 ("seq-lognASYMPT-1K2" 164 ) where
"func seq-lognASYMPT-1K2 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n))"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n))) & (it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef asympt_1_def_3 ("seq-n^ASYMPT-1K3  _ " [164]164 ) where
  mlet "a be RealXREAL-0M1"
"func seq-n^ASYMPT-1K3 a \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 a)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 a)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 a)) & (it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 a)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem asympt_1_cl_2:
"cluster seq-lognASYMPT-1K2 as-term-is eventually-positiveASYMPT-0V4"
proof
(*coherence*)
  show "seq-lognASYMPT-1K2 be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

mtheorem asympt_1_cl_3:
  mlet "a be RealXREAL-0M1"
"cluster seq-n^ASYMPT-1K3 a as-term-is eventually-positiveASYMPT-0V4"
proof
(*coherence*)
  show "seq-n^ASYMPT-1K3 a be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

mlemma asympt_1_lm_4:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /REAL-1K6 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mlemma asympt_1_lm_5:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 g & g inTARSKIR2 Big-OhASYMPT-0K6 f iff Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 g"
sorry

mtheorem asympt_1_th_4:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-OhASYMPT-0K6 f c=TARSKIR1 Big-OhASYMPT-0K6 g &  not Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 g iff f inTARSKIR2 Big-OhASYMPT-0K6 g &  not f inTARSKIR2 Big-OmegaASYMPT-0K7 g"
sorry

mlemma asympt_1_lm_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b) & c >=XXREAL-0R2 0NUMBERSK6 implies a to-powerPOWERK2 c <=XXREAL-0R1 b to-powerPOWERK2 c"
sorry

mlemma asympt_1_lm_7:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<four>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M to-powerSERIES-1K5 n"
sorry

mlemma asympt_1_lm_8:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<six>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<two>\<^sub>M to-powerSERIES-1K5 n"
sorry

mlemma asympt_1_lm_9:
" for c be RealXREAL-0M1 holds c >XXREAL-0R4 \<six>\<^sub>M implies c ^2SQUARE-1K1 <XXREAL-0R3 \<two>\<^sub>M to-powerPOWERK2 c"
sorry

mlemma asympt_1_lm_10:
" for e be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n to-powerPOWERK2 e)) implies f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e) be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e)) =COMPLEX1R1 0NUMBERSK6"
sorry

mlemma asympt_1_lm_11:
" for e be RealXREAL-0M1 holds e >XXREAL-0R4 0NUMBERSK6 implies (seq-lognASYMPT-1K2)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e) be convergentSEQ-2V5 & limSEQ-2K1 ((seq-lognASYMPT-1K2)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e)) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem asympt_1_th_5:
"Big-OhASYMPT-0K6 (seq-lognASYMPT-1K2) c=TARSKIR1 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) &  not Big-OhASYMPT-0K6 (seq-lognASYMPT-1K2) =XBOOLE-0R4 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem asympt_1_th_6:
"seq-n^ASYMPT-1K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) inTARSKIR2 Big-OmegaASYMPT-0K7 (seq-lognASYMPT-1K2) &  not seq-lognASYMPT-1K2 inTARSKIR2 Big-OmegaASYMPT-0K7 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mlemma asympt_1_lm_12:
" for f be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies SumSERIES-1K6(f,N) >=XXREAL-0R2 0NUMBERSK6"
sorry

mlemma asympt_1_lm_13:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies SumSERIES-1K6(f,N) <=XXREAL-0R1 SumSERIES-1K6(g,N)"
sorry

mlemma asympt_1_lm_14:
" for f be Real-SequenceSEQ-1M1 holds  for b be RealXREAL-0M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 b) implies ( for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds SumSERIES-1K6(f,N) =COMPLEX1R1 b *XCMPLX-0K3 N)"
sorry

mlemma asympt_1_lm_15:
" for f be Real-SequenceSEQ-1M1 holds  for N be NatNAT-1M1 holds  for M be NatNAT-1M1 holds SumSERIES-1K7(f,N,M) +XCMPLX-0K2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (N +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 SumSERIES-1K7(f,N +NAT-1K1 \<one>\<^sub>M,M)"
sorry

mlemma asympt_1_lm_16:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for M be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds N >=XXREAL-0R2 M +NAT-1K1 \<one>\<^sub>M implies (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies SumSERIES-1K7(f,N,M) <=XXREAL-0R1 SumSERIES-1K7(g,N,M))"
sorry

mlemma asympt_1_lm_17:
" for n be NatNAT-1M1 holds [/INT-1K3 n /XCMPLX-0K7 \<two>\<^sub>M \\] <=XXREAL-0R1 n"
sorry

mlemma asympt_1_lm_18:
" for f be Real-SequenceSEQ-1M1 holds  for b be RealXREAL-0M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 b) implies ( for M be ElementSUBSET-1M1-of NATNUMBERSK1 holds SumSERIES-1K7(f,N,M) =COMPLEX1R1 b *XCMPLX-0K3 (N -XCMPLX-0K6 M))"
sorry

mtheorem asympt_1_th_7:
" for f be Real-SequenceSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 SumSERIES-1K6(seq-n^ASYMPT-1K3 k,n)) implies f inTARSKIR2 Big-ThetaASYMPT-0K8 (seq-n^ASYMPT-1K3 (k +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem asympt_1_th_8:
" for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 logPOWERK3(\<two>\<^sub>M,n)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f &  not s be smoothASYMPT-0V7)"
sorry

(*\$CD*)
mtheorem asympt_1_cl_4:
"cluster seq-constSEQ-1K1 \<one>\<^sub>M as-term-is eventually-nonnegativeASYMPT-0V2"
proof
(*coherence*)
  show "seq-constSEQ-1K1 \<one>\<^sub>M be eventually-nonnegativeASYMPT-0V2"
sorry
qed "sorry"

mlemma asympt_1_lm_19:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & b >=XXREAL-0R2 a) & c >=XXREAL-0R2 \<one>\<^sub>M implies logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(b,c)"
sorry

mtheorem asympt_1_th_9:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  ex F be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) st F =XBOOLE-0R4 {TARSKIK1 seq-n^ASYMPT-1K3 \<one>\<^sub>M } & (f inTARSKIR2 F to-powerASYMPT-0K15 (Big-OhASYMPT-0K6 (seq-constSEQ-1K1 \<one>\<^sub>M)) iff ( ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex c be RealXREAL-0M1 st  ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st c >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies \<one>\<^sub>M <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 c *XCMPLX-0K3 (seq-n^ASYMPT-1K3 k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)))"
sorry

(*begin*)
mtheorem asympt_1_th_10:
" for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<three>\<^sub>M *NAT-1K2 \<one>\<zero>\<^sub>M to-powerSERIES-1K5 \<six>\<^sub>M -XCMPLX-0K6 (\<one>\<eight>\<^sub>M *NAT-1K2 \<one>\<zero>\<^sub>M to-powerSERIES-1K5 \<three>\<^sub>M)*NAT-1K2 n)+XCMPLX-0K2 \<two>\<seven>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1) implies f inTARSKIR2 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<two>\<^sub>M)"
sorry

(*begin*)
mtheorem asympt_1_th_11:
"seq-n^ASYMPT-1K3 \<two>\<^sub>M inTARSKIR2 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<three>\<^sub>M)"
sorry

mtheorem asympt_1_th_12:
" not seq-n^ASYMPT-1K3 \<two>\<^sub>M inTARSKIR2 Big-OmegaASYMPT-0K7 (seq-n^ASYMPT-1K3 \<three>\<^sub>M)"
sorry

mtheorem asympt_1_th_13:
" ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,\<one>\<^sub>M) & seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,0NUMBERSK6) inTARSKIR2 Big-ThetaASYMPT-0K8 s"
sorry

mdef asympt_1_def_5 ("seq-n!ASYMPT-1K4  _ " [164]164 ) where
  mlet "a be ElementSUBSET-1M1-of NATNUMBERSK1"
"func seq-n!ASYMPT-1K4 a \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (n +NAT-1K1 a)!NEWTONK7"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (n +NAT-1K1 a)!NEWTONK7"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (n +NAT-1K1 a)!NEWTONK7) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (n +NAT-1K1 a)!NEWTONK7) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem asympt_1_cl_5:
  mlet "a be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster seq-n!ASYMPT-1K4 a as-term-is eventually-positiveASYMPT-0V4"
proof
(*coherence*)
  show "seq-n!ASYMPT-1K4 a be eventually-positiveASYMPT-0V4"
sorry
qed "sorry"

mtheorem asympt_1_th_14:
" not seq-n!ASYMPT-1K4 (0NUMBERSK6) inTARSKIR2 Big-ThetaASYMPT-0K8 (seq-n!ASYMPT-1K4 \<one>\<^sub>M)"
sorry

(*begin*)
mlemma asympt_1_lm_20:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & (a <=XXREAL-0R1 b & (0NUMBERSK6 <=XXREAL-0R1 c & c <=XXREAL-0R1 d)) implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
sorry

mtheorem asympt_1_th_15:
" for f be Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<one>\<^sub>M) implies f (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f inTARSKIR2 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<two>\<^sub>M)"
sorry

(*begin*)
mtheorem asympt_1_th_16:
" ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,0NUMBERSK6) & \<two>\<^sub>M (#)ASYMPT-0K2 (seq-n^ASYMPT-1K3 \<one>\<^sub>M) inTARSKIR2 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<one>\<^sub>M)) &  not seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<two>\<^sub>M,0NUMBERSK6) inTARSKIR2 Big-OhASYMPT-0K6 s"
sorry

(*begin*)
mtheorem asympt_1_th_17:
"logPOWERK3(\<two>\<^sub>M,\<three>\<^sub>M) <XXREAL-0R3 \<one>\<five>\<nine>\<^sub>M /XCMPLX-0K7 \<one>\<zero>\<zero>\<^sub>M implies (seq-n^ASYMPT-1K3 logPOWERK3(\<two>\<^sub>M,\<three>\<^sub>M) inTARSKIR2 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<five>\<nine>\<^sub>M /XCMPLX-0K7 \<one>\<zero>\<zero>\<^sub>M)) &  not seq-n^ASYMPT-1K3 logPOWERK3(\<two>\<^sub>M,\<three>\<^sub>M) inTARSKIR2 Big-OmegaASYMPT-0K7 (seq-n^ASYMPT-1K3 (\<one>\<five>\<nine>\<^sub>M /XCMPLX-0K7 \<one>\<zero>\<zero>\<^sub>M))) &  not seq-n^ASYMPT-1K3 logPOWERK3(\<two>\<^sub>M,\<three>\<^sub>M) inTARSKIR2 Big-ThetaASYMPT-0K8 (seq-n^ASYMPT-1K3 (\<one>\<five>\<nine>\<^sub>M /XCMPLX-0K7 \<one>\<zero>\<zero>\<^sub>M))"
sorry

(*begin*)
mtheorem asympt_1_th_18:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n modINT-1K6 \<two>\<^sub>M) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)modINT-1K6 \<two>\<^sub>M) implies ( ex s be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 st ((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g) &  not s inTARSKIR2 Big-OhASYMPT-0K6 s1) &  not s1 inTARSKIR2 Big-OhASYMPT-0K6 s)"
sorry

(*begin*)
mtheorem asympt_1_th_19:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 g iff f inTARSKIR2 Big-ThetaASYMPT-0K8 g"
sorry

mtheorem asympt_1_th_20:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-ThetaASYMPT-0K8 g iff Big-ThetaASYMPT-0K8 f =XBOOLE-0R4 Big-ThetaASYMPT-0K8 g"
sorry

(*begin*)
mlemma asympt_1_lm_21:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma asympt_1_lm_22:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for c be RealXREAL-0M1 holds (f be convergentSEQ-2V5 & limSEQ-2K1 f =COMPLEX1R1 c) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies g be convergentSEQ-2V5 & limSEQ-2K1 g =COMPLEX1R1 c"
sorry

mlemma asympt_1_lm_23:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies (n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n ^2SQUARE-1K1"
sorry

mlemma asympt_1_lm_24:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n ^2SQUARE-1K1 <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 ((n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mlemma asympt_1_lm_25:
" for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e & e <XXREAL-0R3 \<one>\<^sub>M implies ( ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 e) -XCMPLX-0K6 \<eight>\<^sub>M *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) >XXREAL-0R4 \<eight>\<^sub>M *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n))"
sorry

mtheorem asympt_1_th_21:
" for e be RealXREAL-0M1 holds  for f be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <XXREAL-0R3 e & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f & Big-OhASYMPT-0K6 s c=TARSKIR1 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M +XCMPLX-0K2 e))) &  not Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M +XCMPLX-0K2 e)))"
sorry

mtheorem asympt_1_th_22:
" for e be RealXREAL-0M1 holds  for g be Real-SequenceSEQ-1M1 holds e <XXREAL-0R3 \<one>\<^sub>M & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 \<one>\<^sub>M implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerSERIES-1K5 \<two>\<^sub>M /XCMPLX-0K7 logPOWERK3(\<two>\<^sub>M,n)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g & Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M +XCMPLX-0K2 e)) c=TARSKIR1 Big-OhASYMPT-0K6 s) &  not Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 (\<one>\<^sub>M +XCMPLX-0K2 e)) =XBOOLE-0R4 Big-OhASYMPT-0K6 s)"
sorry

mtheorem asympt_1_th_23:
" for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 \<one>\<^sub>M implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerSERIES-1K5 \<two>\<^sub>M /XCMPLX-0K7 logPOWERK3(\<two>\<^sub>M,n)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f & Big-OhASYMPT-0K6 s c=TARSKIR1 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<eight>\<^sub>M)) &  not Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<eight>\<^sub>M))"
sorry

mtheorem asympt_1_th_24:
" for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M)to-powerPOWERK2 \<four>\<^sub>M) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g & Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<eight>\<^sub>M) =XBOOLE-0R4 Big-OhASYMPT-0K6 s)"
sorry

mtheorem asympt_1_th_25:
" for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e & e <XXREAL-0R3 \<one>\<^sub>M implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<one>\<^sub>M +XCMPLX-0K2 e,\<one>\<^sub>M,0NUMBERSK6) & Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<eight>\<^sub>M) c=TARSKIR1 Big-OhASYMPT-0K6 s) &  not Big-OhASYMPT-0K6 (seq-n^ASYMPT-1K3 \<eight>\<^sub>M) =XBOOLE-0R4 Big-OhASYMPT-0K6 s)"
sorry

(*begin*)
mlemma asympt_1_lm_26:
"\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<two>\<^sub>M =COMPLEX1R1 \<four>\<zero>\<nine>\<six>\<^sub>M"
sorry

mlemma asympt_1_lm_27:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<three>\<^sub>M implies n ^2SQUARE-1K1 >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma asympt_1_lm_28:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<zero>\<^sub>M implies \<two>\<^sub>M to-powerPOWERK2 (n -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 (\<two>\<^sub>M *NAT-1K2 n)^2SQUARE-1K1"
sorry

mlemma asympt_1_lm_29:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<nine>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)to-powerSERIES-1K5 \<six>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 n to-powerSERIES-1K5 \<six>\<^sub>M"
sorry

mlemma asympt_1_lm_30:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<three>\<zero>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 n >XXREAL-0R4 n to-powerSERIES-1K5 \<six>\<^sub>M"
sorry

mlemma asympt_1_lm_31:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 \<nine>\<^sub>M implies \<two>\<^sub>M to-powerPOWERK2 x >XXREAL-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1"
sorry

mlemma asympt_1_lm_32:
" ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies sqrtSQUARE-1K3 n -XCMPLX-0K6 logPOWERK3(\<two>\<^sub>M,n) >XXREAL-0R4 \<one>\<^sub>M"
sorry

mlemma asympt_1_lm_33:
"\<five>\<^sub>M !NEWTONK7 =COMPLEX1R1 \<one>\<two>\<zero>\<^sub>M"
sorry

mlemma asympt_1_lm_34:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<zero>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M *NAT-1K2 n) /XCMPLX-0K7 (n !NEWTONK7) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M to-powerPOWERK2 (n -XCMPLX-0K6 \<nine>\<^sub>M)"
sorry

mlemma asympt_1_lm_35:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<three>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 (n -XCMPLX-0K6 \<two>\<^sub>M) >=XXREAL-0R2 n -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mlemma asympt_1_lm_36:
"\<five>\<^sub>M to-powerSERIES-1K5 \<five>\<^sub>M =COMPLEX1R1 \<three>\<one>\<two>\<five>\<^sub>M"
sorry

mlemma asympt_1_lm_37:
"\<four>\<^sub>M to-powerSERIES-1K5 \<four>\<^sub>M =COMPLEX1R1 \<two>\<five>\<six>\<^sub>M"
sorry

mlemma asympt_1_lm_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for e be RealXREAL-0M1 holds (a /XCMPLX-0K7 b)/XCMPLX-0K7 (d /XCMPLX-0K7 e) =COMPLEX1R1 (a /XCMPLX-0K7 d)*XCMPLX-0K3 (e /XCMPLX-0K7 b)"
sorry

mlemma asympt_1_lm_39:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies sqrtSQUARE-1K3 x =COMPLEX1R1 x to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mlemma asympt_1_lm_40:
" ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies n -XCMPLX-0K6 sqrtSQUARE-1K3 n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) >XXREAL-0R4 n /XCMPLX-0K7 \<two>\<^sub>M"
sorry

mlemma asympt_1_lm_41:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies s be non-decreasingVALUED-0V11"
sorry

mlemma asympt_1_lm_42:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n)to-powerPOWERK2 n <=XXREAL-0R1 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem asympt_1_th_26:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 logPOWERK3(\<two>\<^sub>M,n)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 sqrtSQUARE-1K3 n) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st ((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g) & Big-OhASYMPT-0K6 s c=TARSKIR1 Big-OhASYMPT-0K6 s1) &  not Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 s1)"
sorry

mtheorem asympt_1_th_27:
" for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 sqrtSQUARE-1K3 n) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st ((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,0NUMBERSK6)) & Big-OhASYMPT-0K6 s c=TARSKIR1 Big-OhASYMPT-0K6 s1) &  not Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 s1)"
sorry

mtheorem asympt_1_th_28:
" ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,0NUMBERSK6) & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,\<one>\<^sub>M)) & Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 s1"
sorry

mtheorem asympt_1_th_29:
" ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st  ex s1 be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st ((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<one>\<^sub>M,0NUMBERSK6) & s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<two>\<^sub>M,0NUMBERSK6)) & Big-OhASYMPT-0K6 s c=TARSKIR1 Big-OhASYMPT-0K6 s1) &  not Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 s1"
sorry

mtheorem asympt_1_th_30:
" ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-a^ASYMPT-1K1(\<two>\<^sub>M,\<two>\<^sub>M,0NUMBERSK6) & Big-OhASYMPT-0K6 s c=TARSKIR1 Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 (0NUMBERSK6))) &  not Big-OhASYMPT-0K6 s =XBOOLE-0R4 Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 (0NUMBERSK6))"
sorry

mtheorem asympt_1_th_31:
"Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 (0NUMBERSK6)) c=TARSKIR1 Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 \<one>\<^sub>M) & Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 (0NUMBERSK6)) <>HIDDENR2 Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 \<one>\<^sub>M)"
sorry

mtheorem asympt_1_th_32:
" for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerSERIES-1K5 n) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st (s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g & Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 \<one>\<^sub>M) c=TARSKIR1 Big-OhASYMPT-0K6 s) &  not Big-OhASYMPT-0K6 (seq-n!ASYMPT-1K4 \<one>\<^sub>M) =XBOOLE-0R4 Big-OhASYMPT-0K6 s)"
sorry

(*begin*)
mlemma asympt_1_lm_43:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies n chooseNEWTONK4 k >=XXREAL-0R2 ((n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK4 k)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem asympt_1_th_33:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ( for f be Real-SequenceSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 SumSERIES-1K6(seq-n^ASYMPT-1K3 k,n)) implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 n to-powerSERIES-1K5 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))"
sorry

(*begin*)
mlemma asympt_1_lm_44:
" for f be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n !NEWTONK7)) implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 SumSERIES-1K6(seq-lognASYMPT-1K2,n))"
sorry

mlemma asympt_1_lm_45:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<four>\<^sub>M implies n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 n"
sorry

mtheorem asympt_1_th_34:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n)) & ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n !NEWTONK7)) implies ( ex s be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 st s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g & f inTARSKIR2 Big-ThetaASYMPT-0K8 s)"
sorry

(*begin*)
mtheorem asympt_1_th_35:
" for f be eventually-nondecreasingASYMPT-0V6\<bar>eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for t be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n modINT-1K6 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M) & (n modINT-1K6 \<two>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M implies t .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n)) implies  not t inTARSKIR2 Big-ThetaASYMPT-0K8 f"
sorry

(*begin*)
mlemma asympt_1_lm_46:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies [/INT-1K3 n /XCMPLX-0K7 \<two>\<^sub>M \\] <XXREAL-0R3 n"
sorry

(*begin*)
mdef asympt_1_def_6 ("POWEROF2SETASYMPT-1K5" 164 ) where
"func POWEROF2SETASYMPT-1K5 \<rightarrow>  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 equals
  {\<two>\<^sub>M to-powerSERIES-1K5 n where n be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  }"
proof-
  (*coherence*)
    show "{\<two>\<^sub>M to-powerSERIES-1K5 n where n be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  } be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1"
sorry
qed "sorry"

mlemma asympt_1_lm_47:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies n ^2SQUARE-1K1 >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma asympt_1_lm_48:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 n >XXREAL-0R4 \<one>\<^sub>M"
sorry

mlemma asympt_1_lm_49:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies  not \<two>\<^sub>M to-powerSERIES-1K5 n -XCMPLX-0K6 \<one>\<^sub>M inTARSKIR2 POWEROF2SETASYMPT-1K5"
sorry

mtheorem asympt_1_th_36:
" for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n inTARSKIR2 POWEROF2SETASYMPT-1K5 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n) & ( not n inTARSKIR2 POWEROF2SETASYMPT-1K5 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerSERIES-1K5 n)) implies ((f inTARSKIR2 Big-ThetaASYMPT-0K11(seq-n^ASYMPT-1K3 \<one>\<^sub>M,POWEROF2SETASYMPT-1K5) &  not f inTARSKIR2 Big-ThetaASYMPT-0K8 (seq-n^ASYMPT-1K3 \<one>\<^sub>M)) & seq-n^ASYMPT-1K3 \<one>\<^sub>M be smoothASYMPT-0V7) &  not f be eventually-nondecreasingASYMPT-0V6"
sorry

mtheorem asympt_1_th_37:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerPOWERK2 (\<two>\<^sub>M to-powerPOWERK2 ([\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n)/]))) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerSERIES-1K5 n) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st ((((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g & f inTARSKIR2 Big-ThetaASYMPT-0K11(s,POWEROF2SETASYMPT-1K5)) &  not f inTARSKIR2 Big-ThetaASYMPT-0K8 s) & f be eventually-nondecreasingASYMPT-0V6) & s be eventually-nondecreasingASYMPT-0V6) &  not s is-smooth-wrtASYMPT-0R2 \<two>\<^sub>M)"
sorry

mtheorem asympt_1_th_38:
" for g be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n inTARSKIR2 POWEROF2SETASYMPT-1K5 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n) & ( not n inTARSKIR2 POWEROF2SETASYMPT-1K5 implies g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n to-powerSERIES-1K5 \<two>\<^sub>M)) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st ((((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> g & seq-n^ASYMPT-1K3 \<one>\<^sub>M inTARSKIR2 Big-ThetaASYMPT-0K11(s,POWEROF2SETASYMPT-1K5)) &  not seq-n^ASYMPT-1K3 \<one>\<^sub>M inTARSKIR2 Big-ThetaASYMPT-0K8 s) & s taken-everyASYMPT-0K12 \<two>\<^sub>M inTARSKIR2 Big-OhASYMPT-0K6 s) & seq-n^ASYMPT-1K3 \<one>\<^sub>M be eventually-nondecreasingASYMPT-0V6) &  not s be eventually-nondecreasingASYMPT-0V6)"
sorry

(*begin*)
mlemma asympt_1_lm_50:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies n !NEWTONK7 >XXREAL-0R4 \<one>\<^sub>M"
sorry

mlemma asympt_1_lm_51:
" for n1 be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 n1 implies n !NEWTONK7 <=XXREAL-0R1 n1 !NEWTONK7"
sorry

mlemma asympt_1_lm_52:
" for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k >=XXREAL-0R2 \<one>\<^sub>M implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (n !NEWTONK7 <=XXREAL-0R1 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds m !NEWTONK7 <=XXREAL-0R1 k & k <XXREAL-0R3 (m +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 implies m =COMPLEX1R1 n))"
sorry

mdef asympt_1_def_7 ("Step1ASYMPT-1K6  _ " [164]164 ) where
  mlet "x be NatNAT-1M1"
"func Step1ASYMPT-1K6 x \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it.  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (n !NEWTONK7 <=XXREAL-0R1 x & x <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) & it =COMPLEX1R1 n !NEWTONK7 if x <>HIDDENR2 0NUMBERSK6 otherwise \<lambda>it. it =COMPLEX1R1 0NUMBERSK6"
proof-
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds  True "
       sorry
  (*existence*)
    show "(x <>HIDDENR2 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (n !NEWTONK7 <=XXREAL-0R1 x & x <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) & it =COMPLEX1R1 n !NEWTONK7)) & ( not x <>HIDDENR2 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it =COMPLEX1R1 0NUMBERSK6))"
sorry
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (x <>HIDDENR2 0NUMBERSK6 implies (( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (n !NEWTONK7 <=XXREAL-0R1 x & x <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) & it1 =COMPLEX1R1 n !NEWTONK7) & ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (n !NEWTONK7 <=XXREAL-0R1 x & x <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) & it2 =COMPLEX1R1 n !NEWTONK7) implies it1 =HIDDENR1 it2)) & ( not x <>HIDDENR2 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
sorry
qed "sorry"

mlemma asympt_1_lm_53:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<three>\<^sub>M implies n !NEWTONK7 >XXREAL-0R4 n"
sorry

mtheorem asympt_1_th_39:
" for f be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Step1ASYMPT-1K6 n) implies ( ex s be eventually-positiveASYMPT-0V4\<bar>Real-SequenceSEQ-1M1 st ((s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f &  not s be smoothASYMPT-0V7) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (seq-n^ASYMPT-1K3 \<one>\<^sub>M).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & f be eventually-nondecreasingASYMPT-0V6)"
sorry

(*begin*)
mlemma asympt_1_lm_54:
"seq-n^ASYMPT-1K3 \<one>\<^sub>M -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 \<one>\<^sub>M be eventually-positiveASYMPT-0V4"
sorry

mtheorem asympt_1_th_40:
" for F be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds F =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq-n^ASYMPT-1K3 \<one>\<^sub>M -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 \<one>\<^sub>M implies Big-ThetaASYMPT-0K8 F +ASYMPT-0K13\<^bsub>(NATNUMBERSK1)\<^esub> Big-ThetaASYMPT-0K8 (seq-n^ASYMPT-1K3 \<one>\<^sub>M) =XBOOLE-0R4 Big-ThetaASYMPT-0K8 (seq-n^ASYMPT-1K3 \<one>\<^sub>M)"
sorry

(*begin*)
mtheorem asympt_1_th_41:
" ex F be FUNCTION-DOMAINFUNCT-2M3-of(NATNUMBERSK1,REALNUMBERSK2) st (F =XBOOLE-0R4 {TARSKIK1 seq-n^ASYMPT-1K3 \<one>\<^sub>M } & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq-n^ASYMPT-1K3 (-XCMPLX-0K4 \<one>\<^sub>M)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (seq-n^ASYMPT-1K3 \<one>\<^sub>M).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) &  not seq-n^ASYMPT-1K3 (-XCMPLX-0K4 \<one>\<^sub>M) inTARSKIR2 F to-powerASYMPT-0K15 (Big-OhASYMPT-0K6 (seq-constSEQ-1K1 \<one>\<^sub>M))"
sorry

(*begin*)
mtheorem asympt_1_th_42:
" for c be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1 holds  for x be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds ( ex e be RealXREAL-0M1 st  ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st e >XXREAL-0R4 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 e)) implies (x inTARSKIR2 Big-OhASYMPT-0K6 (c +ASYMPT-0K3 f) implies x inTARSKIR2 Big-OhASYMPT-0K6 f)"
sorry

(*begin*)
mtheorem asympt_1_th_43:
"\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<two>\<^sub>M =COMPLEX1R1 \<four>\<zero>\<nine>\<six>\<^sub>M"
  using asympt_1_lm_26 sorry

mtheorem asympt_1_th_44:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<three>\<^sub>M implies n ^2SQUARE-1K1 >XXREAL-0R4 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M"
  using asympt_1_lm_27 sorry

mtheorem asympt_1_th_45:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<zero>\<^sub>M implies \<two>\<^sub>M to-powerPOWERK2 (n -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 (\<two>\<^sub>M *NAT-1K2 n)^2SQUARE-1K1"
  using asympt_1_lm_28 sorry

mtheorem asympt_1_th_46:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<nine>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)to-powerSERIES-1K5 \<six>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 n to-powerSERIES-1K5 \<six>\<^sub>M"
  using asympt_1_lm_29 sorry

mtheorem asympt_1_th_47:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<three>\<zero>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 n >XXREAL-0R4 n to-powerSERIES-1K5 \<six>\<^sub>M"
  using asympt_1_lm_30 sorry

mtheorem asympt_1_th_48:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 \<nine>\<^sub>M implies \<two>\<^sub>M to-powerPOWERK2 x >XXREAL-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1"
  using asympt_1_lm_31 sorry

mtheorem asympt_1_th_49:
" ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies sqrtSQUARE-1K3 n -XCMPLX-0K6 logPOWERK3(\<two>\<^sub>M,n) >XXREAL-0R4 \<one>\<^sub>M"
  using asympt_1_lm_32 sorry

mtheorem asympt_1_th_50:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & c >XXREAL-0R4 0NUMBERSK6) & c <>HIDDENR2 \<one>\<^sub>M implies a to-powerPOWERK2 b =COMPLEX1R1 c to-powerPOWERK2 (b *XCMPLX-0K3 logPOWERK3(c,a))"
  using asympt_1_lm_3 sorry

mtheorem asympt_1_th_51:
"\<five>\<^sub>M !NEWTONK7 =COMPLEX1R1 \<one>\<two>\<zero>\<^sub>M"
  using asympt_1_lm_33 sorry

mtheorem asympt_1_th_52:
"\<five>\<^sub>M to-powerSERIES-1K5 \<five>\<^sub>M =COMPLEX1R1 \<three>\<one>\<two>\<five>\<^sub>M"
  using asympt_1_lm_36 sorry

mtheorem asympt_1_th_53:
"\<four>\<^sub>M to-powerSERIES-1K5 \<four>\<^sub>M =COMPLEX1R1 \<two>\<five>\<six>\<^sub>M"
  using asympt_1_lm_37 sorry

mtheorem asympt_1_th_54:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
  using asympt_1_lm_21 sorry

mtheorem asympt_1_th_55:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies n !NEWTONK7 >XXREAL-0R4 \<one>\<^sub>M"
  using asympt_1_lm_50 sorry

mtheorem asympt_1_th_56:
" for n1 be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 n1 implies n !NEWTONK7 <=XXREAL-0R1 n1 !NEWTONK7"
  using asympt_1_lm_51 sorry

mtheorem asympt_1_th_57:
" for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k >=XXREAL-0R2 \<one>\<^sub>M implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (n !NEWTONK7 <=XXREAL-0R1 k & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds m !NEWTONK7 <=XXREAL-0R1 k & k <XXREAL-0R3 (m +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 implies m =COMPLEX1R1 n))"
  using asympt_1_lm_52 sorry

mtheorem asympt_1_th_58:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies [/INT-1K3 n /XCMPLX-0K7 \<two>\<^sub>M \\] <XXREAL-0R3 n"
  using asympt_1_lm_46 sorry

mtheorem asympt_1_th_59:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<three>\<^sub>M implies n !NEWTONK7 >XXREAL-0R4 n"
  using asympt_1_lm_53 sorry

mtheorem asympt_1_th_60:
"seq-n^ASYMPT-1K3 \<one>\<^sub>M -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq-constSEQ-1K1 \<one>\<^sub>M be eventually-positiveASYMPT-0V4"
  using asympt_1_lm_54 sorry

mtheorem asympt_1_th_61:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 n >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
  using asympt_1_lm_1 sorry

mtheorem asympt_1_th_62:
" for a be logbaseASYMPT-0V1\<bar>RealXREAL-0M1 holds  for f be Real-SequenceSEQ-1M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(a,n)) implies f be eventually-positiveASYMPT-0V4"
  using asympt_1_lm_2 sorry

mtheorem asympt_1_th_63:
" for f be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds  for g be eventually-nonnegativeASYMPT-0V2\<bar>Real-SequenceSEQ-1M1 holds f inTARSKIR2 Big-OhASYMPT-0K6 g & g inTARSKIR2 Big-OhASYMPT-0K6 f iff Big-OhASYMPT-0K6 f =XBOOLE-0R4 Big-OhASYMPT-0K6 g"
  using asympt_1_lm_5 sorry

mtheorem asympt_1_th_64:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b) & c >=XXREAL-0R2 0NUMBERSK6 implies a to-powerPOWERK2 c <=XXREAL-0R1 b to-powerPOWERK2 c"
  using asympt_1_lm_6 sorry

mtheorem asympt_1_th_65:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<four>\<^sub>M implies \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<three>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M to-powerSERIES-1K5 n"
  using asympt_1_lm_7 sorry

mtheorem asympt_1_th_66:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<six>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<two>\<^sub>M to-powerSERIES-1K5 n"
  using asympt_1_lm_8 sorry

mtheorem asympt_1_th_67:
" for c be RealXREAL-0M1 holds c >XXREAL-0R4 \<six>\<^sub>M implies c ^2SQUARE-1K1 <XXREAL-0R3 \<two>\<^sub>M to-powerPOWERK2 c"
  using asympt_1_lm_9 sorry

mtheorem asympt_1_th_68:
" for e be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for f be Real-SequenceSEQ-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n to-powerPOWERK2 e)) implies f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e) be convergentSEQ-2V5 & limSEQ-2K1 (f /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e)) =COMPLEX1R1 0NUMBERSK6"
  using asympt_1_lm_10 sorry

mtheorem asympt_1_th_69:
" for e be RealXREAL-0M1 holds e >XXREAL-0R4 0NUMBERSK6 implies (seq-lognASYMPT-1K2)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e) be convergentSEQ-2V5 & limSEQ-2K1 ((seq-lognASYMPT-1K2)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq-n^ASYMPT-1K3 e)) =COMPLEX1R1 0NUMBERSK6"
  using asympt_1_lm_11 sorry

mtheorem asympt_1_th_70:
" for f be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies SumSERIES-1K6(f,N) >=XXREAL-0R2 0NUMBERSK6"
  using asympt_1_lm_12 sorry

mtheorem asympt_1_th_71:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies SumSERIES-1K6(f,N) <=XXREAL-0R1 SumSERIES-1K6(g,N)"
  using asympt_1_lm_13 sorry

mtheorem asympt_1_th_72:
" for f be Real-SequenceSEQ-1M1 holds  for b be RealXREAL-0M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 b) implies ( for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds SumSERIES-1K6(f,N) =COMPLEX1R1 b *XCMPLX-0K3 N)"
  using asympt_1_lm_14 sorry

mtheorem asympt_1_th_73:
" for f be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for M be ElementSUBSET-1M1-of NATNUMBERSK1 holds SumSERIES-1K7(f,N,M) +XCMPLX-0K2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (N +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 SumSERIES-1K7(f,N +NAT-1K1 \<one>\<^sub>M,M)"
  using asympt_1_lm_15 sorry

mtheorem asympt_1_th_74:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for M be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds N >=XXREAL-0R2 M +NAT-1K1 \<one>\<^sub>M implies (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies SumSERIES-1K7(f,N,M) <=XXREAL-0R1 SumSERIES-1K7(g,N,M))"
  using asympt_1_lm_16 sorry

mtheorem asympt_1_th_75:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds [/INT-1K3 n /XCMPLX-0K7 \<two>\<^sub>M \\] <=XXREAL-0R1 n"
  using asympt_1_lm_17 sorry

mtheorem asympt_1_th_76:
" for f be Real-SequenceSEQ-1M1 holds  for b be RealXREAL-0M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >XXREAL-0R4 0NUMBERSK6 implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 b) implies ( for M be ElementSUBSET-1M1-of NATNUMBERSK1 holds SumSERIES-1K7(f,N,M) =COMPLEX1R1 b *XCMPLX-0K3 (N -XCMPLX-0K6 M))"
  using asympt_1_lm_18 sorry

mtheorem asympt_1_th_77:
" for f be Real-SequenceSEQ-1M1 holds  for g be Real-SequenceSEQ-1M1 holds  for N be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for c be RealXREAL-0M1 holds (f be convergentSEQ-2V5 & limSEQ-2K1 f =COMPLEX1R1 c) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies g be convergentSEQ-2V5 & limSEQ-2K1 g =COMPLEX1R1 c"
  using asympt_1_lm_22 sorry

mtheorem asympt_1_th_78:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies (n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n ^2SQUARE-1K1"
  using asympt_1_lm_23 sorry

mtheorem asympt_1_th_79:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n ^2SQUARE-1K1 <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 ((n ^2SQUARE-1K1 -XCMPLX-0K6 n)+XCMPLX-0K2 \<one>\<^sub>M)"
  using asympt_1_lm_24 sorry

mtheorem asympt_1_th_80:
" for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e & e <XXREAL-0R3 \<one>\<^sub>M implies ( ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,\<one>\<^sub>M +XCMPLX-0K2 e) -XCMPLX-0K6 \<eight>\<^sub>M *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) >XXREAL-0R4 \<eight>\<^sub>M *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n))"
  using asympt_1_lm_25 sorry

mtheorem asympt_1_th_81:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<zero>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M *NAT-1K2 n) /XCMPLX-0K7 (n !NEWTONK7) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M to-powerPOWERK2 (n -XCMPLX-0K6 \<nine>\<^sub>M)"
  using asympt_1_lm_34 sorry

mtheorem asympt_1_th_82:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<three>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 (n -XCMPLX-0K6 \<two>\<^sub>M) >=XXREAL-0R2 n -XCMPLX-0K6 \<one>\<^sub>M"
  using asympt_1_lm_35 sorry

mtheorem asympt_1_th_83:
" for c be RealXREAL-0M1 holds c >=XXREAL-0R2 0NUMBERSK6 implies c to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 c"
  using asympt_1_lm_39 sorry

mtheorem asympt_1_th_84:
" ex N be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 N implies n -XCMPLX-0K6 sqrtSQUARE-1K3 n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) >XXREAL-0R4 n /XCMPLX-0K7 \<two>\<^sub>M"
  using asympt_1_lm_40 sorry

mtheorem asympt_1_th_85:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies s be non-decreasingVALUED-0V11"
  using asympt_1_lm_41 sorry

mtheorem asympt_1_th_86:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n)to-powerPOWERK2 n <=XXREAL-0R1 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
  using asympt_1_lm_42 sorry

mtheorem asympt_1_th_87:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies n chooseNEWTONK4 k >=XXREAL-0R2 ((n +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK4 k)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
  using asympt_1_lm_43 sorry

mtheorem asympt_1_th_88:
" for f be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 logPOWERK3(\<two>\<^sub>M,n !NEWTONK7)) implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 SumSERIES-1K6(seq-lognASYMPT-1K2,n))"
  using asympt_1_lm_44 sorry

mtheorem asympt_1_th_89:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<four>\<^sub>M implies n *XCMPLX-0K3 logPOWERK3(\<two>\<^sub>M,n) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 n"
  using asympt_1_lm_45 sorry

mtheorem asympt_1_th_90:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies n ^2SQUARE-1K1 >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
  using asympt_1_lm_47 sorry

mtheorem asympt_1_th_91:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies \<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 n >XXREAL-0R4 \<one>\<^sub>M"
  using asympt_1_lm_48 sorry

mtheorem asympt_1_th_92:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies  not \<two>\<^sub>M to-powerSERIES-1K5 n -XCMPLX-0K6 \<one>\<^sub>M inTARSKIR2 POWEROF2SETASYMPT-1K5"
  using asympt_1_lm_49 sorry

mtheorem asympt_1_th_93:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (k >=XXREAL-0R2 \<one>\<^sub>M & n !NEWTONK7 <=XXREAL-0R1 k) & k <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 implies Step1ASYMPT-1K6 k =COMPLEX1R1 n !NEWTONK7"
  using asympt_1_def_7 sorry

mtheorem asympt_1_th_94:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & b >=XXREAL-0R2 a) & c >=XXREAL-0R2 \<one>\<^sub>M implies logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(b,c)"
  using asympt_1_lm_19 sorry

end
