theory prob_2
  imports valued_1 prob_1 xcmplx_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve Omega for "setHIDDENM2"
reserve m, n, k for "NatNAT-1M1"
reserve x, y for "objectHIDDENM1"
reserve r, r1, r2, r3 for "RealXREAL-0M1"
reserve seq, seq1 for "Real-SequenceSEQ-1M1"
reserve Sigma for "SigmaFieldPROB-1M3-of Omega"
reserve ASeq, BSeq for "SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
reserve A, B, C, A1, A2, A3 for "EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
mtheorem prob_2_th_1:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 & r1 <>HIDDENR2 0NUMBERSK6 implies (r3 /XCMPLX-0K7 r1 =COMPLEX1R1 r2 /XCMPLX-0K7 r iff r3 *XCMPLX-0K3 r =COMPLEX1R1 r2 *XCMPLX-0K3 r1)"
sorry

mtheorem prob_2_th_2:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq1 be convergentSEQ-2V5 & limSEQ-2K1 seq1 =COMPLEX1R1 r -XCMPLX-0K6 limSEQ-2K1 seq"
sorry

syntax PROB_2K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .PROB-2K1\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n" \<rightharpoonup> "ASeq .FUNCT-1K1 n"

mtheorem prob_2_add_1:
  mlet "Omega be setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma", "n be NatNAT-1M1"
"cluster ASeq .FUNCT-1K1 n as-term-is EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
proof
(*coherence*)
  show "ASeq .FUNCT-1K1 n be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
    using prob_1_th_25 sorry
qed "sorry"

mdef prob_2_def_1 ("@IntersectionPROB-2K2\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,164]164 ) where
  mlet "Omega be setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
"func @IntersectionPROB-2K2\<^bsub>(Omega,Sigma)\<^esub> ASeq \<rightarrow> EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma equals
  IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq"
proof-
  (*coherence*)
    show "IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
sorry
qed "sorry"

mtheorem prob_2_th_3:
" for Omega be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  ex BSeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma st  for n be NatNAT-1M1 holds BSeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n =XBOOLE-0R4 ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B"
sorry

mtheorem prob_2_th_4:
" for Omega be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for BSeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 & ( for n be NatNAT-1M1 holds BSeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n =XBOOLE-0R4 ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) implies BSeq be non-ascendingPROB-1V2"
sorry

mtheorem prob_2_th_5:
" for Omega be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for BSeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds ( for n be NatNAT-1M1 holds BSeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n =XBOOLE-0R4 ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) implies (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)/\\SUBSET-1K9\<^bsub>(Omega)\<^esub> B =XBOOLE-0R4 IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> BSeq"
sorry

mtheorem prob_2_cl_1:
  mlet "Omega be setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
"cluster ComplementPROB-1K2\<^bsub>(Omega)\<^esub> ASeq as-term-is Sigma -valuedRELAT-1V5"
proof
(*coherence*)
  show "ComplementPROB-1K2\<^bsub>(Omega)\<^esub> ASeq be Sigma -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem prob_2_th_6:
" for X be setHIDDENM2 holds  for S be SetSequencePROB-1M2-of X holds S be non-ascendingPROB-1V2 iff ( for n be NatNAT-1M1 holds S .PROB-2K1\<^bsub>(X,boolSETFAM-1K9 X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 S .PROB-2K1\<^bsub>(X,boolSETFAM-1K9 X)\<^esub> n)"
sorry

mtheorem prob_2_th_7:
" for X be setHIDDENM2 holds  for S be SetSequencePROB-1M2-of X holds S be non-descendingPROB-1V3 iff ( for n be NatNAT-1M1 holds S .PROB-2K1\<^bsub>(X,boolSETFAM-1K9 X)\<^esub> n c=TARSKIR1 S .PROB-2K1\<^bsub>(X,boolSETFAM-1K9 X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem prob_2_th_8:
" for Omega be setHIDDENM2 holds  for ASeq be SetSequencePROB-1M2-of Omega holds ASeq be non-ascendingPROB-1V2 iff ComplementPROB-1K2\<^bsub>(Omega)\<^esub> ASeq be non-descendingPROB-1V3"
sorry

mlemma prob_2_lm_1:
" for Omega be setHIDDENM2 holds  for ASeq be SetSequencePROB-1M2-of Omega holds ASeq be non-descendingPROB-1V3 iff ComplementPROB-1K2\<^bsub>(Omega)\<^esub> ASeq be non-ascendingPROB-1V2"
sorry

mdef prob_2_def_2 ("disjoint-valuedPROB-2V1" 70 ) where
"attr disjoint-valuedPROB-2V1 for FunctionFUNCT-1M1 means
  (\<lambda>F.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x <>HIDDENR2 y implies F .FUNCT-1K1 x missesXBOOLE-0R1 F .FUNCT-1K1 y)"..

syntax PROB_2V2 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("disjoint-valuedPROB-2V2\<^bsub>'( _ , _ ')\<^esub>" [0,0]70)
translations "disjoint-valuedPROB-2V2\<^bsub>(Omega,Sigma)\<^esub>" \<rightharpoonup> "disjoint-valuedPROB-2V1"

mtheorem prob_2_def_3:
  mlet "Omega be setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
"redefine attr disjoint-valuedPROB-2V2\<^bsub>(Omega,Sigma)\<^esub> for SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma means
  (\<lambda>ASeq.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <>HIDDENR2 n implies ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> m missesXBOOLE-0R1 ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n)"
proof
(*compatibility*)
  show " for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be disjoint-valuedPROB-2V2\<^bsub>(Omega,Sigma)\<^esub> iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <>HIDDENR2 n implies ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> m missesXBOOLE-0R1 ASeq .PROB-2K1\<^bsub>(Omega,Sigma)\<^esub> n)"
sorry
qed "sorry"

reserve Omega for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Sigma for "SigmaFieldPROB-1M3-of Omega"
reserve A, B, C, A1, A2, A3 for "EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
reserve ASeq, BSeq for "SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
reserve P, P1, P2 for "ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
mlemma prob_2_lm_2:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-descendingPROB-1V3 implies P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (UnionPROB-1K1\<^bsub>(Omega)\<^esub> ASeq)"
sorry

mtheorem prob_2_th_9:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for P1 be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) implies P =FUNCT-2R2\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> P1"
sorry

mtheorem prob_2_th_10:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) holds P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma iff ((( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & P .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M) & ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-descendingPROB-1V3 implies P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 P .FUNCT-1K1 (UnionPROB-1K1\<^bsub>(Omega)\<^esub> ASeq))"
sorry

mtheorem prob_2_th_11:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ((A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B)\\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> C) =COMPLEX1R1 (((P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)+REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C)-REAL-1K5 ((P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C))+REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C)))+REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ((A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)/\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C)"
sorry

mtheorem prob_2_th_12:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
  using prob_1_th_33 xboole_1_th_17 sorry

mtheorem prob_2_th_13:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
  using prob_1_th_34 xboole_1_th_17 sorry

mtheorem prob_2_th_14:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds C =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(Omega)\<^esub> implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C)"
sorry

mtheorem prob_2_th_15:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
sorry

mtheorem prob_2_th_16:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
sorry

mtheorem prob_2_th_17:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <XXREAL-0R3 \<one>\<^sub>M iff 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
sorry

mtheorem prob_2_th_18:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) <XXREAL-0R3 \<one>\<^sub>M iff 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
sorry

mdef prob_2_def_4 ("'( _ , _ ')are-independent-respect-toPROB-2R1\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,0,0,50]50 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma", "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma", "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
"pred (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P means
  P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"..

mdef prob_2_def_5 ("'( _ , _ , _ ')are-independent-respect-toPROB-2R2\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,0,0,0,50]50 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma", "A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma", "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma", "C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
"pred (A,B,C)are-independent-respect-toPROB-2R2\<^bsub>(Omega,Sigma)\<^esub> P means
  ((P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ((A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)/\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)*REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B) & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C) & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C"..

mtheorem prob_2_th_19:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P implies (B,A)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
   sorry

mtheorem prob_2_th_20:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,B,C)are-independent-respect-toPROB-2R2\<^bsub>(Omega,Sigma)\<^esub> P iff ((P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ((A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)/\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)*REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C & (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P) & (B,C)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P) & (A,C)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
   sorry

mtheorem prob_2_th_21:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,B,C)are-independent-respect-toPROB-2R2\<^bsub>(Omega,Sigma)\<^esub> P implies (B,A,C)are-independent-respect-toPROB-2R2\<^bsub>(Omega,Sigma)\<^esub> P"
   sorry

mtheorem prob_2_th_22:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,B,C)are-independent-respect-toPROB-2R2\<^bsub>(Omega,Sigma)\<^esub> P implies (A,C,B)are-independent-respect-toPROB-2R2\<^bsub>(Omega,Sigma)\<^esub> P"
  using xboole_1_th_16 sorry

mtheorem prob_2_th_23:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for E be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds E =XBOOLE-0R4 {}XBOOLE-0K1 implies (A,E)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
sorry

mtheorem prob_2_th_24:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,[#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
sorry

mtheorem prob_2_th_25:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P implies (A,[#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
sorry

mtheorem prob_2_th_26:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P implies ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A,[#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
sorry

mtheorem prob_2_th_27:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds ((A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P & (A,C)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P) & B missesXBOOLE-0R1 C implies (A,B \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> C)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
sorry

mtheorem prob_2_th_28:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds ((A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <XXREAL-0R3 \<one>\<^sub>M) & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) <XXREAL-0R3 \<one>\<^sub>M"
sorry

mdef prob_2_def_6 (" _ .|.PROB-2K3\<^bsub>'( _ , _ ')\<^esub>  _ " [210,0,0,210]210 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma", "B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
"assume 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B func P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B \<rightarrow> ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma means
  \<lambda>it.  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) /REAL-1K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
proof-
  (*existence*)
    show "0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies ( ex it be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma st  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) /REAL-1K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)"
sorry
  (*uniqueness*)
    show "0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies ( for it1 be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for it2 be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds it1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) /REAL-1K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B) & ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds it2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) /REAL-1K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem prob_2_th_29:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
sorry

mtheorem prob_2_th_30:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ((A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)/\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> C) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)*REAL-1K4 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B) .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C"
sorry

mtheorem prob_2_th_31:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for C be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds (C =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(Omega)\<^esub> & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> C .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> C"
sorry

mtheorem prob_2_th_32:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A1 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A2 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A3 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds (((A1 missesXBOOLE-0R1 A2 & A3 =XBOOLE-0R4 (A1 \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> A2)`SUBSET-1K3\<^bsub>(Omega)\<^esub>) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3 implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)+REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A3 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3"
sorry

mtheorem prob_2_th_33:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A iff (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P)"
sorry

mtheorem prob_2_th_34:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds (0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B & P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M) & P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> B) .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A implies (A,B)are-independent-respect-toPROB-2R1\<^bsub>(Omega,Sigma)\<^esub> P"
sorry

mtheorem prob_2_th_35:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies ((P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B <=XXREAL-0R1 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
sorry

mtheorem prob_2_th_36:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A)/REAL-1K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
sorry

mtheorem prob_2_th_37:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A1 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A2 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds ((0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B & A2 =XBOOLE-0R4 A1 `SUBSET-1K3\<^bsub>(Omega)\<^esub>) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2 implies P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1)/REAL-1K6 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2) & P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2 =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)/REAL-1K6 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)"
sorry

mtheorem prob_2_th_38:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A1 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A2 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for A3 be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds ((((0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2) & 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3) & A1 missesXBOOLE-0R1 A2) & A3 =XBOOLE-0R4 (A1 \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> A2)`SUBSET-1K3\<^bsub>(Omega)\<^esub> implies (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1)/REAL-1K6 ((P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)+REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A3 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3) & P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2 =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)/REAL-1K6 ((P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)+REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A3 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3)) & P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3 =COMPLEX1R1 (P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A3 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3)/REAL-1K6 ((P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A1 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A1 +REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A2 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A2)+REAL-1K3 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> A3 .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B *REAL-1K4 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A3)"
sorry

mtheorem prob_2_th_39:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <XXREAL-0R3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B implies \<one>\<^sub>M -XCMPLX-0K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) /REAL-1K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B <=XXREAL-0R1 P .|.PROB-2K3\<^bsub>(Omega,Sigma)\<^esub> B .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
sorry

end
