theory limfunc2
  imports limfunc1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, r2, g, g1, g2, x0, t for "RealXREAL-0M1"
reserve n, k for "NatNAT-1M1"
reserve seq for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma limfunc2_lm_1:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 & r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
sorry

mlemma limfunc2_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X implies (((((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 X) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X"
sorry

mlemma limfunc2_lm_3:
" for r be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r & r <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mlemma limfunc2_lm_4:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X implies (((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 X) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X"
sorry

mtheorem limfunc2_th_1:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & r <XXREAL-0R3 limSEQ-2K1 seq implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies r <XXREAL-0R3 seq .FUNCT-1K1 k)"
sorry

mtheorem limfunc2_th_2:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies seq .FUNCT-1K1 k <XXREAL-0R3 r)"
sorry

mlemma limfunc2_lm_5:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((( for g1 be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st x0 <XXREAL-0R3 r & ( for r1 be RealXREAL-0M1 holds (r1 <XXREAL-0R3 r & x0 <XXREAL-0R3 r1) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1)) & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc2_th_3:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds 0NUMBERSK6 <XXREAL-0R3 r2 & ].RCOMP-1K2 r1 -XCMPLX-0K6 r2,r1 .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 r1 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 r1) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
sorry

mtheorem limfunc2_th_4:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds 0NUMBERSK6 <XXREAL-0R3 r2 & ].RCOMP-1K2 r1,r1 +XCMPLX-0K2 r2 .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for r be RealXREAL-0M1 holds r1 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & r1 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
sorry

mtheorem limfunc2_th_5:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-1K1 n & seq .FUNCT-1K1 n <XXREAL-0R3 x0) & seq .FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
sorry

mtheorem limfunc2_th_6:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds (x0 <XXREAL-0R3 seq .FUNCT-1K1 n & seq .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & seq .FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
sorry

mdef limfunc2_def_1 (" _ is-left-convergent-inLIMFUNC2R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-left-convergent-inLIMFUNC2R1 x0 means
  ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g)"..

mdef limfunc2_def_2 (" _ is-left-divergent-to+infty-inLIMFUNC2R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-left-divergent-to+infty-inLIMFUNC2R2 x0 means
  ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"..

mdef limfunc2_def_3 (" _ is-left-divergent-to-infty-inLIMFUNC2R3  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-left-divergent-to-infty-inLIMFUNC2R3 x0 means
  ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)"..

mdef limfunc2_def_4 (" _ is-right-convergent-inLIMFUNC2R4  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-right-convergent-inLIMFUNC2R4 x0 means
  ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g)"..

mdef limfunc2_def_5 (" _ is-right-divergent-to+infty-inLIMFUNC2R5  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-right-divergent-to+infty-inLIMFUNC2R5 x0 means
  ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"..

mdef limfunc2_def_6 (" _ is-right-divergent-to-infty-inLIMFUNC2R6  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-right-divergent-to-infty-inLIMFUNC2R6 x0 means
  ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)"..

mtheorem limfunc2_th_7:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-convergent-inLIMFUNC2R1 x0 iff ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st r <XXREAL-0R3 x0 & ( for r1 be RealXREAL-0M1 holds (r <XXREAL-0R3 r1 & r1 <XXREAL-0R3 x0) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
sorry

mtheorem limfunc2_th_8:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-divergent-to+infty-inLIMFUNC2R2 x0 iff ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for g1 be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st r <XXREAL-0R3 x0 & ( for r1 be RealXREAL-0M1 holds (r <XXREAL-0R3 r1 & r1 <XXREAL-0R3 x0) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1))"
sorry

mtheorem limfunc2_th_9:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-divergent-to-infty-inLIMFUNC2R3 x0 iff ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for g1 be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st r <XXREAL-0R3 x0 & ( for r1 be RealXREAL-0M1 holds (r <XXREAL-0R3 r1 & r1 <XXREAL-0R3 x0) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1))"
sorry

mtheorem limfunc2_th_10:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-convergent-inLIMFUNC2R4 x0 iff ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st x0 <XXREAL-0R3 r & ( for r1 be RealXREAL-0M1 holds (r1 <XXREAL-0R3 r & x0 <XXREAL-0R3 r1) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
sorry

mtheorem limfunc2_th_11:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-divergent-to+infty-inLIMFUNC2R5 x0 iff ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for g1 be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st x0 <XXREAL-0R3 r & ( for r1 be RealXREAL-0M1 holds (r1 <XXREAL-0R3 r & x0 <XXREAL-0R3 r1) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1))"
sorry

mtheorem limfunc2_th_12:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-divergent-to-infty-inLIMFUNC2R6 x0 iff ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( for g1 be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st x0 <XXREAL-0R3 r & ( for r1 be RealXREAL-0M1 holds (r1 <XXREAL-0R3 r & x0 <XXREAL-0R3 r1) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1))"
sorry

mtheorem limfunc2_th_13:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f2 is-left-divergent-to+infty-inLIMFUNC2R2 x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f2 is-left-divergent-to-infty-inLIMFUNC2R3 x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_15:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & f2 is-right-divergent-to+infty-inLIMFUNC2R5 x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_16:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & f2 is-right-divergent-to-infty-inLIMFUNC2R6 x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_17:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_18:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & 0NUMBERSK6 <XXREAL-0R3 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies r1 <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_19:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_20:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & 0NUMBERSK6 <XXREAL-0R3 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies r1 <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_21:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-divergent-to+infty-inLIMFUNC2R2 x0) & (f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-divergent-to-infty-inLIMFUNC2R3 x0)) & (f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-divergent-to-infty-inLIMFUNC2R3 x0)) & (f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-divergent-to+infty-inLIMFUNC2R2 x0)"
sorry

mtheorem limfunc2_th_22:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f is-right-divergent-to+infty-inLIMFUNC2R5 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-divergent-to+infty-inLIMFUNC2R5 x0) & (f is-right-divergent-to+infty-inLIMFUNC2R5 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-divergent-to-infty-inLIMFUNC2R6 x0)) & (f is-right-divergent-to-infty-inLIMFUNC2R6 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-divergent-to-infty-inLIMFUNC2R6 x0)) & (f is-right-divergent-to-infty-inLIMFUNC2R6 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-divergent-to+infty-inLIMFUNC2R5 x0)"
sorry

mtheorem limfunc2_th_23:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-divergent-to+infty-inLIMFUNC2R2 x0 or f is-left-divergent-to-infty-inLIMFUNC2R3 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_24:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-divergent-to+infty-inLIMFUNC2R5 x0 or f is-right-divergent-to-infty-inLIMFUNC2R6 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_25:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_26:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be increasingVALUED-0V9) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
  using limfunc2_th_25 sorry

mtheorem limfunc2_th_27:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
sorry

mtheorem limfunc2_th_28:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be decreasingVALUED-0V10) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
  using limfunc2_th_27 sorry

mtheorem limfunc2_th_29:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_30:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be decreasingVALUED-0V10) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
  using limfunc2_th_29 sorry

mtheorem limfunc2_th_31:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
sorry

mtheorem limfunc2_th_32:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be increasingVALUED-0V9) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
  using limfunc2_th_31 sorry

mtheorem limfunc2_th_33:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_34:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
sorry

mtheorem limfunc2_th_35:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_36:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
sorry

mtheorem limfunc2_th_37:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to+infty-inLIMFUNC2R2 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_38:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-left-divergent-to-infty-inLIMFUNC2R3 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
sorry

mtheorem limfunc2_th_39:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to+infty-inLIMFUNC2R5 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_40:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-right-divergent-to-infty-inLIMFUNC2R6 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
sorry

mdef limfunc2_def_7 ("lim-leftLIMFUNC2K1'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"assume f is-left-convergent-inLIMFUNC2R1 x0 func lim-leftLIMFUNC2K1(f,x0) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f is-left-convergent-inLIMFUNC2R1 x0 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
sorry
  (*uniqueness*)
    show "f is-left-convergent-inLIMFUNC2R1 x0 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef limfunc2_def_8 ("lim-rightLIMFUNC2K2'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"assume f is-right-convergent-inLIMFUNC2R4 x0 func lim-rightLIMFUNC2K2(f,x0) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f is-right-convergent-inLIMFUNC2R4 x0 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
sorry
  (*uniqueness*)
    show "f is-right-convergent-inLIMFUNC2R4 x0 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem limfunc2_th_41:
" for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-convergent-inLIMFUNC2R1 x0 implies (lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st r <XXREAL-0R3 x0 & ( for r1 be RealXREAL-0M1 holds (r <XXREAL-0R3 r1 & r1 <XXREAL-0R3 x0) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))))"
sorry

mtheorem limfunc2_th_42:
" for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-convergent-inLIMFUNC2R4 x0 implies (lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st x0 <XXREAL-0R3 r & ( for r1 be RealXREAL-0M1 holds (r1 <XXREAL-0R3 r & x0 <XXREAL-0R3 r1) & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))))"
sorry

mtheorem limfunc2_th_43:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-convergent-inLIMFUNC2R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (lim-leftLIMFUNC2K1(f,x0))"
sorry

mtheorem limfunc2_th_44:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-convergent-inLIMFUNC2R1 x0 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 -XCMPLX-0K4 lim-leftLIMFUNC2K1(f,x0)"
sorry

mtheorem limfunc2_th_45:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f1,x0) +XCMPLX-0K2 lim-leftLIMFUNC2K1(f2,x0)"
sorry

mtheorem limfunc2_th_46:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f1,x0) -XCMPLX-0K6 lim-leftLIMFUNC2K1(f2,x0)"
sorry

mtheorem limfunc2_th_47:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-convergent-inLIMFUNC2R1 x0 & f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & lim-leftLIMFUNC2K1(f,x0) <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (lim-leftLIMFUNC2K1(f,x0))\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc2_th_48:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-convergent-inLIMFUNC2R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1  |.COMPLEX1K10 lim-leftLIMFUNC2K1(f,x0) .|"
sorry

mtheorem limfunc2_th_49:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st ((r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (lim-leftLIMFUNC2K1(f,x0))\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc2_th_50:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (lim-leftLIMFUNC2K1(f1,x0))*XCMPLX-0K3 (lim-leftLIMFUNC2K1(f2,x0))"
sorry

mtheorem limfunc2_th_51:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & lim-leftLIMFUNC2K1(f2,x0) <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (lim-leftLIMFUNC2K1(f1,x0))/XCMPLX-0K7 (lim-leftLIMFUNC2K1(f2,x0))"
sorry

mtheorem limfunc2_th_52:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-convergent-inLIMFUNC2R4 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (lim-rightLIMFUNC2K2(f,x0))"
sorry

mtheorem limfunc2_th_53:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-convergent-inLIMFUNC2R4 x0 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 -XCMPLX-0K4 lim-rightLIMFUNC2K2(f,x0)"
sorry

mtheorem limfunc2_th_54:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f1,x0) +XCMPLX-0K2 lim-rightLIMFUNC2K2(f2,x0)"
sorry

mtheorem limfunc2_th_55:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f1,x0) -XCMPLX-0K6 lim-rightLIMFUNC2K2(f2,x0)"
sorry

mtheorem limfunc2_th_56:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-right-convergent-inLIMFUNC2R4 x0 & f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & lim-rightLIMFUNC2K2(f,x0) <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (lim-rightLIMFUNC2K2(f,x0))\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc2_th_57:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-right-convergent-inLIMFUNC2R4 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1  |.COMPLEX1K10 lim-rightLIMFUNC2K2(f,x0) .|"
sorry

mtheorem limfunc2_th_58:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st ((g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (lim-rightLIMFUNC2K2(f,x0))\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc2_th_59:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (lim-rightLIMFUNC2K2(f1,x0))*XCMPLX-0K3 (lim-rightLIMFUNC2K2(f2,x0))"
sorry

mtheorem limfunc2_th_60:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & lim-rightLIMFUNC2K2(f2,x0) <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (lim-rightLIMFUNC2K2(f1,x0))/XCMPLX-0K7 (lim-rightLIMFUNC2K2(f2,x0))"
sorry

mtheorem limfunc2_th_61:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f1,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc2_th_62:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f1,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc2_th_63:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & lim-leftLIMFUNC2K1(f1,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f2,x0)) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[))) implies f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f1,x0)"
sorry

mtheorem limfunc2_th_64:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & lim-leftLIMFUNC2K1(f1,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f2,x0)) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f1,x0)"
sorry

mtheorem limfunc2_th_65:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & lim-rightLIMFUNC2K2(f1,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f2,x0)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[))) implies f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f1,x0)"
sorry

mtheorem limfunc2_th_66:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & lim-rightLIMFUNC2K2(f1,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f2,x0)) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f1,x0)"
sorry

mtheorem limfunc2_th_67:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-left-convergent-inLIMFUNC2R1 x0 & f2 is-left-convergent-inLIMFUNC2R1 x0) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))) implies lim-leftLIMFUNC2K1(f1,x0) <=XXREAL-0R1 lim-leftLIMFUNC2K1(f2,x0)"
sorry

mtheorem limfunc2_th_68:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-right-convergent-inLIMFUNC2R4 x0 & f2 is-right-convergent-inLIMFUNC2R4 x0) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))) implies lim-rightLIMFUNC2K2(f1,x0) <=XXREAL-0R1 lim-rightLIMFUNC2K2(f2,x0)"
sorry

mtheorem limfunc2_th_69:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-divergent-to+infty-inLIMFUNC2R2 x0 or f is-left-divergent-to-infty-inLIMFUNC2R3 x0) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st ((r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc2_th_70:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-right-divergent-to+infty-inLIMFUNC2R5 x0 or f is-right-divergent-to-infty-inLIMFUNC2R6 x0) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st ((g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc2_th_71:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_72:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-divergent-to-infty-inLIMFUNC2R3 x0"
sorry

mtheorem limfunc2_th_73:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_74:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-divergent-to-infty-inLIMFUNC2R6 x0"
sorry

mtheorem limfunc2_th_75:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st ((r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-divergent-to+infty-inLIMFUNC2R2 x0"
sorry

mtheorem limfunc2_th_76:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-left-convergent-inLIMFUNC2R1 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st ((r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-divergent-to-infty-inLIMFUNC2R3 x0"
sorry

mtheorem limfunc2_th_77:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st ((g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc2_th_78:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-right-convergent-inLIMFUNC2R4 x0 & lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st ((g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-divergent-to-infty-inLIMFUNC2R6 x0"
sorry

end
