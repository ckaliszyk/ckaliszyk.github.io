theory rearran1
  imports rfunct_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "NatNAT-1M1"
reserve r for "RealXREAL-0M1"
syntax REARRAN1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')REARRAN1K1\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)REARRAN1K1\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> "r (#)VALUED-1K25 F"

mtheorem rearran1_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,E)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 F as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

mlemma rearran1_lm_1:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  not x inHIDDENR3 rngFUNCT-1K2 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mdef rearran1_def_1 ("terms''ve-same-card-as-numberREARRAN1V1" 70 ) where
"attr terms've-same-card-as-numberREARRAN1V1 for FinSequenceFINSEQ-1M1 means
  (\<lambda>IT.  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 IT implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 IT .FUNCT-1K1 n implies cardCARD-1K4 B =XBOOLE-0R4 n))"..

mdef rearran1_def_2 ("ascendingREARRAN1V2" 70 ) where
"attr ascendingREARRAN1V2 for FinSequenceFINSEQ-1M1 means
  (\<lambda>IT.  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 IT -XCMPLX-0K6 \<one>\<^sub>M implies IT .FUNCT-1K1 n c=TARSKIR1 IT .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"..

mlemma rearran1_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 A implies A .FUNCT-1K1 k be finiteFINSET-1V1"
sorry

mlemma rearran1_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D & A be terms've-same-card-as-numberREARRAN1V1 implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 A .FUNCT-1K1 lenFINSEQ-1K4 A implies B =XBOOLE-0R4 D)"
sorry

mlemma rearran1_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  ex B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st (lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1"
sorry

mdef rearran1_def_3 ("lenght-equal-card-of-setREARRAN1V3\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr lenght-equal-card-of-setREARRAN1V3\<^bsub>(X)\<^esub> for FinSequenceFINSEQ-1M3-of X means
  (\<lambda>IT.  ex B be finiteFINSET-1V1\<bar>setHIDDENM2 st B =XBOOLE-0R4 unionTARSKIK3 X & lenFINSEQ-1K4 IT =XBOOLE-0R4 cardCARD-1K4 B)"..

mtheorem rearran1_cl_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub> for FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st it be terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>"
sorry
qed "sorry"

syntax REARRAN1M1 :: " Set \<Rightarrow> Ty" ("RearrangmentGenREARRAN1M1-of  _ " [70]70)
translations "RearrangmentGenREARRAN1M1-of D" \<rightharpoonup> "terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"

reserve C, D for " non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
reserve a for "FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
mtheorem rearran1_th_1:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds a be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub> iff lenFINSEQ-1K4 a =XBOOLE-0R4 cardCARD-1K4 D"
sorry

mtheorem rearran1_th_2:
" for a be FinSequenceFINSEQ-1M1 holds a be ascendingREARRAN1V2 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 a) & m inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n c=TARSKIR1 a .FUNCT-1K1 m)"
sorry

mtheorem rearran1_th_3:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds a .FUNCT-1K1 lenFINSEQ-1K4 a =XBOOLE-0R4 D"
sorry

mtheorem rearran1_th_4:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds lenFINSEQ-1K4 a <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem rearran1_th_5:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 a & m inTARSKIR2 domFINSEQ-1K5 a) & n <>HIDDENR2 m implies a .FUNCT-1K1 n <>HIDDENR2 a .FUNCT-1K1 m"
sorry

mtheorem rearran1_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 a -XCMPLX-0K6 \<one>\<^sub>M implies a .FUNCT-1K1 n <>HIDDENR2 a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mlemma rearran1_lm_5:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds n inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n c=TARSKIR1 D"
sorry

mtheorem rearran1_th_7:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds n inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n <>HIDDENR2 {}XBOOLE-0K1"
sorry

mtheorem rearran1_th_8:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 a -XCMPLX-0K6 \<one>\<^sub>M implies a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 a .FUNCT-1K1 n <>HIDDENR2 {}XBOOLE-0K1"
sorry

mtheorem rearran1_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  ex d be ElementSUBSET-1M1-of D st a .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 d}"
sorry

mtheorem rearran1_th_10:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 a -XCMPLX-0K6 \<one>\<^sub>M implies ( ex d be ElementSUBSET-1M1-of D st (a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 a .FUNCT-1K1 n =XBOOLE-0R4 {TARSKIK1 d} & a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a .FUNCT-1K1 n \\/XBOOLE-0K2 {TARSKIK1 d}) & a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 d} =XBOOLE-0R4 a .FUNCT-1K1 n)"
sorry

mdef rearran1_def_4 ("Co-GenREARRAN1K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "A be RearrangmentGenREARRAN1M1-of D"
"func Co-GenREARRAN1K2\<^bsub>(D)\<^esub> A \<rightarrow> RearrangmentGenREARRAN1M1-of D means
  \<lambda>it.  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
proof-
  (*existence*)
    show " ex it be RearrangmentGenREARRAN1M1-of D st  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
sorry
  (*uniqueness*)
    show " for it1 be RearrangmentGenREARRAN1M1-of D holds  for it2 be RearrangmentGenREARRAN1M1-of D holds ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it1 -XCMPLX-0K6 \<one>\<^sub>M implies it1 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) & ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it2 -XCMPLX-0K6 \<one>\<^sub>M implies it2 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem REARRAN1K2_involutiveness:
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
" for A be RearrangmentGenREARRAN1M1-of D holds Co-GenREARRAN1K2\<^bsub>(D)\<^esub> (Co-GenREARRAN1K2\<^bsub>(D)\<^esub> A) =HIDDENR1 A"
sorry

(*\$CT*)
mtheorem rearran1_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) =XBOOLE-0R4 lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C))"
sorry

mdef rearran1_def_5 ("RlandREARRAN1K3\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "A be RearrangmentGenREARRAN1M1-of C", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) \<rightarrow> PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) equals
  SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))"
proof-
  (*coherence*)
    show "SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C)) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef rearran1_def_6 ("RlorREARRAN1K4\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "A be RearrangmentGenREARRAN1M1-of C", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) \<rightarrow> PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) equals
  SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A,C))"
proof-
  (*coherence*)
    show "SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A,C)) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem rearran1_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =XBOOLE-0R4 C"
sorry

mtheorem rearran1_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) & ( for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 A) & c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mtheorem rearran1_th_15:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 A) & c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem rearran1_th_16:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
sorry

mtheorem rearran1_th_17:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rearran1_th_18:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
sorry

mtheorem rearran1_th_19:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
sorry

mtheorem rearran1_th_20:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
sorry

mtheorem rearran1_th_21:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =XBOOLE-0R4 C"
sorry

mtheorem rearran1_th_22:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A)) & c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 n implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem rearran1_th_23:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
sorry

mtheorem rearran1_th_24:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rearran1_th_25:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
sorry

mtheorem rearran1_th_26:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
sorry

mtheorem rearran1_th_27:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
sorry

mtheorem rearran1_th_28:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)"
sorry

mtheorem rearran1_th_29:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
sorry

mtheorem rearran1_th_30:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
sorry

mtheorem rearran1_th_31:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C) =XBOOLE-0R4 cardCARD-1K4 C & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)"
sorry

mtheorem rearran1_th_32:
" for n be NatNAT-1M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds (F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C) & n inTARSKIR2 domFINSEQ-1K5 A implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),A .FUNCT-1K1 n)"
sorry

mtheorem rearran1_th_33:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,A) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
sorry

mtheorem rearran1_th_34:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
sorry

mtheorem rearran1_th_35:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
sorry

mtheorem rearran1_th_36:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =XBOOLE-0R4 cardCARD-1K4 C & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C)"
sorry

mtheorem rearran1_th_37:
" for n be NatNAT-1M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds (F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C) & n inTARSKIR2 domFINSEQ-1K5 A implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 n)"
sorry

mtheorem rearran1_th_38:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,A) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
sorry

mtheorem rearran1_th_39:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies (((RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2 & (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2) & rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F) & rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F"
sorry

end
