theory sin_cos5
  imports sin_cos4 sin_cos2 absvalue
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, x1, x2, x3 for "RealXREAL-0M1"
mtheorem sin_cos5_th_1:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 implies cosecSIN-COS4K3 x =COMPLEX1R1 (secSIN-COS4K4 x)/XCMPLX-0K7 (tanSIN-COS4K1 x)"
sorry

mtheorem sin_cos5_th_2:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 x <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 x =COMPLEX1R1 (sinSIN-COSK18 x)*XCMPLX-0K3 (cotSIN-COS4K2 x)"
sorry

mtheorem sin_cos5_th_3:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (sinSIN-COSK18 x1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 x2 <>HIDDENR2 0NUMBERSK6) & sinSIN-COSK18 x3 <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 ((x1 +XCMPLX-0K2 x2)+XCMPLX-0K2 x3) =COMPLEX1R1 (((sinSIN-COSK18 x1)*XCMPLX-0K3 (sinSIN-COSK18 x2))*XCMPLX-0K3 (sinSIN-COSK18 x3))*XCMPLX-0K3 ((((cotSIN-COS4K2 x2)*XCMPLX-0K3 (cotSIN-COS4K2 x3) +XCMPLX-0K2 (cotSIN-COS4K2 x1)*XCMPLX-0K3 (cotSIN-COS4K2 x3))+XCMPLX-0K2 (cotSIN-COS4K2 x1)*XCMPLX-0K3 (cotSIN-COS4K2 x2))-XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos5_th_4:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (sinSIN-COSK18 x1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 x2 <>HIDDENR2 0NUMBERSK6) & sinSIN-COSK18 x3 <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 ((x1 +XCMPLX-0K2 x2)+XCMPLX-0K2 x3) =COMPLEX1R1 -XCMPLX-0K4 (((sinSIN-COSK18 x1)*XCMPLX-0K3 (sinSIN-COSK18 x2))*XCMPLX-0K3 (sinSIN-COSK18 x3))*XCMPLX-0K3 (((cotSIN-COS4K2 x1 +XCMPLX-0K2 cotSIN-COS4K2 x2)+XCMPLX-0K2 cotSIN-COS4K2 x3)-XCMPLX-0K6 ((cotSIN-COS4K2 x1)*XCMPLX-0K3 (cotSIN-COS4K2 x2))*XCMPLX-0K3 (cotSIN-COS4K2 x3))"
sorry

mtheorem sin_cos5_th_5:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x))*XCMPLX-0K3 (cosSIN-COSK20 x)"
sorry

mtheorem sin_cos5_th_6:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (tanSIN-COS4K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos5_th_7:
" for x be RealXREAL-0M1 holds (cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1 & cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) & cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)^2SQUARE-1K1"
sorry

mtheorem sin_cos5_th_8:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos5_th_9:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (tanSIN-COS4K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos5_th_10:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 x <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 ((cotSIN-COS4K2 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (cotSIN-COS4K2 x))"
sorry

mtheorem sin_cos5_th_11:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 implies (secSIN-COS4K4 x)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 x)^2SQUARE-1K1"
sorry

mtheorem sin_cos5_th_12:
" for x be RealXREAL-0M1 holds cotSIN-COS4K2 x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (tanSIN-COS4K1 x)"
  using xcmplx_1_th_57 sorry

mtheorem sin_cos5_th_13:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 x <>HIDDENR2 0NUMBERSK6 implies secSIN-COS4K4 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (secSIN-COS4K4 x)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 x)^2SQUARE-1K1) & secSIN-COS4K4 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (cotSIN-COS4K2 x +XCMPLX-0K2 tanSIN-COS4K1 x)/XCMPLX-0K7 (cotSIN-COS4K2 x -XCMPLX-0K6 tanSIN-COS4K1 x)"
sorry

mtheorem sin_cos5_th_14:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 x <>HIDDENR2 0NUMBERSK6 implies (cosecSIN-COS4K3 x)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 (cotSIN-COS4K2 x)^2SQUARE-1K1"
sorry

mtheorem sin_cos5_th_15:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 x <>HIDDENR2 0NUMBERSK6 implies cosecSIN-COS4K3 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 ((secSIN-COS4K4 x)*XCMPLX-0K3 (cosecSIN-COS4K3 x))/XCMPLX-0K7 \<two>\<^sub>M & cosecSIN-COS4K3 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (tanSIN-COS4K1 x +XCMPLX-0K2 cotSIN-COS4K2 x)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos5_th_16:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 (\<three>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (-XCMPLX-0K4 \<four>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x) |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)"
sorry

mtheorem sin_cos5_th_17:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 (\<three>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 \<four>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x) |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)"
sorry

mtheorem sin_cos5_th_18:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 x <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (\<three>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<three>\<^sub>M *XCMPLX-0K3 (tanSIN-COS4K1 x) -XCMPLX-0K6 (tanSIN-COS4K1 x) |^NEWTONK1 \<three>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (tanSIN-COS4K1 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos5_th_19:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 x <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (\<three>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 ((cotSIN-COS4K2 x) |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (cotSIN-COS4K2 x))/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 (cotSIN-COS4K2 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos5_th_20:
" for x be RealXREAL-0M1 holds (sinSIN-COSK18 x)^2SQUARE-1K1 =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos5_th_21:
" for x be RealXREAL-0M1 holds (cosSIN-COSK20 x)^2SQUARE-1K1 =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem sin_cos5_th_22:
" for x be RealXREAL-0M1 holds (sinSIN-COSK18 x) |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (\<three>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x) -XCMPLX-0K6 sinSIN-COSK18 (\<three>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 \<four>\<^sub>M"
sorry

mtheorem sin_cos5_th_23:
" for x be RealXREAL-0M1 holds (cosSIN-COSK20 x) |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (\<three>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x) +XCMPLX-0K2 cosSIN-COSK20 (\<three>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 \<four>\<^sub>M"
sorry

mtheorem sin_cos5_th_24:
" for x be RealXREAL-0M1 holds (sinSIN-COSK18 x) |^NEWTONK1 \<four>\<^sub>M =COMPLEX1R1 ((\<three>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 cosSIN-COSK20 (\<four>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 \<eight>\<^sub>M"
sorry

mtheorem sin_cos5_th_25:
" for x be RealXREAL-0M1 holds (cosSIN-COSK20 x) |^NEWTONK1 \<four>\<^sub>M =COMPLEX1R1 ((\<three>\<^sub>M +XCMPLX-0K2 \<four>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 cosSIN-COSK20 (\<four>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 \<eight>\<^sub>M"
sorry

mtheorem sin_cos5_th_26:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M) or sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos5_th_27:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M) or cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos5_th_28:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 (sinSIN-COSK18 x)"
sorry

mtheorem sin_cos5_th_29:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinSIN-COSK18 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)"
sorry

mtheorem sin_cos5_th_30:
" for x be RealXREAL-0M1 holds tanSIN-COS4K1 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)) or tanSIN-COS4K1 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x))"
sorry

mtheorem sin_cos5_th_31:
" for x be RealXREAL-0M1 holds cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 (sinSIN-COSK18 x)"
sorry

mtheorem sin_cos5_th_32:
" for x be RealXREAL-0M1 holds sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinSIN-COSK18 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)"
sorry

mtheorem sin_cos5_th_33:
" for x be RealXREAL-0M1 holds cotSIN-COS4K2 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)) or cotSIN-COS4K2 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x))"
sorry

mtheorem sin_cos5_th_34:
" for x be RealXREAL-0M1 holds (sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6) & \<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6 implies secSIN-COS4K4 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (secSIN-COS4K4 x))/XCMPLX-0K7 (secSIN-COS4K4 x +XCMPLX-0K2 \<one>\<^sub>M)) or secSIN-COS4K4 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (secSIN-COS4K4 x))/XCMPLX-0K7 (secSIN-COS4K4 x +XCMPLX-0K2 \<one>\<^sub>M))"
sorry

mtheorem sin_cos5_th_35:
" for x be RealXREAL-0M1 holds (sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6) & \<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6 implies cosecSIN-COS4K3 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (secSIN-COS4K4 x))/XCMPLX-0K7 (secSIN-COS4K4 x -XCMPLX-0K6 \<one>\<^sub>M)) or cosecSIN-COS4K3 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (secSIN-COS4K4 x))/XCMPLX-0K7 (secSIN-COS4K4 x -XCMPLX-0K6 \<one>\<^sub>M))"
sorry

mdef sin_cos5_def_1 ("cothSIN-COS5K1  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func cothSIN-COS5K1 x \<rightarrow> RealXREAL-0M1 equals
  (coshSIN-COS2K4 x)/XCMPLX-0K7 (sinhSIN-COS2K2 x)"
proof-
  (*coherence*)
    show "(coshSIN-COS2K4 x)/XCMPLX-0K7 (sinhSIN-COS2K2 x) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos5_def_2 ("sechSIN-COS5K2  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func sechSIN-COS5K2 x \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M /XCMPLX-0K7 (coshSIN-COS2K4 x)"
proof-
  (*coherence*)
    show "\<one>\<^sub>M /XCMPLX-0K7 (coshSIN-COS2K4 x) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos5_def_3 ("cosechSIN-COS5K3  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func cosechSIN-COS5K3 x \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M /XCMPLX-0K7 (sinhSIN-COS2K2 x)"
proof-
  (*coherence*)
    show "\<one>\<^sub>M /XCMPLX-0K7 (sinhSIN-COS2K2 x) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem sin_cos5_th_36:
" for x be RealXREAL-0M1 holds (cothSIN-COS5K1 x =COMPLEX1R1 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)) & sechSIN-COS5K2 x =COMPLEX1R1 \<two>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))) & cosechSIN-COS5K3 x =COMPLEX1R1 \<two>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
sorry

mtheorem sin_cos5_th_37:
" for x be RealXREAL-0M1 holds exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x) <>HIDDENR2 0NUMBERSK6 implies (tanhSIN-COS2K6 x)*XCMPLX-0K3 (cothSIN-COS5K1 x) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos5_th_38:
" for x be RealXREAL-0M1 holds (sechSIN-COS5K2 x)^2SQUARE-1K1 +XCMPLX-0K2 (tanhSIN-COS2K6 x)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos5_th_39:
" for x be RealXREAL-0M1 holds sinhSIN-COS2K2 x <>HIDDENR2 0NUMBERSK6 implies (cothSIN-COS5K1 x)^2SQUARE-1K1 -XCMPLX-0K6 (cosechSIN-COS5K3 x)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M"
sorry

mlemma sin_cos5_lm_1:
" for x be RealXREAL-0M1 holds cothSIN-COS5K1 (-XCMPLX-0K4 x) =COMPLEX1R1 -XCMPLX-0K4 cothSIN-COS5K1 x"
sorry

mtheorem sin_cos5_th_40:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds sinhSIN-COS2K2 x1 <>HIDDENR2 0NUMBERSK6 & sinhSIN-COS2K2 x2 <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 (cothSIN-COS5K1 x1)*XCMPLX-0K3 (cothSIN-COS5K1 x2))/XCMPLX-0K7 (cothSIN-COS5K1 x1 +XCMPLX-0K2 cothSIN-COS5K1 x2)"
sorry

mtheorem sin_cos5_th_41:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds sinhSIN-COS2K2 x1 <>HIDDENR2 0NUMBERSK6 & sinhSIN-COS2K2 x2 <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 (x1 -XCMPLX-0K6 x2) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 (cothSIN-COS5K1 x1)*XCMPLX-0K3 (cothSIN-COS5K1 x2))/XCMPLX-0K7 (cothSIN-COS5K1 x1 -XCMPLX-0K6 cothSIN-COS5K1 x2)"
sorry

mtheorem sin_cos5_th_42:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds sinhSIN-COS2K2 x1 <>HIDDENR2 0NUMBERSK6 & sinhSIN-COS2K2 x2 <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 x1 +XCMPLX-0K2 cothSIN-COS5K1 x2 =COMPLEX1R1 (sinhSIN-COS2K2 (x1 +XCMPLX-0K2 x2))/XCMPLX-0K7 ((sinhSIN-COS2K2 x1)*XCMPLX-0K3 (sinhSIN-COS2K2 x2)) & cothSIN-COS5K1 x1 -XCMPLX-0K6 cothSIN-COS5K1 x2 =COMPLEX1R1 -XCMPLX-0K4 (sinhSIN-COS2K2 (x1 -XCMPLX-0K6 x2))/XCMPLX-0K7 ((sinhSIN-COS2K2 x1)*XCMPLX-0K3 (sinhSIN-COS2K2 x2))"
sorry

mlemma sin_cos5_lm_2:
" for x be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 x)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x)^2SQUARE-1K1"
sorry

mlemma sin_cos5_lm_3:
" for x be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 ((sinhSIN-COS2K1).FUNCT-1K1 x)^2SQUARE-1K1"
sorry

mtheorem sin_cos5_th_43:
" for x be RealXREAL-0M1 holds sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 \<three>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x) +XCMPLX-0K2 \<four>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x) |^NEWTONK1 \<three>\<^sub>M"
sorry

mtheorem sin_cos5_th_44:
" for x be RealXREAL-0M1 holds coshSIN-COS2K4 (\<three>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 \<four>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x) |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x)"
sorry

mtheorem sin_cos5_th_45:
" for x be RealXREAL-0M1 holds sinhSIN-COS2K2 x <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 (cothSIN-COS5K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (cothSIN-COS5K1 x))"
sorry

mlemma sin_cos5_lm_4:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies sinhSIN-COS2K2 x >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos5_th_46:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies sinhSIN-COS2K2 x >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos5_th_47:
" for x be RealXREAL-0M1 holds x <=XXREAL-0R1 0NUMBERSK6 implies sinhSIN-COS2K2 x <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem sin_cos5_th_48:
" for x be RealXREAL-0M1 holds coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((coshSIN-COS2K4 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos5_th_49:
" for x be RealXREAL-0M1 holds sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (sinhSIN-COS2K2 x)"
sorry

mtheorem sin_cos5_th_50:
" for x be RealXREAL-0M1 holds coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinhSIN-COS2K2 x)/XCMPLX-0K7 (coshSIN-COS2K4 x +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem sin_cos5_th_51:
" for x be RealXREAL-0M1 holds sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinhSIN-COS2K2 x)/XCMPLX-0K7 (coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos5_th_52:
" for x be RealXREAL-0M1 holds coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 (x /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (coshSIN-COS2K4 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (sinhSIN-COS2K2 x)"
sorry

end
