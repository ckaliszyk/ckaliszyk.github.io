theory power
  imports prepower abian
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, e for "RealXREAL-0M1"
reserve m, n, m1, m2 for "NatNAT-1M1"
reserve k, l for "IntegerINT-1M1"
reserve p for "RationalRAT-1M1"
mtheorem power_th_1:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be evenABIANV3 implies (-XCMPLX-0K4 a) |^NEWTONK1 n =COMPLEX1R1 a  |^NEWTONK1 n"
sorry

mtheorem power_th_2:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be oddABIANV2 implies (-XCMPLX-0K4 a) |^NEWTONK1 n =COMPLEX1R1 -XCMPLX-0K4 a  |^NEWTONK1 n"
sorry

mtheorem power_th_3:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 or n be evenABIANV3 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
sorry

mdef power_def_1 (" _ -rootPOWERK1  _ " [300,300]300 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "a be RealXREAL-0M1"
"func n -rootPOWERK1 a \<rightarrow> RealXREAL-0M1 equals
  n -RootPREPOWERK2 a if a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M,
  -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a) if a <XXREAL-0R3 0NUMBERSK6 & n be oddABIANV2"
proof-
  (*consistency*)
    show " for it be RealXREAL-0M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & (a <XXREAL-0R3 0NUMBERSK6 & n be oddABIANV2) implies (it =HIDDENR1 n -RootPREPOWERK2 a iff it =HIDDENR1 -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a))"
       sorry
  (*coherence*)
    show "(a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a be RealXREAL-0M1) & (a <XXREAL-0R3 0NUMBERSK6 & n be oddABIANV2 implies -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a) be RealXREAL-0M1)"
       sorry
qed "sorry"

mtheorem power_th_4:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2 implies n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
sorry

mtheorem power_th_5:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem power_th_6:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem power_th_7:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem power_th_8:
" for n be NatNAT-1M1 holds n be oddABIANV2 implies n -rootPOWERK1 (-XCMPLX-0K4 \<one>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem power_th_9:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M -rootPOWERK1 a =COMPLEX1R1 a"
sorry

mtheorem power_th_10:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be oddABIANV2 implies n -rootPOWERK1 a =COMPLEX1R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
sorry

mtheorem power_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6) & b >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
sorry

mtheorem power_th_12:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M or a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
sorry

mtheorem power_th_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M or b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (a /XCMPLX-0K7 b) =COMPLEX1R1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
sorry

mtheorem power_th_14:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2 implies n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
sorry

mtheorem power_th_15:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2 implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
sorry

mtheorem power_th_16:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <=XXREAL-0R1 b & (0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2) implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
sorry

mtheorem power_th_17:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <XXREAL-0R3 b & (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2) implies n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
sorry

mtheorem power_th_18:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -rootPOWERK1 a"
sorry

mtheorem power_th_19:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & n be oddABIANV2 implies n -rootPOWERK1 a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 n -rootPOWERK1 a"
sorry

mtheorem power_th_20:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & n >=XXREAL-0R2 \<one>\<^sub>M implies a <=XXREAL-0R1 n -rootPOWERK1 a & n -rootPOWERK1 a <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem power_th_21:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 0NUMBERSK6) & n be oddABIANV2 implies a >=XXREAL-0R2 n -rootPOWERK1 a & n -rootPOWERK1 a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem power_th_22:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
sorry

mtheorem power_th_23:
" for s be Real-SequenceSEQ-1M1 holds  for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
sorry

mdef power_def_2 (" _ to-powerPOWERK2  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
" func a to-powerPOWERK2 b \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. it =COMPLEX1R1 a #RPREPOWERK6 b if a >XXREAL-0R4 0NUMBERSK6,
  \<lambda>it. it =COMPLEX1R1 0NUMBERSK6 if a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6,
  \<lambda>it.  ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k if b be IntegerINT-1M1"
proof-
  (*consistency*)
    show " for it be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & (a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) implies (it =COMPLEX1R1 a #RPREPOWERK6 b iff it =COMPLEX1R1 0NUMBERSK6)) & (a >XXREAL-0R4 0NUMBERSK6 & b be IntegerINT-1M1 implies (it =COMPLEX1R1 a #RPREPOWERK6 b iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k)))) & ((a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & b be IntegerINT-1M1 implies (it =COMPLEX1R1 0NUMBERSK6 iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k)))"
sorry
  (*existence*)
    show "(a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 a #RPREPOWERK6 b)) & ((a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6)) & (b be IntegerINT-1M1 implies ( ex it be RealXREAL-0M1 st  ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k)))"
sorry
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 implies (it1 =COMPLEX1R1 a #RPREPOWERK6 b & it2 =COMPLEX1R1 a #RPREPOWERK6 b implies it1 =HIDDENR1 it2)) & ((a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & (b be IntegerINT-1M1 implies (( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it1 =COMPLEX1R1 a #ZPREPOWERK3 k) & ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it2 =COMPLEX1R1 a #ZPREPOWERK3 k) implies it1 =HIDDENR1 it2)))"
       sorry
qed "sorry"

mtheorem power_th_24:
" for a be RealXREAL-0M1 holds a to-powerPOWERK2 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem power_th_25:
" for a be RealXREAL-0M1 holds a to-powerPOWERK2 \<one>\<^sub>M =COMPLEX1R1 a"
sorry

mtheorem power_th_26:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M to-powerPOWERK2 a =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem power_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (b +XCMPLX-0K2 c) =COMPLEX1R1 a to-powerPOWERK2 b *XCMPLX-0K3 a to-powerPOWERK2 c"
sorry

mtheorem power_th_28:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 c"
sorry

mtheorem power_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (b -XCMPLX-0K6 c) =COMPLEX1R1 a to-powerPOWERK2 b /XCMPLX-0K7 a to-powerPOWERK2 c"
sorry

mtheorem power_th_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c *XCMPLX-0K3 b to-powerPOWERK2 c"
sorry

mtheorem power_th_31:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c /XCMPLX-0K7 b to-powerPOWERK2 c"
sorry

mtheorem power_th_32:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 b =COMPLEX1R1 a to-powerPOWERK2 (-XCMPLX-0K4 b)"
sorry

mtheorem power_th_33:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a to-powerPOWERK2 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 c)"
sorry

mtheorem power_th_34:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 b >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem power_th_35:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 b >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem power_th_36:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b <XXREAL-0R3 0NUMBERSK6 implies a to-powerPOWERK2 b <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem power_th_37:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 b) & c >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 c <XXREAL-0R3 b to-powerPOWERK2 c"
sorry

mtheorem power_th_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 b) & c <XXREAL-0R3 0NUMBERSK6 implies a to-powerPOWERK2 c >XXREAL-0R4 b to-powerPOWERK2 c"
sorry

mtheorem power_th_39:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 b & c >XXREAL-0R4 \<one>\<^sub>M implies c to-powerPOWERK2 a <XXREAL-0R3 c to-powerPOWERK2 b"
sorry

mtheorem power_th_40:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <XXREAL-0R3 b & c >XXREAL-0R4 0NUMBERSK6) & c <XXREAL-0R3 \<one>\<^sub>M implies c to-powerPOWERK2 a >XXREAL-0R4 c to-powerPOWERK2 b"
sorry

mtheorem power_ident_1:
  mlet "a be RealXREAL-0M1", "n be NatNAT-1M1"
"identify a to-powerPOWERK2 n with a  |^NEWTONK1 n"
proof
(*compatibility*)
  show "a to-powerPOWERK2 n =HIDDENR1 a  |^NEWTONK1 n"
sorry
qed "sorry"

mtheorem power_th_41:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a to-powerPOWERK2 n =COMPLEX1R1 a  |^NEWTONK1 n"
   sorry

mtheorem power_th_42:
" for k be IntegerINT-1M1 holds k <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6)to-powerPOWERK2 k =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem power_th_43:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a to-powerPOWERK2 k =COMPLEX1R1 a #ZPREPOWERK3 k"
  using power_def_2 sorry

mtheorem power_th_44:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 p =COMPLEX1R1 a #QPREPOWERK4 p"
sorry

mtheorem power_th_45:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =COMPLEX1R1 n -rootPOWERK1 a"
sorry

mtheorem power_th_46:
" for a be RealXREAL-0M1 holds a to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 a ^2SQUARE-1K1"
sorry

mtheorem power_th_47:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds k be evenABIANV1 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k"
sorry

mtheorem power_th_48:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds k be oddABIANV2 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
sorry

mtheorem power_th_49:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a)to-powerPOWERK2 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a"
  using prepower_th_16 sorry

mtheorem power_th_50:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & c <>HIDDENR2 d implies a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
sorry

mdef power_def_3 ("logPOWERK3'( _ , _ ')" [0,0]300 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"assume a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) func logPOWERK3(a,b) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. a to-powerPOWERK2 it =COMPLEX1R1 b"
proof-
  (*existence*)
    show "a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) implies ( ex it be RealXREAL-0M1 st a to-powerPOWERK2 it =COMPLEX1R1 b)"
sorry
  (*uniqueness*)
    show "a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds a to-powerPOWERK2 it1 =COMPLEX1R1 b & a to-powerPOWERK2 it2 =COMPLEX1R1 b implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem power_th_51:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M implies logPOWERK3(a,\<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem power_th_52:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M implies logPOWERK3(a,a) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem power_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,b) +XCMPLX-0K2 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b *XCMPLX-0K3 c)"
sorry

mtheorem power_th_54:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,b) -XCMPLX-0K6 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b /XCMPLX-0K7 c)"
sorry

mtheorem power_th_55:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,b to-powerPOWERK2 c) =COMPLEX1R1 c *XCMPLX-0K3 logPOWERK3(a,b)"
sorry

mtheorem power_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & b <>HIDDENR2 \<one>\<^sub>M) & c >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b) *XCMPLX-0K3 logPOWERK3(b,c)"
sorry

mtheorem power_th_57:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 b implies logPOWERK3(a,c) >XXREAL-0R4 logPOWERK3(a,b)"
sorry

mtheorem power_th_58:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 b implies logPOWERK3(a,c) <XXREAL-0R3 logPOWERK3(a,b)"
sorry

mtheorem power_th_59:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies s be convergentSEQ-2V5"
sorry

mdef power_def_4 ("number-ePOWERK4" 164 ) where
"func number-ePOWERK4 \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it =COMPLEX1R1 limSEQ-2K1 s"
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it =COMPLEX1R1 limSEQ-2K1 s"
sorry
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it1 =COMPLEX1R1 limSEQ-2K1 s) & ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it2 =COMPLEX1R1 limSEQ-2K1 s) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem power_th_60:
"\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 \<four>\<^sub>M"
sorry

mtheorem power_th_61:
"\<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M =COMPLEX1R1 \<eight>\<^sub>M"
sorry

mtheorem power_th_62:
"\<two>\<^sub>M to-powerPOWERK2 \<four>\<^sub>M =COMPLEX1R1 \<one>\<six>\<^sub>M"
sorry

mtheorem power_th_63:
"\<two>\<^sub>M to-powerPOWERK2 \<five>\<^sub>M =COMPLEX1R1 \<three>\<two>\<^sub>M"
sorry

mtheorem power_th_64:
"\<two>\<^sub>M to-powerPOWERK2 \<six>\<^sub>M =COMPLEX1R1 \<six>\<four>\<^sub>M"
sorry

end
