theory euler_2
  imports recdef_1 euler_1 wsierp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, m, x, n, l, xi, xj for "NatNAT-1M1"
reserve t, z for "IntegerINT-1M1"
reserve f, F for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mlemma euler_2_lm_1:
" for t be IntegerINT-1M1 holds t <XXREAL-0R3 \<one>\<^sub>M iff t <=XXREAL-0R1 0NUMBERSK6"
sorry

mlemma euler_2_lm_2:
" for a be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
sorry

mlemma euler_2_lm_3:
" for z be IntegerINT-1M1 holds \<one>\<^sub>M gcdINT-2K3 z =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem euler_2_th_1:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds (a,b)are-coprimeINT-2R1 iff (a,b)are-coprimeINT-2R1"
   sorry

mtheorem euler_2_th_2:
" for m be NatNAT-1M1 holds  for t be IntegerINT-1M1 holds m *XCMPLX-0K3 t >=XXREAL-0R2 \<one>\<^sub>M implies t >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mlemma euler_2_lm_4:
" for m be NatNAT-1M1 holds  for z be IntegerINT-1M1 holds (\<one>\<^sub>M -XCMPLX-0K6 m <=XXREAL-0R1 z & z <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M) & m dividesINT-1R1 z implies z =HIDDENR1 0NUMBERSK6"
sorry

mtheorem euler_2_th_3:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (((a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & m <>HIDDENR2 0NUMBERSK6) & (a,m)are-coprimeINT-2R1) & (b,m)are-coprimeINT-2R1 implies (m,a *XCMPLX-0K3 b modNAT-DK4 m)are-coprimeINT-2R1"
sorry

mtheorem euler_2_th_4:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m >XXREAL-0R4 \<one>\<^sub>M & (m,n)are-coprimeINT-2R1) & n =XBOOLE-0R4 a *XCMPLX-0K3 b modNAT-DK4 m implies (m,b)are-coprimeINT-2R1"
sorry

mtheorem euler_2_th_5:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m modNAT-DK4 n)modNAT-DK4 n =XBOOLE-0R4 m modNAT-DK4 n"
sorry

mtheorem euler_2_th_6:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (l +XCMPLX-0K2 m)modNAT-DK4 n =XBOOLE-0R4 ((l modNAT-DK4 n)+NAT-1K1 (m modNAT-DK4 n))modNAT-DK4 n"
sorry

mtheorem euler_2_th_7:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
sorry

mtheorem euler_2_th_8:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 (l modNAT-DK4 n)*XCMPLX-0K3 m modNAT-DK4 n"
  using euler_2_th_7 sorry

mtheorem euler_2_th_9:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 (l modNAT-DK4 n)*NAT-1K2 (m modNAT-DK4 n) modNAT-DK4 n"
sorry

(*begin*)
abbreviation(input) EULER_2K1(" _ *EULER-2K1  _ " [164,164]164) where
  "a *EULER-2K1 f \<equiv> a *RVSUM-1K11 f"

mtheorem euler_2_add_1:
  mlet "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "a be NatNAT-1M1"
"cluster a *RVSUM-1K11 f as-term-is FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof
(*coherence*)
  show "a *RVSUM-1K11 f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
sorry
qed "sorry"

mtheorem euler_2_th_10:
" for R1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for R2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (R1,R2)are-fiberwise-equipotentCLASSES1R2 implies ProductWSIERP-1K2 R1 =XBOOLE-0R4 ProductWSIERP-1K2 R2"
sorry

(*begin*)
mdef euler_2_def_1 (" _ modEULER-2K2  _ " [132,132]132 ) where
  mlet "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "m be NatNAT-1M1"
"func f modEULER-2K2 m \<rightarrow> FinSequenceFINSEQ-1M3-of NATNUMBERSK1 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for it2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it1 .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it2 .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem euler_2_th_11:
" for m be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
sorry

mtheorem euler_2_th_12:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ((a <>HIDDENR2 0NUMBERSK6 & m >XXREAL-0R4 \<one>\<^sub>M) & a *XCMPLX-0K3 n modNAT-DK4 m =XBOOLE-0R4 n modNAT-DK4 m) & (m,n)are-coprimeINT-2R1 implies a modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem euler_2_th_13:
" for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (F modEULER-2K2 m)modEULER-2K2 m =FINSEQ-1R1 F modEULER-2K2 m"
sorry

mtheorem euler_2_th_14:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m =FINSEQ-1R1 a *EULER-2K1 F modEULER-2K2 m"
sorry

mtheorem euler_2_th_15:
" for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m =FINSEQ-1R1 (F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)"
sorry

mtheorem euler_2_th_16:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m =FINSEQ-1R1 (a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)"
sorry

mtheorem euler_2_th_17:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 0NUMBERSK6) & (a,m)are-coprimeINT-2R1 implies ( for b be NatNAT-1M1 holds (a  |^NEWTONK1 b,m)are-coprimeINT-2R1)"
sorry

(*begin*)
(*\$N Euler's Generalization of Fermat's Little Theorem*)
mtheorem euler_2_th_18:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m >XXREAL-0R4 \<one>\<^sub>M) & (a,m)are-coprimeINT-2R1 implies a  |^NEWTONK1 EulerEULER-1K1 m modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
sorry

(*\$N Small Fermat's Theorem*)
mtheorem euler_2_th_19:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m be primeINT-2V1) & (a,m)are-coprimeINT-2R1 implies a  |^NEWTONK1 m modNAT-DK4 m =XBOOLE-0R4 a modNAT-DK4 m"
sorry

end
