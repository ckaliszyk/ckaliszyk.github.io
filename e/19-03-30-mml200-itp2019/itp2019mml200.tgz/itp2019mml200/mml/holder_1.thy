theory holder_1
  imports taylor_1 int_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, p, q for "RealXREAL-0M1"
mtheorem holder_1_cl_1:
  mlet "x be RealXREAL-0M1"
"cluster right-closed-halflineLIMFUNC1K3 x as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "right-closed-halflineLIMFUNC1K3 x be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem holder_1_th_1:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & 0NUMBERSK6 <XXREAL-0R3 q implies ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies a to-powerPOWERK2 p *XCMPLX-0K3 a to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p +XCMPLX-0K2 q))"
sorry

mtheorem holder_1_th_2:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & 0NUMBERSK6 <XXREAL-0R3 q implies ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies (a to-powerPOWERK2 p)to-powerPOWERK2 q =COMPLEX1R1 a to-powerPOWERK2 (p *XCMPLX-0K3 q))"
sorry

mtheorem holder_1_th_3:
" for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 b implies a to-powerPOWERK2 p <=XXREAL-0R1 b to-powerPOWERK2 p)"
sorry

mtheorem holder_1_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ((\<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M) & 0NUMBERSK6 <XXREAL-0R3 a) & 0NUMBERSK6 <XXREAL-0R3 b implies a *XCMPLX-0K3 b <=XXREAL-0R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q & (a *XCMPLX-0K3 b =COMPLEX1R1 a #RPREPOWERK6 p /XCMPLX-0K7 p +XCMPLX-0K2 b #RPREPOWERK6 q /XCMPLX-0K7 q iff a #RPREPOWERK6 p =COMPLEX1R1 b #RPREPOWERK6 q)"
sorry

mtheorem holder_1_th_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ((\<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 a) & 0NUMBERSK6 <=XXREAL-0R1 b implies a *XCMPLX-0K3 b <=XXREAL-0R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q & (a *XCMPLX-0K3 b =COMPLEX1R1 a to-powerPOWERK2 p /XCMPLX-0K7 p +XCMPLX-0K2 b to-powerPOWERK2 q /XCMPLX-0K7 q iff a to-powerPOWERK2 p =COMPLEX1R1 b to-powerPOWERK2 q)"
sorry

mlemma holder_1_lm_1:
" for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mlemma holder_1_lm_2:
" for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mlemma holder_1_lm_3:
" for a be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies ( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6))"
sorry

mlemma holder_1_lm_4:
" for a be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds k <=XXREAL-0R1 n implies a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6) implies Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
sorry

(*begin*)
mtheorem holder_1_th_6:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bq be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 (Partial-SumsSERIES-1K3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q)))"
sorry

mtheorem holder_1_th_7:
" for p be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bp be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p) implies ( for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 (Partial-SumsSERIES-1K3 ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 (Partial-SumsSERIES-1K3 bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p)))"
sorry

mtheorem holder_1_th_8:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & b be convergentSEQ-2V5) & a be non-decreasingVALUED-0V11 implies a be convergentSEQ-2V5 & limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b"
sorry

mtheorem holder_1_th_9:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & b be convergentSEQ-2V5) & c be convergentSEQ-2V5) & a be non-decreasingVALUED-0V11 implies a be convergentSEQ-2V5 & limSEQ-2K1 a <=XXREAL-0R1 limSEQ-2K1 b +XCMPLX-0K2 limSEQ-2K1 c"
sorry

mtheorem holder_1_th_10:
" for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds (a be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p) implies ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 (limSEQ-2K1 a)to-powerPOWERK2 p)"
sorry

mtheorem holder_1_th_11:
" for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds (a be summableSERIES-1V1 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (Partial-SumsSERIES-1K3 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)to-powerPOWERK2 p) implies ((ap be convergentSEQ-2V5 & limSEQ-2K1 ap =COMPLEX1R1 SumSERIES-1K4 a to-powerPOWERK2 p) & ap be non-decreasingVALUED-0V11) & ( for n be NatNAT-1M1 holds ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 SumSERIES-1K4 a to-powerPOWERK2 p))"
sorry

mtheorem holder_1_th_12:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p & \<one>\<^sub>M /XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 q =COMPLEX1R1 \<one>\<^sub>M implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bq be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 q) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|) & ap be summableSERIES-1V1) & bq be summableSERIES-1V1 implies ab be summableSERIES-1V1 & SumSERIES-1K4 ab <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) *XCMPLX-0K3 SumSERIES-1K4 bq to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 q))"
sorry

mtheorem holder_1_th_13:
" for p be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 p implies ( for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for ap be Real-SequenceSEQ-1M1 holds  for bp be Real-SequenceSEQ-1M1 holds  for ab be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds (ap .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p & bp .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)to-powerPOWERK2 p) & ab .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|)to-powerPOWERK2 p) & ap be summableSERIES-1V1) & bp be summableSERIES-1V1 implies ab be summableSERIES-1V1 & SumSERIES-1K4 ab to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) <=XXREAL-0R1 SumSERIES-1K4 ap to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p) +XCMPLX-0K2 SumSERIES-1K4 bp to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 p))"
sorry

end
