theory polyeq_3
  imports polyeq_1 comptrig
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, a9, b9, c9, d9, y, x1, u, v for "RealXREAL-0M1"
reserve s, t, h, z, z1, z2, z3, s1, s2, s3 for "ComplexXCMPLX-0M1"
abbreviation(input) POLYEQ_3K1(" _ ^2POLYEQ-3K1" [354]354) where
  "z ^2POLYEQ-3K1 \<equiv> z ^2SQUARE-1K1"

mtheorem polyeq_3_def_1:
  mlet "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"redefine func z ^2POLYEQ-3K1 \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z ^2POLYEQ-3K1 iff it =HIDDENR1 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry
qed "sorry"

mtheorem polyeq_3_add_1:
  mlet "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"cluster z ^2SQUARE-1K1 as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z ^2SQUARE-1K1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

(*\$CD*)
abbreviation(input) POLYEQ_3K2("PolynomPOLYEQ-3K2'( _ , _ , _ , _ ')" [0,0,0,0]164) where
  "PolynomPOLYEQ-3K2(a,b,c,z) \<equiv> PolynomPOLYEQ-1K2(a,b,c,z)"

mtheorem polyeq_3_add_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "z be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-1K2(a,b,c,z) as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K2(a,b,c,z) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem polyeq_3_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
sorry

mtheorem polyeq_3_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_3:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(0NUMBERSK6,b,c,z) =COMPLEX1R1 0NUMBERSK6) implies z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 b"
sorry

mtheorem polyeq_3_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(a,b,c,z) =XBOOLE-0R4 QuardPOLYEQ-1K3(a,z1,z2,z)) implies b /XCMPLX-0K7 a =COMPLEX1R1 -XCMPLX-0K4 (z1 +XCMPLX-0K2 z2) & c /XCMPLX-0K7 a =COMPLEX1R1 z1 *XCMPLX-0K3 z2"
sorry

mdef polyeq_3_def_3 (" _ ^3POLYEQ-3K3" [354]354 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z ^3POLYEQ-3K3 \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  z ^2SQUARE-1K1 *XCMPLX-0K3 z"
proof-
  (*coherence*)
    show "z ^2SQUARE-1K1 *XCMPLX-0K3 z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

mlemma polyeq_3_lm_1:
" for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 \<two>\<^sub>M =COMPLEX1R1 z *XCMPLX-0K3 z"
sorry

abbreviation(input) POLYEQ_3K4("PolynomPOLYEQ-3K4'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164) where
  "PolynomPOLYEQ-3K4(a,b,c,d,z) \<equiv> PolynomPOLYEQ-1K4(a,b,c,d,z)"

mtheorem polyeq_3_def_4:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "z be ComplexXCMPLX-0M1"
"redefine func PolynomPOLYEQ-3K4(a,b,c,d,z) \<rightarrow> setHIDDENM2 equals
  ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 PolynomPOLYEQ-3K4(a,b,c,d,z) iff it =HIDDENR1 ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
sorry
qed "sorry"

mtheorem polyeq_3_th_5:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z ^3POLYEQ-3K3 =COMPLEX1R1 ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 z ^3POLYEQ-3K3 =COMPLEX1R1 (-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z"
sorry

mtheorem polyeq_3_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for a9 be RealXREAL-0M1 holds  for b9 be RealXREAL-0M1 holds  for c9 be RealXREAL-0M1 holds  for d9 be RealXREAL-0M1 holds ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,z)) implies ((a =COMPLEX1R1 a9 & b =COMPLEX1R1 b9) & c =COMPLEX1R1 c9) & d =COMPLEX1R1 d9"
sorry

mtheorem polyeq_3_th_7:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 ((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b) or z =COMPLEX1R1 ((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)) or z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)"
sorry

mtheorem polyeq_3_th_8:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_9:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <=XXREAL-0R1 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ((z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_12:
" for a be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y ^2SQUARE-1K1 =COMPLEX1R1 a implies y =COMPLEX1R1 sqrtSQUARE-1K3 a or y =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 a"
sorry

mtheorem polyeq_3_th_13:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 a =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) or z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M))) or z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))"
sorry

mtheorem polyeq_3_th_14:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) =COMPLEX1R1 0NUMBERSK6 implies ((((z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8))"
sorry

mtheorem polyeq_3_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 0NUMBERSK6) & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds (x1 =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a) & ReCOMPLEX1K3 z =COMPLEX1R1 (u +XCMPLX-0K2 v)-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) & (\<three>\<^sub>M *XCMPLX-0K3 u)*XCMPLX-0K3 v +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
sorry

mtheorem polyeq_3_th_16:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K1(z1,z2,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1"
sorry

(*begin*)
mtheorem polyeq_3_th_17:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds  for s1 be ComplexXCMPLX-0M1 holds  for s2 be ComplexXCMPLX-0M1 holds  for s3 be ComplexXCMPLX-0M1 holds ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,z)) implies (z1 =COMPLEX1R1 s1 & z2 =COMPLEX1R1 s2) & z3 =COMPLEX1R1 s3"
sorry

mtheorem polyeq_3_th_18:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_19:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s >=XXREAL-0R2 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_20:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6) & ReCOMPLEX1K3 s >XXREAL-0R4 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s) or z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s)"
sorry

mtheorem polyeq_3_th_21:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6) & ReCOMPLEX1K3 s <XXREAL-0R3 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_22:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s <XXREAL-0R3 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_23:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies ((z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_24:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,z2,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 or z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_25:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,0NUMBERSK6,z3,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1 implies ((z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
sorry

mtheorem polyeq_3_th_26:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 0NUMBERSK6 implies ( for h be ComplexXCMPLX-0M1 holds  for t be ComplexXCMPLX-0M1 holds h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1) implies ((z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t)"
sorry

mtheorem polyeq_3_th_27:
" for z be ComplexXCMPLX-0M1 holds (z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (z *XCMPLX-0K3 z)*XCMPLX-0K3 z & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^2SQUARE-1K1 *XCMPLX-0K3 z) & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^3POLYEQ-3K3"
sorry

mtheorem polyeq_3_th_28:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,z2,0NUMBERSK6,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 or z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_29:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,0NUMBERSK6,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1 implies (((z =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
sorry

mtheorem polyeq_3_th_30:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,z2,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds  for h be ComplexXCMPLX-0M1 holds  for t be ComplexXCMPLX-0M1 holds h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1) implies (((z =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t)"
sorry

mlemma polyeq_3_lm_2:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (0NUMBERSK6) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_31:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_32:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds z  |^NEWTONK1 n =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_33:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for x be RealXREAL-0M1 holds n <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem polyeq_3_th_34:
" for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <>HIDDENR2 0NUMBERSK6 implies z =COMPLEX1R1 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
sorry

mtheorem polyeq_3_th_35:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,z)"
sorry

mtheorem polyeq_3_th_36:
" for z be ComplexXCMPLX-0M1 holds  for v be CRootCOMPTRIGM1-of(\<one>\<^sub>M,z) holds v =COMPLEX1R1 z"
sorry

mtheorem polyeq_3_th_37:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for v be CRootCOMPTRIGM1-of(n,0NUMBERSK6) holds v =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_38:
" for n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ComplexXCMPLX-0M1 holds  for v be CRootCOMPTRIGM1-of(n,z) holds v =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem polyeq_3_th_39:
" for n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds cosSIN-COSK20 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,\<one>\<^sub>M)"
sorry

mtheorem polyeq_3_th_40:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((s <>HIDDENR2 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M) & s  |^NEWTONK1 n =COMPLEX1R1 z  |^NEWTONK1 n implies  |.COMPLEX1K10 s.| =COMPLEX1R1  |.COMPLEX1K10 z.|"
sorry

end
