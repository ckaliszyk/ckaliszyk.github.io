theory extreal1
  imports rfunct_3 measure6 finseq_5 binarith arytm_2
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) EXTREAL1K1(" _ *EXTREAL1K1  _ " [164,164]164) where
  "x *EXTREAL1K1 y \<equiv> x *XXREAL-3K4 y"

mtheorem extreal1_add_1:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster x *XXREAL-3K4 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem extreal1_th_1:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x *XXREAL-3K4 y =HIDDENR1 a *XCMPLX-0K3 b"
  using xxreal_3_def_5 sorry

abbreviation(input) EXTREAL1K2(" _ '/EXTREAL1K2  _ " [164,164]164) where
  "x /EXTREAL1K2 y \<equiv> x /XXREAL-3K6 y"

mtheorem extreal1_add_2:
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"cluster x /XXREAL-3K6 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x /XXREAL-3K6 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem extreal1_th_2:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x /EXTREAL1K2 y =XBOOLE-0R4 a /EXTREAL1K2 b"
   sorry

mdef extreal1_def_1 (" |.EXTREAL1K3  _ .|" [0]164 ) where
  mlet "x be ExtRealXXREAL-0M1"
"func  |.EXTREAL1K3 x.| \<rightarrow> R-ealSUPINF-1M1 equals
  x if 0NUMBERSK6 <=XXREAL-3R1 x otherwise -XXREAL-3K2 x"
proof-
  (*coherence*)
    show "(0NUMBERSK6 <=XXREAL-3R1 x implies x be R-ealSUPINF-1M1) & ( not 0NUMBERSK6 <=XXREAL-3R1 x implies -XXREAL-3K2 x be R-ealSUPINF-1M1)"
      using xxreal_0_def_1 sorry
  (*consistency*)
    show " for it be R-ealSUPINF-1M1 holds  True "
       sorry
qed "sorry"

mtheorem EXTREAL1K3_projectivity:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3  |.EXTREAL1K3 x.| .| =HIDDENR1  |.EXTREAL1K3 x.|"
sorry

mtheorem extreal1_ident_1:
  mlet "x be RealXREAL-0M1", "a be ComplexXCMPLX-0M1"
"identify  |.EXTREAL1K3 x.| with  |.COMPLEX1K10 a.| when x =HIDDENR1 a"
proof
(*compatibility*)
  show "x =HIDDENR1 a implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
sorry
qed "sorry"

mtheorem extreal1_th_3:
" for x be R-ealSUPINF-1M1 holds 0NUMBERSK6 <=XXREAL-3R1 x implies  |.EXTREAL1K3 x.| =XBOOLE-0R4 x"
  using extreal1_def_1 sorry

mtheorem extreal1_th_4:
" for x be R-ealSUPINF-1M1 holds x <XXREAL-0R3 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =XBOOLE-0R4 -SUPINF-2K3 x"
  using extreal1_def_1 sorry

mtheorem extreal1_cl_1:
  mlet "x be R-ealSUPINF-1M1"
"cluster  |.EXTREAL1K3 x.| as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show " |.EXTREAL1K3 x.| be  non negativeXXREAL-0V3"
sorry
qed "sorry"

(*\$CT 2*)
(*begin*)
mdef extreal1_def_2 ("SumEXTREAL1K4  _ " [260]260 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3"
"func SumEXTREAL1K4 F \<rightarrow> R-ealSUPINF-1M1 means
  \<lambda>it.  ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be R-ealSUPINF-1M1 st  ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be R-ealSUPINF-1M1 holds  for it2 be R-ealSUPINF-1M1 holds ( ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it1 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) & ( ex f be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st (it2 =XBOOLE-0R4 f .SUPINF-2K15 lenFINSEQ-1K4 F & f .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 0.SUPINF-2K2) & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 F implies f .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .SUPINF-2K15 i +SUPINF-2K4 F .SUPINF-2K15 (i +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem extreal1_th_7:
"SumEXTREAL1K4 <*>FINSEQ-1K7 (ExtREALXXREAL-0K3) =XBOOLE-0R4 0.SUPINF-2K2"
sorry

mtheorem extreal1_th_8:
" for a be R-ealSUPINF-1M1 holds SumEXTREAL1K4 (<*FINSEQ-1K13\<^bsub>(ExtREALNUMBERSK7)\<^esub> a*>) =XBOOLE-0R4 a"
sorry

mlemma extreal1_lm_1:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> (<*FINSEQ-1K13\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x*>)) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 x"
sorry

mtheorem extreal1_th_9:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds SumEXTREAL1K4 (<*FINSEQ-4K2\<^bsub>(ExtREALNUMBERSK7)\<^esub> a,b *>) =XBOOLE-0R4 a +SUPINF-2K4 b"
sorry

mlemma extreal1_lm_2:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F <>HIDDENR2 -inftySUPINF-1K2"
sorry

mtheorem extreal1_th_10:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G implies SumEXTREAL1K4 (F ^FINSEQ-1K9\<^bsub>(ExtREALXXREAL-0K3)\<^esub> G) =XBOOLE-0R4 SumEXTREAL1K4 F +SUPINF-2K4 SumEXTREAL1K4 G"
sorry

mlemma extreal1_lm_3:
" for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) st  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M))"
sorry

mlemma extreal1_lm_4:
" for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for s be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for s9 be FinSequenceFINSEQ-1M3-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds (s9 =FUNCT-1R1 s & q =XBOOLE-0R4 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)) implies p *PARTFUN1K1\<^bsub>(NATNUMBERSK1,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> s9  |FINSEQ-1K18\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> n be PermutationFUNCT-2M2-of SegFINSEQ-1K2 n"
sorry

mlemma extreal1_lm_5:
" for n be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for p be PermutationFUNCT-2M2-of SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds  for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for H be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds (((F =FUNCT-1R1 H *PARTFUN1K1\<^bsub>(SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M),NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> p & q inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)) & lenFINSEQ-1K4 H =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M) &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> H) & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((i <XXREAL-0R3 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i) & (i =COMPLEX1R1 q implies p .FUNCT-1K1 i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M)) & (i >XXREAL-0R4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M)) implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 H"
sorry

mtheorem extreal1_th_11:
" for F be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for G be FinSequenceFINSEQ-1M3-of ExtREALXXREAL-0K3 holds  for s be PermutationFUNCT-2M2-of domFINSEQ-1K5 F holds G =FUNCT-1R1 F *PARTFUN1K1\<^bsub>(domFINSEQ-1K5 F,domFINSEQ-1K5 F,NATNUMBERSK1,ExtREALXXREAL-0K3)\<^esub> s &  not -inftySUPINF-1K2 inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies SumEXTREAL1K4 F =XBOOLE-0R4 SumEXTREAL1K4 G"
sorry

reserve x, y, w, z for "ExtRealXXREAL-0M1"
reserve a for "RealXREAL-0M1"
(*begin*)
mtheorem extreal1_th_12:
" for x be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds x =HIDDENR1 a implies  |.EXTREAL1K3 x.| =HIDDENR1  |.COMPLEX1K10 a.|"
sorry

mtheorem extreal1_th_13:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =HIDDENR1 x or  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
  using extreal1_def_1 sorry

mtheorem extreal1_th_14:
" for x be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1  |.EXTREAL1K3 x.|"
sorry

mtheorem extreal1_th_15:
" for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3  |.EXTREAL1K3 x.|"
sorry

mtheorem extreal1_th_16:
" for x be ExtRealXXREAL-0M1 holds x =HIDDENR1 0NUMBERSK6 iff  |.EXTREAL1K3 x.| =XBOOLE-0R4 0NUMBERSK6"
  using extreal1_th_15 extreal1_def_1 sorry

mtheorem extreal1_th_17:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x & x <>HIDDENR2 0NUMBERSK6 implies x <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem extreal1_th_18:
" for x be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 0NUMBERSK6 implies  |.EXTREAL1K3 x.| =HIDDENR1 -XXREAL-3K2 x"
sorry

mtheorem extreal1_th_19:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x *XXREAL-3K4 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 y.|)"
sorry

mtheorem extreal1_th_20:
" for x be ExtRealXXREAL-0M1 holds -SUPINF-2K3  |.EXTREAL1K3 x.| <=XXREAL-3R1 x & x <=XXREAL-3R1  |.EXTREAL1K3 x.|"
sorry

mtheorem extreal1_th_21:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <XXREAL-0R3 y implies -XXREAL-3K2 y <XXREAL-0R3 x & x <XXREAL-0R3 y"
sorry

mtheorem extreal1_th_22:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 y <XXREAL-0R3 x & x <XXREAL-0R3 y implies 0NUMBERSK6 <XXREAL-0R3 y &  |.EXTREAL1K3 x.| <XXREAL-0R3 y"
sorry

mtheorem extreal1_th_23:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 y <=XXREAL-3R1 x & x <=XXREAL-3R1 y iff  |.EXTREAL1K3 x.| <=XXREAL-3R1 y"
sorry

mtheorem extreal1_th_24:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
sorry

mtheorem extreal1_th_25:
" for x be ExtRealXXREAL-0M1 holds (-inftySUPINF-1K2 <XXREAL-0R3 x & x <XXREAL-0R3 +inftySUPINF-1K1) & x <>HIDDENR2 0NUMBERSK6 implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 1.SUPINF-2K21"
sorry

mtheorem extreal1_th_26:
" for x be ExtRealXXREAL-0M1 holds x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 implies ( |.EXTREAL1K3 x.|)*EXTREAL1K1 ( |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .|) =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem extreal1_th_27:
" for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies  |.EXTREAL1K3 (1.SUPINF-2K21)/EXTREAL1K2 x .| =XBOOLE-0R4 (1.SUPINF-2K21)/EXTREAL1K2 ( |.EXTREAL1K3 x.|)"
sorry

mtheorem extreal1_th_28:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not ((x =HIDDENR1 -inftySUPINF-1K2 or x =HIDDENR1 +inftySUPINF-1K1) & (y =HIDDENR1 -inftySUPINF-1K2 or y =HIDDENR1 +inftySUPINF-1K1)) & y <>HIDDENR2 0NUMBERSK6 implies  |.EXTREAL1K3 x /EXTREAL1K2 y .| =XBOOLE-0R4 ( |.EXTREAL1K3 x.|)/EXTREAL1K2 ( |.EXTREAL1K3 y.|)"
sorry

mtheorem extreal1_th_29:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =XBOOLE-0R4  |.EXTREAL1K3 -XXREAL-3K2 x .|"
sorry

mtheorem extreal1_th_30:
" |.EXTREAL1K3 +inftySUPINF-1K1.| =XBOOLE-0R4 +inftySUPINF-1K1 &  |.EXTREAL1K3 -inftySUPINF-1K2.| =XBOOLE-0R4 +inftySUPINF-1K1"
sorry

mtheorem extreal1_th_31:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be RealXREAL-0M1 or y be RealXREAL-0M1 implies  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
sorry

mtheorem extreal1_th_32:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x -XXREAL-3K3 y .| <=XXREAL-3R1  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
sorry

(*\$CT*)
mtheorem extreal1_th_34:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <=XXREAL-3R1 z &  |.EXTREAL1K3 y.| <=XXREAL-3R1 w implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| <=XXREAL-3R1 z +XXREAL-3K1 w"
sorry

mtheorem extreal1_th_35:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be RealXREAL-0M1 or y be RealXREAL-0M1 implies  |.EXTREAL1K3  |.EXTREAL1K3 x.| -SUPINF-2K5  |.EXTREAL1K3 y.| .| <=XXREAL-3R1  |.EXTREAL1K3 x -XXREAL-3K3 y .|"
sorry

mtheorem extreal1_th_36:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x *XXREAL-3K4 y implies  |.EXTREAL1K3 x +XXREAL-3K1 y .| =XBOOLE-0R4  |.EXTREAL1K3 x.| +SUPINF-2K4  |.EXTREAL1K3 y.|"
sorry

(*begin*)
mtheorem extreal1_th_37:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftySUPINF-1K1 & y <>HIDDENR2 +inftySUPINF-1K1) &  not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2) implies minXXREAL-0K4(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)-XXREAL-3K3  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
sorry

mtheorem extreal1_th_38:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 -inftySUPINF-1K2 & y <>HIDDENR2 -inftySUPINF-1K2) &  not (x =HIDDENR1 +inftySUPINF-1K1 & y =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2 & y =HIDDENR1 -inftySUPINF-1K2) implies maxXXREAL-0K5(x,y) =HIDDENR1 ((x +XXREAL-3K1 y)+XXREAL-3K1  |.EXTREAL1K3 x -XXREAL-3K3 y .|)/EXTREAL1K2 \<two>\<^sub>M"
sorry

abbreviation(input) EXTREAL1K5("maxEXTREAL1K5'( _ , _ ')" [0,0]228) where
  "maxEXTREAL1K5(x,y) \<equiv> maxXXREAL-0K5(x,y)"

mtheorem extreal1_add_3:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster maxXXREAL-0K5(x,y) as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "maxXXREAL-0K5(x,y) be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) EXTREAL1K6("minEXTREAL1K6'( _ , _ ')" [0,0]228) where
  "minEXTREAL1K6(x,y) \<equiv> minXXREAL-0K4(x,y)"

mtheorem extreal1_add_4:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster minXXREAL-0K4(x,y) as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "minXXREAL-0K4(x,y) be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem extreal1_th_39:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds minXXREAL-0K4(x,y) +XXREAL-3K1 maxXXREAL-0K5(x,y) =HIDDENR1 x +XXREAL-3K1 y"
sorry

(*begin*)
mtheorem extreal1_th_40:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| =XBOOLE-0R4 +inftySUPINF-1K1 implies x =HIDDENR1 +inftySUPINF-1K1 or x =HIDDENR1 -inftySUPINF-1K2"
sorry

mtheorem extreal1_th_41:
" for x be ExtRealXXREAL-0M1 holds  |.EXTREAL1K3 x.| <XXREAL-0R3 +inftySUPINF-1K1 iff x inHIDDENR3 REALNUMBERSK2"
  using extreal1_th_30 extreal1_th_40 xxreal_0_th_4 xxreal_0_th_14 sorry

end
