theory sin_cos7
  imports sin_cos2 polyeq_1 taylor_1 asympt_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, t for "RealXREAL-0M1"
mlemma sin_cos7_lm_1:
"number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
  using taylor_1_th_11 sorry

mlemma sin_cos7_lm_2:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M & y <XXREAL-0R3 \<one>\<^sub>M implies x ^2SQUARE-1K1 *XCMPLX-0K3 y <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_1:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 x =COMPLEX1R1 x to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_2:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 \<one>\<^sub>M implies (sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) /XCMPLX-0K7 x)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_3:
" for x be RealXREAL-0M1 holds (x /XCMPLX-0K7 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M))^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_4:
" for x be RealXREAL-0M1 holds sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_5:
" for x be RealXREAL-0M1 holds sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) +XCMPLX-0K2 x >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_3:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 x implies x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_6:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y >=XXREAL-0R2 0NUMBERSK6 & x >=XXREAL-0R2 \<one>\<^sub>M implies (x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 y >=XXREAL-0R2 0NUMBERSK6"
   sorry

mtheorem sin_cos7_th_7:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y >=XXREAL-0R2 0NUMBERSK6 & x >=XXREAL-0R2 \<one>\<^sub>M implies (x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 y >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_8:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 \<one>\<^sub>M implies sqrtSQUARE-1K3 ((x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_9:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y >=XXREAL-0R2 0NUMBERSK6 & x >=XXREAL-0R2 \<one>\<^sub>M implies (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 y >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_10:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 \<one>\<^sub>M implies sqrtSQUARE-1K3 ((x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_11:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies x +XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & \<one>\<^sub>M -XCMPLX-0K6 x >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_4:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies (x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_12:
" for x be RealXREAL-0M1 holds x <>HIDDENR2 \<one>\<^sub>M implies (\<one>\<^sub>M -XCMPLX-0K6 x)^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_13:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_14:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies ((\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_15:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_16:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
sorry

mlemma sin_cos7_lm_5:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1"
sorry

mtheorem sin_cos7_th_17:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_18:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_19:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)^2SQUARE-1K1"
sorry

mtheorem sin_cos7_th_20:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_21:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 x ^2SQUARE-1K1 implies (\<one>\<^sub>M /XCMPLX-0K7 x)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_22:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <=XXREAL-0R1 \<one>\<^sub>M implies \<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_23:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 x implies 0NUMBERSK6 <XXREAL-0R3 x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_24:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 x & \<one>\<^sub>M <=XXREAL-0R1 y implies 0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 y *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_25:
" for y be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 y implies 0NUMBERSK6 <XXREAL-0R3 y -XCMPLX-0K6 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_26:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (\<one>\<^sub>M <=XXREAL-0R1 x & \<one>\<^sub>M <=XXREAL-0R1 y) &  |.COMPLEX1K10 y.| <=XXREAL-0R1  |.COMPLEX1K10 x.| implies 0NUMBERSK6 <=XXREAL-0R1 y *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 x *XCMPLX-0K3 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_27:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M & y ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies x *XCMPLX-0K3 y <>HIDDENR2 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_28:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M & y ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies x *XCMPLX-0K3 y <>HIDDENR2 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_29:
" for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies exp-RSIN-COSK24 x <>HIDDENR2 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_30:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <>HIDDENR2 x implies (exp-RSIN-COSK24 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_6:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos7_th_31:
" for t be RealXREAL-0M1 holds (t ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (t ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_32:
" for t be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 t & t <XXREAL-0R3 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 (t +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 t)"
sorry

mlemma sin_cos7_lm_7:
" for t be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 t or t <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 (t +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (t -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mlemma sin_cos7_lm_8:
" for x be RealXREAL-0M1 holds sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) >XXREAL-0R4 x"
sorry

mlemma sin_cos7_lm_9:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 x *XCMPLX-0K3 y >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_10:
" for y be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 y implies y +XCMPLX-0K2 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_11:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 (t ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (t ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mlemma sin_cos7_lm_12:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t & t <>HIDDENR2 \<one>\<^sub>M implies \<one>\<^sub>M <XXREAL-0R3 (t ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (t ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) or (t ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (t ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mlemma sin_cos7_lm_13:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies 0NUMBERSK6 <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 t)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 t ^2SQUARE-1K1)"
   sorry

mlemma sin_cos7_lm_14:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies (\<two>\<^sub>M *XCMPLX-0K3 t)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 t ^2SQUARE-1K1) <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mlemma sin_cos7_lm_15:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies (\<one>\<^sub>M -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 t ^2SQUARE-1K1))/XCMPLX-0K7 t <XXREAL-0R3 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_16:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t & t <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 t ^2SQUARE-1K1"
sorry

mlemma sin_cos7_lm_17:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t & t <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 \<four>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 t ^2SQUARE-1K1"
sorry

mlemma sin_cos7_lm_18:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t & t <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 t ^2SQUARE-1K1)"
sorry

mlemma sin_cos7_lm_19:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t & t <=XXREAL-0R1 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 t ^2SQUARE-1K1))/XCMPLX-0K7 t"
sorry

mlemma sin_cos7_lm_20:
" for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t & t <>HIDDENR2 \<one>\<^sub>M implies (\<two>\<^sub>M *XCMPLX-0K3 t)/XCMPLX-0K7 (t ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
sorry

mlemma sin_cos7_lm_21:
" for t be RealXREAL-0M1 holds t <XXREAL-0R3 0NUMBERSK6 implies (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 t ^2SQUARE-1K1))/XCMPLX-0K7 t <XXREAL-0R3 0NUMBERSK6"
sorry

(*begin*)
mdef sin_cos7_def_1 ("sinh\<inverse>SIN-COS7K1  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func sinh\<inverse>SIN-COS7K1 x \<rightarrow> RealXREAL-0M1 equals
  logPOWERK3(number-ePOWERK4,x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  (*coherence*)
    show "logPOWERK3(number-ePOWERK4,x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_2 ("cosh1\<inverse>SIN-COS7K2  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func cosh1\<inverse>SIN-COS7K2 x \<rightarrow> RealXREAL-0M1 equals
  logPOWERK3(number-ePOWERK4,x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  (*coherence*)
    show "logPOWERK3(number-ePOWERK4,x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_3 ("cosh2\<inverse>SIN-COS7K3  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func cosh2\<inverse>SIN-COS7K3 x \<rightarrow> RealXREAL-0M1 equals
  -XCMPLX-0K4 logPOWERK3(number-ePOWERK4,x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  (*coherence*)
    show "-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,x +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_4 ("tanh\<inverse>SIN-COS7K4  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func tanh\<inverse>SIN-COS7K4 x \<rightarrow> RealXREAL-0M1 equals
  (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x))"
proof-
  (*coherence*)
    show "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x)) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_5 ("coth\<inverse>SIN-COS7K5  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func coth\<inverse>SIN-COS7K5 x \<rightarrow> RealXREAL-0M1 equals
  (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,(x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (x -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  (*coherence*)
    show "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,(x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (x -XCMPLX-0K6 \<one>\<^sub>M)) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_6 ("sech1\<inverse>SIN-COS7K6  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func sech1\<inverse>SIN-COS7K6 x \<rightarrow> RealXREAL-0M1 equals
  logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 x)"
proof-
  (*coherence*)
    show "logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 x) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_7 ("sech2\<inverse>SIN-COS7K7  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func sech2\<inverse>SIN-COS7K7 x \<rightarrow> RealXREAL-0M1 equals
  -XCMPLX-0K4 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 x)"
proof-
  (*coherence*)
    show "-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 x) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos7_def_8 ("csch\<inverse>SIN-COS7K8  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func csch\<inverse>SIN-COS7K8 x \<rightarrow> RealXREAL-0M1 equals
  logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 x) if 0NUMBERSK6 <XXREAL-0R3 x,
  logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 x) if x <XXREAL-0R3 0NUMBERSK6"
proof-
  (*coherence*)
    show "(0NUMBERSK6 <XXREAL-0R3 x implies logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 x) be RealXREAL-0M1) & (x <XXREAL-0R3 0NUMBERSK6 implies logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 x) be RealXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 0NUMBERSK6 implies (it =HIDDENR1 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 x) iff it =HIDDENR1 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 x))"
       sorry
qed "sorry"

mtheorem sin_cos7_th_33:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x implies sinh\<inverse>SIN-COS7K1 x =COMPLEX1R1 cosh1\<inverse>SIN-COS7K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_34:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies sinh\<inverse>SIN-COS7K1 x =COMPLEX1R1 cosh2\<inverse>SIN-COS7K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_35:
" for x be RealXREAL-0M1 holds sinh\<inverse>SIN-COS7K1 x =COMPLEX1R1 tanh\<inverse>SIN-COS7K4 (x /XCMPLX-0K7 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M))"
sorry

mtheorem sin_cos7_th_36:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 \<one>\<^sub>M implies cosh1\<inverse>SIN-COS7K2 x =COMPLEX1R1 sinh\<inverse>SIN-COS7K1 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos7_th_37:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 \<one>\<^sub>M implies cosh1\<inverse>SIN-COS7K2 x =COMPLEX1R1 tanh\<inverse>SIN-COS7K4 (sqrtSQUARE-1K3 (x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) /XCMPLX-0K7 x)"
sorry

mtheorem sin_cos7_th_38:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 \<one>\<^sub>M implies cosh1\<inverse>SIN-COS7K2 x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (cosh1\<inverse>SIN-COS7K2 sqrtSQUARE-1K3 ((x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos7_th_39:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 \<one>\<^sub>M implies cosh2\<inverse>SIN-COS7K3 x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (cosh2\<inverse>SIN-COS7K3 sqrtSQUARE-1K3 ((x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos7_th_40:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 \<one>\<^sub>M implies cosh1\<inverse>SIN-COS7K2 x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (sinh\<inverse>SIN-COS7K1 sqrtSQUARE-1K3 ((x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos7_th_41:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x =COMPLEX1R1 sinh\<inverse>SIN-COS7K1 (x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
sorry

mtheorem sin_cos7_th_42:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x =COMPLEX1R1 cosh1\<inverse>SIN-COS7K2 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
sorry

mtheorem sin_cos7_th_43:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinh\<inverse>SIN-COS7K1 ((\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
sorry

mtheorem sin_cos7_th_44:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 & x <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosh1\<inverse>SIN-COS7K2 ((\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
sorry

mtheorem sin_cos7_th_45:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (tanh\<inverse>SIN-COS7K4 ((\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)))"
sorry

mtheorem sin_cos7_th_46:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 >XXREAL-0R4 \<one>\<^sub>M implies coth\<inverse>SIN-COS7K5 x =COMPLEX1R1 tanh\<inverse>SIN-COS7K4 (\<one>\<^sub>M /XCMPLX-0K7 x)"
sorry

mtheorem sin_cos7_th_47:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 & x <=XXREAL-0R1 \<one>\<^sub>M implies sech1\<inverse>SIN-COS7K6 x =COMPLEX1R1 cosh1\<inverse>SIN-COS7K2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
sorry

mtheorem sin_cos7_th_48:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 & x <=XXREAL-0R1 \<one>\<^sub>M implies sech2\<inverse>SIN-COS7K7 x =COMPLEX1R1 cosh2\<inverse>SIN-COS7K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
sorry

mtheorem sin_cos7_th_49:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies csch\<inverse>SIN-COS7K8 x =COMPLEX1R1 sinh\<inverse>SIN-COS7K1 (\<one>\<^sub>M /XCMPLX-0K7 x)"
sorry

mtheorem sin_cos7_th_50:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x *XCMPLX-0K3 y +XCMPLX-0K2 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6 implies sinh\<inverse>SIN-COS7K1 x +XCMPLX-0K2 sinh\<inverse>SIN-COS7K1 y =COMPLEX1R1 sinh\<inverse>SIN-COS7K1 (x *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 y ^2SQUARE-1K1) +XCMPLX-0K2 y *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
sorry

mtheorem sin_cos7_th_51:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sinh\<inverse>SIN-COS7K1 x -XCMPLX-0K6 sinh\<inverse>SIN-COS7K1 y =COMPLEX1R1 sinh\<inverse>SIN-COS7K1 (x *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 y ^2SQUARE-1K1) -XCMPLX-0K6 y *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
sorry

mtheorem sin_cos7_th_52:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 x & \<one>\<^sub>M <=XXREAL-0R1 y implies cosh1\<inverse>SIN-COS7K2 x +XCMPLX-0K2 cosh1\<inverse>SIN-COS7K2 y =COMPLEX1R1 cosh1\<inverse>SIN-COS7K2 (x *XCMPLX-0K3 y +XCMPLX-0K2 sqrtSQUARE-1K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)))"
sorry

mtheorem sin_cos7_th_53:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 x & \<one>\<^sub>M <=XXREAL-0R1 y implies cosh2\<inverse>SIN-COS7K3 x +XCMPLX-0K2 cosh2\<inverse>SIN-COS7K3 y =COMPLEX1R1 cosh2\<inverse>SIN-COS7K3 (x *XCMPLX-0K3 y +XCMPLX-0K2 sqrtSQUARE-1K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)))"
sorry

mtheorem sin_cos7_th_54:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (\<one>\<^sub>M <=XXREAL-0R1 x & \<one>\<^sub>M <=XXREAL-0R1 y) &  |.COMPLEX1K10 y.| <=XXREAL-0R1  |.COMPLEX1K10 x.| implies cosh1\<inverse>SIN-COS7K2 x -XCMPLX-0K6 cosh1\<inverse>SIN-COS7K2 y =COMPLEX1R1 cosh1\<inverse>SIN-COS7K2 (x *XCMPLX-0K3 y -XCMPLX-0K6 sqrtSQUARE-1K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)))"
sorry

mtheorem sin_cos7_th_55:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (\<one>\<^sub>M <=XXREAL-0R1 x & \<one>\<^sub>M <=XXREAL-0R1 y) &  |.COMPLEX1K10 y.| <=XXREAL-0R1  |.COMPLEX1K10 x.| implies cosh2\<inverse>SIN-COS7K3 x -XCMPLX-0K6 cosh2\<inverse>SIN-COS7K3 y =COMPLEX1R1 cosh2\<inverse>SIN-COS7K3 (x *XCMPLX-0K3 y -XCMPLX-0K6 sqrtSQUARE-1K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)))"
sorry

mtheorem sin_cos7_th_56:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M & y ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x +XCMPLX-0K2 tanh\<inverse>SIN-COS7K4 y =COMPLEX1R1 tanh\<inverse>SIN-COS7K4 ((x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y))"
sorry

mtheorem sin_cos7_th_57:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M & y ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies tanh\<inverse>SIN-COS7K4 x -XCMPLX-0K6 tanh\<inverse>SIN-COS7K4 y =COMPLEX1R1 tanh\<inverse>SIN-COS7K4 ((x -XCMPLX-0K6 y)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x *XCMPLX-0K3 y))"
sorry

mtheorem sin_cos7_th_58:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x implies logPOWERK3(number-ePOWERK4,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (tanh\<inverse>SIN-COS7K4 ((x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (x +XCMPLX-0K2 \<one>\<^sub>M)))"
sorry

mtheorem sin_cos7_th_59:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x implies logPOWERK3(number-ePOWERK4,x) =COMPLEX1R1 tanh\<inverse>SIN-COS7K4 ((x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M))"
sorry

mtheorem sin_cos7_th_60:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 x implies logPOWERK3(number-ePOWERK4,x) =COMPLEX1R1 cosh1\<inverse>SIN-COS7K2 ((x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 x))"
sorry

mtheorem sin_cos7_th_61:
" for x be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M) & \<one>\<^sub>M <=XXREAL-0R1 (x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 x) implies logPOWERK3(number-ePOWERK4,x) =COMPLEX1R1 cosh2\<inverse>SIN-COS7K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 x))"
sorry

mtheorem sin_cos7_th_62:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x implies logPOWERK3(number-ePOWERK4,x) =COMPLEX1R1 sinh\<inverse>SIN-COS7K1 ((x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 x))"
sorry

mtheorem sin_cos7_th_63:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)) implies x =COMPLEX1R1 logPOWERK3(number-ePOWERK4,y +XCMPLX-0K2 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M))"
sorry

mtheorem sin_cos7_th_64:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)) & \<one>\<^sub>M <=XXREAL-0R1 y implies x =COMPLEX1R1 logPOWERK3(number-ePOWERK4,y +XCMPLX-0K2 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)) or x =COMPLEX1R1 -XCMPLX-0K4 logPOWERK3(number-ePOWERK4,y +XCMPLX-0K2 sqrtSQUARE-1K3 (y ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M))"
sorry

mtheorem sin_cos7_th_65:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y =COMPLEX1R1 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)) implies x =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 y))"
sorry

mtheorem sin_cos7_th_66:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y =COMPLEX1R1 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)) & x <>HIDDENR2 0NUMBERSK6 implies x =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,(y +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (y -XCMPLX-0K6 \<one>\<^sub>M))"
sorry

mtheorem sin_cos7_th_67:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 \<two>\<^sub>M) implies x =COMPLEX1R1 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 y ^2SQUARE-1K1))/XCMPLX-0K7 y) or x =COMPLEX1R1 -XCMPLX-0K4 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 y ^2SQUARE-1K1))/XCMPLX-0K7 y)"
sorry

mtheorem sin_cos7_th_68:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 \<two>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6 implies x =COMPLEX1R1 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 y ^2SQUARE-1K1))/XCMPLX-0K7 y) or x =COMPLEX1R1 logPOWERK3(number-ePOWERK4,(\<one>\<^sub>M -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 y ^2SQUARE-1K1))/XCMPLX-0K7 y)"
sorry

mtheorem sin_cos7_th_69:
" for x be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 x)^2SQUARE-1K1"
sorry

mtheorem sin_cos7_th_70:
" for x be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 x)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 x)^2SQUARE-1K1"
sorry

mtheorem sin_cos7_th_71:
" for x be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 x)^2SQUARE-1K1 =COMPLEX1R1 ((coshSIN-COS2K3).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mtheorem sin_cos7_th_72:
" for x be RealXREAL-0M1 holds sinhSIN-COS2K2 (\<five>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<five>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x) +XCMPLX-0K2 \<two>\<zero>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x) |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 \<one>\<six>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x) |^NEWTONK1 \<five>\<^sub>M"
sorry

mtheorem sin_cos7_th_73:
" for x be RealXREAL-0M1 holds coshSIN-COS2K4 (\<five>\<^sub>M *XCMPLX-0K3 x) =COMPLEX1R1 (\<five>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x) -XCMPLX-0K6 \<two>\<zero>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x) |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 \<one>\<six>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x) |^NEWTONK1 \<five>\<^sub>M"
sorry

end
