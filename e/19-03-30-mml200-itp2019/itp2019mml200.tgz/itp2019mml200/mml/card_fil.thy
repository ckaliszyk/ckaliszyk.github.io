theory card_fil
  imports setfam_1 card_5 setwiseo trees_2
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem card_fil_th_1:
" for x be setHIDDENM2 holds  for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds cardCARD-1K4 {TARSKIK1 x} inTARSKIR2 cardCARD-1K1 X"
  using card_3_th_86 sorry

theorem card_fil_sch_1:
  fixes Df0 xf0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "xf0 be setHIDDENM2" and
   A1: "xf0 inTARSKIR2 {y where y be ElementSUBSET-1M1-of Df0 : Pp1(y) }"
  shows "Pp1(xf0)"
sorry

reserve N for "CardinalCARD-1M1"
reserve M for "AlephCARD-5M1"
reserve X for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Y, Z, Z1, Z2, Y1, Y2, Y3, Y4 for "SubsetSUBSET-1M2-of X"
reserve S for "Subset-FamilySETFAM-1M1-of X"
mtheorem card_fil_th_2:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ({TARSKIK1 X} be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 X}) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X} implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}) & (Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 {TARSKIK1 X}))"
sorry

mdef card_fil_def_1 ("FilterCARD-FILM1-of  _ " [70]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode FilterCARD-FILM1-of X \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X means
  (\<lambda>it.  not {}XBOOLE-0K1 inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 it)))"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st  not {}XBOOLE-0K1 inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 it))"
sorry
qed "sorry"

mtheorem card_fil_th_3:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be setHIDDENM2 holds F be FilterCARD-FILM1-of X iff (F be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 F) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 F & Y2 inTARSKIR2 F implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 F) & (Y1 inTARSKIR2 F & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 F))"
  using card_fil_def_1 sorry

mtheorem card_fil_th_4:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {TARSKIK1 X} be FilterCARD-FILM1-of X"
sorry

reserve F, Uf for "FilterCARD-FILM1-of X"
mtheorem card_fil_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds X inTARSKIR2 F"
sorry

mtheorem card_fil_th_6:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds Y inTARSKIR2 F implies  not X \\SUBSET-1K6 Y inTARSKIR2 F"
sorry

mtheorem card_fil_th_7:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  for I be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds ( for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 I iff Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F) implies  not X inTARSKIR2 I & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 I & Y2 inTARSKIR2 I implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 I) & (Y1 inTARSKIR2 I & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 I))"
sorry

abbreviation(input) CARD_FILK1("dualCARD-FILK1\<^bsub>'( _ ')\<^esub>  _ " [0,164]164) where
  "dualCARD-FILK1\<^bsub>(X)\<^esub> S \<equiv> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> S"

reserve S for " non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
mtheorem card_fil_cl_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"cluster COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> S as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> S be  non emptyXBOOLE-0V1"
    using setfam_1_th_32 sorry
qed "sorry"

mtheorem card_fil_th_8:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
sorry

mtheorem card_fil_th_9:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
sorry

mdef card_fil_def_2 ("IdealCARD-FILM2-of  _ " [70]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode IdealCARD-FILM2-of X \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X means
  (\<lambda>it.  not X inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 it)))"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st  not X inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 it))"
sorry
qed "sorry"

abbreviation(input) CARD_FILK2("dualCARD-FILK2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164) where
  "dualCARD-FILK2\<^bsub>(X)\<^esub> F \<equiv> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F"

mtheorem card_fil_add_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FilterCARD-FILM1-of X"
"cluster COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F as-term-is IdealCARD-FILM2-of X"
proof
(*coherence*)
  show "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F be IdealCARD-FILM2-of X"
sorry
qed "sorry"

reserve I for "IdealCARD-FILM2-of X"
mtheorem card_fil_th_10:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  for I be IdealCARD-FILM2-of X holds ( for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 F & Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F)) & ( for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 I & Y inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> I))"
sorry

mtheorem card_fil_th_11:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for I be IdealCARD-FILM2-of X holds {}XBOOLE-0K1 inTARSKIR2 I"
sorry

mdef card_fil_def_3 (" _ is-multiplicative-withCARD-FILR1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "N be CardinalCARD-1M1", "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"pred S is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N means
   for S1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S1 c=TARSKIR1 S & cardCARD-1K1 S1 inTARSKIR2 N implies meetSETFAM-1K1 S1 inTARSKIR2 S"..

mdef card_fil_def_4 (" _ is-additive-withCARD-FILR2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "N be CardinalCARD-1M1", "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"pred S is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N means
   for S1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S1 c=TARSKIR1 S & cardCARD-1K1 S1 inTARSKIR2 N implies unionTARSKIK3 S1 inTARSKIR2 S"..

abbreviation(input) CARD_FILR3(" _ is-complete-withCARD-FILR3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "F is-complete-withCARD-FILR3\<^bsub>(X)\<^esub> N \<equiv> F is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N"

abbreviation(input) CARD_FILR4(" _ is-complete-withCARD-FILR4\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "I is-complete-withCARD-FILR4\<^bsub>(X)\<^esub> N \<equiv> I is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N"

mtheorem card_fil_th_12:
" for N be CardinalCARD-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds S is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N implies dualCARD-FILK1\<^bsub>(X)\<^esub> S is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N"
sorry

mdef card_fil_def_5 ("uniformCARD-FILV1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr uniformCARD-FILV1\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X means
  (\<lambda>F.  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F implies cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X)"..

mdef card_fil_def_6 ("principalCARD-FILV2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr principalCARD-FILV2\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X means
  (\<lambda>F.  ex Y be SubsetSUBSET-1M2-of X st Y inTARSKIR2 F & ( for Z be SubsetSUBSET-1M2-of X holds Z inTARSKIR2 F implies Y c=TARSKIR1 Z))"..

mdef card_fil_def_7 ("being-ultrafilterCARD-FILV3\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X means
  (\<lambda>F.  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F or X \\SUBSET-1K6 Y inTARSKIR2 F)"..

mdef card_fil_def_8 ("Extend-FilterCARD-FILK3\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FilterCARD-FILM1-of X", "Z be SubsetSUBSET-1M2-of X"
"func Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X equals
  {Y where Y be SubsetSUBSET-1M2-of X :  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y }"
proof-
  (*coherence*)
    show "{Y where Y be SubsetSUBSET-1M2-of X :  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
sorry
qed "sorry"

mtheorem card_fil_th_13:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds  for Z1 be SubsetSUBSET-1M2-of X holds Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) iff ( ex Z2 be SubsetSUBSET-1M2-of X st Z2 inTARSKIR2 F & Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1)"
sorry

mtheorem card_fil_th_14:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds ( for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 F implies Y1 meetsXBOOLE-0R5 Z) implies (Z inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) be FilterCARD-FILM1-of X) & F c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
sorry

reserve S, S1 for "Subset-FamilySETFAM-1M1-of X"
mdef card_fil_def_9 ("FiltersCARD-FILK4  _ " [164]164 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func FiltersCARD-FILK4 X \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X equals
  {S where S be Subset-FamilySETFAM-1M1-of X : S be FilterCARD-FILM1-of X }"
proof-
  (*coherence*)
    show "{S where S be Subset-FamilySETFAM-1M1-of X : S be FilterCARD-FILM1-of X } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X"
sorry
qed "sorry"

mtheorem card_fil_th_15:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be setHIDDENM2 holds S inTARSKIR2 FiltersCARD-FILK4 X iff S be FilterCARD-FILM1-of X"
sorry

reserve FS for " non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X"
mtheorem card_fil_th_16:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for FS be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X holds FS be c=-linearORDINAL1V6 implies unionTARSKIK3 FS be FilterCARD-FILM1-of X"
sorry

mtheorem card_fil_th_17:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  ex Uf be FilterCARD-FILM1-of X st F c=TARSKIR1 Uf & Uf be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
sorry

reserve X for "infiniteFINSET-1V2\<bar>setHIDDENM2"
reserve Y, Y1, Y2, Z for "SubsetSUBSET-1M2-of X"
reserve F, Uf for "FilterCARD-FILM1-of X"
mdef card_fil_def_10 ("Frechet-FilterCARD-FILK5  _ " [164]164 ) where
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"func Frechet-FilterCARD-FILK5 X \<rightarrow> FilterCARD-FILM1-of X equals
  {Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X }"
proof-
  (*coherence*)
    show "{Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X } be FilterCARD-FILM1-of X"
sorry
qed "sorry"

mdef card_fil_def_11 ("Frechet-IdealCARD-FILK6  _ " [164]164 ) where
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"func Frechet-IdealCARD-FILK6 X \<rightarrow> IdealCARD-FILM2-of X equals
  dualCARD-FILK2\<^bsub>(X)\<^esub> (Frechet-FilterCARD-FILK5 X)"
proof-
  (*coherence*)
    show "dualCARD-FILK2\<^bsub>(X)\<^esub> (Frechet-FilterCARD-FILK5 X) be IdealCARD-FILM2-of X"
       sorry
qed "sorry"

mtheorem card_fil_th_18:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 Frechet-FilterCARD-FILK5 X iff cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X"
sorry

mtheorem card_fil_th_19:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 Frechet-IdealCARD-FILK6 X iff cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
sorry

mtheorem card_fil_th_20:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds Frechet-FilterCARD-FILK5 X c=TARSKIR1 F implies F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
sorry

mtheorem card_fil_th_21:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Uf be FilterCARD-FILM1-of X holds Uf be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies Frechet-FilterCARD-FILK5 X c=TARSKIR1 Uf"
sorry

mtheorem card_fil_cl_2:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X"
proof
(*existence*)
  show " ex it be FilterCARD-FILM1-of X st it be  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
sorry
qed "sorry"

mtheorem card_fil_cl_3:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> also-is  non principalCARD-FILV2\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X"
proof
(*coherence*)
  show " for it be FilterCARD-FILM1-of X holds it be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies it be  non principalCARD-FILV2\<^bsub>(X)\<^esub>"
sorry
qed "sorry"

mtheorem card_fil_th_22:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>\<bar>FilterCARD-FILM1-of X holds  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F iff  not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F"
sorry

reserve x for "ElementSUBSET-1M1-of X"
mtheorem card_fil_th_23:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds F be  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> & F is-complete-withCARD-FILR3\<^bsub>(X)\<^esub> cardCARD-1K1 X implies F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
sorry

(*begin*)
mtheorem card_fil_th_24:
" for N be CardinalCARD-1M1 holds nextcardCARD-1K2 N c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
sorry

mdef card_fil_def_12 ("GCHCARD-FILR5" 50 ) where
"pred GCHCARD-FILR5 means
   for N be AlephCARD-5M1 holds nextcardCARD-1K2 N =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,N)"..

mdef card_fil_def_13 ("inaccessibleCARD-FILV4" 70 ) where
"attr inaccessibleCARD-FILV4 for AlephCARD-5M1 means
  (\<lambda>IT. IT be regularCARD-5V1\<bar>limit-cardinalCARD-1V2)"..

mtheorem card_fil_cl_4:
"cluster inaccessibleCARD-FILV4 also-is regularCARD-5V1\<bar>limit-cardinalCARD-1V2 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be inaccessibleCARD-FILV4 implies it be regularCARD-5V1\<bar>limit-cardinalCARD-1V2"
     sorry
qed "sorry"

mtheorem card_fil_th_25:
"omegaORDINAL1K4 be inaccessibleCARD-FILV4"
  using card_5_th_30 sorry

mdef card_fil_def_14 ("strong-limitCARD-FILV5" 70 ) where
"attr strong-limitCARD-FILV5 for AlephCARD-5M1 means
  (\<lambda>IT.  for N be CardinalCARD-1M1 holds N inTARSKIR2 IT implies expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 IT)"..

mtheorem card_fil_th_26:
"omegaORDINAL1K4 be strong-limitCARD-FILV5"
sorry

mtheorem card_fil_th_27:
" for M be AlephCARD-5M1 holds M be strong-limitCARD-FILV5 implies M be limit-cardinalCARD-1V2"
sorry

mtheorem card_fil_cl_5:
"cluster strong-limitCARD-FILV5 also-is limit-cardinalCARD-1V2 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be strong-limitCARD-FILV5 implies it be limit-cardinalCARD-1V2"
    using card_fil_th_27 sorry
qed "sorry"

mtheorem card_fil_th_28:
" for M be AlephCARD-5M1 holds GCHCARD-FILR5 implies (M be limit-cardinalCARD-1V2 implies M be strong-limitCARD-FILV5)"
sorry

mdef card_fil_def_15 ("strongly-inaccessibleCARD-FILV6" 70 ) where
"attr strongly-inaccessibleCARD-FILV6 for AlephCARD-5M1 means
  (\<lambda>IT. IT be regularCARD-5V1\<bar>strong-limitCARD-FILV5)"..

mtheorem card_fil_cl_6:
"cluster strongly-inaccessibleCARD-FILV6 also-is regularCARD-5V1\<bar>strong-limitCARD-FILV5 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be strongly-inaccessibleCARD-FILV6 implies it be regularCARD-5V1\<bar>strong-limitCARD-FILV5"
     sorry
qed "sorry"

mtheorem card_fil_th_29:
"omegaORDINAL1K4 be strongly-inaccessibleCARD-FILV6"
  using card_fil_th_26 card_5_th_30 sorry

mtheorem card_fil_th_30:
" for M be AlephCARD-5M1 holds M be strongly-inaccessibleCARD-FILV6 implies M be inaccessibleCARD-FILV4"
   sorry

mtheorem card_fil_cl_7:
"cluster strongly-inaccessibleCARD-FILV6 also-is inaccessibleCARD-FILV4 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be strongly-inaccessibleCARD-FILV6 implies it be inaccessibleCARD-FILV4"
     sorry
qed "sorry"

mtheorem card_fil_th_31:
" for M be AlephCARD-5M1 holds GCHCARD-FILR5 implies (M be inaccessibleCARD-FILV4 implies M be strongly-inaccessibleCARD-FILV6)"
  using card_fil_th_28 sorry

mdef card_fil_def_16 ("measurableCARD-FILV7" 70 ) where
"attr measurableCARD-FILV7 for AlephCARD-5M1 means
  (\<lambda>M.  ex Uf be FilterCARD-FILM1-of M st Uf is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M & Uf be  non principalCARD-FILV2\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub>)"..

mtheorem card_fil_th_32:
" for A be limit-ordinalORDINAL1V4\<bar>OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies (supORDINAL2K3 X =XBOOLE-0R4 A implies unionTARSKIK3 X =XBOOLE-0R4 A)"
sorry

mtheorem card_fil_th_33:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be regularCARD-5V1"
sorry

mtheorem card_fil_cl_8:
  mlet "M be AlephCARD-5M1"
"cluster nextcardCARD-1K2 M as-term-is  non limit-cardinalCARD-1V2"
proof
(*coherence*)
  show "nextcardCARD-1K2 M be  non limit-cardinalCARD-1V2"
     sorry
qed "sorry"

mtheorem card_fil_cl_9:
"cluster  non limit-cardinalCARD-1V2\<bar>infiniteFINSET-1V2 for CardinalCARD-1M1"
proof
(*existence*)
  show " ex it be CardinalCARD-1M1 st it be  non limit-cardinalCARD-1V2\<bar>infiniteFINSET-1V2"
sorry
qed "sorry"

mtheorem card_fil_cl_10:
"cluster  non limit-cardinalCARD-1V2 also-is regularCARD-5V1 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be  non limit-cardinalCARD-1V2 implies it be regularCARD-5V1"
sorry
qed "sorry"

mdef card_fil_def_17 ("predecessorCARD-FILK7  _ " [164]164 ) where
  mlet "M be  non limit-cardinalCARD-1V2\<bar>CardinalCARD-1M1"
"func predecessorCARD-FILK7 M \<rightarrow> CardinalCARD-1M1 means
  \<lambda>it. M =XBOOLE-0R4 nextcardCARD-1K2 it"
proof-
  (*existence*)
    show " ex it be CardinalCARD-1M1 st M =XBOOLE-0R4 nextcardCARD-1K2 it"
      using card_1_def_4 sorry
  (*uniqueness*)
    show " for it1 be CardinalCARD-1M1 holds  for it2 be CardinalCARD-1M1 holds M =XBOOLE-0R4 nextcardCARD-1K2 it1 & M =XBOOLE-0R4 nextcardCARD-1K2 it2 implies it1 =HIDDENR1 it2"
      using card_3_th_89 sorry
qed "sorry"

mtheorem card_fil_cl_11:
  mlet "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
"cluster predecessorCARD-FILK7 M as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "predecessorCARD-FILK7 M be infiniteFINSET-1V2"
sorry
qed "sorry"

syntax CARD_FILM3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Ty" ("Inf-MatrixCARD-FILM3-of'( _ , _ , _ ')" [0,0,0]70)
translations "Inf-MatrixCARD-FILM3-of(N,N1,X)" \<rightharpoonup> "FunctionFUNCT-2M1-of([:ZFMISC-1K2 N,N1 :],X)"

reserve X for "setHIDDENM2"
reserve M for " non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
reserve F for "FilterCARD-FILM1-of M"
reserve N1, N2, N3 for "ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
reserve K1, K2 for "ElementSUBSET-1M1-of M"
reserve T for "Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)"
mdef card_fil_def_18 (" _ is-Ulam-Matrix-ofCARD-FILR6  _ " [50,50]50 ) where
  mlet "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1", "T be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)"
"pred T is-Ulam-Matrix-ofCARD-FILR6 M means
  ((( for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds K1 <>HIDDENR2 K2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2) be emptyXBOOLE-0V1) & ( for K1 be ElementSUBSET-1M1-of M holds  for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds N1 <>HIDDENR2 N2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) be emptyXBOOLE-0V1)) & ( for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M)) & ( for K1 be ElementSUBSET-1M1-of M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M)"..

mtheorem card_fil_th_34:
" for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  ex T be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M) st T is-Ulam-Matrix-ofCARD-FILR6 M"
sorry

mtheorem card_fil_th_35:
" for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  for I be IdealCARD-FILM2-of M holds I is-complete-withCARD-FILR4\<^bsub>(M)\<^esub> M & Frechet-IdealCARD-FILK6 M c=TARSKIR1 I implies ( ex S be Subset-FamilySETFAM-1M1-of M st (cardCARD-1K1 S =XBOOLE-0R4 M & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 S implies  not X1 inTARSKIR2 I)) & ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds (X1 inTARSKIR2 S & X2 inTARSKIR2 S) & X1 <>HIDDENR2 X2 implies X1 missesXBOOLE-0R1 X2))"
sorry

mtheorem card_fil_th_36:
" for X be setHIDDENM2 holds  for N be CardinalCARD-1M1 holds N c=ORDINAL1R1 cardCARD-1K1 X implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 N)"
sorry

mtheorem card_fil_th_37:
" for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  not ( ex F be FilterCARD-FILM1-of M st F be uniformCARD-FILV1\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub> & F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M)"
sorry

reserve M for "AlephCARD-5M1"
mtheorem card_fil_th_38:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be limit-cardinalCARD-1V2"
sorry

mtheorem card_fil_th_39:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be inaccessibleCARD-FILV4"
  using card_fil_th_33 card_fil_th_38 sorry

mtheorem card_fil_th_40:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be strong-limitCARD-FILV5"
sorry

mtheorem card_fil_th_41:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be strongly-inaccessibleCARD-FILV6"
  using card_fil_th_33 card_fil_th_40 sorry

end
