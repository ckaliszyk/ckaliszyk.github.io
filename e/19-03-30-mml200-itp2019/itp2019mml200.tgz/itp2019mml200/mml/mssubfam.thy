theory mssubfam
  imports setfam_1 pzfmisc1 pre_circ
begin
(*begin*)
mtheorem mssubfam_cl_1:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster domsFUNCT-6K1 F as-term-is I -definedRELAT-1V4"
proof
(*coherence*)
  show "domsFUNCT-6K1 F be I -definedRELAT-1V4"
sorry
qed "sorry"

mtheorem mssubfam_cl_2:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster rngsFUNCT-6K2 F as-term-is I -definedRELAT-1V4"
proof
(*coherence*)
  show "rngsFUNCT-6K2 F be I -definedRELAT-1V4"
sorry
qed "sorry"

mtheorem mssubfam_cl_3:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster domsFUNCT-6K1 F as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 domsFUNCT-6K1 F implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
sorry
qed "sorry"

mtheorem mssubfam_cl_4:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster rngsFUNCT-6K2 F as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 rngsFUNCT-6K2 F implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
sorry
qed "sorry"

reserve I, G, H for "setHIDDENM2"
reserve i, x for "objectHIDDENM1"
reserve A, B, M for "ManySortedSetPBOOLEM1-of I"
reserve sf, sg, sh for "Subset-FamilySETFAM-1M1-of I"
reserve v, w for "SubsetSUBSET-1M2-of I"
reserve F for "ManySortedFunctionPBOOLEM2-of I"
theorem mssubfam_sch_1:
  fixes If0 Af0 Bf0 Pp3 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty]: "Af0 be ManySortedSetPBOOLEM1-of If0" and
  [ty]: "Bf0 be ManySortedSetPBOOLEM1-of If0" and
   A1: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Bf0 .FUNCT-1K1 i & Pp3(y,x,i)))"
  shows " ex F be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex f be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f =FUNCT-1R1 F .FUNCT-1K1 i & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f .FUNCT-1K1 x,x,i)))"
sorry

mtheorem mssubfam_th_1:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds sf <>HIDDENR2 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 unionSETFAM-1K5\<^bsub>(I)\<^esub> sf"
sorry

mtheorem mssubfam_th_2:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 G"
sorry

mtheorem mssubfam_th_3:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds {}XBOOLE-0K1 inTARSKIR2 sf implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem mssubfam_th_4:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for Z be SubsetSUBSET-1M2-of I holds ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies Z c=TARSKIR1 Z1) implies Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
sorry

mtheorem mssubfam_th_5:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds sf <>HIDDENR2 {}XBOOLE-0K1 & ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies G c=TARSKIR1 Z1) implies G c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
sorry

mtheorem mssubfam_th_6:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for H be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf & G c=TARSKIR1 H implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 H"
sorry

mtheorem mssubfam_th_7:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for H be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf & G missesXBOOLE-0R1 H implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf missesXBOOLE-0R1 H"
sorry

mtheorem mssubfam_th_8:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for sg be Subset-FamilySETFAM-1M1-of I holds  for sh be Subset-FamilySETFAM-1M1-of I holds sh =XBOOLE-0R4 sf \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 I)\<^esub> sg implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
sorry

mtheorem mssubfam_th_9:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for v be SubsetSUBSET-1M2-of I holds sf =XBOOLE-0R4 {TARSKIK1 v} implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v"
sorry

mtheorem mssubfam_th_10:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for v be SubsetSUBSET-1M2-of I holds  for w be SubsetSUBSET-1M2-of I holds sf =XBOOLE-0R4 {TARSKIK2 v,w } implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v /\\SUBSET-1K9\<^bsub>(I)\<^esub> w"
sorry

mtheorem mssubfam_th_11:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> B implies A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B"
sorry

mtheorem mssubfam_th_12:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B implies A inPBOOLER1\<^bsub>(I)\<^esub> B"
sorry

mtheorem mssubfam_th_13:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for f be FunctionFUNCT-1M1 holds i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies rngsFUNCT-6K2 F .FUNCT-1K1 i =XBOOLE-0R4 rngFUNCT-1K2 f"
sorry

mtheorem mssubfam_th_14:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for f be FunctionFUNCT-1M1 holds i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies domsFUNCT-6K1 F .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 f"
sorry

mtheorem mssubfam_th_15:
" for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for G be ManySortedFunctionPBOOLEM2-of I holds G **PBOOLEK8 F be ManySortedFunctionPBOOLEM2-of I"
sorry

mtheorem mssubfam_th_16:
" for I be setHIDDENM2 holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,EmptyMSPBOOLEK1 I) holds F =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem mssubfam_th_17:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM2-of I holds A is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B & F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B) implies domsFUNCT-6K1 F =PBOOLER7\<^bsub>(I)\<^esub> A & rngsFUNCT-6K2 F c=PBOOLER2\<^bsub>(I)\<^esub> B"
sorry

(*begin*)
mtheorem mssubfam_cl_5:
  mlet "I be setHIDDENM2"
"cluster empty-yieldingRELAT-1V3 also-is finite-yieldingFINSET-1V3 for ManySortedSetPBOOLEM1-of I"
proof
(*coherence*)
  show " for it be ManySortedSetPBOOLEM1-of I holds it be empty-yieldingRELAT-1V3 implies it be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_cl_6:
  mlet "I be setHIDDENM2"
"cluster EmptyMSPBOOLEK1 I as-term-is empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

mtheorem mssubfam_cl_7:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"cluster empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3 for ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A"
proof
(*existence*)
  show " ex it be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A st it be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_th_18:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B & B be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_cl_8:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster note-that finite-yieldingFINSET-1V3 for ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A"
proof
(*coherence*)
  show " for it be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A holds it be finite-yieldingFINSET-1V3"
    using pboole_def_18 mssubfam_th_18 sorry
qed "sorry"

mtheorem mssubfam_cl_9:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_cl_10:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_cl_11:
  mlet "I be setHIDDENM2", "B be ManySortedSetPBOOLEM1-of I", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

mtheorem mssubfam_cl_12:
  mlet "I be setHIDDENM2", "B be ManySortedSetPBOOLEM1-of I", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_cl_13:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_cl_14:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_th_19:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds B be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_th_20:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3 implies B be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_th_21:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds A be finite-yieldingFINSET-1V3 iff boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_cl_15:
  mlet "I be setHIDDENM2", "M be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> M as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be finite-yieldingFINSET-1V3"
    using mssubfam_th_21 sorry
qed "sorry"

mtheorem mssubfam_th_22:
" for I be setHIDDENM2 holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds A be finite-yieldingFINSET-1V3 & ( for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_th_23:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3 & ( for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3)"
sorry

mtheorem mssubfam_th_24:
" for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds domsFUNCT-6K1 F be finite-yieldingFINSET-1V3 implies rngsFUNCT-6K2 F be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_th_25:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM2-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F & ( for i be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies f \<inverse>FUNCT-1K6 (A .FUNCT-1K1 i) be finiteFINSET-1V1) implies A be finite-yieldingFINSET-1V3"
sorry

mtheorem mssubfam_cl_16:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster (Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "(Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) be finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_cl_17:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

reserve X, Y, Z for "ManySortedSetPBOOLEM1-of I"
mtheorem mssubfam_th_26:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X be finite-yieldingFINSET-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies ( ex A be ManySortedSetPBOOLEM1-of I st  ex B be ManySortedSetPBOOLEM1-of I st (((A be finite-yieldingFINSET-1V3 & A c=PBOOLER2\<^bsub>(I)\<^esub> Y) & B be finite-yieldingFINSET-1V3) & B c=PBOOLER2\<^bsub>(I)\<^esub> Z) & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |])"
sorry

mtheorem mssubfam_th_27:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X be finite-yieldingFINSET-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies ( ex A be ManySortedSetPBOOLEM1-of I st (A be finite-yieldingFINSET-1V3 & A c=PBOOLER2\<^bsub>(I)\<^esub> Y) & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,Z |])"
sorry

mtheorem mssubfam_th_28:
" for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I holds ( for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A) implies ( ex m be ManySortedSetPBOOLEM1-of I st m inPBOOLER1\<^bsub>(I)\<^esub> M & ( for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies m c=PBOOLER2\<^bsub>(I)\<^esub> K))"
sorry

mtheorem mssubfam_th_29:
" for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I holds ( for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A) implies ( ex m be ManySortedSetPBOOLEM1-of I st m inPBOOLER1\<^bsub>(I)\<^esub> M & ( for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies K c=PBOOLER2\<^bsub>(I)\<^esub> m))"
sorry

mtheorem mssubfam_th_30:
" for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z be finite-yieldingFINSET-1V3 & Z c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F implies ( ex Y be ManySortedSetPBOOLEM1-of I st (Y c=PBOOLER2\<^bsub>(I)\<^esub> domsFUNCT-6K1 F & Y be finite-yieldingFINSET-1V3) & F .:.:PBOOLEK9\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Z)"
sorry

(*begin*)
abbreviation(input) MSSUBFAMM1("MSSubsetFamilyMSSUBFAMM1\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70) where
  "MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M \<equiv> ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of boolMBOOLEANK1\<^bsub>(I)\<^esub> M"

mtheorem mssubfam_cl_18:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2"
sorry
qed "sorry"

abbreviation(input) MSSUBFAMK1("boolMSSUBFAMK1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228) where
  "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M \<equiv> boolMBOOLEANK1\<^bsub>(I)\<^esub> M"

mtheorem mssubfam_add_1:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> M as-term-is MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    using pboole_def_18 sorry
qed "sorry"

mtheorem mssubfam_cl_19:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem mssubfam_th_31:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  using pboole_th_43 pboole_def_18 sorry

mtheorem mssubfam_cl_20:
  mlet "I be setHIDDENM2", "M be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
sorry
qed "sorry"

reserve SF, SG, SH for "MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
reserve SFe for "non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
reserve V, W for "ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
syntax MSSUBFAMK2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .MSSUBFAMK2\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "SF .MSSUBFAMK2\<^bsub>(I,M)\<^esub> i" \<rightharpoonup> "SF .FUNCT-1K1 i"

mtheorem mssubfam_add_2:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M", "i be ElementSUBSET-1M1-of I"
"cluster SF .FUNCT-1K1 i as-term-is Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
proof
(*coherence*)
  show "SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
sorry
qed "sorry"

mtheorem mssubfam_th_32:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds i inHIDDENR3 I implies SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
sorry

mtheorem mssubfam_th_33:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF implies A be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_34:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_35:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_36:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> A be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_37:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_38:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> M implies {PZFMISC1K1\<^bsub>(I)\<^esub> A} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_39:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> M & B c=PBOOLER2\<^bsub>(I)\<^esub> M implies {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
sorry

mtheorem mssubfam_th_40:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds unionMBOOLEANK2\<^bsub>(I)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> M"
sorry

(*begin*)
mdef mssubfam_def_1 ("meetMSSUBFAMK3\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
"func meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)"
sorry
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it2 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

abbreviation(input) MSSUBFAMK4("meetMSSUBFAMK4\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228) where
  "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF \<equiv> meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF"

mtheorem mssubfam_add_3:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
"cluster meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF as-term-is ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show "meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
sorry
qed "sorry"

mtheorem mssubfam_th_41:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> M"
sorry

mtheorem mssubfam_th_42:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SFe be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> SFe"
sorry

mtheorem mssubfam_th_43:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> A"
sorry

mtheorem mssubfam_th_44:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem mssubfam_th_45:
" for I be setHIDDENM2 holds  for Z be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds ( for Z1 be ManySortedSetPBOOLEM1-of I holds Z1 inPBOOLER1\<^bsub>(I)\<^esub> SF implies Z c=PBOOLER2\<^bsub>(I)\<^esub> Z1) implies Z c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
sorry

mtheorem mssubfam_th_46:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF c=PBOOLER2\<^bsub>(I)\<^esub> SG implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
sorry

mtheorem mssubfam_th_47:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & A c=PBOOLER2\<^bsub>(I)\<^esub> B implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> B"
sorry

mtheorem mssubfam_th_48:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem mssubfam_th_49:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SH be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SH =PBOOLER7\<^bsub>(I)\<^esub> SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH =PBOOLER7\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG"
sorry

mtheorem mssubfam_th_50:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> V} implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V"
sorry

mtheorem mssubfam_th_51:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds  for W be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> V,W } implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W"
sorry

mtheorem mssubfam_th_52:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF implies ( for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B)"
sorry

mtheorem mssubfam_th_53:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> M & ( for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B) implies A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
sorry

mdef mssubfam_def_2 ("additiveMSSUBFAMV1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> IT & B inPBOOLER1\<^bsub>(I)\<^esub> IT implies A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_3 ("absolutely-additiveMSSUBFAMV2\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for F be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds F c=PBOOLER2\<^bsub>(I)\<^esub> IT implies unionMBOOLEANK2\<^bsub>(I)\<^esub> F inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_4 ("multiplicativeMSSUBFAMV3\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> IT & B inPBOOLER1\<^bsub>(I)\<^esub> IT implies A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_5 ("absolutely-multiplicativeMSSUBFAMV4\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for F be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds F c=PBOOLER2\<^bsub>(I)\<^esub> IT implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> F inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_6 ("properly-upper-boundMSSUBFAMV5\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT. M inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_7 ("properly-lower-boundMSSUBFAMV6\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT. EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mlemma mssubfam_lm_1:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
sorry

mtheorem mssubfam_cl_21:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2\<bar>additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2\<bar>additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
sorry
qed "sorry"

abbreviation(input) MSSUBFAMK5("boolMSSUBFAMK5\<^bsub>'( _ ')\<^esub>  _ " [0,228]228) where
  "boolMSSUBFAMK5\<^bsub>(I)\<^esub> M \<equiv> boolMBOOLEANK1\<^bsub>(I)\<^esub> M"

mtheorem mssubfam_add_4:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> M as-term-is additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    using mssubfam_lm_1 sorry
qed "sorry"

mtheorem mssubfam_cl_22:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> also-is additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> implies it be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>"
sorry
qed "sorry"

mtheorem mssubfam_cl_23:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> also-is multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> implies it be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>"
sorry
qed "sorry"

mtheorem mssubfam_cl_24:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> also-is properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> implies it be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>"
sorry
qed "sorry"

mtheorem mssubfam_cl_25:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> also-is non-emptyRELAT-1V2 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> implies it be non-emptyRELAT-1V2"
sorry
qed "sorry"

mtheorem mssubfam_cl_26:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> also-is properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> implies it be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
sorry
qed "sorry"

mtheorem mssubfam_cl_27:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> also-is non-emptyRELAT-1V2 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> implies it be non-emptyRELAT-1V2"
sorry
qed "sorry"

end
