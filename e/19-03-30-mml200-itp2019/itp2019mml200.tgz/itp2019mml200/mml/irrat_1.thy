theory irrat_1
  imports sin_cos rat_1 pepin finseq_5 limfunc1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, m, n, p, K, N for "NatNAT-1M1"
reserve i for "IntegerINT-1M1"
reserve x, y, eps for "RealXREAL-0M1"
reserve seq, seq1, seq2 for "Real-SequenceSEQ-1M1"
reserve sq for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
syntax IRRAT_1V1 :: "Ty" ("irrationalIRRAT-1V1" 70)
translations "irrationalIRRAT-1V1" \<rightharpoonup> " non rationalRAT-1V1"

abbreviation(input) IRRAT_1K1(" _ ^IRRAT-1K1  _ " [164,164]164) where
  "x ^IRRAT-1K1 y \<equiv> x to-powerPOWERK2 y"

(*\$N The Irrationality of the Square Root of 2*)
mtheorem irrat_1_th_1:
" for p be NatNAT-1M1 holds p be primeINT-2V1 implies sqrtSQUARE-1K3 p be irrationalIRRAT-1V1"
sorry

mtheorem irrat_1_th_2:
" ex x be RealXREAL-0M1 st  ex y be RealXREAL-0M1 st (x be irrationalIRRAT-1V1 & y be irrationalIRRAT-1V1) & x ^IRRAT-1K1 y be rationalRAT-1V1"
sorry

(*begin*)
theorem irrat_1_sch_1:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be RealXREAL-0M1"
  shows "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) implies seq1 =FUNCT-1R1 seq2)"
sorry

mdef irrat_1_def_1 ("aseqIRRAT-1K2  _ " [350]350 ) where
  mlet "k be NatNAT-1M1"
"func aseqIRRAT-1K2 k \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef irrat_1_def_2 ("bseqIRRAT-1K3  _ " [350]350 ) where
  mlet "k be NatNAT-1M1"
"func bseqIRRAT-1K3 k \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef irrat_1_def_3 ("cseqIRRAT-1K4  _ " [350]350 ) where
  mlet "n be NatNAT-1M1"
"func cseqIRRAT-1K4 n \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds it1 .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for k be NatNAT-1M1 holds it2 .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem irrat_1_th_3:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cseqIRRAT-1K4 n .FUNCT-1K1 k =COMPLEX1R1 bseqIRRAT-1K3 k .FUNCT-1K1 n"
sorry

mdef irrat_1_def_4 ("dseqIRRAT-1K5" 350 ) where
"func dseqIRRAT-1K5 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef irrat_1_def_5 ("eseqIRRAT-1K6" 350 ) where
"func eseqIRRAT-1K6 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds it1 .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & ( for k be NatNAT-1M1 holds it2 .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem irrat_1_th_4:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n"
sorry

mtheorem irrat_1_th_5:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
sorry

mtheorem irrat_1_th_6:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =COMPLEX1R1 ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
sorry

mtheorem irrat_1_th_7:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies aseqIRRAT-1K2 k .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n"
sorry

mtheorem irrat_1_th_8:
" for k be NatNAT-1M1 holds aseqIRRAT-1K2 k be convergentSEQ-2V5 & limSEQ-2K1 aseqIRRAT-1K2 k =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem irrat_1_th_9:
" for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 x) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x"
sorry

mtheorem irrat_1_th_10:
" for n be NatNAT-1M1 holds bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem irrat_1_th_11:
" for k be NatNAT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
sorry

mtheorem irrat_1_th_12:
" for k be NatNAT-1M1 holds (bseqIRRAT-1K3 k be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
sorry

mtheorem irrat_1_th_13:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <XXREAL-0R3 n implies 0NUMBERSK6 <XXREAL-0R3 aseqIRRAT-1K2 k .FUNCT-1K1 n & aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem irrat_1_th_14:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ((((0NUMBERSK6 <=XXREAL-0R1 bseqIRRAT-1K3 k .FUNCT-1K1 n & bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k) & 0NUMBERSK6 <=XXREAL-0R1 cseqIRRAT-1K4 n .FUNCT-1K1 k) & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
sorry

mtheorem irrat_1_th_15:
" for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be summableSERIES-1V1 implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
sorry

mtheorem irrat_1_th_16:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for sq be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 sq implies (sq /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =XBOOLE-0R4 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem irrat_1_th_17:
" for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 sq >XXREAL-0R4 0NUMBERSK6 implies SumRVSUM-1K22 sq =COMPLEX1R1 sq .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 SumRVSUM-1K22 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
sorry

mtheorem irrat_1_th_18:
" for n be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
sorry

mtheorem irrat_1_th_19:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds k <=XXREAL-0R1 n implies ((x,y)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (x ^IRRAT-1K1 (n -XCMPLX-0K6 k)))*XCMPLX-0K3 (y ^IRRAT-1K1 k)"
sorry

mtheorem irrat_1_th_20:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 & k <=XXREAL-0R1 n implies cseqIRRAT-1K4 n .FUNCT-1K1 k =COMPLEX1R1 ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem irrat_1_th_21:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (cseqIRRAT-1K4 n be summableSERIES-1V1 & SumSERIES-1K4 cseqIRRAT-1K4 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & SumSERIES-1K4 cseqIRRAT-1K4 n =COMPLEX1R1 dseqIRRAT-1K5 .FUNCT-1K1 n"
sorry

mtheorem irrat_1_th_22:
"dseqIRRAT-1K5 be convergentSEQ-2V5 & limSEQ-2K1 dseqIRRAT-1K5 =COMPLEX1R1 number-ePOWERK4"
sorry

mtheorem irrat_1_th_23:
"eseqIRRAT-1K6 be summableSERIES-1V1 & SumSERIES-1K4 eseqIRRAT-1K6 =HIDDENR1 exp-RSIN-COSK24 \<one>\<^sub>M"
sorry

mtheorem irrat_1_th_24:
" for K be NatNAT-1M1 holds  for dseqK be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K"
sorry

mtheorem irrat_1_th_25:
" for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x implies ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps))"
sorry

mtheorem irrat_1_th_26:
" for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps)) & ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n <=XXREAL-0R1 x) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x"
sorry

mtheorem irrat_1_th_27:
" for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 implies ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex K be NatNAT-1M1 st Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K >XXREAL-0R4 SumSERIES-1K4 seq -XCMPLX-0K6 eps))"
sorry

mtheorem irrat_1_th_28:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies dseqIRRAT-1K5 .FUNCT-1K1 n <=XXREAL-0R1 SumSERIES-1K4 eseqIRRAT-1K6"
sorry

mtheorem irrat_1_th_29:
" for K be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 & ( for k be NatNAT-1M1 holds seq .FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6) implies SumSERIES-1K4 seq >=XXREAL-0R2 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K"
sorry

mtheorem irrat_1_th_30:
"dseqIRRAT-1K5 be convergentSEQ-2V5 & limSEQ-2K1 dseqIRRAT-1K5 =COMPLEX1R1 SumSERIES-1K4 eseqIRRAT-1K6"
sorry

abbreviation(input) IRRAT_1K7("number-eIRRAT-1K7" 164) where
  "number-eIRRAT-1K7 \<equiv> number-ePOWERK4"

mtheorem irrat_1_def_6:
"redefine func number-eIRRAT-1K7 \<rightarrow> objectHIDDENM1 equals
  SumSERIES-1K4 eseqIRRAT-1K6"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 number-eIRRAT-1K7 iff it =HIDDENR1 SumSERIES-1K4 eseqIRRAT-1K6"
    using irrat_1_th_22 irrat_1_th_30 sorry
qed "sorry"

abbreviation(input) IRRAT_1K8("number-eIRRAT-1K8" 164) where
  "number-eIRRAT-1K8 \<equiv> number-ePOWERK4"

mtheorem irrat_1_def_7:
"redefine func number-eIRRAT-1K8 \<rightarrow> objectHIDDENM1 equals
  exp-RSIN-COSK24 \<one>\<^sub>M"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 number-eIRRAT-1K8 iff it =HIDDENR1 exp-RSIN-COSK24 \<one>\<^sub>M"
    using irrat_1_th_23 sorry
qed "sorry"

(*begin*)
mtheorem irrat_1_th_31:
" for x be RealXREAL-0M1 holds x be rationalRAT-1V1 implies ( ex n be NatNAT-1M1 st n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1)"
sorry

mtheorem irrat_1_th_32:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 k =COMPLEX1R1 (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7)"
sorry

mtheorem irrat_1_th_33:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) >XXREAL-0R4 0NUMBERSK6"
  using xreal_1_th_139 sorry

mtheorem irrat_1_th_34:
" for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6) implies SumSERIES-1K4 seq >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem irrat_1_th_35:
" for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem irrat_1_th_36:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
sorry

mtheorem irrat_1_th_37:
" for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n be integerINT-1V1"
sorry

mtheorem irrat_1_th_38:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem irrat_1_th_39:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds n >XXREAL-0R4 0NUMBERSK6 & x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x)"
sorry

mtheorem irrat_1_th_40:
" for x be RealXREAL-0M1 holds  for n be RealXREAL-0M1 holds n >=XXREAL-0R2 \<two>\<^sub>M & x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) implies x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x) <XXREAL-0R3 \<one>\<^sub>M"
sorry

(*\$N Irrationality of e*)
mtheorem irrat_1_th_41:
"number-eIRRAT-1K8 be irrationalIRRAT-1V1"
sorry

end
