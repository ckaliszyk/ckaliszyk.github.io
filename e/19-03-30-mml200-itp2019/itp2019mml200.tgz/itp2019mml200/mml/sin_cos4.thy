theory sin_cos4
  imports sin_cos
   "../mizar_extension/E_number"
begin
(*begin*)
reserve th, th1, th2, th3 for "RealXREAL-0M1"
mdef sin_cos4_def_1 ("tanSIN-COS4K1  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func tanSIN-COS4K1 th \<rightarrow> RealXREAL-0M1 equals
  (sinSIN-COSK18 th)/XCMPLX-0K7 (cosSIN-COSK20 th)"
proof-
  (*coherence*)
    show "(sinSIN-COSK18 th)/XCMPLX-0K7 (cosSIN-COSK20 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos4_def_2 ("cotSIN-COS4K2  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func cotSIN-COS4K2 th \<rightarrow> RealXREAL-0M1 equals
  (cosSIN-COSK20 th)/XCMPLX-0K7 (sinSIN-COSK18 th)"
proof-
  (*coherence*)
    show "(cosSIN-COSK20 th)/XCMPLX-0K7 (sinSIN-COSK18 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos4_def_3 ("cosecSIN-COS4K3  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func cosecSIN-COS4K3 th \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
proof-
  (*coherence*)
    show "\<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos4_def_4 ("secSIN-COS4K4  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func secSIN-COS4K4 th \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK20 th)"
proof-
  (*coherence*)
    show "\<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK20 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem sin_cos4_th_1:
" for th be RealXREAL-0M1 holds tanSIN-COS4K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 th"
sorry

mtheorem sin_cos4_th_2:
" for th be RealXREAL-0M1 holds cosecSIN-COS4K3 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
sorry

mtheorem sin_cos4_th_3:
" for th be RealXREAL-0M1 holds cotSIN-COS4K2 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 cotSIN-COS4K2 th"
sorry

mtheorem sin_cos4_th_4:
" for th be RealXREAL-0M1 holds (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)"
sorry

mtheorem sin_cos4_th_5:
" for th be RealXREAL-0M1 holds (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th)"
sorry

mtheorem sin_cos4_th_6:
" for th be RealXREAL-0M1 holds cosSIN-COSK20 th <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 th =HIDDENR1 (cosSIN-COSK20 th)*XCMPLX-0K3 (tanSIN-COS4K1 th)"
sorry

mtheorem sin_cos4_th_7:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (th1 +XCMPLX-0K2 th2) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
sorry

mtheorem sin_cos4_th_8:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
sorry

mtheorem sin_cos4_th_9:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1)"
sorry

mtheorem sin_cos4_th_10:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 -XCMPLX-0K6 cotSIN-COS4K2 th1)"
sorry

mtheorem sin_cos4_th_11:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))"
sorry

mtheorem sin_cos4_th_12:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
sorry

mtheorem sin_cos4_th_13:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))/XCMPLX-0K7 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
sorry

mtheorem sin_cos4_th_14:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6) & sinSIN-COSK18 th3 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((((cotSIN-COS4K2 th2)*XCMPLX-0K3 (cotSIN-COS4K2 th3) +XCMPLX-0K2 (cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th1))+XCMPLX-0K2 (cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))-XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem sin_cos4_th_15:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
sorry

mtheorem sin_cos4_th_16:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
sorry

mtheorem sin_cos4_th_17:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
sorry

mtheorem sin_cos4_th_18:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
sorry

mtheorem sin_cos4_th_19:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
sorry

mtheorem sin_cos4_th_20:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
sorry

mtheorem sin_cos4_th_21:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
sorry

mtheorem sin_cos4_th_22:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
sorry

mtheorem sin_cos4_th_23:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
sorry

mtheorem sin_cos4_th_24:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
sorry

mtheorem sin_cos4_th_25:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
sorry

mtheorem sin_cos4_th_26:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
sorry

mtheorem sin_cos4_th_27:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
sorry

mtheorem sin_cos4_th_28:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
sorry

mtheorem sin_cos4_th_29:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
sorry

mtheorem sin_cos4_th_30:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
sorry

mtheorem sin_cos4_th_31:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
sorry

mtheorem sin_cos4_th_32:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
sorry

mtheorem sin_cos4_th_33:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
sorry

mtheorem sin_cos4_th_34:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 ((((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
sorry

mtheorem sin_cos4_th_35:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
sorry

mtheorem sin_cos4_th_36:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
sorry

mtheorem sin_cos4_th_37:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
sorry

mtheorem sin_cos4_th_38:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)"
sorry

mtheorem sin_cos4_th_39:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
sorry

mtheorem sin_cos4_th_40:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
sorry

mtheorem sin_cos4_th_41:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
sorry

mtheorem sin_cos4_th_42:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)"
sorry

mtheorem sin_cos4_th_43:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)"
sorry

mtheorem sin_cos4_th_44:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
sorry

mtheorem sin_cos4_th_45:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2) =HIDDENR1 (tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos4_th_46:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos4_th_47:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos4_th_48:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos4_th_49:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos4_th_50:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2) =HIDDENR1 (cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

end
