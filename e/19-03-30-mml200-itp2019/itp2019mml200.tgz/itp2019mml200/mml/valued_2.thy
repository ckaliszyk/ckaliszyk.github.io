theory valued_2
  imports binop_1 rat_1 finseq_1 rfunct_1 relat_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y for "objectHIDDENM1"
reserve X, X1, X2 for "setHIDDENM2"
mlemma valued_2_lm_1:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds X1 /\\XBOOLE-0K3 (X2 /\\XBOOLE-0K3 X3) =HIDDENR1 (X1 /\\XBOOLE-0K3 X2)/\\XBOOLE-0K3 (X1 /\\XBOOLE-0K3 X3)"
sorry

mdef valued_2_def_1 ("DOMSVALUED-2K1  _ " [164]164 ) where
  mlet "Y be functionalFUNCT-1V6\<bar>setHIDDENM2"
"func DOMSVALUED-2K1 Y \<rightarrow> setHIDDENM2 equals
  unionTARSKIK3 ({domRELAT-1K1 f where f be ElementSUBSET-1M1-of Y :  True  })"
proof-
  (*coherence*)
    show "unionTARSKIK3 ({domRELAT-1K1 f where f be ElementSUBSET-1M1-of Y :  True  }) be setHIDDENM2"
       sorry
qed "sorry"

mdef valued_2_def_2 ("complex-functions-memberedVALUED-2V1" 70 ) where
"attr complex-functions-memberedVALUED-2V1 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1)"..

mdef valued_2_def_3 ("ext-real-functions-memberedVALUED-2V2" 70 ) where
"attr ext-real-functions-memberedVALUED-2V2 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1)"..

mdef valued_2_def_4 ("real-functions-memberedVALUED-2V3" 70 ) where
"attr real-functions-memberedVALUED-2V3 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1)"..

mdef valued_2_def_5 ("rational-functions-memberedVALUED-2V4" 70 ) where
"attr rational-functions-memberedVALUED-2V4 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1)"..

mdef valued_2_def_6 ("integer-functions-memberedVALUED-2V5" 70 ) where
"attr integer-functions-memberedVALUED-2V5 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1)"..

mdef valued_2_def_7 ("natural-functions-memberedVALUED-2V6" 70 ) where
"attr natural-functions-memberedVALUED-2V6 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1)"..

mtheorem valued_2_cl_1:
"cluster natural-functions-memberedVALUED-2V6 also-is integer-functions-memberedVALUED-2V5 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be natural-functions-memberedVALUED-2V6 implies it be integer-functions-memberedVALUED-2V5"
sorry
qed "sorry"

mtheorem valued_2_cl_2:
"cluster integer-functions-memberedVALUED-2V5 also-is rational-functions-memberedVALUED-2V4 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be integer-functions-memberedVALUED-2V5 implies it be rational-functions-memberedVALUED-2V4"
sorry
qed "sorry"

mtheorem valued_2_cl_3:
"cluster rational-functions-memberedVALUED-2V4 also-is real-functions-memberedVALUED-2V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be rational-functions-memberedVALUED-2V4 implies it be real-functions-memberedVALUED-2V3"
     sorry
qed "sorry"

mtheorem valued_2_cl_4:
"cluster real-functions-memberedVALUED-2V3 also-is complex-functions-memberedVALUED-2V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be real-functions-memberedVALUED-2V3 implies it be complex-functions-memberedVALUED-2V1"
     sorry
qed "sorry"

mtheorem valued_2_cl_5:
"cluster real-functions-memberedVALUED-2V3 also-is ext-real-functions-memberedVALUED-2V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be real-functions-memberedVALUED-2V3 implies it be ext-real-functions-memberedVALUED-2V2"
     sorry
qed "sorry"

mtheorem valued_2_cl_6:
"cluster emptyXBOOLE-0V1 also-is natural-functions-memberedVALUED-2V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be natural-functions-memberedVALUED-2V6"
     sorry
qed "sorry"

mtheorem valued_2_cl_7:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster {TARSKIK1 f} as-term-is complex-functions-memberedVALUED-2V1"
proof
(*coherence*)
  show "{TARSKIK1 f} be complex-functions-memberedVALUED-2V1"
    using tarski_def_1 sorry
qed "sorry"

mtheorem valued_2_cl_8:
"cluster complex-functions-memberedVALUED-2V1 also-is functionalFUNCT-1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be complex-functions-memberedVALUED-2V1 implies it be functionalFUNCT-1V6"
sorry
qed "sorry"

mtheorem valued_2_cl_9:
"cluster ext-real-functions-memberedVALUED-2V2 also-is functionalFUNCT-1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be ext-real-functions-memberedVALUED-2V2 implies it be functionalFUNCT-1V6"
sorry
qed "sorry"

mtheorem valued_2_cl_10:
"cluster natural-functions-memberedVALUED-2V6\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be natural-functions-memberedVALUED-2V6\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem valued_2_cl_11:
  mlet "X be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2"
"cluster note-that complex-functions-memberedVALUED-2V1 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be complex-functions-memberedVALUED-2V1"
    using valued_2_def_2 sorry
qed "sorry"

mtheorem valued_2_cl_12:
  mlet "X be ext-real-functions-memberedVALUED-2V2\<bar>setHIDDENM2"
"cluster note-that ext-real-functions-memberedVALUED-2V2 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be ext-real-functions-memberedVALUED-2V2"
    using valued_2_def_3 sorry
qed "sorry"

mtheorem valued_2_cl_13:
  mlet "X be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2"
"cluster note-that real-functions-memberedVALUED-2V3 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be real-functions-memberedVALUED-2V3"
    using valued_2_def_4 sorry
qed "sorry"

mtheorem valued_2_cl_14:
  mlet "X be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2"
"cluster note-that rational-functions-memberedVALUED-2V4 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be rational-functions-memberedVALUED-2V4"
    using valued_2_def_5 sorry
qed "sorry"

mtheorem valued_2_cl_15:
  mlet "X be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2"
"cluster note-that integer-functions-memberedVALUED-2V5 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be integer-functions-memberedVALUED-2V5"
    using valued_2_def_6 sorry
qed "sorry"

mtheorem valued_2_cl_16:
  mlet "X be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2"
"cluster note-that natural-functions-memberedVALUED-2V6 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be natural-functions-memberedVALUED-2V6"
    using valued_2_def_7 sorry
qed "sorry"

mdef valued_2_def_8 ("C-PFuncsVALUED-2K2  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func C-PFuncsVALUED-2K2 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,COMPLEXNUMBERSK3)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,COMPLEXNUMBERSK3)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be PartFuncPARTFUN1M1-of(D,COMPLEXNUMBERSK3)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be PartFuncPARTFUN1M1-of(D,COMPLEXNUMBERSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_9 ("C-FuncsVALUED-2K3  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func C-FuncsVALUED-2K3 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,COMPLEXNUMBERSK3)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,COMPLEXNUMBERSK3)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be FunctionFUNCT-2M1-of(D,COMPLEXNUMBERSK3)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be FunctionFUNCT-2M1-of(D,COMPLEXNUMBERSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_10 ("E-PFuncsVALUED-2K4  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func E-PFuncsVALUED-2K4 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,ExtREALNUMBERSK7)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,ExtREALNUMBERSK7)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be PartFuncPARTFUN1M1-of(D,ExtREALNUMBERSK7)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be PartFuncPARTFUN1M1-of(D,ExtREALNUMBERSK7)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_11 ("E-FuncsVALUED-2K5  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func E-FuncsVALUED-2K5 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,ExtREALNUMBERSK7)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,ExtREALNUMBERSK7)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be FunctionFUNCT-2M1-of(D,ExtREALNUMBERSK7)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be FunctionFUNCT-2M1-of(D,ExtREALNUMBERSK7)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_12 ("R-PFuncsVALUED-2K6  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func R-PFuncsVALUED-2K6 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_13 ("R-FuncsVALUED-2K7  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func R-FuncsVALUED-2K7 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,REALNUMBERSK2)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,REALNUMBERSK2)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be FunctionFUNCT-2M1-of(D,REALNUMBERSK2)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be FunctionFUNCT-2M1-of(D,REALNUMBERSK2)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_14 ("Q-PFuncsVALUED-2K8  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func Q-PFuncsVALUED-2K8 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,RATRAT-1K1)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,RATRAT-1K1)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be PartFuncPARTFUN1M1-of(D,RATRAT-1K1)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be PartFuncPARTFUN1M1-of(D,RATRAT-1K1)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_15 ("Q-FuncsVALUED-2K9  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func Q-FuncsVALUED-2K9 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,RATRAT-1K1)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,RATRAT-1K1)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be FunctionFUNCT-2M1-of(D,RATRAT-1K1)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be FunctionFUNCT-2M1-of(D,RATRAT-1K1)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_16 ("I-PFuncsVALUED-2K10  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func I-PFuncsVALUED-2K10 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,INTINT-1K1)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,INTINT-1K1)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be PartFuncPARTFUN1M1-of(D,INTINT-1K1)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be PartFuncPARTFUN1M1-of(D,INTINT-1K1)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_17 ("I-FuncsVALUED-2K11  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func I-FuncsVALUED-2K11 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,INTINT-1K1)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,INTINT-1K1)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be FunctionFUNCT-2M1-of(D,INTINT-1K1)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be FunctionFUNCT-2M1-of(D,INTINT-1K1)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_18 ("N-PFuncsVALUED-2K12  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func N-PFuncsVALUED-2K12 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,NATNUMBERSK1)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be PartFuncPARTFUN1M1-of(D,NATNUMBERSK1)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be PartFuncPARTFUN1M1-of(D,NATNUMBERSK1)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be PartFuncPARTFUN1M1-of(D,NATNUMBERSK1)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_19 ("N-FuncsVALUED-2K13  _ " [164]164 ) where
  mlet "D be setHIDDENM2"
"func N-FuncsVALUED-2K13 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,NATNUMBERSK1)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for f be objectHIDDENM1 holds f inHIDDENR3 it iff f be FunctionFUNCT-2M1-of(D,NATNUMBERSK1)"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for f be objectHIDDENM1 holds f inHIDDENR3 it1 iff f be FunctionFUNCT-2M1-of(D,NATNUMBERSK1)) & ( for f be objectHIDDENM1 holds f inHIDDENR3 it2 iff f be FunctionFUNCT-2M1-of(D,NATNUMBERSK1)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem valued_2_th_1:
" for X be setHIDDENM2 holds C-FuncsVALUED-2K3 X be SubsetSUBSET-1M2-of C-PFuncsVALUED-2K2 X"
sorry

mtheorem valued_2_th_2:
" for X be setHIDDENM2 holds E-FuncsVALUED-2K5 X be SubsetSUBSET-1M2-of E-PFuncsVALUED-2K4 X"
sorry

mtheorem valued_2_th_3:
" for X be setHIDDENM2 holds R-FuncsVALUED-2K7 X be SubsetSUBSET-1M2-of R-PFuncsVALUED-2K6 X"
sorry

mtheorem valued_2_th_4:
" for X be setHIDDENM2 holds Q-FuncsVALUED-2K9 X be SubsetSUBSET-1M2-of Q-PFuncsVALUED-2K8 X"
sorry

mtheorem valued_2_th_5:
" for X be setHIDDENM2 holds I-FuncsVALUED-2K11 X be SubsetSUBSET-1M2-of I-PFuncsVALUED-2K10 X"
sorry

mtheorem valued_2_th_6:
" for X be setHIDDENM2 holds N-FuncsVALUED-2K13 X be SubsetSUBSET-1M2-of N-PFuncsVALUED-2K12 X"
sorry

mtheorem valued_2_cl_17:
  mlet "X be setHIDDENM2"
"cluster C-PFuncsVALUED-2K2 X as-term-is complex-functions-memberedVALUED-2V1"
proof
(*coherence*)
  show "C-PFuncsVALUED-2K2 X be complex-functions-memberedVALUED-2V1"
    using valued_2_def_8 sorry
qed "sorry"

mtheorem valued_2_cl_18:
  mlet "X be setHIDDENM2"
"cluster C-FuncsVALUED-2K3 X as-term-is complex-functions-memberedVALUED-2V1"
proof
(*coherence*)
  show "C-FuncsVALUED-2K3 X be complex-functions-memberedVALUED-2V1"
sorry
qed "sorry"

mtheorem valued_2_cl_19:
  mlet "X be setHIDDENM2"
"cluster E-PFuncsVALUED-2K4 X as-term-is ext-real-functions-memberedVALUED-2V2"
proof
(*coherence*)
  show "E-PFuncsVALUED-2K4 X be ext-real-functions-memberedVALUED-2V2"
    using valued_2_def_10 sorry
qed "sorry"

mtheorem valued_2_cl_20:
  mlet "X be setHIDDENM2"
"cluster E-FuncsVALUED-2K5 X as-term-is ext-real-functions-memberedVALUED-2V2"
proof
(*coherence*)
  show "E-FuncsVALUED-2K5 X be ext-real-functions-memberedVALUED-2V2"
sorry
qed "sorry"

mtheorem valued_2_cl_21:
  mlet "X be setHIDDENM2"
"cluster R-PFuncsVALUED-2K6 X as-term-is real-functions-memberedVALUED-2V3"
proof
(*coherence*)
  show "R-PFuncsVALUED-2K6 X be real-functions-memberedVALUED-2V3"
    using valued_2_def_12 sorry
qed "sorry"

mtheorem valued_2_cl_22:
  mlet "X be setHIDDENM2"
"cluster R-FuncsVALUED-2K7 X as-term-is real-functions-memberedVALUED-2V3"
proof
(*coherence*)
  show "R-FuncsVALUED-2K7 X be real-functions-memberedVALUED-2V3"
sorry
qed "sorry"

mtheorem valued_2_cl_23:
  mlet "X be setHIDDENM2"
"cluster Q-PFuncsVALUED-2K8 X as-term-is rational-functions-memberedVALUED-2V4"
proof
(*coherence*)
  show "Q-PFuncsVALUED-2K8 X be rational-functions-memberedVALUED-2V4"
    using valued_2_def_14 sorry
qed "sorry"

mtheorem valued_2_cl_24:
  mlet "X be setHIDDENM2"
"cluster Q-FuncsVALUED-2K9 X as-term-is rational-functions-memberedVALUED-2V4"
proof
(*coherence*)
  show "Q-FuncsVALUED-2K9 X be rational-functions-memberedVALUED-2V4"
sorry
qed "sorry"

mtheorem valued_2_cl_25:
  mlet "X be setHIDDENM2"
"cluster I-PFuncsVALUED-2K10 X as-term-is integer-functions-memberedVALUED-2V5"
proof
(*coherence*)
  show "I-PFuncsVALUED-2K10 X be integer-functions-memberedVALUED-2V5"
    using valued_2_def_16 sorry
qed "sorry"

mtheorem valued_2_cl_26:
  mlet "X be setHIDDENM2"
"cluster I-FuncsVALUED-2K11 X as-term-is integer-functions-memberedVALUED-2V5"
proof
(*coherence*)
  show "I-FuncsVALUED-2K11 X be integer-functions-memberedVALUED-2V5"
sorry
qed "sorry"

mtheorem valued_2_cl_27:
  mlet "X be setHIDDENM2"
"cluster N-PFuncsVALUED-2K12 X as-term-is natural-functions-memberedVALUED-2V6"
proof
(*coherence*)
  show "N-PFuncsVALUED-2K12 X be natural-functions-memberedVALUED-2V6"
    using valued_2_def_18 sorry
qed "sorry"

mtheorem valued_2_cl_28:
  mlet "X be setHIDDENM2"
"cluster N-FuncsVALUED-2K13 X as-term-is natural-functions-memberedVALUED-2V6"
proof
(*coherence*)
  show "N-FuncsVALUED-2K13 X be natural-functions-memberedVALUED-2V6"
sorry
qed "sorry"

mtheorem valued_2_cl_29:
  mlet "X be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2"
"cluster note-that complex-valuedVALUED-0V5 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem valued_2_cl_30:
  mlet "X be ext-real-functions-memberedVALUED-2V2\<bar>setHIDDENM2"
"cluster note-that ext-real-valuedVALUED-0V6 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be ext-real-valuedVALUED-0V6"
sorry
qed "sorry"

mtheorem valued_2_cl_31:
  mlet "X be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2"
"cluster note-that real-valuedVALUED-0V7 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem valued_2_cl_32:
  mlet "X be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2"
"cluster note-that RATRAT-1K1 -valuedRELAT-1V5 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be RATRAT-1K1 -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem valued_2_cl_33:
  mlet "X be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2"
"cluster note-that INTINT-1K1 -valuedRELAT-1V5 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be INTINT-1K1 -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem valued_2_cl_34:
  mlet "X be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2"
"cluster note-that natural-valuedVALUED-0V8 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem valued_2_cl_35:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem valued_2_cl_36:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be ext-real-functions-memberedVALUED-2V2\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem valued_2_cl_37:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem valued_2_cl_38:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be ext-real-functions-memberedVALUED-2V2\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is ext-real-valuedVALUED-0V6"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be ext-real-valuedVALUED-0V6"
sorry
qed "sorry"

mtheorem valued_2_cl_39:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem valued_2_cl_40:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be RATRAT-1K1 -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem valued_2_cl_41:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be INTINT-1K1 -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem valued_2_cl_42:
  mlet "X be setHIDDENM2", "x be objectHIDDENM1", "Y be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster f .FUNCT-1K1 x as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem valued_2_cl_43:
  mlet "X be setHIDDENM2", "Y be complex-memberedMEMBEREDV1\<bar>setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is complex-functions-memberedVALUED-2V1"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be complex-functions-memberedVALUED-2V1"
sorry
qed "sorry"

mtheorem valued_2_cl_44:
  mlet "X be setHIDDENM2", "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is ext-real-functions-memberedVALUED-2V2"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be ext-real-functions-memberedVALUED-2V2"
sorry
qed "sorry"

mtheorem valued_2_cl_45:
  mlet "X be setHIDDENM2", "Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is real-functions-memberedVALUED-2V3"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be real-functions-memberedVALUED-2V3"
sorry
qed "sorry"

mtheorem valued_2_cl_46:
  mlet "X be setHIDDENM2", "Y be rational-memberedMEMBEREDV4\<bar>setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is rational-functions-memberedVALUED-2V4"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be rational-functions-memberedVALUED-2V4"
sorry
qed "sorry"

mtheorem valued_2_cl_47:
  mlet "X be setHIDDENM2", "Y be integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is integer-functions-memberedVALUED-2V5"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be integer-functions-memberedVALUED-2V5"
sorry
qed "sorry"

mtheorem valued_2_cl_48:
  mlet "X be setHIDDENM2", "Y be natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is natural-functions-memberedVALUED-2V6"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be natural-functions-memberedVALUED-2V6"
sorry
qed "sorry"

mtheorem valued_2_cl_49:
  mlet "X be setHIDDENM2", "Y be complex-memberedMEMBEREDV1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is complex-functions-memberedVALUED-2V1"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be complex-functions-memberedVALUED-2V1"
sorry
qed "sorry"

mtheorem valued_2_cl_50:
  mlet "X be setHIDDENM2", "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is ext-real-functions-memberedVALUED-2V2"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be ext-real-functions-memberedVALUED-2V2"
sorry
qed "sorry"

mtheorem valued_2_cl_51:
  mlet "X be setHIDDENM2", "Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is real-functions-memberedVALUED-2V3"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be real-functions-memberedVALUED-2V3"
sorry
qed "sorry"

mtheorem valued_2_cl_52:
  mlet "X be setHIDDENM2", "Y be rational-memberedMEMBEREDV4\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is rational-functions-memberedVALUED-2V4"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be rational-functions-memberedVALUED-2V4"
sorry
qed "sorry"

mtheorem valued_2_cl_53:
  mlet "X be setHIDDENM2", "Y be integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is integer-functions-memberedVALUED-2V5"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be integer-functions-memberedVALUED-2V5"
sorry
qed "sorry"

mtheorem valued_2_cl_54:
  mlet "X be setHIDDENM2", "Y be natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is natural-functions-memberedVALUED-2V6"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be natural-functions-memberedVALUED-2V6"
sorry
qed "sorry"

mdef valued_2_def_20 ("complex-functions-valuedVALUED-2V7" 70 ) where
"attr complex-functions-valuedVALUED-2V7 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be complex-functions-memberedVALUED-2V1)"..

mdef valued_2_def_21 ("ext-real-functions-valuedVALUED-2V8" 70 ) where
"attr ext-real-functions-valuedVALUED-2V8 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be ext-real-functions-memberedVALUED-2V2)"..

mdef valued_2_def_22 ("real-functions-valuedVALUED-2V9" 70 ) where
"attr real-functions-valuedVALUED-2V9 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be real-functions-memberedVALUED-2V3)"..

mdef valued_2_def_23 ("rational-functions-valuedVALUED-2V10" 70 ) where
"attr rational-functions-valuedVALUED-2V10 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be rational-functions-memberedVALUED-2V4)"..

mdef valued_2_def_24 ("integer-functions-valuedVALUED-2V11" 70 ) where
"attr integer-functions-valuedVALUED-2V11 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be integer-functions-memberedVALUED-2V5)"..

mdef valued_2_def_25 ("natural-functions-valuedVALUED-2V12" 70 ) where
"attr natural-functions-valuedVALUED-2V12 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be natural-functions-memberedVALUED-2V6)"..

mtheorem valued_2_cl_55:
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2"
"cluster note-that complex-functions-valuedVALUED-2V7 for Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds it be complex-functions-valuedVALUED-2V7"
sorry
qed "sorry"

abbreviation(input) VALUED_2V13("complex-functions-valuedVALUED-2V13" 70) where
  "complex-functions-valuedVALUED-2V13 \<equiv> complex-functions-valuedVALUED-2V7"

mtheorem valued_2_def_26:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr complex-functions-valuedVALUED-2V13 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be complex-functions-valuedVALUED-2V13 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1)"
sorry
qed "sorry"

abbreviation(input) VALUED_2V14("ext-real-functions-valuedVALUED-2V14" 70) where
  "ext-real-functions-valuedVALUED-2V14 \<equiv> ext-real-functions-valuedVALUED-2V8"

mtheorem valued_2_def_27:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr ext-real-functions-valuedVALUED-2V14 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be ext-real-functions-valuedVALUED-2V14 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1)"
sorry
qed "sorry"

abbreviation(input) VALUED_2V15("real-functions-valuedVALUED-2V15" 70) where
  "real-functions-valuedVALUED-2V15 \<equiv> real-functions-valuedVALUED-2V9"

mtheorem valued_2_def_28:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr real-functions-valuedVALUED-2V15 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be real-functions-valuedVALUED-2V15 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1)"
sorry
qed "sorry"

abbreviation(input) VALUED_2V16("rational-functions-valuedVALUED-2V16" 70) where
  "rational-functions-valuedVALUED-2V16 \<equiv> rational-functions-valuedVALUED-2V10"

mtheorem valued_2_def_29:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr rational-functions-valuedVALUED-2V16 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be rational-functions-valuedVALUED-2V16 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1)"
sorry
qed "sorry"

abbreviation(input) VALUED_2V17("integer-functions-valuedVALUED-2V17" 70) where
  "integer-functions-valuedVALUED-2V17 \<equiv> integer-functions-valuedVALUED-2V11"

mtheorem valued_2_def_30:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr integer-functions-valuedVALUED-2V17 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be integer-functions-valuedVALUED-2V17 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1)"
sorry
qed "sorry"

abbreviation(input) VALUED_2V18("natural-functions-valuedVALUED-2V18" 70) where
  "natural-functions-valuedVALUED-2V18 \<equiv> natural-functions-valuedVALUED-2V12"

mtheorem valued_2_def_31:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr natural-functions-valuedVALUED-2V18 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be natural-functions-valuedVALUED-2V18 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1)"
sorry
qed "sorry"

mtheorem valued_2_cl_56:
"cluster natural-functions-valuedVALUED-2V12 also-is integer-functions-valuedVALUED-2V11 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be natural-functions-valuedVALUED-2V12 implies it be integer-functions-valuedVALUED-2V11"
     sorry
qed "sorry"

mtheorem valued_2_cl_57:
"cluster integer-functions-valuedVALUED-2V11 also-is rational-functions-valuedVALUED-2V10 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be integer-functions-valuedVALUED-2V11 implies it be rational-functions-valuedVALUED-2V10"
     sorry
qed "sorry"

mtheorem valued_2_cl_58:
"cluster rational-functions-valuedVALUED-2V10 also-is real-functions-valuedVALUED-2V9 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be rational-functions-valuedVALUED-2V10 implies it be real-functions-valuedVALUED-2V9"
     sorry
qed "sorry"

mtheorem valued_2_cl_59:
"cluster real-functions-valuedVALUED-2V9 also-is ext-real-functions-valuedVALUED-2V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be real-functions-valuedVALUED-2V9 implies it be ext-real-functions-valuedVALUED-2V8"
     sorry
qed "sorry"

mtheorem valued_2_cl_60:
"cluster real-functions-valuedVALUED-2V9 also-is complex-functions-valuedVALUED-2V7 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be real-functions-valuedVALUED-2V9 implies it be complex-functions-valuedVALUED-2V7"
     sorry
qed "sorry"

mtheorem valued_2_cl_61:
"cluster emptyXBOOLE-0V1 also-is natural-functions-valuedVALUED-2V12 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be natural-functions-valuedVALUED-2V12"
     sorry
qed "sorry"

mtheorem valued_2_cl_62:
"cluster natural-functions-valuedVALUED-2V18 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be natural-functions-valuedVALUED-2V18"
sorry
qed "sorry"

mtheorem valued_2_cl_63:
  mlet "R be complex-functions-valuedVALUED-2V7\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is complex-functions-memberedVALUED-2V1"
proof
(*coherence*)
  show "rngRELAT-1K2 R be complex-functions-memberedVALUED-2V1"
    using valued_2_def_20 sorry
qed "sorry"

mtheorem valued_2_cl_64:
  mlet "R be ext-real-functions-valuedVALUED-2V8\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is ext-real-functions-memberedVALUED-2V2"
proof
(*coherence*)
  show "rngRELAT-1K2 R be ext-real-functions-memberedVALUED-2V2"
    using valued_2_def_21 sorry
qed "sorry"

mtheorem valued_2_cl_65:
  mlet "R be real-functions-valuedVALUED-2V9\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is real-functions-memberedVALUED-2V3"
proof
(*coherence*)
  show "rngRELAT-1K2 R be real-functions-memberedVALUED-2V3"
    using valued_2_def_22 sorry
qed "sorry"

mtheorem valued_2_cl_66:
  mlet "R be rational-functions-valuedVALUED-2V10\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is rational-functions-memberedVALUED-2V4"
proof
(*coherence*)
  show "rngRELAT-1K2 R be rational-functions-memberedVALUED-2V4"
    using valued_2_def_23 sorry
qed "sorry"

mtheorem valued_2_cl_67:
  mlet "R be integer-functions-valuedVALUED-2V11\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is integer-functions-memberedVALUED-2V5"
proof
(*coherence*)
  show "rngRELAT-1K2 R be integer-functions-memberedVALUED-2V5"
    using valued_2_def_24 sorry
qed "sorry"

mtheorem valued_2_cl_68:
  mlet "R be natural-functions-valuedVALUED-2V12\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is natural-functions-memberedVALUED-2V6"
proof
(*coherence*)
  show "rngRELAT-1K2 R be natural-functions-memberedVALUED-2V6"
    using valued_2_def_25 sorry
qed "sorry"

mtheorem valued_2_cl_69:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2"
"cluster note-that complex-functions-valuedVALUED-2V13 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be complex-functions-valuedVALUED-2V13"
     sorry
qed "sorry"

mtheorem valued_2_cl_70:
  mlet "X be setHIDDENM2", "Y be ext-real-functions-memberedVALUED-2V2\<bar>setHIDDENM2"
"cluster note-that ext-real-functions-valuedVALUED-2V14 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be ext-real-functions-valuedVALUED-2V14"
     sorry
qed "sorry"

mtheorem valued_2_cl_71:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2"
"cluster note-that real-functions-valuedVALUED-2V15 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be real-functions-valuedVALUED-2V15"
     sorry
qed "sorry"

mtheorem valued_2_cl_72:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2"
"cluster note-that rational-functions-valuedVALUED-2V16 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be rational-functions-valuedVALUED-2V16"
     sorry
qed "sorry"

mtheorem valued_2_cl_73:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2"
"cluster note-that integer-functions-valuedVALUED-2V17 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be integer-functions-valuedVALUED-2V17"
     sorry
qed "sorry"

mtheorem valued_2_cl_74:
  mlet "X be setHIDDENM2", "Y be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2"
"cluster note-that natural-functions-valuedVALUED-2V18 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be natural-functions-valuedVALUED-2V18"
     sorry
qed "sorry"

mtheorem valued_2_cl_75:
"cluster complex-functions-valuedVALUED-2V13 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be complex-functions-valuedVALUED-2V13 implies it be Function-yieldingFUNCOP-1V1"
sorry
qed "sorry"

mtheorem valued_2_cl_76:
"cluster real-functions-valuedVALUED-2V15 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be real-functions-valuedVALUED-2V15 implies it be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem valued_2_cl_77:
"cluster ext-real-functions-valuedVALUED-2V14 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be ext-real-functions-valuedVALUED-2V14 implies it be Function-yieldingFUNCOP-1V1"
sorry
qed "sorry"

mtheorem valued_2_cl_78:
  mlet "f be complex-functions-valuedVALUED-2V13\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
sorry
qed "sorry"

mtheorem valued_2_cl_79:
  mlet "f be ext-real-functions-valuedVALUED-2V14\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
sorry
qed "sorry"

mtheorem valued_2_cl_80:
  mlet "f be complex-functions-valuedVALUED-2V13\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem valued_2_cl_81:
  mlet "f be ext-real-functions-valuedVALUED-2V14\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is ext-real-valuedVALUED-0V6"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be ext-real-valuedVALUED-0V6"
sorry
qed "sorry"

mtheorem valued_2_cl_82:
  mlet "f be real-functions-valuedVALUED-2V15\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem valued_2_cl_83:
  mlet "f be rational-functions-valuedVALUED-2V16\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be RATRAT-1K1 -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem valued_2_cl_84:
  mlet "f be integer-functions-valuedVALUED-2V17\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be INTINT-1K1 -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem valued_2_cl_85:
  mlet "f be natural-functions-valuedVALUED-2V18\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem valued_2_cl_86:
  mlet "f be real-functions-valuedVALUED-2V15\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster f .BINOP-1K1(x,y) as-term-is real-valuedVALUED-0V7 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it =HIDDENR1 f .BINOP-1K1(x,y) implies it be real-valuedVALUED-0V7"
     sorry
qed "sorry"

(*begin*)
reserve Y, Y1, Y2 for "complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2"
reserve c, c1, c2 for "ComplexXCMPLX-0M1"
reserve f for "PartFuncPARTFUN1M1-of(X,Y)"
reserve f1 for "PartFuncPARTFUN1M1-of(X1,Y1)"
reserve f2 for "PartFuncPARTFUN1M1-of(X2,Y2)"
reserve g, h, k for "complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
mtheorem valued_2_th_7:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g <>HIDDENR2 {}XBOOLE-0K1 & g +VALUED-1K8 c1 =FUNCT-1R1 g +VALUED-1K8 c2 implies c1 =HIDDENR1 c2"
sorry

mtheorem valued_2_th_8:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g <>HIDDENR2 {}XBOOLE-0K1 & g -VALUED-1K14 c1 =FUNCT-1R1 g -VALUED-1K14 c2 implies c1 =HIDDENR1 c2"
sorry

mtheorem valued_2_th_9:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g <>HIDDENR2 {}XBOOLE-0K1 & g be non-emptyFUNCT-1V4) & g (#)VALUED-1K26 c1 =FUNCT-1R1 g (#)VALUED-1K26 c2 implies c1 =HIDDENR1 c2"
sorry

mtheorem valued_2_th_10:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 (g +VALUED-1K8 c) =FUNCT-1R1 (-VALUED-1K32 g)-VALUED-1K14 c"
sorry

mtheorem valued_2_th_11:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 (g -VALUED-1K14 c) =FUNCT-1R1 (-VALUED-1K32 g)+VALUED-1K8 c"
sorry

mtheorem valued_2_th_12:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g +VALUED-1K8 c1)+VALUED-1K8 c2 =FUNCT-1R1 g +VALUED-1K8 (c1 +XCMPLX-0K2 c2)"
sorry

mtheorem valued_2_th_13:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g +VALUED-1K8 c1)-VALUED-1K14 c2 =FUNCT-1R1 g +VALUED-1K8 (c1 -XCMPLX-0K6 c2)"
sorry

mtheorem valued_2_th_14:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g -VALUED-1K14 c1)+VALUED-1K8 c2 =FUNCT-1R1 g -VALUED-1K14 (c1 -XCMPLX-0K6 c2)"
sorry

mtheorem valued_2_th_15:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g -VALUED-1K14 c1)-VALUED-1K14 c2 =FUNCT-1R1 g -VALUED-1K14 (c1 +XCMPLX-0K2 c2)"
sorry

mtheorem valued_2_th_16:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g (#)VALUED-1K26 c1)(#)VALUED-1K26 c2 =FUNCT-1R1 g (#)VALUED-1K26 (c1 *XCMPLX-0K3 c2)"
sorry

mtheorem valued_2_th_17:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 (g +VALUED-1K1 h) =FUNCT-1R1 (-VALUED-1K32 g)-VALUED-1K47 h"
sorry

mtheorem valued_2_th_18:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g -VALUED-1K47 h =FUNCT-1R1 -VALUED-1K32 (h -VALUED-1K47 g)"
sorry

mtheorem valued_2_th_19:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for k be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g (#)VALUED-1K19 h)/\<inverse>VALUED-1K52 k =FUNCT-1R1 g (#)VALUED-1K19 (h /\<inverse>VALUED-1K52 k)"
sorry

mtheorem valued_2_th_20:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for k be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g /\<inverse>VALUED-1K52 h)(#)VALUED-1K19 k =FUNCT-1R1 (g (#)VALUED-1K19 k)/\<inverse>VALUED-1K52 h"
sorry

mtheorem valued_2_th_21:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for k be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g /\<inverse>VALUED-1K52 h)/\<inverse>VALUED-1K52 k =FUNCT-1R1 g /\<inverse>VALUED-1K52 (h (#)VALUED-1K19 k)"
sorry

mtheorem valued_2_th_22:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds c (#)VALUED-1K25 (-VALUED-1K32 g) =FUNCT-1R1 (-XCMPLX-0K4 c)(#)VALUED-1K25 g"
sorry

mtheorem valued_2_th_23:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds c (#)VALUED-1K25 (-VALUED-1K32 g) =FUNCT-1R1 -VALUED-1K32 c (#)VALUED-1K25 g"
sorry

mtheorem valued_2_th_24:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (-XCMPLX-0K4 c)(#)VALUED-1K25 g =FUNCT-1R1 -VALUED-1K32 c (#)VALUED-1K25 g"
sorry

mtheorem valued_2_th_25:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 g (#)VALUED-1K19 h =FUNCT-1R1 (-VALUED-1K32 g)(#)VALUED-1K19 h"
sorry

mtheorem valued_2_th_26:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 g /\<inverse>VALUED-1K52 h =FUNCT-1R1 (-VALUED-1K32 g)/\<inverse>VALUED-1K52 h"
sorry

mtheorem valued_2_th_27:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 g /\<inverse>VALUED-1K52 h =FUNCT-1R1 g /\<inverse>VALUED-1K52 (-VALUED-1K32 h)"
sorry

mdef valued_2_def_32 (" _ '('/')VALUED-2K14  _ " [164,164]164 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "c be ComplexXCMPLX-0M1"
"func f (/)VALUED-2K14 c \<rightarrow> FunctionFUNCT-1M1 equals
  (\<one>\<^sub>M /XCMPLX-0K7 c)(#)VALUED-1K25 f"
proof-
  (*coherence*)
    show "(\<one>\<^sub>M /XCMPLX-0K7 c)(#)VALUED-1K25 f be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_2_cl_87:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "c be ComplexXCMPLX-0M1"
"cluster f (/)VALUED-2K14 c as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f (/)VALUED-2K14 c be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem valued_2_cl_88:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be RealXREAL-0M1"
"cluster f (/)VALUED-2K14 r as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f (/)VALUED-2K14 r be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem valued_2_cl_89:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be RationalRAT-1M1"
"cluster f (/)VALUED-2K14 r as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f (/)VALUED-2K14 r be RATRAT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_2_cl_90:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "c be ComplexXCMPLX-0M1"
"cluster f (/)VALUED-2K14 c as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f (/)VALUED-2K14 c be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

mtheorem valued_2_th_28:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (g (/)VALUED-2K14 c) =XBOOLE-0R4 domRELAT-1K1 g"
  using valued_1_def_5 sorry

mtheorem valued_2_th_29:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds (g (/)VALUED-2K14 c).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x /XCMPLX-0K7 c"
  using valued_1_th_6 sorry

mtheorem valued_2_th_30:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (-VALUED-1K32 g)(/)VALUED-2K14 c =FUNCT-1R1 -VALUED-1K32 g (/)VALUED-2K14 c"
sorry

mtheorem valued_2_th_31:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g (/)VALUED-2K14 (-XCMPLX-0K4 c) =FUNCT-1R1 -VALUED-1K32 g (/)VALUED-2K14 c"
sorry

mtheorem valued_2_th_32:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g (/)VALUED-2K14 (-XCMPLX-0K4 c) =FUNCT-1R1 (-VALUED-1K32 g)(/)VALUED-2K14 c"
sorry

mtheorem valued_2_th_33:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g <>HIDDENR2 {}XBOOLE-0K1 & g be non-emptyFUNCT-1V4) & g (/)VALUED-2K14 c1 =FUNCT-1R1 g (/)VALUED-2K14 c2 implies c1 =HIDDENR1 c2"
sorry

mtheorem valued_2_th_34:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g (#)VALUED-1K26 c1)(/)VALUED-2K14 c2 =FUNCT-1R1 g (#)VALUED-1K26 (c1 /XCMPLX-0K7 c2)"
sorry

mtheorem valued_2_th_35:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g (/)VALUED-2K14 c1)(#)VALUED-1K26 c2 =FUNCT-1R1 (g (#)VALUED-1K26 c2)(/)VALUED-2K14 c1"
sorry

mtheorem valued_2_th_36:
" for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g (/)VALUED-2K14 c1)(/)VALUED-2K14 c2 =FUNCT-1R1 g (/)VALUED-2K14 (c1 *XCMPLX-0K3 c2)"
sorry

mtheorem valued_2_th_37:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g +VALUED-1K1 h)(/)VALUED-2K14 c =FUNCT-1R1 g (/)VALUED-2K14 c +VALUED-1K1 h (/)VALUED-2K14 c"
sorry

mtheorem valued_2_th_38:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g -VALUED-1K47 h)(/)VALUED-2K14 c =FUNCT-1R1 g (/)VALUED-2K14 c -VALUED-1K47 h (/)VALUED-2K14 c"
sorry

mtheorem valued_2_th_39:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g (#)VALUED-1K19 h)(/)VALUED-2K14 c =FUNCT-1R1 g (#)VALUED-1K19 (h (/)VALUED-2K14 c)"
sorry

mtheorem valued_2_th_40:
" for c be ComplexXCMPLX-0M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (g /\<inverse>VALUED-1K52 h)(/)VALUED-2K14 c =FUNCT-1R1 g /\<inverse>VALUED-1K52 (h (#)VALUED-1K26 c)"
sorry

mdef valued_2_def_33 ("<->VALUED-2K15  _ " [164]164 ) where
  mlet "f be complex-functions-valuedVALUED-2V13\<bar>FunctionFUNCT-1M1"
"func <->VALUED-2K15 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 -VALUED-1K32 f .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 -VALUED-1K32 f .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 -VALUED-1K32 f .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 -VALUED-1K32 f .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K16 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<->VALUED-2K16\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,164]164)
translations "<->VALUED-2K16\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "<->VALUED-2K15 f"

mtheorem valued_2_add_1:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster <->VALUED-2K15 f as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "<->VALUED-2K15 f be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<->VALUED-2K17\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,164]164)
translations "<->VALUED-2K17\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "<->VALUED-2K15 f"

mtheorem valued_2_add_2:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster <->VALUED-2K15 f as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "<->VALUED-2K15 f be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K18 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<->VALUED-2K18\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,164]164)
translations "<->VALUED-2K18\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "<->VALUED-2K15 f"

mtheorem valued_2_add_3:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster <->VALUED-2K15 f as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "<->VALUED-2K15 f be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K19 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<->VALUED-2K19\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,164]164)
translations "<->VALUED-2K19\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "<->VALUED-2K15 f"

mtheorem valued_2_add_4:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster <->VALUED-2K15 f as-term-is PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "<->VALUED-2K15 f be PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_cl_91:
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of Y"
"cluster <->VALUED-2K16\<^bsub>(NATNUMBERSK1,Y)\<^esub> f as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "<->VALUED-2K16\<^bsub>(NATNUMBERSK1,Y)\<^esub> f be FinSequence-likeFINSEQ-1V1"
sorry
qed "sorry"

mtheorem valued_2_th_41:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds <->VALUED-2K16\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> (<->VALUED-2K16\<^bsub>(X,Y)\<^esub> f) =FUNCT-1R1 f"
sorry

mtheorem valued_2_th_42:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds <->VALUED-2K16\<^bsub>(X1,Y1)\<^esub> f1 =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X2,Y2)\<^esub> f2 implies f1 =FUNCT-1R1 f2"
sorry

mdef valued_2_def_34 (" _ '(-')VALUED-2K20\<^bsub>'( _ , _ ')\<^esub>" [132,0,0]132 ) where
  mlet "X be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"func f (-)VALUED-2K20\<^bsub>(X,Y)\<^esub> \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f & ( for x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds x inTARSKIR2 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (-VALUED-1K32 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f & ( for x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds x inTARSKIR2 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (-VALUED-1K32 x))"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f & ( for x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds x inTARSKIR2 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (-VALUED-1K32 x))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f & ( for x be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds x inTARSKIR2 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (-VALUED-1K32 x))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef valued_2_def_35 ("<'/>VALUED-2K21  _ " [228]228 ) where
  mlet "f be complex-functions-valuedVALUED-2V13\<bar>FunctionFUNCT-1M1"
"func </>VALUED-2K21 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 (f .FUNCT-1K1 x)\<inverse>VALUED-1K37)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 (f .FUNCT-1K1 x)\<inverse>VALUED-1K37)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 (f .FUNCT-1K1 x)\<inverse>VALUED-1K37)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 (f .FUNCT-1K1 x)\<inverse>VALUED-1K37)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K22 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<'/>VALUED-2K22\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228)
translations "</>VALUED-2K22\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "</>VALUED-2K21 f"

mtheorem valued_2_add_5:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster </>VALUED-2K21 f as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "</>VALUED-2K21 f be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K23 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<'/>VALUED-2K23\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228)
translations "</>VALUED-2K23\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "</>VALUED-2K21 f"

mtheorem valued_2_add_6:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster </>VALUED-2K21 f as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "</>VALUED-2K21 f be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K24 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<'/>VALUED-2K24\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228)
translations "</>VALUED-2K24\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "</>VALUED-2K21 f"

mtheorem valued_2_add_7:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster </>VALUED-2K21 f as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "</>VALUED-2K21 f be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_cl_92:
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of Y"
"cluster </>VALUED-2K22\<^bsub>(NATNUMBERSK1,Y)\<^esub> f as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "</>VALUED-2K22\<^bsub>(NATNUMBERSK1,Y)\<^esub> f be FinSequence-likeFINSEQ-1V1"
sorry
qed "sorry"

mtheorem valued_2_th_43:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds </>VALUED-2K22\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> (</>VALUED-2K22\<^bsub>(X,Y)\<^esub> f) =FUNCT-1R1 f"
sorry

mdef valued_2_def_36 ("absVALUED-2K25  _ " [250]250 ) where
  mlet "f be complex-functions-valuedVALUED-2V13\<bar>FunctionFUNCT-1M1"
"func absVALUED-2K25 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 absVALUED-1K57 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 absVALUED-1K57 (f .FUNCT-1K1 x))"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 absVALUED-1K57 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 absVALUED-1K57 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K26 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-2K26\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-2K26\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "absVALUED-2K25 f"

mtheorem valued_2_add_8:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster absVALUED-2K25 f as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "absVALUED-2K25 f be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K27 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-2K27\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-2K27\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "absVALUED-2K25 f"

mtheorem valued_2_add_9:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster absVALUED-2K25 f as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "absVALUED-2K25 f be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K28 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-2K28\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-2K28\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "absVALUED-2K25 f"

mtheorem valued_2_add_10:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster absVALUED-2K25 f as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "absVALUED-2K25 f be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K29 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-2K29\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-2K29\<^bsub>(X,Y)\<^esub> f" \<rightharpoonup> "absVALUED-2K25 f"

mtheorem valued_2_add_11:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster absVALUED-2K25 f as-term-is PartFuncPARTFUN1M1-of(X,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "absVALUED-2K25 f be PartFuncPARTFUN1M1-of(X,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_cl_93:
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of Y"
"cluster absVALUED-2K26\<^bsub>(NATNUMBERSK1,Y)\<^esub> f as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "absVALUED-2K26\<^bsub>(NATNUMBERSK1,Y)\<^esub> f be FinSequence-likeFINSEQ-1V1"
sorry
qed "sorry"

mtheorem valued_2_th_44:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds absVALUED-2K26\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> (absVALUED-2K26\<^bsub>(X,Y)\<^esub> f) =FUNCT-1R1 absVALUED-2K26\<^bsub>(X,Y)\<^esub> f"
sorry

mdef valued_2_def_37 (" _ [+]VALUED-2K30\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "c be ComplexXCMPLX-0M1"
"func f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 c +VALUED-1K7 f .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 c +VALUED-1K7 f .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 c +VALUED-1K7 f .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 c +VALUED-1K7 f .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K31 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [+]VALUED-2K31\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_12:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be ComplexXCMPLX-0M1"
"cluster f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K32 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [+]VALUED-2K32\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [+]VALUED-2K32\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_13:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RealXREAL-0M1"
"cluster f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K33 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [+]VALUED-2K33\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [+]VALUED-2K33\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_14:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RationalRAT-1M1"
"cluster f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K34 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [+]VALUED-2K34\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [+]VALUED-2K34\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_15:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be IntegerINT-1M1"
"cluster f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K35 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [+]VALUED-2K35\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [+]VALUED-2K35\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_16:
  mlet "X be setHIDDENM2", "Y be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be NatNAT-1M1"
"cluster f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_45:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> c1)[+]VALUED-2K31\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> c2 =FUNCT-1R1 f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> (c1 +XCMPLX-0K2 c2)"
sorry

mtheorem valued_2_th_46:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f <>HIDDENR2 {}XBOOLE-0K1 & f be non-emptyFUNCT-1V4) & f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> c1 =RELSET-1R2\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> c2 implies c1 =HIDDENR1 c2"
sorry

mdef valued_2_def_38 (" _ [-]VALUED-2K36\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "c be ComplexXCMPLX-0M1"
"func f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c \<rightarrow> FunctionFUNCT-1M1 equals
  f [+]VALUED-2K30\<^bsub>(Y)\<^esub> (-XCMPLX-0K4 c)"
proof-
  (*coherence*)
    show "f [+]VALUED-2K30\<^bsub>(Y)\<^esub> (-XCMPLX-0K4 c) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_2_th_47:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds domRELAT-1K1 (f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
  using valued_2_def_37 sorry

mtheorem valued_2_th_48:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds x inHIDDENR3 domRELAT-1K1 (f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c) implies (f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x -VALUED-1K14 c"
  using valued_2_def_37 sorry

syntax VALUED_2K37 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [-]VALUED-2K37\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_17:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be ComplexXCMPLX-0M1"
"cluster f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K38 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [-]VALUED-2K38\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [-]VALUED-2K38\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_18:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RealXREAL-0M1"
"cluster f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K39 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [-]VALUED-2K39\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [-]VALUED-2K39\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_19:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RationalRAT-1M1"
"cluster f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K40 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [-]VALUED-2K40\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f [-]VALUED-2K40\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_20:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be IntegerINT-1M1"
"cluster f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [-]VALUED-2K36\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_49:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f <>HIDDENR2 {}XBOOLE-0K1 & f be non-emptyFUNCT-1V4) & f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> c1 =RELSET-1R2\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> c2 implies c1 =HIDDENR1 c2"
sorry

mtheorem valued_2_th_50:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> c1)[-]VALUED-2K37\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> c2 =FUNCT-1R1 f [+]VALUED-2K31\<^bsub>(X,Y)\<^esub> (c1 -XCMPLX-0K6 c2)"
sorry

mtheorem valued_2_th_51:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> c1)[+]VALUED-2K31\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> c2 =FUNCT-1R1 f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> (c1 -XCMPLX-0K6 c2)"
sorry

mtheorem valued_2_th_52:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> c1)[-]VALUED-2K37\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> c2 =FUNCT-1R1 f [-]VALUED-2K37\<^bsub>(X,Y)\<^esub> (c1 +XCMPLX-0K2 c2)"
sorry

mdef valued_2_def_39 (" _ [#]VALUED-2K41\<^bsub>'( _ ')\<^esub>  _ " [228,0,228]228 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "c be ComplexXCMPLX-0M1"
"func f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 c (#)VALUED-1K25 f .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 c (#)VALUED-1K25 f .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 c (#)VALUED-1K25 f .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 c (#)VALUED-1K25 f .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K42 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [#]VALUED-2K42\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [#]VALUED-2K42\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_21:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be ComplexXCMPLX-0M1"
"cluster f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K43 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [#]VALUED-2K43\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [#]VALUED-2K43\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_22:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RealXREAL-0M1"
"cluster f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K44 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [#]VALUED-2K44\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [#]VALUED-2K44\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_23:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RationalRAT-1M1"
"cluster f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K45 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [#]VALUED-2K45\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [#]VALUED-2K45\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_24:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be IntegerINT-1M1"
"cluster f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K46 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [#]VALUED-2K46\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [#]VALUED-2K46\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_25:
  mlet "X be setHIDDENM2", "Y be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be NatNAT-1M1"
"cluster f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_53:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f [#]VALUED-2K42\<^bsub>(X,Y)\<^esub> c1)[#]VALUED-2K42\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> c2 =FUNCT-1R1 f [#]VALUED-2K42\<^bsub>(X,Y)\<^esub> (c1 *XCMPLX-0K3 c2)"
sorry

mtheorem valued_2_th_54:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds ((f <>HIDDENR2 {}XBOOLE-0K1 & f be non-emptyFUNCT-1V4) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x be non-emptyFUNCT-1V4)) & f [#]VALUED-2K42\<^bsub>(X,Y)\<^esub> c1 =RELSET-1R2\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> f [#]VALUED-2K42\<^bsub>(X,Y)\<^esub> c2 implies c1 =HIDDENR1 c2"
sorry

mdef valued_2_def_40 (" _ ['/]VALUED-2K47\<^bsub>'( _ ')\<^esub>  _ " [228,0,228]228 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "c be ComplexXCMPLX-0M1"
"func f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c \<rightarrow> FunctionFUNCT-1M1 equals
  f [#]VALUED-2K41\<^bsub>(Y)\<^esub> (c \<inverse>XCMPLX-0K5)"
proof-
  (*coherence*)
    show "f [#]VALUED-2K41\<^bsub>(Y)\<^esub> (c \<inverse>XCMPLX-0K5) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_2_th_55:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds domRELAT-1K1 (f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
  using valued_2_def_39 sorry

mtheorem valued_2_th_56:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds x inHIDDENR3 domRELAT-1K1 (f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c) implies f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c .FUNCT-1K1 x =XBOOLE-0R4 c \<inverse>XCMPLX-0K5 (#)VALUED-1K25 f .FUNCT-1K1 x"
  using valued_2_def_39 sorry

syntax VALUED_2K48 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ['/]VALUED-2K48\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [/]VALUED-2K48\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_26:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be ComplexXCMPLX-0M1"
"cluster f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K49 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ['/]VALUED-2K49\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [/]VALUED-2K49\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_27:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RealXREAL-0M1"
"cluster f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K50 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ['/]VALUED-2K50\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f [/]VALUED-2K50\<^bsub>(X,Y)\<^esub> c" \<rightharpoonup> "f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c"

mtheorem valued_2_add_28:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "c be RationalRAT-1M1"
"cluster f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c as-term-is PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f [/]VALUED-2K47\<^bsub>(Y)\<^esub> c be PartFuncPARTFUN1M1-of(X,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_57:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f [/]VALUED-2K48\<^bsub>(X,Y)\<^esub> c1)[/]VALUED-2K48\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> c2 =FUNCT-1R1 f [/]VALUED-2K48\<^bsub>(X,Y)\<^esub> (c1 *XCMPLX-0K3 c2)"
sorry

mtheorem valued_2_th_58:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds ((f <>HIDDENR2 {}XBOOLE-0K1 & f be non-emptyFUNCT-1V4) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x be non-emptyFUNCT-1V4)) & f [/]VALUED-2K48\<^bsub>(X,Y)\<^esub> c1 =RELSET-1R2\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> f [/]VALUED-2K48\<^bsub>(X,Y)\<^esub> c2 implies c1 =HIDDENR1 c2"
sorry

mdef valued_2_def_41 (" _ <+>VALUED-2K51\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K8 g .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K8 g .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K8 g .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K8 g .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K52 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <+>VALUED-2K52\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_29:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K53 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <+>VALUED-2K53\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <+>VALUED-2K53\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_30:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K54 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <+>VALUED-2K54\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <+>VALUED-2K54\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_31:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K55 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <+>VALUED-2K55\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <+>VALUED-2K55\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_32:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K56 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <+>VALUED-2K56\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <+>VALUED-2K56\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_33:
  mlet "X be setHIDDENM2", "Y be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1"
"cluster f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_59:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> g)<+>VALUED-2K52\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> h =FUNCT-1R1 f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> (g +VALUED-1K1 h)"
sorry

mtheorem valued_2_th_60:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds <->VALUED-2K16\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> (f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> g) =FUNCT-1R1 (<->VALUED-2K16\<^bsub>(X,Y)\<^esub> f)<+>VALUED-2K52\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> (-VALUED-1K32 g)"
sorry

mdef valued_2_def_42 (" _ <->VALUED-2K57\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f <->VALUED-2K57\<^bsub>(Y)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 equals
  f <+>VALUED-2K51\<^bsub>(Y)\<^esub> (-VALUED-1K32 g)"
proof-
  (*coherence*)
    show "f <+>VALUED-2K51\<^bsub>(Y)\<^esub> (-VALUED-1K32 g) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_2_th_61:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f <->VALUED-2K57\<^bsub>(Y)\<^esub> g) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 g"
sorry

mtheorem valued_2_th_62:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f <->VALUED-2K57\<^bsub>(Y)\<^esub> g) implies (f <->VALUED-2K57\<^bsub>(Y)\<^esub> g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x -VALUED-1K14 g .FUNCT-1K1 x"
sorry

syntax VALUED_2K58 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <->VALUED-2K58\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_34:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f <->VALUED-2K57\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K59 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <->VALUED-2K59\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <->VALUED-2K59\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_35:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f <->VALUED-2K57\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K60 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <->VALUED-2K60\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <->VALUED-2K60\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_36:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f <->VALUED-2K57\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K61 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <->VALUED-2K61\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f <->VALUED-2K61\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_37:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f <->VALUED-2K57\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <->VALUED-2K57\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_63:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> (-VALUED-1K32 g) =FUNCT-1R1 f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> g"
   sorry

mtheorem valued_2_th_64:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds <->VALUED-2K16\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> (f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> g) =RELSET-1R2\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 (C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))))\<^esub> (<->VALUED-2K16\<^bsub>(X,Y)\<^esub> f)<+>VALUED-2K52\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> g"
sorry

mtheorem valued_2_th_65:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> g)<->VALUED-2K58\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> h =FUNCT-1R1 f <+>VALUED-2K52\<^bsub>(X,Y)\<^esub> (g -VALUED-1K47 h)"
sorry

mtheorem valued_2_th_66:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> g)<+>VALUED-2K52\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> h =FUNCT-1R1 f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> (g -VALUED-1K47 h)"
sorry

mtheorem valued_2_th_67:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> g)<->VALUED-2K58\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> h =FUNCT-1R1 f <->VALUED-2K58\<^bsub>(X,Y)\<^esub> (g +VALUED-1K1 h)"
sorry

mdef valued_2_def_43 (" _ <#>VALUED-2K62\<^bsub>'( _ ')\<^esub>  _ " [228,0,228]228 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K26 g .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K26 g .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K26 g .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K26 g .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K63 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <#>VALUED-2K63\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_38:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K64 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <#>VALUED-2K64\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f <#>VALUED-2K64\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_39:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K65 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <#>VALUED-2K65\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f <#>VALUED-2K65\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_40:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K66 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <#>VALUED-2K66\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f <#>VALUED-2K66\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_41:
  mlet "X be setHIDDENM2", "Y be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,I-PFuncsVALUED-2K10 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K67 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <#>VALUED-2K67\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f <#>VALUED-2K67\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_42:
  mlet "X be setHIDDENM2", "Y be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1"
"cluster f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,N-PFuncsVALUED-2K12 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_68:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> (-VALUED-1K32 g) =FUNCT-1R1 (<->VALUED-2K16\<^bsub>(X,Y)\<^esub> f)<#>VALUED-2K63\<^bsub>(X,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> g"
sorry

mtheorem valued_2_th_69:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> (-VALUED-1K32 g) =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> g"
sorry

mtheorem valued_2_th_70:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> g)<#>VALUED-2K63\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> h =FUNCT-1R1 f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> (g (#)VALUED-1K19 h)"
sorry

mdef valued_2_def_44 (" _ <'/>VALUED-2K68\<^bsub>'( _ ')\<^esub>  _ " [228,0,228]228 ) where
  mlet "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f </>VALUED-2K68\<^bsub>(Y)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 equals
  f <#>VALUED-2K62\<^bsub>(Y)\<^esub> (g \<inverse>VALUED-1K37)"
proof-
  (*coherence*)
    show "f <#>VALUED-2K62\<^bsub>(Y)\<^esub> (g \<inverse>VALUED-1K37) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_2_th_71:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f </>VALUED-2K68\<^bsub>(Y)\<^esub> g) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 g"
sorry

mtheorem valued_2_th_72:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f </>VALUED-2K68\<^bsub>(Y)\<^esub> g) implies f </>VALUED-2K68\<^bsub>(Y)\<^esub> g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (/)VALUED-2K14 g .FUNCT-1K1 x"
sorry

syntax VALUED_2K69 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <'/>VALUED-2K69\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f </>VALUED-2K69\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f </>VALUED-2K68\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_43:
  mlet "X be setHIDDENM2", "Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f </>VALUED-2K68\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f </>VALUED-2K68\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K70 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <'/>VALUED-2K70\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f </>VALUED-2K70\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f </>VALUED-2K68\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_44:
  mlet "X be setHIDDENM2", "Y be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f </>VALUED-2K68\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f </>VALUED-2K68\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,R-PFuncsVALUED-2K6 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

syntax VALUED_2K71 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <'/>VALUED-2K71\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "f </>VALUED-2K71\<^bsub>(X,Y)\<^esub> g" \<rightharpoonup> "f </>VALUED-2K68\<^bsub>(Y)\<^esub> g"

mtheorem valued_2_add_45:
  mlet "X be setHIDDENM2", "Y be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f </>VALUED-2K68\<^bsub>(Y)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
proof
(*coherence*)
  show "f </>VALUED-2K68\<^bsub>(Y)\<^esub> g be PartFuncPARTFUN1M1-of(X /\\XBOOLE-0K3 domRELAT-1K1 g,Q-PFuncsVALUED-2K8 (DOMSVALUED-2K1 Y))"
sorry
qed "sorry"

mtheorem valued_2_th_73:
" for X be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> g)</>VALUED-2K69\<^bsub>(X /\\XBOOLE-0K3 domRELAT-1K1 g,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y))\<^esub> h =FUNCT-1R1 f <#>VALUED-2K63\<^bsub>(X,Y)\<^esub> (g /\<inverse>VALUED-1K52 h)"
sorry

mdef valued_2_def_45 (" _ <++>VALUED-2K72\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164 ) where
  mlet "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be Y2 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"func f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K1 g .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K1 g .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K1 g .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x +VALUED-1K1 g .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K73 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <++>VALUED-2K73\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_46:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K74 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <++>VALUED-2K74\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <++>VALUED-2K74\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_47:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "Y2 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K75 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <++>VALUED-2K75\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <++>VALUED-2K75\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_48:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "Y2 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K76 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <++>VALUED-2K76\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <++>VALUED-2K76\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_49:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "Y2 be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,I-PFuncsVALUED-2K10 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,I-PFuncsVALUED-2K10 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K77 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <++>VALUED-2K77\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <++>VALUED-2K77\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_50:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "Y2 be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,N-PFuncsVALUED-2K12 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <++>VALUED-2K72\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,N-PFuncsVALUED-2K12 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

mtheorem valued_2_th_74:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2 =FUNCT-1R1 f2 <++>VALUED-2K73\<^bsub>(X2,X1,Y2,Y1)\<^esub> f1"
sorry

mtheorem valued_2_th_75:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <++>VALUED-2K73\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<++>VALUED-2K73\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <++>VALUED-2K73\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_76:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds <->VALUED-2K16\<^bsub>(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2) =FUNCT-1R1 (<->VALUED-2K16\<^bsub>(X1,Y1)\<^esub> f1)<++>VALUED-2K73\<^bsub>(X1,X2,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y1),C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y2))\<^esub> (<->VALUED-2K16\<^bsub>(X2,Y2)\<^esub> f2)"
sorry

mdef valued_2_def_46 (" _ <-->VALUED-2K78\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164 ) where
  mlet "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be Y2 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"func f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x -VALUED-1K47 g .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x -VALUED-1K47 g .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x -VALUED-1K47 g .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x -VALUED-1K47 g .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K79 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <-->VALUED-2K79\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_51:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K80 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <-->VALUED-2K80\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <-->VALUED-2K80\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_52:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "Y2 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K81 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <-->VALUED-2K81\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <-->VALUED-2K81\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_53:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "Y2 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K82 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <-->VALUED-2K82\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "f <-->VALUED-2K82\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_54:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "Y2 be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,I-PFuncsVALUED-2K10 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <-->VALUED-2K78\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,I-PFuncsVALUED-2K10 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

mtheorem valued_2_th_77:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2 =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X2 /\\XBOOLE-0K3 X1,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y2)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)))\<^esub> (f2 <-->VALUED-2K79\<^bsub>(X2,X1,Y2,Y1)\<^esub> f1)"
sorry

mtheorem valued_2_th_78:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds <->VALUED-2K16\<^bsub>(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2) =FUNCT-1R1 (<->VALUED-2K16\<^bsub>(X1,Y1)\<^esub> f1)<++>VALUED-2K73\<^bsub>(X1,X2,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y1),Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_79:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <++>VALUED-2K73\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<-->VALUED-2K79\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <++>VALUED-2K73\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_80:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <-->VALUED-2K79\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<++>VALUED-2K73\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <-->VALUED-2K79\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_81:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <-->VALUED-2K79\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<-->VALUED-2K79\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <-->VALUED-2K79\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_82:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <-->VALUED-2K79\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<-->VALUED-2K79\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 (f <-->VALUED-2K79\<^bsub>(X,X2,Y,Y2)\<^esub> f2)<-->VALUED-2K79\<^bsub>(X /\\XBOOLE-0K3 X2,X1,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)),Y1)\<^esub> f1"
sorry

mdef valued_2_def_47 (" _ <##>VALUED-2K83\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228 ) where
  mlet "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be Y2 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"func f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K19 g .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K19 g .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K19 g .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x (#)VALUED-1K19 g .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K84 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <##>VALUED-2K84\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <##>VALUED-2K84\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_55:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K85 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <##>VALUED-2K85\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <##>VALUED-2K85\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_56:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "Y2 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K86 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <##>VALUED-2K86\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <##>VALUED-2K86\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_57:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "Y2 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K87 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <##>VALUED-2K87\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <##>VALUED-2K87\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_58:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "Y2 be integer-functions-memberedVALUED-2V5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,I-PFuncsVALUED-2K10 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,I-PFuncsVALUED-2K10 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K88 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <##>VALUED-2K88\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <##>VALUED-2K88\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_59:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "Y2 be natural-functions-memberedVALUED-2V6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,N-PFuncsVALUED-2K12 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <##>VALUED-2K83\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,N-PFuncsVALUED-2K12 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

mtheorem valued_2_th_83:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f1 <##>VALUED-2K84\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2 =FUNCT-1R1 f2 <##>VALUED-2K84\<^bsub>(X2,X1,Y2,Y1)\<^esub> f1"
sorry

mtheorem valued_2_th_84:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <##>VALUED-2K84\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<##>VALUED-2K84\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <##>VALUED-2K84\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <##>VALUED-2K84\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_85:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (<->VALUED-2K16\<^bsub>(X1,Y1)\<^esub> f1)<##>VALUED-2K84\<^bsub>(X1,X2,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y1),Y2)\<^esub> f2 =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> f1 <##>VALUED-2K84\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_86:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f1 <##>VALUED-2K84\<^bsub>(X1,X2,Y1,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y2))\<^esub> (<->VALUED-2K16\<^bsub>(X2,Y2)\<^esub> f2) =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> f1 <##>VALUED-2K84\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_87:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f <##>VALUED-2K84\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2) =FUNCT-1R1 f <##>VALUED-2K84\<^bsub>(X,X1,Y,Y1)\<^esub> f1 <++>VALUED-2K73\<^bsub>(X /\\XBOOLE-0K3 X1,X /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> f <##>VALUED-2K84\<^bsub>(X,X2,Y,Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_88:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)<##>VALUED-2K84\<^bsub>(X1 /\\XBOOLE-0K3 X2,X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)),Y)\<^esub> f =FUNCT-1R1 f1 <##>VALUED-2K84\<^bsub>(X1,X,Y1,Y)\<^esub> f <++>VALUED-2K73\<^bsub>(X1 /\\XBOOLE-0K3 X,X2 /\\XBOOLE-0K3 X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)),C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y2)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)))\<^esub> f2 <##>VALUED-2K84\<^bsub>(X2,X,Y2,Y)\<^esub> f"
sorry

mtheorem valued_2_th_89:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f <##>VALUED-2K84\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2) =FUNCT-1R1 f <##>VALUED-2K84\<^bsub>(X,X1,Y,Y1)\<^esub> f1 <-->VALUED-2K79\<^bsub>(X /\\XBOOLE-0K3 X1,X /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> f <##>VALUED-2K84\<^bsub>(X,X2,Y,Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_90:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)<##>VALUED-2K84\<^bsub>(X1 /\\XBOOLE-0K3 X2,X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)),Y)\<^esub> f =FUNCT-1R1 f1 <##>VALUED-2K84\<^bsub>(X1,X,Y1,Y)\<^esub> f <-->VALUED-2K79\<^bsub>(X1 /\\XBOOLE-0K3 X,X2 /\\XBOOLE-0K3 X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)),C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y2)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)))\<^esub> f2 <##>VALUED-2K84\<^bsub>(X2,X,Y2,Y)\<^esub> f"
sorry

mdef valued_2_def_48 (" _ <'/'/>VALUED-2K89\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228 ) where
  mlet "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be Y1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "g be Y2 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"func f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x /\<inverse>VALUED-1K52 g .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x /\<inverse>VALUED-1K52 g .FUNCT-1K1 x)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x /\<inverse>VALUED-1K52 g .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x /\<inverse>VALUED-1K52 g .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax VALUED_2K90 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <'/'/>VALUED-2K90\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <//>VALUED-2K90\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_60:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K91 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <'/'/>VALUED-2K91\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <//>VALUED-2K91\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_61:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "Y2 be real-functions-memberedVALUED-2V3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,R-PFuncsVALUED-2K6 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

syntax VALUED_2K92 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ <'/'/>VALUED-2K92\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [228,0,0,0,0,228]228)
translations "f <//>VALUED-2K92\<^bsub>(X1,X2,Y1,Y2)\<^esub> g" \<rightharpoonup> "f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g"

mtheorem valued_2_add_62:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "Y1 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "Y2 be rational-functions-memberedVALUED-2V4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X1,Y1)", "g be PartFuncPARTFUN1M1-of(X2,Y2)"
"cluster f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g as-term-is PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
proof
(*coherence*)
  show "f <//>VALUED-2K89\<^bsub>(Y1,Y2)\<^esub> g be PartFuncPARTFUN1M1-of(X1 /\\XBOOLE-0K3 X2,Q-PFuncsVALUED-2K8 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))"
sorry
qed "sorry"

mtheorem valued_2_th_91:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (<->VALUED-2K16\<^bsub>(X1,Y1)\<^esub> f1)<//>VALUED-2K90\<^bsub>(X1,X2,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y1),Y2)\<^esub> f2 =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> f1 <//>VALUED-2K90\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_92:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds f1 <//>VALUED-2K90\<^bsub>(X1,X2,Y1,C-PFuncsVALUED-2K2 (DOMSVALUED-2K1 Y2))\<^esub> (<->VALUED-2K16\<^bsub>(X2,Y2)\<^esub> f2) =FUNCT-1R1 <->VALUED-2K16\<^bsub>(X1 /\\XBOOLE-0K3 X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> f1 <//>VALUED-2K90\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2"
sorry

mtheorem valued_2_th_93:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <##>VALUED-2K84\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<//>VALUED-2K90\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <##>VALUED-2K84\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <//>VALUED-2K90\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_94:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <//>VALUED-2K90\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<##>VALUED-2K84\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 (f <##>VALUED-2K84\<^bsub>(X,X2,Y,Y2)\<^esub> f2)<//>VALUED-2K90\<^bsub>(X /\\XBOOLE-0K3 X2,X1,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)),Y1)\<^esub> f1"
sorry

mtheorem valued_2_th_95:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f <//>VALUED-2K90\<^bsub>(X,X1,Y,Y1)\<^esub> f1)<//>VALUED-2K90\<^bsub>(X /\\XBOOLE-0K3 X1,X2,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y1)),Y2)\<^esub> f2 =FUNCT-1R1 f <//>VALUED-2K90\<^bsub>(X,X1 /\\XBOOLE-0K3 X2,Y,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)))\<^esub> (f1 <##>VALUED-2K84\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)"
sorry

mtheorem valued_2_th_96:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f1 <++>VALUED-2K73\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)<//>VALUED-2K90\<^bsub>(X1 /\\XBOOLE-0K3 X2,X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)),Y)\<^esub> f =FUNCT-1R1 f1 <//>VALUED-2K90\<^bsub>(X1,X,Y1,Y)\<^esub> f <++>VALUED-2K73\<^bsub>(X1 /\\XBOOLE-0K3 X,X2 /\\XBOOLE-0K3 X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)),C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y2)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)))\<^esub> f2 <//>VALUED-2K90\<^bsub>(X2,X,Y2,Y)\<^esub> f"
sorry

mtheorem valued_2_th_97:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y1 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for Y2 be complex-functions-memberedVALUED-2V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for f1 be PartFuncPARTFUN1M1-of(X1,Y1) holds  for f2 be PartFuncPARTFUN1M1-of(X2,Y2) holds (f1 <-->VALUED-2K79\<^bsub>(X1,X2,Y1,Y2)\<^esub> f2)<//>VALUED-2K90\<^bsub>(X1 /\\XBOOLE-0K3 X2,X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y2)),Y)\<^esub> f =FUNCT-1R1 f1 <//>VALUED-2K90\<^bsub>(X1,X,Y1,Y)\<^esub> f <-->VALUED-2K79\<^bsub>(X1 /\\XBOOLE-0K3 X,X2 /\\XBOOLE-0K3 X,C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y1)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)),C-PFuncsVALUED-2K2 ((DOMSVALUED-2K1 Y2)/\\XBOOLE-0K3 (DOMSVALUED-2K1 Y)))\<^esub> f2 <//>VALUED-2K90\<^bsub>(X2,X,Y2,Y)\<^esub> f"
sorry

end
