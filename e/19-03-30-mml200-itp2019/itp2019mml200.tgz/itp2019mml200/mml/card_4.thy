theory card_4
  imports domain_1 newton card_3 orders_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X, Y, Z, x, y, y1, y2 for "setHIDDENM2"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve k, n, n1, n2, m2, m1 for "NatNAT-1M1"
reserve L, K, M, N for "CardinalCARD-1M1"
reserve f, g for "FunctionFUNCT-1M1"
mtheorem card_4_th_1:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies X be countableCARD-3V4"
   sorry

mtheorem card_4_th_2:
"omegaORDINAL1K4 be countableCARD-3V4"
   sorry

reserve r for "RealXREAL-0M1"
mtheorem card_4_th_3:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 or n =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
sorry

mlemma card_4_lm_1:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 <=XXREAL-0R1 n2"
sorry

mtheorem card_4_th_4:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 =XBOOLE-0R4 n2 & m1 =XBOOLE-0R4 m2"
sorry

mlemma card_4_lm_2:
" for x be setHIDDENM2 holds x inTARSKIR2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] implies ( ex n1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex n2 be ElementSUBSET-1M1-of NATNUMBERSK1 st x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2 ])"
sorry

mtheorem card_4_th_5:
"([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1)are-equipotentWELLORD2R2 & cardCARD-1K1 NATNUMBERSK1 =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
sorry

mtheorem card_4_th_6:
"omegaORDINAL1K4 *`CARD-2K2 omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4"
  using card_4_th_5 card_2_def_2 sorry

mtheorem card_4_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 & Y be countableCARD-3V4 implies [:ZFMISC-1K2 X,Y :] be countableCARD-3V4"
sorry

mtheorem card_4_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
sorry

reserve p, q for "FinSequenceFINSEQ-1M1"
reserve k, m, n, n1, n2, n3 for "NatNAT-1M1"
mtheorem card_4_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :],(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :]) =XBOOLE-0R4 cardCARD-1K1 ((n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)"
sorry

mtheorem card_4_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds D be countableCARD-3V4 implies n -tuples-onFINSEQ-2K4 D be countableCARD-3V4"
sorry

mtheorem card_4_th_11:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be countableCARD-3V4 & ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 x be countableCARD-3V4) implies UnionCARD-3K3 f be countableCARD-3V4"
sorry

mtheorem card_4_th_12:
" for X be setHIDDENM2 holds X be countableCARD-3V4 & ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y be countableCARD-3V4) implies unionTARSKIK3 X be countableCARD-3V4"
sorry

mtheorem card_4_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds D be countableCARD-3V4 implies D * FINSEQ-2K3 be countableCARD-3V4"
sorry

mtheorem card_4_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 (D * FINSEQ-2K3)"
sorry

theorem card_4_sch_1:
  fixes ff1 Pp1 
  assumes
[ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> ff1(x1) be setHIDDENM2"
  shows "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } be countableCARD-3V4"
sorry

theorem card_4_sch_2:
  fixes ff2 Pp2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> ff2(x1,x2) be setHIDDENM2"
  shows "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } be countableCARD-3V4"
sorry

theorem card_4_sch_3:
  fixes ff3 Pp3 
  assumes
[ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> ff3(x1,x2,x3) be setHIDDENM2"
  shows "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } be countableCARD-3V4"
sorry

reserve f, f1, f2 for "FunctionFUNCT-1M1"
reserve X1, X2 for "setHIDDENM2"
(*\$N Hessenberg's theorem*)
mtheorem card_4_th_15:
" for M be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies M *`CARD-2K2 M =XBOOLE-0R4 M"
sorry

mtheorem card_4_th_16:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ( not M be finiteFINSET-1V1 & 0NUMBERSK6 inTARSKIR2 N) & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M *`CARD-2K2 N =XBOOLE-0R4 M & N *`CARD-2K2 M =XBOOLE-0R4 M"
sorry

mtheorem card_4_th_17:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M *`CARD-2K2 N c=ORDINAL1R1 M & N *`CARD-2K2 M c=ORDINAL1R1 M"
sorry

mtheorem card_4_th_18:
" for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 implies ([:ZFMISC-1K2 X,X :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,X :]) =XBOOLE-0R4 cardCARD-1K1 X"
sorry

mtheorem card_4_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( not X be finiteFINSET-1V1 & Y be finiteFINSET-1V1) & Y <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K2 X,Y :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 X"
sorry

mtheorem card_4_th_20:
" for L be CardinalCARD-1M1 holds  for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K inTARSKIR2 L & M inTARSKIR2 N implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N & M *`CARD-2K2 K inTARSKIR2 L *`CARD-2K2 N"
sorry

mtheorem card_4_th_21:
" for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 implies cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K1 X"
sorry

mtheorem card_4_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be finiteFINSET-1V1) &  not Y be finiteFINSET-1V1 implies cardCARD-1K1 Y *`CARD-2K2 cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
sorry

mtheorem card_4_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  not D be finiteFINSET-1V1 & n <>HIDDENR2 0NUMBERSK6 implies (n -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (n -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
sorry

mtheorem card_4_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not D be finiteFINSET-1V1 implies cardCARD-1K1 D =XBOOLE-0R4 cardCARD-1K1 (D * FINSEQ-2K3)"
sorry

end
