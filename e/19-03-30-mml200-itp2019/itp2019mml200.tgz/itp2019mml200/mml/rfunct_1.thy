theory rfunct_1
  imports funct_3 seq_2 partfun2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve C for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c for "ElementSUBSET-1M1-of C"
reserve f, f1, f2, f3, g, g1 for "complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
reserve r, p for "ComplexXCMPLX-0M1"
mlemma rfunct_1_lm_1:
"(-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
   sorry

mdef rfunct_1_def_1 (" _ '/RFUNCT-1K1  _ " [164,164]164 ) where
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f1 /RFUNCT-1K1 f2 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem rfunct_1_cl_1:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 /RFUNCT-1K1 f2 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem rfunct_1_cl_2:
  mlet "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 /RFUNCT-1K1 f2 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be real-valuedVALUED-0V7"
sorry
qed "sorry"

syntax RFUNCT_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/RFUNCT-1K2\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f1 /RFUNCT-1K2\<^bsub>(C,D)\<^esub> f2" \<rightharpoonup> "f1 /RFUNCT-1K1 f2"

mtheorem rfunct_1_add_1:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D)", "f2 be PartFuncPARTFUN1M1-of(C,D)"
"cluster f1 /RFUNCT-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
sorry
qed "sorry"

syntax RFUNCT_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/RFUNCT-1K3\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f1 /RFUNCT-1K3\<^bsub>(C,D)\<^esub> f2" \<rightharpoonup> "f1 /RFUNCT-1K1 f2"

mtheorem rfunct_1_add_2:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D)", "f2 be PartFuncPARTFUN1M1-of(C,D)"
"cluster f1 /RFUNCT-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
sorry
qed "sorry"

mdef rfunct_1_def_2 (" _ ^RFUNCT-1K4" [164]164 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f ^RFUNCT-1K4 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem rfunct_1_cl_3:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f ^RFUNCT-1K4 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem rfunct_1_cl_4:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f ^RFUNCT-1K4 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be real-valuedVALUED-0V7"
sorry
qed "sorry"

syntax RFUNCT_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^RFUNCT-1K5\<^bsub>'( _ , _ ')\<^esub>" [164,0,0]164)
translations "f ^RFUNCT-1K5\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^RFUNCT-1K4"

mtheorem rfunct_1_add_3:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^RFUNCT-1K4 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
sorry
qed "sorry"

syntax RFUNCT_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^RFUNCT-1K6\<^bsub>'( _ , _ ')\<^esub>" [164,0,0]164)
translations "f ^RFUNCT-1K6\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^RFUNCT-1K4"

mtheorem rfunct_1_add_4:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^RFUNCT-1K4 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem rfunct_1_th_1:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (g ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 g & domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem rfunct_1_th_2:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
sorry

mtheorem rfunct_1_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds c inTARSKIR2 domRELAT-1K1 (f ^RFUNCT-1K4) implies f .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem rfunct_1_th_4:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f ^RFUNCT-1K4)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem rfunct_1_th_5:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem rfunct_1_th_6:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4))"
sorry

mtheorem rfunct_1_th_7:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem rfunct_1_th_8:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2)+VALUED-1K1 f3 =FUNCT-1R1 f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)"
sorry

mtheorem rfunct_1_th_9:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)"
sorry

mtheorem rfunct_1_th_10:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3"
sorry

mtheorem rfunct_1_th_11:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f3 (#)VALUED-1K19 (f1 +VALUED-1K1 f2) =FUNCT-1R1 f3 (#)VALUED-1K19 f1 +VALUED-1K1 f3 (#)VALUED-1K19 f2"
  using rfunct_1_th_10 sorry

mtheorem rfunct_1_th_12:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 (r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2"
sorry

mtheorem rfunct_1_th_13:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)"
sorry

mtheorem rfunct_1_th_14:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3"
sorry

mtheorem rfunct_1_th_15:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f3 (#)VALUED-1K19 f1 -VALUED-1K47 f3 (#)VALUED-1K19 f2 =FUNCT-1R1 f3 (#)VALUED-1K19 (f1 -VALUED-1K47 f2)"
  using rfunct_1_th_14 sorry

mtheorem rfunct_1_th_16:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 +VALUED-1K1 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2"
sorry

mtheorem rfunct_1_th_17:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds  for p be ComplexXCMPLX-0M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K25 f =FUNCT-1R1 r (#)VALUED-1K25 (p (#)VALUED-1K25 f)"
sorry

mtheorem rfunct_1_th_18:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 -VALUED-1K47 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2"
sorry

mtheorem rfunct_1_th_19:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 f2 =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)"
sorry

mtheorem rfunct_1_th_20:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 (f2 +VALUED-1K1 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)-VALUED-1K47 f3"
sorry

mtheorem rfunct_1_th_21:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds \<one>\<^sub>M (#)VALUED-1K25 f =FUNCT-1R1 f"
sorry

mtheorem rfunct_1_th_22:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)+VALUED-1K1 f3"
sorry

mtheorem rfunct_1_th_23:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 +VALUED-1K1 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 +VALUED-1K1 f2)-VALUED-1K47 f3"
sorry

mtheorem rfunct_1_th_24:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2"
sorry

mtheorem rfunct_1_th_25:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds absVALUED-1K57 (r (#)VALUED-1K25 f) =FUNCT-1R1 ( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f"
sorry

mtheorem rfunct_1_th_26:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f ^RFUNCT-1K4)^RFUNCT-1K4 =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)"
sorry

mtheorem rfunct_1_th_27:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2)^RFUNCT-1K4 =FUNCT-1R1 (f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)"
sorry

mtheorem rfunct_1_th_28:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K25 f)^RFUNCT-1K4 =FUNCT-1R1 r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)"
sorry

mtheorem rfunct_1_th_29:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (-VALUED-1K32 f)^RFUNCT-1K4 =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f ^RFUNCT-1K4)"
  using rfunct_1_lm_1 rfunct_1_th_28 sorry

mtheorem rfunct_1_th_30:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f ^RFUNCT-1K4 =FUNCT-1R1 absVALUED-1K57 (f ^RFUNCT-1K4)"
sorry

mtheorem rfunct_1_th_31:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f /RFUNCT-1K1 g =FUNCT-1R1 f (#)VALUED-1K19 (g ^RFUNCT-1K4)"
sorry

mtheorem rfunct_1_th_32:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (g /RFUNCT-1K1 f) =FUNCT-1R1 (r (#)VALUED-1K25 g)/RFUNCT-1K1 f"
sorry

mtheorem rfunct_1_th_33:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)(#)VALUED-1K19 g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)"
sorry

mtheorem rfunct_1_th_34:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1) =FUNCT-1R1 (f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)"
sorry

mtheorem rfunct_1_th_35:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 /RFUNCT-1K1 f2)^RFUNCT-1K4 =FUNCT-1R1 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) /RFUNCT-1K1 f1"
sorry

mtheorem rfunct_1_th_36:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g (#)VALUED-1K19 (f1 /RFUNCT-1K1 f2) =FUNCT-1R1 (g (#)VALUED-1K19 f1)/RFUNCT-1K1 f2"
sorry

mtheorem rfunct_1_th_37:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g /RFUNCT-1K1 (f1 /RFUNCT-1K1 f2) =FUNCT-1R1 (g (#)VALUED-1K19 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4))/RFUNCT-1K1 f1"
sorry

mtheorem rfunct_1_th_38:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 f /RFUNCT-1K1 g =FUNCT-1R1 (-VALUED-1K32 f)/RFUNCT-1K1 g & f /RFUNCT-1K1 (-VALUED-1K32 g) =FUNCT-1R1 -VALUED-1K32 f /RFUNCT-1K1 g"
sorry

mtheorem rfunct_1_th_39:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f +VALUED-1K1 f2 /RFUNCT-1K1 f =FUNCT-1R1 (f1 +VALUED-1K1 f2)/RFUNCT-1K1 f & f1 /RFUNCT-1K1 f -VALUED-1K47 f2 /RFUNCT-1K1 f =FUNCT-1R1 (f1 -VALUED-1K47 f2)/RFUNCT-1K1 f"
sorry

mtheorem rfunct_1_th_40:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g =FUNCT-1R1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
sorry

mtheorem rfunct_1_th_41:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)/RFUNCT-1K1 (f1 /RFUNCT-1K1 g1) =FUNCT-1R1 (f (#)VALUED-1K19 g1  |RELAT-1K8 domRELAT-1K1 (g1 ^RFUNCT-1K4))/RFUNCT-1K1 (g (#)VALUED-1K19 f1)"
sorry

mtheorem rfunct_1_th_42:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f -VALUED-1K47 g1 /RFUNCT-1K1 g =FUNCT-1R1 (f1 (#)VALUED-1K19 g -VALUED-1K47 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
sorry

mtheorem rfunct_1_th_43:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 (f1 /RFUNCT-1K1 f2) =FUNCT-1R1 absVALUED-1K57 f1 /RFUNCT-1K1 absVALUED-1K57 f2"
sorry

mtheorem rfunct_1_th_44:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X & (f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2) & (f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1 +VALUED-1K1 f2  |RELAT-1K8 X"
sorry

mtheorem rfunct_1_th_45:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X & (f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2) & (f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1 (#)VALUED-1K19 f2  |RELAT-1K8 X"
sorry

mtheorem rfunct_1_th_46:
" for X be setHIDDENM2 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((-VALUED-1K32 f) |RELAT-1K8 X =FUNCT-1R1 -VALUED-1K32 f  |RELAT-1K8 X & (f ^RFUNCT-1K4) |RELAT-1K8 X =FUNCT-1R1 f  |RELAT-1K8 X ^RFUNCT-1K4) & absVALUED-1K57 f  |RELAT-1K8 X =FUNCT-1R1 absVALUED-1K57 (f  |RELAT-1K8 X)"
sorry

mtheorem rfunct_1_th_47:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X -VALUED-1K47 f2  |RELAT-1K8 X & (f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X -VALUED-1K47 f2) & (f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1 -VALUED-1K47 f2  |RELAT-1K8 X"
sorry

mtheorem rfunct_1_th_48:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2  |RELAT-1K8 X & (f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2) & (f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1 /RFUNCT-1K1 f2  |RELAT-1K8 X"
sorry

mtheorem rfunct_1_th_49:
" for X be setHIDDENM2 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K25 f) |RELAT-1K8 X =FUNCT-1R1 r (#)VALUED-1K25 f  |RELAT-1K8 X"
sorry

reserve r, r1, r2, p for "RealXREAL-0M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
mtheorem rfunct_1_th_50:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
sorry

mtheorem rfunct_1_th_51:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using valued_1_def_5 sorry

mtheorem rfunct_1_th_52:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff -VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using rfunct_1_th_51 sorry

mtheorem rfunct_1_th_53:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using valued_1_def_11 sorry

mtheorem rfunct_1_th_54:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
sorry

mtheorem rfunct_1_th_55:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
sorry

mtheorem rfunct_1_th_56:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies ((f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c & (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
sorry

mtheorem rfunct_1_th_57:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
sorry

mtheorem rfunct_1_th_58:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 -XCMPLX-0K4 f .FUNCT-1K1 c & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
  using valued_1_th_8 valued_1_th_18 sorry

mtheorem rfunct_1_th_59:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>).FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
  using rfunct_1_def_2 sorry

mtheorem rfunct_1_th_60:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
sorry

abbreviation(input) RFUNCT_1K7("chiRFUNCT-1K7'( _ , _ ')" [0,0]228) where
  "chiRFUNCT-1K7(X,C) \<equiv> chiFUNCT-3K4(X,C)"

mtheorem rfunct_1_add_5:
  mlet "X be setHIDDENM2", "C be setHIDDENM2"
"cluster chiFUNCT-3K4(X,C) as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "chiFUNCT-3K4(X,C) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem rfunct_1_cl_5:
  mlet "X be setHIDDENM2", "C be setHIDDENM2"
"cluster chiRFUNCT-1K7(X,C) as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 chiRFUNCT-1K7(X,C) implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using funct_3_def_3 sorry
qed "sorry"

mtheorem rfunct_1_th_61:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X,C) iff domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C & ( for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M) & ( not c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6))"
sorry

mtheorem rfunct_1_th_62:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds chiRFUNCT-1K7(X,C) be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
   sorry

mtheorem rfunct_1_th_63:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_64:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  not c inTARSKIR2 X iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_65:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 C \\SUBSET-1K6 X iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem rfunct_1_th_66:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds chiRFUNCT-1K7(C,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_67:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds chiRFUNCT-1K7(X,C) .FUNCT-1K1 c <>HIDDENR2 \<one>\<^sub>M iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_68:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds X missesXBOOLE-0R1 Y implies chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C)"
sorry

mtheorem rfunct_1_th_69:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C)"
sorry

reserve f for "real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
mtheorem rfunct_1_th_70:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r)"
sorry

mtheorem rfunct_1_th_71:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c)"
sorry

mtheorem rfunct_1_th_72:
" for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be boundedSEQ-2V6 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)"
sorry

mtheorem rfunct_1_th_73:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)"
sorry

mtheorem rfunct_1_th_74:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1) & (Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 Y be bounded-belowSEQ-2V2)) & (Y c=TARSKIR1 X & f  |RELAT-1K8 X be boundedSEQ-2V6 implies f  |RELAT-1K8 Y be boundedSEQ-2V6)"
sorry

mtheorem rfunct_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
sorry

mtheorem rfunct_1_cl_6:
"cluster constantFUNCT-1V5 also-is boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it be constantFUNCT-1V5 implies it be boundedSEQ-2V6"
sorry
qed "sorry"

mtheorem rfunct_1_th_76:
" for X be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds X missesXBOOLE-0R1 domRELAT-1K1 f implies f  |RELAT-1K8 X be boundedSEQ-2V6"
sorry

mtheorem rfunct_1_th_77:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
sorry

mtheorem rfunct_1_cl_7:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f  |RELAT-1K8 X implies it be bounded-aboveSEQ-2V1"
sorry
qed "sorry"

mtheorem rfunct_1_cl_8:
  mlet "f be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f  |RELAT-1K8 X implies it be bounded-belowSEQ-2V2"
sorry
qed "sorry"

mtheorem rfunct_1_cl_9:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-aboveSEQ-2V1"
sorry
qed "sorry"

mtheorem rfunct_1_cl_10:
  mlet "f be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-belowSEQ-2V2"
sorry
qed "sorry"

mtheorem rfunct_1_cl_11:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-belowSEQ-2V2"
sorry
qed "sorry"

mtheorem rfunct_1_cl_12:
  mlet "f be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-aboveSEQ-2V1"
sorry
qed "sorry"

mtheorem rfunct_1_th_78:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1) & (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2)"
sorry

mtheorem rfunct_1_th_79:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2) & (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1)"
sorry

mtheorem rfunct_1_th_80:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
sorry

mtheorem rfunct_1_cl_13:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster absVALUED-1K57 f as-term-is bounded-belowSEQ-2V2"
proof
(*coherence*)
  show "absVALUED-1K57 f be bounded-belowSEQ-2V2"
sorry
qed "sorry"

mtheorem rfunct_1_th_81:
" for X be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f  |RELAT-1K8 X be bounded-belowSEQ-2V2"
   sorry

mtheorem rfunct_1_cl_14:
  mlet "f be boundedSEQ-2V6\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster absVALUED-1K57 f as-term-is boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 absVALUED-1K57 f implies it be boundedSEQ-2V6"
sorry
qed "sorry"

mtheorem rfunct_1_cl_15:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 -VALUED-1K32 f implies it be bounded-belowSEQ-2V2"
     sorry
qed "sorry"

mtheorem rfunct_1_th_82:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 implies absVALUED-1K57 f  |RELAT-1K8 Y be boundedSEQ-2V6 & (-VALUED-1K32 f) |RELAT-1K8 Y be boundedSEQ-2V6"
sorry

reserve f1, f2 for "real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
mtheorem rfunct_1_cl_16:
  mlet "f1 be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 +VALUED-1K1 f2 implies it be bounded-aboveSEQ-2V1"
sorry
qed "sorry"

mtheorem rfunct_1_cl_17:
  mlet "f1 be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 +VALUED-1K1 f2 implies it be bounded-belowSEQ-2V2"
sorry
qed "sorry"

mtheorem rfunct_1_th_83:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((f1  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f2  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & (f1  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f2  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) & (f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6 implies (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
sorry

mtheorem rfunct_1_cl_18:
  mlet "f1 be boundedSEQ-2V6\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be boundedSEQ-2V6\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 (#)VALUED-1K19 f2 implies it be boundedSEQ-2V6"
sorry
qed "sorry"

mtheorem rfunct_1_th_84:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6 implies (f1 (#)VALUED-1K19 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & (f1 -VALUED-1K47 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
sorry

mtheorem rfunct_1_th_85:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-aboveSEQ-2V1"
sorry

mtheorem rfunct_1_th_86:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-belowSEQ-2V2"
sorry

mtheorem rfunct_1_th_87:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be boundedSEQ-2V6 & f  |RELAT-1K8 Y be boundedSEQ-2V6 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be boundedSEQ-2V6"
  using rfunct_1_th_85 rfunct_1_th_86 sorry

reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
mtheorem rfunct_1_cl_19:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "f2 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_1_cl_20:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "f2 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_1_cl_21:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "f2 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_1_th_88:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be constantFUNCT-1V5 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies ((f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
sorry

mtheorem rfunct_1_cl_22:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster -VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_1_cl_23:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_1_cl_24:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "p be RealXREAL-0M1"
"cluster p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_1_th_89:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
sorry

mtheorem rfunct_1_th_90:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
sorry

mtheorem rfunct_1_th_91:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
sorry

mtheorem rfunct_1_th_92:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (( for r be RealXREAL-0M1 holds (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6) & (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6) & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
sorry

mtheorem rfunct_1_th_93:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
  using rfunct_1_th_83 sorry

mtheorem rfunct_1_th_94:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies ((f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & (f2 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
sorry

end
