theory limfunc3
  imports limfunc2 xcmplx_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, r2, g, g1, g2, x0, t for "RealXREAL-0M1"
reserve n, k, m for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve seq for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma limfunc3_lm_1:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 & r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
sorry

mlemma limfunc3_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X implies ((((rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
sorry

mlemma limfunc3_lm_3:
" for r be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r & r <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mlemma limfunc3_lm_4:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X implies ((((rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
sorry

mtheorem limfunc3_th_1:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) or rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
sorry

mtheorem limfunc3_th_2:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f) implies ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
sorry

mtheorem limfunc3_th_3:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 k implies (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 r) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f))"
sorry

mtheorem limfunc3_th_4:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
sorry

mtheorem limfunc3_th_5:
" for r2 be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds 0NUMBERSK6 <XXREAL-0R3 r2 & ].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .[ c=TARSKIR1 domRELAT-1K1 f implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))"
sorry

mtheorem limfunc3_th_6:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f) implies (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
sorry

mtheorem limfunc3_th_7:
" for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & 0NUMBERSK6 <XXREAL-0R3 g implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g)"
sorry

mtheorem limfunc3_th_8:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) iff ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f))"
sorry

mdef limfunc3_def_1 (" _ is-convergent-inLIMFUNC3R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-convergent-inLIMFUNC3R1 x0 means
  ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g)"..

mdef limfunc3_def_2 (" _ is-divergent-to+infty-inLIMFUNC3R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-divergent-to+infty-inLIMFUNC3R2 x0 means
  ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"..

mdef limfunc3_def_3 (" _ is-divergent-to-infty-inLIMFUNC3R3  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-divergent-to-infty-inLIMFUNC3R3 x0 means
  ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)"..

mtheorem limfunc3_th_9:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
sorry

mtheorem limfunc3_th_10:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1))"
sorry

mtheorem limfunc3_th_11:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to-infty-inLIMFUNC3R3 x0 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1))"
sorry

mtheorem limfunc3_th_12:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 iff f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
sorry

mtheorem limfunc3_th_13:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to-infty-inLIMFUNC3R3 x0 iff f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
sorry

mtheorem limfunc3_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & f2 is-divergent-to+infty-inLIMFUNC3R2 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_15:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & f2 is-divergent-to-infty-inLIMFUNC3R3 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to-infty-inLIMFUNC3R3 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_16:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_17:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & 0NUMBERSK6 <XXREAL-0R3 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies r1 <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_18:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f is-divergent-to+infty-inLIMFUNC3R2 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0) & (f is-divergent-to+infty-inLIMFUNC3R2 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0)) & (f is-divergent-to-infty-inLIMFUNC3R3 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0)) & (f is-divergent-to-infty-inLIMFUNC3R3 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0)"
sorry

mtheorem limfunc3_th_19:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_20:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-decreasingVALUED-0V11 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-increasingVALUED-0V12) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_21:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (((0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be increasingVALUED-0V9) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be decreasingVALUED-0V10) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
  using limfunc3_th_20 sorry

mtheorem limfunc3_th_22:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-increasingVALUED-0V12 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-decreasingVALUED-0V11) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
sorry

mtheorem limfunc3_th_23:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (((0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be decreasingVALUED-0V10) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be increasingVALUED-0V9) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
  using limfunc3_th_22 sorry

mtheorem limfunc3_th_24:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_25:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
sorry

mtheorem limfunc3_th_26:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_27:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
sorry

mdef limfunc3_def_4 ("limLIMFUNC3K1'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"assume f is-convergent-inLIMFUNC3R1 x0 func limLIMFUNC3K1(f,x0) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f is-convergent-inLIMFUNC3R1 x0 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
sorry
  (*uniqueness*)
    show "f is-convergent-inLIMFUNC3R1 x0 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem limfunc3_th_28:
" for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies (limLIMFUNC3K1(f,x0) =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))))"
sorry

mtheorem limfunc3_th_29:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies (((f is-left-convergent-inLIMFUNC2R1 x0 & f is-right-convergent-inLIMFUNC2R4 x0) & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
sorry

mtheorem limfunc3_th_30:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-convergent-inLIMFUNC2R1 x0 & f is-right-convergent-inLIMFUNC2R4 x0) & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0) implies (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
sorry

mtheorem limfunc3_th_31:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
sorry

mtheorem limfunc3_th_32:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 -XCMPLX-0K4 limLIMFUNC3K1(f,x0)"
sorry

mtheorem limfunc3_th_33:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(f2,x0)"
sorry

mtheorem limfunc3_th_34:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0) -XCMPLX-0K6 limLIMFUNC3K1(f2,x0)"
sorry

mtheorem limfunc3_th_35:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc3_th_36:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1  |.COMPLEX1K10 limLIMFUNC3K1(f,x0) .|"
sorry

mtheorem limfunc3_th_37:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc3_th_38:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))"
sorry

mtheorem limfunc3_th_39:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & limLIMFUNC3K1(f2,x0) <>HIDDENR2 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))/XCMPLX-0K7 (limLIMFUNC3K1(f2,x0))"
sorry

mtheorem limfunc3_th_40:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc3_th_41:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[))) implies f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
sorry

mtheorem limfunc3_th_42:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
sorry

mtheorem limfunc3_th_43:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))) implies limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
sorry

mtheorem limfunc3_th_44:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc3_th_45:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_46:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0"
sorry

mtheorem limfunc3_th_47:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0"
sorry

mtheorem limfunc3_th_48:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0"
sorry

end
