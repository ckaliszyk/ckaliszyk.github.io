theory sin_cos2
  imports sin_cos
   "../mizar_extension/E_number"
begin
(*begin*)
reserve p, q, r, th, th1 for "RealXREAL-0M1"
reserve n for "NatNAT-1M1"
mtheorem sin_cos2_th_1:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds p >=XXREAL-0R2 0NUMBERSK6 & r >=XXREAL-0R2 0NUMBERSK6 implies p +XCMPLX-0K2 r >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (p *XCMPLX-0K3 r)"
sorry

mtheorem sin_cos2_th_2:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be increasingVALUED-0V9"
sorry

mlemma sin_cos2_lm_1:
" for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies 0NUMBERSK6 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 th"
sorry

mtheorem sin_cos2_th_3:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be decreasingVALUED-0V10"
sorry

mtheorem sin_cos2_th_4:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be decreasingVALUED-0V10"
sorry

mtheorem sin_cos2_th_5:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be decreasingVALUED-0V10"
sorry

mtheorem sin_cos2_th_6:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be decreasingVALUED-0V10"
sorry

mtheorem sin_cos2_th_7:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
sorry

mtheorem sin_cos2_th_8:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
sorry

mtheorem sin_cos2_th_9:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
sorry

mtheorem sin_cos2_th_10:
" for th be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
sorry

mtheorem sin_cos2_th_11:
" for th be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
sorry

(*begin*)
mdef sin_cos2_def_1 ("sinhSIN-COS2K1" 164 ) where
"func sinhSIN-COS2K1 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos2_def_2 ("sinhSIN-COS2K2  _ " [164]164 ) where
  mlet "d be objectHIDDENM1"
"func sinhSIN-COS2K2 d \<rightarrow> numberORDINAL1M2 equals
  (sinhSIN-COS2K1).FUNCT-1K1 d"
proof-
  (*coherence*)
    show "(sinhSIN-COS2K1).FUNCT-1K1 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos2_cl_1:
  mlet "d be objectHIDDENM1"
"cluster sinhSIN-COS2K2 d as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "sinhSIN-COS2K2 d be realXREAL-0V1"
     sorry
qed "sorry"

mdef sin_cos2_def_3 ("coshSIN-COS2K3" 164 ) where
"func coshSIN-COS2K3 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos2_def_4 ("coshSIN-COS2K4  _ " [164]164 ) where
  mlet "d be objectHIDDENM1"
"func coshSIN-COS2K4 d \<rightarrow> numberORDINAL1M2 equals
  (coshSIN-COS2K3).FUNCT-1K1 d"
proof-
  (*coherence*)
    show "(coshSIN-COS2K3).FUNCT-1K1 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos2_cl_2:
  mlet "d be objectHIDDENM1"
"cluster coshSIN-COS2K4 d as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "coshSIN-COS2K4 d be realXREAL-0V1"
     sorry
qed "sorry"

mdef sin_cos2_def_5 ("tanhSIN-COS2K5" 164 ) where
"func tanhSIN-COS2K5 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos2_def_6 ("tanhSIN-COS2K6  _ " [164]164 ) where
  mlet "d be objectHIDDENM1"
"func tanhSIN-COS2K6 d \<rightarrow> numberORDINAL1M2 equals
  (tanhSIN-COS2K5).FUNCT-1K1 d"
proof-
  (*coherence*)
    show "(tanhSIN-COS2K5).FUNCT-1K1 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos2_cl_3:
  mlet "d be objectHIDDENM1"
"cluster tanhSIN-COS2K6 d as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "tanhSIN-COS2K6 d be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem sin_cos2_th_12:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
sorry

mtheorem sin_cos2_th_13:
"(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
  using sin_cos_th_51 sin_cos_def_23 sorry

mtheorem sin_cos2_th_14:
" for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M & (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mlemma sin_cos2_lm_2:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
sorry

mlemma sin_cos2_lm_3:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
sorry

mtheorem sin_cos2_th_15:
" for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6 & (coshSIN-COS2K3).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6) & (coshSIN-COS2K3).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem sin_cos2_th_16:
"(sinhSIN-COS2K1).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos2_th_17:
" for p be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_4:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for a1 be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 & q <>HIDDENR2 0NUMBERSK6 implies (p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1) =XBOOLE-0R4 (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 r)*XCMPLX-0K3 (a1 /XCMPLX-0K7 q))"
sorry

mlemma sin_cos2_lm_5:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
sorry

mtheorem sin_cos2_th_18:
" for p be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 \<one>\<^sub>M) & ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mlemma sin_cos2_lm_6:
" for p be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mtheorem sin_cos2_th_19:
" for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p & (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p) & (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_7:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
sorry

mtheorem sin_cos2_th_20:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r & (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  using sin_cos2_lm_2 sin_cos2_lm_7 sorry

mlemma sin_cos2_lm_8:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
sorry

mtheorem sin_cos2_th_21:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r & (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  using sin_cos2_lm_3 sin_cos2_lm_8 sorry

mlemma sin_cos2_lm_9:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
sorry

mtheorem sin_cos2_th_22:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r) & (tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
  using sin_cos2_lm_5 sin_cos2_lm_9 sorry

mtheorem sin_cos2_th_23:
" for p be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) & (tanhSIN-COS2K5).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((tanhSIN-COS2K5).FUNCT-1K1 p)^2SQUARE-1K1)"
sorry

mtheorem sin_cos2_th_24:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) & (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1"
sorry

mtheorem sin_cos2_th_25:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) & (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
sorry

mtheorem sin_cos2_th_26:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos2_th_27:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos2_th_28:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) & (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
sorry

mtheorem sin_cos2_th_29:
" for p be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p)"
sorry

mtheorem sin_cos2_th_30:
"(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1) =XBOOLE-0R4 REALNUMBERSK2 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) =XBOOLE-0R4 REALNUMBERSK2) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanhSIN-COS2K5) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mlemma sin_cos2_lm_10:
" for d be RealXREAL-0M1 holds (comprealBINOP-2K7).FUNCT-1K1 d =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d"
sorry

mlemma sin_cos2_lm_11:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mlemma sin_cos2_lm_12:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies ( for p be RealXREAL-0M1 holds f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(f,p) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
sorry

mlemma sin_cos2_lm_13:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
sorry

mlemma sin_cos2_lm_14:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p) =XBOOLE-0R4 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_15:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p) & diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) & diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
sorry

mlemma sin_cos2_lm_16:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p))"
sorry

mlemma sin_cos2_lm_17:
" for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_18:
" for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies sinhSIN-COS2K1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
sorry

mtheorem sin_cos2_th_31:
" for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_19:
" for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff,p))"
sorry

mlemma sin_cos2_lm_20:
" for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (coshSIN-COS2K3).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_21:
" for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies coshSIN-COS2K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
sorry

mtheorem sin_cos2_th_32:
" for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
sorry

mlemma sin_cos2_lm_22:
" for p be RealXREAL-0M1 holds (sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3),p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
sorry

mlemma sin_cos2_lm_23:
"tanhSIN-COS2K5 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
sorry

mtheorem sin_cos2_th_33:
" for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(tanhSIN-COS2K5,p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
  using sin_cos2_lm_22 sin_cos2_lm_23 sorry

mtheorem sin_cos2_th_34:
" for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
sorry

mtheorem sin_cos2_th_35:
" for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
sorry

mtheorem sin_cos2_th_36:
" for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(tanhSIN-COS2K5,p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
sorry

mlemma sin_cos2_lm_24:
" for p be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<two>\<^sub>M"
sorry

mtheorem sin_cos2_th_37:
" for p be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 p >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem sin_cos2_th_38:
" for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-continuous-inFCONT-1R1 p"
  using sin_cos2_th_31 fdiff_1_th_24 sorry

mtheorem sin_cos2_th_39:
" for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-continuous-inFCONT-1R1 p"
  using sin_cos2_th_32 fdiff_1_th_24 sorry

mtheorem sin_cos2_th_40:
" for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-continuous-inFCONT-1R1 p"
  using sin_cos2_lm_22 sin_cos2_lm_23 fdiff_1_th_24 sorry

mtheorem sin_cos2_th_41:
"(sinhSIN-COS2K1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
  using sin_cos2_th_34 fdiff_1_th_25 sorry

mtheorem sin_cos2_th_42:
"(coshSIN-COS2K3) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
  using sin_cos2_th_35 fdiff_1_th_25 sorry

mtheorem sin_cos2_th_43:
"(tanhSIN-COS2K5) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
  using sin_cos2_th_36 fdiff_1_th_25 sorry

mtheorem sin_cos2_th_44:
" for p be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p <XXREAL-0R3 \<one>\<^sub>M & (tanhSIN-COS2K5).FUNCT-1K1 p >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

end
