theory rfinseq
  imports seqm_3 rvsum_1 card_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y for "setHIDDENM2"
reserve n, m for "NatNAT-1M1"
reserve r, s for "RealXREAL-0M1"
mtheorem rfinseq_cl_1:
  mlet "f be finiteFINSET-1V1\<bar>RelationRELAT-1M1", "x be objectHIDDENM1"
"cluster CoimRELAT-1K13(f,x) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "CoimRELAT-1K13(f,x) be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem rfinseq_th_1:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FinSequenceFINSEQ-1M1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 iff (f ^FINSEQ-1K8 h,g ^FINSEQ-1K8 h)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfinseq_th_2:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g,g ^FINSEQ-1K8 f)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfinseq_th_3:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 implies lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g & domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 g"
sorry

mtheorem rfinseq_th_4:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 iff ( ex P be PermutationFUNCT-2M2-of domFINSEQ-1K5 g st f =FUNCT-1R1 g *FUNCT-1K3 P)"
sorry

mlemma rfinseq_lm_1:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds cardCARD-1K4 (domRELAT-1K1 (F  |RELAT-1K8 X)) =XBOOLE-0R4 0NUMBERSK6 implies ( ex a be FinSequenceFINSEQ-1M1 st (F  |RELAT-1K8 X,a)are-fiberwise-equipotentCLASSES1R2)"
sorry

mlemma rfinseq_lm_2:
" for n be NatNAT-1M1 holds ( for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds cardCARD-1K4 (domRELAT-1K1 (F  |RELAT-1K8 X)) =XBOOLE-0R4 n implies ( ex a be FinSequenceFINSEQ-1M1 st (F  |RELAT-1K8 X,a)are-fiberwise-equipotentCLASSES1R2)) implies ( for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds cardCARD-1K4 (domRELAT-1K1 (F  |RELAT-1K8 X)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies ( ex a be FinSequenceFINSEQ-1M1 st (F  |RELAT-1K8 X,a)are-fiberwise-equipotentCLASSES1R2))"
sorry

mtheorem rfinseq_th_5:
" for F be FunctionFUNCT-1M1 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  ex f be FinSequenceFINSEQ-1M1 st (F  |RELAT-1K8 X,f)are-fiberwise-equipotentCLASSES1R2"
sorry

mdef rfinseq_def_1 (" _ '/^RFINSEQK1  _ " [164,164]164 ) where
  mlet "n be NatNAT-1M1", "f be FinSequenceFINSEQ-1M1"
"func f /^RFINSEQK1 n \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 n & ( for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n)) if n <=XXREAL-0R1 lenFINSEQ-1K4 f otherwise \<lambda>it. it =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  (*existence*)
    show "(n <=XXREAL-0R1 lenFINSEQ-1K4 f implies ( ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 n & ( for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n)))) & ( not n <=XXREAL-0R1 lenFINSEQ-1K4 f implies ( ex it be FinSequenceFINSEQ-1M1 st it =FINSEQ-1R1 {}XBOOLE-0K1))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (n <=XXREAL-0R1 lenFINSEQ-1K4 f implies ((lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 n & ( for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n))) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 n & ( for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n))) implies it1 =HIDDENR1 it2)) & ( not n <=XXREAL-0R1 lenFINSEQ-1K4 f implies (it1 =FINSEQ-1R1 {}XBOOLE-0K1 & it2 =FINSEQ-1R1 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
qed "sorry"

syntax RFINSEQK2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/^RFINSEQK2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "f /^RFINSEQK2\<^bsub>(D)\<^esub> n" \<rightharpoonup> "f /^RFINSEQK1 n"

mtheorem rfinseq_add_1:
  mlet "D be setHIDDENM2", "n be NatNAT-1M1", "f be FinSequenceFINSEQ-1M3-of D"
"cluster f /^RFINSEQK1 n as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "f /^RFINSEQK1 n be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

mlemma rfinseq_lm_3:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =FINSEQ-1R1 f"
sorry

mtheorem rfinseq_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 SegFINSEQ-1K2 n implies (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n).FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 m & m inTARSKIR2 domFINSEQ-1K5 f"
sorry

mtheorem rfinseq_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds lenFINSEQ-1K4 f =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & x =XBOOLE-0R4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies f =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
sorry

mtheorem rfinseq_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) =FINSEQ-1R1 f"
sorry

mtheorem rfinseq_th_9:
" for R1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for R2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (R1,R2)are-fiberwise-equipotentCLASSES1R2 implies SumRVSUM-1K22 R1 =HIDDENR1 SumRVSUM-1K22 R2"
sorry

mdef rfinseq_def_2 ("MIMRFINSEQK3  _ " [228]228 ) where
  mlet "R be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"func MIMRFINSEQK3 R \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. (lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 R & it .FUNCT-1K1 lenFINSEQ-1K4 it =XBOOLE-0R4 R .FUNCT-1K1 lenFINSEQ-1K4 R) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 n =XBOOLE-0R4 R .FUNCT-1K1 n -XCMPLX-0K6 R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 R & it .FUNCT-1K1 lenFINSEQ-1K4 it =XBOOLE-0R4 R .FUNCT-1K1 lenFINSEQ-1K4 R) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 n =XBOOLE-0R4 R .FUNCT-1K1 n -XCMPLX-0K6 R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds ((lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 R & it1 .FUNCT-1K1 lenFINSEQ-1K4 it1 =XBOOLE-0R4 R .FUNCT-1K1 lenFINSEQ-1K4 R) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 it1 -XCMPLX-0K6 \<one>\<^sub>M implies it1 .FUNCT-1K1 n =XBOOLE-0R4 R .FUNCT-1K1 n -XCMPLX-0K6 R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & ((lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 R & it2 .FUNCT-1K1 lenFINSEQ-1K4 it2 =XBOOLE-0R4 R .FUNCT-1K1 lenFINSEQ-1K4 R) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 it2 -XCMPLX-0K6 \<one>\<^sub>M implies it2 .FUNCT-1K1 n =XBOOLE-0R4 R .FUNCT-1K1 n -XCMPLX-0K6 R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem rfinseq_th_10:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds lenFINSEQ-1K4 R =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M & R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 r implies MIMRFINSEQK3 (R  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =FINSEQ-1R1 MIMRFINSEQK3 R  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)"
sorry

mtheorem rfinseq_th_11:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (lenFINSEQ-1K4 R =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M & R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 r) & R .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 s implies MIMRFINSEQK3 R =FINSEQ-1R1 MIMRFINSEQK3 R  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K11 r -XCMPLX-0K6 s,s *>)"
sorry

mtheorem rfinseq_th_12:
"MIMRFINSEQK3 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
sorry

mtheorem rfinseq_th_13:
" for r be RealXREAL-0M1 holds MIMRFINSEQK3 (<*FINSEQ-1K10 r*>) =FINSEQ-1R1 <*FINSEQ-1K10 r*>"
sorry

mtheorem rfinseq_th_14:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds MIMRFINSEQK3 (<*FINSEQ-1K11 r,s *>) =FINSEQ-1R1 <*FINSEQ-1K11 r -XCMPLX-0K6 s,s *>"
sorry

mtheorem rfinseq_th_15:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds MIMRFINSEQK3 R /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 MIMRFINSEQK3 (R /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem rfinseq_th_16:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 R <>HIDDENR2 0NUMBERSK6 implies SumRVSUM-1K22 (MIMRFINSEQK3 R) =HIDDENR1 R .FUNCT-1K1 \<one>\<^sub>M"
sorry

mtheorem rfinseq_th_17:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 R implies SumRVSUM-1K22 (MIMRFINSEQK3 (R /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)) =HIDDENR1 R .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

abbreviation(input) RFINSEQV1("non-increasingRFINSEQV1" 70) where
  "non-increasingRFINSEQV1 \<equiv> non-increasingSEQM-3V4"

mtheorem rfinseq_def_3:
  mlet "IT be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine attr non-increasingRFINSEQV1 for real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 means
  (\<lambda>IT.  for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 IT & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 IT implies IT .FUNCT-1K1 n >=XXREAL-0R2 IT .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for IT be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds IT be non-increasingRFINSEQV1 iff ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 IT & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 IT implies IT .FUNCT-1K1 n >=XXREAL-0R2 IT .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
qed "sorry"

mtheorem rfinseq_cl_2:
"cluster non-increasingRFINSEQV1 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st it be non-increasingRFINSEQV1"
sorry
qed "sorry"

mtheorem rfinseq_th_18:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 R =XBOOLE-0R4 0NUMBERSK6 or lenFINSEQ-1K4 R =XBOOLE-0R4 \<one>\<^sub>M implies R be non-increasingRFINSEQV1"
sorry

mtheorem rfinseq_th_19:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds R be non-increasingRFINSEQV1 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 R & m inTARSKIR2 domFINSEQ-1K5 R) & n <XXREAL-0R3 m implies R .FUNCT-1K1 n >=XXREAL-0R2 R .FUNCT-1K1 m)"
sorry

mtheorem rfinseq_th_20:
" for R be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds R  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
sorry

mtheorem rfinseq_th_21:
" for R be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds R /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n be non-increasingRFINSEQV1"
sorry

mlemma rfinseq_lm_4:
" for f be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for g be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds (lenFINSEQ-1K4 f =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g) & (f,g)are-fiberwise-equipotentCLASSES1R2 implies f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 g .FUNCT-1K1 lenFINSEQ-1K4 g & (f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n,g  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)are-fiberwise-equipotentCLASSES1R2"
sorry

mlemma rfinseq_lm_5:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds 0NUMBERSK6 =XBOOLE-0R4 lenFINSEQ-1K4 R implies ( ex b be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (R,b)are-fiberwise-equipotentCLASSES1R2)"
sorry

mlemma rfinseq_lm_6:
" for n be NatNAT-1M1 holds ( for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds n =XBOOLE-0R4 lenFINSEQ-1K4 R implies ( ex b be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (R,b)are-fiberwise-equipotentCLASSES1R2)) implies ( for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 R implies ( ex b be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (R,b)are-fiberwise-equipotentCLASSES1R2))"
sorry

mtheorem rfinseq_th_22:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  ex R1 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (R,R1)are-fiberwise-equipotentCLASSES1R2"
sorry

mlemma rfinseq_lm_7:
" for n be NatNAT-1M1 holds  for g1 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for g2 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds n =XBOOLE-0R4 lenFINSEQ-1K4 g1 & (g1,g2)are-fiberwise-equipotentCLASSES1R2 implies g1 =FINSEQ-1R1 g2"
sorry

mtheorem rfinseq_th_23:
" for R1 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for R2 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (R1,R2)are-fiberwise-equipotentCLASSES1R2 implies R1 =FINSEQ-1R1 R2"
sorry

mtheorem rfinseq_th_24:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies R \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } =XBOOLE-0R4 (r *RVSUM-1K12 R)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
sorry

mtheorem rfinseq_th_25:
" for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds ((0NUMBERSK6)*RVSUM-1K12 R)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domFINSEQ-1K5 R"
sorry

(*begin*)
reserve f, g for "FunctionFUNCT-1M1"
mtheorem rfinseq_th_26:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 g & f be one-to-oneFUNCT-1V2) & g be one-to-oneFUNCT-1V2 implies (f,g)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfinseq_th_27:
" for f be FinSequenceFINSEQ-1M1 holds f /^RFINSEQK1 lenFINSEQ-1K4 f =FINSEQ-1R1 {}XBOOLE-0K1"
sorry

mtheorem rfinseq_th_28:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for m be setHIDDENM2 holds  for n be setHIDDENM2 holds ((((f .FUNCT-1K1 m =XBOOLE-0R4 g .FUNCT-1K1 n & f .FUNCT-1K1 n =XBOOLE-0R4 g .FUNCT-1K1 m) & m inTARSKIR2 domRELAT-1K1 f) & n inTARSKIR2 domRELAT-1K1 f) & domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g) & ( for k be setHIDDENM2 holds (k <>HIDDENR2 m & k <>HIDDENR2 n) & k inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 k =XBOOLE-0R4 g .FUNCT-1K1 k) implies (f,g)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfinseq_th_29:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 (f /^RFINSEQK1 k) =XBOOLE-0R4 lenFINSEQ-1K4 f -'XREAL-0K1 k"
sorry

mtheorem rfinseq_th_30:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 domFINSEQ-1K5 g & (f,g)are-fiberwise-equipotentCLASSES1R2 implies ( ex y be setHIDDENM2 st y inTARSKIR2 domFINSEQ-1K5 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y)"
sorry

mtheorem rfinseq_th_31:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FinSequenceFINSEQ-1M1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 iff (h ^FINSEQ-1K8 f,h ^FINSEQ-1K8 g)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfinseq_th_32:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for j be NatNAT-1M1 holds ((((((f,g)are-fiberwise-equipotentCLASSES1R2 & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies f .FUNCT-1K1 i =XBOOLE-0R4 g .FUNCT-1K1 i)) & ( for i be NatNAT-1M1 holds n <XXREAL-0R3 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 i =XBOOLE-0R4 g .FUNCT-1K1 i)) & m <XXREAL-0R3 j) & j <=XXREAL-0R1 n implies ( ex k be NatNAT-1M1 st (m <XXREAL-0R3 k & k <=XXREAL-0R1 n) & f .FUNCT-1K1 j =XBOOLE-0R4 g .FUNCT-1K1 k)"
sorry

mtheorem rfinseq_th_33:
" for t be FinSequenceFINSEQ-1M3-of INTNUMBERSK5 holds  ex u be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st ((t,u)are-fiberwise-equipotentCLASSES1R2 & u be FinSequenceFINSEQ-1M3-of INTNUMBERSK5) & u be non-increasingRFINSEQV1"
sorry

end
