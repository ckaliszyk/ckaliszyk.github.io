theory trees_a
  imports trees_2 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve T, T1 for "TreeTREES-1M1"
reserve P for "AntiChain-of-PrefixesTREES-1M6-of T"
reserve p1 for "FinSequenceFINSEQ-1M1"
reserve p, q, r, s, p9 for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
reserve x, Z for "setHIDDENM2"
reserve t for "ElementTREES-1M2-of T"
reserve k, n for "NatNAT-1M1"
mtheorem trees_a_th_1:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds p ^FINSEQ-1K8 q =FINSEQ-1R1 s ^FINSEQ-1K8 r implies (p,s)are-c=-comparableXBOOLE-0R3"
sorry

mdef trees_a_def_1 ("treeTREES-AK1'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "T be TreeTREES-1M1", "T1 be TreeTREES-1M1", "P be AntiChain-of-PrefixesTREES-1M6-of T"
"assume P <>HIDDENR2 {}XBOOLE-0K1 func treeTREES-AK1(T,P,T1) \<rightarrow> TreeTREES-1M1 means
  \<lambda>it.  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
proof-
  (*existence*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
sorry
  (*uniqueness*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff q inTARSKIR2 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (p inTARSKIR2 P & r inTARSKIR2 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem trees_a_th_2:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P <>HIDDENR2 {}XBOOLE-0K1 implies treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
sorry

mtheorem trees_a_th_3:
" for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
sorry

mtheorem trees_a_th_4:
" for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P c=TARSKIR1 {t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 }"
sorry

mtheorem trees_a_th_5:
" for T be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\SUBSET-1K6 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 }) =XBOOLE-0R4 P"
sorry

mtheorem trees_a_th_6:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P }"
sorry

mtheorem trees_a_th_7:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds P <>HIDDENR2 {}XBOOLE-0K1 implies treeTREES-AK1(T,P,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of T, s be ElementTREES-1M2-of T1 : p inTARSKIR2 P })"
sorry

mtheorem trees_a_th_8:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for P be AntiChain-of-PrefixesTREES-1M6-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies T1 =TREES-2R1 (treeTREES-AK1(T,P,T1)) |TREES-1K4 p"
sorry

mtheorem trees_a_cl_1:
  mlet "T be TreeTREES-1M1"
"cluster  non emptyXBOOLE-0V1 for AntiChain-of-PrefixesTREES-1M6-of T"
proof
(*existence*)
  show " ex it be AntiChain-of-PrefixesTREES-1M6-of T st it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

syntax TREES_AK2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("{TREES-AK2\<^bsub>'( _ ')\<^esub>  _ }" [0,0]356)
translations "{TREES-AK2\<^bsub>(T)\<^esub> t}" \<rightharpoonup> "{TARSKIK1 t}"

mtheorem trees_a_add_1:
  mlet "T be TreeTREES-1M1", "t be ElementTREES-1M2-of T"
"cluster {TARSKIK1 t} as-term-is AntiChain-of-PrefixesTREES-1M6-of T"
proof
(*coherence*)
  show "{TARSKIK1 t} be AntiChain-of-PrefixesTREES-1M6-of T"
    using trees_1_th_39 sorry
qed "sorry"

mtheorem trees_a_th_9:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds treeTREES-AK1(T,{TREES-AK2\<^bsub>(T)\<^esub> t},T1) =TREES-2R1 T with-replacementTREES-1K5(t,T1)"
sorry

reserve T, T1 for "DecoratedTreeTREES-2M4"
reserve P for "AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
reserve t for "ElementTREES-1M2-of domRELAT-1K1 T"
reserve p1, p2, r1, r2 for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mdef trees_a_def_2 ("treeTREES-AK3'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "T be DecoratedTreeTREES-2M4", "P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T", "T1 be DecoratedTreeTREES-2M4"
"assume P <>HIDDENR2 {}XBOOLE-0K1 func treeTREES-AK3(T,P,T1) \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. domRELAT-1K1 it =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  (*existence*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
sorry
  (*uniqueness*)
    show "P <>HIDDENR2 {}XBOOLE-0K1 implies ( for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) & (domRELAT-1K1 it2 =TREES-2R1 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 treeTREES-AK1(domRELAT-1K1 T,P,domRELAT-1K1 T1) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem trees_a_th_10:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds P <>HIDDENR2 {}XBOOLE-0K1 implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 q & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q) or ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st ((p inTARSKIR2 P & r inTARSKIR2 domRELAT-1K1 T1) & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
sorry

mtheorem trees_a_th_11:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) implies  not p is-a-prefix-ofTREES-1R2 q & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
sorry

mtheorem trees_a_th_12:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds P <>HIDDENR2 {}XBOOLE-0K1 implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 P implies  not p is-a-prefix-ofTREES-1R2 t1 } implies (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q)"
sorry

mtheorem trees_a_th_13:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) & q inTARSKIR2 {t1 where t1 be ElementTREES-1M2-of domRELAT-1K1 T :  not p is-a-prefix-ofTREES-1R2 t1 } implies (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q)"
sorry

mtheorem trees_a_th_14:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for P be AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (treeTREES-AK3(T,P,T1)) & q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where p be ElementTREES-1M2-of domRELAT-1K1 T, s be ElementTREES-1M2-of domRELAT-1K1 T1 : p inTARSKIR2 P } implies ( ex p9 be ElementTREES-1M2-of domRELAT-1K1 T st  ex r be ElementTREES-1M2-of domRELAT-1K1 T1 st (q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & p9 inTARSKIR2 P) & (treeTREES-AK3(T,P,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
sorry

mtheorem trees_a_th_15:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) & q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of domRELAT-1K1 T1 :  True  } implies ( ex r be ElementTREES-1M2-of domRELAT-1K1 T1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & (T with-replacementTREES-2K7(p,T1)).FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
sorry

mtheorem trees_a_th_16:
" for T be DecoratedTreeTREES-2M4 holds  for T1 be DecoratedTreeTREES-2M4 holds  for t be ElementTREES-1M2-of domRELAT-1K1 T holds treeTREES-AK3(T,{TREES-AK2\<^bsub>(domRELAT-1K1 T)\<^esub> t},T1) =FUNCT-1R1 T with-replacementTREES-2K7(t,T1)"
sorry

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve T, T1 for "DecoratedTreeTREES-2M5-of D"
reserve P for " non emptyXBOOLE-0V1\<bar>AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T"
mtheorem trees_a_cl_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "P be  non emptyXBOOLE-0V1\<bar>AntiChain-of-PrefixesTREES-1M6-of domRELAT-1K1 T", "T1 be DecoratedTreeTREES-2M5-of D"
"cluster treeTREES-AK3(T,P,T1) as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "treeTREES-AK3(T,P,T1) be D -valuedRELAT-1V5"
sorry
qed "sorry"

end
