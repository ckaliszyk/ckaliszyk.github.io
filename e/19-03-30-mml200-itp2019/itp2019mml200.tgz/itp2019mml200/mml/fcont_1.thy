theory fcont_1
  imports square_1 rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve x, X, X1, Z, Z1 for "setHIDDENM2"
reserve s, g, r, p, x0, x1, x2 for "RealXREAL-0M1"
reserve s1, s2, q1 for "Real-SequenceSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mdef fcont_1_def_1 (" _ is-continuous-inFCONT-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-continuous-inFCONT-1R1 x0 means
   for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0 implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"..

mtheorem fcont_1_th_1:
" for X be setHIDDENM2 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 X & f is-continuous-inFCONT-1R1 x0 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_2:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 iff ( for s1 be Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
sorry

mtheorem fcont_1_th_3:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 iff ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
sorry

mtheorem fcont_1_th_4:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-continuous-inFCONT-1R1 x0 iff ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1)"
sorry

mtheorem fcont_1_th_5:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-continuous-inFCONT-1R1 x0 iff ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1)"
sorry

mtheorem fcont_1_th_6:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N =XBOOLE-0R4 {SEQ-4K1 x0}) implies f is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_7:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1 is-continuous-inFCONT-1R1 x0) & f2 is-continuous-inFCONT-1R1 x0 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0 & f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0) & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_8:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-continuous-inFCONT-1R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_9:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-continuous-inFCONT-1R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0 & -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_10:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 & f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_11:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1 is-continuous-inFCONT-1R1 x0) & f1 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) & f2 is-continuous-inFCONT-1R1 x0 implies f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fcont_1_th_12:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & f1 is-continuous-inFCONT-1R1 x0) & f2 is-continuous-inFCONT-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
sorry

mdef fcont_1_def_2 ("continuousFCONT-1V1" 70 ) where
"attr continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f.  for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-continuous-inFCONT-1R1 x0)"..

mtheorem fcont_1_th_13:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 iff ( for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1))"
sorry

mtheorem fcont_1_th_14:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 iff ( for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))))"
sorry

mtheorem fcont_1_cl_1:
"cluster constantFUNCT-1V5 also-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_cl_2:
"cluster continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_cl_3:
  mlet "f be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_15:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 iff (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
   sorry

mtheorem fcont_1_th_16:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1"
sorry

mtheorem fcont_1_cl_4:
"cluster emptyXBOOLE-0V1 also-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be emptyXBOOLE-0V1 implies it be continuousFCONT-1V1"
     sorry
qed "sorry"

mtheorem fcont_1_cl_5:
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be trivialZFMISC-1V1\<bar>setHIDDENM2"
"cluster f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_17:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0} be continuousFCONT-1V1"
   sorry

mtheorem fcont_1_cl_6:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_cl_7:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_cl_8:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_18:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_19:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1 implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1) & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1"
sorry

mtheorem fcont_1_cl_9:
  mlet "f be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_20:
" for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_21:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_22:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_23:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_24:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_cl_10:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_25:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be continuousFCONT-1V1 implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_26:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1 implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_27:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds f .FUNCT-1K1 (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 x2)) & ( ex x0 be RealXREAL-0M1 st f is-continuous-inFCONT-1R1 x0) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_28:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1 implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1"
sorry

mtheorem fcont_1_th_29:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1 implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be compactRCOMP-1V1"
sorry

mtheorem fcont_1_th_30:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1 implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f))"
sorry

(*\$N Extreme value theorem*)
mtheorem fcont_1_th_31:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((Y <>HIDDENR2 {}XBOOLE-0K1 & Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1 implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
sorry

mdef fcont_1_def_3 ("LipschitzianFCONT-1V2" 70 ) where
"attr LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f.  ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"..

mtheorem fcont_1_th_32:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 iff ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"
sorry

mtheorem fcont_1_cl_11:
"cluster emptyXBOOLE-0V1 also-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be emptyXBOOLE-0V1 implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_cl_12:
"cluster emptyXBOOLE-0V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem fcont_1_cl_13:
  mlet "f be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_th_33:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2"
sorry

mtheorem fcont_1_cl_14:
  mlet "f1 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_cl_15:
  mlet "f1 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_th_34:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
sorry

mtheorem fcont_1_th_35:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2 implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
sorry

mtheorem fcont_1_cl_16:
  mlet "f1 be boundedSEQ-2V6\<bar>LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be boundedSEQ-2V6\<bar>LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_th_36:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Z1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6 implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be LipschitzianFCONT-1V2"
sorry

mtheorem fcont_1_cl_17:
  mlet "f be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "p be RealXREAL-0M1"
"cluster p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_th_37:
" for X be setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
sorry

mtheorem fcont_1_cl_18:
  mlet "f be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_th_38:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
sorry

mtheorem fcont_1_cl_19:
"cluster constantFUNCT-1V5 also-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

mtheorem fcont_1_cl_20:
  mlet "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
"cluster idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y implies it be LipschitzianFCONT-1V2"
sorry
qed "sorry"

(*\$N Lipschitz continuity*)
mtheorem fcont_1_cl_21:
"cluster LipschitzianFCONT-1V2 also-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be LipschitzianFCONT-1V2 implies it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_39:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {SEQ-4K1 r}) implies f be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_40:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1 x0) implies f be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_41:
" for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1 r *XCMPLX-0K3 x0 +XCMPLX-0K2 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_42:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_43:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_44:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|) implies f be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_45:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_46:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 & ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st p <=XXREAL-0R1 g & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_1_th_47:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
sorry

mdef fcont_1_def_4 ("AffineMapFCONT-1K1'( _ , _ ')" [0,0]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"func AffineMapFCONT-1K1(a,b) \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x be RealXREAL-0M1 holds it1 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) & ( for x be RealXREAL-0M1 holds it2 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem fcont_1_cl_22:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"cluster AffineMapFCONT-1K1(a,b) as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "AffineMapFCONT-1K1(a,b) be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_cl_23:
"cluster continuousFCONT-1V1 for FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem fcont_1_th_48:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 b"
sorry

mtheorem fcont_1_th_49:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 a +XCMPLX-0K2 b"
sorry

mtheorem fcont_1_th_50:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies AffineMapFCONT-1K1(a,b) be one-to-oneFUNCT-1V2"
sorry

mtheorem fcont_1_th_51:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & x <XXREAL-0R3 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <XXREAL-0R3 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
sorry

mtheorem fcont_1_th_52:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & x <XXREAL-0R3 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >XXREAL-0R4 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
sorry

mtheorem fcont_1_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & x <=XXREAL-0R1 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <=XXREAL-0R1 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
sorry

mtheorem fcont_1_th_54:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & x <=XXREAL-0R1 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >=XXREAL-0R2 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
sorry

mtheorem fcont_1_th_55:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) =XBOOLE-0R4 REALNUMBERSK2"
sorry

mtheorem fcont_1_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (AffineMapFCONT-1K1(a,b))\<inverse>FUNCT-1K4 =FUNCT-1R1 AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a)"
sorry

mtheorem fcont_1_th_57:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) =XBOOLE-0R4 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
sorry

end
