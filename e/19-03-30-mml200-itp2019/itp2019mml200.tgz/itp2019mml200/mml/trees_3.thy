theory trees_3
  imports trees_2 finseq_3 square_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve i, k, n for "NatNAT-1M1"
reserve p, q, r, s for "FinSequenceFINSEQ-1M1"
reserve w for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
reserve f for "FunctionFUNCT-1M1"
mlemma trees_3_lm_1:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^FINSEQ-1K8 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
sorry

(*begin*)
mdef trees_3_def_1 ("TreesTREES-3K1" 164 ) where
"func TreesTREES-3K1 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be TreeTREES-1M1"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be TreeTREES-1M1"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be TreeTREES-1M1) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_3_cl_1:
"cluster TreesTREES-3K1 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "TreesTREES-3K1 be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef trees_3_def_2 ("FinTreesTREES-3K2" 164 ) where
"func FinTreesTREES-3K2 \<rightarrow> SubsetSUBSET-1M2-of TreesTREES-3K1 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of TreesTREES-3K1 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of TreesTREES-3K1 holds  for it2 be SubsetSUBSET-1M2-of TreesTREES-3K1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_3_cl_2:
"cluster FinTreesTREES-3K2 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "FinTreesTREES-3K2 be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef trees_3_def_3 ("constituted-TreesTREES-3V1" 70 ) where
"attr constituted-TreesTREES-3V1 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be TreeTREES-1M1)"..

mdef trees_3_def_4 ("constituted-FinTreesTREES-3V2" 70 ) where
"attr constituted-FinTreesTREES-3V2 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"..

mdef trees_3_def_5 ("constituted-DTreesTREES-3V3" 70 ) where
"attr constituted-DTreesTREES-3V3 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be DecoratedTreeTREES-2M4)"..

mtheorem trees_3_th_1:
" for X be setHIDDENM2 holds X be constituted-TreesTREES-3V1 iff X c=TARSKIR1 TreesTREES-3K1"
sorry

mtheorem trees_3_th_2:
" for X be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 iff X c=TARSKIR1 FinTreesTREES-3K2"
sorry

mtheorem trees_3_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1 iff X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1"
sorry

mtheorem trees_3_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1 implies X \\+\\XBOOLE-0K5 Y be constituted-TreesTREES-3V1"
sorry

mtheorem trees_3_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 implies (X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1 & Y /\\XBOOLE-0K3 X be constituted-TreesTREES-3V1) & X \\SUBSET-1K6 Y be constituted-TreesTREES-3V1"
sorry

mtheorem trees_3_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2 iff X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2"
sorry

mtheorem trees_3_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2 implies X \\+\\XBOOLE-0K5 Y be constituted-FinTreesTREES-3V2"
sorry

mtheorem trees_3_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 implies (X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2 & Y /\\XBOOLE-0K3 X be constituted-FinTreesTREES-3V2) & X \\SUBSET-1K6 Y be constituted-FinTreesTREES-3V2"
sorry

mtheorem trees_3_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3 iff X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3"
sorry

mtheorem trees_3_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3 implies X \\+\\XBOOLE-0K5 Y be constituted-DTreesTREES-3V3"
sorry

mtheorem trees_3_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 implies (X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3 & Y /\\XBOOLE-0K3 X be constituted-DTreesTREES-3V3) & X \\SUBSET-1K6 Y be constituted-DTreesTREES-3V3"
sorry

mtheorem trees_3_cl_3:
"cluster emptyXBOOLE-0V1 also-is constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar>constituted-DTreesTREES-3V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar>constituted-DTreesTREES-3V3"
     sorry
qed "sorry"

mtheorem trees_3_th_12:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be constituted-TreesTREES-3V1 iff x be TreeTREES-1M1"
sorry

mtheorem trees_3_th_13:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be constituted-FinTreesTREES-3V2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
sorry

mtheorem trees_3_th_14:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be constituted-DTreesTREES-3V3 iff x be DecoratedTreeTREES-2M4"
sorry

mtheorem trees_3_th_15:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK2 x,y } be constituted-TreesTREES-3V1 iff x be TreeTREES-1M1 & y be TreeTREES-1M1"
sorry

mtheorem trees_3_th_16:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK2 x,y } be constituted-FinTreesTREES-3V2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
sorry

mtheorem trees_3_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK2 x,y } be constituted-DTreesTREES-3V3 iff x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
sorry

mtheorem trees_3_th_18:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 & Y c=TARSKIR1 X implies Y be constituted-TreesTREES-3V1"
   sorry

mtheorem trees_3_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 & Y c=TARSKIR1 X implies Y be constituted-FinTreesTREES-3V2"
   sorry

mtheorem trees_3_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 & Y c=TARSKIR1 X implies Y be constituted-DTreesTREES-3V3"
   sorry

mtheorem trees_3_cl_4:
"cluster finiteFINSET-1V1\<bar>constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be finiteFINSET-1V1\<bar>constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_5:
"cluster finiteFINSET-1V1\<bar>constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be finiteFINSET-1V1\<bar>constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_6:
"cluster constituted-FinTreesTREES-3V2 also-is constituted-TreesTREES-3V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be constituted-FinTreesTREES-3V2 implies it be constituted-TreesTREES-3V1"
     sorry
qed "sorry"

mtheorem trees_3_cl_7:
  mlet "X be constituted-TreesTREES-3V1\<bar>setHIDDENM2"
"cluster note-that constituted-TreesTREES-3V1 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be constituted-TreesTREES-3V1"
    using trees_3_def_3 sorry
qed "sorry"

mtheorem trees_3_cl_8:
  mlet "X be constituted-FinTreesTREES-3V2\<bar>setHIDDENM2"
"cluster note-that constituted-FinTreesTREES-3V2 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be constituted-FinTreesTREES-3V2"
    using trees_3_def_4 sorry
qed "sorry"

mtheorem trees_3_cl_9:
  mlet "X be constituted-DTreesTREES-3V3\<bar>setHIDDENM2"
"cluster note-that constituted-DTreesTREES-3V3 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be constituted-DTreesTREES-3V3"
    using trees_3_def_5 sorry
qed "sorry"

mtheorem trees_3_cl_10:
  mlet "D be constituted-TreesTREES-3V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1 for ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D holds it be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
    using trees_3_def_3 sorry
qed "sorry"

mtheorem trees_3_cl_11:
  mlet "D be constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D holds it be finiteFINSET-1V1"
    using trees_3_def_4 sorry
qed "sorry"

mtheorem trees_3_cl_12:
"cluster constituted-DTreesTREES-3V3 also-is functionalFUNCT-1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be constituted-DTreesTREES-3V3 implies it be functionalFUNCT-1V6"
     sorry
qed "sorry"

mtheorem trees_3_cl_13:
  mlet "D be constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that DecoratedTree-likeTREES-2V3 for ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D holds it be DecoratedTree-likeTREES-2V3"
    using trees_3_def_5 sorry
qed "sorry"

mtheorem trees_3_cl_14:
"cluster TreesTREES-3K1 as-term-is constituted-TreesTREES-3V1"
proof
(*coherence*)
  show "TreesTREES-3K1 be constituted-TreesTREES-3V1"
    using trees_3_def_1 sorry
qed "sorry"

mtheorem trees_3_cl_15:
"cluster FinTreesTREES-3K2 as-term-is constituted-FinTreesTREES-3V2"
proof
(*coherence*)
  show "FinTreesTREES-3K2 be constituted-FinTreesTREES-3V2"
    using trees_3_def_2 sorry
qed "sorry"

mtheorem trees_3_cl_16:
"cluster constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of TreesTREES-3K1"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of TreesTREES-3K1 st it be constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef trees_3_def_6 ("DTree-setTREES-3M1-of  _ " [70]70 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode DTree-setTREES-3M1-of D \<rightarrow>  non emptyXBOOLE-0V1\<bar>setHIDDENM2 means
  (\<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it implies x be DecoratedTreeTREES-2M5-of D)"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it implies x be DecoratedTreeTREES-2M5-of D"
sorry
qed "sorry"

mtheorem trees_3_cl_17:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that constituted-DTreesTREES-3V3 for DTree-setTREES-3M1-of D"
proof
(*coherence*)
  show " for it be DTree-setTREES-3M1-of D holds it be constituted-DTreesTREES-3V3"
    using trees_3_def_6 sorry
qed "sorry"

mtheorem trees_3_cl_18:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1 for DTree-setTREES-3M1-of D"
proof
(*existence*)
  show " ex it be DTree-setTREES-3M1-of D st it be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_19:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
"cluster note-that D -valuedRELAT-1V5 for ElementSUBSET-1M1-of E"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of E holds it be D -valuedRELAT-1V5"
    using trees_3_def_6 sorry
qed "sorry"

abbreviation(input) TREES_3K3("FuncsTREES-3K3'( _ , _ ')" [0,0]228) where
  "FuncsTREES-3K3(T,D) \<equiv> FuncsFUNCT-2K1(T,D)"

mtheorem trees_3_add_1:
  mlet "T be TreeTREES-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(T,D) as-term-is  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(T,D) be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
sorry
qed "sorry"

mtheorem trees_3_cl_20:
  mlet "T be TreeTREES-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that DecoratedTree-likeTREES-2V3 for FunctionFUNCT-2M1-of(T,D)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(T,D) holds it be DecoratedTree-likeTREES-2V3"
    using funct_2_def_1 sorry
qed "sorry"

mdef trees_3_def_7 ("TreesTREES-3K4  _ " [164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func TreesTREES-3K4 D \<rightarrow> DTree-setTREES-3M1-of D means
  \<lambda>it.  for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it"
proof-
  (*existence*)
    show " ex it be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it"
sorry
  (*uniqueness*)
    show " for it1 be DTree-setTREES-3M1-of D holds  for it2 be DTree-setTREES-3M1-of D holds ( for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it1) & ( for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it2) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_3_cl_21:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster TreesTREES-3K4 D as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "TreesTREES-3K4 D be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mdef trees_3_def_8 ("FinTreesTREES-3K5  _ " [164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func FinTreesTREES-3K5 D \<rightarrow> DTree-setTREES-3M1-of D means
  \<lambda>it.  for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it"
proof-
  (*existence*)
    show " ex it be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it"
sorry
  (*uniqueness*)
    show " for it1 be DTree-setTREES-3M1-of D holds  for it2 be DTree-setTREES-3M1-of D holds ( for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it1) & ( for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it2) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_3_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds FinTreesTREES-3K5 D c=TARSKIR1 TreesTREES-3K4 D"
  using trees_3_def_7 sorry

(*begin*)
mdef trees_3_def_9 ("Tree-yieldingTREES-3V4" 70 ) where
"attr Tree-yieldingTREES-3V4 for FunctionFUNCT-1M1 means
  (\<lambda>IT. rngFUNCT-1K2 IT be constituted-TreesTREES-3V1)"..

mdef trees_3_def_10 ("FinTree-yieldingTREES-3V5" 70 ) where
"attr FinTree-yieldingTREES-3V5 for FunctionFUNCT-1M1 means
  (\<lambda>IT. rngFUNCT-1K2 IT be constituted-FinTreesTREES-3V2)"..

mdef trees_3_def_11 ("DTree-yieldingTREES-3V6" 70 ) where
"attr DTree-yieldingTREES-3V6 for FunctionFUNCT-1M1 means
  (\<lambda>IT. rngFUNCT-1K2 IT be constituted-DTreesTREES-3V3)"..

mtheorem trees_3_cl_22:
"cluster emptyXBOOLE-0V1 also-is Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>DTree-yieldingTREES-3V6 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>DTree-yieldingTREES-3V6"
     sorry
qed "sorry"

mtheorem trees_3_th_22:
" for f be FunctionFUNCT-1M1 holds f be Tree-yieldingTREES-3V4 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1)"
sorry

mtheorem trees_3_th_23:
" for f be FunctionFUNCT-1M1 holds f be FinTree-yieldingTREES-3V5 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
sorry

mtheorem trees_3_th_24:
" for f be FunctionFUNCT-1M1 holds f be DTree-yieldingTREES-3V6 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)"
sorry

mtheorem trees_3_th_25:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4 iff p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4"
sorry

mtheorem trees_3_th_26:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5 iff p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5"
sorry

mtheorem trees_3_th_27:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6 iff p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6"
sorry

mtheorem trees_3_th_28:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> be Tree-yieldingTREES-3V4 iff x be TreeTREES-1M1"
sorry

mtheorem trees_3_th_29:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
sorry

mtheorem trees_3_th_30:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> be DTree-yieldingTREES-3V6 iff x be DecoratedTreeTREES-2M4"
sorry

mtheorem trees_3_th_31:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <*FINSEQ-1K11 x,y *> be Tree-yieldingTREES-3V4 iff x be TreeTREES-1M1 & y be TreeTREES-1M1"
sorry

mtheorem trees_3_th_32:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <*FINSEQ-1K11 x,y *> be FinTree-yieldingTREES-3V5 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
sorry

mtheorem trees_3_th_33:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <*FINSEQ-1K11 x,y *> be DTree-yieldingTREES-3V6 iff x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
sorry

mtheorem trees_3_th_34:
" for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i  |->FINSEQ-2K2 x be Tree-yieldingTREES-3V4 iff x be TreeTREES-1M1)"
sorry

mtheorem trees_3_th_35:
" for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i  |->FINSEQ-2K2 x be FinTree-yieldingTREES-3V5 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
sorry

mtheorem trees_3_th_36:
" for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i  |->FINSEQ-2K2 x be DTree-yieldingTREES-3V6 iff x be DecoratedTreeTREES-2M4)"
sorry

mtheorem trees_3_cl_23:
"cluster Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_24:
"cluster DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_25:
"cluster Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_26:
"cluster DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem trees_3_cl_27:
"cluster FinTree-yieldingTREES-3V5 also-is Tree-yieldingTREES-3V4 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be FinTree-yieldingTREES-3V5 implies it be Tree-yieldingTREES-3V4"
     sorry
qed "sorry"

mtheorem trees_3_cl_28:
  mlet "D be constituted-TreesTREES-3V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that Tree-yieldingTREES-3V4 for FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of D holds it be Tree-yieldingTREES-3V4"
sorry
qed "sorry"

mtheorem trees_3_cl_29:
  mlet "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1", "q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is Tree-yieldingTREES-3V4"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4"
    using trees_3_th_25 sorry
qed "sorry"

mtheorem trees_3_cl_30:
  mlet "D be constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that FinTree-yieldingTREES-3V5 for FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of D holds it be FinTree-yieldingTREES-3V5"
sorry
qed "sorry"

mtheorem trees_3_cl_31:
  mlet "p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1", "q be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5"
    using trees_3_th_26 sorry
qed "sorry"

mtheorem trees_3_cl_32:
  mlet "D be constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that DTree-yieldingTREES-3V6 for FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of D holds it be DTree-yieldingTREES-3V6"
sorry
qed "sorry"

mtheorem trees_3_cl_33:
  mlet "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1", "q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is DTree-yieldingTREES-3V6"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6"
    using trees_3_th_27 sorry
qed "sorry"

mtheorem trees_3_cl_34:
  mlet "T be TreeTREES-1M1"
"cluster <*FINSEQ-1K10 T*> as-term-is Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 T*> be Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_28 sorry
qed "sorry"

mtheorem trees_3_cl_35:
  mlet "T be TreeTREES-1M1", "S be TreeTREES-1M1"
"cluster <*FINSEQ-1K11 T,S *> as-term-is Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 T,S *> be Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_31 sorry
qed "sorry"

mtheorem trees_3_cl_36:
  mlet "n be NatNAT-1M1", "T be TreeTREES-1M1"
"cluster n  |->FINSEQ-2K2 T as-term-is Tree-yieldingTREES-3V4"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 T be Tree-yieldingTREES-3V4"
sorry
qed "sorry"

mtheorem trees_3_cl_37:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster <*FINSEQ-1K10 T*> as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "<*FINSEQ-1K10 T*> be FinTree-yieldingTREES-3V5"
    using trees_3_th_29 sorry
qed "sorry"

mtheorem trees_3_cl_38:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1", "S be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster <*FINSEQ-1K11 T,S *> as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "<*FINSEQ-1K11 T,S *> be FinTree-yieldingTREES-3V5"
    using trees_3_th_32 sorry
qed "sorry"

mtheorem trees_3_cl_39:
  mlet "n be NatNAT-1M1", "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster n  |->FINSEQ-2K2 T as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 T be FinTree-yieldingTREES-3V5"
sorry
qed "sorry"

mtheorem trees_3_cl_40:
  mlet "T be DecoratedTreeTREES-2M4"
"cluster <*FINSEQ-1K10 T*> as-term-is DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 T*> be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_30 sorry
qed "sorry"

mtheorem trees_3_cl_41:
  mlet "T be DecoratedTreeTREES-2M4", "S be DecoratedTreeTREES-2M4"
"cluster <*FINSEQ-1K11 T,S *> as-term-is DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 T,S *> be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_33 sorry
qed "sorry"

mtheorem trees_3_cl_42:
  mlet "n be NatNAT-1M1", "T be DecoratedTreeTREES-2M4"
"cluster n  |->FINSEQ-2K2 T as-term-is DTree-yieldingTREES-3V6"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 T be DTree-yieldingTREES-3V6"
sorry
qed "sorry"

mtheorem trees_3_cl_43:
"cluster DTree-yieldingTREES-3V6 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be DTree-yieldingTREES-3V6 implies it be Function-yieldingFUNCOP-1V1"
sorry
qed "sorry"

mtheorem trees_3_th_37:
" for f be DTree-yieldingTREES-3V6\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f & domsFUNCT-6K1 f be Tree-yieldingTREES-3V4"
sorry

mtheorem trees_3_cl_44:
  mlet "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
"cluster domsFUNCT-6K1 p as-term-is Tree-yieldingTREES-3V4\<bar>FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "domsFUNCT-6K1 p be Tree-yieldingTREES-3V4\<bar>FinSequence-likeFINSEQ-1V1"
sorry
qed "sorry"

mtheorem trees_3_th_38:
" for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
sorry

mlemma trees_3_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-2M5-of D holds T be FunctionFUNCT-2M1-of(domRELAT-1K1 T,D)"
sorry

(*begin*)
syntax TREES_3M2 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("DecoratedTreeTREES-3M2-of'( _ , _ ')" [0,0]70)
translations "DecoratedTreeTREES-3M2-of(D,E)" \<rightharpoonup> "DecoratedTreeTREES-2M5-of [:ZFMISC-1K2 D,E :]"

syntax TREES_3M3 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("DTree-setTREES-3M3-of'( _ , _ ')" [0,0]70)
translations "DTree-setTREES-3M3-of(D,E)" \<rightharpoonup> "DTree-setTREES-3M1-of [:ZFMISC-1K2 D,E :]"

mtheorem trees_3_cl_45:
  mlet "T1 be DecoratedTreeTREES-2M4", "T2 be DecoratedTreeTREES-2M4"
"cluster <:FUNCT-3K14 T1,T2 :> as-term-is DecoratedTree-likeTREES-2V3"
proof
(*coherence*)
  show "<:FUNCT-3K14 T1,T2 :> be DecoratedTree-likeTREES-2V3"
sorry
qed "sorry"

mtheorem trees_3_cl_46:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T1 be DecoratedTreeTREES-2M5-of D1", "T2 be DecoratedTreeTREES-2M5-of D2"
"cluster <:FUNCT-3K14 T1,T2 :> as-term-is [:ZFMISC-1K2 D1,D2 :] -valuedRELAT-1V5"
proof
(*coherence*)
  show "<:FUNCT-3K14 T1,T2 :> be [:ZFMISC-1K2 D1,D2 :] -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem trees_3_cl_47:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "f be FunctionFUNCT-2M1-of(D,E)"
"cluster f *FUNCT-1K3 T as-term-is DecoratedTree-likeTREES-2V3"
proof
(*coherence*)
  show "f *FUNCT-1K3 T be DecoratedTree-likeTREES-2V3"
sorry
qed "sorry"

abbreviation(input) TREES_3K6("pr1TREES-3K6'( _ , _ ')" [0,0]228) where
  "pr1TREES-3K6(D1,D2) \<equiv> pr1FUNCT-3K8(D1,D2)"

mtheorem trees_3_add_2:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster pr1FUNCT-3K8(D1,D2) as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D1)"
proof
(*coherence*)
  show "pr1FUNCT-3K8(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D1)"
sorry
qed "sorry"

abbreviation(input) TREES_3K7("pr2TREES-3K7'( _ , _ ')" [0,0]228) where
  "pr2TREES-3K7(D1,D2) \<equiv> pr2FUNCT-3K9(D1,D2)"

mtheorem trees_3_add_3:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster pr2FUNCT-3K9(D1,D2) as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D2)"
proof
(*coherence*)
  show "pr2FUNCT-3K9(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D2)"
sorry
qed "sorry"

mdef trees_3_def_12 (" _ `1TREES-3K8\<^bsub>'( _ , _ ')\<^esub>" [355,0,0]355 ) where
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-3M2-of(D1,D2)"
"func T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> \<rightarrow> DecoratedTreeTREES-2M5-of D1 equals
  pr1TREES-3K6(D1,D2) *FUNCT-1K3 T"
proof-
  (*coherence*)
    show "pr1TREES-3K6(D1,D2) *FUNCT-1K3 T be DecoratedTreeTREES-2M5-of D1"
       sorry
qed "sorry"

mdef trees_3_def_13 (" _ `2TREES-3K9\<^bsub>'( _ , _ ')\<^esub>" [355,0,0]355 ) where
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-3M2-of(D1,D2)"
"func T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> \<rightarrow> DecoratedTreeTREES-2M5-of D2 equals
  pr2TREES-3K7(D1,D2) *FUNCT-1K3 T"
proof-
  (*coherence*)
    show "pr2TREES-3K7(D1,D2) *FUNCT-1K3 T be DecoratedTreeTREES-2M5-of D2"
       sorry
qed "sorry"

mtheorem trees_3_th_39:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-3M2-of(D1,D2) holds  for t be ElementTREES-1M2-of domRELAT-1K1 T holds (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub> =XBOOLE-0R4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t & T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t =XBOOLE-0R4 (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>"
sorry

mtheorem trees_3_th_40:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-3M2-of(D1,D2) holds <:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :> =FUNCT-1R1 T"
sorry

mtheorem trees_3_cl_48:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster LeavesTREES-1K3 T as-term-is finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "LeavesTREES-1K3 T be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

syntax TREES_3M4 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementTREES-3M4\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "ElementTREES-3M4\<^bsub>(T)\<^esub>-of S" \<rightharpoonup> "ElementSUBSET-1M1-of S"

mtheorem trees_3_add_4:
  mlet "T be TreeTREES-1M1", "S be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of T"
"cluster note-that ElementTREES-1M2-of T for ElementSUBSET-1M1-of S"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of S holds it be ElementTREES-1M2-of T"
sorry
qed "sorry"

abbreviation(input) TREES_3M5("LeafTREES-3M5-of  _ " [70]70) where
  "LeafTREES-3M5-of T \<equiv> LeafTREES-1M3-of T"

mtheorem trees_3_add_5:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster note-that ElementTREES-3M4\<^bsub>(T)\<^esub>-of LeavesTREES-1K3 T for LeafTREES-1M3-of T"
proof
(*coherence*)
  show " for it be LeafTREES-1M3-of T holds it be ElementTREES-3M4\<^bsub>(T)\<^esub>-of LeavesTREES-1K3 T"
    using trees_1_def_7 sorry
qed "sorry"

mdef trees_3_def_14 ("T-SubstitutionTREES-3M6-of  _ " [70]70 ) where
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"mode T-SubstitutionTREES-3M6-of T \<rightarrow> TreeTREES-1M1 means
  (\<lambda>it.  for t be ElementTREES-1M2-of it holds t inTARSKIR2 T or ( ex l be LeafTREES-3M5-of T st l is-a-proper-prefix-ofTREES-1R3 t))"
proof-
  (*existence*)
    show " ex it be TreeTREES-1M1 st  for t be ElementTREES-1M2-of it holds t inTARSKIR2 T or ( ex l be LeafTREES-3M5-of T st l is-a-proper-prefix-ofTREES-1R3 t)"
sorry
qed "sorry"

abbreviation(input) TREES_3K10(" _ with-replacementTREES-3K10'( _ , _ ')" [164,0,0]164) where
  "T with-replacementTREES-3K10(t,S) \<equiv> T with-replacementTREES-1K5(t,S)"

mtheorem trees_3_add_6:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1", "t be LeafTREES-3M5-of T", "S be TreeTREES-1M1"
"cluster T with-replacementTREES-1K5(t,S) as-term-is T-SubstitutionTREES-3M6-of T"
proof
(*coherence*)
  show "T with-replacementTREES-1K5(t,S) be T-SubstitutionTREES-3M6-of T"
sorry
qed "sorry"

mtheorem trees_3_cl_49:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster finiteFINSET-1V1 for T-SubstitutionTREES-3M6-of T"
proof
(*existence*)
  show " ex it be T-SubstitutionTREES-3M6-of T st it be finiteFINSET-1V1"
sorry
qed "sorry"

abbreviation(input) TREES_3M7("T-SubstitutionTREES-3M7-of  _ " [70]70) where
  "T-SubstitutionTREES-3M7-of n \<equiv> T-SubstitutionTREES-3M6-of elementary-treeTREES-1K2 n"

mtheorem trees_3_th_41:
" for T be TreeTREES-1M1 holds T be T-SubstitutionTREES-3M7-of 0NUMBERSK6"
sorry

mtheorem trees_3_th_42:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds T1 -levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 T2 -levelTREES-2K2 \<one>\<^sub>M & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 T1 implies T1  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 T2  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) implies T1 c=TARSKIR1 T2"
sorry

mlemma trees_3_lm_3:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
sorry

(*begin*)
mtheorem trees_3_th_43:
" for T be TreeTREES-1M1 holds  for T9 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 LeavesTREES-1K3 T implies T c=TARSKIR1 T with-replacementTREES-1K5(p,T9)"
sorry

mtheorem trees_3_th_44:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 {}XBOOLE-0K1"
sorry

mtheorem trees_3_th_45:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds  for q be ElementTREES-1M2-of domRELAT-1K1 T holds  not p is-a-prefix-ofTREES-1R2 q implies (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
sorry

mtheorem trees_3_th_46:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds  for q be ElementTREES-1M2-of domRELAT-1K1 T9 holds (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q"
sorry

mtheorem trees_3_cl_50:
  mlet "T1 be TreeTREES-1M1", "T2 be TreeTREES-1M1"
"cluster T1 \\/XBOOLE-0K2 T2 as-term-is  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
proof
(*coherence*)
  show "T1 \\/XBOOLE-0K2 T2 be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
     sorry
qed "sorry"

mtheorem trees_3_th_47:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T1 \\/XBOOLE-0K2 T2 holds ((p inTARSKIR2 T1 & p inTARSKIR2 T2 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p) & ( not p inTARSKIR2 T1 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T2  |TREES-1K4 p)) & ( not p inTARSKIR2 T2 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p)"
sorry

mdef trees_3_def_15 ("treeTREES-3K11  _ " [164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1"
"assume p be Tree-yieldingTREES-3V4 func treeTREES-3K11 p \<rightarrow> TreeTREES-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
proof-
  (*existence*)
    show "p be Tree-yieldingTREES-3V4 implies ( ex it be TreeTREES-1M1 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q))"
sorry
  (*uniqueness*)
    show "p be Tree-yieldingTREES-3V4 implies ( for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef trees_3_def_16 ("^TREES-3K12  _ " [164]164 ) where
  mlet "T be TreeTREES-1M1"
"func ^TREES-3K12 T \<rightarrow> TreeTREES-1M1 equals
  treeTREES-3K11 (<*FINSEQ-1K10 T*>)"
proof-
  (*coherence*)
    show "treeTREES-3K11 (<*FINSEQ-1K10 T*>) be TreeTREES-1M1"
       sorry
qed "sorry"

mdef trees_3_def_17 ("treeTREES-3K13'( _ , _ ')" [0,0]164 ) where
  mlet "T1 be TreeTREES-1M1", "T2 be TreeTREES-1M1"
"func treeTREES-3K13(T1,T2) \<rightarrow> TreeTREES-1M1 equals
  treeTREES-3K11 (<*FINSEQ-1K11 T1,T2 *>)"
proof-
  (*coherence*)
    show "treeTREES-3K11 (<*FINSEQ-1K11 T1,T2 *>) be TreeTREES-1M1"
       sorry
qed "sorry"

mtheorem trees_3_th_48:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies ((<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p iff n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem trees_3_th_49:
" for p be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p } & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem trees_3_th_50:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 p =TREES-2R1 treeTREES-3K11 q implies p =FINSEQ-1R1 q"
sorry

mtheorem trees_3_th_51:
" for p be FinSequenceFINSEQ-1M1 holds  for p1 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for p2 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for T be TreeTREES-1M1 holds p inTARSKIR2 T iff (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K11 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)"
sorry

mtheorem trees_3_th_52:
"treeTREES-3K11 {}XBOOLE-0K1 =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
sorry

mtheorem trees_3_th_53:
" for p be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 treeTREES-3K11 p"
sorry

mtheorem trees_3_th_54:
" for i be NatNAT-1M1 holds elementary-treeTREES-1K2 i =TREES-2R1 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
sorry

mtheorem trees_3_th_55:
" for T be TreeTREES-1M1 holds  for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) =TREES-2R1 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
sorry

mtheorem trees_3_th_56:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 elementary-treeTREES-1K2 (0NUMBERSK6)*>)) =TREES-2R1 treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem trees_3_th_57:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) =TREES-2R1 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
sorry

abbreviation(input) TREES_3K14("<*TREES-3K14  _ *>" [0]164) where
  "<*TREES-3K14 n*> \<equiv> <*FINSEQ-1K6 n*>"

mtheorem trees_3_add_7:
  mlet "n be NatNAT-1M1"
"cluster <*FINSEQ-1K6 n*> as-term-is FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof
(*coherence*)
  show "<*FINSEQ-1K6 n*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
sorry
qed "sorry"

mtheorem trees_3_th_58:
" for T be TreeTREES-1M1 holds ^TREES-3K12 T =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
sorry

mtheorem trees_3_th_59:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds treeTREES-3K13(T1,T2) =TREES-2R1 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
sorry

mtheorem trees_3_cl_51:
  mlet "p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
"cluster treeTREES-3K11 p as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "treeTREES-3K11 p be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem trees_3_cl_52:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster ^TREES-3K12 T as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "^TREES-3K12 T be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem trees_3_cl_53:
  mlet "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1", "T2 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster treeTREES-3K13(T1,T2) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "treeTREES-3K13(T1,T2) be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem trees_3_th_60:
" for T be TreeTREES-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 ^TREES-3K12 T iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p)"
sorry

mtheorem trees_3_th_61:
" for T be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T iff (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 ^TREES-3K12 T"
sorry

mtheorem trees_3_th_62:
" for T be TreeTREES-1M1 holds elementary-treeTREES-1K2 \<one>\<^sub>M c=TARSKIR1 ^TREES-3K12 T"
sorry

mtheorem trees_3_th_63:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds T1 c=TARSKIR1 T2 implies ^TREES-3K12 T1 c=TARSKIR1 ^TREES-3K12 T2"
sorry

mtheorem trees_3_th_64:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds ^TREES-3K12 T1 =TREES-2R1 ^TREES-3K12 T2 implies T1 =TREES-2R1 T2"
sorry

mtheorem trees_3_th_65:
" for T be TreeTREES-1M1 holds (^TREES-3K12 T) |TREES-1K4 (<*TREES-3K14 0NUMBERSK6 *>) =TREES-2R1 T"
sorry

mtheorem trees_3_th_66:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds (^TREES-3K12 T1)with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T2) =TREES-2R1 ^TREES-3K12 T2"
sorry

mtheorem trees_3_th_67:
"^TREES-3K12 elementary-treeTREES-1K2 (0NUMBERSK6) =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M"
sorry

mtheorem trees_3_th_68:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 treeTREES-3K13(T1,T2) iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p or p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p)"
sorry

mtheorem trees_3_th_69:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T1 iff (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)"
sorry

mtheorem trees_3_th_70:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T2 iff (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)"
sorry

mtheorem trees_3_th_71:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds elementary-treeTREES-1K2 \<two>\<^sub>M c=TARSKIR1 treeTREES-3K13(T1,T2)"
sorry

mtheorem trees_3_th_72:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds T1 c=TARSKIR1 W1 & T2 c=TARSKIR1 W2 implies treeTREES-3K13(T1,T2) c=TARSKIR1 treeTREES-3K13(W1,W2)"
sorry

mtheorem trees_3_th_73:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds treeTREES-3K13(T1,T2) =TREES-2R1 treeTREES-3K13(W1,W2) implies T1 =TREES-2R1 W1 & T2 =TREES-2R1 W2"
sorry

mtheorem trees_3_th_74:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds (treeTREES-3K13(T1,T2)) |TREES-1K4 (<*TREES-3K14 0NUMBERSK6 *>) =TREES-2R1 T1 & (treeTREES-3K13(T1,T2)) |TREES-1K4 (<*TREES-3K14 \<one>\<^sub>M*>) =TREES-2R1 T2"
sorry

mtheorem trees_3_th_75:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds (treeTREES-3K13(T1,T2))with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T) =TREES-2R1 treeTREES-3K13(T,T2) & (treeTREES-3K13(T1,T2))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T) =TREES-2R1 treeTREES-3K13(T1,T)"
sorry

mtheorem trees_3_th_76:
"treeTREES-3K13(elementary-treeTREES-1K2 (0NUMBERSK6),elementary-treeTREES-1K2 (0NUMBERSK6)) =TREES-2R1 elementary-treeTREES-1K2 \<two>\<^sub>M"
sorry

reserve w for "FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
mtheorem trees_3_th_77:
" for n be NatNAT-1M1 holds  for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds ( for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t <=XXREAL-0R1 n) implies heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem trees_3_th_78:
" for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds  for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 (treeTREES-3K11 w) >XXREAL-0R4 heightTREES-1K6 t"
sorry

mtheorem trees_3_th_79:
" for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds  for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w & ( for t9 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t9 inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t9 <=XXREAL-0R1 heightTREES-1K6 t) implies heightTREES-1K6 (treeTREES-3K11 w) =XBOOLE-0R4 heightTREES-1K6 t +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem trees_3_th_80:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 (^TREES-3K12 T) =XBOOLE-0R4 heightTREES-1K6 T +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem trees_3_th_81:
" for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T2 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 (treeTREES-3K13(T1,T2)) =XBOOLE-0R4 maxXXREAL-0K5(heightTREES-1K6 T1,heightTREES-1K6 T2) +NAT-1K1 \<one>\<^sub>M"
sorry

(*begin*)
mtheorem trees_3_cl_54:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "t be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
"cluster domRELAT-1K1 t as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "domRELAT-1K1 t be finiteFINSET-1V1"
    using trees_3_def_8 sorry
qed "sorry"

mdef trees_3_def_18 ("rootsTREES-3K15  _ " [164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1"
"assume p be DTree-yieldingTREES-3V6 func rootsTREES-3K15 p \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))"
proof-
  (*existence*)
    show "p be DTree-yieldingTREES-3V6 implies ( ex it be FinSequenceFINSEQ-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1)))"
sorry
  (*uniqueness*)
    show "p be DTree-yieldingTREES-3V6 implies ( for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it1 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))) & (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it2 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

end
