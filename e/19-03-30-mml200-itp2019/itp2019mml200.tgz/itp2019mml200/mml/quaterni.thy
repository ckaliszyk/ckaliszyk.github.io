theory quaterni
  imports arytm_0 series_3 funct_7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, x, y, w, z, x1, x2, x3, x4, X for "setHIDDENM2"
reserve A for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mdef quaterni_def_1 ("QUATERNIONQUATERNIK1" 164 ) where
"func QUATERNIONQUATERNIK1 \<rightarrow> setHIDDENM2 equals
  (FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }))\\/XBOOLE-0K2 COMPLEXNUMBERSK3"
proof-
  (*coherence*)
    show "(FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }))\\/XBOOLE-0K2 COMPLEXNUMBERSK3 be setHIDDENM2"
       sorry
qed "sorry"

mdef quaterni_def_2 ("quaternionQUATERNIV1" 70 ) where
"attr quaternionQUATERNIV1 for NumberORDINAL1M1 means
  (\<lambda>x. x inHIDDENR3 QUATERNIONQUATERNIK1)"..

mtheorem quaterni_cl_1:
"cluster QUATERNIONQUATERNIK1 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "QUATERNIONQUATERNIK1 be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem quaterni_cl_2:
"cluster quaternionQUATERNIV1 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be quaternionQUATERNIV1"
sorry
qed "sorry"

syntax QUATERNIM1 :: "Ty" ("QuaternionQUATERNIM1" 70)
translations "QuaternionQUATERNIM1" \<rightharpoonup> "quaternionQUATERNIV1\<bar>NumberORDINAL1M1"

(*\$CD*)
(*\$CT 4*)
mlemma quaterni_lm_1:
"(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)are-mutually-distinctZFMISC-1R2"
   sorry

mtheorem quaterni_th_5:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for X be setHIDDENM2 holds {ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X iff ((x1 inTARSKIR2 X & x2 inTARSKIR2 X) & x3 inTARSKIR2 X) & x4 inTARSKIR2 X"
sorry

syntax QUATERNIK2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("'( _ , _ , _ , _ ')-->QUATERNIK2\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]116)
translations "(x,y,w,z)-->QUATERNIK2\<^bsub>(A)\<^esub>(a,b,c,d)" \<rightharpoonup> "(x,y,w,z)-->FUNCT-4K12(a,b,c,d)"

mtheorem quaterni_add_1:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be setHIDDENM2", "y be setHIDDENM2", "w be setHIDDENM2", "z be setHIDDENM2", "a be ElementSUBSET-1M1-of A", "b be ElementSUBSET-1M1-of A", "c be ElementSUBSET-1M1-of A", "d be ElementSUBSET-1M1-of A"
"cluster (x,y,w,z)-->FUNCT-4K12(a,b,c,d) as-term-is FunctionFUNCT-2M1-of({ENUMSET1K2 x,y,w,z },A)"
proof
(*coherence*)
  show "(x,y,w,z)-->FUNCT-4K12(a,b,c,d) be FunctionFUNCT-2M1-of({ENUMSET1K2 x,y,w,z },A)"
sorry
qed "sorry"

mdef quaterni_def_4 ("<j>QUATERNIK3" 164 ) where
"func <j>QUATERNIK3 \<rightarrow> NumberORDINAL1M1 equals
  (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6)"
proof-
  (*coherence*)
    show "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef quaterni_def_5 ("<k>QUATERNIK4" 164 ) where
"func <k>QUATERNIK4 \<rightarrow> NumberORDINAL1M1 equals
  (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M)"
proof-
  (*coherence*)
    show "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M) be NumberORDINAL1M1"
       sorry
qed "sorry"

mtheorem quaterni_cl_3:
"cluster <i>XCMPLX-0K1 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "<i>XCMPLX-0K1 be quaternionQUATERNIV1"
sorry
qed "sorry"

mtheorem quaterni_cl_4:
"cluster <j>QUATERNIK3 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "<j>QUATERNIK3 be quaternionQUATERNIV1"
sorry
qed "sorry"

mtheorem quaterni_cl_5:
"cluster <k>QUATERNIK4 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "<k>QUATERNIK4 be quaternionQUATERNIV1"
sorry
qed "sorry"

mtheorem quaterni_cl_6:
"cluster note-that quaternionQUATERNIV1 for ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds it be quaternionQUATERNIV1"
     sorry
qed "sorry"

mdef quaterni_def_6 ("[*QUATERNIK5 _ , _ , _ , _ *]" [0,0,0,0]164 ) where
  mlet "x be RealXREAL-0M1", "y be RealXREAL-0M1", "w be RealXREAL-0M1", "z be RealXREAL-0M1"
"func [*QUATERNIK5 x,y,w,z *] \<rightarrow> ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 means
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *] if w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 otherwise \<lambda>it. it =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)"
proof-
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds  True "
       sorry
  (*existence*)
    show "(w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *])) & ( not (w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6) implies ( ex it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st it =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)))"
sorry
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds  for it2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds (w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies (( ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it1 =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]) & ( ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it2 =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]) implies it1 =HIDDENR1 it2)) & ( not (w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6) implies (it1 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z) & it2 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z) implies it1 =HIDDENR1 it2))"
       sorry
qed "sorry"

mlemma quaterni_lm_2:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x,y *]"
sorry

(*\$CT*)
mtheorem quaterni_th_7:
" for g be QuaternionQUATERNIM1 holds  ex r be RealXREAL-0M1 st  ex s be RealXREAL-0M1 st  ex t be RealXREAL-0M1 st  ex u be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,s,t,u *]"
sorry

reserve i, j, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve a, b, c, d for "RealXREAL-0M1"
reserve y, r, s, x, t, w for "ElementSUBSET-1M1-of RAT+ARYTM-3K5"
(*\$CT*)
mlemma quaterni_lm_3:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] =HIDDENR1 {TARSKIK1 z} implies z =HIDDENR1 {TARSKIK1 x} & x =HIDDENR1 y"
sorry

mtheorem quaterni_th_9:
" for A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 holds ( ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t inTARSKIR2 A & t <>HIDDENR2 {}ARYTM-3K12) & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A) implies ( ex r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r5 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (((((((((((((r1 inTARSKIR2 A & r2 inTARSKIR2 A) & r3 inTARSKIR2 A) & r4 inTARSKIR2 A) & r5 inTARSKIR2 A) & r1 <>HIDDENR2 r2) & r1 <>HIDDENR2 r3) & r1 <>HIDDENR2 r4) & r1 <>HIDDENR2 r5) & r2 <>HIDDENR2 r3) & r2 <>HIDDENR2 r4) & r2 <>HIDDENR2 r5) & r3 <>HIDDENR2 r4) & r3 <>HIDDENR2 r5) & r4 <>HIDDENR2 r5)"
sorry

mlemma quaterni_lm_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 REALNUMBERSK2"
sorry

mtheorem quaterni_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 COMPLEXNUMBERSK3"
sorry

(*\$CT*)
mtheorem quaterni_th_12:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds [*QUATERNIK5 x1,x2,x3,x4 *] =XBOOLE-0R4 [*QUATERNIK5 y1,y2,y3,y4 *] implies ((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
sorry

mdef quaterni_def_7 (" _ +QUATERNIK6  _ " [132,132]132 ) where
  mlet "x be QuaternionQUATERNIM1", "y be QuaternionQUATERNIM1"
"func x +QUATERNIK6 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it1 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) & ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it2 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem QUATERNIK6_commutativity:
" for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds x +QUATERNIK6 y =HIDDENR1 y +QUATERNIK6 x"
sorry

mlemma quaterni_lm_5:
"0NUMBERSK6 =XBOOLE-0R4 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
sorry

mdef quaterni_def_8 ("-QUATERNIK7  _ " [132]132 ) where
  mlet "z be QuaternionQUATERNIM1"
"func -QUATERNIK7 z \<rightarrow> QuaternionQUATERNIM1 means
  \<lambda>it. z +QUATERNIK6 it =HIDDENR1 0NUMBERSK6"
proof-
  (*existence*)
    show " ex it be QuaternionQUATERNIM1 st z +QUATERNIK6 it =HIDDENR1 0NUMBERSK6"
sorry
  (*uniqueness*)
    show " for it1 be QuaternionQUATERNIM1 holds  for it2 be QuaternionQUATERNIM1 holds z +QUATERNIK6 it1 =HIDDENR1 0NUMBERSK6 & z +QUATERNIK6 it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem QUATERNIK7_involutiveness:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK7 (-QUATERNIK7 z) =HIDDENR1 z"
sorry

mdef quaterni_def_9 (" _ -QUATERNIK8  _ " [132,132]132 ) where
  mlet "x be QuaternionQUATERNIM1", "y be QuaternionQUATERNIM1"
"func x -QUATERNIK8 y \<rightarrow> NumberORDINAL1M1 equals
  x +QUATERNIK6 (-QUATERNIK7 y)"
proof-
  (*coherence*)
    show "x +QUATERNIK6 (-QUATERNIK7 y) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef quaterni_def_10 (" _ *QUATERNIK9  _ " [164,164]164 ) where
  mlet "x be QuaternionQUATERNIM1", "y be QuaternionQUATERNIM1"
"func x *QUATERNIK9 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it1 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) & ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it2 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem quaterni_cl_7:
  mlet "z be QuaternionQUATERNIM1", "z9 be QuaternionQUATERNIM1"
"cluster z +QUATERNIK6 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "z +QUATERNIK6 z9 be quaternionQUATERNIV1"
sorry
qed "sorry"

mtheorem quaterni_cl_8:
  mlet "z be QuaternionQUATERNIM1", "z9 be QuaternionQUATERNIM1"
"cluster z *QUATERNIK9 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "z *QUATERNIK9 z9 be quaternionQUATERNIV1"
sorry
qed "sorry"

abbreviation(input) QUATERNIK10("<j>QUATERNIK10" 164) where
  "<j>QUATERNIK10 \<equiv> <j>QUATERNIK3"

mtheorem quaterni_def_11:
"redefine func <j>QUATERNIK10 \<rightarrow> ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 equals
  [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6 *]"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds it =HIDDENR1 <j>QUATERNIK10 iff it =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6 *]"
    using quaterni_def_6 sorry
qed "sorry"

mtheorem quaterni_add_2:
"cluster <j>QUATERNIK3 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "<j>QUATERNIK3 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

abbreviation(input) QUATERNIK11("<k>QUATERNIK11" 164) where
  "<k>QUATERNIK11 \<equiv> <k>QUATERNIK4"

mtheorem quaterni_def_12:
"redefine func <k>QUATERNIK11 \<rightarrow> ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 equals
  [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M *]"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds it =HIDDENR1 <k>QUATERNIK11 iff it =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M *]"
    using quaterni_def_6 sorry
qed "sorry"

mtheorem quaterni_add_3:
"cluster <k>QUATERNIK4 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "<k>QUATERNIK4 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mtheorem quaterni_th_13:
"(<i>XCMPLX-0K1)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem quaterni_th_14:
"(<j>QUATERNIK10)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem quaterni_th_15:
"(<k>QUATERNIK11)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem quaterni_th_16:
"(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 <k>QUATERNIK11"
sorry

mtheorem quaterni_th_17:
"(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 <i>XCMPLX-0K1"
sorry

mtheorem quaterni_th_18:
"(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 <j>QUATERNIK10"
sorry

mtheorem quaterni_th_19:
"(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 -QUATERNIK7 (<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1)"
sorry

mtheorem quaterni_th_20:
"(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 -QUATERNIK7 (<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10)"
sorry

mtheorem quaterni_th_21:
"(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 -QUATERNIK7 (<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11)"
sorry

mdef quaterni_def_13 ("ReaQUATERNIK12  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func ReaQUATERNIK12 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ReCOMPLEX1K3 z9 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ReCOMPLEX1K3 z9)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)))"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it1 =HIDDENR1 ReCOMPLEX1K3 z9) & ( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it2 =HIDDENR1 ReCOMPLEX1K3 z9) implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mdef quaterni_def_14 ("Im1QUATERNIK13  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func Im1QUATERNIK13 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ImCOMPLEX1K4 z9 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ImCOMPLEX1K4 z9)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it1 =HIDDENR1 ImCOMPLEX1K4 z9) & ( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it2 =HIDDENR1 ImCOMPLEX1K4 z9) implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mdef quaterni_def_15 ("Im2QUATERNIK14  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func Im2QUATERNIK14 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it. it =HIDDENR1 0NUMBERSK6 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st it =HIDDENR1 0NUMBERSK6)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mdef quaterni_def_16 ("Im3QUATERNIK15  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func Im3QUATERNIK15 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it. it =HIDDENR1 0NUMBERSK6 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st it =HIDDENR1 0NUMBERSK6)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mtheorem quaterni_cl_9:
  mlet "z be QuaternionQUATERNIM1"
"cluster ReaQUATERNIK12 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "ReaQUATERNIK12 z be realXREAL-0V1"
sorry
qed "sorry"

mtheorem quaterni_cl_10:
  mlet "z be QuaternionQUATERNIM1"
"cluster Im1QUATERNIK13 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Im1QUATERNIK13 z be realXREAL-0V1"
sorry
qed "sorry"

mtheorem quaterni_cl_11:
  mlet "z be QuaternionQUATERNIM1"
"cluster Im2QUATERNIK14 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Im2QUATERNIK14 z be realXREAL-0V1"
sorry
qed "sorry"

mtheorem quaterni_cl_12:
  mlet "z be QuaternionQUATERNIM1"
"cluster Im3QUATERNIK15 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Im3QUATERNIK15 z be realXREAL-0V1"
sorry
qed "sorry"

mtheorem quaterni_th_22:
" for f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) holds  ex a be RealXREAL-0M1 st  ex b be RealXREAL-0M1 st  ex c be RealXREAL-0M1 st  ex d be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d)"
sorry

mlemma quaterni_lm_6:
" for a be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b be ElementSUBSET-1M1-of REALNUMBERSK2 holds ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a & ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
sorry

mlemma quaterni_lm_7:
" for z be ComplexXCMPLX-0M1 holds [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =COMPLEX1R1 z"
sorry

mtheorem quaterni_th_23:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a & Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b) & Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c) & Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
sorry

reserve z, z1, z2, z3, z4 for "QuaternionQUATERNIM1"
mtheorem quaterni_th_24:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
sorry

mtheorem quaterni_th_25:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z1 =COMPLEX1R1 ReaQUATERNIK12 z2 & Im1QUATERNIK13 z1 =COMPLEX1R1 Im1QUATERNIK13 z2) & Im2QUATERNIK14 z1 =COMPLEX1R1 Im2QUATERNIK14 z2) & Im3QUATERNIK15 z1 =COMPLEX1R1 Im3QUATERNIK15 z2 implies z1 =HIDDENR1 z2"
sorry

mdef quaterni_def_17 ("0qQUATERNIK16" 164 ) where
"func 0qQUATERNIK16 \<rightarrow> QuaternionQUATERNIM1 equals
  0NUMBERSK6"
proof-
  (*coherence*)
    show "0NUMBERSK6 be QuaternionQUATERNIM1"
      using quaterni_lm_5 sorry
qed "sorry"

mdef quaterni_def_18 ("1qQUATERNIK17" 164 ) where
"func 1qQUATERNIK17 \<rightarrow> QuaternionQUATERNIM1 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be QuaternionQUATERNIM1"
sorry
qed "sorry"

mlemma quaterni_lm_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies ((a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6) & c =COMPLEX1R1 0NUMBERSK6) & d =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_26:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0qQUATERNIK16"
sorry

mtheorem quaterni_th_27:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 0NUMBERSK6 implies (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_28:
" for z be QuaternionQUATERNIM1 holds (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0qQUATERNIK16"
sorry

mtheorem quaterni_th_29:
"((ReaQUATERNIK12 (1qQUATERNIK17) =COMPLEX1R1 \<one>\<^sub>M & Im1QUATERNIK13 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_30:
"((ReaQUATERNIK12 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<i>XCMPLX-0K1) =COMPLEX1R1 \<one>\<^sub>M) & Im2QUATERNIK14 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_31:
"((((((ReaQUATERNIK12 (<j>QUATERNIK10) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<j>QUATERNIK10) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<j>QUATERNIK10) =COMPLEX1R1 \<one>\<^sub>M) & Im3QUATERNIK15 (<j>QUATERNIK10) =COMPLEX1R1 0NUMBERSK6) & ReaQUATERNIK12 (<k>QUATERNIK11) =COMPLEX1R1 0NUMBERSK6) & Im1QUATERNIK13 (<k>QUATERNIK11) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<k>QUATERNIK11) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<k>QUATERNIK11) =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_23 sorry

mlemma quaterni_lm_9:
" for m be QuaternionQUATERNIM1 holds  for n be QuaternionQUATERNIM1 holds  for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z =HIDDENR1 ((m +QUATERNIK6 n)+QUATERNIK6 x)+QUATERNIK6 y implies ((ReaQUATERNIK12 z =COMPLEX1R1 ((ReaQUATERNIK12 m +XCMPLX-0K2 ReaQUATERNIK12 n)+XCMPLX-0K2 ReaQUATERNIK12 x)+XCMPLX-0K2 ReaQUATERNIK12 y & Im1QUATERNIK13 z =COMPLEX1R1 ((Im1QUATERNIK13 m +XCMPLX-0K2 Im1QUATERNIK13 n)+XCMPLX-0K2 Im1QUATERNIK13 x)+XCMPLX-0K2 Im1QUATERNIK13 y) & Im2QUATERNIK14 z =COMPLEX1R1 ((Im2QUATERNIK14 m +XCMPLX-0K2 Im2QUATERNIK14 n)+XCMPLX-0K2 Im2QUATERNIK14 x)+XCMPLX-0K2 Im2QUATERNIK14 y) & Im3QUATERNIK15 z =COMPLEX1R1 ((Im3QUATERNIK15 m +XCMPLX-0K2 Im3QUATERNIK15 n)+XCMPLX-0K2 Im3QUATERNIK15 x)+XCMPLX-0K2 Im3QUATERNIK15 y"
sorry

mlemma quaterni_lm_10:
" for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z =HIDDENR1 x +QUATERNIK6 y implies ((ReaQUATERNIK12 z =COMPLEX1R1 ReaQUATERNIK12 x +XCMPLX-0K2 ReaQUATERNIK12 y & Im1QUATERNIK13 z =COMPLEX1R1 Im1QUATERNIK13 x +XCMPLX-0K2 Im1QUATERNIK13 y) & Im2QUATERNIK14 z =COMPLEX1R1 Im2QUATERNIK14 x +XCMPLX-0K2 Im2QUATERNIK14 y) & Im3QUATERNIK15 z =COMPLEX1R1 Im3QUATERNIK15 x +XCMPLX-0K2 Im3QUATERNIK15 y"
sorry

mlemma quaterni_lm_11:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK6 z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
sorry

mlemma quaterni_lm_12:
" for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z =HIDDENR1 x *QUATERNIK9 y implies ((ReaQUATERNIK12 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (ReaQUATERNIK12 y) -XCMPLX-0K6 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im1QUATERNIK13 y))-XCMPLX-0K6 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im2QUATERNIK14 y))-XCMPLX-0K6 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im3QUATERNIK15 y) & Im1QUATERNIK13 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im1QUATERNIK13 y) +XCMPLX-0K2 (Im1QUATERNIK13 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im3QUATERNIK15 y))-XCMPLX-0K6 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im2QUATERNIK14 y)) & Im2QUATERNIK14 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im2QUATERNIK14 y) +XCMPLX-0K2 (Im2QUATERNIK14 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im1QUATERNIK13 y))-XCMPLX-0K6 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im3QUATERNIK15 y)) & Im3QUATERNIK15 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im3QUATERNIK15 y) +XCMPLX-0K2 (Im3QUATERNIK15 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im2QUATERNIK14 y))-XCMPLX-0K6 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im1QUATERNIK13 y)"
sorry

mlemma quaterni_lm_13:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  for z3 be QuaternionQUATERNIM1 holds  for z4 be QuaternionQUATERNIM1 holds ((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4 =HIDDENR1 [*QUATERNIK5 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4,((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4,((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4,((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4 *]"
sorry

mlemma quaterni_lm_14:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK9 z2 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
sorry

mlemma quaterni_lm_15:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
sorry

mtheorem quaterni_th_32:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  for z3 be QuaternionQUATERNIM1 holds  for z4 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4 & Im1QUATERNIK13 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4) & Im2QUATERNIK14 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4) & Im3QUATERNIK15 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4"
sorry

reserve x for "RealXREAL-0M1"
mlemma quaterni_lm_16:
" for z be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z =HIDDENR1 x implies ((ReaQUATERNIK12 z =COMPLEX1R1 x & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_33:
" for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 x) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_34:
" for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 x) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_35:
" for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 x"
sorry

mdef quaterni_def_19 (" _ +QUATERNIK18  _ " [132,132]132 ) where
  mlet "x be RealXREAL-0M1", "y be QuaternionQUATERNIM1"
"func x +QUATERNIK18 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it1 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) & ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it2 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef quaterni_def_20 (" _ -QUATERNIK19  _ " [132,132]132 ) where
  mlet "x be RealXREAL-0M1", "y be QuaternionQUATERNIM1"
"func x -QUATERNIK19 y \<rightarrow> NumberORDINAL1M1 equals
  x +QUATERNIK18 (-QUATERNIK7 y)"
proof-
  (*coherence*)
    show "x +QUATERNIK18 (-QUATERNIK7 y) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef quaterni_def_21 (" _ *QUATERNIK20  _ " [164,164]164 ) where
  mlet "x be RealXREAL-0M1", "y be QuaternionQUATERNIM1"
"func x *QUATERNIK20 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
sorry
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it1 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) & ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it2 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem quaterni_cl_13:
  mlet "x be RealXREAL-0M1", "z9 be QuaternionQUATERNIM1"
"cluster x +QUATERNIK18 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "x +QUATERNIK18 z9 be quaternionQUATERNIV1"
sorry
qed "sorry"

mtheorem quaterni_cl_14:
  mlet "x be RealXREAL-0M1", "z9 be QuaternionQUATERNIM1"
"cluster x *QUATERNIK20 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "x *QUATERNIK20 z9 be quaternionQUATERNIV1"
sorry
qed "sorry"

mtheorem quaterni_cl_15:
  mlet "x be RealXREAL-0M1", "z9 be QuaternionQUATERNIM1"
"cluster x -QUATERNIK19 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "x -QUATERNIK19 z9 be quaternionQUATERNIV1"
     sorry
qed "sorry"

mlemma quaterni_lm_17:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds [*QUATERNIK5 x,y,z,w *] =HIDDENR1 ((x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK6 z *QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK6 w *QUATERNIK20 (<k>QUATERNIK11)"
sorry

abbreviation(input) QUATERNIK21(" _ +QUATERNIK21  _ " [132,132]132) where
  "z1 +QUATERNIK21 z2 \<equiv> z1 +QUATERNIK6 z2"

mtheorem quaterni_add_4:
  mlet "z1 be QuaternionQUATERNIM1", "z2 be QuaternionQUATERNIM1"
"cluster z1 +QUATERNIK6 z2 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z1 +QUATERNIK6 z2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_18:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK21 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
sorry

mtheorem quaterni_th_36:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 +QUATERNIK21 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2"
sorry

abbreviation(input) QUATERNIK22(" _ *QUATERNIK22  _ " [164,164]164) where
  "z1 *QUATERNIK22 z2 \<equiv> z1 *QUATERNIK9 z2"

mtheorem quaterni_add_5:
  mlet "z1 be QuaternionQUATERNIM1", "z2 be QuaternionQUATERNIM1"
"cluster z1 *QUATERNIK9 z2 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z1 *QUATERNIK9 z2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_19:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK22 z2 =XBOOLE-0R4 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
sorry

mtheorem quaterni_th_37:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 ((ReaQUATERNIK12 z +QUATERNIK18 (Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
sorry

mlemma quaterni_lm_20:
" for c be QuaternionQUATERNIM1 holds c +QUATERNIK21 0qQUATERNIK16 =HIDDENR1 c"
sorry

mlemma quaterni_lm_21:
"((0NUMBERSK6)*QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 0NUMBERSK6 & (0NUMBERSK6)*QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 0NUMBERSK6) & (0NUMBERSK6)*QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 0NUMBERSK6"
sorry

mtheorem quaterni_th_38:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((((Im1QUATERNIK13 z1 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 z2 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z1 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z2 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z1 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z2 =COMPLEX1R1 0NUMBERSK6 implies ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
sorry

mtheorem quaterni_th_39:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z1 =COMPLEX1R1 0NUMBERSK6 & ReaQUATERNIK12 z2 =COMPLEX1R1 0NUMBERSK6 implies ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((-XCMPLX-0K4 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
sorry

mtheorem quaterni_th_40:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 -XCMPLX-0K6 (Im1QUATERNIK13 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im2QUATERNIK14 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im1QUATERNIK13 z))) & Im2QUATERNIK14 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))) & Im3QUATERNIK15 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im3QUATERNIK15 z))"
sorry

abbreviation(input) QUATERNIK23("-QUATERNIK23  _ " [132]132) where
  "-QUATERNIK23 z \<equiv> -QUATERNIK7 z"

mtheorem quaterni_add_6:
  mlet "z be QuaternionQUATERNIM1"
"cluster -QUATERNIK7 z as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "-QUATERNIK7 z be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_22:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
sorry

mtheorem quaterni_th_41:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 ReaQUATERNIK12 z & Im1QUATERNIK13 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
sorry

abbreviation(input) QUATERNIK24(" _ -QUATERNIK24  _ " [132,132]132) where
  "z1 -QUATERNIK24 z2 \<equiv> z1 -QUATERNIK8 z2"

mtheorem quaterni_add_7:
  mlet "z1 be QuaternionQUATERNIM1", "z2 be QuaternionQUATERNIM1"
"cluster z1 -QUATERNIK8 z2 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z1 -QUATERNIK8 z2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_23:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
sorry

mtheorem quaterni_th_42:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
sorry

mdef quaterni_def_22 (" _ *''QUATERNIK25" [228]228 ) where
  mlet "z be QuaternionQUATERNIM1"
"func z *'QUATERNIK25 \<rightarrow> QuaternionQUATERNIM1 equals
  ((ReaQUATERNIK12 z +QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  (*coherence*)
    show "((ReaQUATERNIK12 z +QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11) be QuaternionQUATERNIM1"
       sorry
qed "sorry"

abbreviation(input) QUATERNIK26(" _ *''QUATERNIK26" [228]228) where
  "z *'QUATERNIK26 \<equiv> z *'QUATERNIK25"

mtheorem quaterni_add_8:
  mlet "z be QuaternionQUATERNIM1"
"cluster z *'QUATERNIK25 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z *'QUATERNIK25 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
     sorry
qed "sorry"

mtheorem quaterni_th_43:
" for z be QuaternionQUATERNIM1 holds z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
sorry

mtheorem quaterni_th_44:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z *'QUATERNIK26 =COMPLEX1R1 ReaQUATERNIK12 z & Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
sorry

mtheorem quaterni_th_45:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 0NUMBERSK6 implies z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem quaterni_th_46:
" for z be QuaternionQUATERNIM1 holds z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
sorry

mtheorem quaterni_th_47:
"(1qQUATERNIK17)*'QUATERNIK26 =HIDDENR1 1qQUATERNIK17"
sorry

mtheorem quaterni_th_48:
"((ReaQUATERNIK12 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & Im2QUATERNIK14 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_49:
"((ReaQUATERNIK12 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & Im3QUATERNIK15 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_50:
"((ReaQUATERNIK12 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem quaterni_th_51:
"(<i>XCMPLX-0K1)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 <i>XCMPLX-0K1"
  using quaterni_th_30 quaterni_lm_22 sorry

mtheorem quaterni_th_52:
"(<j>QUATERNIK10)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 <j>QUATERNIK10"
  using quaterni_th_31 quaterni_lm_22 sorry

mtheorem quaterni_th_53:
"(<k>QUATERNIK11)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 <k>QUATERNIK11"
  using quaterni_th_31 quaterni_lm_22 sorry

mtheorem quaterni_th_54:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 +QUATERNIK21 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 +QUATERNIK21 z2 *'QUATERNIK26"
sorry

mtheorem quaterni_th_55:
" for z be QuaternionQUATERNIM1 holds (-QUATERNIK23 z)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z *'QUATERNIK26"
sorry

mtheorem quaterni_th_56:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 -QUATERNIK24 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 -QUATERNIK24 z2 *'QUATERNIK26"
sorry

mtheorem quaterni_th_57:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 *QUATERNIK22 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26 implies (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
sorry

mtheorem quaterni_th_58:
" for z be QuaternionQUATERNIM1 holds (Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6 & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6 implies z *'QUATERNIK26 =HIDDENR1 z"
sorry

mtheorem quaterni_th_59:
" for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6 implies z *'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z"
sorry

mtheorem quaterni_th_60:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_61:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (ReaQUATERNIK12 z) & Im1QUATERNIK13 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_62:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
sorry

mtheorem quaterni_th_63:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
sorry

mtheorem quaterni_th_64:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im1QUATERNIK13 z)) & Im2QUATERNIK14 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im2QUATERNIK14 z)) & Im3QUATERNIK15 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im3QUATERNIK15 z)"
sorry

mdef quaterni_def_23 (" |.QUATERNIK27  _ .|" [0]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func  |.QUATERNIK27 z.| \<rightarrow> RealXREAL-0M1 equals
  sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1)"
proof-
  (*coherence*)
    show "sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem quaterni_th_65:
" |.QUATERNIK27 0qQUATERNIK16 .| =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem quaterni_th_66:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z.| =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
sorry

mtheorem quaterni_th_67:
" for z be QuaternionQUATERNIM1 holds 0NUMBERSK6 <=XXREAL-0R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_68:
" |.QUATERNIK27 1qQUATERNIK17 .| =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem quaterni_th_69:
" |.QUATERNIK27 <i>XCMPLX-0K1 .| =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_30 square_1_th_18 sorry

mtheorem quaterni_th_70:
" |.QUATERNIK27 <j>QUATERNIK10 .| =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_31 square_1_th_18 sorry

mtheorem quaterni_th_71:
" |.QUATERNIK27 <k>QUATERNIK11 .| =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_31 square_1_th_18 sorry

mtheorem quaterni_th_72:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 -QUATERNIK23 z .| =COMPLEX1R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_73:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *'QUATERNIK26.| =COMPLEX1R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_74:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
sorry

mlemma quaterni_lm_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
sorry

mlemma quaterni_lm_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds c ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
sorry

mlemma quaterni_lm_26:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
sorry

mlemma quaterni_lm_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b ^2SQUARE-1K1 implies sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
sorry

mlemma quaterni_lm_28:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for a6 be RealXREAL-0M1 holds  for b1 be RealXREAL-0M1 holds  for b2 be RealXREAL-0M1 holds  for b3 be RealXREAL-0M1 holds  for b4 be RealXREAL-0M1 holds  for b5 be RealXREAL-0M1 holds  for b6 be RealXREAL-0M1 holds ((((a1 >=XXREAL-0R2 b1 & a2 >=XXREAL-0R2 b2) & a3 >=XXREAL-0R2 b3) & a4 >=XXREAL-0R2 b4) & a5 >=XXREAL-0R2 b5) & a6 >=XXREAL-0R2 b6 implies ((((a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 a3)+XCMPLX-0K2 a4)+XCMPLX-0K2 a5)+XCMPLX-0K2 a6 >=XXREAL-0R2 ((((b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 b3)+XCMPLX-0K2 b4)+XCMPLX-0K2 b5)+XCMPLX-0K2 b6"
sorry

mlemma quaterni_lm_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & a ^2SQUARE-1K1 >=XXREAL-0R2 b ^2SQUARE-1K1 implies a >=XXREAL-0R2 b"
sorry

mlemma quaterni_lm_30:
" for m1 be RealXREAL-0M1 holds  for m2 be RealXREAL-0M1 holds  for m4 be RealXREAL-0M1 holds  for m3 be RealXREAL-0M1 holds  for n1 be RealXREAL-0M1 holds  for n2 be RealXREAL-0M1 holds  for n3 be RealXREAL-0M1 holds  for n4 be RealXREAL-0M1 holds (sqrtSQUARE-1K3 (((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 (((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((((((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1)+XCMPLX-0K2 n1 ^2SQUARE-1K1)+XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1))"
sorry

mlemma quaterni_lm_31:
" for m1 be RealXREAL-0M1 holds  for m2 be RealXREAL-0M1 holds  for m3 be RealXREAL-0M1 holds  for m4 be RealXREAL-0M1 holds  for n1 be RealXREAL-0M1 holds  for n2 be RealXREAL-0M1 holds  for n3 be RealXREAL-0M1 holds  for n4 be RealXREAL-0M1 holds (sqrtSQUARE-1K3 ((((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1"
sorry

mtheorem quaterni_th_75:
" for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_76:
" for z be QuaternionQUATERNIM1 holds Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_77:
" for z be QuaternionQUATERNIM1 holds Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_78:
" for z be QuaternionQUATERNIM1 holds Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
sorry

mtheorem quaterni_th_79:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 +QUATERNIK21 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
sorry

mtheorem quaterni_th_80:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
sorry

mlemma quaterni_lm_32:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 =HIDDENR1 (z1 +QUATERNIK21 z2)-QUATERNIK24 z2"
sorry

mlemma quaterni_lm_33:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 =HIDDENR1 (z1 -QUATERNIK24 z2)+QUATERNIK21 z2"
sorry

mlemma quaterni_lm_34:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
sorry

mlemma quaterni_lm_35:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 -QUATERNIK23 (z2 -QUATERNIK24 z1)"
sorry

mlemma quaterni_lm_36:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 0NUMBERSK6 implies z1 =HIDDENR1 z2"
sorry

mtheorem quaterni_th_81:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 +QUATERNIK21 z2 .|"
sorry

mtheorem quaterni_th_82:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
sorry

mtheorem quaterni_th_83:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1  |.QUATERNIK27 z2 -QUATERNIK24 z1 .|"
sorry

mtheorem quaterni_th_84:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1 0NUMBERSK6 iff z1 =HIDDENR1 z2"
sorry

mlemma quaterni_lm_37:
" for z be QuaternionQUATERNIM1 holds  for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)"
sorry

mtheorem quaterni_th_85:
" for z be QuaternionQUATERNIM1 holds  for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z .| +XCMPLX-0K2  |.QUATERNIK27 z -QUATERNIK24 z2 .|"
sorry

mtheorem quaterni_th_86:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.COMPLEX1K10  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
sorry

mtheorem quaterni_th_87:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 *QUATERNIK22 z2 .| =COMPLEX1R1 ( |.QUATERNIK27 z1.|)*XCMPLX-0K3 ( |.QUATERNIK27 z2.|)"
sorry

mtheorem quaterni_th_88:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *QUATERNIK22 z .| =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
sorry

mtheorem quaterni_th_89:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *QUATERNIK22 z .| =COMPLEX1R1  |.QUATERNIK27 z *QUATERNIK22 z *'QUATERNIK26 .|"
sorry

mtheorem quaterni_th_90:
" for z be QuaternionQUATERNIM1 holds z be realXREAL-0V1 implies ((ReaQUATERNIK12 z =HIDDENR1 z & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
  using quaterni_lm_16 sorry

mtheorem quaterni_th_91:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x,y *]"
  using quaterni_lm_2 sorry

mtheorem quaterni_th_92:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK21 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_18 sorry

mtheorem quaterni_th_93:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK22 z2 =XBOOLE-0R4 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_19 sorry

mtheorem quaterni_th_94:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_22 sorry

mtheorem quaterni_th_95:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_23 sorry

mtheorem quaterni_th_96:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies ((a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6) & c =COMPLEX1R1 0NUMBERSK6) & d =COMPLEX1R1 0NUMBERSK6"
  using quaterni_lm_8 sorry

mtheorem quaterni_th_97:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
  using quaterni_lm_15 sorry

end
