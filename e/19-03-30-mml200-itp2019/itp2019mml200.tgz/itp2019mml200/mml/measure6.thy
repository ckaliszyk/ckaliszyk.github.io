theory measure6
  imports setfam_1 member_1 measure5 card_4 fcont_3
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem measure6_th_1:
" ex F be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (F be one-to-oneFUNCT-1V2 & domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> F =MEMBEREDR12 NATNUMBERSK1) & rngFUNCOP-1K11\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1,NATNUMBERSK1)\<^esub> F =RELAT-1R1 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]"
sorry

mtheorem measure6_th_2:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies 0.SUPINF-2K2 <=XXREAL-3R1 SUMSUPINF-2K20 F"
sorry

mtheorem measure6_th_3:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for x be R-ealSUPINF-1M1 holds ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x <=XXREAL-3R1 F .SUPINF-2K15 n) & F be nonnegativeSUPINF-2V6 implies x <=XXREAL-3R1 SUMSUPINF-2K20 F"
sorry

(*\$CD*)
mtheorem measure6_th_4:
" for eps be ExtRealXXREAL-0M1 holds 0.SUPINF-2K2 <XXREAL-0R3 eps implies ( ex F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st ( for n be NatNAT-1M1 holds 0.SUPINF-2K2 <XXREAL-0R3 F .SUPINF-2K15 n) & SUMSUPINF-2K20 F <XXREAL-0R3 eps)"
sorry

mtheorem measure6_th_5:
" for eps be ExtRealXXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds 0.SUPINF-2K2 <XXREAL-0R3 eps & infSUPINF-2K10 X be RealXREAL-0M1 implies ( ex x be ExtRealXXREAL-0M1 st x inHIDDENR3 X & x <XXREAL-0R3 infSUPINF-2K10 X +XXREAL-3K1 eps)"
sorry

mtheorem measure6_th_6:
" for eps be ExtRealXXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds 0.SUPINF-2K2 <XXREAL-0R3 eps & supSUPINF-2K11 X be RealXREAL-0M1 implies ( ex x be ExtRealXXREAL-0M1 st x inHIDDENR3 X & supSUPINF-2K11 X -XXREAL-3K3 eps <XXREAL-0R3 x)"
sorry

mtheorem measure6_th_7:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 & SUMSUPINF-2K20 F <XXREAL-0R3 +inftySUPINF-1K1 implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2)"
sorry

mtheorem measure6_cl_1:
"cluster  non emptyXBOOLE-0V1\<bar>intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>intervalXXREAL-2V6"
sorry
qed "sorry"

mtheorem measure6_th_8:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for a be ExtRealXXREAL-0M1 holds ( ex b be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR9 ].RCOMP-1K2 a,b .[) implies a =HIDDENR1 infSUPINF-2K10 A"
  using xxreal_1_th_28 xxreal_2_th_28 sorry

mtheorem measure6_th_9:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for a be ExtRealXXREAL-0M1 holds ( ex b be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR8 ].XXREAL-1K3 a,b .]) implies a =HIDDENR1 infSUPINF-2K10 A"
  using xxreal_1_th_26 xxreal_2_th_27 sorry

mtheorem measure6_th_10:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for a be ExtRealXXREAL-0M1 holds ( ex b be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR8 [.XXREAL-1K1 a,b .]) implies a =HIDDENR1 infSUPINF-2K10 A"
  using xxreal_2_th_25 sorry

mtheorem measure6_th_11:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for a be ExtRealXXREAL-0M1 holds ( ex b be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR8 [.XXREAL-1K2 a,b .[) implies a =HIDDENR1 infSUPINF-2K10 A"
sorry

mtheorem measure6_th_12:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for b be ExtRealXXREAL-0M1 holds ( ex a be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR9 ].RCOMP-1K2 a,b .[) implies b =HIDDENR1 supSUPINF-2K11 A"
  using xxreal_1_th_28 xxreal_2_th_32 sorry

mtheorem measure6_th_13:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for b be ExtRealXXREAL-0M1 holds ( ex a be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR8 ].XXREAL-1K3 a,b .]) implies b =HIDDENR1 supSUPINF-2K11 A"
sorry

mtheorem measure6_th_14:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for b be ExtRealXXREAL-0M1 holds ( ex a be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR8 [.XXREAL-1K1 a,b .]) implies b =HIDDENR1 supSUPINF-2K11 A"
  using xxreal_2_th_29 sorry

mtheorem measure6_th_15:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for b be ExtRealXXREAL-0M1 holds ( ex a be ExtRealXXREAL-0M1 st a <=XXREAL-3R1 b & A =MEMBEREDR8 [.XXREAL-1K2 a,b .[) implies b =HIDDENR1 supSUPINF-2K11 A"
sorry

mtheorem measure6_th_16:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds A be open-intervalMEASURE5V1 implies A =MEMBEREDR9 ].MEASURE5K1 infSUPINF-2K10 A,supSUPINF-2K11 A .["
sorry

mtheorem measure6_th_17:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds A be closed-intervalMEASURE5V2 implies A =MEMBEREDR8 [.XXREAL-1K1 infSUPINF-2K10 A,supSUPINF-2K11 A .]"
sorry

mtheorem measure6_th_18:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds A be right-open-intervalMEASURE5V3 implies A =MEMBEREDR8 [.XXREAL-1K2 infSUPINF-2K10 A,supSUPINF-2K11 A .["
sorry

mtheorem measure6_th_19:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds A be left-open-intervalMEASURE5V5 implies A =MEMBEREDR8 ].XXREAL-1K3 infSUPINF-2K10 A,supSUPINF-2K11 A .]"
sorry

mtheorem measure6_th_20:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for B be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a inHIDDENR3 A & b inHIDDENR3 B) & supSUPINF-2K11 A <=XXREAL-3R1 infSUPINF-2K10 B implies a <=XXREAL-3R1 b"
sorry

mtheorem measure6_th_21:
" for A be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for B be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for y be RealXREAL-0M1 holds y inHIDDENR3 B ++MEMBER-1K9 A iff ( ex x be RealXREAL-0M1 st  ex z be RealXREAL-0M1 st (x inHIDDENR3 B & z inHIDDENR3 A) & y =COMPLEX1R1 x +XCMPLX-0K2 z)"
sorry

mtheorem measure6_th_22:
" for A be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds  for B be  non emptyXBOOLE-0V1\<bar>IntervalMEASURE5M1 holds supSUPINF-2K11 A =XBOOLE-0R4 infSUPINF-2K10 B & (supSUPINF-2K11 A inTARSKIR2 A or infSUPINF-2K10 B inTARSKIR2 B) implies A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B be IntervalMEASURE5M1"
  using xxreal_2_def_5 xxreal_2_def_6 xxreal_2_th_90 xxreal_2_th_91 sorry

abbreviation(input) MEASURE6K1(" _ ++MEASURE6K1  _ " [132,132]132) where
  "x ++MEASURE6K1 A \<equiv> x ++MEMBER-1K17 A"

mtheorem measure6_add_1:
  mlet "A be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "x be RealXREAL-0M1"
"cluster x ++MEMBER-1K17 A as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "x ++MEMBER-1K17 A be SubsetSUBSET-1M2-of REALNUMBERSK2"
    using membered_th_3 sorry
qed "sorry"

mlemma measure6_lm_1:
" for A be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y inHIDDENR3 x ++MEASURE6K1 A iff ( ex z be RealXREAL-0M1 st z inHIDDENR3 A & y =COMPLEX1R1 x +XCMPLX-0K2 z)"
sorry

mtheorem measure6_th_23:
" for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds (-XCMPLX-0K4 x)++MEASURE6K1 (x ++MEASURE6K1 A) =MEMBEREDR9 A"
sorry

mtheorem measure6_th_24:
" for x be RealXREAL-0M1 holds  for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds A =MEMBEREDR9 REALNUMBERSK2 implies x ++MEASURE6K1 A =MEMBEREDR9 A"
sorry

mtheorem measure6_th_25:
" for x be RealXREAL-0M1 holds x ++MEASURE6K1 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem measure6_th_26:
" for A be IntervalMEASURE5M1 holds  for x be RealXREAL-0M1 holds A be open-intervalMEASURE5V1 iff x ++MEASURE6K1 A be open-intervalMEASURE5V1"
sorry

mtheorem measure6_th_27:
" for A be IntervalMEASURE5M1 holds  for x be RealXREAL-0M1 holds A be closed-intervalMEASURE5V2 iff x ++MEASURE6K1 A be closed-intervalMEASURE5V2"
sorry

mtheorem measure6_th_28:
" for A be IntervalMEASURE5M1 holds  for x be RealXREAL-0M1 holds A be right-open-intervalMEASURE5V3 iff x ++MEASURE6K1 A be right-open-intervalMEASURE5V3"
sorry

mtheorem measure6_th_29:
" for A be IntervalMEASURE5M1 holds  for x be RealXREAL-0M1 holds A be left-open-intervalMEASURE5V5 iff x ++MEASURE6K1 A be left-open-intervalMEASURE5V5"
sorry

mtheorem measure6_th_30:
" for A be IntervalMEASURE5M1 holds  for x be RealXREAL-0M1 holds x ++MEASURE6K1 A be IntervalMEASURE5M1"
sorry

mtheorem measure6_th_31:
" for A be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for x be RealXREAL-0M1 holds  for y be R-ealSUPINF-1M1 holds x =HIDDENR1 y implies supSUPINF-2K11 (x ++MEASURE6K1 A) =XBOOLE-0R4 y +SUPINF-2K4 supSUPINF-2K11 A"
sorry

mtheorem measure6_th_32:
" for A be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for x be RealXREAL-0M1 holds  for y be R-ealSUPINF-1M1 holds x =HIDDENR1 y implies infSUPINF-2K10 (x ++MEASURE6K1 A) =XBOOLE-0R4 y +SUPINF-2K4 infSUPINF-2K10 A"
sorry

mtheorem measure6_th_33:
" for A be IntervalMEASURE5M1 holds  for x be RealXREAL-0M1 holds diameterMEASURE5K2 A =XBOOLE-0R4 diameterMEASURE5K2 (x ++MEASURE6K1 A)"
sorry

(*begin*)
abbreviation(input) MEASURE6V1("without-zeroMEASURE6V1" 70) where
  "without-zeroMEASURE6V1 \<equiv> with-non-empty-elementsSETFAM-1V1"

syntax MEASURE6V2 :: "Ty" ("with-zeroMEASURE6V2" 70)
translations "with-zeroMEASURE6V2" \<rightharpoonup> " non with-non-empty-elementsSETFAM-1V1"

abbreviation(input) MEASURE6V3("without-zeroMEASURE6V3" 70) where
  "without-zeroMEASURE6V3 \<equiv> with-non-empty-elementsSETFAM-1V1"

mtheorem measure6_def_2:
  mlet "X be setHIDDENM2"
"redefine attr without-zeroMEASURE6V3 for setHIDDENM2 means
  (\<lambda>X.  not 0NUMBERSK6 inTARSKIR2 X)"
proof
(*compatibility*)
  show " for X be setHIDDENM2 holds X be without-zeroMEASURE6V3 iff  not 0NUMBERSK6 inTARSKIR2 X"
sorry
qed "sorry"

mtheorem measure6_cl_2:
"cluster REALNUMBERSK2 as-term-is with-zeroMEASURE6V2"
proof
(*coherence*)
  show "REALNUMBERSK2 be with-zeroMEASURE6V2"
    using xreal_0_def_1 sorry
qed "sorry"

mtheorem measure6_cl_3:
"cluster NATNUMBERSK1 as-term-is with-zeroMEASURE6V2"
proof
(*coherence*)
  show "NATNUMBERSK1 be with-zeroMEASURE6V2"
     sorry
qed "sorry"

mtheorem measure6_cl_4:
"cluster  non emptyXBOOLE-0V1\<bar>without-zeroMEASURE6V3 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>without-zeroMEASURE6V3"
sorry
qed "sorry"

mtheorem measure6_cl_5:
"cluster  non emptyXBOOLE-0V1\<bar>with-zeroMEASURE6V2 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>with-zeroMEASURE6V2"
    using measure6_def_2 sorry
qed "sorry"

mtheorem measure6_cl_6:
"cluster  non emptyXBOOLE-0V1\<bar>without-zeroMEASURE6V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>without-zeroMEASURE6V3"
sorry
qed "sorry"

mtheorem measure6_cl_7:
"cluster  non emptyXBOOLE-0V1\<bar>with-zeroMEASURE6V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>with-zeroMEASURE6V2"
sorry
qed "sorry"

mtheorem measure6_th_34:
" for F be setHIDDENM2 holds F be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1\<bar>c=-linearORDINAL1V6 implies F be centeredFINSET-1V4"
sorry

mtheorem measure6_cl_8:
  mlet "F be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1\<bar>c=-linearORDINAL1V6 also-is centeredFINSET-1V4 for Subset-FamilySETFAM-1M1-of F"
proof
(*coherence*)
  show " for it be Subset-FamilySETFAM-1M1-of F holds it be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1\<bar>c=-linearORDINAL1V6 implies it be centeredFINSET-1V4"
    using measure6_th_34 sorry
qed "sorry"

mtheorem measure6_cl_9:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,Y)"
"cluster f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef measure6_def_3 ("\<inverse>MEASURE6K2\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,Y)"
"func \<inverse>MEASURE6K2\<^bsub>(X,Y)\<^esub> f \<rightarrow> FunctionFUNCT-2M1-of(boolSETFAM-1K9 Y,boolSETFAM-1K9 X) means
  \<lambda>it.  for y be SubsetSUBSET-1M2-of Y holds it .FUNCT-2K3\<^bsub>(boolZFMISC-1K1 Y,boolSETFAM-1K9 X)\<^esub> y =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> y"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(boolSETFAM-1K9 Y,boolSETFAM-1K9 X) st  for y be SubsetSUBSET-1M2-of Y holds it .FUNCT-2K3\<^bsub>(boolZFMISC-1K1 Y,boolSETFAM-1K9 X)\<^esub> y =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> y"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(boolSETFAM-1K9 Y,boolSETFAM-1K9 X) holds  for it2 be FunctionFUNCT-2M1-of(boolSETFAM-1K9 Y,boolSETFAM-1K9 X) holds ( for y be SubsetSUBSET-1M2-of Y holds it1 .FUNCT-2K3\<^bsub>(boolZFMISC-1K1 Y,boolSETFAM-1K9 X)\<^esub> y =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> y) & ( for y be SubsetSUBSET-1M2-of Y holds it2 .FUNCT-2K3\<^bsub>(boolZFMISC-1K1 Y,boolSETFAM-1K9 X)\<^esub> y =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> y) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem measure6_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be setHIDDENM2 holds  for S be Subset-FamilySETFAM-1M1-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds x inTARSKIR2 meetSETFAM-1K6\<^bsub>(X)\<^esub> (\<inverse>MEASURE6K2\<^bsub>(X,Y)\<^esub> f .:RELSET-1K7\<^bsub>(boolSETFAM-1K9 Y,boolSETFAM-1K9 X)\<^esub> S) implies f .FUNCT-1K1 x inTARSKIR2 meetSETFAM-1K6\<^bsub>(Y)\<^esub> S"
sorry

reserve r, s, t for "RealXREAL-0M1"
mtheorem measure6_th_36:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 s.| =COMPLEX1R1 0NUMBERSK6 implies r =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem measure6_th_37:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds r <XXREAL-0R3 s & s <XXREAL-0R3 t implies  |.COMPLEX1K10 s.| <XXREAL-0R3  |.COMPLEX1K10 r.| +XCMPLX-0K2  |.COMPLEX1K10 t.|"
sorry

reserve seq for "Real-SequenceSEQ-1M1"
reserve X, Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
mtheorem measure6_th_38:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & seq be non-zeroORDINAL1V9) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6 implies seq \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> be  non boundedSEQ-2V6"
sorry

mtheorem measure6_th_39:
" for seq be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq be real-boundedXXREAL-2V5 iff seq be boundedSEQ-2V6"
sorry

abbreviation(input) MEASURE6V4("with-maxMEASURE6V4" 70) where
  "with-maxMEASURE6V4 \<equiv> right-endXXREAL-2V2"

abbreviation(input) MEASURE6V5("with-minMEASURE6V5" 70) where
  "with-minMEASURE6V5 \<equiv> left-endXXREAL-2V1"

abbreviation(input) MEASURE6V6("with-maxMEASURE6V6" 70) where
  "with-maxMEASURE6V6 \<equiv> right-endXXREAL-2V2"

mtheorem measure6_def_4:
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"redefine attr with-maxMEASURE6V6 for real-memberedMEMBEREDV3\<bar>setHIDDENM2 means
  (\<lambda>X. X be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 X inHIDDENR3 X)"
proof
(*compatibility*)
  show " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be with-maxMEASURE6V6 iff X be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 X inHIDDENR3 X"
sorry
qed "sorry"

abbreviation(input) MEASURE6V7("with-minMEASURE6V7" 70) where
  "with-minMEASURE6V7 \<equiv> left-endXXREAL-2V1"

mtheorem measure6_def_5:
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"redefine attr with-minMEASURE6V7 for real-memberedMEMBEREDV3\<bar>setHIDDENM2 means
  (\<lambda>X. X be bounded-belowXXREAL-2V3 & lower-boundSEQ-4K3 X inHIDDENR3 X)"
proof
(*compatibility*)
  show " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be with-minMEASURE6V7 iff X be bounded-belowXXREAL-2V3 & lower-boundSEQ-4K3 X inHIDDENR3 X"
sorry
qed "sorry"

mtheorem measure6_cl_10:
"cluster  non emptyXBOOLE-0V1\<bar>closedRCOMP-1V2\<bar>real-boundedXXREAL-2V5 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>closedRCOMP-1V2\<bar>real-boundedXXREAL-2V5"
sorry
qed "sorry"

mdef measure6_def_6 ("openMEASURE6V8" 70 ) where
"attr openMEASURE6V8 for Subset-FamilySETFAM-1M1-of REALNUMBERSK2 means
  (\<lambda>R.  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X inTARSKIR2 R implies X be openRCOMP-1V3)"..

mdef measure6_def_7 ("closedMEASURE6V9" 70 ) where
"attr closedMEASURE6V9 for Subset-FamilySETFAM-1M1-of REALNUMBERSK2 means
  (\<lambda>R.  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X inTARSKIR2 R implies X be closedRCOMP-1V2)"..

reserve r3, r1, q3, p3 for "RealXREAL-0M1"
abbreviation(input) MEASURE6K3("--MEASURE6K3  _ " [132]132) where
  "--MEASURE6K3 X \<equiv> --MEMBER-1K5 X"

mtheorem measure6_add_2:
  mlet "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
"cluster --MEMBER-1K5 X as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "--MEMBER-1K5 X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    using membered_th_3 sorry
qed "sorry"

mtheorem measure6_th_40:
" for r be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds r inHIDDENR3 X iff -XCMPLX-0K4 r inHIDDENR3 --MEASURE6K3 X"
  using member_1_th_11 sorry

mlemma measure6_lm_2:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-aboveXXREAL-2V4 implies --MEASURE6K3 X be bounded-belowXXREAL-2V3"
sorry

mlemma measure6_lm_3:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 implies --MEASURE6K3 X be bounded-aboveXXREAL-2V4"
sorry

mtheorem measure6_th_41:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-aboveXXREAL-2V4 iff --MEASURE6K3 X be bounded-belowXXREAL-2V3"
sorry

mtheorem measure6_th_42:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 iff --MEASURE6K3 X be bounded-aboveXXREAL-2V4"
sorry

mtheorem measure6_th_43:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 X =COMPLEX1R1 -XCMPLX-0K4 upper-boundSEQ-4K2 (--MEASURE6K3 X)"
sorry

mtheorem measure6_th_44:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-aboveXXREAL-2V4 implies upper-boundSEQ-4K2 X =COMPLEX1R1 -XCMPLX-0K4 lower-boundSEQ-4K3 (--MEASURE6K3 X)"
sorry

mlemma measure6_lm_4:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be closedRCOMP-1V2 implies --MEASURE6K3 X be closedRCOMP-1V2"
sorry

mtheorem measure6_th_45:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be closedRCOMP-1V2 iff --MEASURE6K3 X be closedRCOMP-1V2"
sorry

mlemma measure6_lm_5:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for p be RealXREAL-0M1 holds p ++MEASURE6K1 X =XBOOLE-0R4 {p +XCMPLX-0K2 r3 where r3 be RealXREAL-0M1 : r3 inHIDDENR3 X }"
sorry

mtheorem measure6_th_46:
" for r be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for q3 be RealXREAL-0M1 holds r inHIDDENR3 X iff q3 +XCMPLX-0K2 r inTARSKIR2 q3 ++MEASURE6K1 X"
sorry

mtheorem measure6_th_47:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =MEMBEREDR9 0NUMBERSK6 ++MEASURE6K1 X"
  using member_1_th_146 sorry

mtheorem measure6_th_48:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for q3 be RealXREAL-0M1 holds  for p3 be RealXREAL-0M1 holds q3 ++MEASURE6K1 (p3 ++MEASURE6K1 X) =MEMBEREDR9 (q3 +XCMPLX-0K2 p3)++MEASURE6K1 X"
  using member_1_th_147 sorry

mlemma measure6_lm_6:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for s be RealXREAL-0M1 holds X be bounded-aboveXXREAL-2V4 implies s ++MEASURE6K1 X be bounded-aboveXXREAL-2V4"
sorry

mtheorem measure6_th_49:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for q3 be RealXREAL-0M1 holds X be bounded-aboveXXREAL-2V4 iff q3 ++MEASURE6K1 X be bounded-aboveXXREAL-2V4"
sorry

mlemma measure6_lm_7:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for p be RealXREAL-0M1 holds X be bounded-belowXXREAL-2V3 implies p ++MEASURE6K1 X be bounded-belowXXREAL-2V3"
sorry

mtheorem measure6_th_50:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for q3 be RealXREAL-0M1 holds X be bounded-belowXXREAL-2V3 iff q3 ++MEASURE6K1 X be bounded-belowXXREAL-2V3"
sorry

mtheorem measure6_th_51:
" for q3 be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 (q3 ++MEASURE6K1 X) =COMPLEX1R1 q3 +XCMPLX-0K2 lower-boundSEQ-4K3 X"
sorry

mtheorem measure6_th_52:
" for q3 be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-aboveXXREAL-2V4 implies upper-boundSEQ-4K2 (q3 ++MEASURE6K1 X) =COMPLEX1R1 q3 +XCMPLX-0K2 upper-boundSEQ-4K2 X"
sorry

mlemma measure6_lm_8:
" for q3 be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be closedRCOMP-1V2 implies q3 ++MEASURE6K1 X be closedRCOMP-1V2"
sorry

mtheorem measure6_th_53:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for q3 be RealXREAL-0M1 holds X be closedRCOMP-1V2 iff q3 ++MEASURE6K1 X be closedRCOMP-1V2"
sorry

mdef measure6_def_8 ("InvMEASURE6K4  _ " [228]228 ) where
  mlet "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
"func InvMEASURE6K4 X \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {\<one>\<^sub>M /XCMPLX-0K7 r3 where r3 be RealXREAL-0M1 : r3 inHIDDENR3 X }"
proof-
  (*coherence*)
    show "{\<one>\<^sub>M /XCMPLX-0K7 r3 where r3 be RealXREAL-0M1 : r3 inHIDDENR3 X } be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mtheorem MEASURE6K4_involutiveness:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds InvMEASURE6K4 (InvMEASURE6K4 X) =HIDDENR1 X"
sorry

mtheorem measure6_th_54:
" for r be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds r inHIDDENR3 X iff \<one>\<^sub>M /XCMPLX-0K7 r inTARSKIR2 InvMEASURE6K4 X"
sorry

mtheorem measure6_cl_11:
  mlet "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
"cluster InvMEASURE6K4 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "InvMEASURE6K4 X be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem measure6_cl_12:
  mlet "X be without-zeroMEASURE6V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
"cluster InvMEASURE6K4 X as-term-is without-zeroMEASURE6V3"
proof
(*coherence*)
  show "InvMEASURE6K4 X be without-zeroMEASURE6V3"
sorry
qed "sorry"

mtheorem measure6_th_55:
" for X be without-zeroMEASURE6V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be closedRCOMP-1V2\<bar>real-boundedXXREAL-2V5 implies InvMEASURE6K4 X be closedRCOMP-1V2"
sorry

mtheorem measure6_th_56:
" for Z be Subset-FamilySETFAM-1M1-of REALNUMBERSK2 holds Z be closedMEASURE6V9 implies meetSETFAM-1K6\<^bsub>(REALNUMBERSK2)\<^esub> Z be closedRCOMP-1V2"
sorry

mdef measure6_def_9 ("ClMEASURE6K5  _ " [228]228 ) where
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"func ClMEASURE6K5 X \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  meetSETFAM-1K1 ({A where A be SubsetSUBSET-1M2-of REALNUMBERSK2 : X c=MEMBEREDR3 A & A be closedRCOMP-1V2 })"
proof-
  (*coherence*)
    show "meetSETFAM-1K1 ({A where A be SubsetSUBSET-1M2-of REALNUMBERSK2 : X c=MEMBEREDR3 A & A be closedRCOMP-1V2 }) be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mtheorem MEASURE6K5_projectivity:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ClMEASURE6K5 (ClMEASURE6K5 X) =HIDDENR1 ClMEASURE6K5 X"
sorry

mtheorem measure6_cl_13:
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster ClMEASURE6K5 X as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "ClMEASURE6K5 X be closedRCOMP-1V2"
sorry
qed "sorry"

mtheorem measure6_th_57:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be closedRCOMP-1V2\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds X c=MEMBEREDR3 Y implies ClMEASURE6K5 X c=MEMBEREDR3 Y"
sorry

mtheorem measure6_th_58:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X c=MEMBEREDR3 ClMEASURE6K5 X"
sorry

mtheorem measure6_th_59:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be closedRCOMP-1V2 iff X =MEMBEREDR9 ClMEASURE6K5 X"
sorry

mtheorem measure6_th_60:
"ClMEASURE6K5 ({}SUBSET-1K1 REALNUMBERSK2) =MEMBEREDR9 {}XBOOLE-0K1"
  using measure6_th_59 sorry

mtheorem measure6_th_61:
"ClMEASURE6K5 ([#]SUBSET-1K2 REALNUMBERSK2) =MEMBEREDR9 REALNUMBERSK2"
  using measure6_th_59 sorry

mtheorem measure6_th_62:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X c=MEMBEREDR3 Y implies ClMEASURE6K5 X c=MEMBEREDR3 ClMEASURE6K5 Y"
sorry

mtheorem measure6_th_63:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r3 be RealXREAL-0M1 holds r3 inHIDDENR3 ClMEASURE6K5 X iff ( for O be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds r3 inHIDDENR3 O implies O /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> X be  non emptyXBOOLE-0V1)"
sorry

mtheorem measure6_th_64:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r3 be RealXREAL-0M1 holds r3 inHIDDENR3 ClMEASURE6K5 X implies ( ex seq be Real-SequenceSEQ-1M1 st (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq c=MEMBEREDR3 X & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 r3)"
sorry

(*begin*)
syntax MEASURE6V10 :: " Set \<Rightarrow> Ty" ("bounded-belowMEASURE6V10\<^bsub>'( _ ')\<^esub>" [0]70)
translations "bounded-belowMEASURE6V10\<^bsub>(X)\<^esub>" \<rightharpoonup> "bounded-belowSEQ-2V2"

mtheorem measure6_def_10:
  mlet "X be setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2)"
"redefine attr bounded-belowMEASURE6V10\<^bsub>(X)\<^esub> for FunctionFUNCT-2M1-of(X,REALNUMBERSK2) means
  (\<lambda>f. f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> X be bounded-belowXXREAL-2V3)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds f be bounded-belowMEASURE6V10\<^bsub>(X)\<^esub> iff f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> X be bounded-belowXXREAL-2V3"
sorry
qed "sorry"

syntax MEASURE6V11 :: " Set \<Rightarrow> Ty" ("bounded-aboveMEASURE6V11\<^bsub>'( _ ')\<^esub>" [0]70)
translations "bounded-aboveMEASURE6V11\<^bsub>(X)\<^esub>" \<rightharpoonup> "bounded-aboveSEQ-2V1"

mtheorem measure6_def_11:
  mlet "X be setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2)"
"redefine attr bounded-aboveMEASURE6V11\<^bsub>(X)\<^esub> for FunctionFUNCT-2M1-of(X,REALNUMBERSK2) means
  (\<lambda>f. f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> X be bounded-aboveXXREAL-2V4)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds f be bounded-aboveMEASURE6V11\<^bsub>(X)\<^esub> iff f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> X be bounded-aboveXXREAL-2V4"
sorry
qed "sorry"

mdef measure6_def_12 ("with-maxMEASURE6V12\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr with-maxMEASURE6V12\<^bsub>(X)\<^esub> for FunctionFUNCT-2M1-of(X,REALNUMBERSK2) means
  (\<lambda>f. f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> X be with-maxMEASURE6V6)"..

mdef measure6_def_13 ("with-minMEASURE6V13\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr with-minMEASURE6V13\<^bsub>(X)\<^esub> for FunctionFUNCT-2M1-of(X,REALNUMBERSK2) means
  (\<lambda>f. f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> X be with-minMEASURE6V7)"..

mtheorem measure6_th_65:
" for X be setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds (-VALUED-1K34\<^bsub>(X,REALNUMBERSK2)\<^esub> f).:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> A =MEMBEREDR9 --MEASURE6K3 f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> A"
sorry

mlemma measure6_lm_9:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds f be with-maxMEASURE6V12\<^bsub>(X)\<^esub> implies -VALUED-1K34\<^bsub>(X,REALNUMBERSK2)\<^esub> f be with-minMEASURE6V13\<^bsub>(X)\<^esub>"
sorry

mlemma measure6_lm_10:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds f be with-minMEASURE6V13\<^bsub>(X)\<^esub> implies -VALUED-1K34\<^bsub>(X,REALNUMBERSK2)\<^esub> f be with-maxMEASURE6V12\<^bsub>(X)\<^esub>"
sorry

mtheorem measure6_th_66:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds f be with-minMEASURE6V13\<^bsub>(X)\<^esub> iff -VALUED-1K34\<^bsub>(X,REALNUMBERSK2)\<^esub> f be with-maxMEASURE6V12\<^bsub>(X)\<^esub>"
sorry

mtheorem measure6_th_67:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds f be with-maxMEASURE6V12\<^bsub>(X)\<^esub> iff -VALUED-1K34\<^bsub>(X,REALNUMBERSK2)\<^esub> f be with-minMEASURE6V13\<^bsub>(X)\<^esub>"
sorry

mtheorem measure6_th_68:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds (-VALUED-1K34\<^bsub>(X,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(X,REALNUMBERSK2)\<^esub> A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,REALNUMBERSK2)\<^esub> (--MEASURE6K3 A)"
sorry

mtheorem measure6_th_69:
" for X be setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds  for s be RealXREAL-0M1 holds (s +VALUED-1K10\<^bsub>(X,REALNUMBERSK2)\<^esub> f).:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> A =MEMBEREDR9 s ++MEASURE6K1 f .:RELSET-1K7\<^bsub>(X,REALNUMBERSK2)\<^esub> A"
sorry

mtheorem measure6_th_70:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds  for q3 be RealXREAL-0M1 holds (q3 +VALUED-1K10\<^bsub>(X,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(X,REALNUMBERSK2)\<^esub> A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 q3)++MEASURE6K1 A)"
sorry

abbreviation(input) MEASURE6K6("InvMEASURE6K6  _ " [228]228) where
  "InvMEASURE6K6 f \<equiv> f \<inverse>VALUED-1K37"

syntax MEASURE6K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("InvMEASURE6K7\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228)
translations "InvMEASURE6K7\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "f \<inverse>VALUED-1K37"

mtheorem measure6_add_3:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f \<inverse>VALUED-1K37 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
sorry
qed "sorry"

mtheorem measure6_th_71:
" for X be setHIDDENM2 holds  for A be without-zeroMEASURE6V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be FunctionFUNCT-2M1-of(X,REALNUMBERSK2) holds (InvMEASURE6K7\<^bsub>(X,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(X,REALNUMBERSK2)\<^esub> A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,REALNUMBERSK2)\<^esub> (InvMEASURE6K4 A)"
sorry

mtheorem measure6_th_72:
" for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 --MEASURE6K3 A implies ( ex a be RealXREAL-0M1 st a inHIDDENR3 A & x =COMPLEX1R1 -XCMPLX-0K4 a)"
sorry

end
