theory nat_2
  imports abian xcmplx_1 recdef_1 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, j, k, l, m, n, t for "NatNAT-1M1"
theorem nat_2_sch_1:
  fixes Df0 Af0 Nf0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Nf0 be NatNAT-1M1" and
   A1: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies ( for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp3(n,x,y))"
  shows " ex p be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0 & (p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

mtheorem nat_2_th_1:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6 implies x /XCMPLX-0K7 ([\\INT-1K2 x /XCMPLX-0K7 y /] +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 y"
sorry

(*begin*)
mtheorem nat_2_th_2:
" for n be NatNAT-1M1 holds 0NUMBERSK6 divNAT-DK3 n =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem nat_2_th_3:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds n divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem nat_2_th_4:
" for n be NatNAT-1M1 holds n divNAT-DK3 \<one>\<^sub>M =XBOOLE-0R4 n"
sorry

mtheorem nat_2_th_5:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (i <=XXREAL-0R1 j & k <=XXREAL-0R1 j) & i =XBOOLE-0R4 (j -'NAT-DK9 k)+XCMPLX-0K2 l implies k =XBOOLE-0R4 (j -'NAT-DK9 i)+XCMPLX-0K2 l"
sorry

mtheorem nat_2_th_6:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies (n -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
sorry

mtheorem nat_2_th_7:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds j <XXREAL-0R3 i implies (i -'NAT-DK9 (j +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i -'NAT-DK9 j"
sorry

mtheorem nat_2_th_8:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i >=XXREAL-0R2 j implies j -'NAT-DK9 i =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem nat_2_th_9:
" for i be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for j be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds i -'NAT-DK9 j <XXREAL-0R3 i"
sorry

mtheorem nat_2_th_10:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies \<two>\<^sub>M to-powerPOWERK2 n =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 k *XCMPLX-0K3 \<two>\<^sub>M to-powerPOWERK2 (n -'NAT-DK9 k)"
sorry

mtheorem nat_2_th_11:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies \<two>\<^sub>M to-powerPOWERK2 k dividesNAT-DR1 \<two>\<^sub>M to-powerPOWERK2 n"
sorry

mtheorem nat_2_th_12:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & n divNAT-DK3 k =XBOOLE-0R4 0NUMBERSK6 implies n <XXREAL-0R3 k"
sorry

mtheorem nat_2_th_13:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & k <=XXREAL-0R1 n implies n divNAT-DK3 k >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem nat_2_th_14:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 implies (n +XCMPLX-0K2 k)divNAT-DK3 k =XBOOLE-0R4 (n divNAT-DK3 k)+NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem nat_2_th_15:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ((k dividesNAT-DR1 n & \<one>\<^sub>M <=XXREAL-0R1 n) & \<one>\<^sub>M <=XXREAL-0R1 i) & i <=XXREAL-0R1 k implies (n -'NAT-DK9 i)divNAT-DK3 k =XBOOLE-0R4 (n divNAT-DK3 k)-XCMPLX-0K6 \<one>\<^sub>M"
sorry

mtheorem nat_2_th_16:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies \<two>\<^sub>M to-powerPOWERK2 n divNAT-DK1 \<two>\<^sub>M to-powerPOWERK2 k =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (n -'NAT-DK9 k)"
sorry

mtheorem nat_2_th_17:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies \<two>\<^sub>M to-powerPOWERK2 n modNAT-DK2 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem nat_2_th_18:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (n modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 iff (n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M)"
sorry

mtheorem nat_2_th_19:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds n <>HIDDENR2 \<one>\<^sub>M implies n >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem nat_2_th_20:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 k & k <XXREAL-0R3 n +XCMPLX-0K2 n implies k divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem nat_2_th_21:
" for n be NatNAT-1M1 holds n be evenABIANV3 iff n modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem nat_2_th_22:
" for n be NatNAT-1M1 holds n be oddABIANV2 iff n modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  using nat_2_th_21 nat_d_th_12 sorry

mtheorem nat_2_th_23:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for t be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 t & k <=XXREAL-0R1 n) & \<two>\<^sub>M *XCMPLX-0K3 t dividesNAT-DR1 k implies (n divNAT-DK3 t be evenABIANV3 iff (n -'NAT-DK9 k)divNAT-DK3 t be evenABIANV3)"
sorry

mtheorem nat_2_th_24:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies n divNAT-DK3 k <=XXREAL-0R1 m divNAT-DK3 k"
sorry

mtheorem nat_2_th_25:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 n implies (k +NAT-1K1 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M <=XXREAL-0R1 n"
sorry

mtheorem nat_2_th_26:
" for n be NatNAT-1M1 holds n be evenABIANV3 implies n divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M"
sorry

mtheorem nat_2_th_27:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n divNAT-DK3 k)divNAT-DK3 i =XBOOLE-0R4 n divNAT-DK3 k *XCMPLX-0K3 i"
sorry

abbreviation(input) NAT_2V1("trivialNAT-2V1" 70) where
  "trivialNAT-2V1 \<equiv> trivialZFMISC-1V1"

mtheorem nat_2_def_1:
  mlet "n be NatNAT-1M1"
"redefine attr trivialNAT-2V1 for NatNAT-1M1 means
  (\<lambda>n. n =XBOOLE-0R4 0NUMBERSK6 or n =XBOOLE-0R4 \<one>\<^sub>M)"
proof
(*compatibility*)
  show " for n be NatNAT-1M1 holds n be trivialNAT-2V1 iff n =XBOOLE-0R4 0NUMBERSK6 or n =XBOOLE-0R4 \<one>\<^sub>M"
sorry
qed "sorry"

mtheorem nat_2_cl_1:
"cluster  non trivialNAT-2V1 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be  non trivialNAT-2V1"
sorry
qed "sorry"

mtheorem nat_2_th_28:
" for k be NatNAT-1M1 holds k be  non trivialNAT-2V1 iff k be  non emptyXBOOLE-0V1 & k <>HIDDENR2 \<one>\<^sub>M"
   sorry

mtheorem nat_2_th_29:
" for k be  non trivialNAT-2V1\<bar>NatNAT-1M1 holds k >=XXREAL-0R2 \<two>\<^sub>M"
sorry

theorem nat_2_sch_2:
  fixes Pp1 
  assumes
    A1: "Pp1(\<two>\<^sub>M)" and
   A2: " for k be  non trivialNAT-2V1\<bar>NatNAT-1M1 holds Pp1(k) implies Pp1(k +NAT-1K1 \<one>\<^sub>M)"
  shows " for k be  non trivialNAT-2V1\<bar>NatNAT-1M1 holds Pp1(k)"
sorry

(*begin*)
mtheorem nat_2_th_30:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds (i -'NAT-DK9 j)-'NAT-DK9 k =XBOOLE-0R4 i -'NAT-DK9 (j +XCMPLX-0K2 k)"
sorry

end
