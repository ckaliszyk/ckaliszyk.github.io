theory series_3
  imports sin_cos2 polyeq_2 asympt_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c for "positiveXXREAL-0V2\<bar>RealXREAL-0M1"
reserve m, x, y, z for "RealXREAL-0M1"
reserve n for "NatNAT-1M1"
reserve s, s1, s2, s3, s4, s5 for "Real-SequenceSEQ-1M1"
mtheorem series_3_cl_1:
  mlet "x be RealXREAL-0M1"
"cluster  |.COMPLEX1K10 x.| as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show " |.COMPLEX1K10 x.| be  non negativeXXREAL-0V3"
     sorry
qed "sorry"

mlemma series_3_lm_1:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 =COMPLEX1R1 x  |^NEWTONK1 \<two>\<^sub>M"
sorry

mlemma series_3_lm_2:
"\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M =COMPLEX1R1 \<eight>\<^sub>M"
sorry

mlemma series_3_lm_3:
"\<three>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M =COMPLEX1R1 \<two>\<seven>\<^sub>M"
sorry

mlemma series_3_lm_4:
" for x be RealXREAL-0M1 holds (-XCMPLX-0K4 x) |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 -XCMPLX-0K4 x  |^NEWTONK1 \<three>\<^sub>M"
sorry

mlemma series_3_lm_5:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x +XCMPLX-0K2 y) |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 y)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y ^2SQUARE-1K1)+XCMPLX-0K2 y  |^NEWTONK1 \<three>\<^sub>M"
sorry

mlemma series_3_lm_6:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 y  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (x +XCMPLX-0K2 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1)"
sorry

mlemma series_3_lm_7:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds x ^2SQUARE-1K1 <=XXREAL-0R1 y *XCMPLX-0K3 z implies  |.COMPLEX1K10 x.| <=XXREAL-0R1 sqrtSQUARE-1K3 (y *XCMPLX-0K3 z)"
sorry

mtheorem series_3_th_1:
" for m be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (y >XXREAL-0R4 x & x >=XXREAL-0R2 0NUMBERSK6) & m >=XXREAL-0R2 0NUMBERSK6 implies x /XCMPLX-0K7 y <=XXREAL-0R1 (x +XCMPLX-0K2 m)/XCMPLX-0K7 (y +XCMPLX-0K2 m)"
sorry

mtheorem series_3_th_2:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
sorry

mtheorem series_3_th_3:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds b /XCMPLX-0K7 a +XCMPLX-0K2 a /XCMPLX-0K7 b >=XXREAL-0R2 \<two>\<^sub>M"
sorry

mtheorem series_3_th_4:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ((x +XCMPLX-0K2 y)/XCMPLX-0K7 \<two>\<^sub>M)^2SQUARE-1K1 >=XXREAL-0R2 x *XCMPLX-0K3 y"
sorry

mtheorem series_3_th_5:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 ((x +XCMPLX-0K2 y)/XCMPLX-0K7 \<two>\<^sub>M)^2SQUARE-1K1"
sorry

mtheorem series_3_th_6:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y"
sorry

mtheorem series_3_th_7:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 x *XCMPLX-0K3 y"
sorry

mtheorem series_3_th_8:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x.|))*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
sorry

mtheorem series_3_th_9:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)^2SQUARE-1K1 >=XXREAL-0R2 (\<four>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y"
sorry

mtheorem series_3_th_10:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 >=XXREAL-0R2 (x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 x *XCMPLX-0K3 z"
sorry

mtheorem series_3_th_11:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((x +XCMPLX-0K2 y)+XCMPLX-0K2 z)^2SQUARE-1K1 >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 ((x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 x *XCMPLX-0K3 z)"
sorry

mtheorem series_3_th_12:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M >=XXREAL-0R2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
sorry

mtheorem series_3_th_13:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M >=XXREAL-0R2 (a *XCMPLX-0K3 b)*XCMPLX-0K3 c"
sorry

mtheorem series_3_th_14:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a /XCMPLX-0K7 b) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (b /XCMPLX-0K7 c) |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (c /XCMPLX-0K7 a) |^NEWTONK1 \<three>\<^sub>M >=XXREAL-0R2 (b /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 b)+XCMPLX-0K2 a /XCMPLX-0K7 c"
sorry

mtheorem series_3_th_15:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
sorry

mtheorem series_3_th_16:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)/XCMPLX-0K7 \<three>\<^sub>M >=XXREAL-0R2 \<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
sorry

mtheorem series_3_th_17:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 x *XCMPLX-0K3 z <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
sorry

mtheorem series_3_th_18:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y =COMPLEX1R1 \<one>\<^sub>M implies x *XCMPLX-0K3 y <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
sorry

mtheorem series_3_th_19:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y =COMPLEX1R1 \<one>\<^sub>M implies x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem series_3_th_20:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<nine>\<^sub>M"
sorry

mtheorem series_3_th_21:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y =COMPLEX1R1 \<one>\<^sub>M implies x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 y  |^NEWTONK1 \<three>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
sorry

mtheorem series_3_th_22:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem series_3_th_23:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies (a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<two>\<five>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
sorry

mtheorem series_3_th_24:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <=XXREAL-0R1 a implies x ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
sorry

mtheorem series_3_th_25:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| >=XXREAL-0R2 a implies x ^2SQUARE-1K1 >=XXREAL-0R2 a ^2SQUARE-1K1"
sorry

mtheorem series_3_th_26:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  |.COMPLEX1K10  |.COMPLEX1K10 x.| -XCMPLX-0K6  |.COMPLEX1K10 y.| .| <=XXREAL-0R1  |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|"
sorry

mtheorem series_3_th_27:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b)*XCMPLX-0K3 c =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)+XCMPLX-0K2 sqrtSQUARE-1K3 c"
sorry

mtheorem series_3_th_28:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((x >XXREAL-0R4 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6) & z <XXREAL-0R3 0NUMBERSK6) & (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 0NUMBERSK6 implies ((x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 y  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 z  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M >=XXREAL-0R2 \<six>\<^sub>M *XCMPLX-0K3 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 z  |^NEWTONK1 \<three>\<^sub>M)^2SQUARE-1K1"
sorry

mtheorem series_3_th_29:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M implies a to-powerPOWERK2 b +XCMPLX-0K2 a to-powerPOWERK2 c >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 a to-powerPOWERK2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
sorry

mtheorem series_3_th_30:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >=XXREAL-0R2 b & b >=XXREAL-0R2 c implies (a to-powerPOWERK2 a *XCMPLX-0K3 b to-powerPOWERK2 b)*XCMPLX-0K3 c to-powerPOWERK2 c >=XXREAL-0R2 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)to-powerPOWERK2 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)/XCMPLX-0K7 \<three>\<^sub>M)"
sorry

mtheorem series_3_th_31:
" for n be NatNAT-1M1 holds  for a be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1 holds  for b be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 ((n +NAT-1K1 \<two>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b"
sorry

mtheorem series_3_th_32:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
sorry

mtheorem series_3_th_33:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6)"
sorry

mtheorem series_3_th_34:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6)"
sorry

mtheorem series_3_th_35:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6"
sorry

mtheorem series_3_th_36:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6)"
sorry

mtheorem series_3_th_37:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 s .FUNCT-1K1 (n -XCMPLX-0K6 \<one>\<^sub>M)) implies (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem series_3_th_38:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 s .FUNCT-1K1 (n -XCMPLX-0K6 \<one>\<^sub>M)) implies (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem series_3_th_39:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem series_3_th_40:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6 & s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem series_3_th_41:
" for s be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem series_3_th_42:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mdef series_3_def_1 ("Partial-ProductSERIES-3K1  _ " [350]350 ) where
  mlet "s be Real-SequenceSEQ-1M1"
"func Partial-ProductSERIES-3K1 s \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it. it .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st it .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds (it1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) & (it2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem series_3_th_43:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem series_3_th_44:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem series_3_th_45:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M)"
sorry

mtheorem series_3_th_46:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M)"
sorry

mtheorem series_3_th_47:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 Partial-ProductSERIES-3K1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-ProductSERIES-3K1 (s1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> s2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem series_3_th_48:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<four>\<^sub>M)"
sorry

mlemma series_3_lm_8:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6)"
sorry

mtheorem series_3_th_49:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds (s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds \<one>\<^sub>M +XCMPLX-0K2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-ProductSERIES-3K1 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mlemma series_3_lm_9:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6)"
sorry

mtheorem series_3_th_50:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds \<one>\<^sub>M +XCMPLX-0K2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-ProductSERIES-3K1 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem series_3_th_51:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds  for s3 be Real-SequenceSEQ-1M1 holds  for s4 be Real-SequenceSEQ-1M1 holds  for s5 be Real-SequenceSEQ-1M1 holds (s3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 & s4 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) & s5 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 implies ( for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 s3 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)^2SQUARE-1K1 <=XXREAL-0R1 Partial-SumsSERIES-1K3 s4 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Partial-SumsSERIES-1K3 s5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mlemma series_3_lm_10:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)^2SQUARE-1K1) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem series_3_th_52:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds  for s3 be Real-SequenceSEQ-1M1 holds  for s4 be Real-SequenceSEQ-1M1 holds  for s5 be Real-SequenceSEQ-1M1 holds (s4 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & s5 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2) & ( for n be NatNAT-1M1 holds (s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) & s3 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)^2SQUARE-1K1) implies ( for n be NatNAT-1M1 holds sqrtSQUARE-1K3 (Partial-SumsSERIES-1K3 s3 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) <=XXREAL-0R1 sqrtSQUARE-1K3 (Partial-SumsSERIES-1K3 s4 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 sqrtSQUARE-1K3 (Partial-SumsSERIES-1K3 s5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mlemma series_3_lm_11:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) implies (n +NAT-1K1 \<one>\<^sub>M)-rootPOWERK1 (Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma series_3_lm_12:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 s .FUNCT-1K1 (n -XCMPLX-0K6 \<one>\<^sub>M)) implies (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem series_3_th_53:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 s .FUNCT-1K1 (n -XCMPLX-0K6 \<one>\<^sub>M)) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)-rootPOWERK1 (Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

end
