theory cfunct_1
  imports rfunct_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, X, Y for "setHIDDENM2"
reserve C for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c for "ElementSUBSET-1M1-of C"
reserve f, f1, f2, f3, g, g1 for "PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
reserve r1, r2, p1 for "RealXREAL-0M1"
reserve r, q, cr1, cr2 for "ComplexXCMPLX-0M1"
mdef cfunct_1_def_1 (" _ '/CFUNCT-1K1\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)", "f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
"func f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 \<rightarrow> PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) means
  \<lambda>it. domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
sorry
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(C)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it1 implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) & (domRELSET-1K1\<^bsub>(C)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it2 implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef cfunct_1_def_2 (" _ ^CFUNCT-1K2\<^bsub>'( _ ')\<^esub>" [164,0]164 ) where
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
"func f ^CFUNCT-1K2\<^bsub>(C)\<^esub> \<rightarrow> PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) means
  \<lambda>it. domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(C)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)"
sorry
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(C)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it1 implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) & (domRELSET-1K1\<^bsub>(C)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> it2 implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem cfunct_1_th_1:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
sorry

mtheorem cfunct_1_th_2:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
sorry

mtheorem cfunct_1_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
sorry

mtheorem cfunct_1_th_4:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
sorry

mtheorem cfunct_1_th_5:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)"
sorry

mlemma cfunct_1_lm_1:
" for x be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds x inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y iff x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x inTARSKIR2 Y"
  using partfun2_th_26 sorry

mtheorem cfunct_1_th_6:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g & domRELSET-1K1\<^bsub>(C)\<^esub> g /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g \\SUBSET-1K7\<^bsub>(C)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem cfunct_1_th_7:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) \\SUBSET-1K7\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELSET-1K1\<^bsub>(C)\<^esub> f1 \\SUBSET-1K7\<^bsub>(C)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 })"
sorry

mtheorem cfunct_1_th_8:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem cfunct_1_th_9:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem cfunct_1_th_10:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)\<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem cfunct_1_th_11:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(C)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>))"
sorry

mtheorem cfunct_1_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

(*begin*)
mtheorem cfunct_1_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
sorry

mtheorem cfunct_1_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3)"
sorry

mtheorem cfunct_1_th_15:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
sorry

mtheorem cfunct_1_th_16:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
  using cfunct_1_th_15 sorry

mtheorem cfunct_1_th_17:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
sorry

mtheorem cfunct_1_th_18:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2)"
sorry

mtheorem cfunct_1_th_19:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
sorry

mtheorem cfunct_1_th_20:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f3 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
  using cfunct_1_th_19 sorry

mtheorem cfunct_1_th_21:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
sorry

mtheorem cfunct_1_th_22:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds  for q be ComplexXCMPLX-0M1 holds (r *XCMPLX-0K3 q)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)"
sorry

mtheorem cfunct_1_th_23:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2"
sorry

mtheorem cfunct_1_th_24:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
sorry

mtheorem cfunct_1_th_25:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
sorry

mtheorem cfunct_1_th_26:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds 1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f"
sorry

mtheorem cfunct_1_th_27:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)+VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
sorry

mtheorem cfunct_1_th_28:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f3 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)-VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f3"
sorry

mtheorem cfunct_1_th_29:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)(#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
sorry

mtheorem cfunct_1_th_30:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)"
sorry

mtheorem cfunct_1_th_31:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f"
  using complex1_def_4 sorry

(*\$CT*)
mtheorem cfunct_1_th_33:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
   sorry

mtheorem cfunct_1_th_34:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
sorry

mtheorem cfunct_1_th_35:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
sorry

mtheorem cfunct_1_th_36:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
sorry

mlemma cfunct_1_lm_2:
"(-XCMPLX-0K4 1rCOMPLEX1K7)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 1rCOMPLEX1K7"
  using complex1_def_4 sorry

mtheorem cfunct_1_th_37:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
  using cfunct_1_lm_2 cfunct_1_th_36 complex1_def_4 sorry

mtheorem cfunct_1_th_38:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|)^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f ^CFUNCT-1K2\<^bsub>(C)\<^esub> .|"
sorry

mtheorem cfunct_1_th_39:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
sorry

mtheorem cfunct_1_th_40:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g /CFUNCT-1K1\<^bsub>(C)\<^esub> f) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
sorry

mtheorem cfunct_1_th_41:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g ^CFUNCT-1K2\<^bsub>(C)\<^esub>)"
sorry

mtheorem cfunct_1_th_42:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)(#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1)"
sorry

mtheorem cfunct_1_th_43:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)^CFUNCT-1K2\<^bsub>(C)\<^esub> =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>) /CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
sorry

mtheorem cfunct_1_th_44:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)/CFUNCT-1K1\<^bsub>(C)\<^esub> f2"
sorry

mtheorem cfunct_1_th_45:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds g /CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> f1"
sorry

mtheorem cfunct_1_th_46:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> g & f /CFUNCT-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> g) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f /CFUNCT-1K1\<^bsub>(C)\<^esub> g"
sorry

mtheorem cfunct_1_th_47:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f & f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /CFUNCT-1K1\<^bsub>(C)\<^esub> f =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/CFUNCT-1K1\<^bsub>(C)\<^esub> f"
sorry

mtheorem cfunct_1_th_48:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
sorry

mtheorem cfunct_1_th_49:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f /CFUNCT-1K1\<^bsub>(C)\<^esub> g)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g1) =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (g1 ^CFUNCT-1K2\<^bsub>(C)\<^esub>))/CFUNCT-1K1\<^bsub>(C)\<^esub> (g (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1)"
sorry

mtheorem cfunct_1_th_50:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for g1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 /CFUNCT-1K1\<^bsub>(C)\<^esub> g =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/CFUNCT-1K1\<^bsub>(C)\<^esub> (f (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> g)"
sorry

mtheorem cfunct_1_th_51:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 .| =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1.|)/RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f2.|)"
sorry

mtheorem cfunct_1_th_52:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
sorry

mtheorem cfunct_1_th_53:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
sorry

mtheorem cfunct_1_th_54:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(C)\<^esub>) & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X.|"
sorry

mtheorem cfunct_1_th_55:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
sorry

mtheorem cfunct_1_th_56:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X & (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) & (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
sorry

mtheorem cfunct_1_th_57:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X =RELSET-1R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X"
sorry

(*begin*)
mtheorem cfunct_1_th_58:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
sorry

mtheorem cfunct_1_th_59:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using cfunct_1_th_4 sorry

mtheorem cfunct_1_th_60:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff -VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using cfunct_1_th_59 sorry

mtheorem cfunct_1_th_61:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using valued_1_def_11 sorry

mtheorem cfunct_1_th_62:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
sorry

mtheorem cfunct_1_th_63:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
sorry

mtheorem cfunct_1_th_64:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
sorry

mtheorem cfunct_1_th_65:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 r *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
sorry

mtheorem cfunct_1_th_66:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|).FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.|"
sorry

mtheorem cfunct_1_th_67:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f ^CFUNCT-1K2\<^bsub>(C)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
  using cfunct_1_def_2 sorry

mtheorem cfunct_1_th_68:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 ^CFUNCT-1K2\<^bsub>(C)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 /CFUNCT-1K1\<^bsub>(C)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =COMPLEX1R1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c)\<inverse>XCMPLX-0K5"
sorry

(*begin*)
mlemma cfunct_1_lm_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6 iff f be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_69:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 iff ( ex p be RealXREAL-0M1 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c.| <=XXREAL-0R1 p)"
sorry

mtheorem cfunct_1_th_70:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds Y c=TARSKIR1 X & f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_71:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_72:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for r be ComplexXCMPLX-0M1 holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_73:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2"
sorry

mtheorem cfunct_1_th_74:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6 & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_76:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_77:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X \\/XBOOLE-0K2 Y) be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_78:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be constantFUNCT-1V5 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ((f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & (f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
sorry

mtheorem cfunct_1_th_79:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for q be ComplexXCMPLX-0M1 holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (q (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
sorry

mtheorem cfunct_1_th_80:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5"
sorry

mtheorem cfunct_1_th_81:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_82:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (( for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K27\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1) & (-VALUED-1K33\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be boundedCOMSEQ-2V1) & ( |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.|) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
sorry

mtheorem cfunct_1_th_83:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K2\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_84:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds f1  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> X be boundedCOMSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> Y be constantFUNCT-1V5 implies ((f1 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1 & (f2 -VALUED-1K48\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1) & (f1 (#)VALUED-1K20\<^bsub>(C,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedCOMSEQ-2V1"
sorry

mtheorem cfunct_1_th_85:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  |.VALUED-1K58\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> f.| be boundedSEQ-2V6 iff f be boundedCOMSEQ-2V1"
  using cfunct_1_lm_3 sorry

mtheorem cfunct_1_ident_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,D)", "c be ComplexXCMPLX-0M1"
"identify f /.PARTFUN1K7\<^bsub>(D)\<^esub> c with f .FUNCT-1K1 c"
proof
(*compatibility*)
  show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 f .FUNCT-1K1 c"
sorry
qed "sorry"

end
