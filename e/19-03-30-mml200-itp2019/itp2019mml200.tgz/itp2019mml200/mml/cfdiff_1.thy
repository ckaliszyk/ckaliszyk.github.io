theory cfdiff_1
  imports cfcont_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, k1, n, n1, m for "NatNAT-1M1"
reserve X, y for "setHIDDENM2"
reserve p for "RealXREAL-0M1"
reserve r for "RealXREAL-0M1"
reserve a, a1, a2, b, b1, b2, x, x0, z, z0 for "ComplexXCMPLX-0M1"
reserve s1, s3, seq, seq1 for "Complex-SequenceCOMSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
reserve Nseq for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mdef cfdiff_1_def_1 (" _ -convergentCFDIFF-1V1" [70]70 ) where
  mlet "x be RealXREAL-0M1"
"attr x -convergentCFDIFF-1V1 for Complex-SequenceCOMSEQ-1M1 means
  (\<lambda>IT. IT be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 IT =COMPLEX1R1 x)"..

mtheorem cfdiff_1_th_1:
" for rs be Real-SequenceSEQ-1M1 holds  for cs be Complex-SequenceCOMSEQ-1M1 holds rs =FUNCT-2R1\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> cs & rs be convergentCOMSEQ-2V3 implies cs be convergentCOMSEQ-2V3"
   sorry

mdef cfdiff_1_def_2 ("InvShiftCFDIFF-1K1  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func InvShiftCFDIFF-1K1 r \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem cfdiff_1_th_2:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies InvShiftCFDIFF-1K1 r be convergentCOMSEQ-2V3"
sorry

mtheorem cfdiff_1_cl_1:
  mlet "r be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster InvShiftCFDIFF-1K1 r as-term-is convergentCOMSEQ-2V3"
proof
(*coherence*)
  show "InvShiftCFDIFF-1K1 r be convergentCOMSEQ-2V3"
    using cfdiff_1_th_2 sorry
qed "sorry"

mtheorem cfdiff_1_th_3:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies limCOMSEQ-2K3 (InvShiftCFDIFF-1K1 r) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem cfdiff_1_cl_2:
  mlet "r be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster InvShiftCFDIFF-1K1 r as-term-is non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentCFDIFF-1V1"
proof
(*coherence*)
  show "InvShiftCFDIFF-1K1 r be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentCFDIFF-1V1"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_3:
"cluster 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_4:
"cluster 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9 also-is convergentCOMSEQ-2V3 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9 implies it be convergentCOMSEQ-2V3"
     sorry
qed "sorry"

mtheorem cfdiff_1_cl_5:
"cluster constantVALUED-0V15 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be constantVALUED-0V15"
sorry
qed "sorry"

mtheorem cfdiff_1_th_4:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m)"
sorry

mtheorem cfdiff_1_th_5:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  for n be NatNAT-1M1 holds (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
sorry

reserve h for "0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
reserve c for "constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1"
mdef cfdiff_1_def_3 ("RestFunc-likeCFDIFF-1V2" 70 ) where
"attr RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  (\<lambda>IT.  for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0NUMBERSK6)"..

mtheorem cfdiff_1_cl_6:
"cluster totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

syntax CFDIFF_1M1 :: "Ty" ("C-RestFuncCFDIFF-1M1" 70)
translations "C-RestFuncCFDIFF-1M1" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2\<bar>PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"

mdef cfdiff_1_def_4 ("linearCFDIFF-1V3" 70 ) where
"attr linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  (\<lambda>IT.  ex a be ComplexXCMPLX-0M1 st  for z be ComplexXCMPLX-0M1 holds IT /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a *XCMPLX-0K3 z)"..

mtheorem cfdiff_1_cl_7:
"cluster totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
sorry
qed "sorry"

syntax CFDIFF_1M2 :: "Ty" ("C-LinearFuncCFDIFF-1M2" 70)
translations "C-LinearFuncCFDIFF-1M2" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3\<bar>PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"

reserve R, R1, R2 for "C-RestFuncCFDIFF-1M1"
reserve L, L1, L2 for "C-LinearFuncCFDIFF-1M2"
mtheorem cfdiff_1_cl_8:
  mlet "L1 be C-LinearFuncCFDIFF-1M2", "L2 be C-LinearFuncCFDIFF-1M2"
"cluster L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_9:
  mlet "L1 be C-LinearFuncCFDIFF-1M2", "L2 be C-LinearFuncCFDIFF-1M2"
"cluster L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_10:
  mlet "a be ComplexXCMPLX-0M1", "L be C-LinearFuncCFDIFF-1M2"
"cluster a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_11:
  mlet "R1 be C-RestFuncCFDIFF-1M1", "R2 be C-RestFuncCFDIFF-1M1"
"cluster R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_12:
  mlet "R1 be C-RestFuncCFDIFF-1M1", "R2 be C-RestFuncCFDIFF-1M1"
"cluster R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_13:
  mlet "R1 be C-RestFuncCFDIFF-1M1", "R2 be C-RestFuncCFDIFF-1M1"
"cluster R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_14:
  mlet "a be ComplexXCMPLX-0M1", "R be C-RestFuncCFDIFF-1M1"
"cluster a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_15:
  mlet "L1 be C-LinearFuncCFDIFF-1M2", "L2 be C-LinearFuncCFDIFF-1M2"
"cluster L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_16:
  mlet "R be C-RestFuncCFDIFF-1M1", "L be C-LinearFuncCFDIFF-1M2"
"cluster R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_17:
  mlet "R be C-RestFuncCFDIFF-1M1", "L be C-LinearFuncCFDIFF-1M2"
"cluster L (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
     sorry
qed "sorry"

mdef cfdiff_1_def_5 ("NeighbourhoodCFDIFF-1M3-of  _ " [70]70 ) where
  mlet "z0 be ComplexXCMPLX-0M1"
"mode NeighbourhoodCFDIFF-1M3-of z0 \<rightarrow> SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 means
  (\<lambda>it.  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 it)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 st  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 it"
sorry
qed "sorry"

mtheorem cfdiff_1_th_6:
" for z0 be ComplexXCMPLX-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } be NeighbourhoodCFDIFF-1M3-of z0"
sorry

mtheorem cfdiff_1_th_7:
" for z0 be ComplexXCMPLX-0M1 holds  for N be NeighbourhoodCFDIFF-1M3-of z0 holds z0 inHIDDENR3 N"
sorry

mlemma cfdiff_1_lm_1:
" for z0 be ComplexXCMPLX-0M1 holds  for N1 be NeighbourhoodCFDIFF-1M3-of z0 holds  for N2 be NeighbourhoodCFDIFF-1M3-of z0 holds  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 N1 & N c=TARSKIR1 N2"
sorry

mdef cfdiff_1_def_6 (" _ is-differentiable-inCFDIFF-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "z0 be ComplexXCMPLX-0M1"
"pred f is-differentiable-inCFDIFF-1R1 z0 means
   ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0))"..

mdef cfdiff_1_def_7 ("diffCFDIFF-1K2'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "z0 be ComplexXCMPLX-0M1"
"assume f is-differentiable-inCFDIFF-1R1 z0 func diffCFDIFF-1K2(f,z0) \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 means
  \<lambda>it.  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))"
proof-
  (*existence*)
    show "f is-differentiable-inCFDIFF-1R1 z0 implies ( ex it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0))))"
sorry
  (*uniqueness*)
    show "f is-differentiable-inCFDIFF-1R1 z0 implies ( for it1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for it2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it1 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) & ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it2 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef cfdiff_1_def_8 ("differentiableCFDIFF-1V4" 70 ) where
"attr differentiableCFDIFF-1V4 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  (\<lambda>f.  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f is-differentiable-inCFDIFF-1R1 x)"..

mdef cfdiff_1_def_9 (" _ is-differentiable-onCFDIFF-1R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "X be setHIDDENM2"
"pred f is-differentiable-onCFDIFF-1R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X be differentiableCFDIFF-1V4"..

mtheorem cfdiff_1_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 X implies X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
  using xboole_1_th_1 sorry

mdef cfdiff_1_def_10 ("closedCFDIFF-1V5" 70 ) where
"attr closedCFDIFF-1V5 for SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 means
  (\<lambda>X.  for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 s1 inHIDDENR3 X)"..

mdef cfdiff_1_def_11 ("openCFDIFF-1V6" 70 ) where
"attr openCFDIFF-1V6 for SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 means
  (\<lambda>X. X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> be closedCFDIFF-1V5)"..

mtheorem cfdiff_1_th_9:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 implies ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 X))"
sorry

mtheorem cfdiff_1_th_10:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 implies ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex g be RealXREAL-0M1 st {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 X))"
sorry

mtheorem cfdiff_1_th_11:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 X)) implies X be openCFDIFF-1V6"
sorry

mtheorem cfdiff_1_th_12:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 iff ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of x st N c=TARSKIR1 X))"
  using cfdiff_1_th_9 cfdiff_1_th_11 sorry

mtheorem cfdiff_1_th_13:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for z0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for r be RealXREAL-0M1 holds X =HIDDENR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 r } implies X be openCFDIFF-1V6"
sorry

mtheorem cfdiff_1_th_14:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for z0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for r be RealXREAL-0M1 holds X =HIDDENR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <=XXREAL-0R1 r } implies X be closedCFDIFF-1V5"
sorry

mtheorem cfdiff_1_cl_18:
"cluster openCFDIFF-1V6 for SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 st it be openCFDIFF-1V6"
sorry
qed "sorry"

reserve Z for "openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
mtheorem cfdiff_1_th_15:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds f is-differentiable-onCFDIFF-1R2 Z iff Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x)"
sorry

mtheorem cfdiff_1_th_16:
" for Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 Y implies Y be openCFDIFF-1V6"
sorry

mdef cfdiff_1_def_12 (" _ `|CFDIFF-1K3  _ " [164,164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "X be setHIDDENM2"
"assume f is-differentiable-onCFDIFF-1R2 X func f `|CFDIFF-1K3 X \<rightarrow> PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it. domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))"
proof-
  (*existence*)
    show "f is-differentiable-onCFDIFF-1R2 X implies ( ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)))"
sorry
  (*uniqueness*)
    show "f is-differentiable-onCFDIFF-1R2 X implies ( for it1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it1 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))) & (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it2 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem cfdiff_1_th_17:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex a1 be ComplexXCMPLX-0M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 {TARSKIK1 a1}) implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 0cCOMPLEX1K6)"
sorry

mtheorem cfdiff_1_cl_19:
  mlet "seq be non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1", "k be NatNAT-1M1"
"cluster seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k as-term-is non-zeroORDINAL1V9"
proof
(*coherence*)
  show "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
sorry
qed "sorry"

mtheorem cfdiff_1_cl_20:
  mlet "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1", "n be NatNAT-1M1"
"cluster h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n as-term-is 0NUMBERSK6 -convergentCFDIFF-1V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies it be 0NUMBERSK6 -convergentCFDIFF-1V1"
sorry
qed "sorry"

mtheorem cfdiff_1_th_18:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
sorry

mtheorem cfdiff_1_th_19:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
sorry

mtheorem cfdiff_1_th_20:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
sorry

mtheorem cfdiff_1_th_21:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
sorry

mtheorem cfdiff_1_th_22:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds  for N be NeighbourhoodCFDIFF-1M3-of x0 holds f is-differentiable-inCFDIFF-1R1 x0 & N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies ( for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds  for c be constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 N implies h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) be convergentCOMSEQ-2V3 & diffCFDIFF-1K2(f,x0) =COMPLEX1R1 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)))"
sorry

mtheorem cfdiff_1_th_23:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =COMPLEX1R1 diffCFDIFF-1K2(f1,x0) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x0)"
sorry

mtheorem cfdiff_1_th_24:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =COMPLEX1R1 diffCFDIFF-1K2(f1,x0) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x0)"
sorry

mtheorem cfdiff_1_th_25:
" for a be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f is-differentiable-inCFDIFF-1R1 x0 implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f,x0) =COMPLEX1R1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x0))"
sorry

mtheorem cfdiff_1_th_26:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x0)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x0))"
sorry

mtheorem cfdiff_1_th_27:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z =FUNCT-1R1 idPARTFUN1K6 Z implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 1rCOMPLEX1K7)"
sorry

mtheorem cfdiff_1_th_28:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & f1 is-differentiable-onCFDIFF-1R2 Z) & f2 is-differentiable-onCFDIFF-1R2 Z implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x))"
sorry

mtheorem cfdiff_1_th_29:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & f1 is-differentiable-onCFDIFF-1R2 Z) & f2 is-differentiable-onCFDIFF-1R2 Z implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x))"
sorry

mtheorem cfdiff_1_th_30:
" for a be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) & f is-differentiable-onCFDIFF-1R2 Z implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x)))"
sorry

mtheorem cfdiff_1_th_31:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & f1 is-differentiable-onCFDIFF-1R2 Z) & f2 is-differentiable-onCFDIFF-1R2 Z implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x)))"
sorry

mtheorem cfdiff_1_th_32:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be constantFUNCT-1V5 implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 0cCOMPLEX1K6)"
sorry

mtheorem cfdiff_1_th_33:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a)"
sorry

mtheorem cfdiff_1_th_34:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f is-differentiable-inCFDIFF-1R1 x0 implies f is-continuous-inCFCONT-1R1 x0"
sorry

mtheorem cfdiff_1_th_35:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 X implies f is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfdiff_1_th_36:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds f is-differentiable-onCFDIFF-1R2 X & Z c=TARSKIR1 X implies f is-differentiable-onCFDIFF-1R2 Z"
sorry

(*\$CT*)
mtheorem cfdiff_1_th_38:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-inCFDIFF-1R1 x0 implies ( ex R be C-RestFuncCFDIFF-1M1 st R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0cCOMPLEX1K6 & R is-continuous-inCFCONT-1R1 0cCOMPLEX1K6)"
sorry

end
