theory pzfmisc1
  imports mboolean enumset1
begin
(*begin*)
reserve i for "objectHIDDENM1"
reserve I for "setHIDDENM2"
reserve f for "FunctionFUNCT-1M1"
reserve x, x1, x2, y, A, B, X, Y, Z for "ManySortedSetPBOOLEM1-of I"
mtheorem pzfmisc1_th_1:
" for i be objectHIDDENM1 holds  for I be setHIDDENM2 holds  for X be objectHIDDENM1 holds  for M be ManySortedSetPBOOLEM1-of I holds i inHIDDENR3 I implies domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =XBOOLE-0R4 I"
sorry

mtheorem pzfmisc1_th_2:
" for f be FunctionFUNCT-1M1 holds f =XBOOLE-0R4 {}XBOOLE-0K1 implies f be ManySortedSetPBOOLEM1-of {}XBOOLE-0K1"
  using partfun1_def_2 relat_1_th_38 relat_1_def_18 sorry

mtheorem pzfmisc1_th_3:
" for I be setHIDDENM2 holds I be  non emptyXBOOLE-0V1 implies  not ( ex X be ManySortedSetPBOOLEM1-of I st X be empty-yieldingRELAT-1V3 & X be non-emptyRELAT-1V2)"
sorry

(*begin*)
mdef pzfmisc1_def_1 ("{PZFMISC1K1\<^bsub>'( _ ')\<^esub>  _ }" [0,0]356 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"func {PZFMISC1K1\<^bsub>(I)\<^esub> A} \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
sorry
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem pzfmisc1_cl_1:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"cluster {PZFMISC1K1\<^bsub>(I)\<^esub> A} as-term-is non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mdef pzfmisc1_def_2 ("{PZFMISC1K2\<^bsub>'( _ ')\<^esub> _ , _ }" [0,0,0]356 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"func {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
sorry
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem PZFMISC1K2_commutativity:
  mlet "I be setHIDDENM2"
" for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> B,A }"
sorry

mtheorem pzfmisc1_cl_2:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"cluster {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } as-term-is non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem pzfmisc1_th_4:
" for I be setHIDDENM2 holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} iff ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> y)"
sorry

mtheorem pzfmisc1_th_5:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2) implies X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
sorry

mtheorem pzfmisc1_th_6:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies ( for x be ManySortedSetPBOOLEM1-of I holds x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2 implies x inPBOOLER1\<^bsub>(I)\<^esub> X)"
sorry

mtheorem pzfmisc1_th_7:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies x =PBOOLER7\<^bsub>(I)\<^esub> A"
sorry

mtheorem pzfmisc1_th_8:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
sorry

mtheorem pzfmisc1_th_9:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x =PBOOLER7\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
sorry

mtheorem pzfmisc1_th_10:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
sorry

mtheorem pzfmisc1_th_11:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,x } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
sorry

mtheorem pzfmisc1_th_12:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} implies A =PBOOLER7\<^bsub>(I)\<^esub> B"
sorry

mtheorem pzfmisc1_th_13:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
sorry

mtheorem pzfmisc1_th_14:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies x =PBOOLER7\<^bsub>(I)\<^esub> A & x =PBOOLER7\<^bsub>(I)\<^esub> B"
sorry

mtheorem pzfmisc1_th_15:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies A =PBOOLER7\<^bsub>(I)\<^esub> B"
sorry

mtheorem pzfmisc1_th_16:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } & {PZFMISC1K1\<^bsub>(I)\<^esub> y} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
sorry

mtheorem pzfmisc1_th_17:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
sorry

mtheorem pzfmisc1_th_18:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
sorry

mtheorem pzfmisc1_th_19:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x <>HIDDENR2 y"
sorry

mtheorem pzfmisc1_th_20:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
sorry

mtheorem pzfmisc1_th_21:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
sorry

mtheorem pzfmisc1_th_22:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x <>HIDDENR2 y"
sorry

mtheorem pzfmisc1_th_23:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
sorry

mtheorem pzfmisc1_th_24:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem pzfmisc1_th_25:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
sorry

mtheorem pzfmisc1_th_26:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies x =PBOOLER7\<^bsub>(I)\<^esub> A & y =PBOOLER7\<^bsub>(I)\<^esub> A"
sorry

mtheorem pzfmisc1_th_27:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
sorry

mtheorem pzfmisc1_th_28:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} }"
sorry

mtheorem pzfmisc1_th_29:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
sorry

mtheorem pzfmisc1_th_30:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> x"
sorry

mtheorem pzfmisc1_th_31:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
sorry

mtheorem pzfmisc1_th_32:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } =PBOOLER7\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
sorry

mtheorem pzfmisc1_th_33:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_34:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X iff x1 inPBOOLER1\<^bsub>(I)\<^esub> X & x2 inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_35:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds ((A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies A c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
sorry

(*begin*)
mtheorem pzfmisc1_th_36:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}"
sorry

mtheorem pzfmisc1_th_37:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B iff x inPBOOLER1\<^bsub>(I)\<^esub> B & A c=PBOOLER2\<^bsub>(I)\<^esub> B"
sorry

mtheorem pzfmisc1_th_38:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_39:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_40:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A iff x inPBOOLER1\<^bsub>(I)\<^esub> A & y inPBOOLER1\<^bsub>(I)\<^esub> A"
sorry

mtheorem pzfmisc1_th_41:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X <>HIDDENR2 EmptyMSPBOOLEK1 I"
sorry

mtheorem pzfmisc1_th_42:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X <>HIDDENR2 EmptyMSPBOOLEK1 I"
sorry

(*begin*)
mtheorem pzfmisc1_th_43:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_44:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
sorry

mtheorem pzfmisc1_th_45:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X iff {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
sorry

mtheorem pzfmisc1_th_46:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_47:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X &  not y inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

(*begin*)
mtheorem pzfmisc1_th_48:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies y inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_49:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies y <>HIDDENR2 x"
sorry

mtheorem pzfmisc1_th_50:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> X implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_51:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_52:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I iff x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_53:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_54:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X &  not y inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_55:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I iff x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X"
sorry

mtheorem pzfmisc1_th_56:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ((X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

(*begin*)
mtheorem pzfmisc1_th_57:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem pzfmisc1_th_58:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X be non-emptyRELAT-1V2 & Y be non-emptyRELAT-1V2) & [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
sorry

mtheorem pzfmisc1_th_59:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Y |] implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
sorry

mtheorem pzfmisc1_th_60:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z be non-emptyRELAT-1V2 & ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] or [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]) implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
sorry

mtheorem pzfmisc1_th_61:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
sorry

mtheorem pzfmisc1_th_62:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 c=PBOOLER2\<^bsub>(I)\<^esub> A & x2 c=PBOOLER2\<^bsub>(I)\<^esub> B implies [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
sorry

mtheorem pzfmisc1_th_63:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
sorry

mtheorem pzfmisc1_th_64:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]"
sorry

mtheorem pzfmisc1_th_65:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]) & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])"
sorry

mtheorem pzfmisc1_th_66:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])"
sorry

mtheorem pzfmisc1_th_67:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> X & B c=PBOOLER2\<^bsub>(I)\<^esub> Y implies ([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |]) =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
sorry

mtheorem pzfmisc1_th_68:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
sorry

mtheorem pzfmisc1_th_69:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]"
sorry

mtheorem pzfmisc1_th_70:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem pzfmisc1_th_71:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 implies [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] be non-emptyRELAT-1V2"
sorry

mtheorem pzfmisc1_th_72:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |] & [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]"
sorry

mtheorem pzfmisc1_th_73:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds (x1 be non-emptyRELAT-1V2 & A be non-emptyRELAT-1V2) & [|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |] implies x1 =PBOOLER7\<^bsub>(I)\<^esub> x2 & A =PBOOLER7\<^bsub>(I)\<^esub> B"
sorry

mtheorem pzfmisc1_th_74:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem pzfmisc1_th_75:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x,y |] & A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X,y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]"
sorry

mtheorem pzfmisc1_th_76:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |] & [|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] be non-emptyRELAT-1V2 implies x c=PBOOLER2\<^bsub>(I)\<^esub> y & X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
sorry

mtheorem pzfmisc1_th_77:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> X implies [|PBOOLEK6\<^bsub>(I)\<^esub> A,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]"
sorry

mtheorem pzfmisc1_th_78:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
sorry

mtheorem pzfmisc1_th_79:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A be non-emptyRELAT-1V2 & ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or [|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) implies B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
sorry

mtheorem pzfmisc1_th_80:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] & y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X,B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]"
sorry

(*begin*)
mdef pzfmisc1_def_3 (" _ is-transformable-toPZFMISC1R1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"pred A is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B means
   for i be setHIDDENM2 holds i inTARSKIR2 I implies (B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1 implies A .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1)"..

mtheorem PZFMISC1R1_reflexivity:
  mlet "I be setHIDDENM2"
" for B be ManySortedSetPBOOLEM1-of I holds B is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B"
sorry

end
