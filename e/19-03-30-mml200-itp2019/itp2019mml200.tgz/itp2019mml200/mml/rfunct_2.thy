theory rfunct_2
  imports partfun2 rcomp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, X, Y for "setHIDDENM2"
reserve g, r, r1, r2, p, p1, p2 for "RealXREAL-0M1"
reserve R for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve seq, seq1, seq2, seq3 for "Real-SequenceSEQ-1M1"
reserve Ns for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
reserve n for "NatNAT-1M1"
reserve W for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem rfunct_2_th_1:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 iff ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n)"
sorry

mtheorem rfunct_2_th_2:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns) & (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
sorry

mtheorem rfunct_2_th_3:
" for p be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
sorry

mtheorem rfunct_2_th_4:
" for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
sorry

mtheorem rfunct_2_th_5:
" for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
sorry

mtheorem rfunct_2_th_6:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
sorry

mtheorem rfunct_2_th_7:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6) implies limSEQ-2K1 seq <=XXREAL-0R1 0NUMBERSK6"
sorry

mtheorem rfunct_2_th_8:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2 implies ((h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) & (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
sorry

mtheorem rfunct_2_th_9:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds  for r be RealXREAL-0M1 holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h implies (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
sorry

mtheorem rfunct_2_th_10:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
sorry

mtheorem rfunct_2_th_11:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) implies h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq be non-zeroORDINAL1V9"
sorry

mtheorem rfunct_2_th_12:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) implies (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
sorry

mtheorem rfunct_2_th_13:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds h1 be totalPARTFUN1V1\<^bsub>(W)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(W)\<^esub> implies ((h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) & (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
sorry

mtheorem rfunct_2_th_14:
" for r be RealXREAL-0M1 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds h be totalPARTFUN1V1\<^bsub>(W)\<^esub> implies (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
sorry

mtheorem rfunct_2_th_15:
" for X be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
sorry

mtheorem rfunct_2_th_16:
" for X be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) & h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
sorry

mtheorem rfunct_2_cl_1:
  mlet "Z be setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
"cluster f  |RELAT-1K8 Z as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f  |RELAT-1K8 Z be one-to-oneFUNCT-1V2"
    using funct_1_th_52 sorry
qed "sorry"

mtheorem rfunct_2_th_17:
" for X be setHIDDENM2 holds  for h be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1 holds (h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 =FUNCT-1R1 h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)"
sorry

mtheorem rfunct_2_th_18:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) implies h be constantFUNCT-1V5"
sorry

mtheorem rfunct_2_th_19:
" for Y be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) =COMPLEX1R1 lower-boundSEQ-4K3 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) implies h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
sorry

reserve e1, e2 for "ExtRealXXREAL-0M1"
reserve h, h1, h2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
abbreviation(input) RFUNCT_2V1("increasingRFUNCT-2V1" 70) where
  "increasingRFUNCT-2V1 \<equiv> increasingVALUED-0V9"

mtheorem rfunct_2_def_1:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr increasingRFUNCT-2V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be increasingRFUNCT-2V1 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
sorry
qed "sorry"

abbreviation(input) RFUNCT_2V2("decreasingRFUNCT-2V2" 70) where
  "decreasingRFUNCT-2V2 \<equiv> decreasingVALUED-0V10"

mtheorem rfunct_2_def_2:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr decreasingRFUNCT-2V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be decreasingRFUNCT-2V2 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
sorry
qed "sorry"

abbreviation(input) RFUNCT_2V3("non-decreasingRFUNCT-2V3" 70) where
  "non-decreasingRFUNCT-2V3 \<equiv> non-decreasingVALUED-0V11"

mtheorem rfunct_2_def_3:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr non-decreasingRFUNCT-2V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
sorry
qed "sorry"

abbreviation(input) RFUNCT_2V4("non-increasingRFUNCT-2V4" 70) where
  "non-increasingRFUNCT-2V4 \<equiv> non-increasingVALUED-0V12"

mtheorem rfunct_2_def_4:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr non-increasingRFUNCT-2V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
sorry
qed "sorry"

mtheorem rfunct_2_th_20:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
sorry

mtheorem rfunct_2_th_21:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
sorry

mtheorem rfunct_2_th_22:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
sorry

mtheorem rfunct_2_th_23:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
sorry

mdef rfunct_2_def_5 ("monotoneRFUNCT-2V5" 70 ) where
"attr monotoneRFUNCT-2V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h. h be non-decreasingRFUNCT-2V3 or h be non-increasingRFUNCT-2V4)"..

mtheorem rfunct_2_cl_2:
"cluster non-decreasingRFUNCT-2V3 also-is monotoneRFUNCT-2V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be non-decreasingRFUNCT-2V3 implies it be monotoneRFUNCT-2V5"
     sorry
qed "sorry"

mtheorem rfunct_2_cl_3:
"cluster non-increasingRFUNCT-2V4 also-is monotoneRFUNCT-2V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be non-increasingRFUNCT-2V4 implies it be monotoneRFUNCT-2V5"
     sorry
qed "sorry"

mtheorem rfunct_2_cl_4:
"cluster  non monotoneRFUNCT-2V5 also-is  non non-decreasingRFUNCT-2V3\<bar> non non-increasingRFUNCT-2V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be  non monotoneRFUNCT-2V5 implies it be  non non-decreasingRFUNCT-2V3\<bar> non non-increasingRFUNCT-2V4"
     sorry
qed "sorry"

mtheorem rfunct_2_th_24:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
sorry

mtheorem rfunct_2_th_25:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
sorry

mtheorem rfunct_2_cl_5:
"cluster non-decreasingRFUNCT-2V3\<bar>non-increasingRFUNCT-2V4 also-is constantFUNCT-1V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be non-decreasingRFUNCT-2V3\<bar>non-increasingRFUNCT-2V4 implies it be constantFUNCT-1V5"
sorry
qed "sorry"

mtheorem rfunct_2_cl_6:
"cluster constantFUNCT-1V5 also-is non-increasingRFUNCT-2V4\<bar>non-decreasingRFUNCT-2V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be non-increasingRFUNCT-2V4\<bar>non-decreasingRFUNCT-2V3"
     sorry
qed "sorry"

mtheorem rfunct_2_cl_7:
"cluster trivialZFMISC-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be trivialZFMISC-1V1"
sorry
qed "sorry"

mtheorem rfunct_2_cl_8:
  mlet "h be increasingRFUNCT-2V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is increasingRFUNCT-2V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be increasingRFUNCT-2V1"
sorry
qed "sorry"

mtheorem rfunct_2_cl_9:
  mlet "h be decreasingRFUNCT-2V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is decreasingRFUNCT-2V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be decreasingRFUNCT-2V2"
sorry
qed "sorry"

mtheorem rfunct_2_cl_10:
  mlet "h be non-decreasingRFUNCT-2V3\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is non-decreasingRFUNCT-2V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be non-decreasingRFUNCT-2V3"
sorry
qed "sorry"

mtheorem rfunct_2_th_26:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Y missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies (((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be monotoneRFUNCT-2V5"
sorry

mtheorem rfunct_2_th_27:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
sorry

mtheorem rfunct_2_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
sorry

mtheorem rfunct_2_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
sorry

mtheorem rfunct_2_th_30:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
sorry

mtheorem rfunct_2_th_31:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
sorry

mtheorem rfunct_2_th_32:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1) & (r =COMPLEX1R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & r <XXREAL-0R3 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2)"
sorry

mtheorem rfunct_2_th_33:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & r <XXREAL-0R3 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1)"
sorry

mtheorem rfunct_2_th_34:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4)"
sorry

mtheorem rfunct_2_th_35:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3)"
sorry

mtheorem rfunct_2_th_36:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds r inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) implies r inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
sorry

mtheorem rfunct_2_th_37:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2)) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3)) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4)"
sorry

mtheorem rfunct_2_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2)"
sorry

mtheorem rfunct_2_th_39:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
sorry

mtheorem rfunct_2_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4"
sorry

mtheorem rfunct_2_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
sorry

mtheorem rfunct_2_th_42:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3"
sorry

mtheorem rfunct_2_th_43:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
sorry

mtheorem rfunct_2_th_44:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be decreasingRFUNCT-2V2"
sorry

mtheorem rfunct_2_th_45:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-decreasingRFUNCT-2V3"
sorry

mtheorem rfunct_2_th_46:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
sorry

mtheorem rfunct_2_th_47:
" for R be SubsetSUBSET-1M2-of REALNUMBERSK2 holds idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be increasingRFUNCT-2V1"
sorry

mtheorem rfunct_2_th_48:
" for X be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
  using rfunct_2_th_32 sorry

mtheorem rfunct_2_th_49:
" for X be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
  using rfunct_2_th_34 sorry

mtheorem rfunct_2_th_50:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
sorry

mtheorem rfunct_2_th_51:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1"
sorry

mtheorem rfunct_2_th_52:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2"
sorry

end
