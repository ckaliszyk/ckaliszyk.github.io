theory trees_4
  imports trees_3
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) TREES_4M1("NodeTREES-4M1-of  _ " [70]70) where
  "NodeTREES-4M1-of T \<equiv> ElementTREES-1M2-of domRELAT-1K1 T"

reserve x, y, z for "objectHIDDENM1"
reserve i, j, n for "NatNAT-1M1"
reserve p, q, r for "FinSequenceFINSEQ-1M1"
reserve v for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mlemma trees_4_lm_1:
" for x be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M3-of x holds y inHIDDENR3 domFINSEQ-1K5 p or y inHIDDENR3 domFINSEQ-1K5 p implies p .FUNCT-1K1 y inTARSKIR2 x"
sorry

abbreviation(input) TREES_4R1(" _ =TREES-4R1  _ " [50,50]50) where
  "T1 =TREES-4R1 T2 \<equiv> T1 =HIDDENR1 T2"

mtheorem trees_4_def_1:
  mlet "T1 be DecoratedTreeTREES-2M4", "T2 be DecoratedTreeTREES-2M4"
"redefine pred T1 =TREES-4R1 T2 means
  domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p)"
proof
(*compatibility*)
  show "T1 =TREES-4R1 T2 iff domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p)"
sorry
qed "sorry"

mtheorem trees_4_th_1:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds elementary-treeTREES-1K2 i c=TARSKIR1 elementary-treeTREES-1K2 j implies i <=XXREAL-0R1 j"
sorry

mtheorem trees_4_th_2:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds elementary-treeTREES-1K2 i =TREES-2R1 elementary-treeTREES-1K2 j implies i =XBOOLE-0R4 j"
sorry

mlemma trees_4_lm_2:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
sorry

mlemma trees_4_lm_3:
" for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of x holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 x"
sorry

mdef trees_4_def_2 ("root-treeTREES-4K1  _ " [164]164 ) where
  mlet "x be objectHIDDENM1"
"func root-treeTREES-4K1 x \<rightarrow> DecoratedTreeTREES-2M4 equals
  elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K7 x"
proof-
  (*coherence*)
    show "elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K7 x be DecoratedTreeTREES-2M4"
       sorry
qed "sorry"

syntax TREES_4K2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("root-treeTREES-4K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "root-treeTREES-4K2\<^bsub>(D)\<^esub> d" \<rightharpoonup> "root-treeTREES-4K1 d"

mtheorem trees_4_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D"
"cluster root-treeTREES-4K1 d as-term-is ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
proof
(*coherence*)
  show "root-treeTREES-4K1 d be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
sorry
qed "sorry"

mtheorem trees_4_th_3:
" for x be objectHIDDENM1 holds domRELAT-1K1 (root-treeTREES-4K1 x) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6) & (root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
sorry

mtheorem trees_4_th_4:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds root-treeTREES-4K1 x =TREES-4R1 root-treeTREES-4K1 y implies x =HIDDENR1 y"
sorry

mtheorem trees_4_th_5:
" for T be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6) implies T =TREES-4R1 root-treeTREES-4K1 T .FUNCT-1K1 {}XBOOLE-0K1"
sorry

mtheorem trees_4_th_6:
" for x be objectHIDDENM1 holds root-treeTREES-4K1 x =FUNCT-1R1 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
sorry

mdef trees_4_def_3 (" _ -flat-treeTREES-4K3  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "p be FinSequenceFINSEQ-1M1"
"func x -flat-treeTREES-4K3 p \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. (domRELAT-1K1 it =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be DecoratedTreeTREES-2M4 st (domRELAT-1K1 it =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((domRELAT-1K1 it1 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it1 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & ((domRELAT-1K1 it2 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it2 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_4_th_7:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x -flat-treeTREES-4K3 p =TREES-4R1 y -flat-treeTREES-4K3 q implies x =HIDDENR1 y & p =FINSEQ-1R1 q"
sorry

mtheorem trees_4_th_8:
" for i be NatNAT-1M1 holds  for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j <XXREAL-0R3 i implies elementary-treeTREES-1K2 i  |TREES-1K4 (<*TREES-3K14 j*>) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
sorry

mtheorem trees_4_th_9:
" for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 p implies (x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 i*>) =TREES-4R1 root-treeTREES-4K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
sorry

mdef trees_4_def_4 (" _ -treeTREES-4K4  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "p be FinSequenceFINSEQ-1M1"
"assume p be DTree-yieldingTREES-3V6 func x -treeTREES-4K4 p \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. (( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show "p be DTree-yieldingTREES-3V6 implies ( ex it be DecoratedTreeTREES-2M4 st (( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
sorry
  (*uniqueness*)
    show "p be DTree-yieldingTREES-3V6 implies ( for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it1 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it1  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & ((( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it2 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it2  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef trees_4_def_5 (" _ -treeTREES-4K5  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "T be DecoratedTreeTREES-2M4"
"func x -treeTREES-4K5 T \<rightarrow> DecoratedTreeTREES-2M4 equals
  x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)"
proof-
  (*coherence*)
    show "x -treeTREES-4K4 (<*FINSEQ-1K10 T*>) be DecoratedTreeTREES-2M4"
       sorry
qed "sorry"

mdef trees_4_def_6 (" _ -treeTREES-4K6'( _ , _ ')" [164,0,0]164 ) where
  mlet "x be objectHIDDENM1", "T1 be DecoratedTreeTREES-2M4", "T2 be DecoratedTreeTREES-2M4"
"func x -treeTREES-4K6(T1,T2) \<rightarrow> DecoratedTreeTREES-2M4 equals
  x -treeTREES-4K4 (<*FINSEQ-1K11 T1,T2 *>)"
proof-
  (*coherence*)
    show "x -treeTREES-4K4 (<*FINSEQ-1K11 T1,T2 *>) be DecoratedTreeTREES-2M4"
       sorry
qed "sorry"

mtheorem trees_4_th_10:
" for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p"
sorry

mtheorem trees_4_th_11:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds y inHIDDENR3 domRELAT-1K1 (x -treeTREES-4K4 p) iff y =HIDDENR1 {}XBOOLE-0K1 or ( ex i be NatNAT-1M1 st  ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
sorry

mtheorem trees_4_th_12:
" for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T .FUNCT-1K1 q"
sorry

mtheorem trees_4_th_13:
" for x be objectHIDDENM1 holds  for T be DecoratedTreeTREES-2M4 holds domRELAT-1K1 (x -treeTREES-4K5 T) =TREES-2R1 ^TREES-3K12 domRELAT-1K1 T"
sorry

mtheorem trees_4_th_14:
" for x be objectHIDDENM1 holds  for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 (x -treeTREES-4K6(T1,T2)) =TREES-2R1 treeTREES-3K13(domRELAT-1K1 T1,domRELAT-1K1 T2)"
sorry

mtheorem trees_4_th_15:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds x -treeTREES-4K4 p =TREES-4R1 y -treeTREES-4K4 q implies x =HIDDENR1 y & p =FINSEQ-1R1 q"
sorry

mtheorem trees_4_th_16:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds root-treeTREES-4K1 x =TREES-4R1 y -flat-treeTREES-4K3 p implies x =HIDDENR1 y & p =FINSEQ-1R1 {}XBOOLE-0K1"
sorry

mtheorem trees_4_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds root-treeTREES-4K1 x =TREES-4R1 y -treeTREES-4K4 p & p be DTree-yieldingTREES-3V6 implies x =HIDDENR1 y & p =FINSEQ-1R1 {}XBOOLE-0K1"
sorry

mtheorem trees_4_th_18:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x -flat-treeTREES-4K3 p =TREES-4R1 y -treeTREES-4K4 q & q be DTree-yieldingTREES-3V6 implies (x =HIDDENR1 y & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies q .FUNCT-1K1 i =XBOOLE-0R4 root-treeTREES-4K1 p .FUNCT-1K1 i)"
sorry

mtheorem trees_4_th_19:
" for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (<*TREES-3K14 n*>)^FINSEQ-1K8 q inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p) implies (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K8 q) =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,q)"
sorry

mtheorem trees_4_th_20:
" for x be objectHIDDENM1 holds x -flat-treeTREES-4K3 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x & x -treeTREES-4K4 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x"
sorry

mtheorem trees_4_th_21:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)"
sorry

mtheorem trees_4_th_22:
" for x be objectHIDDENM1 holds  for T be DecoratedTreeTREES-2M4 holds x -treeTREES-4K4 (<*FINSEQ-1K10 T*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)"
sorry

mtheorem trees_4_cl_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "p be FinSequenceFINSEQ-1M3-of D"
"cluster d -flat-treeTREES-4K3 p as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -flat-treeTREES-4K3 p be D -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem trees_4_cl_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D", "d be ElementSUBSET-1M1-of D", "p be FinSequenceFINSEQ-1M3-of F"
"cluster d -treeTREES-4K4 p as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -treeTREES-4K4 p be D -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem trees_4_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "T be DecoratedTreeTREES-2M5-of D"
"cluster d -treeTREES-4K5 T as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -treeTREES-4K5 T be D -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem trees_4_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "T1 be DecoratedTreeTREES-2M5-of D", "T2 be DecoratedTreeTREES-2M5-of D"
"cluster d -treeTREES-4K6(T1,T2) as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -treeTREES-4K6(T1,T2) be D -valuedRELAT-1V5"
sorry
qed "sorry"

syntax TREES_4K7 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("domsTREES-4K7\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "domsTREES-4K7\<^bsub>(D)\<^esub> p" \<rightharpoonup> "domsFUNCT-6K1 p"

mtheorem trees_4_add_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D"
"cluster domsFUNCT-6K1 p as-term-is FinSequenceFINSEQ-1M3-of FinTreesTREES-3K2"
proof
(*coherence*)
  show "domsFUNCT-6K1 p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K2"
sorry
qed "sorry"

syntax TREES_4K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -treeTREES-4K8\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "d -treeTREES-4K8\<^bsub>(D)\<^esub> p" \<rightharpoonup> "d -treeTREES-4K4 p"

mtheorem trees_4_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D"
"cluster d -treeTREES-4K4 p as-term-is ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
proof
(*coherence*)
  show "d -treeTREES-4K4 p be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
sorry
qed "sorry"

syntax TREES_4M2 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("FinSequenceTREES-4M2\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of x" \<rightharpoonup> "FinSequenceFINSEQ-1M2-of x"

mtheorem trees_4_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be SubsetSUBSET-1M2-of D"
"cluster note-that FinSequenceFINSEQ-1M3-of D for FinSequenceFINSEQ-1M2-of x"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M2-of x holds it be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

mtheorem trees_4_cl_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>constituted-DTreesTREES-3V3\<bar>setHIDDENM2", "X be SubsetSUBSET-1M2-of D"
"cluster note-that DTree-yieldingTREES-3V6 for FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of X"
proof
(*coherence*)
  show " for it be FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of X holds it be DTree-yieldingTREES-3V6"
     sorry
qed "sorry"

(*begin*)
theorem trees_4_sch_1:
  fixes T1f0 T2f0 Pp1 
  assumes
[ty]: "T1f0 be TreeTREES-1M1" and
  [ty]: "T2f0 be TreeTREES-1M1"
  shows " ex T be TreeTREES-1M1 st  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T iff p inTARSKIR2 T1f0 or ( ex q be ElementTREES-1M2-of T1f0 st  ex r be ElementTREES-1M2-of T2f0 st Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
sorry

mdef trees_4_def_7 ("'( _ , _ ')<-TREES-4K9  _ " [0,0,200]200 ) where
  mlet "T be DecoratedTreeTREES-2M4", "T9 be DecoratedTreeTREES-2M4", "x be setHIDDENM2"
"func (T,x)<-TREES-4K9 T9 \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. (( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)"
proof-
  (*existence*)
    show " ex it be DecoratedTreeTREES-2M4 st (( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)"
sorry
  (*uniqueness*)
    show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it1 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it1 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it1 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)) & ((( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it2 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it2 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it2 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem trees_4_cl_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "T9 be DecoratedTreeTREES-2M5-of D", "x be setHIDDENM2"
"cluster (T,x)<-TREES-4K9 T9 as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "(T,x)<-TREES-4K9 T9 be D -valuedRELAT-1V5"
sorry
qed "sorry"

reserve T, T9 for "DecoratedTreeTREES-2M4"
reserve x, y for "setHIDDENM2"
mtheorem trees_4_th_23:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds  not x inTARSKIR2 rngFUNCT-1K2 T or  not x inTARSKIR2 LeavesTREES-2K4 T implies (T,x)<-TREES-4K9 T9 =TREES-4R1 T"
sorry

(*begin*)
reserve D1, D2 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve T for "DecoratedTreeTREES-3M2-of(D1,D2)"
reserve d1 for "ElementSUBSET-1M1-of D1"
reserve d2 for "ElementSUBSET-1M1-of D2"
reserve F for " non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2)"
reserve F1 for " non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D1"
reserve F2 for " non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D2"
mtheorem trees_4_th_24:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-3M2-of(D1,D2) holds domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T & domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
sorry

mtheorem trees_4_th_25:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 root-treeTREES-4K2\<^bsub>(D1)\<^esub> d1 & (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 root-treeTREES-4K2\<^bsub>(D2)\<^esub> d2"
sorry

mtheorem trees_4_th_26:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <:FUNCT-3K14 root-treeTREES-4K1 x,root-treeTREES-4K1 y :> =TREES-4R1 root-treeTREES-4K1 [TARSKIK4 x,y ]"
sorry

mtheorem trees_4_th_27:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for F1 be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D1 holds  for p be FinSequenceFINSEQ-1M3-of F holds  for p1 be FinSequenceFINSEQ-1M3-of F1 holds domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)) implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
sorry

mtheorem trees_4_th_28:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for F2 be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of F holds  for p2 be FinSequenceFINSEQ-1M3-of F2 holds domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)) implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
sorry

mtheorem trees_4_th_29:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for p be FinSequenceFINSEQ-1M3-of F holds  ex p1 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D1 st (domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
sorry

mtheorem trees_4_th_30:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for p be FinSequenceFINSEQ-1M3-of F holds  ex p2 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D2 st (domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
sorry

mtheorem trees_4_th_31:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  ex p1 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D1 st (domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K8\<^bsub>(D1)\<^esub> p1"
sorry

mtheorem trees_4_th_32:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  ex p2 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D2 st (domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K8\<^bsub>(D2)\<^esub> p2"
sorry

end
