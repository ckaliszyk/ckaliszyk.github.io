theory partit1
  imports finseq_4 classes1 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve Y, Z for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve PA, PB for "a-partitionEQREL-1M3-of Y"
reserve A, B for "SubsetSUBSET-1M2-of Y"
reserve i, j, k for "NatNAT-1M1"
reserve x, y, z, x1, x2, y1, z0, X, V, a, b, d, t, SFX, SFY for "setHIDDENM2"
mtheorem partit1_th_1:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X be setHIDDENM2 holds  for V be setHIDDENM2 holds (X inTARSKIR2 PA & V inTARSKIR2 PA) & X c=TARSKIR1 V implies X =XBOOLE-0R4 V"
sorry

abbreviation(input) PARTIT1R1(" _ ''<''PARTIT1R1  _ " [50,50]50) where
  "SFX '<'PARTIT1R1 SFY \<equiv> SFX is-finer-thanSETFAM-1R1 SFY"

abbreviation(input) PARTIT1R2(" _ ''>''PARTIT1R2  _ " [50,50]50) where
  "SFY '>'PARTIT1R2 SFX \<equiv> SFX is-finer-thanSETFAM-1R1 SFY"

mtheorem partit1_th_2:
" for SFX be setHIDDENM2 holds unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) =XBOOLE-0R4 unionTARSKIK3 SFX"
sorry

mtheorem partit1_th_3:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA implies PB c=TARSKIR1 PA"
sorry

mtheorem partit1_th_4:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA implies PA =XBOOLE-0R4 PB"
sorry

mtheorem partit1_th_5:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB implies PA is-coarser-thanSETFAM-1R2 PB"
sorry

mdef partit1_def_1 (" _ is-a-dependent-set-ofPARTIT1R3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "b be setHIDDENM2"
"pred b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA means
   ex B be setHIDDENM2 st (B c=TARSKIR1 PA & B <>HIDDENR2 {}XBOOLE-0K1) & b =XBOOLE-0R4 unionTARSKIK3 B"..

mdef partit1_def_2 (" _ is-min-dependPARTIT1R4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [50,0,0,0]50 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "PB be a-partitionEQREL-1M3-of Y", "b be setHIDDENM2"
"pred b is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) means
  (b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB) & ( for d be setHIDDENM2 holds (d c=TARSKIR1 b & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB implies d =XBOOLE-0R4 b)"..

mtheorem partit1_th_6:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB implies ( for b be setHIDDENM2 holds b inTARSKIR2 PA implies b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB)"
sorry

mtheorem partit1_th_7:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds Y is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
sorry

mtheorem partit1_th_8:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for F be Subset-FamilySETFAM-1M1-of Y holds IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds X inTARSKIR2 F implies X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) implies IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
sorry

mtheorem partit1_th_9:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X0 be SubsetSUBSET-1M2-of Y holds  for X1 be SubsetSUBSET-1M2-of Y holds (X0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & X0 meetsXBOOLE-0R5 X1 implies X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
sorry

mtheorem partit1_th_10:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X be SubsetSUBSET-1M2-of Y holds X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & X <>HIDDENR2 Y implies X `SUBSET-1K3\<^bsub>(Y)\<^esub> is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
sorry

mtheorem partit1_th_11:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for y be ElementSUBSET-1M1-of Y holds  ex X be SubsetSUBSET-1M2-of Y st y inTARSKIR2 X & X is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
sorry

mtheorem partit1_th_12:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for P be a-partitionEQREL-1M3-of Y holds  for y be ElementSUBSET-1M1-of Y holds  ex A be SubsetSUBSET-1M2-of Y st y inTARSKIR2 A & A inTARSKIR2 P"
sorry

mdef partit1_def_3 ("PARTITIONSPARTIT1K1  _ " [164]164 ) where
  mlet "Y be setHIDDENM2"
"func PARTITIONSPARTIT1K1 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be setHIDDENM2 holds x inTARSKIR2 it iff x be a-partitionEQREL-1M3-of Y"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be setHIDDENM2 holds x inTARSKIR2 it iff x be a-partitionEQREL-1M3-of Y"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 it1 iff x be a-partitionEQREL-1M3-of Y) & ( for x be setHIDDENM2 holds x inTARSKIR2 it2 iff x be a-partitionEQREL-1M3-of Y) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem partit1_cl_1:
  mlet "Y be setHIDDENM2"
"cluster PARTITIONSPARTIT1K1 Y as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "PARTITIONSPARTIT1K1 Y be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

(*begin*)
mdef partit1_def_4 (" _ '''/'\\''PARTIT1K2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "PB be a-partitionEQREL-1M3-of Y"
"func PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB \<rightarrow> a-partitionEQREL-1M3-of Y equals
  INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  (*coherence*)
    show "INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } be a-partitionEQREL-1M3-of Y"
sorry
qed "sorry"

mtheorem PARTIT1K2_commutativity:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB =HIDDENR1 PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA"
sorry

mtheorem partit1_th_13:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
sorry

mtheorem partit1_th_14:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC)"
sorry

mtheorem partit1_th_15:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
sorry

mdef partit1_def_5 (" _ '''\\'/''PARTIT1K3\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "PB be a-partitionEQREL-1M3-of Y"
"func PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB \<rightarrow> a-partitionEQREL-1M3-of Y means
  \<lambda>it.  for d be setHIDDENM2 holds d inTARSKIR2 it iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
proof-
  (*existence*)
    show " ex it be a-partitionEQREL-1M3-of Y st  for d be setHIDDENM2 holds d inTARSKIR2 it iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
sorry
  (*uniqueness*)
    show " for it1 be a-partitionEQREL-1M3-of Y holds  for it2 be a-partitionEQREL-1M3-of Y holds ( for d be setHIDDENM2 holds d inTARSKIR2 it1 iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) & ( for d be setHIDDENM2 holds d inTARSKIR2 it2 iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem PARTIT1K3_commutativity:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB =HIDDENR1 PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
sorry

mtheorem partit1_th_16:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
sorry

mtheorem partit1_th_17:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
sorry

mtheorem partit1_th_18:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for z0 be setHIDDENM2 holds  for t be setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (((PA '<'PARTIT1R1 PC & x inTARSKIR2 PC) & z0 inTARSKIR2 PA) & t inTARSKIR2 x) & t inTARSKIR2 z0 implies z0 c=TARSKIR1 x"
sorry

mtheorem partit1_th_19:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for z0 be setHIDDENM2 holds  for t be setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ((x inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & z0 inTARSKIR2 PA) & t inTARSKIR2 x) & t inTARSKIR2 z0 implies z0 c=TARSKIR1 x"
  using partit1_th_16 partit1_th_18 sorry

(*begin*)
mdef partit1_def_6 ("ERlPARTIT1K4\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y"
"func ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \<rightarrow> Equivalence-RelationEQREL-1M2-of Y means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
proof-
  (*existence*)
    show " ex it be Equivalence-RelationEQREL-1M2-of Y st  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
sorry
  (*uniqueness*)
    show " for it1 be Equivalence-RelationEQREL-1M2-of Y holds  for it2 be Equivalence-RelationEQREL-1M2-of Y holds ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it1 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) & ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it2 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef partit1_def_7 ("RelPARTIT1K5  _ " [164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func RelPARTIT1K5 Y \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it1 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))) & (domRELAT-1K1 it2 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it2 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem partit1_th_20:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PB iff ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
sorry

mtheorem partit1_th_21:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for p0 be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of Y holds ((((((p0 c=TARSKIR1 Y & x inTARSKIR2 p0) & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y) & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p2 be setHIDDENM2 st  ex p3 be setHIDDENM2 st  ex u be setHIDDENM2 st ((((p2 inTARSKIR2 PA & p3 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p2) & u inTARSKIR2 p2) & u inTARSKIR2 p3) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p3))) & p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB implies y inTARSKIR2 p0"
sorry

mtheorem partit1_th_22:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R1 be Equivalence-RelationEQREL-1M2-of Y holds  for R2 be Equivalence-RelationEQREL-1M2-of Y holds  for f be FinSequenceFINSEQ-1M3-of Y holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (((x inTARSKIR2 Y & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y) & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex u be setHIDDENM2 st (u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2)) implies [TARSKIK4 x,y ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
sorry

mtheorem partit1_th_23:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
sorry

mtheorem partit1_th_24:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
sorry

mtheorem partit1_th_25:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =RELAT-1R1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB implies PA =XBOOLE-0R4 PB"
sorry

mtheorem partit1_th_26:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC)"
sorry

mtheorem partit1_th_27:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
sorry

mtheorem partit1_th_28:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
sorry

mtheorem partit1_th_29:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PC & PB '<'PARTIT1R1 PC implies PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB '<'PARTIT1R1 PC"
sorry

mtheorem partit1_th_30:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PC & PB '>'PARTIT1R2 PC implies PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB '>'PARTIT1R2 PC"
sorry

abbreviation(input) PARTIT1K6("%IPARTIT1K6  _ " [164]164) where
  "%IPARTIT1K6 Y \<equiv> SmallestPartitionEQREL-1K12 Y"

abbreviation(input) PARTIT1K7("%IPARTIT1K7  _ " [164]164) where
  "%IPARTIT1K7 Y \<equiv> SmallestPartitionEQREL-1K12 Y"

mtheorem partit1_add_1:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster SmallestPartitionEQREL-1K12 Y as-term-is a-partitionEQREL-1M3-of Y"
proof
(*coherence*)
  show "SmallestPartitionEQREL-1K12 Y be a-partitionEQREL-1M3-of Y"
     sorry
qed "sorry"

mdef partit1_def_8 ("%OPARTIT1K8  _ " [164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func %OPARTIT1K8 Y \<rightarrow> a-partitionEQREL-1M3-of Y equals
  {TARSKIK1 Y}"
proof-
  (*coherence*)
    show "{TARSKIK1 Y} be a-partitionEQREL-1M3-of Y"
sorry
qed "sorry"

mtheorem partit1_th_31:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds %IPARTIT1K7 Y =XBOOLE-0R4 {B where B be SubsetSUBSET-1M2-of Y :  ex x be setHIDDENM2 st B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y }"
sorry

mtheorem partit1_th_32:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds %OPARTIT1K8 Y '>'PARTIT1R2 PA & PA '>'PARTIT1R2 %IPARTIT1K7 Y"
sorry

mtheorem partit1_th_33:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =RELAT-1R1 nablaEQREL-1K1 Y"
sorry

mtheorem partit1_th_34:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) =RELAT-1R1 idRELAT-1K7 Y"
sorry

mtheorem partit1_th_35:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds %IPARTIT1K7 Y '<'PARTIT1R1 %OPARTIT1K8 Y"
sorry

mtheorem partit1_th_36:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds (%OPARTIT1K8 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %OPARTIT1K8 Y & (%OPARTIT1K8 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
sorry

mtheorem partit1_th_37:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds (%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA & (%IPARTIT1K7 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %IPARTIT1K7 Y"
sorry

end
