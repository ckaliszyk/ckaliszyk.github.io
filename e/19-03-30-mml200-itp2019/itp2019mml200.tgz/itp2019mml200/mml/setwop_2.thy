theory setwop_2
  imports finseqop finsop_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve C, C9, D, E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c, c9, c1, c2, c3 for "ElementSUBSET-1M1-of C"
reserve B, B9, B1, B2 for "ElementSUBSET-1M1-of FinFINSUB-1K5 C"
reserve A for "ElementSUBSET-1M1-of FinFINSUB-1K5 C9"
reserve d, d1, d2, d3, d4, e for "ElementSUBSET-1M1-of D"
reserve F, G for "BinOpBINOP-1M2-of D"
reserve u for "UnOpBINOP-1M1-of D"
reserve f, f9 for "FunctionFUNCT-2M1-of(C,D)"
reserve g for "FunctionFUNCT-2M1-of(C9,D)"
reserve H for "BinOpBINOP-1M2-of E"
reserve h for "FunctionFUNCT-2M1-of(D,E)"
reserve i, j for "NatNAT-1M1"
reserve s for "FunctionFUNCT-1M1"
reserve p, q for "FinSequenceFINSEQ-1M3-of D"
reserve T1, T2 for "ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
mlemma setwop_2_lm_1:
" for i be NatNAT-1M1 holds SegFINSEQ-1K2 i be ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
  using finsub_1_def_5 sorry

mlemma setwop_2_lm_2:
" for i be NatNAT-1M1 holds  not i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 i"
  using finseq_1_th_1 xreal_1_th_29 sorry

mtheorem setwop_2_th_1:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & c1 <>HIDDENR2 c2 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2)"
sorry

mtheorem setwop_2_th_2:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) &  not c inTARSKIR2 B implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
sorry

mtheorem setwop_2_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for c3 be ElementSUBSET-1M1-of C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & c1 <>HIDDENR2 c2) & c1 <>HIDDENR2 c3) & c2 <>HIDDENR2 c3 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK7\<^bsub>(C)\<^esub> c1,c2,c3 .},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c3)"
sorry

mtheorem setwop_2_th_4:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & B1 missesXBOOLE-0R1 B2 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
sorry

mtheorem setwop_2_th_5:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 C9 holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (A <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 A & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
sorry

mtheorem setwop_2_th_6:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds (H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>)) & f be one-to-oneFUNCT-1V2 implies H $$SETWISEOK10\<^bsub>(D,E)\<^esub>(f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B,h) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
sorry

mtheorem setwop_2_th_7:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B =FUNCT-1R1 f9  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)"
sorry

mtheorem setwop_2_th_8:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B =XBOOLE-0R4 {TARSKIK1 e} implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 e"
sorry

mtheorem setwop_2_th_9:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
sorry

mlemma setwop_2_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> implies ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
sorry

mtheorem setwop_2_th_10:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
sorry

mtheorem setwop_2_th_11:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
sorry

mtheorem setwop_2_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
sorry

mtheorem setwop_2_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
sorry

mtheorem setwop_2_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
sorry

mtheorem setwop_2_th_15:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
sorry

mtheorem setwop_2_th_16:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds ((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub>) & H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>) & h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
sorry

mtheorem setwop_2_th_17:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
  using setwop_2_th_16 sorry

mtheorem setwop_2_th_18:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
sorry

mtheorem setwop_2_th_19:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
sorry

mdef setwop_2_def_1 ("[#]SETWOP-2K1\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "d be ElementSUBSET-1M1-of D"
"func [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) \<rightarrow> sequenceNAT-1M2-of D equals
  (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> d)+*FINSOP-1K2\<^bsub>(D)\<^esub> p"
proof-
  (*coherence*)
    show "(NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> d)+*FINSOP-1K2\<^bsub>(D)\<^esub> p be sequenceNAT-1M2-of D"
       sorry
qed "sorry"

mtheorem setwop_2_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of D holds (i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i) & ( not i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =XBOOLE-0R4 d)"
sorry

mtheorem setwop_2_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
sorry

mtheorem setwop_2_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
sorry

mtheorem setwop_2_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
sorry

mtheorem setwop_2_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for p be FinSequenceFINSEQ-1M3-of D holds h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,D,D,E)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,E)\<^esub> [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
sorry

mlemma setwop_2_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & F .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e implies F .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e)"
sorry

mlemma setwop_2_lm_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies F [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e)"
sorry

mlemma setwop_2_lm_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies F [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e)"
sorry

abbreviation(input) SETWOP_2K2("finSegSETWOP-2K2  _ " [164]164) where
  "finSegSETWOP-2K2 i \<equiv> SegFINSEQ-1K1 i"

abbreviation(input) SETWOP_2K3("finSegSETWOP-2K3  _ " [164]164) where
  "finSegSETWOP-2K3 i \<equiv> SegFINSEQ-1K1 i"

mtheorem setwop_2_add_1:
  mlet "i be NatNAT-1M1"
"cluster SegFINSEQ-1K1 i as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
proof
(*coherence*)
  show "SegFINSEQ-1K1 i be ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
    using setwop_2_lm_1 sorry
qed "sorry"

abbreviation(input) SETWOP_2K4(" _ $$SETWOP-2K4\<^bsub>'( _ ')\<^esub>  _ " [180,0,180]180) where
  "F $$SETWOP-2K4\<^bsub>(D)\<^esub> p \<equiv> F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p"

abbreviation(input) SETWOP_2K5(" _ $$SETWOP-2K5\<^bsub>'( _ ')\<^esub>  _ " [180,0,180]180) where
  "F $$SETWOP-2K5\<^bsub>(D)\<^esub> p \<equiv> F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p"

mtheorem setwop_2_def_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "F be BinOpBINOP-1M2-of D"
"assume (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub> redefine func F $$SETWOP-2K5\<^bsub>(D)\<^esub> p \<rightarrow> ElementSUBSET-1M1-of D equals
  F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F))"
proof
(*compatibility*)
  show "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies ( for it be ElementSUBSET-1M1-of D holds it =HIDDENR1 F $$SETWOP-2K5\<^bsub>(D)\<^esub> p iff it =HIDDENR1 F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)))"
sorry
qed "sorry"

mtheorem setwop_2_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
sorry

mtheorem setwop_2_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
sorry

mtheorem setwop_2_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
sorry

mtheorem setwop_2_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>) & h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p"
sorry

mtheorem setwop_2_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> u *FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
  using setwop_2_th_28 sorry

mtheorem setwop_2_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
sorry

mtheorem setwop_2_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
sorry

mtheorem setwop_2_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds ((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))) & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
sorry

mtheorem setwop_2_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
sorry

mtheorem setwop_2_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
sorry

mtheorem setwop_2_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
sorry

mtheorem setwop_2_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d2)"
sorry

mtheorem setwop_2_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
sorry

mtheorem setwop_2_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
sorry

mtheorem setwop_2_th_39:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
sorry

mtheorem setwop_2_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
sorry

mtheorem setwop_2_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
sorry

end
