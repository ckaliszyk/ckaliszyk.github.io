theory cfcont_1
  imports cfunct_1 comseq_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, n1, m, m1, k for "NatNAT-1M1"
reserve x, X, X1 for "setHIDDENM2"
reserve g, g1, g2, t, x0, x1, x2 for "ComplexXCMPLX-0M1"
reserve s1, s2, q1, seq, seq1, seq2, seq3 for "Complex-SequenceCOMSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
reserve f, f1, f2, h, h1, h2 for "PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
reserve p, r, s for "RealXREAL-0M1"
reserve Ns, Nseq for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mdef cfcont_1_def_1 (" _ is-continuous-inCFCONT-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "x0 be ComplexXCMPLX-0M1"
"pred f is-continuous-inCFCONT-1R1 x0 means
  x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0 implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"..

mtheorem cfcont_1_th_1:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 iff ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
sorry

mtheorem cfcont_1_th_2:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns & (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns) & (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns)"
sorry

mtheorem cfcont_1_th_3:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
sorry

mtheorem cfcont_1_th_4:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|"
sorry

mtheorem cfcont_1_th_5:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns"
sorry

mtheorem cfcont_1_th_6:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 *COMSEQ-3K9 Ns)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
sorry

mtheorem cfcont_1_th_7:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2 implies ((h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) & (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
sorry

mtheorem cfcont_1_th_8:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
sorry

mtheorem cfcont_1_th_9:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  using cfcont_1_th_8 sorry

mtheorem cfcont_1_th_10:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) implies h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
sorry

mtheorem cfcont_1_th_11:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) implies (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
sorry

mtheorem cfcont_1_th_12:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
sorry

mtheorem cfcont_1_th_13:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
sorry

mtheorem cfcont_1_th_14:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds h1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> implies ((h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) & (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
sorry

mtheorem cfcont_1_th_15:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds h be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
sorry

mtheorem cfcont_1_th_16:
" for X be setHIDDENM2 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) & h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
sorry

mtheorem cfcont_1_th_17:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq be convergentCOMSEQ-2V3 implies seq1 be convergentCOMSEQ-2V3"
sorry

mtheorem cfcont_1_th_18:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
sorry

mtheorem cfcont_1_th_19:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq1 be convergentCOMSEQ-2V3"
sorry

mtheorem cfcont_1_th_20:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies limCOMSEQ-2K3 seq =COMPLEX1R1 limCOMSEQ-2K3 seq1"
sorry

mtheorem cfcont_1_th_21:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 implies seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) =COMPLEX1R1 limCOMSEQ-2K3 seq"
  using cfcont_1_th_17 cfcont_1_th_18 sorry

mtheorem cfcont_1_th_22:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies seq1 be convergentCOMSEQ-2V3"
sorry

mtheorem cfcont_1_th_23:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
sorry

mtheorem cfcont_1_th_24:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9)"
sorry

mtheorem cfcont_1_th_25:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( ex seq1 be Complex-SequenceCOMSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9)"
sorry

mtheorem cfcont_1_th_26:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 implies seq be convergentCOMSEQ-2V3"
sorry

mtheorem cfcont_1_th_27:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq or seq be constantVALUED-0V15 & ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g) implies limCOMSEQ-2K3 seq =COMPLEX1R1 g"
sorry

mtheorem cfcont_1_th_28:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 implies ( for n be NatNAT-1M1 holds limCOMSEQ-2K3 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
  using cfcont_1_th_27 sorry

mtheorem cfcont_1_th_29:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9 implies limCOMSEQ-2K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =COMPLEX1R1 (limCOMSEQ-2K3 seq)\<inverse>XCMPLX-0K5)"
sorry

mtheorem cfcont_1_th_30:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 & seq1 be convergentCOMSEQ-2V3 implies ((limCOMSEQ-2K3 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limCOMSEQ-2K3 seq1 & limCOMSEQ-2K3 (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limCOMSEQ-2K3 seq1) & limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =COMPLEX1R1 limCOMSEQ-2K3 seq1 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)) & limCOMSEQ-2K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limCOMSEQ-2K3 seq1)"
sorry

theorem cfcont_1_sch_1:
  fixes Pp2 
  assumes
    A1: " for n be NatNAT-1M1 holds  ex g be ComplexXCMPLX-0M1 st Pp2(n,g)"
  shows " ex s1 be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds Pp2(n,s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
sorry

(*begin*)
mtheorem cfcont_1_th_31:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 iff x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
sorry

mtheorem cfcont_1_th_32:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 iff x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
sorry

mtheorem cfcont_1_th_33:
" for x0 be ComplexXCMPLX-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-inCFCONT-1R1 x0 & f2 is-continuous-inCFCONT-1R1 x0 implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0 & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0"
sorry

mtheorem cfcont_1_th_34:
" for g be ComplexXCMPLX-0M1 holds  for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 implies g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 x0"
sorry

mtheorem cfcont_1_th_35:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 implies -VALUED-1K33\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 x0"
  using cfcont_1_th_34 sorry

mtheorem cfcont_1_th_36:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-inCFCONT-1R1 x0"
sorry

mtheorem cfcont_1_th_37:
" for x0 be ComplexXCMPLX-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f1 is-continuous-inCFCONT-1R1 x0 & f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6) & f2 is-continuous-inCFCONT-1R1 x0 implies f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-inCFCONT-1R1 x0"
sorry

mdef cfcont_1_def_2 (" _ is-continuous-onCFCONT-1R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "X be setHIDDENM2"
"pred f is-continuous-onCFCONT-1R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x0)"..

mtheorem cfcont_1_th_38:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X iff X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
sorry

mtheorem cfcont_1_th_39:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X iff X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
sorry

mtheorem cfcont_1_th_40:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X iff f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfcont_1_th_41:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & X1 c=TARSKIR1 X implies f is-continuous-onCFCONT-1R2 X1"
sorry

mtheorem cfcont_1_th_42:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f is-continuous-onCFCONT-1R2 {TARSKIK1 x0}"
sorry

mtheorem cfcont_1_th_43:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfcont_1_th_44:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X1 implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1 & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1"
sorry

mtheorem cfcont_1_th_45:
" for g be ComplexXCMPLX-0M1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X implies g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfcont_1_th_46:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X implies -VALUED-1K33\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-onCFCONT-1R2 X"
  using cfcont_1_th_45 sorry

mtheorem cfcont_1_th_47:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfcont_1_th_48:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfcont_1_th_49:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f1 is-continuous-onCFCONT-1R2 X & f1 \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 is-continuous-onCFCONT-1R2 X implies f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-onCFCONT-1R2 X"
sorry

mtheorem cfcont_1_th_50:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & ( for x1 be ComplexXCMPLX-0M1 holds  for x2 be ComplexXCMPLX-0M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2)) & ( ex x0 be ComplexXCMPLX-0M1 st f is-continuous-inCFCONT-1R1 x0) implies f is-continuous-onCFCONT-1R2 COMPLEXNUMBERSK3"
sorry

mdef cfcont_1_def_3 ("compactCFCONT-1V1" 70 ) where
"attr compactCFCONT-1V1 for setHIDDENM2 means
  (\<lambda>X.  for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X implies ( ex s2 be Complex-SequenceCOMSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s2 inHIDDENR3 X))"..

mtheorem cfcont_1_th_51:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f be compactCFCONT-1V1 & f is-continuous-onCFCONT-1R2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f be compactCFCONT-1V1"
sorry

mtheorem cfcont_1_th_52:
" for Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & Y be compactCFCONT-1V1) & f is-continuous-onCFCONT-1R2 Y implies f .:RELSET-1K7\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y be compactCFCONT-1V1"
sorry

end
