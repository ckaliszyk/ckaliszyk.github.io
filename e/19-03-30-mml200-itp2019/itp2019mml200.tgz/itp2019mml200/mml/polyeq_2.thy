theory polyeq_2
  imports polyeq_1 series_1
   "../mizar_extension/E_number"
begin
(*begin*)
mlemma
"\<four>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M"
   sorry

mlemma
"\<two>\<^sub>M dividesINT-1R1 \<four>\<^sub>M"
  using int_1_def_3 sorry

mlemma polyeq_2_lm_1:
"\<four>\<^sub>M be evenABIANV3"
  using abian_def_1 sorry

mlemma
"\<three>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
   sorry

mlemma polyeq_2_lm_2:
"\<three>\<^sub>M be oddABIANV2"
  using abian_th_1 sorry

mdef polyeq_2_def_1 ("PolynomPOLYEQ-2K1'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "e be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"func PolynomPOLYEQ-2K1(a,b,c,d,e,x) \<rightarrow> setHIDDENM2 equals
  (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 d *XCMPLX-0K3 x)+XCMPLX-0K2 e"
proof-
  (*coherence*)
    show "(((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 d *XCMPLX-0K3 x)+XCMPLX-0K2 e be setHIDDENM2"
       sorry
qed "sorry"

mtheorem polyeq_2_cl_1:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "e be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-2K1(a,b,c,d,e,x) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-2K1(a,b,c,d,e,x) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem polyeq_2_cl_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "d be RealXREAL-0M1", "e be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster PolynomPOLYEQ-2K1(a,b,c,d,e,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-2K1(a,b,c,d,e,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_2_th_1:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for e be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & e <>HIDDENR2 0NUMBERSK6) & c ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 e >XXREAL-0R4 0NUMBERSK6 implies (PolynomPOLYEQ-2K1(a,0NUMBERSK6,c,0NUMBERSK6,e,x) =COMPLEX1R1 0NUMBERSK6 implies x <>HIDDENR2 0NUMBERSK6 & (((x =COMPLEX1R1 sqrtSQUARE-1K3 (((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,c,e)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =COMPLEX1R1 sqrtSQUARE-1K3 (((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,c,e)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) or x =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,c,e)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) or x =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,c,e)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))))"
sorry

mtheorem polyeq_2_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & y =COMPLEX1R1 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 x implies (PolynomPOLYEQ-2K1(a,b,c,b,a,x) =COMPLEX1R1 0NUMBERSK6 implies x <>HIDDENR2 0NUMBERSK6 & ((a *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 y)+XCMPLX-0K2 c)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem polyeq_2_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6) & y =COMPLEX1R1 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 x implies (PolynomPOLYEQ-2K1(a,b,c,b,a,x) =COMPLEX1R1 0NUMBERSK6 implies ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & y2 =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies x <>HIDDENR2 0NUMBERSK6 & (((x =COMPLEX1R1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =COMPLEX1R1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =COMPLEX1R1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)))"
sorry

mtheorem polyeq_2_th_4:
" for x be RealXREAL-0M1 holds (x  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 x ^2SQUARE-1K1 *XCMPLX-0K3 x & x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 x =COMPLEX1R1 x  |^NEWTONK1 \<four>\<^sub>M) & x ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 =COMPLEX1R1 x  |^NEWTONK1 \<four>\<^sub>M"
sorry

mtheorem polyeq_2_th_5:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y <>HIDDENR2 0NUMBERSK6 implies (x +XCMPLX-0K2 y) |^NEWTONK1 \<four>\<^sub>M =COMPLEX1R1 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 y ^2SQUARE-1K1)*XCMPLX-0K3 x))+XCMPLX-0K2 y  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 y ^2SQUARE-1K1)*XCMPLX-0K3 x))+XCMPLX-0K2 y  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 y"
sorry

mtheorem polyeq_2_th_6:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y <>HIDDENR2 0NUMBERSK6 implies (x +XCMPLX-0K2 y) |^NEWTONK1 \<four>\<^sub>M =COMPLEX1R1 (x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (((\<four>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 y ^2SQUARE-1K1)*XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 y  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 x))+XCMPLX-0K2 y  |^NEWTONK1 \<four>\<^sub>M"
sorry

mtheorem polyeq_2_th_7:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for b1 be RealXREAL-0M1 holds  for b2 be RealXREAL-0M1 holds  for b3 be RealXREAL-0M1 holds  for b4 be RealXREAL-0M1 holds  for b5 be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-2K1(a1,a2,a3,a4,a5,x) =COMPLEX1R1 PolynomPOLYEQ-2K1(b1,b2,b3,b4,b5,x)) implies (a5 =COMPLEX1R1 b5 & ((a1 -XCMPLX-0K6 a2)+XCMPLX-0K2 a3)-XCMPLX-0K6 a4 =COMPLEX1R1 ((b1 -XCMPLX-0K6 b2)+XCMPLX-0K2 b3)-XCMPLX-0K6 b4) & ((a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 a3)+XCMPLX-0K2 a4 =COMPLEX1R1 ((b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 b3)+XCMPLX-0K2 b4"
sorry

mtheorem polyeq_2_th_8:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for b1 be RealXREAL-0M1 holds  for b2 be RealXREAL-0M1 holds  for b3 be RealXREAL-0M1 holds  for b4 be RealXREAL-0M1 holds  for b5 be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-2K1(a1,a2,a3,a4,a5,x) =COMPLEX1R1 PolynomPOLYEQ-2K1(b1,b2,b3,b4,b5,x)) implies a1 -XCMPLX-0K6 b1 =COMPLEX1R1 b3 -XCMPLX-0K6 a3 & a2 -XCMPLX-0K6 b2 =COMPLEX1R1 b4 -XCMPLX-0K6 a4"
sorry

mtheorem polyeq_2_th_9:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for b1 be RealXREAL-0M1 holds  for b2 be RealXREAL-0M1 holds  for b3 be RealXREAL-0M1 holds  for b4 be RealXREAL-0M1 holds  for b5 be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-2K1(a1,a2,a3,a4,a5,x) =COMPLEX1R1 PolynomPOLYEQ-2K1(b1,b2,b3,b4,b5,x)) implies (((a1 =COMPLEX1R1 b1 & a2 =COMPLEX1R1 b2) & a3 =COMPLEX1R1 b3) & a4 =COMPLEX1R1 b4) & a5 =COMPLEX1R1 b5"
sorry

mdef polyeq_2_def_2 ("Four0POLYEQ-2K2'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "a1 be RealXREAL-0M1", "x1 be RealXREAL-0M1", "x2 be RealXREAL-0M1", "x3 be RealXREAL-0M1", "x4 be RealXREAL-0M1", "x be RealXREAL-0M1"
"func Four0POLYEQ-2K2(a1,x1,x2,x3,x4,x) \<rightarrow> setHIDDENM2 equals
  a1 *XCMPLX-0K3 ((((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2))*XCMPLX-0K3 (x -XCMPLX-0K6 x3))*XCMPLX-0K3 (x -XCMPLX-0K6 x4))"
proof-
  (*coherence*)
    show "a1 *XCMPLX-0K3 ((((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2))*XCMPLX-0K3 (x -XCMPLX-0K6 x3))*XCMPLX-0K3 (x -XCMPLX-0K6 x4)) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem polyeq_2_cl_3:
  mlet "a1 be RealXREAL-0M1", "x1 be RealXREAL-0M1", "x2 be RealXREAL-0M1", "x3 be RealXREAL-0M1", "x4 be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster Four0POLYEQ-2K2(a1,x1,x2,x3,x4,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Four0POLYEQ-2K2(a1,x1,x2,x3,x4,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_2_th_10:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds a1 <>HIDDENR2 0NUMBERSK6 implies (( for x be RealXREAL-0M1 holds PolynomPOLYEQ-2K1(a1,a2,a3,a4,a5,x) =COMPLEX1R1 Four0POLYEQ-2K2(a1,x1,x2,x3,x4,x)) implies ((((a1 *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a2 *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a3 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 a4 *XCMPLX-0K3 x)+XCMPLX-0K2 a5)/XCMPLX-0K7 a1 =COMPLEX1R1 (((x ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 ((x1 +XCMPLX-0K2 x2)+XCMPLX-0K2 x3)*XCMPLX-0K3 (x ^2SQUARE-1K1 *XCMPLX-0K3 x))+XCMPLX-0K2 ((x1 *XCMPLX-0K3 x3 +XCMPLX-0K2 x2 *XCMPLX-0K3 x3)+XCMPLX-0K2 x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x ^2SQUARE-1K1)-XCMPLX-0K6 ((x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x3)*XCMPLX-0K3 x)-XCMPLX-0K6 (((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2))*XCMPLX-0K3 (x -XCMPLX-0K6 x3))*XCMPLX-0K3 x4)"
sorry

mtheorem polyeq_2_th_11:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds a1 <>HIDDENR2 0NUMBERSK6 implies (( for x be RealXREAL-0M1 holds PolynomPOLYEQ-2K1(a1,a2,a3,a4,a5,x) =COMPLEX1R1 Four0POLYEQ-2K2(a1,x1,x2,x3,x4,x)) implies ((((a1 *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a2 *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a3 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 a4 *XCMPLX-0K3 x)+XCMPLX-0K2 a5)/XCMPLX-0K7 a1 =COMPLEX1R1 (((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (((x1 +XCMPLX-0K2 x2)+XCMPLX-0K2 x3)+XCMPLX-0K2 x4)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((((x1 *XCMPLX-0K3 x2 +XCMPLX-0K2 x1 *XCMPLX-0K3 x3)+XCMPLX-0K2 x1 *XCMPLX-0K3 x4)+XCMPLX-0K2 (x2 *XCMPLX-0K3 x3 +XCMPLX-0K2 x2 *XCMPLX-0K3 x4))+XCMPLX-0K2 x3 *XCMPLX-0K3 x4)*XCMPLX-0K3 x ^2SQUARE-1K1)-XCMPLX-0K6 ((((x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x3 +XCMPLX-0K2 (x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x4)+XCMPLX-0K2 (x1 *XCMPLX-0K3 x3)*XCMPLX-0K3 x4)+XCMPLX-0K2 (x2 *XCMPLX-0K3 x3)*XCMPLX-0K3 x4)*XCMPLX-0K3 x)+XCMPLX-0K2 ((x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x3)*XCMPLX-0K3 x4)"
sorry

mtheorem polyeq_2_th_12:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds a1 <>HIDDENR2 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-2K1(a1,a2,a3,a4,a5,x) =COMPLEX1R1 Four0POLYEQ-2K2(a1,x1,x2,x3,x4,x)) implies ((a2 /XCMPLX-0K7 a1 =COMPLEX1R1 -XCMPLX-0K4 (((x1 +XCMPLX-0K2 x2)+XCMPLX-0K2 x3)+XCMPLX-0K2 x4) & a3 /XCMPLX-0K7 a1 =COMPLEX1R1 (((x1 *XCMPLX-0K3 x2 +XCMPLX-0K2 x1 *XCMPLX-0K3 x3)+XCMPLX-0K2 x1 *XCMPLX-0K3 x4)+XCMPLX-0K2 (x2 *XCMPLX-0K3 x3 +XCMPLX-0K2 x2 *XCMPLX-0K3 x4))+XCMPLX-0K2 x3 *XCMPLX-0K3 x4) & a4 /XCMPLX-0K7 a1 =COMPLEX1R1 -XCMPLX-0K4 ((((x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x3 +XCMPLX-0K2 (x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x4)+XCMPLX-0K2 (x1 *XCMPLX-0K3 x3)*XCMPLX-0K3 x4)+XCMPLX-0K2 (x2 *XCMPLX-0K3 x3)*XCMPLX-0K3 x4)) & a5 /XCMPLX-0K7 a1 =COMPLEX1R1 ((x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x3)*XCMPLX-0K3 x4"
sorry

mtheorem polyeq_2_th_13:
" for a be RealXREAL-0M1 holds  for k be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (( for x be RealXREAL-0M1 holds x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<four>\<^sub>M =COMPLEX1R1 ((k *XCMPLX-0K3 a)*XCMPLX-0K3 x)*XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)) implies ((y  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 k *XCMPLX-0K3 y  |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 k *XCMPLX-0K3 y)+XCMPLX-0K2 \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6)"
sorry

end
