theory fcont_2
  imports fcont_1 binop_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve x, X, X1, Z, Z1 for "setHIDDENM2"
reserve s, g, r, t, p, x0, x1, x2 for "RealXREAL-0M1"
reserve s1, s2, q1 for "Real-SequenceSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mdef fcont_2_def_1 ("uniformly-continuousFCONT-2V1" 70 ) where
"attr uniformly-continuousFCONT-2V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f.  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)))"..

mtheorem fcont_2_th_1:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 iff ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)))"
sorry

mtheorem fcont_2_th_2:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_3:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_4:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_5:
" for X be setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_6:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
  using fcont_2_th_5 sorry

mtheorem fcont_2_th_7:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_8:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Z1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6 implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_9:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_2_th_10:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_11:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1"
sorry

mtheorem fcont_2_th_12:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1 implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be compactRCOMP-1V1"
  using fcont_2_th_9 fcont_1_th_29 sorry

mtheorem fcont_2_th_13:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((Y <>HIDDENR2 {}XBOOLE-0K1 & Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1 implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
  using fcont_2_th_9 fcont_1_th_31 sorry

mtheorem fcont_2_th_14:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be constantVALUED-0V15 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
  using fcont_2_th_10 sorry

mtheorem fcont_2_th_15:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies ( for r be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s))"
sorry

mtheorem fcont_2_th_16:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies ( for r be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .] implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s))"
sorry

mtheorem fcont_2_th_17:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be one-to-oneFUNCT-1V2 & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & p <=XXREAL-0R1 g) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
sorry

mtheorem fcont_2_th_18:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be one-to-oneFUNCT-1V2 & p <=XXREAL-0R1 g) & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g or lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p"
sorry

(*\$N Darboux Theorem*)
mtheorem fcont_2_th_19:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) =XBOOLE-0R4 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
sorry

mtheorem fcont_2_th_20:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
sorry

end
