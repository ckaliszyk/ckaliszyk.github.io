theory binari_2
  imports binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, n for "NatNAT-1M1"
reserve m for " non zeroORDINAL1V8\<bar>NatNAT-1M1"
reserve p, q for "TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
reserve d, d1, d2 for "ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
mlemma binari_2_lm_1:
" for n be NatNAT-1M1 holds  for p be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for q be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (lenFINSEQ-1K4 p =XBOOLE-0R4 n & lenFINSEQ-1K4 q =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies p /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 q /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies p =FINSEQ-1R1 q"
sorry

mdef binari_2_def_1 ("Bin1BINARI-2K1  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func Bin1BINARI-2K1 n \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
sorry
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef binari_2_def_2 ("Neg2BINARI-2K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func Neg2BINARI-2K2\<^bsub>(n)\<^esub> x \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) equals
  'not'BINARITHK3\<^bsub>(n)\<^esub> x +BINARITHK7\<^bsub>(n)\<^esub> Bin1BINARI-2K1 n"
proof-
  (*coherence*)
    show "'not'BINARITHK3\<^bsub>(n)\<^esub> x +BINARITHK7\<^bsub>(n)\<^esub> Bin1BINARI-2K1 n be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
       sorry
qed "sorry"

mdef binari_2_def_3 ("IntvalBINARI-2K3\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func IntvalBINARI-2K3\<^bsub>(n)\<^esub> x \<rightarrow> IntegerINT-1M1 equals
  AbsvalBINARITHK6\<^bsub>(n)\<^esub> x if x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 FALSEMARGREL1K6 otherwise AbsvalBINARITHK6\<^bsub>(n)\<^esub> x -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 n"
proof-
  (*coherence*)
    show "(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 FALSEMARGREL1K6 implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> x be IntegerINT-1M1) & ( not x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 FALSEMARGREL1K6 implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> x -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 n be IntegerINT-1M1)"
       sorry
  (*consistency*)
    show " for it be IntegerINT-1M1 holds  True "
       sorry
qed "sorry"

mdef binari_2_def_4 ("Int-add-ovflBINARI-2K4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func Int-add-ovflBINARI-2K4\<^bsub>(n)\<^esub>(z1,z2) \<rightarrow> ElementSUBSET-1M1-of BOOLEANMARGREL1K5 equals
  ('not'MARGREL1K10 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 'not'MARGREL1K10 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
proof-
  (*coherence*)
    show "('not'MARGREL1K10 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 'not'MARGREL1K10 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
qed "sorry"

mdef binari_2_def_5 ("Int-add-udflBINARI-2K5\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func Int-add-udflBINARI-2K5\<^bsub>(n)\<^esub>(z1,z2) \<rightarrow> ElementSUBSET-1M1-of BOOLEANMARGREL1K5 equals
  (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
proof-
  (*coherence*)
    show "(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
qed "sorry"

mtheorem binari_2_th_1:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 0NUMBERSK6"
sorry

mtheorem binari_2_th_2:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem binari_2_th_3:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M"
sorry

mtheorem binari_2_th_4:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem binari_2_th_5:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n & i =XBOOLE-0R4 \<one>\<^sub>M implies (Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 TRUEMARGREL1K7"
sorry

mtheorem binari_2_th_6:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n & i <>HIDDENR2 \<one>\<^sub>M implies (Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 FALSEMARGREL1K6"
sorry

mtheorem binari_2_th_7:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
sorry

mtheorem binari_2_th_8:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem binari_2_th_9:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds 'not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =FINSEQ-1R1 'not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)"
sorry

mtheorem binari_2_th_10:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
sorry

mtheorem binari_2_th_11:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
sorry

mtheorem binari_2_th_12:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem binari_2_th_13:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m)\<^esub> 'not'BINARITHK3\<^bsub>(m)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
sorry

mtheorem binari_2_th_14:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =FINSEQ-1R1 (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z,Bin1BINARI-2K1 m)) *>)"
sorry

mtheorem binari_2_th_15:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
sorry

mtheorem binari_2_th_16:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
sorry

mdef binari_2_def_6 (" _ -BINARI-2K6\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func x -BINARI-2K6\<^bsub>(n)\<^esub> y \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
sorry
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem binari_2_th_17:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for y be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds x -BINARI-2K6\<^bsub>(m)\<^esub> y =FINSEQ-1R1 x +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> y"
sorry

mtheorem binari_2_th_18:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =FINSEQ-1R1 (z1 +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ((d1 'xor'BINARITHK2 'not'MARGREL1K10 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)) *>)"
sorry

mtheorem binari_2_th_19:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) -XCMPLX-0K6 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
sorry

end
