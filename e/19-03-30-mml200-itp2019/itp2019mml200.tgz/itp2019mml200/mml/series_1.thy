theory series_1
  imports pboole power rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "NatNAT-1M1"
reserve a, p, r for "RealXREAL-0M1"
reserve s, s1, s2, s3 for "Real-SequenceSEQ-1M1"
mtheorem series_1_th_1:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem series_1_th_2:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds ( |.COMPLEX1K10 a.|)to-powerPOWERK2 n =COMPLEX1R1  |.COMPLEX1K10 a to-powerPOWERK2 n.|"
sorry

mtheorem series_1_th_3:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds  |.COMPLEX1K10 a.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 0NUMBERSK6"
sorry

syntax SERIES_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +SERIES-1K1\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "s1 +SERIES-1K1\<^bsub>(X)\<^esub> s2" \<rightharpoonup> "s1 +VALUED-1K1 s2"

mtheorem series_1_add_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>add-closedMEMBEREDV7\<bar>complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "s1 be sequenceNAT-1M2-of X", "s2 be sequenceNAT-1M2-of X"
"cluster s1 +VALUED-1K1 s2 as-term-is sequenceNAT-1M2-of X"
proof
(*coherence*)
  show "s1 +VALUED-1K1 s2 be sequenceNAT-1M2-of X"
sorry
qed "sorry"

mdef series_1_def_1 ("Partial-SumsSERIES-1K2  _ " [350]350 ) where
  mlet "s be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"func Partial-SumsSERIES-1K2 s \<rightarrow> complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 means
  \<lambda>it. it .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-1K1 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .FUNCT-1K1 n +XCMPLX-0K2 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 st it .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-1K1 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .FUNCT-1K1 n +XCMPLX-0K2 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for it2 be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds (it1 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-1K1 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it1 .FUNCT-1K1 n +XCMPLX-0K2 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & (it2 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 s .FUNCT-1K1 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it2 .FUNCT-1K1 n +XCMPLX-0K2 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem series_1_cl_1:
  mlet "s be real-valuedVALUED-0V7\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"cluster Partial-SumsSERIES-1K2 s as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "Partial-SumsSERIES-1K2 s be real-valuedVALUED-0V7"
sorry
qed "sorry"

abbreviation(input) SERIES_1K3("Partial-SumsSERIES-1K3  _ " [350]350) where
  "Partial-SumsSERIES-1K3 s \<equiv> Partial-SumsSERIES-1K2 s"

mtheorem series_1_add_2:
  mlet "s be Real-SequenceSEQ-1M1"
"cluster Partial-SumsSERIES-1K2 s as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "Partial-SumsSERIES-1K2 s be Real-SequenceSEQ-1M1"
sorry
qed "sorry"

mdef series_1_def_2 ("summableSERIES-1V1" 70 ) where
"attr summableSERIES-1V1 for Real-SequenceSEQ-1M1 means
  (\<lambda>s. Partial-SumsSERIES-1K3 s be convergentSEQ-2V5)"..

mdef series_1_def_3 ("SumSERIES-1K4  _ " [260]260 ) where
  mlet "s be Real-SequenceSEQ-1M1"
"func SumSERIES-1K4 s \<rightarrow> RealXREAL-0M1 equals
  limSEQ-2K1 Partial-SumsSERIES-1K3 s"
proof-
  (*coherence*)
    show "limSEQ-2K1 Partial-SumsSERIES-1K3 s be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem series_1_th_4:
" for s be Real-SequenceSEQ-1M1 holds s be summableSERIES-1V1 implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 0NUMBERSK6"
sorry

mlemma series_1_lm_1:
" for seq be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for seq1 be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for seq2 be complex-valuedVALUED-0V5\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds seq =FUNCT-1R1 seq1 +VALUED-1K1 seq2 iff ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 seq1 .FUNCT-1K1 n +XCMPLX-0K2 seq2 .FUNCT-1K1 n)"
sorry

mtheorem series_1_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>add-closedMEMBEREDV7\<bar>complex-memberedMEMBEREDV1\<bar>setHIDDENM2 holds  for s1 be sequenceNAT-1M2-of X holds  for s2 be sequenceNAT-1M2-of X holds Partial-SumsSERIES-1K2 s1 +VALUED-1K1 Partial-SumsSERIES-1K2 s2 =FUNCT-1R1 Partial-SumsSERIES-1K2 (s1 +SERIES-1K1\<^bsub>(X)\<^esub> s2)"
sorry

mtheorem series_1_th_6:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds Partial-SumsSERIES-1K3 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 s2 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 (s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)"
sorry

mtheorem series_1_th_7:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be summableSERIES-1V1 & s2 be summableSERIES-1V1 implies s1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> s2 be summableSERIES-1V1 & SumSERIES-1K4 (s1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> s2) =COMPLEX1R1 SumSERIES-1K4 s1 +XCMPLX-0K2 SumSERIES-1K4 s2"
sorry

mtheorem series_1_th_8:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be summableSERIES-1V1 & s2 be summableSERIES-1V1 implies s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be summableSERIES-1V1 & SumSERIES-1K4 (s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2) =COMPLEX1R1 SumSERIES-1K4 s1 -XCMPLX-0K6 SumSERIES-1K4 s2"
sorry

mtheorem series_1_th_9:
" for r be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds Partial-SumsSERIES-1K3 (r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 s"
sorry

mtheorem series_1_th_10:
" for r be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds s be summableSERIES-1V1 implies r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s be summableSERIES-1V1 & SumSERIES-1K4 (r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s) =COMPLEX1R1 r *XCMPLX-0K3 SumSERIES-1K4 s"
sorry

mtheorem series_1_th_11:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) implies Partial-SumsSERIES-1K3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
sorry

mtheorem series_1_th_12:
" for s be Real-SequenceSEQ-1M1 holds s be summableSERIES-1V1 implies ( for n be NatNAT-1M1 holds s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n be summableSERIES-1V1)"
sorry

mtheorem series_1_th_13:
" for s be Real-SequenceSEQ-1M1 holds ( ex n be NatNAT-1M1 st s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n be summableSERIES-1V1) implies s be summableSERIES-1V1"
sorry

mtheorem series_1_th_14:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem series_1_th_15:
" for s be Real-SequenceSEQ-1M1 holds s be summableSERIES-1V1 implies ( for n be NatNAT-1M1 holds SumSERIES-1K4 s =COMPLEX1R1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

mtheorem series_1_th_16:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies Partial-SumsSERIES-1K3 s be non-decreasingVALUED-0V11"
sorry

mtheorem series_1_th_17:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies (Partial-SumsSERIES-1K3 s be bounded-aboveSEQ-2V3 iff s be summableSERIES-1V1)"
sorry

mtheorem series_1_th_18:
" for s be Real-SequenceSEQ-1M1 holds s be summableSERIES-1V1 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies 0NUMBERSK6 <=XXREAL-0R1 SumSERIES-1K4 s"
sorry

mtheorem series_1_th_19:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & s1 be summableSERIES-1V1) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies s2 be summableSERIES-1V1"
sorry

mtheorem series_1_th_20:
" for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & s2 be summableSERIES-1V1 implies s1 be summableSERIES-1V1 & SumSERIES-1K4 s1 <=XXREAL-0R1 SumSERIES-1K4 s2"
sorry

mtheorem series_1_th_21:
" for s be Real-SequenceSEQ-1M1 holds s be summableSERIES-1V1 iff ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 r))"
  using seq_4_th_41 sorry

(*\$N Sum of a Geometric Series*)
mtheorem series_1_th_22:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 (a GeoSeqPREPOWERK1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 a to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
sorry

mtheorem series_1_th_23:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 a *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
sorry

mtheorem series_1_th_24:
" for a be RealXREAL-0M1 holds  |.COMPLEX1K10 a.| <XXREAL-0R3 \<one>\<^sub>M implies a GeoSeqPREPOWERK1 be summableSERIES-1V1 & SumSERIES-1K4 (a GeoSeqPREPOWERK1) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
sorry

mtheorem series_1_th_25:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds  |.COMPLEX1K10 a.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 a *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies s be summableSERIES-1V1 & SumSERIES-1K4 s =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
sorry

mtheorem series_1_th_26:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 <XXREAL-0R3 \<one>\<^sub>M implies s be summableSERIES-1V1"
sorry

mtheorem series_1_th_27:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not s be summableSERIES-1V1"
sorry

mtheorem series_1_th_28:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 <XXREAL-0R3 \<one>\<^sub>M implies s be summableSERIES-1V1"
sorry

mtheorem series_1_th_29:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not s be summableSERIES-1V1"
sorry

mtheorem series_1_th_30:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 >XXREAL-0R4 \<one>\<^sub>M implies  not s be summableSERIES-1V1"
sorry

mtheorem series_1_cl_2:
  mlet "k be NatNAT-1M1", "n be NatNAT-1M1"
"cluster k to-powerPOWERK2 n as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "k to-powerPOWERK2 n be naturalORDINAL1V7"
     sorry
qed "sorry"

abbreviation(input) SERIES_1K5(" _ to-powerSERIES-1K5  _ " [220,220]220) where
  "k to-powerSERIES-1K5 n \<equiv> k to-powerPOWERK2 n"

mtheorem series_1_add_3:
  mlet "k be NatNAT-1M1", "n be NatNAT-1M1"
"cluster k to-powerPOWERK2 n as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "k to-powerPOWERK2 n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mtheorem series_1_th_31:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s be non-increasingVALUED-0V12 & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerSERIES-1K5 n *XCMPLX-0K3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> \<two>\<^sub>M to-powerSERIES-1K5 n) implies (s be summableSERIES-1V1 iff s1 be summableSERIES-1V1)"
sorry

mlemma series_1_lm_2:
"\<one>\<^sub>M inHIDDENR3 REALNUMBERSK2"
  using xreal_0_def_1 sorry

mtheorem series_1_th_32:
" for p be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n to-powerPOWERK2 p) implies s be summableSERIES-1V1"
sorry

(*\$N Divergence of the Harmonic Series*)
mtheorem series_1_th_33:
" for p be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds p <=XXREAL-0R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n to-powerPOWERK2 p) implies  not s be summableSERIES-1V1"
sorry

mdef series_1_def_4 ("absolutely-summableSERIES-1V2" 70 ) where
"attr absolutely-summableSERIES-1V2 for Real-SequenceSEQ-1M1 means
  (\<lambda>s. absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s be summableSERIES-1V1)"..

mtheorem series_1_th_34:
" for s be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
sorry

mtheorem series_1_cl_3:
"cluster absolutely-summableSERIES-1V2 also-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be absolutely-summableSERIES-1V2 implies it be summableSERIES-1V1"
sorry
qed "sorry"

mtheorem series_1_th_35:
" for s be Real-SequenceSEQ-1M1 holds s be absolutely-summableSERIES-1V2 implies s be summableSERIES-1V1"
   sorry

mtheorem series_1_th_36:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & s be summableSERIES-1V1 implies s be absolutely-summableSERIES-1V2"
sorry

mtheorem series_1_th_37:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 <XXREAL-0R3 \<one>\<^sub>M implies s be absolutely-summableSERIES-1V2"
sorry

mtheorem series_1_th_38:
" for r be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds r >XXREAL-0R4 0NUMBERSK6 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >=XXREAL-0R2 r) implies  not s be convergentSEQ-2V5 or limSEQ-2K1 s <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem series_1_th_39:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not s be summableSERIES-1V1"
sorry

mtheorem series_1_th_40:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 <XXREAL-0R3 \<one>\<^sub>M implies s be absolutely-summableSERIES-1V2"
sorry

mtheorem series_1_th_41:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not s be summableSERIES-1V1"
sorry

mtheorem series_1_th_42:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 >XXREAL-0R4 \<one>\<^sub>M implies  not s be summableSERIES-1V1"
sorry

(*begin*)
mdef series_1_def_5 ("SumSERIES-1K6'( _ , _ ')" [0,0]260 ) where
  mlet "s be Real-SequenceSEQ-1M1", "n be NatNAT-1M1"
"func SumSERIES-1K6(s,n) \<rightarrow> RealXREAL-0M1 equals
  Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof-
  (*coherence*)
    show "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be RealXREAL-0M1"
       sorry
qed "sorry"

mdef series_1_def_6 ("SumSERIES-1K7'( _ , _ , _ ')" [0,0,0]260 ) where
  mlet "s be Real-SequenceSEQ-1M1", "n be NatNAT-1M1", "m be NatNAT-1M1"
"func SumSERIES-1K7(s,n,m) \<rightarrow> RealXREAL-0M1 equals
  SumSERIES-1K6(s,n) -XCMPLX-0K6 SumSERIES-1K6(s,m)"
proof-
  (*coherence*)
    show "SumSERIES-1K6(s,n) -XCMPLX-0K6 SumSERIES-1K6(s,m) be RealXREAL-0M1"
       sorry
qed "sorry"

end
