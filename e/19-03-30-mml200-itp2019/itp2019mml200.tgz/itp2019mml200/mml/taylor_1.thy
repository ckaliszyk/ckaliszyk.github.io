theory taylor_1
  imports irrat_1 seqfunc card_4
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n for "NatNAT-1M1"
reserve i for "IntegerINT-1M1"
reserve p, x, x0, y for "RealXREAL-0M1"
reserve q for "RationalRAT-1M1"
reserve f for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mdef taylor_1_def_1 ("#ZTAYLOR-1K1  _ " [220]220 ) where
  mlet "q be IntegerINT-1M1"
"func #ZTAYLOR-1K1 q \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x be RealXREAL-0M1 holds it1 .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q) & ( for x be RealXREAL-0M1 holds it2 .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem taylor_1_th_1:
" for x be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
sorry

mtheorem taylor_1_th_2:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 n,x) =COMPLEX1R1 n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem taylor_1_th_3:
" for n be NatNAT-1M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (n *XCMPLX-0K3 (f .FUNCT-1K1 x0)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
sorry

mlemma taylor_1_lm_1:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 n =COMPLEX1R1 exp-RSIN-COSK24 (n *XCMPLX-0K3 x)"
sorry

mtheorem taylor_1_th_4:
" for x be RealXREAL-0M1 holds exp-RSIN-COSK24 (-XCMPLX-0K4 x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
sorry

mlemma taylor_1_lm_2:
" for i be IntegerINT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x)"
sorry

mtheorem taylor_1_th_5:
" for i be IntegerINT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =COMPLEX1R1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
sorry

mtheorem taylor_1_th_6:
" for x be RealXREAL-0M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 (m /XCMPLX-0K7 n) =COMPLEX1R1 exp-RSIN-COSK24 ((m /XCMPLX-0K7 n)*XCMPLX-0K3 x)"
sorry

mlemma taylor_1_lm_3:
" for x be RealXREAL-0M1 holds  for q be RationalRAT-1M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 q =COMPLEX1R1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
sorry

mtheorem taylor_1_th_7:
" for x be RealXREAL-0M1 holds  for q be RationalRAT-1M1 holds (exp-RSIN-COSK24 x)#QPREPOWERK4 q =COMPLEX1R1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
sorry

mtheorem taylor_1_th_8:
" for p be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 p =COMPLEX1R1 exp-RSIN-COSK24 (p *XCMPLX-0K3 x)"
sorry

mtheorem taylor_1_th_9:
" for x be RealXREAL-0M1 holds (((exp-RSIN-COSK24 \<one>\<^sub>M)#RPREPOWERK6 x =COMPLEX1R1 exp-RSIN-COSK24 x & (exp-RSIN-COSK24 \<one>\<^sub>M)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x) & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x) & (number-ePOWERK4)#RPREPOWERK6 x =COMPLEX1R1 exp-RSIN-COSK24 x"
sorry

mtheorem taylor_1_th_10:
" for x be RealXREAL-0M1 holds ((((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)#RPREPOWERK6 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x & ((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)to-powerPOWERK2 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x) & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x) & (number-ePOWERK4)#RPREPOWERK6 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
sorry

mtheorem taylor_1_th_11:
"number-ePOWERK4 >XXREAL-0R4 \<two>\<^sub>M"
sorry

mlemma taylor_1_lm_4:
"number-ePOWERK4 >XXREAL-0R4 \<one>\<^sub>M"
  using xxreal_0_th_2 sorry

mtheorem taylor_1_th_12:
" for x be RealXREAL-0M1 holds logPOWERK3(number-ePOWERK4,exp-RSIN-COSK24 x) =COMPLEX1R1 x"
sorry

mtheorem taylor_1_th_13:
" for x be RealXREAL-0M1 holds logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 x) =COMPLEX1R1 x"
sorry

mtheorem taylor_1_th_14:
" for y be RealXREAL-0M1 holds y >XXREAL-0R4 0NUMBERSK6 implies exp-RSIN-COSK24 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
sorry

mtheorem taylor_1_th_15:
" for y be RealXREAL-0M1 holds y >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
sorry

mtheorem taylor_1_th_16:
"(((((exp-RSIN-COSK23 be one-to-oneFUNCT-1V2 & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2) & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x be RealXREAL-0M1 holds diffFDIFF-1K1(exp-RSIN-COSK23,x) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x)) & ( for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(exp-RSIN-COSK23,x))) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
sorry

mtheorem taylor_1_cl_1:
"cluster exp-RSIN-COSK23 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "exp-RSIN-COSK23 be one-to-oneFUNCT-1V2"
    using taylor_1_th_16 sorry
qed "sorry"

mtheorem taylor_1_th_17:
"(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x)"
sorry

mtheorem taylor_1_cl_2:
"cluster right-open-halflineLIMFUNC1K4 (0NUMBERSK6) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "right-open-halflineLIMFUNC1K4 (0NUMBERSK6) be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef taylor_1_def_2 ("log-TAYLOR-1K2  _ " [164]164 ) where
  mlet "a be RealXREAL-0M1"
"func log-TAYLOR-1K2 a \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))"
sorry
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it1 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it2 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef taylor_1_def_3 ("lnTAYLOR-1K3" 164 ) where
"func lnTAYLOR-1K3 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  log-TAYLOR-1K2 (number-ePOWERK4)"
proof-
  (*coherence*)
    show "log-TAYLOR-1K2 (number-ePOWERK4) be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem taylor_1_th_18:
"((((((lnTAYLOR-1K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> & lnTAYLOR-1K3 be one-to-oneFUNCT-1V2) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 REALNUMBERSK2) & lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) & ( for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x)) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds diffFDIFF-1K1(lnTAYLOR-1K3,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x)) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x))"
sorry

mtheorem taylor_1_th_19:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x0) *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
sorry

mtheorem taylor_1_th_20:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6 implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 f .FUNCT-1K1 x0"
sorry

mdef taylor_1_def_4 ("#RTAYLOR-1K4  _ " [220]220 ) where
  mlet "p be RealXREAL-0M1"
"func #RTAYLOR-1K4 p \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)"
sorry
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it1 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it2 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem taylor_1_th_21:
" for p be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies #RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#RTAYLOR-1K4 p,x) =COMPLEX1R1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
sorry

mtheorem taylor_1_th_22:
" for p be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6 implies #RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(#RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (p *XCMPLX-0K3 (f .FUNCT-1K1 x0)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
sorry

(*begin*)
mdef taylor_1_def_5 ("diffTAYLOR-1K5'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
"func diffTAYLOR-1K5(f,Z) \<rightarrow> Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) st it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds (it1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)) & (it2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef taylor_1_def_6 (" _ is-differentiable-onTAYLOR-1R1'( _ , _ ')" [50,0,0]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "n be NatNAT-1M1", "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
"pred f is-differentiable-onTAYLOR-1R1(n,Z) means
   for i be NatNAT-1M1 holds i <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M implies (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i is-differentiable-onFDIFF-1R2 Z"..

mtheorem taylor_1_th_23:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies f is-differentiable-onTAYLOR-1R1(m,Z))"
sorry

mdef taylor_1_def_7 ("TaylorTAYLOR-1K6'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "Z be SubsetSUBSET-1M2-of REALNUMBERSK2", "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"func TaylorTAYLOR-1K6(f,Z,a,b) \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mlemma taylor_1_lm_5:
" for b be RealXREAL-0M1 holds  ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 b -XCMPLX-0K6 x & ( for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M))"
sorry

mlemma taylor_1_lm_6:
" for n be NatNAT-1M1 holds  for l be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & ( for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
sorry

mlemma taylor_1_lm_7:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for b be RealXREAL-0M1 holds  ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem taylor_1_th_24:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n)"
sorry

mlemma taylor_1_lm_8:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))"
sorry

mlemma taylor_1_lm_9:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
sorry

mtheorem taylor_1_th_25:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for l be RealXREAL-0M1 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6 implies (((g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
sorry

mtheorem taylor_1_th_26:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for b be RealXREAL-0M1 holds  for l be RealXREAL-0M1 holds  ex g be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
sorry

mtheorem taylor_1_th_27:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex c be RealXREAL-0M1 st c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 b =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
sorry

mlemma taylor_1_lm_10:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))"
sorry

mlemma taylor_1_lm_11:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
sorry

mtheorem taylor_1_th_28:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for l be RealXREAL-0M1 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6 implies (((g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
sorry

mtheorem taylor_1_th_29:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex c be RealXREAL-0M1 st c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 a =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
sorry

mtheorem taylor_1_th_30:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z1 c=TARSKIR1 Z implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem taylor_1_th_31:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z1 c=TARSKIR1 Z implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,Z) implies f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,Z1))"
sorry

mtheorem taylor_1_th_32:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ( for n be NatNAT-1M1 holds f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

(*\$N Taylor's Theorem*)
mtheorem taylor_1_th_33:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & 0NUMBERSK6 <XXREAL-0R3 r) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[) implies ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
sorry

end
