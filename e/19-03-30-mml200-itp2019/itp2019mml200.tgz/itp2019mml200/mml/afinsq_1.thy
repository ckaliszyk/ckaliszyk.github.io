theory afinsq_1
  imports ordinal4 finsop_1 funct_7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, n for "NatNAT-1M1"
reserve x, y, z, y1, y2 for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve f, g for "FunctionFUNCT-1M1"
(*\$CT*)
mtheorem afinsq_1_th_2:
" for n be NatNAT-1M1 holds SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n} =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem afinsq_1_th_3:
" for n be NatNAT-1M1 holds SegFINSEQ-1K2 n c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem afinsq_1_th_4:
" for n be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
sorry

mtheorem afinsq_1_th_5:
" for r be FunctionFUNCT-1M1 holds r be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5 iff ( ex n be NatNAT-1M1 st domRELAT-1K1 r =XBOOLE-0R4 n)"
  using finset_1_th_10 sorry

syntax AFINSQ_1M1 :: "Ty" ("XFinSequenceAFINSQ-1M1" 70)
translations "XFinSequenceAFINSQ-1M1" \<rightharpoonup> "finiteFINSET-1V1\<bar>SequenceORDINAL1M4"

reserve p, q, r, s, t for "XFinSequenceAFINSQ-1M1"
mtheorem afinsq_1_cl_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"cluster domRELAT-1K1 p as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "domRELAT-1K1 p be naturalORDINAL1V7"
     sorry
qed "sorry"

abbreviation(input) AFINSQ_1K1("lenAFINSQ-1K1  _ " [228]228) where
  "lenAFINSQ-1K1 p \<equiv> cardCARD-1K1 p"

mtheorem afinsq_1_ident_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"identify cardCARD-1K1 p with domRELAT-1K1 p"
proof
(*compatibility*)
  show "cardCARD-1K1 p =HIDDENR1 domRELAT-1K1 p"
sorry
qed "sorry"

abbreviation(input) AFINSQ_1K2("lenAFINSQ-1K2  _ " [228]228) where
  "lenAFINSQ-1K2 p \<equiv> cardCARD-1K1 p"

mtheorem afinsq_1_add_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"cluster cardCARD-1K1 p as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "cardCARD-1K1 p be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

abbreviation(input) AFINSQ_1K3("domAFINSQ-1K3  _ " [228]228) where
  "domAFINSQ-1K3 p \<equiv> domRELAT-1K1 p"

mtheorem afinsq_1_add_2:
  mlet "p be XFinSequenceAFINSQ-1M1"
"cluster domRELAT-1K1 p as-term-is SubsetSUBSET-1M2-of NATNUMBERSK1"
proof
(*coherence*)
  show "domRELAT-1K1 p be SubsetSUBSET-1M2-of NATNUMBERSK1"
sorry
qed "sorry"

mtheorem afinsq_1_th_6:
" for f be FunctionFUNCT-1M1 holds ( ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 k) implies ( ex p be XFinSequenceAFINSQ-1M1 st f c=RELAT-1R2 p)"
sorry

theorem afinsq_1_sch_1:
  fixes Af0 Pp2 
  assumes
[ty]: "Af0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds k inTARSKIR2 Af0 implies ( ex x be objectHIDDENM1 st Pp2(k,x))"
  shows " ex p be XFinSequenceAFINSQ-1M1 st domAFINSQ-1K3 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 Af0 implies Pp2(k,p .FUNCT-1K1 k))"
sorry

theorem afinsq_1_sch_2:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex p be XFinSequenceAFINSQ-1M1 st lenAFINSQ-1K2 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 Af0 implies p .FUNCT-1K1 k =HIDDENR1 Ff1(k))"
sorry

mtheorem afinsq_1_th_7:
" for z be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds z inHIDDENR3 p implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domAFINSQ-1K3 p & z =HIDDENR1 [TARSKIK4 k,p .FUNCT-1K1 k ])"
sorry

mtheorem afinsq_1_th_8:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds domAFINSQ-1K3 p =XBOOLE-0R4 domAFINSQ-1K3 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
   sorry

mlemma afinsq_1_lm_1:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p iff k inTARSKIR2 domAFINSQ-1K3 p"
sorry

mtheorem afinsq_1_th_9:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
sorry

mtheorem afinsq_1_cl_2:
  mlet "p be XFinSequenceAFINSQ-1M1", "n be NatNAT-1M1"
"cluster p  |RELAT-1K8 n as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "p  |RELAT-1K8 n be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_th_10:
" for f be FunctionFUNCT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f implies f *FUNCT-1K3 p be XFinSequenceAFINSQ-1M1"
sorry

mtheorem afinsq_1_th_11:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies domAFINSQ-1K3 (p  |RELAT-1K8 k) =XBOOLE-0R4 k"
sorry

mtheorem afinsq_1_cl_3:
  mlet "D be setHIDDENM2"
"cluster finiteFINSET-1V1 for SequenceORDINAL1M5-of D"
proof
(*existence*)
  show " ex it be SequenceORDINAL1M5-of D st it be finiteFINSET-1V1"
sorry
qed "sorry"

syntax AFINSQ_1M2 :: " Set \<Rightarrow> Ty" ("XFinSequenceAFINSQ-1M2-of  _ " [70]70)
translations "XFinSequenceAFINSQ-1M2-of D" \<rightharpoonup> "finiteFINSET-1V1\<bar>SequenceORDINAL1M5-of D"

mtheorem afinsq_1_th_12:
" for D be setHIDDENM2 holds  for f be XFinSequenceAFINSQ-1M2-of D holds f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
sorry

mtheorem afinsq_1_cl_4:
"cluster emptyXBOOLE-0V1 also-is Sequence-likeORDINAL1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

reserve D for "setHIDDENM2"
mtheorem afinsq_1_cl_5:
  mlet "k be NatNAT-1M1", "a be objectHIDDENM1"
"cluster SegmCARD-1K5 k -->FUNCOP-1K7 a as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "SegmCARD-1K5 k -->FUNCOP-1K7 a be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

(*\$CT*)
mtheorem afinsq_1_th_14:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex p be XFinSequenceAFINSQ-1M2-of D st lenAFINSQ-1K2 p =XBOOLE-0R4 k"
sorry

mtheorem afinsq_1_th_15:
" for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 0NUMBERSK6 iff p =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem afinsq_1_th_16:
" for D be setHIDDENM2 holds {}XBOOLE-0K1 be XFinSequenceAFINSQ-1M2-of D"
sorry

mtheorem afinsq_1_cl_6:
  mlet "D be setHIDDENM2"
"cluster emptyXBOOLE-0V1 for XFinSequenceAFINSQ-1M2-of D"
proof
(*existence*)
  show " ex it be XFinSequenceAFINSQ-1M2-of D st it be emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem afinsq_1_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for XFinSequenceAFINSQ-1M2-of D"
proof
(*existence*)
  show " ex it be XFinSequenceAFINSQ-1M2-of D st it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef afinsq_1_def_1 ("<%AFINSQ-1K4  _ %>" [0]164 ) where
  mlet "x be objectHIDDENM1"
"func <%AFINSQ-1K4 x%> \<rightarrow> setHIDDENM2 equals
  (0NUMBERSK6).-->FUNCOP-1K17 x"
proof-
  (*coherence*)
    show "(0NUMBERSK6).-->FUNCOP-1K17 x be setHIDDENM2"
       sorry
qed "sorry"

mtheorem afinsq_1_cl_8:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K4 x%> as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<%AFINSQ-1K4 x%> be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mdef afinsq_1_def_2 ("<%>AFINSQ-1K5  _ " [354]354 ) where
  mlet "D be setHIDDENM2"
"func <%>AFINSQ-1K5 D \<rightarrow> XFinSequenceAFINSQ-1M2-of D equals
  {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "{}XBOOLE-0K1 be XFinSequenceAFINSQ-1M2-of D"
      using afinsq_1_th_16 sorry
qed "sorry"

mtheorem afinsq_1_cl_9:
  mlet "D be setHIDDENM2"
"cluster <%>AFINSQ-1K5 D as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<%>AFINSQ-1K5 D be emptyXBOOLE-0V1"
     sorry
qed "sorry"

abbreviation(input) AFINSQ_1K6(" _ ^AFINSQ-1K6  _ " [164,164]164) where
  "p ^AFINSQ-1K6 q \<equiv> p ^ORDINAL4K1 q"

mtheorem afinsq_1_def_3:
  mlet "p be XFinSequenceAFINSQ-1M1", "q be XFinSequenceAFINSQ-1M1"
"redefine func p ^AFINSQ-1K6 q \<rightarrow> setHIDDENM2 means
  \<lambda>it. (domRELAT-1K1 it =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies it .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 p ^AFINSQ-1K6 q iff (domRELAT-1K1 it =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies it .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)"
sorry
qed "sorry"

mtheorem afinsq_1_cl_10:
  mlet "p be XFinSequenceAFINSQ-1M1", "q be XFinSequenceAFINSQ-1M1"
"cluster p ^AFINSQ-1K6 q as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "p ^AFINSQ-1K6 q be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem afinsq_1_th_17:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
  using afinsq_1_def_3 sorry

mtheorem afinsq_1_th_18:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 k & k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q implies (p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
sorry

mtheorem afinsq_1_th_19:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 k & k <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
sorry

mtheorem afinsq_1_th_20:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) implies k inTARSKIR2 domAFINSQ-1K3 p or ( ex n be NatNAT-1M1 st n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)"
sorry

mtheorem afinsq_1_th_21:
" for p be SequenceORDINAL1M4 holds  for q be SequenceORDINAL1M4 holds domRELAT-1K1 p c=ORDINAL1R1 domRELAT-1K1 (p ^ORDINAL4K1 q)"
sorry

mtheorem afinsq_1_th_22:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds x inHIDDENR3 domAFINSQ-1K3 q implies ( ex k be NatNAT-1M1 st k =HIDDENR1 x & lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q))"
sorry

mtheorem afinsq_1_th_23:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
sorry

mtheorem afinsq_1_th_24:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
sorry

mtheorem afinsq_1_th_25:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
sorry

mtheorem afinsq_1_th_26:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
sorry

mtheorem afinsq_1_th_27:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 q)^AFINSQ-1K6 r =FUNCT-1R1 p ^AFINSQ-1K6 (q ^AFINSQ-1K6 r)"
sorry

mtheorem afinsq_1_th_28:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r or r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q implies p =FUNCT-1R1 q"
sorry

mtheorem afinsq_1_reduce_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"reduce p ^AFINSQ-1K6 {}XBOOLE-0K1 to p"
proof
(*reducibility*)
  show "p ^AFINSQ-1K6 {}XBOOLE-0K1 =HIDDENR1 p"
sorry
qed "sorry"

mtheorem afinsq_1_reduce_2:
  mlet "p be XFinSequenceAFINSQ-1M1"
"reduce {}XBOOLE-0K1 ^AFINSQ-1K6 p to p"
proof
(*reducibility*)
  show "{}XBOOLE-0K1 ^AFINSQ-1K6 p =HIDDENR1 p"
sorry
qed "sorry"

(*\$CT*)
mtheorem afinsq_1_th_30:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 {}XBOOLE-0K1 implies p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
sorry

mtheorem afinsq_1_cl_11:
  mlet "D be setHIDDENM2", "p be XFinSequenceAFINSQ-1M2-of D", "q be XFinSequenceAFINSQ-1M2-of D"
"cluster p ^AFINSQ-1K6 q as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "p ^AFINSQ-1K6 q be D -valuedRELAT-1V5"
sorry
qed "sorry"

mlemma afinsq_1_lm_2:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for x1 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
sorry

abbreviation(input) AFINSQ_1K7("<%AFINSQ-1K7  _ %>" [0]164) where
  "<%AFINSQ-1K7 x%> \<equiv> <%AFINSQ-1K4 x%>"

mtheorem afinsq_1_def_4:
  mlet "x be objectHIDDENM1"
"redefine func <%AFINSQ-1K7 x%> \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 \<one>\<^sub>M & it .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-1M1 holds it =HIDDENR1 <%AFINSQ-1K7 x%> iff domRELAT-1K1 it =XBOOLE-0R4 \<one>\<^sub>M & it .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
sorry
qed "sorry"

mtheorem afinsq_1_add_3:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K4 x%> as-term-is FunctionFUNCT-1M1"
proof
(*coherence*)
  show "<%AFINSQ-1K4 x%> be FunctionFUNCT-1M1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_12:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K7 x%> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K7 x%> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_13:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K7 x%> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K7 x%> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
    using afinsq_1_def_4 sorry
qed "sorry"

mtheorem afinsq_1_th_31:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for D be setHIDDENM2 holds p ^AFINSQ-1K6 q be XFinSequenceAFINSQ-1M2-of D implies p be XFinSequenceAFINSQ-1M2-of D & q be XFinSequenceAFINSQ-1M2-of D"
sorry

mdef afinsq_1_def_5 ("<%AFINSQ-1K8 _ , _ %>" [0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"func <%AFINSQ-1K8 x,y %> \<rightarrow> setHIDDENM2 equals
  (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>)"
proof-
  (*coherence*)
    show "(<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>) be setHIDDENM2"
       sorry
qed "sorry"

mdef afinsq_1_def_6 ("<%AFINSQ-1K9 _ , _ , _ %>" [0,0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"func <%AFINSQ-1K9 x,y,z %> \<rightarrow> setHIDDENM2 equals
  ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>))^AFINSQ-1K6 (<%AFINSQ-1K7 z%>)"
proof-
  (*coherence*)
    show "((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>))^AFINSQ-1K6 (<%AFINSQ-1K7 z%>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem afinsq_1_cl_14:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <%AFINSQ-1K8 x,y %> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K8 x,y %> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_15:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <%AFINSQ-1K9 x,y,z %> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K9 x,y,z %> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_16:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <%AFINSQ-1K8 x,y %> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K8 x,y %> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_17:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <%AFINSQ-1K9 x,y,z %> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K9 x,y,z %> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_th_32:
" for x be objectHIDDENM1 holds <%AFINSQ-1K7 x%> =FUNCT-1R1 {TARSKIK1 [TARSKIK4 0NUMBERSK6,x ] }"
  using funct_4_th_82 sorry

mtheorem afinsq_1_th_33:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K7 x%> iff domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
sorry

mtheorem afinsq_1_th_34:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K7 x%> iff lenAFINSQ-1K2 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
  using afinsq_1_def_4 sorry

mtheorem afinsq_1_reduce_3:
  mlet "x be objectHIDDENM1"
"reduce (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6) to x"
proof
(*reducibility*)
  show "(<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
    using afinsq_1_th_34 sorry
qed "sorry"

mtheorem afinsq_1_th_35:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
sorry

mtheorem afinsq_1_th_36:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 lenAFINSQ-1K2 p =HIDDENR1 x"
sorry

mtheorem afinsq_1_th_37:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds <%AFINSQ-1K9 x,y,z %> =FUNCT-1R1 (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K8 y,z %>) & <%AFINSQ-1K9 x,y,z %> =FUNCT-1R1 (<%AFINSQ-1K8 x,y %>)^AFINSQ-1K6 (<%AFINSQ-1K7 z%>)"
  using afinsq_1_th_27 sorry

mtheorem afinsq_1_th_38:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K8 x,y %> iff (lenAFINSQ-1K2 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
sorry

mtheorem afinsq_1_reduce_4:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"reduce (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 (0NUMBERSK6) to x"
proof
(*reducibility*)
  show "(<%AFINSQ-1K8 x,y %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
    using afinsq_1_th_38 sorry
qed "sorry"

mtheorem afinsq_1_reduce_5:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"reduce (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 \<one>\<^sub>M to y"
proof
(*reducibility*)
  show "(<%AFINSQ-1K8 x,y %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
    using afinsq_1_th_38 sorry
qed "sorry"

mtheorem afinsq_1_th_39:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %> iff ((lenAFINSQ-1K2 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
sorry

mtheorem afinsq_1_reduce_6:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"reduce (<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 (0NUMBERSK6) to x"
proof
(*reducibility*)
  show "(<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_reduce_7:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"reduce (<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<one>\<^sub>M to y"
proof
(*reducibility*)
  show "(<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_reduce_8:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"reduce (<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<two>\<^sub>M to z"
proof
(*reducibility*)
  show "(<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_cl_18:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K7 x%> as-term-is \<one>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<%AFINSQ-1K7 x%> be \<one>\<^sub>M -elementCARD-1V3"
    using afinsq_1_th_33 sorry
qed "sorry"

mtheorem afinsq_1_cl_19:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <%AFINSQ-1K8 x,y %> as-term-is \<two>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<%AFINSQ-1K8 x,y %> be \<two>\<^sub>M -elementCARD-1V3"
    using afinsq_1_th_38 sorry
qed "sorry"

mtheorem afinsq_1_cl_20:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <%AFINSQ-1K9 x,y,z %> as-term-is \<three>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<%AFINSQ-1K9 x,y,z %> be \<three>\<^sub>M -elementCARD-1V3"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_cl_21:
  mlet "n be NatNAT-1M1"
"cluster n -elementCARD-1V3 also-is n -definedRELAT-1V4 for XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M1 holds it be n -elementCARD-1V3 implies it be n -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_22:
  mlet "n be NatNAT-1M1", "x be objectHIDDENM1"
"cluster n -->FUNCOP-1K7 x as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "n -->FUNCOP-1K7 x be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_23:
  mlet "n be NatNAT-1M1"
"cluster n -elementCARD-1V3 for XFinSequenceAFINSQ-1M1"
proof
(*existence*)
  show " ex it be XFinSequenceAFINSQ-1M1 st it be n -elementCARD-1V3"
sorry
qed "sorry"

mtheorem afinsq_1_cl_24:
  mlet "n be NatNAT-1M1"
"cluster note-that totalPARTFUN1V1\<^bsub>(n)\<^esub> for n -elementCARD-1V3\<bar>n -definedRELAT-1V4\<bar>XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be n -elementCARD-1V3\<bar>n -definedRELAT-1V4\<bar>XFinSequenceAFINSQ-1M1 holds it be totalPARTFUN1V1\<^bsub>(n)\<^esub>"
sorry
qed "sorry"

mtheorem afinsq_1_th_40:
" for p be XFinSequenceAFINSQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex q be XFinSequenceAFINSQ-1M1 st  ex x be objectHIDDENM1 st p =FUNCT-1R1 q ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
sorry

mtheorem afinsq_1_cl_25:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D"
"cluster <%AFINSQ-1K7 d1%> as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K7 d1%> be D -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_26:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D", "d2 be ElementSUBSET-1M1-of D"
"cluster <%AFINSQ-1K8 d1,d2 %> as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K8 d1,d2 %> be D -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_27:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D", "d2 be ElementSUBSET-1M1-of D", "d3 be ElementSUBSET-1M1-of D"
"cluster <%AFINSQ-1K9 d1,d2,d3 %> as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K9 d1,d2,d3 %> be D -valuedRELAT-1V5"
     sorry
qed "sorry"

theorem afinsq_1_sch_3:
  fixes Pp1 
  assumes
    A1: "Pp1({}XBOOLE-0K1)" and
   A2: " for p be XFinSequenceAFINSQ-1M1 holds  for x be objectHIDDENM1 holds Pp1(p) implies Pp1(p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
  shows " for p be XFinSequenceAFINSQ-1M1 holds Pp1(p)"
sorry

mtheorem afinsq_1_th_41:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r implies ( ex t be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 t =FUNCT-1R1 r)"
sorry

mdef afinsq_1_def_7 (" _ ^omegaAFINSQ-1K10" [164]164 ) where
  mlet "D be setHIDDENM2"
"func D ^omegaAFINSQ-1K10 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be XFinSequenceAFINSQ-1M2-of D"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be XFinSequenceAFINSQ-1M2-of D"
sorry
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be XFinSequenceAFINSQ-1M2-of D) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be XFinSequenceAFINSQ-1M2-of D) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem afinsq_1_cl_28:
  mlet "D be setHIDDENM2"
"cluster D ^omegaAFINSQ-1K10 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "D ^omegaAFINSQ-1K10 be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem afinsq_1_th_42:
" for x be objectHIDDENM1 holds  for D be setHIDDENM2 holds x inHIDDENR3 D ^omegaAFINSQ-1K10 iff x be XFinSequenceAFINSQ-1M2-of D"
  using afinsq_1_def_7 sorry

mtheorem afinsq_1_th_43:
" for D be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 D ^omegaAFINSQ-1K10"
sorry

theorem afinsq_1_sch_4:
  fixes Df0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex X be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex p be XFinSequenceAFINSQ-1M1 st (p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p)"
sorry

abbreviation(input) AFINSQ_1K11("ReplaceAFINSQ-1K11'( _ , _ , _ ')" [0,0,0]164) where
  "ReplaceAFINSQ-1K11(p,i,x) \<equiv> p +*FUNCT-7K1(i,x)"

mtheorem afinsq_1_cl_29:
  mlet "p be XFinSequenceAFINSQ-1M1", "i be objectHIDDENM1", "x be objectHIDDENM1"
"cluster p +*FUNCT-7K1(i,x) as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "p +*FUNCT-7K1(i,x) be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
sorry
qed "sorry"

mtheorem afinsq_1_th_44:
" for p be XFinSequenceAFINSQ-1M1 holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for x be setHIDDENM2 holds (lenAFINSQ-1K2 (ReplaceAFINSQ-1K11(p,i,x)) =XBOOLE-0R4 lenAFINSQ-1K2 p & (i <XXREAL-0R3 lenAFINSQ-1K2 p implies (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 i =XBOOLE-0R4 x)) & ( for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j <>HIDDENR2 i implies (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 j =XBOOLE-0R4 p .FUNCT-1K1 j)"
sorry

mtheorem afinsq_1_cl_30:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be XFinSequenceAFINSQ-1M2-of D", "i be ElementSUBSET-1M1-of NATNUMBERSK1", "a be ElementSUBSET-1M1-of D"
"cluster ReplaceAFINSQ-1K11(p,i,a) as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "ReplaceAFINSQ-1K11(p,i,a) be D -valuedRELAT-1V5"
sorry
qed "sorry"

mtheorem afinsq_1_cl_31:
"cluster note-that real-valuedVALUED-0V7 for XFinSequenceAFINSQ-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M2-of REALNUMBERSK2 holds it be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem afinsq_1_cl_32:
"cluster note-that natural-valuedVALUED-0V8 for XFinSequenceAFINSQ-1M2-of NATNUMBERSK1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M2-of NATNUMBERSK1 holds it be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem afinsq_1_th_45:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds p =FUNCT-1R1 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>) implies (((lenAFINSQ-1K2 p =XBOOLE-0R4 \<four>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
sorry

mtheorem afinsq_1_th_46:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds p =FUNCT-1R1 ((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>) implies ((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<five>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5"
sorry

mtheorem afinsq_1_th_47:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds p =FUNCT-1R1 (((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>) implies (((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<six>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6"
sorry

mtheorem afinsq_1_th_48:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds p =FUNCT-1R1 ((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>) implies ((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<seven>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7"
sorry

mtheorem afinsq_1_th_49:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds p =FUNCT-1R1 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>) implies (((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<eight>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8"
sorry

mtheorem afinsq_1_th_50:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds  for x9 be setHIDDENM2 holds p =FUNCT-1R1 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x9%>) implies ((((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<nine>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x9"
sorry

mtheorem afinsq_1_th_51:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n <XXREAL-0R3 lenAFINSQ-1K2 p implies (p ^AFINSQ-1K6 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
sorry

mtheorem afinsq_1_th_52:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 n implies p  |RELAT-1K8 n =FUNCT-1R1 p"
sorry

mtheorem afinsq_1_th_53:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 lenAFINSQ-1K2 p & k inTARSKIR2 n implies (p  |RELAT-1K8 n).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k & k inTARSKIR2 domAFINSQ-1K3 p"
sorry

mtheorem afinsq_1_th_54:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 lenAFINSQ-1K2 p implies lenAFINSQ-1K2 (p  |RELAT-1K8 n) =XBOOLE-0R4 n"
sorry

mtheorem afinsq_1_th_55:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p  |RELAT-1K8 n) <=XXREAL-0R1 n"
sorry

mtheorem afinsq_1_th_56:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)"
sorry

mtheorem afinsq_1_th_57:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p =FUNCT-1R1 p"
sorry

mtheorem afinsq_1_th_58:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 domAFINSQ-1K3 p implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p  |RELAT-1K8 n"
sorry

mtheorem afinsq_1_th_59:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n =XBOOLE-0R4 domAFINSQ-1K3 p +XCMPLX-0K2 k implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
sorry

mtheorem afinsq_1_th_60:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  ex q be XFinSequenceAFINSQ-1M1 st p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q"
sorry

mtheorem afinsq_1_th_61:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +XCMPLX-0K2 k implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be XFinSequenceAFINSQ-1M1 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 n & lenAFINSQ-1K2 q2 =XBOOLE-0R4 k) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)"
sorry

mtheorem afinsq_1_th_62:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p =FUNCT-1R1 (<%AFINSQ-1K7 y%>)^AFINSQ-1K6 q implies x =HIDDENR1 y & p =FUNCT-1R1 q"
sorry

mdef afinsq_1_def_8 ("FS2XFSAFINSQ-1K12\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "q be FinSequenceFINSEQ-1M3-of D"
"func FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q \<rightarrow> XFinSequenceAFINSQ-1M2-of D means
  \<lambda>it. lenAFINSQ-1K2 it =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be XFinSequenceAFINSQ-1M2-of D st lenAFINSQ-1K2 it =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
sorry
  (*uniqueness*)
    show " for it1 be XFinSequenceAFINSQ-1M2-of D holds  for it2 be XFinSequenceAFINSQ-1M2-of D holds (lenAFINSQ-1K2 it1 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it1 .FUNCT-1K1 i)) & (lenAFINSQ-1K2 it2 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it2 .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

reserve i for "NatNAT-1M1"
mdef afinsq_1_def_9 ("XFS2FSAFINSQ-1K13\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "q be XFinSequenceAFINSQ-1M2-of D"
"func XFS2FSAFINSQ-1K13\<^bsub>(D)\<^esub> q \<rightarrow> FinSequenceFINSEQ-1M3-of D means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of D st lenFINSEQ-1K4 it =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of D holds  for it2 be FinSequenceFINSEQ-1M3-of D holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it1 .FUNCT-1K1 i)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it2 .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem afinsq_1_th_63:
" for D be setHIDDENM2 holds  for n be NatNAT-1M1 holds  for r be setHIDDENM2 holds r inTARSKIR2 D implies n -->FUNCOP-1K7 r be XFinSequenceAFINSQ-1M2-of D"
   sorry

mdef afinsq_1_def_10 ("FS2XFS*AFINSQ-1K14\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "q be FinSequenceFINSEQ-1M3-of D", "n be NatNAT-1M1"
"assume n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D func FS2XFS*AFINSQ-1K14\<^bsub>(D)\<^esub>(q,n) \<rightarrow>  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D means
  \<lambda>it. ((lenFINSEQ-1K4 q =XBOOLE-0R4 it .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)"
proof-
  (*existence*)
    show "n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D implies ( ex it be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D st ((lenFINSEQ-1K4 q =XBOOLE-0R4 it .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6))"
sorry
  (*uniqueness*)
    show "n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D implies ( for it1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds  for it2 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds (((lenFINSEQ-1K4 q =XBOOLE-0R4 it1 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it1 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)) & (((lenFINSEQ-1K4 q =XBOOLE-0R4 it2 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it2 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it2 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it2 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

reserve m for "NatNAT-1M1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mdef afinsq_1_def_11 ("XFS2FS*AFINSQ-1K15\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be XFinSequenceAFINSQ-1M2-of D"
"assume p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p func XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p \<rightarrow> FinSequenceFINSEQ-1M3-of D means
  \<lambda>it.  for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
proof-
  (*existence*)
    show "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p implies ( ex it be FinSequenceFINSEQ-1M3-of D st  for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i))"
sorry
  (*uniqueness*)
    show "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p implies ( for it1 be FinSequenceFINSEQ-1M3-of D holds  for it2 be FinSequenceFINSEQ-1M3-of D holds ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) & ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it2 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it2 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem afinsq_1_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M2-of D holds p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 lenAFINSQ-1K2 p implies XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p =FUNCT-1R1 {}XBOOLE-0K1"
sorry

mdef afinsq_1_def_12 ("initialAFINSQ-1V1" 70 ) where
"attr initialAFINSQ-1V1 for FunctionFUNCT-1M1 means
  (\<lambda>F.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n inTARSKIR2 domRELAT-1K1 F & m <XXREAL-0R3 n implies m inTARSKIR2 domRELAT-1K1 F)"..

mtheorem afinsq_1_cl_33:
"cluster emptyXBOOLE-0V1 also-is initialAFINSQ-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be initialAFINSQ-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_34:
"cluster note-that initialAFINSQ-1V1 for XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M1 holds it be initialAFINSQ-1V1"
sorry
qed "sorry"

mtheorem afinsq_1_cl_35:
"cluster note-that NATNUMBERSK1 -definedRELAT-1V4 for XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M1 holds it be NATNUMBERSK1 -definedRELAT-1V4"
sorry
qed "sorry"

mtheorem afinsq_1_th_65:
" for F be  non emptyXBOOLE-0V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds 0NUMBERSK6 inTARSKIR2 domRELAT-1K1 F"
sorry

mtheorem afinsq_1_cl_36:
"cluster initialAFINSQ-1V1\<bar>finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 also-is Sequence-likeORDINAL1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be initialAFINSQ-1V1\<bar>finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 implies it be Sequence-likeORDINAL1V5"
sorry
qed "sorry"

mtheorem afinsq_1_th_66:
" for F be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for n be NatNAT-1M1 holds n inTARSKIR2 domAFINSQ-1K3 F iff n <XXREAL-0R3 cardCARD-1K4 F"
  using afinsq_1_lm_1 sorry

mtheorem afinsq_1_th_67:
" for F be initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for G be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G implies G be initialAFINSQ-1V1"
  using afinsq_1_def_12 sorry

mtheorem afinsq_1_th_68:
" for F be initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domAFINSQ-1K3 F =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F }"
sorry

mtheorem afinsq_1_th_69:
" for F be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds F c=RELAT-1R2 G & LastLocVALUED-1K65 F =XBOOLE-0R4 LastLocVALUED-1K65 G implies F =FUNCT-1R1 G"
sorry

mtheorem afinsq_1_th_70:
" for F be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
sorry

mtheorem afinsq_1_th_71:
" for F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds FirstLocVALUED-1K67 F =XBOOLE-0R4 0NUMBERSK6"
  using afinsq_1_th_65 valued_1_th_35 sorry

mtheorem afinsq_1_cl_37:
  mlet "F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is initialAFINSQ-1V1"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
sorry
qed "sorry"

reserve l for "NatNAT-1M1"
mtheorem afinsq_1_th_72:
" for I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds domAFINSQ-1K3 I missesXBOOLE-0R1 domRELAT-1K1 (ShiftVALUED-1K64(J,cardCARD-1K4 I))"
sorry

mtheorem afinsq_1_th_73:
" for p be XFinSequenceAFINSQ-1M1 holds  for m be NatNAT-1M1 holds  not m inTARSKIR2 domAFINSQ-1K3 p implies  not m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 p"
sorry

mtheorem afinsq_1_cl_38:
  mlet "D be setHIDDENM2"
"cluster D ^omegaAFINSQ-1K10 as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "D ^omegaAFINSQ-1K10 be functionalFUNCT-1V6"
    using afinsq_1_def_7 sorry
qed "sorry"

mtheorem afinsq_1_cl_39:
  mlet "D be setHIDDENM2"
"cluster note-that finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5 for ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10 holds it be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
    using afinsq_1_def_7 sorry
qed "sorry"

mdef afinsq_1_def_13 ("DownAFINSQ-1K16\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "f be XFinSequenceAFINSQ-1M2-of D"
"func DownAFINSQ-1K16\<^bsub>(D)\<^esub> f \<rightarrow> ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10 equals
  f"
proof-
  (*coherence*)
    show "f be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
      using afinsq_1_def_7 sorry
qed "sorry"

syntax AFINSQ_1K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^AFINSQ-1K17\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "f ^AFINSQ-1K17\<^bsub>(D)\<^esub> g" \<rightharpoonup> "f ^ORDINAL4K1 g"

mtheorem afinsq_1_add_4:
  mlet "D be setHIDDENM2", "f be XFinSequenceAFINSQ-1M2-of D", "g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
"cluster f ^ORDINAL4K1 g as-term-is ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
proof
(*coherence*)
  show "f ^ORDINAL4K1 g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
sorry
qed "sorry"

syntax AFINSQ_1K18 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^AFINSQ-1K18\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "f ^AFINSQ-1K18\<^bsub>(D)\<^esub> g" \<rightharpoonup> "f ^ORDINAL4K1 g"

mtheorem afinsq_1_add_5:
  mlet "D be setHIDDENM2", "f be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10", "g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
"cluster f ^ORDINAL4K1 g as-term-is ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
proof
(*coherence*)
  show "f ^ORDINAL4K1 g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
sorry
qed "sorry"

mtheorem afinsq_1_th_74:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p c=RELAT-1R2 p ^AFINSQ-1K6 q"
sorry

mtheorem afinsq_1_th_75:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem afinsq_1_th_76:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <%AFINSQ-1K8 x,y %> =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(x,y)"
sorry

reserve M for "NatNAT-1M1"
mtheorem afinsq_1_th_77:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 p +*FUNCT-4K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
sorry

mtheorem afinsq_1_th_78:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p +*FUNCT-4K1 (p ^AFINSQ-1K6 q) =FUNCT-1R1 p ^AFINSQ-1K6 q & (p ^AFINSQ-1K6 q)+*FUNCT-4K1 p =FUNCT-1R1 p ^AFINSQ-1K6 q"
  using afinsq_1_th_74 funct_4_th_97 funct_4_th_98 sorry

reserve m, n for "NatNAT-1M1"
mtheorem afinsq_1_th_79:
" for n be NatNAT-1M1 holds  for I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds domRELAT-1K1 (ShiftVALUED-1K64(I,n)) missesXBOOLE-0R1 domRELAT-1K1 (ShiftVALUED-1K64(J,n +NAT-1K1 cardCARD-1K4 I))"
sorry

mtheorem afinsq_1_th_80:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p,n) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
sorry

mtheorem afinsq_1_th_81:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
sorry

mtheorem afinsq_1_th_82:
" for X be setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X implies ShiftVALUED-1K64(p,n) c=RELAT-1R2 X"
sorry

mtheorem afinsq_1_th_83:
" for X be setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X implies ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 X"
sorry

mtheorem afinsq_1_cl_40:
  mlet "F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is initialAFINSQ-1V1"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
     sorry
qed "sorry"

mdef afinsq_1_def_14 ("<%AFINSQ-1K19 _ , _ , _ , _ %>" [0,0,0,0]164 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"func <%AFINSQ-1K19 x1,x2,x3,x4 %> \<rightarrow> setHIDDENM2 equals
  (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>)"
proof-
  (*coherence*)
    show "(((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem afinsq_1_cl_41:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <%AFINSQ-1K19 x1,x2,x3,x4 %> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K19 x1,x2,x3,x4 %> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_42:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <%AFINSQ-1K19 x1,x2,x3,x4 %> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K19 x1,x2,x3,x4 %> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

reserve x1, x2, x3, x4 for "objectHIDDENM1"
mtheorem afinsq_1_th_84:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds lenAFINSQ-1K2 (<%AFINSQ-1K19 x1,x2,x3,x4 %>) =XBOOLE-0R4 \<four>\<^sub>M"
sorry

mlemma afinsq_1_lm_3:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds ((<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x2 & (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x3) & (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4"
sorry

mtheorem afinsq_1_reduce_9:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 (0NUMBERSK6) to x1"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x1"
sorry
qed "sorry"

mtheorem afinsq_1_reduce_10:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M to x2"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x2"
    using afinsq_1_lm_3 sorry
qed "sorry"

mtheorem afinsq_1_reduce_11:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M to x3"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x3"
    using afinsq_1_lm_3 sorry
qed "sorry"

mtheorem afinsq_1_reduce_12:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M to x4"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4"
    using afinsq_1_lm_3 sorry
qed "sorry"

(*\$CT*)
mtheorem afinsq_1_th_86:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p iff k inTARSKIR2 domAFINSQ-1K3 p"
  using afinsq_1_lm_1 sorry

reserve e, u for "objectHIDDENM1"
mtheorem afinsq_1_th_87:
" for n be NatNAT-1M1 holds  for e be objectHIDDENM1 holds SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e =FUNCT-1R1 (SegmCARD-1K5 n -->FUNCOP-1K7 e)^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)"
sorry

mtheorem afinsq_1_th_88:
" for p be XFinSequenceAFINSQ-1M1 holds  for e be objectHIDDENM1 holds domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) =XBOOLE-0R4 {TARSKIK1 cardCARD-1K4 p }"
sorry

mtheorem afinsq_1_th_89:
" for p be XFinSequenceAFINSQ-1M1 holds  for e be objectHIDDENM1 holds domAFINSQ-1K3 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)) =XBOOLE-0R4 domAFINSQ-1K3 p \\/XBOOLE-0K2 {TARSKIK1 cardCARD-1K4 p }"
sorry

mtheorem afinsq_1_th_90:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y) =FUNCT-1R1 <%AFINSQ-1K7 y%>"
sorry

mtheorem afinsq_1_th_91:
" for I be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds LastLocVALUED-1K65 I =XBOOLE-0R4 cardCARD-1K4 I -XCMPLX-0K6 \<one>\<^sub>M"
sorry

end
