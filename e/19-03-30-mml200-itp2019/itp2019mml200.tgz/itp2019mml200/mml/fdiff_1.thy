theory fdiff_1
  imports fcont_1 realset1 finset_1 rvsum_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X for "setHIDDENM2"
reserve x, x0, x1, x2, g, g1, g2, r, r1, s, p, p1 for "RealXREAL-0M1"
reserve n, m, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve s1, s3 for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fdiff_1_th_1:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds r inHIDDENR3 Y iff r inHIDDENR3 REALNUMBERSK2) iff Y =XBOOLE-0R4 REALNUMBERSK2"
sorry

mdef fdiff_1_def_1 (" _ -convergentFDIFF-1V1" [70]70 ) where
  mlet "x be RealXREAL-0M1"
"attr x -convergentFDIFF-1V1 for Real-SequenceSEQ-1M1 means
  (\<lambda>IT. IT be convergentSEQ-2V5 & limSEQ-2K1 IT =COMPLEX1R1 x)"..

mtheorem fdiff_1_cl_1:
"cluster 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9"
sorry
qed "sorry"

mtheorem fdiff_1_cl_2:
  mlet "f be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
"cluster limSEQ-2K1 f as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "limSEQ-2K1 f be zeroORDINAL1V8"
    using fdiff_1_def_1 sorry
qed "sorry"

mtheorem fdiff_1_cl_3:
"cluster 0NUMBERSK6 -convergentFDIFF-1V1 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be 0NUMBERSK6 -convergentFDIFF-1V1 implies it be convergentSEQ-2V5"
     sorry
qed "sorry"

reserve h for "non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
reserve c for "constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
mdef fdiff_1_def_2 ("RestFunc-likeFDIFF-1V2" 70 ) where
"attr RestFunc-likeFDIFF-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>IT. IT be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 0NUMBERSK6))"..

mtheorem fdiff_1_cl_4:
"cluster RestFunc-likeFDIFF-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be RestFunc-likeFDIFF-1V2"
sorry
qed "sorry"

syntax FDIFF_1M1 :: "Ty" ("RestFuncFDIFF-1M1" 70)
translations "RestFuncFDIFF-1M1" \<rightharpoonup> "RestFunc-likeFDIFF-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"

mdef fdiff_1_def_3 ("linearFDIFF-1V3" 70 ) where
"attr linearFDIFF-1V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>IT. IT be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds IT .FUNCT-1K1 p =COMPLEX1R1 r *XCMPLX-0K3 p))"..

mtheorem fdiff_1_cl_5:
"cluster linearFDIFF-1V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be linearFDIFF-1V3"
sorry
qed "sorry"

syntax FDIFF_1M2 :: "Ty" ("LinearFuncFDIFF-1M2" 70)
translations "LinearFuncFDIFF-1M2" \<rightharpoonup> "linearFDIFF-1V3\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"

reserve R, R1, R2 for "RestFuncFDIFF-1M1"
reserve L, L1, L2 for "LinearFuncFDIFF-1M2"
mtheorem fdiff_1_th_2:
" for L1 be LinearFuncFDIFF-1M2 holds  for L2 be LinearFuncFDIFF-1M2 holds L1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2 & L1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be LinearFuncFDIFF-1M2"
sorry

mtheorem fdiff_1_th_3:
" for r be RealXREAL-0M1 holds  for L be LinearFuncFDIFF-1M2 holds r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be LinearFuncFDIFF-1M2"
sorry

mtheorem fdiff_1_th_4:
" for R1 be RestFuncFDIFF-1M1 holds  for R2 be RestFuncFDIFF-1M1 holds (R1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1 & R1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1) & R1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R2 be RestFuncFDIFF-1M1"
sorry

mtheorem fdiff_1_th_5:
" for r be RealXREAL-0M1 holds  for R be RestFuncFDIFF-1M1 holds r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
sorry

mtheorem fdiff_1_th_6:
" for L1 be LinearFuncFDIFF-1M2 holds  for L2 be LinearFuncFDIFF-1M2 holds L1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L2 be RestFunc-likeFDIFF-1V2"
sorry

mtheorem fdiff_1_th_7:
" for R be RestFuncFDIFF-1M1 holds  for L be LinearFuncFDIFF-1M2 holds R (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L be RestFuncFDIFF-1M1 & L (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be RestFuncFDIFF-1M1"
sorry

mdef fdiff_1_def_4 (" _ is-differentiable-inFDIFF-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-differentiable-inFDIFF-1R1 x0 means
   ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))"..

mdef fdiff_1_def_5 ("diffFDIFF-1K1'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"assume f is-differentiable-inFDIFF-1R1 x0 func diffFDIFF-1K1(f,x0) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))"
proof-
  (*existence*)
    show "f is-differentiable-inFDIFF-1R1 x0 implies ( ex it be RealXREAL-0M1 st  ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0))))"
sorry
  (*uniqueness*)
    show "f is-differentiable-inFDIFF-1R1 x0 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it1 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) & ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st it2 =COMPLEX1R1 L .FUNCT-1K1 \<one>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 N implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (x -XCMPLX-0K6 x0)))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef fdiff_1_def_6 (" _ is-differentiable-onFDIFF-1R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-differentiable-onFDIFF-1R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-differentiable-inFDIFF-1R1 x)"..

mtheorem fdiff_1_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X implies X be SubsetSUBSET-1M2-of REALNUMBERSK2"
  using xboole_1_th_1 sorry

mtheorem fdiff_1_th_9:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 Z iff Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inFDIFF-1R1 x)"
sorry

mtheorem fdiff_1_th_10:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 Y implies Y be openRCOMP-1V3"
sorry

mdef fdiff_1_def_7 (" _ `|FDIFF-1K2  _ " [164,164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"assume f is-differentiable-onFDIFF-1R2 X func f `|FDIFF-1K2 X \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))"
proof-
  (*existence*)
    show "f is-differentiable-onFDIFF-1R2 X implies ( ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x)))"
sorry
  (*uniqueness*)
    show "f is-differentiable-onFDIFF-1R2 X implies ( for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it1 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 X & ( for x be RealXREAL-0M1 holds x inHIDDENR3 X implies it2 .FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f,x))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem fdiff_1_th_11:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem fdiff_1_cl_6:
  mlet "h be non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1", "n be NatNAT-1M1"
"cluster h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n as-term-is non-zeroORDINAL1V9 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n implies it be non-zeroORDINAL1V9"
sorry
qed "sorry"

mtheorem fdiff_1_cl_7:
  mlet "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1", "n be NatNAT-1M1"
"cluster h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n as-term-is non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n implies it be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1"
sorry
qed "sorry"

mtheorem fdiff_1_th_12:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds  for N be NeighbourhoodRCOMP-1M1-of x0 holds f is-differentiable-inFDIFF-1R1 x0 & N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
sorry

mtheorem fdiff_1_th_13:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
sorry

mtheorem fdiff_1_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
sorry

mtheorem fdiff_1_th_15:
" for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
sorry

mtheorem fdiff_1_th_16:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 f2 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
sorry

mtheorem fdiff_1_th_17:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M)"
sorry

mtheorem fdiff_1_th_18:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f1 is-differentiable-onFDIFF-1R2 Z) & f2 is-differentiable-onFDIFF-1R2 Z implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x))"
sorry

mtheorem fdiff_1_th_19:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f1 is-differentiable-onFDIFF-1R2 Z) & f2 is-differentiable-onFDIFF-1R2 Z implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1(f2,x))"
sorry

mtheorem fdiff_1_th_20:
" for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f is-differentiable-onFDIFF-1R2 Z implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
sorry

mtheorem fdiff_1_th_21:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f1 is-differentiable-onFDIFF-1R2 Z) & f2 is-differentiable-onFDIFF-1R2 Z implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
sorry

mtheorem fdiff_1_th_22:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be constantFUNCT-1V5 implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem fdiff_1_th_23:
" for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 x +XCMPLX-0K2 p) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =COMPLEX1R1 r)"
sorry

mtheorem fdiff_1_th_24:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-differentiable-inFDIFF-1R1 x0 implies f is-continuous-inFCONT-1R1 x0"
sorry

mtheorem fdiff_1_th_25:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fdiff_1_th_26:
" for X be setHIDDENM2 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 X & Z c=TARSKIR1 X implies f is-differentiable-onFDIFF-1R2 Z"
sorry

mtheorem fdiff_1_th_27:
" ex R be RestFuncFDIFF-1M1 st R .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & R is-continuous-inFCONT-1R1 0NUMBERSK6"
sorry

mdef fdiff_1_def_8 ("differentiableFDIFF-1V4" 70 ) where
"attr differentiableFDIFF-1V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. f is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"..

mlemma fdiff_1_lm_1:
"{}SUBSET-1K1 REALNUMBERSK2 be closedRCOMP-1V2"
  using xboole_1_th_3 sorry

mlemma fdiff_1_lm_2:
"[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3"
  using xboole_1_th_37 fdiff_1_lm_1 sorry

mtheorem fdiff_1_cl_8:
"cluster differentiableFDIFF-1V4 for FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be differentiableFDIFF-1V4"
sorry
qed "sorry"

mtheorem fdiff_1_th_28:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be differentiableFDIFF-1V4\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-differentiable-onFDIFF-1R2 Z"
  using fdiff_1_th_26 fdiff_1_def_8 sorry

end
