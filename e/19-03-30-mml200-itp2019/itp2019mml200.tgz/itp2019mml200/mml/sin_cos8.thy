theory sin_cos8
  imports sin_cos5 polyeq_2 sin_cos7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, w for "RealXREAL-0M1"
reserve n for "ElementSUBSET-1M1-of NATNUMBERSK1"
mlemma sin_cos8_lm_1:
" for x be RealXREAL-0M1 holds (coshSIN-COS2K4 x >=XXREAL-0R2 \<one>\<^sub>M & coshSIN-COS2K4 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) & sinhSIN-COS2K2 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
sorry

mlemma sin_cos8_lm_2:
" for x be RealXREAL-0M1 holds (sinhSIN-COS2K2 x =HIDDENR1 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 \<two>\<^sub>M & coshSIN-COS2K4 x =HIDDENR1 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 \<two>\<^sub>M) & tanhSIN-COS2K6 x =HIDDENR1 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
sorry

mlemma sin_cos8_lm_3:
" for x be RealXREAL-0M1 holds (coshSIN-COS2K4 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinhSIN-COS2K2 x)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M & (coshSIN-COS2K4 x)*XCMPLX-0K3 (coshSIN-COS2K4 x) -XCMPLX-0K6 (sinhSIN-COS2K2 x)*XCMPLX-0K3 (sinhSIN-COS2K2 x) =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem sin_cos8_th_1:
" for x be RealXREAL-0M1 holds tanhSIN-COS2K6 x =HIDDENR1 (sinhSIN-COS2K2 x)/XCMPLX-0K7 (coshSIN-COS2K4 x) & tanhSIN-COS2K6 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
sorry

mlemma sin_cos8_lm_4:
" for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies sinhSIN-COS2K2 x <>HIDDENR2 0NUMBERSK6 & tanhSIN-COS2K6 x <>HIDDENR2 0NUMBERSK6"
sorry

mlemma sin_cos8_lm_5:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds y -XCMPLX-0K6 z <>HIDDENR2 0NUMBERSK6 implies sinhSIN-COS2K2 (y /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 z /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
sorry

mlemma sin_cos8_lm_6:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds y +XCMPLX-0K2 z <>HIDDENR2 0NUMBERSK6 implies sinhSIN-COS2K2 (y /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 z /XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
sorry

mlemma sin_cos8_lm_7:
" for x be RealXREAL-0M1 holds (sinhSIN-COS2K2 x)^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<one>\<^sub>M) & (coshSIN-COS2K4 x)^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mlemma sin_cos8_lm_8:
" for x be RealXREAL-0M1 holds ((((sinhSIN-COS2K2 (-XCMPLX-0K4 x) =HIDDENR1 -XCMPLX-0K4 sinhSIN-COS2K2 x & coshSIN-COS2K4 (-XCMPLX-0K4 x) =HIDDENR1 coshSIN-COS2K4 x) & tanhSIN-COS2K6 (-XCMPLX-0K4 x) =HIDDENR1 -XCMPLX-0K4 tanhSIN-COS2K6 x) & cothSIN-COS5K1 (-XCMPLX-0K4 x) =HIDDENR1 -XCMPLX-0K4 cothSIN-COS5K1 x) & sechSIN-COS5K2 (-XCMPLX-0K4 x) =HIDDENR1 sechSIN-COS5K2 x) & cosechSIN-COS5K3 (-XCMPLX-0K4 x) =HIDDENR1 -XCMPLX-0K4 cosechSIN-COS5K3 x"
sorry

mtheorem sin_cos8_th_2:
" for x be RealXREAL-0M1 holds (sinhSIN-COS2K2 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (cosechSIN-COS5K3 x) & coshSIN-COS2K4 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sechSIN-COS5K2 x)) & tanhSIN-COS2K6 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (cothSIN-COS5K1 x)"
sorry

mlemma sin_cos8_lm_9:
" for x be RealXREAL-0M1 holds exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x) >=XXREAL-0R2 \<two>\<^sub>M"
sorry

mtheorem sin_cos8_th_3:
" for x be RealXREAL-0M1 holds (sechSIN-COS5K2 x <=XXREAL-0R1 \<one>\<^sub>M & 0NUMBERSK6 <XXREAL-0R3 sechSIN-COS5K2 x) & sechSIN-COS5K2 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem sin_cos8_th_4:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies tanhSIN-COS2K6 x >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos8_th_5:
" for x be RealXREAL-0M1 holds coshSIN-COS2K4 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K6 x)^2SQUARE-1K1) & sinhSIN-COS2K2 x =HIDDENR1 (tanhSIN-COS2K6 x)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K6 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos8_th_6:
" for x be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (coshSIN-COS2K4 x +XCMPLX-0K2 sinhSIN-COS2K2 x) |^NEWTONK1 n =HIDDENR1 coshSIN-COS2K4 (n *XCMPLX-0K3 x) +XCMPLX-0K2 sinhSIN-COS2K2 (n *XCMPLX-0K3 x) & (coshSIN-COS2K4 x -XCMPLX-0K6 sinhSIN-COS2K2 x) |^NEWTONK1 n =HIDDENR1 coshSIN-COS2K4 (n *XCMPLX-0K3 x) -XCMPLX-0K6 sinhSIN-COS2K2 (n *XCMPLX-0K3 x)"
sorry

mtheorem sin_cos8_th_7:
" for x be RealXREAL-0M1 holds ((((exp-RSIN-COSK24 x =HIDDENR1 coshSIN-COS2K4 x +XCMPLX-0K2 sinhSIN-COS2K2 x & exp-RSIN-COSK24 (-XCMPLX-0K4 x) =HIDDENR1 coshSIN-COS2K4 x -XCMPLX-0K6 sinhSIN-COS2K2 x) & exp-RSIN-COSK24 x =HIDDENR1 (coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M))) & exp-RSIN-COSK24 (-XCMPLX-0K4 x) =HIDDENR1 (coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (coshSIN-COS2K4 (x /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M))) & exp-RSIN-COSK24 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M))) & exp-RSIN-COSK24 (-XCMPLX-0K4 x) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos8_th_8:
" for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies exp-RSIN-COSK24 x =HIDDENR1 (cothSIN-COS5K1 (x /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cothSIN-COS5K1 (x /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M) & exp-RSIN-COSK24 (-XCMPLX-0K4 x) =HIDDENR1 (cothSIN-COS5K1 (x /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cothSIN-COS5K1 (x /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem sin_cos8_th_9:
" for x be RealXREAL-0M1 holds (coshSIN-COS2K4 x +XCMPLX-0K2 sinhSIN-COS2K2 x)/XCMPLX-0K7 (coshSIN-COS2K4 x -XCMPLX-0K6 sinhSIN-COS2K2 x) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 tanhSIN-COS2K6 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 tanhSIN-COS2K6 x)"
sorry

mlemma sin_cos8_lm_10:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((((coshSIN-COS2K4 (y +XCMPLX-0K2 z) =HIDDENR1 (coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) +XCMPLX-0K2 (sinhSIN-COS2K2 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z) & coshSIN-COS2K4 (y -XCMPLX-0K6 z) =HIDDENR1 (coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) -XCMPLX-0K6 (sinhSIN-COS2K2 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z)) & sinhSIN-COS2K2 (y +XCMPLX-0K2 z) =HIDDENR1 (sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) +XCMPLX-0K2 (coshSIN-COS2K4 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z)) & sinhSIN-COS2K2 (y -XCMPLX-0K6 z) =HIDDENR1 (sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) -XCMPLX-0K6 (coshSIN-COS2K4 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z)) & tanhSIN-COS2K6 (y +XCMPLX-0K2 z) =HIDDENR1 (tanhSIN-COS2K6 y +XCMPLX-0K2 tanhSIN-COS2K6 z)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))) & tanhSIN-COS2K6 (y -XCMPLX-0K6 z) =HIDDENR1 (tanhSIN-COS2K6 y -XCMPLX-0K6 tanhSIN-COS2K6 z)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))"
sorry

mtheorem sin_cos8_th_10:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds y <>HIDDENR2 0NUMBERSK6 implies cothSIN-COS5K1 y +XCMPLX-0K2 tanhSIN-COS2K6 z =HIDDENR1 (coshSIN-COS2K4 (y +XCMPLX-0K2 z))/XCMPLX-0K7 ((sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z)) & cothSIN-COS5K1 y -XCMPLX-0K6 tanhSIN-COS2K6 z =HIDDENR1 (coshSIN-COS2K4 (y -XCMPLX-0K6 z))/XCMPLX-0K7 ((sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z))"
sorry

mtheorem sin_cos8_th_11:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (((sinhSIN-COS2K2 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K4 (y +XCMPLX-0K2 z) -XCMPLX-0K6 coshSIN-COS2K4 (y -XCMPLX-0K6 z)) & (sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K2 (y +XCMPLX-0K2 z) +XCMPLX-0K2 sinhSIN-COS2K2 (y -XCMPLX-0K6 z))) & (coshSIN-COS2K4 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K2 (y +XCMPLX-0K2 z) -XCMPLX-0K6 sinhSIN-COS2K2 (y -XCMPLX-0K6 z))) & (coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K4 (y +XCMPLX-0K2 z) +XCMPLX-0K2 coshSIN-COS2K4 (y -XCMPLX-0K6 z))"
sorry

mtheorem sin_cos8_th_12:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (sinhSIN-COS2K2 y)^2SQUARE-1K1 -XCMPLX-0K6 (coshSIN-COS2K4 z)^2SQUARE-1K1 =HIDDENR1 (sinhSIN-COS2K2 (y +XCMPLX-0K2 z))*XCMPLX-0K3 (sinhSIN-COS2K2 (y -XCMPLX-0K6 z)) -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mlemma sin_cos8_lm_11:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((((sinhSIN-COS2K2 y +XCMPLX-0K2 sinhSIN-COS2K2 z =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (y /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 z /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (coshSIN-COS2K4 (y /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 z /XCMPLX-0K7 \<two>\<^sub>M)) & sinhSIN-COS2K2 y -XCMPLX-0K6 sinhSIN-COS2K2 z =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (y /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 z /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (coshSIN-COS2K4 (y /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 z /XCMPLX-0K7 \<two>\<^sub>M))) & coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (y /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 z /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (coshSIN-COS2K4 (y /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 z /XCMPLX-0K7 \<two>\<^sub>M))) & coshSIN-COS2K4 y -XCMPLX-0K6 coshSIN-COS2K4 z =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (y /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 z /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (sinhSIN-COS2K2 (y /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 z /XCMPLX-0K7 \<two>\<^sub>M))) & tanhSIN-COS2K6 y +XCMPLX-0K2 tanhSIN-COS2K6 z =HIDDENR1 (sinhSIN-COS2K2 (y +XCMPLX-0K2 z))/XCMPLX-0K7 ((coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z))) & tanhSIN-COS2K6 y -XCMPLX-0K6 tanhSIN-COS2K6 z =HIDDENR1 (sinhSIN-COS2K2 (y -XCMPLX-0K6 z))/XCMPLX-0K7 ((coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z))"
sorry

mtheorem sin_cos8_th_13:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (sinhSIN-COS2K2 y -XCMPLX-0K6 sinhSIN-COS2K2 z)^2SQUARE-1K1 -XCMPLX-0K6 (coshSIN-COS2K4 y -XCMPLX-0K6 coshSIN-COS2K4 z)^2SQUARE-1K1 =HIDDENR1 \<four>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 ((y -XCMPLX-0K6 z)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 & (coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z)^2SQUARE-1K1 -XCMPLX-0K6 (sinhSIN-COS2K2 y +XCMPLX-0K2 sinhSIN-COS2K2 z)^2SQUARE-1K1 =HIDDENR1 \<four>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 ((y -XCMPLX-0K6 z)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
sorry

mtheorem sin_cos8_th_14:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (sinhSIN-COS2K2 y +XCMPLX-0K2 sinhSIN-COS2K2 z)/XCMPLX-0K7 (sinhSIN-COS2K2 y -XCMPLX-0K6 sinhSIN-COS2K2 z) =HIDDENR1 (tanhSIN-COS2K6 ((y +XCMPLX-0K2 z)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cothSIN-COS5K1 ((y -XCMPLX-0K6 z)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos8_th_15:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z)/XCMPLX-0K7 (coshSIN-COS2K4 y -XCMPLX-0K6 coshSIN-COS2K4 z) =HIDDENR1 (cothSIN-COS5K1 ((y +XCMPLX-0K2 z)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cothSIN-COS5K1 ((y -XCMPLX-0K6 z)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem sin_cos8_th_16:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds y -XCMPLX-0K6 z <>HIDDENR2 0NUMBERSK6 implies (sinhSIN-COS2K2 y +XCMPLX-0K2 sinhSIN-COS2K2 z)/XCMPLX-0K7 (coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z) =HIDDENR1 (coshSIN-COS2K4 y -XCMPLX-0K6 coshSIN-COS2K4 z)/XCMPLX-0K7 (sinhSIN-COS2K2 y -XCMPLX-0K6 sinhSIN-COS2K2 z)"
sorry

mtheorem sin_cos8_th_17:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds y +XCMPLX-0K2 z <>HIDDENR2 0NUMBERSK6 implies (sinhSIN-COS2K2 y -XCMPLX-0K6 sinhSIN-COS2K2 z)/XCMPLX-0K7 (coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z) =HIDDENR1 (coshSIN-COS2K4 y -XCMPLX-0K6 coshSIN-COS2K4 z)/XCMPLX-0K7 (sinhSIN-COS2K2 y +XCMPLX-0K2 sinhSIN-COS2K2 z)"
sorry

mtheorem sin_cos8_th_18:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (sinhSIN-COS2K2 y +XCMPLX-0K2 sinhSIN-COS2K2 z)/XCMPLX-0K7 (coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z) =HIDDENR1 tanhSIN-COS2K6 (y /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 z /XCMPLX-0K7 \<two>\<^sub>M) & (sinhSIN-COS2K2 y -XCMPLX-0K6 sinhSIN-COS2K2 z)/XCMPLX-0K7 (coshSIN-COS2K4 y +XCMPLX-0K2 coshSIN-COS2K4 z) =HIDDENR1 tanhSIN-COS2K6 (y /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 z /XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos8_th_19:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (tanhSIN-COS2K6 y +XCMPLX-0K2 tanhSIN-COS2K6 z)/XCMPLX-0K7 (tanhSIN-COS2K6 y -XCMPLX-0K6 tanhSIN-COS2K6 z) =HIDDENR1 (sinhSIN-COS2K2 (y +XCMPLX-0K2 z))/XCMPLX-0K7 (sinhSIN-COS2K2 (y -XCMPLX-0K6 z))"
sorry

mlemma sin_cos8_lm_12:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M +XCMPLX-0K2 (coshSIN-COS2K4 x +XCMPLX-0K2 coshSIN-COS2K4 x) <>HIDDENR2 0NUMBERSK6"
sorry

mlemma sin_cos8_lm_13:
" for x be RealXREAL-0M1 holds (coshSIN-COS2K4 x +XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6) & (coshSIN-COS2K4 x +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 coshSIN-COS2K4 x <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem sin_cos8_th_20:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((sinhSIN-COS2K2 (y -XCMPLX-0K6 z) +XCMPLX-0K2 sinhSIN-COS2K2 y)+XCMPLX-0K2 sinhSIN-COS2K2 (y +XCMPLX-0K2 z))/XCMPLX-0K7 ((coshSIN-COS2K4 (y -XCMPLX-0K6 z) +XCMPLX-0K2 coshSIN-COS2K4 y)+XCMPLX-0K2 coshSIN-COS2K4 (y +XCMPLX-0K2 z)) =HIDDENR1 tanhSIN-COS2K6 y"
sorry

mlemma sin_cos8_lm_14:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((((sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z))/XCMPLX-0K7 ((coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z)) =HIDDENR1 tanhSIN-COS2K6 y & (sinhSIN-COS2K2 y)*XCMPLX-0K3 (coshSIN-COS2K4 z) =HIDDENR1 (tanhSIN-COS2K6 y)*XCMPLX-0K3 ((coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z))) & sinhSIN-COS2K2 y =HIDDENR1 (tanhSIN-COS2K6 y)*XCMPLX-0K3 (coshSIN-COS2K4 y)) & (sinhSIN-COS2K2 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z) =HIDDENR1 ((tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))*XCMPLX-0K3 ((coshSIN-COS2K4 y)*XCMPLX-0K3 (coshSIN-COS2K4 z))"
sorry

mtheorem sin_cos8_th_21:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds (sinhSIN-COS2K2 ((y +XCMPLX-0K2 z)+XCMPLX-0K2 w) =HIDDENR1 (((((tanhSIN-COS2K6 y +XCMPLX-0K2 tanhSIN-COS2K6 z)+XCMPLX-0K2 tanhSIN-COS2K6 w)+XCMPLX-0K2 ((tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))*XCMPLX-0K3 (tanhSIN-COS2K6 w))*XCMPLX-0K3 (coshSIN-COS2K4 y))*XCMPLX-0K3 (coshSIN-COS2K4 z))*XCMPLX-0K3 (coshSIN-COS2K4 w) & coshSIN-COS2K4 ((y +XCMPLX-0K2 z)+XCMPLX-0K2 w) =HIDDENR1 (((((\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))+XCMPLX-0K2 (tanhSIN-COS2K6 z)*XCMPLX-0K3 (tanhSIN-COS2K6 w))+XCMPLX-0K2 (tanhSIN-COS2K6 w)*XCMPLX-0K3 (tanhSIN-COS2K6 y))*XCMPLX-0K3 (coshSIN-COS2K4 y))*XCMPLX-0K3 (coshSIN-COS2K4 z))*XCMPLX-0K3 (coshSIN-COS2K4 w)) & tanhSIN-COS2K6 ((y +XCMPLX-0K2 z)+XCMPLX-0K2 w) =HIDDENR1 (((tanhSIN-COS2K6 y +XCMPLX-0K2 tanhSIN-COS2K6 z)+XCMPLX-0K2 tanhSIN-COS2K6 w)+XCMPLX-0K2 ((tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))*XCMPLX-0K3 (tanhSIN-COS2K6 w))/XCMPLX-0K7 (((\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K6 z)*XCMPLX-0K3 (tanhSIN-COS2K6 w))+XCMPLX-0K2 (tanhSIN-COS2K6 w)*XCMPLX-0K3 (tanhSIN-COS2K6 y))+XCMPLX-0K2 (tanhSIN-COS2K6 y)*XCMPLX-0K3 (tanhSIN-COS2K6 z))"
sorry

mtheorem sin_cos8_th_22:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds ((coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 y) +XCMPLX-0K2 coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 z))+XCMPLX-0K2 coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 w))+XCMPLX-0K2 coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 ((y +XCMPLX-0K2 z)+XCMPLX-0K2 w)) =HIDDENR1 ((\<four>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (z +XCMPLX-0K2 w)))*XCMPLX-0K3 (coshSIN-COS2K4 (w +XCMPLX-0K2 y)))*XCMPLX-0K3 (coshSIN-COS2K4 (y +XCMPLX-0K2 z))"
sorry

mtheorem sin_cos8_th_23:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds ((((sinhSIN-COS2K2 y)*XCMPLX-0K3 (sinhSIN-COS2K2 z))*XCMPLX-0K3 (sinhSIN-COS2K2 (z -XCMPLX-0K6 y)) +XCMPLX-0K2 ((sinhSIN-COS2K2 z)*XCMPLX-0K3 (sinhSIN-COS2K2 w))*XCMPLX-0K3 (sinhSIN-COS2K2 (w -XCMPLX-0K6 z)))+XCMPLX-0K2 ((sinhSIN-COS2K2 w)*XCMPLX-0K3 (sinhSIN-COS2K2 y))*XCMPLX-0K3 (sinhSIN-COS2K2 (y -XCMPLX-0K6 w)))+XCMPLX-0K2 ((sinhSIN-COS2K2 (z -XCMPLX-0K6 y))*XCMPLX-0K3 (sinhSIN-COS2K2 (w -XCMPLX-0K6 z)))*XCMPLX-0K3 (sinhSIN-COS2K2 (y -XCMPLX-0K6 w)) =HIDDENR1 0NUMBERSK6"
sorry

mtheorem sin_cos8_th_24:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 sqrtSQUARE-1K3 ((coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos8_th_25:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies sinhSIN-COS2K2 (x /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem sin_cos8_th_26:
" for x be RealXREAL-0M1 holds (sinhSIN-COS2K2 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x))*XCMPLX-0K3 (coshSIN-COS2K4 x) & coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) & tanhSIN-COS2K6 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K6 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K6 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos8_th_27:
" for x be RealXREAL-0M1 holds ((((((sinhSIN-COS2K2 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K6 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K6 x)^2SQUARE-1K1) & sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (sinhSIN-COS2K2 x)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)) & sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<three>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x))) & coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x)^2SQUARE-1K1) & coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (coshSIN-COS2K4 x)^2SQUARE-1K1 +XCMPLX-0K2 (sinhSIN-COS2K2 x)^2SQUARE-1K1) & coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K6 x)^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K6 x)^2SQUARE-1K1)) & coshSIN-COS2K4 (\<three>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (coshSIN-COS2K4 x)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x)^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M)) & tanhSIN-COS2K6 (\<three>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 (\<three>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K6 x) +XCMPLX-0K2 (tanhSIN-COS2K6 x) |^NEWTONK1 \<three>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K6 x)^2SQUARE-1K1)"
sorry

mtheorem sin_cos8_th_28:
" for x be RealXREAL-0M1 holds ((sinhSIN-COS2K2 (\<five>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 sinhSIN-COS2K2 x)/XCMPLX-0K7 ((sinhSIN-COS2K2 (\<seven>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (\<five>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x)) =HIDDENR1 (sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 (sinhSIN-COS2K2 (\<five>\<^sub>M *XCMPLX-0K3 x))"
sorry

mtheorem sin_cos8_th_29:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 sqrtSQUARE-1K3 ((coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (coshSIN-COS2K4 x +XCMPLX-0K2 \<one>\<^sub>M))"
sorry

mtheorem sin_cos8_th_30:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies tanhSIN-COS2K6 (x /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 sqrtSQUARE-1K3 ((coshSIN-COS2K4 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (coshSIN-COS2K4 x +XCMPLX-0K2 \<one>\<^sub>M))"
sorry

mtheorem sin_cos8_th_31:
" for x be RealXREAL-0M1 holds (((((sinhSIN-COS2K2 x) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x))/XCMPLX-0K7 \<four>\<^sub>M & (sinhSIN-COS2K2 x) |^NEWTONK1 \<four>\<^sub>M =HIDDENR1 ((coshSIN-COS2K4 (\<four>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 \<eight>\<^sub>M) & (sinhSIN-COS2K2 x) |^NEWTONK1 \<five>\<^sub>M =HIDDENR1 ((sinhSIN-COS2K2 (\<five>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<five>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<one>\<zero>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x))/XCMPLX-0K7 \<one>\<six>\<^sub>M) & (sinhSIN-COS2K2 x) |^NEWTONK1 \<six>\<^sub>M =HIDDENR1 (((coshSIN-COS2K4 (\<six>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<six>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<four>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<one>\<five>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x)))-XCMPLX-0K6 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<three>\<two>\<^sub>M) & (sinhSIN-COS2K2 x) |^NEWTONK1 \<seven>\<^sub>M =HIDDENR1 (((sinhSIN-COS2K2 (\<seven>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<seven>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (\<five>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<two>\<one>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 (\<three>\<^sub>M *XCMPLX-0K3 x)))-XCMPLX-0K6 \<three>\<five>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K2 x))/XCMPLX-0K7 \<six>\<four>\<^sub>M) & (sinhSIN-COS2K2 x) |^NEWTONK1 \<eight>\<^sub>M =HIDDENR1 ((((coshSIN-COS2K4 (\<eight>\<^sub>M *XCMPLX-0K3 x) -XCMPLX-0K6 \<eight>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<six>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<two>\<eight>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<four>\<^sub>M *XCMPLX-0K3 x)))-XCMPLX-0K6 \<five>\<six>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<three>\<five>\<^sub>M)/XCMPLX-0K7 \<one>\<two>\<eight>\<^sub>M"
sorry

mtheorem sin_cos8_th_32:
" for x be RealXREAL-0M1 holds (((((coshSIN-COS2K4 x) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (coshSIN-COS2K4 (\<three>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x))/XCMPLX-0K7 \<four>\<^sub>M & (coshSIN-COS2K4 x) |^NEWTONK1 \<four>\<^sub>M =HIDDENR1 ((coshSIN-COS2K4 (\<four>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<four>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 \<eight>\<^sub>M) & (coshSIN-COS2K4 x) |^NEWTONK1 \<five>\<^sub>M =HIDDENR1 ((coshSIN-COS2K4 (\<five>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<three>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<one>\<zero>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x))/XCMPLX-0K7 \<one>\<six>\<^sub>M) & (coshSIN-COS2K4 x) |^NEWTONK1 \<six>\<^sub>M =HIDDENR1 (((coshSIN-COS2K4 (\<six>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<six>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<four>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<one>\<five>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<three>\<two>\<^sub>M) & (coshSIN-COS2K4 x) |^NEWTONK1 \<seven>\<^sub>M =HIDDENR1 (((coshSIN-COS2K4 (\<seven>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<seven>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<five>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<two>\<one>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<three>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<three>\<five>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 x))/XCMPLX-0K7 \<six>\<four>\<^sub>M) & (coshSIN-COS2K4 x) |^NEWTONK1 \<eight>\<^sub>M =HIDDENR1 ((((coshSIN-COS2K4 (\<eight>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<six>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<two>\<eight>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<four>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<five>\<six>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 x)))+XCMPLX-0K2 \<three>\<five>\<^sub>M)/XCMPLX-0K7 \<one>\<two>\<eight>\<^sub>M"
sorry

mtheorem sin_cos8_th_33:
" for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 y) +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 z) =HIDDENR1 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K2 y)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK18 z)^2SQUARE-1K1) & coshSIN-COS2K4 (\<two>\<^sub>M *XCMPLX-0K3 y) -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 z) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K2 y)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 z)^2SQUARE-1K1)"
sorry

end
