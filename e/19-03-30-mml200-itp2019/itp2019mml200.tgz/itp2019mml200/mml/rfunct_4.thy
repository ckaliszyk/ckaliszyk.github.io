theory rfunct_4
  imports rfunct_3 measure5 fcont_1 card_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, p, r, r1, r2, s, s1, s2, x0, x for "RealXREAL-0M1"
reserve f, g for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
reserve X, Y for "setHIDDENM2"
mtheorem rfunct_4_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
sorry

mtheorem rfunct_4_th_2:
" for n be NatNAT-1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(R1 ^FINSEQ-1K8 (<*FINSEQ-1K10 r1*>),R2 ^FINSEQ-1K8 (<*FINSEQ-1K10 r2*>)) =FINSEQ-1R1 mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K8 (<*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>)"
sorry

mtheorem rfunct_4_th_3:
" for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 R =COMPLEX1R1 0NUMBERSK6 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 <=XXREAL-0R1 R .FUNCT-1K1 i) implies ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies R .FUNCT-1K1 i =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem rfunct_4_th_4:
" for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 =COMPLEX1R1 R .FUNCT-1K1 i) implies R =FINSEQ-1R1 n  |->FINSEQ-2K2 (0NUMBERSK6)"
sorry

mtheorem rfunct_4_th_5:
" for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) =FINSEQ-1R1 n  |->FINSEQ-2K2 (0NUMBERSK6)"
sorry

(*begin*)
mdef rfunct_4_def_1 (" _ is-strictly-convex-onRFUNCT-4R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-strictly-convex-onRFUNCT-4R1 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"..

mtheorem rfunct_4_th_6:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X implies f is-convex-onRFUNCT-3R2 X"
sorry

mtheorem rfunct_4_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .] iff [.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 [.RCOMP-1K1 a,b .] & s inHIDDENR3 [.RCOMP-1K1 a,b .]) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
sorry

mtheorem rfunct_4_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)"
sorry

mtheorem rfunct_4_th_9:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-convex-onRFUNCT-4R1 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)"
sorry

mtheorem rfunct_4_th_10:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & Y c=TARSKIR1 X implies f is-strictly-convex-onRFUNCT-4R1 Y"
  using xboole_1_th_1 sorry

mlemma rfunct_4_lm_1:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X implies f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X"
sorry

mtheorem rfunct_4_th_11:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X iff f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X"
sorry

mlemma rfunct_4_lm_2:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 r implies (f is-strictly-convex-onRFUNCT-4R1 X implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X)"
sorry

mtheorem rfunct_4_th_12:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 r implies (f is-strictly-convex-onRFUNCT-4R1 X iff r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X)"
sorry

mtheorem rfunct_4_th_13:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & g is-strictly-convex-onRFUNCT-4R1 X implies f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
sorry

mtheorem rfunct_4_th_14:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & g is-convex-onRFUNCT-3R2 X implies f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
sorry

mtheorem rfunct_4_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds (f is-strictly-convex-onRFUNCT-4R1 X & g is-strictly-convex-onRFUNCT-4R1 X) & (a >XXREAL-0R4 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 or a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) implies a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
sorry

mtheorem rfunct_4_th_16:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-convex-onRFUNCT-3R2 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))"
sorry

mtheorem rfunct_4_th_17:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))"
sorry

mtheorem rfunct_4_th_18:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> implies (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F))) implies f is-convex-onRFUNCT-3R2 REALNUMBERSK2)"
sorry

mtheorem rfunct_4_th_19:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 REALNUMBERSK2 implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F)))"
sorry

mtheorem rfunct_4_th_20:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for I be IntervalMEASURE5M1 holds  for a be RealXREAL-0M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 I & x2 inHIDDENR3 I) & x1 <XXREAL-0R3 a) & a <XXREAL-0R3 x2) & f is-convex-onRFUNCT-3R2 I implies f is-continuous-inFCONT-1R1 a"
sorry

(*begin*)
mdef rfunct_4_def_2 (" _ is-quasiconvex-onRFUNCT-4R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-quasiconvex-onRFUNCT-4R2 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"..

mdef rfunct_4_def_3 (" _ is-strictly-quasiconvex-onRFUNCT-4R3  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-strictly-quasiconvex-onRFUNCT-4R3 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"..

mdef rfunct_4_def_4 (" _ is-strongly-quasiconvex-onRFUNCT-4R4  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-strongly-quasiconvex-onRFUNCT-4R4 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"..

mdef rfunct_4_def_5 (" _ is-upper-semicontinuous-inRFUNCT-4R5  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-upper-semicontinuous-inRFUNCT-4R5 x0 means
  x0 inHIDDENR3 domRELAT-1K1 f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r)))"..

mdef rfunct_4_def_6 (" _ is-upper-semicontinuous-onRFUNCT-4R6  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-upper-semicontinuous-onRFUNCT-4R6 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-upper-semicontinuous-inRFUNCT-4R5 x0)"..

mdef rfunct_4_def_7 (" _ is-lower-semicontinuous-inRFUNCT-4R7  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-lower-semicontinuous-inRFUNCT-4R7 x0 means
  x0 inHIDDENR3 domRELAT-1K1 f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r)))"..

mdef rfunct_4_def_8 (" _ is-lower-semicontinuous-onRFUNCT-4R8  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-lower-semicontinuous-onRFUNCT-4R8 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-lower-semicontinuous-inRFUNCT-4R7 x0)"..

mtheorem rfunct_4_th_21:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELAT-1K1 f implies (f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0 iff f is-continuous-inFCONT-1R1 x0)"
sorry

mtheorem rfunct_4_th_22:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELAT-1K1 f implies (f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X iff f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
sorry

mtheorem rfunct_4_th_23:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-convex-onRFUNCT-4R1 X implies f is-strongly-quasiconvex-onRFUNCT-4R4 X"
sorry

mtheorem rfunct_4_th_24:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strongly-quasiconvex-onRFUNCT-4R4 X implies f is-quasiconvex-onRFUNCT-4R2 X"
sorry

mtheorem rfunct_4_th_25:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 X implies f is-strictly-quasiconvex-onRFUNCT-4R3 X"
sorry

mtheorem rfunct_4_th_26:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strongly-quasiconvex-onRFUNCT-4R4 X implies f is-strictly-quasiconvex-onRFUNCT-4R3 X"
   sorry

mtheorem rfunct_4_th_27:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-quasiconvex-onRFUNCT-4R3 X & f be one-to-oneFUNCT-1V2 implies f is-strongly-quasiconvex-onRFUNCT-4R4 X"
  using funct_1_def_4 sorry

end
