theory seq_4
  imports xxreal_2 seqm_3 member_1 rvsum_1 axioms fraenkel
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, k, k1, m, m1, n1, n2, l for "NatNAT-1M1"
reserve r, r1, r2, p, p1, g, g1, g2, s, s1, s2, t for "RealXREAL-0M1"
reserve seq, seq1, seq2 for "Real-SequenceSEQ-1M1"
reserve Nseq for "increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
reserve X, Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
mtheorem seq_4_th_1:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <XXREAL-0R3 p) implies ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <=XXREAL-0R1 g & g <=XXREAL-0R1 p)"
sorry

mtheorem seq_4_th_2:
" for p be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (0NUMBERSK6 <XXREAL-0R3 p & ( ex r be RealXREAL-0M1 st r inHIDDENR3 X)) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r +XCMPLX-0K2 p inTARSKIR2 X) implies ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st r inHIDDENR3 X & g <XXREAL-0R3 r)"
sorry

mtheorem seq_4_th_3:
" for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st r <XXREAL-0R3 n"
sorry

mtheorem seq_4_th_4:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5 iff ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s))"
sorry

abbreviation(input) SEQ_4K1("{SEQ-4K1  _ }" [0]356) where
  "{SEQ-4K1 r} \<equiv> {TARSKIK1 r}"

mtheorem seq_4_add_1:
  mlet "r be RealXREAL-0M1"
"cluster {TARSKIK1 r} as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "{TARSKIK1 r} be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mtheorem seq_4_th_5:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 implies ( ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g -XCMPLX-0K6 s <XXREAL-0R3 r)))"
sorry

mtheorem seq_4_th_6:
" for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds  for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ((( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g1) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g1 -XCMPLX-0K6 s <XXREAL-0R3 r))) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g2)) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g2 -XCMPLX-0K6 s <XXREAL-0R3 r)) implies g1 =COMPLEX1R1 g2"
sorry

mtheorem seq_4_th_7:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 implies ( ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g +XCMPLX-0K2 s)))"
sorry

mtheorem seq_4_th_8:
" for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds  for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ((( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g1 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g1 +XCMPLX-0K2 s))) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g2 <=XXREAL-0R1 r)) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g2 +XCMPLX-0K2 s)) implies g1 =COMPLEX1R1 g2"
sorry

mdef seq_4_def_1 ("upper-boundSEQ-4K2  _ " [228]228 ) where
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"assume X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 func upper-boundSEQ-4K2 X \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it -XCMPLX-0K6 s <XXREAL-0R3 r))"
proof-
  (*existence*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 implies ( ex it be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it -XCMPLX-0K6 s <XXREAL-0R3 r)))"
sorry
  (*uniqueness*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it1) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it1 -XCMPLX-0K6 s <XXREAL-0R3 r))) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it2) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it2 -XCMPLX-0K6 s <XXREAL-0R3 r))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef seq_4_def_2 ("lower-boundSEQ-4K3  _ " [228]228 ) where
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"assume X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 func lower-boundSEQ-4K3 X \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it +XCMPLX-0K2 s))"
proof-
  (*existence*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 implies ( ex it be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it +XCMPLX-0K2 s)))"
sorry
  (*uniqueness*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it1 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it1 +XCMPLX-0K2 s))) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it2 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it2 +XCMPLX-0K2 s))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mlemma seq_4_lm_1:
" for r be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies r >=XXREAL-0R2 t) implies r =COMPLEX1R1 lower-boundSEQ-4K3 X"
sorry

mlemma seq_4_lm_2:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies r <=XXREAL-0R1 t) implies r =COMPLEX1R1 upper-boundSEQ-4K2 X"
sorry

mtheorem seq_4_ident_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"identify lower-boundSEQ-4K3 X with infXXREAL-2K2 X"
proof
(*compatibility*)
  show "lower-boundSEQ-4K3 X =HIDDENR1 infXXREAL-2K2 X"
sorry
qed "sorry"

mtheorem seq_4_ident_2:
  mlet "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"identify upper-boundSEQ-4K2 X with supXXREAL-2K1 X"
proof
(*compatibility*)
  show "upper-boundSEQ-4K2 X =HIDDENR1 supXXREAL-2K1 X"
sorry
qed "sorry"

mtheorem seq_4_th_9:
" for r be RealXREAL-0M1 holds lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 r & upper-boundSEQ-4K2 {SEQ-4K1 r} =COMPLEX1R1 r"
  using xxreal_2_th_11 xxreal_2_th_13 sorry

mtheorem seq_4_th_10:
" for r be RealXREAL-0M1 holds lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 upper-boundSEQ-4K2 {SEQ-4K1 r}"
sorry

mtheorem seq_4_th_11:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1 implies lower-boundSEQ-4K3 X <=XXREAL-0R1 upper-boundSEQ-4K2 X"
sorry

mtheorem seq_4_th_12:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1 implies (( ex r be RealXREAL-0M1 st  ex p be RealXREAL-0M1 st (r inHIDDENR3 X & p inHIDDENR3 X) & p <>HIDDENR2 r) iff lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X)"
sorry

mtheorem seq_4_th_13:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
sorry

mtheorem seq_4_cl_1:
  mlet "seq be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq implies it be convergentSEQ-2V5"
    using seq_4_th_13 sorry
qed "sorry"

mtheorem seq_4_th_14:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1  |.COMPLEX1K10 limSEQ-2K1 seq .|"
sorry

mtheorem seq_4_th_15:
" for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6 implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem seq_4_th_16:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq be convergentSEQ-2V5 implies seq1 be convergentSEQ-2V5"
sorry

mtheorem seq_4_th_17:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq be convergentSEQ-2V5 implies limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
sorry

mtheorem seq_4_th_18:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq1 be convergentSEQ-2V5"
sorry

mtheorem seq_4_th_19:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq1"
sorry

mtheorem seq_4_cl_2:
  mlet "seq be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1", "k be NatNAT-1M1"
"cluster seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k implies it be convergentSEQ-2V5"
    using seq_4_th_16 sorry
qed "sorry"

mtheorem seq_4_th_20:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limSEQ-2K1 seq"
  using seq_4_th_17 sorry

mtheorem seq_4_th_21:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5 implies seq be convergentSEQ-2V5"
sorry

mtheorem seq_4_th_22:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5 implies limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
sorry

mtheorem seq_4_th_23:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9)"
sorry

mtheorem seq_4_th_24:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex seq1 be Real-SequenceSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9)"
sorry

mtheorem seq_4_th_25:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 & (r inHIDDENR3 rngRVSUM-1K1 seq or ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)) implies limSEQ-2K1 seq =COMPLEX1R1 r"
sorry

mtheorem seq_4_th_26:
" for seq be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 implies ( for n be NatNAT-1M1 holds limSEQ-2K1 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seq_4_th_25 sorry

mtheorem seq_4_th_27:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9 implies limSEQ-2K1 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5)"
sorry

(*\$CT 3*)
mlemma seq_4_lm_3:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p))"
sorry

mlemma seq_4_lm_4:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5"
sorry

mlemma seq_4_lm_5:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem seq_4_th_31:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
sorry

(*\$CT 3*)
mlemma seq_4_lm_6:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p))"
sorry

mlemma seq_4_lm_7:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5"
sorry

mlemma seq_4_lm_8:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem seq_4_th_35:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem seq_4_cl_3:
"cluster non-decreasingSEQM-3V3\<bar>bounded-aboveSEQ-2V3 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be non-decreasingSEQM-3V3\<bar>bounded-aboveSEQ-2V3 implies it be convergentSEQ-2V5"
sorry
qed "sorry"

mtheorem seq_4_cl_4:
"cluster non-increasingSEQM-3V4\<bar>bounded-belowSEQ-2V4 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be non-increasingSEQM-3V4\<bar>bounded-belowSEQ-2V4 implies it be convergentSEQ-2V5"
sorry
qed "sorry"

mtheorem seq_4_cl_5:
"cluster monotoneSEQM-3V5\<bar>boundedSEQ-2V6 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be monotoneSEQM-3V5\<bar>boundedSEQ-2V6 implies it be convergentSEQ-2V5"
sorry
qed "sorry"

mtheorem seq_4_th_36:
" for seq be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 & seq be boundedSEQ-2V6 implies seq be convergentSEQ-2V5"
   sorry

mtheorem seq_4_th_37:
" for seq be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 limSEQ-2K1 seq)"
sorry

mtheorem seq_4_th_38:
" for seq be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds limSEQ-2K1 seq <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem seq_4_th_39:
" for seq be Real-SequenceSEQ-1M1 holds  ex Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5"
sorry

(*\$N Bolzano-Weierstrass Theorem (1 dimension)*)
mtheorem seq_4_th_40:
" for seq be Real-SequenceSEQ-1M1 holds seq be boundedSEQ-2V6 implies ( ex seq1 be Real-SequenceSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be convergentSEQ-2V5)"
sorry

(*\$N Cauchy sequence*)
mtheorem seq_4_th_41:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 iff ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s))"
sorry

mtheorem seq_4_th_42:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 & seq1 be convergentSEQ-2V5 implies ((limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limSEQ-2K1 seq1 & limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limSEQ-2K1 seq1) & limSEQ-2K1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 limSEQ-2K1 seq1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)) & limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limSEQ-2K1 seq1)"
sorry

(*begin*)
mtheorem seq_4_th_43:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 t"
sorry

mtheorem seq_4_th_44:
" for r be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies r >=XXREAL-0R2 t) implies r =COMPLEX1R1 lower-boundSEQ-4K3 X"
  using seq_4_lm_1 sorry

mtheorem seq_4_th_45:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies upper-boundSEQ-4K2 X <=XXREAL-0R1 t"
sorry

mtheorem seq_4_th_46:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies r <=XXREAL-0R1 t) implies r =COMPLEX1R1 upper-boundSEQ-4K2 X"
  using seq_4_lm_2 sorry

mtheorem seq_4_th_47:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X c=MEMBEREDR3 Y & Y be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 Y <=XXREAL-0R1 lower-boundSEQ-4K3 X"
sorry

mtheorem seq_4_th_48:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X c=MEMBEREDR3 Y & Y be bounded-aboveXXREAL-2V4 implies upper-boundSEQ-4K2 X <=XXREAL-0R1 upper-boundSEQ-4K2 Y"
sorry

abbreviation(input) SEQ_4K4("minSEQ-4K4  _ " [228]228) where
  "minSEQ-4K4 A \<equiv> infXXREAL-2K2 A"

mtheorem seq_4_add_2:
  mlet "A be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
"cluster infXXREAL-2K2 A as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "infXXREAL-2K2 A be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

(*begin*)
reserve k, n for "NatNAT-1M1"
reserve r, r9, r1, r2 for "RealXREAL-0M1"
reserve c, c9, c1, c2, c3 for "ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
mtheorem seq_4_th_49:
"0cCOMPLEX1K6 is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
  using binop_2_th_1 setwiseo_th_14 sorry

mtheorem seq_4_th_50:
"compcomplexBINOP-2K1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
sorry

mtheorem seq_4_th_51:
"addcomplexBINOP-2K3 be having-an-inverseOpFINSEQOPV1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
  using seq_4_th_50 sorry

mtheorem seq_4_th_52:
"the-inverseOp-wrtFINSEQOPK5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3 =FUNCT-2R2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> compcomplexBINOP-2K1"
  using seq_4_th_50 seq_4_th_51 finseqop_def_3 sorry

abbreviation(input) SEQ_4K5("diffcomplexSEQ-4K5" 228) where
  "diffcomplexSEQ-4K5 \<equiv> diffcomplexBINOP-2K4"

mtheorem seq_4_def_3:
"redefine func diffcomplexSEQ-4K5 \<rightarrow> ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3 :]) equals
  addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3 :]) holds it =HIDDENR1 diffcomplexSEQ-4K5 iff it =HIDDENR1 addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)"
sorry
qed "sorry"

mtheorem seq_4_th_53:
"1rCOMPLEX1K7 is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5"
  using binop_2_th_6 setwiseo_th_14 sorry

mtheorem seq_4_th_54:
"multcomplexBINOP-2K5 is-distributive-wrtBINOP-1R6\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
sorry

mdef seq_4_def_4 (" _ multcomplexSEQ-4K6" [228]228 ) where
  mlet "c be ComplexXCMPLX-0M1"
"func c multcomplexSEQ-4K6 \<rightarrow> UnOpBINOP-1M1-of COMPLEXNUMBERSK3 equals
  multcomplexBINOP-2K5 [;]FUNCOP-1K5(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))"
proof-
  (*coherence*)
    show "multcomplexBINOP-2K5 [;]FUNCOP-1K5(c,idPARTFUN1K6 (COMPLEXNUMBERSK3)) be UnOpBINOP-1M1-of COMPLEXNUMBERSK3"
sorry
qed "sorry"

mlemma seq_4_lm_9:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds (multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))).FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =COMPLEX1R1 c *XCMPLX-0K3 c9"
sorry

mtheorem seq_4_th_55:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds c multcomplexSEQ-4K6 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =COMPLEX1R1 c *XCMPLX-0K3 c9"
  using seq_4_lm_9 sorry

mtheorem seq_4_th_56:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds c multcomplexSEQ-4K6 is-distributive-wrtBINOP-1R12\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
  using seq_4_th_54 finseqop_th_54 sorry

mdef seq_4_def_5 ("abscomplexSEQ-4K7" 228 ) where
"func abscomplexSEQ-4K7 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) means
  \<lambda>it.  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) st  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) holds ( for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|) & ( for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|) implies it1 =HIDDENR1 it2"
      using binop_2_sch_1 sorry
qed "sorry"

reserve z, z1, z2 for "FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
abbreviation(input) SEQ_4K8(" _ +SEQ-4K8  _ " [132,132]132) where
  "z1 +SEQ-4K8 z2 \<equiv> z1 +VALUED-1K1 z2"

mtheorem seq_4_def_6:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func z1 +SEQ-4K8 z2 \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z1 +SEQ-4K8 z2 iff it =HIDDENR1 addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
sorry
qed "sorry"

mtheorem seq_4_add_3:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster z1 +VALUED-1K1 z2 as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z1 +VALUED-1K1 z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
sorry
qed "sorry"

abbreviation(input) SEQ_4K9(" _ -SEQ-4K9  _ " [132,132]132) where
  "z1 -SEQ-4K9 z2 \<equiv> z1 -VALUED-1K47 z2"

mtheorem seq_4_def_7:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func z1 -SEQ-4K9 z2 \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z1 -SEQ-4K9 z2 iff it =HIDDENR1 diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
sorry
qed "sorry"

mtheorem seq_4_add_4:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster z1 -VALUED-1K47 z2 as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z1 -VALUED-1K47 z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
sorry
qed "sorry"

abbreviation(input) SEQ_4K10("-SEQ-4K10  _ " [132]132) where
  "-SEQ-4K10 z \<equiv> -VALUED-1K32 z"

mtheorem seq_4_def_8:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func -SEQ-4K10 z \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 -SEQ-4K10 z iff it =HIDDENR1 compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
sorry
qed "sorry"

mtheorem seq_4_add_5:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster -VALUED-1K32 z as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "-VALUED-1K32 z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
sorry
qed "sorry"

abbreviation(input) SEQ_4K11(" _ *SEQ-4K11  _ " [164,164]164) where
  "c *SEQ-4K11 z \<equiv> c (#)VALUED-1K25 z"

abbreviation(input) SEQ_4K12(" _ *SEQ-4K12  _ " [164,164]164) where
  "c *SEQ-4K12 z \<equiv> c (#)VALUED-1K25 z"

mtheorem seq_4_def_9:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "c be ComplexXCMPLX-0M1"
"redefine func c *SEQ-4K12 z \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 c *SEQ-4K12 z iff it =HIDDENR1 c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
sorry
qed "sorry"

mtheorem seq_4_add_6:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "c be ComplexXCMPLX-0M1"
"cluster c (#)VALUED-1K25 z as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "c (#)VALUED-1K25 z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
sorry
qed "sorry"

abbreviation(input) SEQ_4K13("absSEQ-4K13  _ " [250]250) where
  "absSEQ-4K13 z \<equiv>  |.VALUED-1K56 z.|"

mtheorem seq_4_def_10:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func absSEQ-4K13 z \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 absSEQ-4K13 z iff it =HIDDENR1 abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z"
sorry
qed "sorry"

mtheorem seq_4_add_7:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster  |.VALUED-1K56 z.| as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show " |.VALUED-1K56 z.| be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
sorry
qed "sorry"

mdef seq_4_def_11 ("COMPLEXSEQ-4K14  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func COMPLEXSEQ-4K14 n \<rightarrow> FinSequenceSetFINSEQ-2M1-of COMPLEXNUMBERSK3 equals
  n -tuples-onFINSEQ-2K4 (COMPLEXNUMBERSK3)"
proof-
  (*coherence*)
    show "n -tuples-onFINSEQ-2K4 (COMPLEXNUMBERSK3) be FinSequenceSetFINSEQ-2M1-of COMPLEXNUMBERSK3"
       sorry
qed "sorry"

mtheorem seq_4_cl_6:
  mlet "n be NatNAT-1M1"
"cluster COMPLEXSEQ-4K14 n as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "COMPLEXSEQ-4K14 n be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

reserve x, z, z1, z2, z3 for "ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
reserve A, B for "SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
mlemma seq_4_lm_10:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds domFINSEQ-1K5 z =MEMBEREDR12 SegFINSEQ-1K2 n"
sorry

mtheorem seq_4_th_57:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n implies z .FUNCT-1K1 k inTARSKIR2 COMPLEXNUMBERSK3"
sorry

syntax SEQ_4K15 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +SEQ-4K15\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2" \<rightharpoonup> "z1 +VALUED-1K1 z2"

mtheorem seq_4_add_8:
  mlet "n be NatNAT-1M1", "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster z1 +VALUED-1K1 z2 as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "z1 +VALUED-1K1 z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem seq_4_th_58:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (k inTARSKIR2 SegFINSEQ-1K2 n & c1 =COMPLEX1R1 z1 .FUNCT-1K1 k) & c2 =COMPLEX1R1 z2 .FUNCT-1K1 k implies (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =COMPLEX1R1 c1 +XCMPLX-0K2 c2"
sorry

mdef seq_4_def_12 ("0cSEQ-4K16  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func 0cSEQ-4K16 n \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
proof-
  (*coherence*)
    show "n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
       sorry
qed "sorry"

abbreviation(input) SEQ_4K17("0cSEQ-4K17  _ " [228]228) where
  "0cSEQ-4K17 n \<equiv> 0cSEQ-4K16 n"

mtheorem seq_4_add_9:
  mlet "n be NatNAT-1M1"
"cluster 0cSEQ-4K16 n as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "0cSEQ-4K16 n be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
     sorry
qed "sorry"

mtheorem seq_4_th_59:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =FINSEQ-1R1 z & z =FINSEQ-1R1 0cSEQ-4K17 n +SEQ-4K15\<^bsub>(n)\<^esub> z"
  using binop_2_th_1 finseqop_th_56 sorry

syntax SEQ_4K18 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("-SEQ-4K18\<^bsub>'( _ ')\<^esub>  _ " [0,132]132)
translations "-SEQ-4K18\<^bsub>(n)\<^esub> z" \<rightharpoonup> "-VALUED-1K32 z"

mtheorem seq_4_add_10:
  mlet "n be NatNAT-1M1", "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster -VALUED-1K32 z as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "-VALUED-1K32 z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem seq_4_th_60:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c =COMPLEX1R1 z .FUNCT-1K1 k implies (-SEQ-4K18\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =COMPLEX1R1 -XCMPLX-0K4 c"
sorry

mlemma seq_4_lm_11:
" for n be NatNAT-1M1 holds -SEQ-4K18\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =FINSEQ-1R1 0cSEQ-4K17 n"
sorry

mtheorem seq_4_th_61:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 0cSEQ-4K17 n & (-SEQ-4K18\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 0cSEQ-4K17 n"
  using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry

mtheorem seq_4_th_62:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n implies z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z2 & z2 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z1"
  using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_74 sorry

(*\$CT*)
mtheorem seq_4_th_64:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z2 implies z1 =FINSEQ-1R1 z2"
sorry

mlemma seq_4_lm_12:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> z implies z1 =FINSEQ-1R1 z2"
sorry

mtheorem seq_4_th_65:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> z or z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z +SEQ-4K15\<^bsub>(n)\<^esub> z2 implies z1 =FINSEQ-1R1 z2"
  using seq_4_lm_12 sorry

mtheorem seq_4_th_66:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
sorry

syntax SEQ_4K19 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -SEQ-4K19\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2" \<rightharpoonup> "z1 -VALUED-1K47 z2"

mtheorem seq_4_add_11:
  mlet "n be NatNAT-1M1", "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster z1 -VALUED-1K47 z2 as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "z1 -VALUED-1K47 z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem seq_4_th_67:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n implies (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =COMPLEX1R1 z1 .FUNCT-1K1 k -XCMPLX-0K6 z2 .FUNCT-1K1 k"
sorry

mtheorem seq_4_th_68:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z -SEQ-4K19\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =FINSEQ-1R1 z"
sorry

mtheorem seq_4_th_69:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0cSEQ-4K17 n -SEQ-4K19\<^bsub>(n)\<^esub> z =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z"
sorry

mtheorem seq_4_th_70:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2"
   sorry

mtheorem seq_4_th_71:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1"
sorry

mtheorem seq_4_th_72:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> z2"
sorry

mtheorem seq_4_th_73:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z -SEQ-4K19\<^bsub>(n)\<^esub> z =FINSEQ-1R1 0cSEQ-4K17 n"
sorry

mtheorem seq_4_th_74:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n implies z1 =FINSEQ-1R1 z2"
sorry

mtheorem seq_4_th_75:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3 =FINSEQ-1R1 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 +SEQ-4K15\<^bsub>(n)\<^esub> z3)"
sorry

mtheorem seq_4_th_76:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3"
sorry

mtheorem seq_4_th_77:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =FINSEQ-1R1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3"
sorry

mtheorem seq_4_th_78:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3 =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z3)-SEQ-4K19\<^bsub>(n)\<^esub> z2"
  using seq_4_th_76 sorry

mtheorem seq_4_th_79:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z"
sorry

mtheorem seq_4_th_80:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1) =FINSEQ-1R1 z2"
sorry

mtheorem seq_4_th_81:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 =FINSEQ-1R1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z"
sorry

syntax SEQ_4K20 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *SEQ-4K20\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "c *SEQ-4K20\<^bsub>(n)\<^esub> z" \<rightharpoonup> "c (#)VALUED-1K25 z"

mtheorem seq_4_add_12:
  mlet "n be NatNAT-1M1", "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"cluster c (#)VALUED-1K25 z as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "c (#)VALUED-1K25 z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem seq_4_th_82:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c9 =COMPLEX1R1 z .FUNCT-1K1 k implies (c *SEQ-4K20\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =COMPLEX1R1 c *XCMPLX-0K3 c9"
sorry

mtheorem seq_4_th_83:
" for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds c1 *SEQ-4K20\<^bsub>(n)\<^esub> (c2 *SEQ-4K20\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 (c1 *XCMPLX-0K3 c2)*SEQ-4K12 z"
sorry

mtheorem seq_4_th_84:
" for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (c1 +XCMPLX-0K2 c2)*SEQ-4K12 z =FINSEQ-1R1 c1 *SEQ-4K20\<^bsub>(n)\<^esub> z +SEQ-4K15\<^bsub>(n)\<^esub> c2 *SEQ-4K20\<^bsub>(n)\<^esub> z"
sorry

mtheorem seq_4_th_85:
" for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds c *SEQ-4K20\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 c *SEQ-4K20\<^bsub>(n)\<^esub> z1 +SEQ-4K15\<^bsub>(n)\<^esub> c *SEQ-4K20\<^bsub>(n)\<^esub> z2"
  using seq_4_th_54 finseqop_th_51 finseqop_th_54 sorry

mtheorem seq_4_th_86:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 1rCOMPLEX1K7 *SEQ-4K20\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z"
sorry

mtheorem seq_4_th_87:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0cCOMPLEX1K6 *SEQ-4K20\<^bsub>(n)\<^esub> z =FINSEQ-1R1 0cSEQ-4K17 n"
sorry

mtheorem seq_4_th_88:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (-XCMPLX-0K4 1rCOMPLEX1K7)*SEQ-4K12 z =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z"
   sorry

syntax SEQ_4K21 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("absSEQ-4K21\<^bsub>'( _ ')\<^esub>  _ " [0,250]250)
translations "absSEQ-4K21\<^bsub>(n)\<^esub> z" \<rightharpoonup> " |.VALUED-1K56 z.|"

mtheorem seq_4_add_13:
  mlet "n be NatNAT-1M1", "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster  |.VALUED-1K56 z.| as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show " |.VALUED-1K56 z.| be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem seq_4_th_89:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c =COMPLEX1R1 z .FUNCT-1K1 k implies absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 k =COMPLEX1R1  |.COMPLEX1K10 c.|"
sorry

mtheorem seq_4_th_90:
" for n be NatNAT-1M1 holds absSEQ-4K21\<^bsub>(n)\<^esub> (0cSEQ-4K17 n) =FINSEQ-1R1 n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
sorry

mtheorem seq_4_th_91:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 absSEQ-4K21\<^bsub>(n)\<^esub> z"
sorry

mtheorem seq_4_th_92:
" for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 ( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z"
sorry

mdef seq_4_def_13 (" |.SEQ-4K22  _ .|" [0]164 ) where
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"func  |.SEQ-4K22 z.| \<rightarrow> RealXREAL-0M1 equals
  sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K15 absSEQ-4K13 z))"
proof-
  (*coherence*)
    show "sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K15 absSEQ-4K13 z)) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem seq_4_th_93:
" for n be NatNAT-1M1 holds  |.SEQ-4K22 0cSEQ-4K17 n.| =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem seq_4_th_94:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| =COMPLEX1R1 0NUMBERSK6 implies z =FINSEQ-1R1 0cSEQ-4K17 n"
sorry

mtheorem seq_4_th_95:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <=XXREAL-0R1  |.SEQ-4K22 z.|"
sorry

mtheorem seq_4_th_96:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 -SEQ-4K18\<^bsub>(n)\<^esub> z .| =COMPLEX1R1  |.SEQ-4K22 z.|"
  using seq_4_th_91 sorry

mtheorem seq_4_th_97:
" for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 c *SEQ-4K20\<^bsub>(n)\<^esub> z .| =COMPLEX1R1 ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ( |.SEQ-4K22 z.|)"
sorry

mtheorem seq_4_th_98:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
sorry

mtheorem seq_4_th_99:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
sorry

mtheorem seq_4_th_100:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .|"
sorry

mtheorem seq_4_th_101:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
sorry

mtheorem seq_4_th_102:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6 iff z1 =FINSEQ-1R1 z2"
sorry

mtheorem seq_4_th_103:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 <>HIDDENR2 z2 implies 0NUMBERSK6 <XXREAL-0R3  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
sorry

mtheorem seq_4_th_104:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1  |.SEQ-4K22 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|"
sorry

mtheorem seq_4_th_105:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .| +XCMPLX-0K2  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
sorry

mdef seq_4_def_14 ("openSEQ-4V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "n be NatNAT-1M1"
"attr openSEQ-4V1\<^bsub>(n)\<^esub> for SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n means
  (\<lambda>A.  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)))"..

mdef seq_4_def_15 ("closedSEQ-4V2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "n be NatNAT-1M1"
"attr closedSEQ-4V2\<^bsub>(n)\<^esub> for SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n means
  (\<lambda>A.  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A)"..

mtheorem seq_4_th_106:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 {}XBOOLE-0K1 implies A be openSEQ-4V1\<^bsub>(n)\<^esub>"
   sorry

mtheorem seq_4_th_107:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 COMPLEXSEQ-4K14 n implies A be openSEQ-4V1\<^bsub>(n)\<^esub>"
sorry

mtheorem seq_4_th_108:
" for n be NatNAT-1M1 holds  for AA be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n holds ( for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A inTARSKIR2 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>) implies ( for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 unionTARSKIK3 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>)"
sorry

mtheorem seq_4_th_109:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A be openSEQ-4V1\<^bsub>(n)\<^esub> & B be openSEQ-4V1\<^bsub>(n)\<^esub> implies ( for C be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds C =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> B implies C be openSEQ-4V1\<^bsub>(n)\<^esub>)"
sorry

mdef seq_4_def_16 ("BallSEQ-4K23\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "r be RealXREAL-0M1"
"func BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r) \<rightarrow> SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n equals
  {z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r }"
proof-
  (*coherence*)
    show "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
sorry
qed "sorry"

mtheorem seq_4_th_110:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r) iff  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| <XXREAL-0R3 r"
sorry

mtheorem seq_4_th_111:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r implies x inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r)"
sorry

mtheorem seq_4_th_112:
" for n be NatNAT-1M1 holds  for r1 be RealXREAL-0M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
sorry

mdef seq_4_def_17 ("distSEQ-4K24\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
"func distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
sorry
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it1 =COMPLEX1R1 lower-boundSEQ-4K3 X) & ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it2 =COMPLEX1R1 lower-boundSEQ-4K3 X) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef seq_4_def_18 ("BallSEQ-4K25\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n", "r be RealXREAL-0M1"
"func BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r) \<rightarrow> SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n equals
  {z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r }"
proof-
  (*coherence*)
    show "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
sorry
qed "sorry"

mtheorem seq_4_th_113:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds X <>HIDDENR2 {}XBOOLE-0K1 & ( for r9 be RealXREAL-0M1 holds r9 inHIDDENR3 X implies r <=XXREAL-0R1 r9) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 r"
sorry

mtheorem seq_4_th_114:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem seq_4_th_115:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) <=XXREAL-0R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2  |.SEQ-4K22 z.|"
sorry

mtheorem seq_4_th_116:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem seq_4_th_117:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds ( not x inTARSKIR2 A & A <>HIDDENR2 {}XBOOLE-0K1) & A be closedSEQ-4V2\<^bsub>(n)\<^esub> implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem seq_4_th_118:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(z1,A)"
sorry

mtheorem seq_4_th_119:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r) iff distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r"
sorry

mtheorem seq_4_th_120:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r & x inTARSKIR2 A implies x inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r)"
sorry

mtheorem seq_4_th_121:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r implies A c=TARSKIR1 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r)"
  using seq_4_th_120 sorry

mtheorem seq_4_th_122:
" for n be NatNAT-1M1 holds  for r1 be RealXREAL-0M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
sorry

mdef seq_4_def_19 ("distSEQ-4K26\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n", "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
"func distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
sorry
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it1 =COMPLEX1R1 lower-boundSEQ-4K3 X) & ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it2 =COMPLEX1R1 lower-boundSEQ-4K3 X) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem seq_4_th_123:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies X ++MEMBER-1K9 Y <>HIDDENR2 {}XBOOLE-0K1"
   sorry

mtheorem seq_4_th_124:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 & Y be bounded-belowXXREAL-2V3 implies X ++MEMBER-1K9 Y be bounded-belowXXREAL-2V3"
sorry

mtheorem seq_4_th_125:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((X <>HIDDENR2 {}XBOOLE-0K1 & X be bounded-belowXXREAL-2V3) & Y <>HIDDENR2 {}XBOOLE-0K1) & Y be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 (X ++MEMBER-1K9 Y) =COMPLEX1R1 lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y"
sorry

mtheorem seq_4_th_126:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Y be bounded-belowXXREAL-2V3 & X <>HIDDENR2 {}XBOOLE-0K1) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 Y & r1 <=XXREAL-0R1 r)) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
sorry

mtheorem seq_4_th_127:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem seq_4_th_128:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 distSEQ-4K26\<^bsub>(n)\<^esub>(B,A)"
sorry

mtheorem seq_4_th_129:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,B) >=XXREAL-0R2 distSEQ-4K26\<^bsub>(n)\<^esub>(A,B)"
sorry

mtheorem seq_4_th_130:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A meetsXBOOLE-0R5 B implies distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 0NUMBERSK6"
sorry

mdef seq_4_def_20 ("ComplexOpenSetsSEQ-4K27  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func ComplexOpenSetsSEQ-4K27 n \<rightarrow> Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n equals
  {A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> }"
proof-
  (*coherence*)
    show "{A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n"
sorry
qed "sorry"

mtheorem seq_4_th_131:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A inTARSKIR2 ComplexOpenSetsSEQ-4K27 n iff A be openSEQ-4V1\<^bsub>(n)\<^esub>"
sorry

mtheorem seq_4_th_132:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A be closedSEQ-4V2\<^bsub>(n)\<^esub> iff A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>"
sorry

(*begin*)
reserve v, v1, v2 for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
reserve n, m, k for "NatNAT-1M1"
mlemma seq_4_lm_13:
" for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 0NUMBERSK6 implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
   sorry

mlemma seq_4_lm_14:
" for n be NatNAT-1M1 holds ( for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R) implies ( for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R)"
sorry

mlemma seq_4_lm_15:
" for n be NatNAT-1M1 holds  for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
  using nat_1_sch_2 seq_4_lm_13 seq_4_lm_14 sorry

mtheorem seq_4_th_133:
" for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
sorry

mtheorem seq_4_th_134:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f iff n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
sorry

mtheorem seq_4_th_135:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f iff (n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) & n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
sorry

mtheorem seq_4_th_136:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f2 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 lenFINSEQ-1K4 f1) =XBOOLE-0R4 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
sorry

mtheorem seq_4_th_137:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds v be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v) & n <=XXREAL-0R1 m implies v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m)"
sorry

mtheorem seq_4_th_138:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds v be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v) & n <>HIDDENR2 m implies v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m)"
sorry

mtheorem seq_4_th_139:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds v be increasingVALUED-0V9 & v1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> v  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n implies v1 be increasingVALUED-0V9"
sorry

mlemma seq_4_lm_16:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 0NUMBERSK6 implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)"
sorry

mlemma seq_4_lm_17:
" for n be NatNAT-1M1 holds ( for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)) implies ( for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9))"
sorry

mlemma seq_4_lm_18:
" for n be NatNAT-1M1 holds  for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)"
  using nat_1_sch_2 seq_4_lm_16 seq_4_lm_17 sorry

mtheorem seq_4_th_140:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9"
  using seq_4_lm_18 sorry

mlemma seq_4_lm_19:
" for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 0NUMBERSK6 & lenFINSEQ-1K4 v2 =COMPLEX1R1 0NUMBERSK6) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
sorry

mlemma seq_4_lm_20:
" for n be NatNAT-1M1 holds ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n & lenFINSEQ-1K4 v2 =COMPLEX1R1 n) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2) implies ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 v2 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2)"
sorry

mlemma seq_4_lm_21:
" for n be NatNAT-1M1 holds  for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n & lenFINSEQ-1K4 v2 =COMPLEX1R1 n) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
  using nat_1_sch_2 seq_4_lm_19 seq_4_lm_20 sorry

mtheorem seq_4_th_141:
" for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds ((lenFINSEQ-1K4 v1 =COMPLEX1R1 lenFINSEQ-1K4 v2 & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
  using seq_4_lm_21 sorry

mdef seq_4_def_21 ("IncrSEQ-4K28  _ " [228]228 ) where
  mlet "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"func IncrSEQ-4K28 v \<rightarrow> increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. rngRVSUM-1K1 it =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
proof-
  (*existence*)
    show " ex it be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 it =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
sorry
  (*uniqueness*)
    show " for it1 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (rngRVSUM-1K1 it1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & (rngRVSUM-1K1 it2 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it2 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) implies it1 =HIDDENR1 it2"
      using seq_4_lm_21 sorry
qed "sorry"

mtheorem seq_4_cl_7:
  mlet "v be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"cluster IncrSEQ-4K28 v as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "IncrSEQ-4K28 v be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem seq_4_cl_8:
"cluster  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3"
sorry
qed "sorry"

mtheorem seq_4_th_142:
" for A be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for B be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds lower-boundSEQ-4K3 (A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B) =COMPLEX1R1 minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B)"
sorry

mtheorem seq_4_th_143:
" for A be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for B be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds upper-boundSEQ-4K2 (A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B) =COMPLEX1R1 maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B)"
sorry

mtheorem seq_4_th_144:
" for R be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r0 be RealXREAL-0M1 holds ( for r be RealXREAL-0M1 holds r inHIDDENR3 R implies r <=XXREAL-0R1 r0) implies upper-boundSEQ-4K2 R <=XXREAL-0R1 r0"
sorry

end
