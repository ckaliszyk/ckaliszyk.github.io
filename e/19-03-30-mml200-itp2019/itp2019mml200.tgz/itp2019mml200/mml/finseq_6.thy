theory finseq_6
  imports xxreal_2 funct_7 seqm_3 card_2 xcmplx_1 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z for "setHIDDENM2"
mtheorem finseq_6_cl_1:
  mlet "x be setHIDDENM2", "y be setHIDDENM2", "z be setHIDDENM2"
"cluster <*FINSEQ-1K12 x,y,z *> as-term-is  non trivialZFMISC-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K12 x,y,z *> be  non trivialZFMISC-1V1"
sorry
qed "sorry"

mtheorem finseq_6_cl_2:
  mlet "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster RevFINSEQ-5K3 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mlemma finseq_6_lm_1:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 x,y }"
sorry

mlemma finseq_6_lm_2:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds rngFUNCT-1K2 (<*FINSEQ-1K12 x,y,z *>) =XBOOLE-0R4 {ENUMSET1K1 x,y,z }"
sorry

(*begin*)
reserve f, f1, f2, f3 for "FinSequenceFINSEQ-1M1"
reserve p, p1, p2, p3 for "setHIDDENM2"
reserve i, k for "NatNAT-1M1"
mtheorem finseq_6_th_1:
" for X be setHIDDENM2 holds  for i be NatNAT-1M1 holds X c=TARSKIR1 SegFINSEQ-1K2 i & \<one>\<^sub>M inTARSKIR2 X implies SgmFINSEQ-1K15 X .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_2:
" for k be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f .FUNCT-1K1 i <>HIDDENR2 f .FUNCT-1K1 k) implies (f .FUNCT-1K1 k)..FINSEQ-4K4 f =XBOOLE-0R4 k"
sorry

mtheorem finseq_6_th_3:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds (<*FINSEQ-1K11 p1,p2 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
sorry

mtheorem finseq_6_th_4:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds (<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K10 p1*>"
sorry

mtheorem finseq_6_th_5:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds (<*FINSEQ-1K12 p1,p2,p3 *>) |RELAT-1K8 SegFINSEQ-1K2 \<two>\<^sub>M =FUNCT-1R1 <*FINSEQ-1K11 p1,p2 *>"
sorry

mtheorem finseq_6_th_6:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 p ..FINSEQ-4K4 f1"
sorry

mtheorem finseq_6_th_7:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies p ..FINSEQ-4K4 (f1 ^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 p ..FINSEQ-4K4 f2"
sorry

mtheorem finseq_6_th_8:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 (f1  |--FINSEQ-4K6 p)^FINSEQ-1K8 f2"
sorry

mtheorem finseq_6_th_9:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2  |--FINSEQ-4K6 p =FINSEQ-1R1 f2  |--FINSEQ-4K6 p"
sorry

mtheorem finseq_6_th_10:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds f1 c=RELAT-1R2 f1 ^FINSEQ-1K8 f2"
sorry

mtheorem finseq_6_th_11:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for A be setHIDDENM2 holds A c=TARSKIR1 domFINSEQ-1K5 f1 implies (f1 ^FINSEQ-1K8 f2) |RELAT-1K8 A =FUNCT-1R1 f1  |RELAT-1K8 A"
  using finseq_6_th_10 grfunc_1_th_27 sorry

mtheorem finseq_6_th_12:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 -|FINSEQ-4K5 p"
sorry

mtheorem finseq_6_cl_3:
  mlet "f1 be FinSequenceFINSEQ-1M1", "i be NatNAT-1M1"
"cluster f1  |RELAT-1K8 SegFINSEQ-1K2 i as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f1  |RELAT-1K8 SegFINSEQ-1K2 i be FinSequence-likeFINSEQ-1V1"
    using finseq_1_th_15 sorry
qed "sorry"

mtheorem finseq_6_th_13:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for f3 be FinSequenceFINSEQ-1M1 holds f1 c=RELAT-1R2 f2 implies f3 ^FINSEQ-1K8 f1 c=RELAT-1R2 f3 ^FINSEQ-1K8 f2"
sorry

mtheorem finseq_6_th_14:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds (f1 ^FINSEQ-1K8 f2) |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +XCMPLX-0K2 i) =FINSEQ-1R1 f1 ^FINSEQ-1K8 f2  |RELAT-1K8 SegFINSEQ-1K2 i"
sorry

mtheorem finseq_6_th_15:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies f1 ^FINSEQ-1K8 f2 -|FINSEQ-4K5 p =FINSEQ-1R1 f1 ^FINSEQ-1K8 (f2 -|FINSEQ-4K5 p)"
sorry

mtheorem finseq_6_th_16:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p implies p inTARSKIR2 rngFUNCT-1K2 f1 \\+\\XBOOLE-0K5 rngFUNCT-1K2 f2"
sorry

mtheorem finseq_6_th_17:
" for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds f1 ^FINSEQ-1K8 f2 just-once-valuesFINSEQ-4R2 p & p inTARSKIR2 rngFUNCT-1K2 f1 implies f1 just-once-valuesFINSEQ-4R2 p"
sorry

mtheorem finseq_6_th_18:
" for p be setHIDDENM2 holds p ..FINSEQ-4K4 (<*FINSEQ-1K10 p*>) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_19:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds p1 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_20:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds p1 <>HIDDENR2 p2 implies p2 ..FINSEQ-4K4 (<*FINSEQ-1K11 p1,p2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
sorry

mtheorem finseq_6_th_21:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_22:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 <>HIDDENR2 p2 implies p2 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<two>\<^sub>M"
sorry

mtheorem finseq_6_th_23:
" for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies p3 ..FINSEQ-4K4 (<*FINSEQ-1K12 p1,p2,p3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
sorry

mtheorem finseq_6_th_24:
" for p be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) =FINSEQ-1R1 RevFINSEQ-5K3 f ^FINSEQ-1K8 (<*FINSEQ-1K10 p*>)"
sorry

mtheorem finseq_6_th_25:
" for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (RevFINSEQ-5K3 f) =FINSEQ-1R1 f"
   sorry

mtheorem finseq_6_th_26:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K11 x,y *> -|FINSEQ-4K5 y =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
sorry

mtheorem finseq_6_th_27:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 y =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
sorry

mtheorem finseq_6_th_28:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 z & y <>HIDDENR2 z implies <*FINSEQ-1K12 x,y,z *> -|FINSEQ-4K5 z =FINSEQ-1R1 <*FINSEQ-1K11 x,y *>"
sorry

mtheorem finseq_6_th_29:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K10 y*>"
sorry

mtheorem finseq_6_th_30:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 y =FINSEQ-1R1 <*FINSEQ-1K10 z*>"
sorry

mtheorem finseq_6_th_31:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 x =FINSEQ-1R1 <*FINSEQ-1K11 y,z *>"
sorry

mtheorem finseq_6_th_32:
" for z be setHIDDENM2 holds <*FINSEQ-1K10 z*>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1 & <*FINSEQ-1K10 z*> -|FINSEQ-4K5 z =FINSEQ-1R1 {}XBOOLE-0K1"
sorry

mtheorem finseq_6_th_33:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x <>HIDDENR2 y implies <*FINSEQ-1K11 x,y *>  |--FINSEQ-4K6 y =FINSEQ-1R1 {}XBOOLE-0K1"
sorry

mtheorem finseq_6_th_34:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 z & y <>HIDDENR2 z implies <*FINSEQ-1K12 x,y,z *>  |--FINSEQ-4K6 z =FINSEQ-1R1 {}XBOOLE-0K1"
sorry

mtheorem finseq_6_th_35:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 rngFUNCT-1K2 f & y inTARSKIR2 rngFUNCT-1K2 (f -|FINSEQ-4K5 x) implies (f -|FINSEQ-4K5 x)-|FINSEQ-4K5 y =FINSEQ-1R1 f -|FINSEQ-4K5 y"
sorry

mtheorem finseq_6_th_36:
" for x be setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 rngFUNCT-1K2 f1 implies x ..FINSEQ-4K4 ((f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_37:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies x ..FINSEQ-4K4 f +NAT-1K1 x ..FINSEQ-4K4 RevFINSEQ-5K3 f =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_38:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies RevFINSEQ-5K3 (f -|FINSEQ-4K5 x) =FINSEQ-1R1 RevFINSEQ-5K3 f  |--FINSEQ-4K6 x"
sorry

mtheorem finseq_6_th_39:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f just-once-valuesFINSEQ-4R2 x implies RevFINSEQ-5K3 f just-once-valuesFINSEQ-4R2 x"
sorry

(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p, p1, p2, p3 for "ElementSUBSET-1M1-of D"
reserve f, f1, f2 for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_6_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
sorry

mtheorem finseq_6_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K8 (f  |--FINSEQ-4K6 p)"
sorry

mtheorem finseq_6_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
sorry

mtheorem finseq_6_th_43:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M)..FINSEQ-4K4 f =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_44:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f <>HIDDENR2 {}XBOOLE-0K1 & f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_45:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p1*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
  using finseq_6_th_45 sorry

mtheorem finseq_6_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
sorry

mtheorem finseq_6_th_48:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k inTARSKIR2 domFINSEQ-1K5 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 k implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k) implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> k)..FINSEQ-4K4 f =XBOOLE-0R4 k"
sorry

mtheorem finseq_6_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
sorry

mtheorem finseq_6_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
sorry

mtheorem finseq_6_th_51:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p3 =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
sorry

mtheorem finseq_6_th_52:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> & (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
sorry

mtheorem finseq_6_th_53:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p2*>"
sorry

mtheorem finseq_6_th_54:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p3 *>"
sorry

mtheorem finseq_6_th_55:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p3 & p2 <>HIDDENR2 p3 implies (<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>):-FINSEQ-5K2\<^bsub>(D)\<^esub> p3 =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p3*>"
sorry

mtheorem finseq_6_th_56:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies p ..FINSEQ-4K4 f =XBOOLE-0R4 k +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
sorry

mtheorem finseq_6_th_57:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies p inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
sorry

mtheorem finseq_6_th_58:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k <XXREAL-0R3 i & i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)"
sorry

mtheorem finseq_6_th_59:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
sorry

mtheorem finseq_6_th_60:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_61:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_6_th_62:
" for x be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (x inTARSKIR2 rngFUNCT-1K2 f & p inTARSKIR2 rngFUNCT-1K2 f) & x ..FINSEQ-4K4 f >=XXREAL-0R2 p ..FINSEQ-4K4 f implies x inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_6_th_63:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & k <=XXREAL-0R1 lenFINSEQ-1K4 f) & k >=XXREAL-0R2 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k inTARSKIR2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_6_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 (f1 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
sorry

mtheorem finseq_6_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f2 :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_66:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f1 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f2 \\SUBSET-1K6 rngFUNCT-1K2 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f2 -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_6_th_68:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_69:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies f  |--FINSEQ-4K6 p2 =FINSEQ-1R1 (f  |--FINSEQ-4K6 p1) |--FINSEQ-4K6 p2"
sorry

mtheorem finseq_6_th_70:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) \\/XBOOLE-0K2 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_6_th_71:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1):-FINSEQ-5K2\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p2"
sorry

mtheorem finseq_6_th_72:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies p ..FINSEQ-4K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
sorry

mtheorem finseq_6_th_73:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) |FINSEQ-1K18\<^bsub>(D)\<^esub> i =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
   sorry

mtheorem finseq_6_th_74:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_75:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p1 inTARSKIR2 rngFUNCT-1K2 f & p2 inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1)-:FINSEQ-5K1\<^bsub>(D)\<^esub> p2 =FINSEQ-1R1 f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p2"
sorry

mtheorem finseq_6_th_76:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_77:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds f1 <>HIDDENR2 {}XBOOLE-0K1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
sorry

mtheorem finseq_6_th_78:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 f & p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p ..FINSEQ-4K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mlemma finseq_6_lm_3:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 i implies i +NAT-1K1 p ..FINSEQ-4K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
sorry

mtheorem finseq_6_th_80:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds <*>FINSEQ-1K7 D /^RFINSEQK2\<^bsub>(D)\<^esub> k =FINSEQ-1R1 <*>FINSEQ-1K7 D"
sorry

mtheorem finseq_6_th_81:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 k) =FINSEQ-1R1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)/^RFINSEQK2\<^bsub>(D)\<^esub> k"
sorry

mtheorem finseq_6_th_82:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f >XXREAL-0R4 k implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> k):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_83:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M):-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_84:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
sorry

mtheorem finseq_6_th_85:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +XCMPLX-0K2 k =XBOOLE-0R4 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
sorry

mtheorem finseq_6_th_86:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K3 (f  |--FINSEQ-4K6 p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -|FINSEQ-4K5 p"
sorry

mtheorem finseq_6_th_87:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
sorry

mtheorem finseq_6_th_88:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p"
sorry

(*begin*)
mdef finseq_6_def_1 ("circularFINSEQ-6V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr circularFINSEQ-6V1\<^bsub>(D)\<^esub> for FinSequenceFINSEQ-1M3-of D means
  (\<lambda>IT. IT /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 IT /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 IT)"..

mdef finseq_6_def_2 ("RotateFINSEQ-6K1\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D"
"func RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) if p inTARSKIR2 rngFUNCT-1K2 f otherwise f"
proof-
  (*coherence*)
    show "(p inTARSKIR2 rngFUNCT-1K2 f implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)^FINSEQ-1K9\<^bsub>(D)\<^esub> ((f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) be FinSequenceFINSEQ-1M3-of D) & ( not p inTARSKIR2 rngFUNCT-1K2 f implies f be FinSequenceFINSEQ-1M3-of D)"
       sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M3-of D holds  True "
       sorry
qed "sorry"

mtheorem finseq_6_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D"
"cluster RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem finseq_6_cl_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>\<one>\<^sub>M -elementCARD-1V3 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>\<one>\<^sub>M -elementCARD-1V3"
sorry
qed "sorry"

mtheorem finseq_6_cl_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1"
sorry
qed "sorry"

mtheorem finseq_6_th_89:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) as-term-is circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
proof
(*coherence*)
  show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
sorry
qed "sorry"

mtheorem finseq_6_th_90:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 rngFUNCT-1K2 f"
sorry

mtheorem finseq_6_th_91:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies p inTARSKIR2 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
sorry

mtheorem finseq_6_th_92:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
sorry

mtheorem finseq_6_th_93:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),p) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)"
sorry

mtheorem finseq_6_th_94:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>,p) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>"
sorry

mtheorem finseq_6_th_95:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>"
sorry

mtheorem finseq_6_th_96:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K2\<^bsub>(D)\<^esub> p1,p2 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(D)\<^esub> p2,p2 *>"
sorry

mtheorem finseq_6_th_97:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p1) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>"
sorry

mtheorem finseq_6_th_98:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p1 <>HIDDENR2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p2) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p2,p3,p2 *>"
sorry

mtheorem finseq_6_th_99:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for p3 be ElementSUBSET-1M1-of D holds p2 <>HIDDENR2 p3 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(<*FINSEQ-4K3\<^bsub>(D)\<^esub> p1,p2,p3 *>,p3) =FINSEQ-1R1 <*FINSEQ-4K3\<^bsub>(D)\<^esub> p3,p2,p3 *>"
sorry

mtheorem finseq_6_th_100:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 rngFUNCT-1K2 f"
sorry

mtheorem finseq_6_th_101:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) c=TARSKIR1 rngFUNCT-1K2 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))"
sorry

mtheorem finseq_6_th_102:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
sorry

mtheorem finseq_6_th_103:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 ..FINSEQ-4K4 f <>HIDDENR2 \<one>\<^sub>M & p2 inTARSKIR2 rngFUNCT-1K2 f \\SUBSET-1K6 rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p1) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
sorry

mtheorem finseq_6_th_104:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p2 inTARSKIR2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
sorry

mtheorem finseq_6_th_105:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p1 be ElementSUBSET-1M1-of D holds  for p2 be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p2 implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p1),p2) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p2)"
sorry

mtheorem finseq_6_th_106:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be circularFINSEQ-6V1\<^bsub>(D)\<^esub> & f just-once-valuesFINSEQ-4R2 p implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =FINSEQ-1R1 RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,p)"
sorry

(*begin*)
mtheorem finseq_6_th_107:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds f be emptyXBOOLE-0V1 or ( ex x be ElementSUBSET-1M1-of D st f =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> x*>)"
sorry

(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem finseq_6_th_108:
" for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p <XXREAL-0R3 i & (i <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q or i <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 q)) implies (p ^FINSEQ-1K8 q).FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 (i -XCMPLX-0K6 lenFINSEQ-1K4 p)"
sorry

mtheorem finseq_6_th_109:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies (((f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M & (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
sorry

mtheorem finseq_6_th_110:
" for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M implies RevFINSEQ-5K3 f =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_111:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k be NatNAT-1M1 holds lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> k) =XBOOLE-0R4 lenFINSEQ-1K4 f -'NAT-DK9 k"
  using rfinseq_th_29 sorry

mdef finseq_6_def_3 ("midFINSEQ-6K2'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "f be FinSequenceFINSEQ-1M1", "k1 be NatNAT-1M1", "k2 be NatNAT-1M1"
"func midFINSEQ-6K2(f,k1,k2) \<rightarrow> FinSequenceFINSEQ-1M1 equals
  (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) if k1 <=XXREAL-0R1 k2 otherwise RevFINSEQ-5K3 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M))"
proof-
  (*coherence*)
    show "(k1 <=XXREAL-0R1 k2 implies (f /^RFINSEQK1 (k1 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M) be FinSequenceFINSEQ-1M1) & ( not k1 <=XXREAL-0R1 k2 implies RevFINSEQ-5K3 ((f /^RFINSEQK1 (k2 -'NAT-DK9 \<one>\<^sub>M)) |FINSEQ-1K17 ((k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M)) be FinSequenceFINSEQ-1M1)"
       sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
qed "sorry"

syntax FINSEQ_6K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("midFINSEQ-6K3\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]164)
translations "midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)" \<rightharpoonup> "midFINSEQ-6K2(f,k1,k2)"

mtheorem finseq_6_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "k1 be NatNAT-1M1", "k2 be NatNAT-1M1"
"cluster midFINSEQ-6K2(f,k1,k2) as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "midFINSEQ-6K2(f,k1,k2) be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

(*\$CT*)
mtheorem finseq_6_th_113:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 k2) & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f implies RevFINSEQ-5K4\<^bsub>(D)\<^esub> (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2)) =FINSEQ-1R1 midFINSEQ-6K3\<^bsub>(D)\<^esub>(RevFINSEQ-5K4\<^bsub>(D)\<^esub> f,(lenFINSEQ-1K4 f -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M,(lenFINSEQ-1K4 f -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_114:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f /^RFINSEQK1 n).FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 (m +XCMPLX-0K2 n)"
sorry

mtheorem finseq_6_th_115:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_116:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k implies midFINSEQ-6K2(f,\<one>\<^sub>M,k) =FINSEQ-1R1 f  |FINSEQ-1K17 k"
sorry

mtheorem finseq_6_th_117:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds k <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K2(f,k,lenFINSEQ-1K4 f) =FINSEQ-1R1 f /^RFINSEQK1 (k -'NAT-DK9 \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_118:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 k2) & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f implies ((midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 k1 & (k1 <=XXREAL-0R1 k2 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) =XBOOLE-0R4 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M)))) & (k1 >XXREAL-0R4 k2 implies lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) =XBOOLE-0R4 (k1 -'NAT-DK9 k2)+NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) implies (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((k1 -'NAT-DK9 i)+NAT-1K1 \<one>\<^sub>M)))"
sorry

mtheorem finseq_6_th_119:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds rngFUNCT-1K2 (midFINSEQ-6K2(f,k1,k2)) c=TARSKIR1 rngFUNCT-1K2 f"
sorry

mtheorem finseq_6_th_120:
" for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K2(f,\<one>\<^sub>M,lenFINSEQ-1K4 f) =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_121:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,lenFINSEQ-1K4 f,\<one>\<^sub>M) =FINSEQ-1R1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f"
sorry

mtheorem finseq_6_th_122:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds  for i be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 k2) & k2 <=XXREAL-0R1 lenFINSEQ-1K4 f) & \<one>\<^sub>M <=XXREAL-0R1 i) & ((i <=XXREAL-0R1 (k2 -'NAT-DK9 k1)+NAT-1K1 \<one>\<^sub>M or i <=XXREAL-0R1 (k2 -XCMPLX-0K6 k1)+XCMPLX-0K2 \<one>\<^sub>M) or i <=XXREAL-0R1 (k2 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k1) implies (((midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-'NAT-DK9 \<one>\<^sub>M) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -'NAT-DK9 \<one>\<^sub>M)+XCMPLX-0K2 k1)) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i +XCMPLX-0K2 k1)-XCMPLX-0K6 \<one>\<^sub>M)) & (midFINSEQ-6K2(f,k1,k2)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 k1)"
sorry

mtheorem finseq_6_th_123:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds  for i be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 k) & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies (midFINSEQ-6K2(f,\<one>\<^sub>M,k)).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
sorry

mtheorem finseq_6_th_124:
" for f be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds lenFINSEQ-1K4 (midFINSEQ-6K2(f,k1,k2)) <=XXREAL-0R1 lenFINSEQ-1K4 f"
sorry

mtheorem finseq_6_th_125:
" for f be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds  for p be setHIDDENM2 holds ((<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f) |FINSEQ-1K17 (k +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (<*FINSEQ-1K10 p*>)^FINSEQ-1K8 f  |FINSEQ-1K17 k"
sorry

mlemma finseq_6_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <XXREAL-0R3 k2 & k1 inTARSKIR2 domFINSEQ-1K5 f implies midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1,k2) =FINSEQ-1R1 (<*FINSEQ-1K10 f .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K3\<^bsub>(D)\<^esub>(f,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
sorry

mtheorem finseq_6_th_126:
" for p be FinSequenceFINSEQ-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <XXREAL-0R3 k2 & k1 inTARSKIR2 domFINSEQ-1K5 p implies midFINSEQ-6K2(p,k1,k2) =FINSEQ-1R1 (<*FINSEQ-1K10 p .FUNCT-1K1 k1*>)^FINSEQ-1K8 (midFINSEQ-6K2(p,k1 +NAT-1K1 \<one>\<^sub>M,k2))"
sorry

(*begin*)
reserve p, q for "FinSequenceFINSEQ-1M1"
reserve X, Y, x, y for "setHIDDENM2"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve i, j, k, l, m, n, r for "NatNAT-1M1"
mtheorem finseq_6_th_127:
" for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 n iff ( ex i be NatNAT-1M1 st (m <=XXREAL-0R1 i & i <XXREAL-0R3 n) & k =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_128:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds q =FINSEQ-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n implies lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)"
sorry

mtheorem finseq_6_th_129:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for k be NatNAT-1M1 holds X c=TARSKIR1 SegFINSEQ-1K2 k & Y c=TARSKIR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 X) implies SgmFINSEQ-1K15 X *FUNCT-1K3 SgmFINSEQ-1K15 Y =FUNCT-1R1 SgmFINSEQ-1K15 (rngFUNCT-1K2 (SgmFINSEQ-1K15 X  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> Y))"
sorry

mlemma finseq_6_lm_5:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for F be finiteFINSET-1V1\<bar>setHIDDENM2 holds F =XBOOLE-0R4 {k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n } implies cardCARD-1K4 F =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_130:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cardCARD-1K1 ({k where k be NatNAT-1M1 : m <=XXREAL-0R1 k & k <=XXREAL-0R1 m +XCMPLX-0K2 n }) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_131:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 l & l <=XXREAL-0R1 n implies SgmFINSEQ-1K15 ({kk where kk be NatNAT-1M1 : m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 kk & kk <=XXREAL-0R1 m +XCMPLX-0K2 n }) .FUNCT-1K1 l =XBOOLE-0R4 m +XCMPLX-0K2 l"
sorry

(*begin*)
mdef finseq_6_def_4 ("'( _ , _ ')-cutFINSEQ-6K4  _ " [0,0,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"func (m,n)-cutFINSEQ-6K4 p \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. lenFINSEQ-1K4 it +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it implies it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)) if (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p otherwise \<lambda>it. it =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
  (*existence*)
    show "((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies ( ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it implies it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i)))) & ( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies ( ex it be FinSequenceFINSEQ-1M1 st it =FINSEQ-1R1 {}XBOOLE-0K1))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((lenFINSEQ-1K4 it1 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it1 implies it1 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))) & (lenFINSEQ-1K4 it2 +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 it2 implies it2 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))) implies it1 =HIDDENR1 it2)) & ( not ((\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p) implies (it1 =FINSEQ-1R1 {}XBOOLE-0K1 & it2 =FINSEQ-1R1 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
sorry
qed "sorry"

mlemma finseq_6_lm_6:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) +XCMPLX-0K2 m =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) implies ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (m +XCMPLX-0K2 i))"
sorry

mtheorem finseq_6_th_132:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 p implies (m,m)-cutFINSEQ-6K4 p =FINSEQ-1R1 <*FINSEQ-1K10 p .FUNCT-1K1 m*>"
sorry

mtheorem finseq_6_th_133:
" for p be FinSequenceFINSEQ-1M1 holds (\<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p =FINSEQ-1R1 p"
sorry

mtheorem finseq_6_th_134:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for r be NatNAT-1M1 holds (m <=XXREAL-0R1 n & n <=XXREAL-0R1 r) & r <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p) =FINSEQ-1R1 (m +NAT-1K1 \<one>\<^sub>M,r)-cutFINSEQ-6K4 p"
sorry

mtheorem finseq_6_th_135:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds m <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =FINSEQ-1R1 p"
sorry

mtheorem finseq_6_th_136:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies (((\<one>\<^sub>M,m)-cutFINSEQ-6K4 p)^FINSEQ-1K8 ((m +NAT-1K1 \<one>\<^sub>M,n)-cutFINSEQ-6K4 p))^FINSEQ-1K8 ((n +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 p)-cutFINSEQ-6K4 p) =FINSEQ-1R1 p"
sorry

mtheorem finseq_6_th_137:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K4 p) c=TARSKIR1 rngFUNCT-1K2 p"
sorry

syntax FINSEQ_6K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("'( _ , _ ')-cutFINSEQ-6K5\<^bsub>'( _ ')\<^esub>  _ " [0,0,0,164]164)
translations "(m,n)-cutFINSEQ-6K5\<^bsub>(D)\<^esub> p" \<rightharpoonup> "(m,n)-cutFINSEQ-6K4 p"

mtheorem finseq_6_add_2:
  mlet "D be setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "m be NatNAT-1M1", "n be NatNAT-1M1"
"cluster (m,n)-cutFINSEQ-6K4 p as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "(m,n)-cutFINSEQ-6K4 p be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

mtheorem finseq_6_th_138:
" for p be FinSequenceFINSEQ-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p .FUNCT-1K1 m & ((m,n)-cutFINSEQ-6K4 p).FUNCT-1K1 lenFINSEQ-1K4 ((m,n)-cutFINSEQ-6K4 p) =XBOOLE-0R4 p .FUNCT-1K1 n"
sorry

(*begin*)
mdef finseq_6_def_5 (" _ ^''FINSEQ-6K6  _ " [164,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"func p ^'FINSEQ-6K6 q \<rightarrow> FinSequenceFINSEQ-1M1 equals
  p ^FINSEQ-1K8 ((\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q)"
proof-
  (*coherence*)
    show "p ^FINSEQ-1K8 ((\<two>\<^sub>M,lenFINSEQ-1K4 q)-cutFINSEQ-6K4 q) be FinSequenceFINSEQ-1M1"
       sorry
qed "sorry"

mtheorem finseq_6_th_139:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q"
sorry

mtheorem finseq_6_th_140:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
sorry

mtheorem finseq_6_th_141:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 q implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_142:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 q implies (p ^'FINSEQ-6K6 q).FUNCT-1K1 lenFINSEQ-1K4 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 q .FUNCT-1K1 lenFINSEQ-1K4 q"
sorry

mtheorem finseq_6_th_143:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
sorry

syntax FINSEQ_6K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^''FINSEQ-6K7\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "p ^'FINSEQ-6K7\<^bsub>(D)\<^esub> q" \<rightharpoonup> "p ^'FINSEQ-6K6 q"

mtheorem finseq_6_add_3:
  mlet "D be setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "q be FinSequenceFINSEQ-1M3-of D"
"cluster p ^'FINSEQ-6K6 q as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "p ^'FINSEQ-6K6 q be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

mtheorem finseq_6_th_144:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p <>HIDDENR2 {}XBOOLE-0K1 & q <>HIDDENR2 {}XBOOLE-0K1) & p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M implies rngFUNCT-1K2 (p ^'FINSEQ-6K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
sorry

(*begin*)
mdef finseq_6_def_6 ("TwoValuedFINSEQ-6V2" 70 ) where
"attr TwoValuedFINSEQ-6V2 for FinSequenceFINSEQ-1M1 means
  (\<lambda>f. cardCARD-1K4 (rngFUNCT-1K2 f) =XBOOLE-0R4 \<two>\<^sub>M)"..

mlemma finseq_6_lm_7:
"lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) >XXREAL-0R4 \<one>\<^sub>M & (\<one>\<^sub>M <>HIDDENR2 \<two>\<^sub>M & rngFUNCT-1K2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) =HIDDENR1 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M })"
sorry

mtheorem finseq_6_th_145:
" for p be FinSequenceFINSEQ-1M1 holds p be TwoValuedFINSEQ-6V2 iff lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M & ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK2 x,y })"
sorry

mlemma finseq_6_lm_8:
"<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *> be TwoValuedFINSEQ-6V2"
  using finseq_6_lm_7 sorry

mlemma finseq_6_lm_9:
" for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>) implies (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>).FUNCT-1K1 i <>HIDDENR2 (<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
sorry

mdef finseq_6_def_7 ("AlternatingFINSEQ-6V3" 70 ) where
"attr AlternatingFINSEQ-6V3 for FinSequenceFINSEQ-1M1 means
  (\<lambda>f.  for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 i <>HIDDENR2 f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"..

mlemma finseq_6_lm_10:
"<*FINSEQ-4K2\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *> be AlternatingFINSEQ-6V3"
  using finseq_6_lm_9 sorry

mtheorem finseq_6_cl_8:
"cluster TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3"
    using finseq_6_lm_8 finseq_6_lm_10 sorry
qed "sorry"

reserve a, a1, a2 for "TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1"
mtheorem finseq_6_th_146:
" for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2 & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2) & a1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a2 .FUNCT-1K1 \<one>\<^sub>M implies a1 =FINSEQ-1R1 a2"
sorry

mtheorem finseq_6_th_147:
" for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds (a1 <>HIDDENR2 a2 & lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2) & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2 implies ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 a1 implies a1 .FUNCT-1K1 i <>HIDDENR2 a2 .FUNCT-1K1 i)"
sorry

mtheorem finseq_6_th_148:
" for a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds  for a2 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds (a1 <>HIDDENR2 a2 & lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2) & rngFUNCT-1K2 a1 =XBOOLE-0R4 rngFUNCT-1K2 a2 implies ( for a be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 a1 & rngFUNCT-1K2 a =XBOOLE-0R4 rngFUNCT-1K2 a1 implies a =FINSEQ-1R1 a1 or a =FINSEQ-1R1 a2)"
sorry

mtheorem finseq_6_th_149:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for n be NatNAT-1M1 holds X <>HIDDENR2 Y & n >XXREAL-0R4 \<one>\<^sub>M implies ( ex a1 be TwoValuedFINSEQ-6V2\<bar>AlternatingFINSEQ-6V3\<bar>FinSequenceFINSEQ-1M1 st (rngFUNCT-1K2 a1 =XBOOLE-0R4 {TARSKIK2 X,Y } & lenFINSEQ-1K4 a1 =XBOOLE-0R4 n) & a1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 X)"
sorry

(*begin*)
mtheorem finseq_6_cl_9:
  mlet "X be setHIDDENM2", "fs be FinSequenceFINSEQ-1M3-of X"
"cluster note-that FinSubsequence-likeFINSEQ-1V2 for SubsetSUBSET-1M2-of fs"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of fs holds it be FinSubsequence-likeFINSEQ-1V2"
sorry
qed "sorry"

mtheorem finseq_6_th_150:
" for f be FinSubsequenceFINSEQ-1M4 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FinSequenceFINSEQ-1M1 holds  for fg be FinSequenceFINSEQ-1M1 holds  for fh be FinSequenceFINSEQ-1M1 holds  for fgh be FinSequenceFINSEQ-1M1 holds (((rngFUNCT-1K2 g c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f & rngFUNCT-1K2 h c=TARSKIR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> f) & fg =FUNCT-1R1 f *FUNCT-1K3 g) & fh =FUNCT-1R1 f *FUNCT-1K3 h) & fgh =FUNCT-1R1 f *FUNCT-1K3 (g ^FINSEQ-1K8 h) implies fgh =FINSEQ-1R1 fg ^FINSEQ-1K8 fh"
sorry

reserve fs, fs1, fs2 for "FinSequenceFINSEQ-1M3-of X"
reserve fss, fss2 for "SubsetSUBSET-1M2-of fs"
mtheorem finseq_6_th_151:
" for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss c=TARSKIR1 domFINSEQ-1K5 fs & rngFUNCT-1K2 fss c=TARSKIR1 rngFUNCT-1K2 fs"
  using relat_1_th_11 sorry

mtheorem finseq_6_th_152:
" for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds fs be SubsetSUBSET-1M2-of fs"
sorry

mtheorem finseq_6_th_153:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds fss  |RELAT-1K8 Y be SubsetSUBSET-1M2-of fs"
sorry

mtheorem finseq_6_th_154:
" for X be setHIDDENM2 holds  for fs be FinSequenceFINSEQ-1M3-of X holds  for fs1 be FinSequenceFINSEQ-1M3-of X holds  for fs2 be FinSequenceFINSEQ-1M3-of X holds  for fss be SubsetSUBSET-1M2-of fs holds  for fss2 be SubsetSUBSET-1M2-of fs holds  for fss1 be SubsetSUBSET-1M2-of fs1 holds (SeqFINSEQ-1K16 fss =FINSEQ-1R1 fs1 & SeqFINSEQ-1K16 fss1 =FINSEQ-1R1 fs2) & fss2 =FUNCT-1R1 fss  |RELAT-1K8 rngFUNCT-1K2 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss)  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> fss1) implies SeqFINSEQ-1K16 fss2 =FINSEQ-1R1 fs2"
sorry

(*begin*)
mtheorem finseq_6_th_155:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_156:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be  non trivialZFMISC-1V1\<bar>FinSequenceFINSEQ-1M3-of D holds (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f2"
sorry

mtheorem finseq_6_th_157:
" for f be FinSequenceFINSEQ-1M1 holds f ^'FINSEQ-6K6 {}XBOOLE-0K1 =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_158:
" for x be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds f ^'FINSEQ-6K6 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_159:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
sorry

mtheorem finseq_6_th_160:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 f2 implies (f1 ^'FINSEQ-6K7\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +XCMPLX-0K2 n) =XBOOLE-0R4 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mdef finseq_6_def_8 ("min-atFINSEQ-6K8'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of INTINT-1K1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"assume \<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) func min-atFINSEQ-6K8(F,m,n) \<rightarrow> NatNAT-1M1 means
  \<lambda>it.  ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m"
proof-
  (*existence*)
    show "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) implies ( ex it be NatNAT-1M1 st  ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m)"
sorry
  (*uniqueness*)
    show "\<one>\<^sub>M <=XXREAL-0R1 m & (m <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 F) implies ( for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ( ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m) & ( ex X be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of INTINT-1K1 st X =XBOOLE-0R4 rngFUNCT-1K2 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) & it2 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 minXXREAL-2K5 X ..FINSEQ-4K4 ((m,n)-cutFINSEQ-6K5\<^bsub>(INTINT-1K1)\<^esub> F) +XCMPLX-0K2 m) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

reserve F, F1 for "FinSequenceFINSEQ-1M3-of INTINT-1K1"
reserve k, m, n, ma for "NatNAT-1M1"
mtheorem finseq_6_th_161:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 n) & n <=XXREAL-0R1 lenFINSEQ-1K4 F implies (ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,m,n) iff ((m <=XXREAL-0R1 ma & ma <=XXREAL-0R1 n) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <=XXREAL-0R1 n implies F .FUNCT-1K1 ma <=XXREAL-0R1 F .FUNCT-1K1 i)) & ( for i be NatNAT-1M1 holds m <=XXREAL-0R1 i & i <XXREAL-0R3 ma implies F .FUNCT-1K1 ma <XXREAL-0R3 F .FUNCT-1K1 i))"
sorry

mtheorem finseq_6_th_162:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 F implies min-atFINSEQ-6K8(F,m,m) =XBOOLE-0R4 m"
sorry

mdef finseq_6_def_9 (" _ is-non-decreasing-onFINSEQ-6R1'( _ , _ ')" [50,0,0]50 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of INTINT-1K1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"pred F is-non-decreasing-onFINSEQ-6R1(m,n) means
   for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds (m <=XXREAL-0R1 i & i <=XXREAL-0R1 j) & j <=XXREAL-0R1 n implies F .FUNCT-1K1 i <=XXREAL-0R1 F .FUNCT-1K1 j"..

mdef finseq_6_def_10 (" _ is-split-atFINSEQ-6R2  _ " [50,50]50 ) where
  mlet "F be FinSequenceFINSEQ-1M3-of INTINT-1K1", "n be NatNAT-1M1"
"pred F is-split-atFINSEQ-6R2 n means
   for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 n) & n <XXREAL-0R3 j) & j <=XXREAL-0R1 lenFINSEQ-1K4 F implies F .FUNCT-1K1 i <=XXREAL-0R1 F .FUNCT-1K1 j"..

mtheorem finseq_6_th_163:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for k be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds (((k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F & ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F)) & F is-split-atFINSEQ-6R2 k) & F is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k)) & F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies F1 is-non-decreasing-onFINSEQ-6R1(\<one>\<^sub>M,k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem finseq_6_th_164:
" for F be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for F1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for k be NatNAT-1M1 holds  for ma be NatNAT-1M1 holds ((k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 F & ma =XBOOLE-0R4 min-atFINSEQ-6K8(F,k +NAT-1K1 \<one>\<^sub>M,lenFINSEQ-1K4 F)) & F is-split-atFINSEQ-6R2 k) & F1 =FUNCT-1R1 (F +*FUNCT-7K1(k +NAT-1K1 \<one>\<^sub>M,F .FUNCT-1K1 ma))+*FUNCT-7K1(ma,F .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies F1 is-split-atFINSEQ-6R2 k +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem finseq_6_th_165:
" for f be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >=XXREAL-0R2 n implies f is-non-decreasing-onFINSEQ-6R1(m,n)"
sorry

(*begin*)
reserve i, j, k, m, n for "NatNAT-1M1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f for "FinSequenceFINSEQ-1M3-of D"
syntax FINSEQ_6V4 :: " Set \<Rightarrow> Ty" ("constantFINSEQ-6V4\<^bsub>'( _ ')\<^esub>" [0]70)
translations "constantFINSEQ-6V4\<^bsub>(D)\<^esub>" \<rightharpoonup> "constantFUNCT-1V5"

mtheorem finseq_6_def_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D"
"redefine attr constantFINSEQ-6V4\<^bsub>(D)\<^esub> for FinSequenceFINSEQ-1M3-of D means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)"
proof
(*compatibility*)
  show " for f be FinSequenceFINSEQ-1M3-of D holds f be constantFINSEQ-6V4\<^bsub>(D)\<^esub> iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m)"
sorry
qed "sorry"

mtheorem finseq_6_th_166:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-4R2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f)..FINSEQ-4K4 f =XBOOLE-0R4 lenFINSEQ-1K4 f"
sorry

mtheorem finseq_6_th_167:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =FINSEQ-1R1 {}XBOOLE-0K1"
  using rfinseq_th_27 sorry

mtheorem finseq_6_th_168:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f inTARSKIR2 rngFUNCT-1K2 f"
sorry

syntax FINSEQ_6R3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ just-once-valuesFINSEQ-6R3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> y" \<rightharpoonup> "f just-once-valuesFINSEQ-4R2 y"

mtheorem finseq_6_def_12:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "y be setHIDDENM2"
"redefine pred f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> y means
   ex x be setHIDDENM2 st (x inTARSKIR2 domFINSEQ-1K5 f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y)"
proof
(*compatibility*)
  show "f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> y iff ( ex x be setHIDDENM2 st (x inTARSKIR2 domFINSEQ-1K5 f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x) & ( for z be setHIDDENM2 holds z inTARSKIR2 domFINSEQ-1K5 f & z <>HIDDENR2 x implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> z <>HIDDENR2 y))"
sorry
qed "sorry"

mtheorem finseq_6_th_169:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =FINSEQ-1R1 f"
sorry

mtheorem finseq_6_th_170:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f just-once-valuesFINSEQ-6R3\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>"
sorry

mtheorem finseq_6_th_171:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
sorry

mtheorem finseq_6_th_172:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 lenFINSEQ-1K4 f"
sorry

mtheorem finseq_6_th_173:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds RevFINSEQ-5K4\<^bsub>(D)\<^esub> f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
sorry

(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_6_th_174:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & \<one>\<^sub>M <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 p ..FINSEQ-4K4 f)"
sorry

mtheorem finseq_6_th_175:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & p ..FINSEQ-4K4 f <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 p ..FINSEQ-4K4 f)"
sorry

mtheorem finseq_6_th_176:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
sorry

mlemma finseq_6_lm_11:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds j <XXREAL-0R3 i implies (i -'NAT-DK9 (j +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i -'NAT-DK9 j"
sorry

mtheorem finseq_6_th_177:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <XXREAL-0R3 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
sorry

mtheorem finseq_6_th_178:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & \<one>\<^sub>M <XXREAL-0R3 i) & i <=XXREAL-0R1 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
sorry

mtheorem finseq_6_th_179:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f"
sorry

mtheorem finseq_6_th_180:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds domFINSEQ-1K5 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p)) =XBOOLE-0R4 domFINSEQ-1K5 f"
sorry

mtheorem finseq_6_th_181:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds  for p be ElementSUBSET-1M1-of D holds ( for i be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i <>HIDDENR2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p),f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M) =FINSEQ-1R1 f"
sorry

(*begin*)
reserve f for "circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_6_th_182:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 p ..FINSEQ-4K4 f)-'NAT-DK9 lenFINSEQ-1K4 f)"
sorry

mtheorem finseq_6_th_183:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D holds (p inTARSKIR2 rngFUNCT-1K2 f & \<one>\<^sub>M <=XXREAL-0R1 i) & i <=XXREAL-0R1 p ..FINSEQ-4K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 (RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p))/.PARTFUN1K7\<^bsub>(D)\<^esub> ((i +NAT-1K1 lenFINSEQ-1K4 f)-'NAT-DK9 p ..FINSEQ-4K4 f)"
sorry

mtheorem finseq_6_cl_10:
  mlet "D be  non trivialZFMISC-1V1\<bar>setHIDDENM2"
"cluster  non constantFUNCT-1V5\<bar>circularFINSEQ-6V1\<^bsub>(D)\<^esub> for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be  non constantFUNCT-1V5\<bar>circularFINSEQ-6V1\<^bsub>(D)\<^esub>"
sorry
qed "sorry"

mtheorem finseq_6_cl_11:
  mlet "D be  non trivialZFMISC-1V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be  non constantFUNCT-1V5\<bar>circularFINSEQ-6V1\<^bsub>(D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) as-term-is  non constantFUNCT-1V5"
proof
(*coherence*)
  show "RotateFINSEQ-6K1\<^bsub>(D)\<^esub>(f,p) be  non constantFUNCT-1V5"
sorry
qed "sorry"

end
