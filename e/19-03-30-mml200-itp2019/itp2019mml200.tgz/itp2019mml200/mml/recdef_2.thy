theory recdef_2
  imports funct_7 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, e, z for "objectHIDDENM1"
reserve A, B, C, D, E for "setHIDDENM2"
abbreviation(input) RECDEF_2K1(" _ `1-3RECDEF-2K1" [164]164) where
  "x `1-3RECDEF-2K1 \<equiv> x `1-3XTUPLE-0K4"

mtheorem recdef_2_def_1:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"redefine func x `1-3RECDEF-2K1 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y1"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `1-3RECDEF-2K1 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y1)"
sorry
qed "sorry"

abbreviation(input) RECDEF_2K2(" _ `2-3RECDEF-2K2" [164]164) where
  "x `2-3RECDEF-2K2 \<equiv> x `2-3XTUPLE-0K5"

mtheorem recdef_2_def_2:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"redefine func x `2-3RECDEF-2K2 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y2"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `2-3RECDEF-2K2 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y2)"
sorry
qed "sorry"

abbreviation(input) RECDEF_2K3(" _ `3-3RECDEF-2K3" [164]164) where
  "x `3-3RECDEF-2K3 \<equiv> x `2XTUPLE-0K2"

mtheorem recdef_2_def_3:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"redefine func x `3-3RECDEF-2K3 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y3"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `3-3RECDEF-2K3 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y3)"
sorry
qed "sorry"

(*\$CT*)
mtheorem recdef_2_th_2:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 A,B,C :] implies (z `1-3XTUPLE-0K4 inHIDDENR3 A & z `2-3XTUPLE-0K5 inHIDDENR3 B) & z `3-3XTUPLE-0K6 inHIDDENR3 C"
sorry

mtheorem recdef_2_th_3:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 A,B,C :] implies z =HIDDENR1 [XTUPLE-0K3 z `1-3XTUPLE-0K4,z `2-3XTUPLE-0K5,z `3-3XTUPLE-0K6 ]"
sorry

abbreviation(input) RECDEF_2K4(" _ `1-4RECDEF-2K4" [164]164) where
  "x `1-4RECDEF-2K4 \<equiv> x `1-4XTUPLE-0K8"

mtheorem recdef_2_def_4:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `1-4RECDEF-2K4 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y1"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `1-4RECDEF-2K4 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y1)"
sorry
qed "sorry"

abbreviation(input) RECDEF_2K5(" _ `2-4RECDEF-2K5" [164]164) where
  "x `2-4RECDEF-2K5 \<equiv> x `2-4XTUPLE-0K9"

mtheorem recdef_2_def_5:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `2-4RECDEF-2K5 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y2"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `2-4RECDEF-2K5 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y2)"
sorry
qed "sorry"

abbreviation(input) RECDEF_2K6(" _ `3-4RECDEF-2K6" [164]164) where
  "x `3-4RECDEF-2K6 \<equiv> x `2-3XTUPLE-0K5"

mtheorem recdef_2_def_6:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `3-4RECDEF-2K6 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y3"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `3-4RECDEF-2K6 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y3)"
sorry
qed "sorry"

abbreviation(input) RECDEF_2K7(" _ `4-4RECDEF-2K7" [164]164) where
  "x `4-4RECDEF-2K7 \<equiv> x `2XTUPLE-0K2"

mtheorem recdef_2_def_7:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `4-4RECDEF-2K7 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y4"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `4-4RECDEF-2K7 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y4)"
sorry
qed "sorry"

(*\$CT*)
mtheorem recdef_2_th_5:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :] implies ((z `1-4XTUPLE-0K8 inHIDDENR3 A & z `2-4XTUPLE-0K9 inHIDDENR3 B) & z `3-4XTUPLE-0K10 inHIDDENR3 C) & z `4-4XTUPLE-0K11 inHIDDENR3 D"
sorry

mtheorem recdef_2_th_6:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :] implies z =HIDDENR1 [XTUPLE-0K7 z `1-4XTUPLE-0K8,z `2-4XTUPLE-0K9,z `3-4XTUPLE-0K10,z `4-4XTUPLE-0K11 ]"
sorry

(*\$CD 5*)
(*\$CT 3*)
theorem recdef_2_sch_1:
  fixes Cf0 Ff1 Gf1 Hf1 Pp1 Qp1 Rp1 
  assumes
[ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be objectHIDDENM1" and
   A1: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Rp1(c))" and
   A2: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (Pp1(c) or Qp1(c)) or Rp1(c)"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c)))"
sorry

theorem recdef_2_sch_2:
  fixes Cf0 Ff1 Gf1 Hf1 If1 Pp1 Qp1 Rp1 Sp1 
  assumes
[ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> If1(x1) be objectHIDDENM1" and
   A1: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (((((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Pp1(c) implies  not Sp1(c))) & (Qp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Sp1(c))) & (Rp1(c) implies  not Sp1(c))" and
   A2: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) or Qp1(c)) or Rp1(c)) or Sp1(c)"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (((Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c))) & (Sp1(c) implies f .FUNCT-1K1 c =HIDDENR1 If1(c)))"
sorry

theorem recdef_2_sch_3:
  fixes Af0 Bf0 A0f0 B0f0 Pp5 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "A0f0 be ElementSUBSET-1M1-of Af0" and
  [ty]: "B0f0 be ElementSUBSET-1M1-of Bf0" and
   A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Bf0 holds  ex x1 be ElementSUBSET-1M1-of Af0 st  ex y1 be ElementSUBSET-1M1-of Bf0 st Pp5(n,x,y,x1,y1)"
  shows " ex f be sequenceNAT-1M2-of Af0 st  ex g be sequenceNAT-1M2-of Bf0 st (f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 A0f0 & g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 B0f0) & ( for n be NatNAT-1M1 holds Pp5(n,f .FUNCT-1K1 n,g .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

theorem recdef_2_sch_4:
  fixes Af0 Bf0 Ff3 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st ((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0) & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Bf0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

theorem recdef_2_sch_5:
  fixes Xf0 Af0 Bf0 Ff3 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be ElementSUBSET-1M1-of Xf0"
  shows " ex f be sequenceNAT-1M2-of Xf0 st (f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

theorem recdef_2_sch_6:
  fixes Af0 Bf0 Ff0 Gf0 Ff3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be objectHIDDENM1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
  shows "Ff0 =FUNCT-1R1 Gf0"
sorry

theorem recdef_2_sch_7:
  fixes Xf0 Af0 Bf0 Ff0 Gf0 Ff3 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Xf0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be ElementSUBSET-1M1-of Xf0" and
   A1: "Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))" and
   A3: "Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
sorry

theorem recdef_2_sch_8:
  fixes Af0 Bf0 Cf0 Ff4 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st (((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0) & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 Cf0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M)))"
sorry

theorem recdef_2_sch_9:
  fixes Xf0 Af0 Bf0 Cf0 Ff4 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Cf0 be ElementSUBSET-1M1-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be ElementSUBSET-1M1-of Xf0"
  shows " ex f be sequenceNAT-1M2-of Xf0 st ((f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M)))"
sorry

theorem recdef_2_sch_10:
  fixes Af0 Bf0 Cf0 Ff0 Gf0 Ff4 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty]: "Cf0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be objectHIDDENM1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "(Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Ff0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "(Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Gf0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))"
  shows "Ff0 =FUNCT-1R1 Gf0"
sorry

theorem recdef_2_sch_11:
  fixes Xf0 Af0 Bf0 Cf0 Ff0 Gf0 Ff4 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Cf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Xf0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be ElementSUBSET-1M1-of Xf0" and
   A1: "(Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M))" and
   A3: "(Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M))"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
sorry

theorem recdef_2_sch_12:
  fixes Af0 Bf0 Cf0 Df0 Ff0 Gf0 Ff5 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty]: "Cf0 be objectHIDDENM1" and
  [ty]: "Df0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
  [ty_func]: "\<And> x1 x2 x3 x4 x5. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> x5 be objectHIDDENM1 \<Longrightarrow> Ff5(x1,x2,x3,x4,x5) be objectHIDDENM1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "((Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Ff0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0) & Ff0 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 Df0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<four>\<^sub>M) =HIDDENR1 Ff5(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M),Ff0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "((Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Gf0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0) & Gf0 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 Df0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<four>\<^sub>M) =HIDDENR1 Ff5(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M),Gf0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M))"
  shows "Ff0 =FUNCT-1R1 Gf0"
sorry

theorem recdef_2_sch_13:
  fixes Xf0 Af0 Bf0 Cf0 Df0 Ff0 Gf0 Ff5 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Cf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Df0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Xf0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3 x4 x5. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> x5 be objectHIDDENM1 \<Longrightarrow> Ff5(x1,x2,x3,x4,x5) be ElementSUBSET-1M1-of Xf0" and
   A1: "((Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 Df0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<four>\<^sub>M) =XBOOLE-0R4 Ff5(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M),Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M))" and
   A3: "((Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 Df0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<four>\<^sub>M) =XBOOLE-0R4 Ff5(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M),Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M))"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
sorry

(*begin*)
mtheorem recdef_2_th_10:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (((x `1-3XTUPLE-0K4 =HIDDENR1 y `1-3XTUPLE-0K4 & x `2-3XTUPLE-0K5 =HIDDENR1 y `2-3XTUPLE-0K5) & x `3-3XTUPLE-0K6 =HIDDENR1 y `3-3XTUPLE-0K6) & y inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :]) & x inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :] implies x =XBOOLE-0R4 y"
sorry

end
