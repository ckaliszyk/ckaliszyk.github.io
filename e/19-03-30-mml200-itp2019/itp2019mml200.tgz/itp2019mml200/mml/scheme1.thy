theory scheme1
  imports nat_d seqm_3 classes1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z for "objectHIDDENM1"
reserve n, m, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve r for "RealXREAL-0M1"
mtheorem scheme1_th_1:
" for n be NatNAT-1M1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m or n =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem scheme1_th_2:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st (n =XBOOLE-0R4 \<three>\<^sub>M *NAT-1K2 m or n =XBOOLE-0R4 \<three>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M) or n =XBOOLE-0R4 \<three>\<^sub>M *NAT-1K2 m +NAT-1K1 \<two>\<^sub>M"
sorry

mtheorem scheme1_th_3:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ((n =XBOOLE-0R4 \<four>\<^sub>M *NAT-1K2 m or n =XBOOLE-0R4 \<four>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M) or n =XBOOLE-0R4 \<four>\<^sub>M *NAT-1K2 m +NAT-1K1 \<two>\<^sub>M) or n =XBOOLE-0R4 \<four>\<^sub>M *NAT-1K2 m +NAT-1K1 \<three>\<^sub>M"
sorry

mtheorem scheme1_th_4:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st (((n =XBOOLE-0R4 \<five>\<^sub>M *NAT-1K2 m or n =XBOOLE-0R4 \<five>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M) or n =XBOOLE-0R4 \<five>\<^sub>M *NAT-1K2 m +NAT-1K1 \<two>\<^sub>M) or n =XBOOLE-0R4 \<five>\<^sub>M *NAT-1K2 m +NAT-1K1 \<three>\<^sub>M) or n =XBOOLE-0R4 \<five>\<^sub>M *NAT-1K2 m +NAT-1K1 \<four>\<^sub>M"
sorry

theorem scheme1_sch_1:
  fixes sf0 Pp1 
  assumes
[ty]: "sf0 be Real-SequenceSEQ-1M1" and
   A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
  shows " ex q be Real-SequenceSEQ-1M1 st (q be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of sf0 & ( for n be NatNAT-1M1 holds Pp1(q .FUNCT-1K1 n))) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =HIDDENR1 sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies Pp1(r)) implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =XBOOLE-0R4 q .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m))"
sorry

theorem scheme1_sch_2:
  fixes Ff1 Gf1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2"
  shows " ex s be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) =XBOOLE-0R4 Ff1(n) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf1(n)"
sorry

theorem scheme1_sch_3:
  fixes Ff1 Gf1 Hf1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2"
  shows " ex s be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<three>\<^sub>M *NAT-1K2 n) =XBOOLE-0R4 Ff1(n) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<three>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf1(n)) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<three>\<^sub>M *NAT-1K2 n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Hf1(n)"
sorry

theorem scheme1_sch_4:
  fixes Ff1 Gf1 Hf1 If1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> If1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2"
  shows " ex s be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<four>\<^sub>M *NAT-1K2 n) =XBOOLE-0R4 Ff1(n) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<four>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf1(n)) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<four>\<^sub>M *NAT-1K2 n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Hf1(n)) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<four>\<^sub>M *NAT-1K2 n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 If1(n)"
sorry

theorem scheme1_sch_5:
  fixes Ff1 Gf1 Hf1 If1 Jf1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> If1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Jf1(x1) be ElementSUBSET-1M1-of REALNUMBERSK2"
  shows " ex s be Real-SequenceSEQ-1M1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<five>\<^sub>M *NAT-1K2 n) =XBOOLE-0R4 Ff1(n) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<five>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf1(n)) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<five>\<^sub>M *NAT-1K2 n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Hf1(n)) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<five>\<^sub>M *NAT-1K2 n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 If1(n)) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<five>\<^sub>M *NAT-1K2 n +NAT-1K1 \<four>\<^sub>M) =XBOOLE-0R4 Jf1(n)"
sorry

theorem scheme1_sch_6:
  fixes Cf0 Df0 Ff1 Gf1 Pp1 Qp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds Pp1(c) implies  not Qp1(c)"
  shows " ex f be PartFuncPARTFUN1M1-of(Cf0,Df0) st ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f iff Pp1(c) or Qp1(c)) & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies (Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Gf1(c)))"
sorry

theorem scheme1_sch_7:
  fixes Cf0 Df0 Ff1 Gf1 Pp1 Qp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds Pp1(c) & Qp1(c) implies Ff1(c) =XBOOLE-0R4 Gf1(c)"
  shows " ex f be PartFuncPARTFUN1M1-of(Cf0,Df0) st ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f iff Pp1(c) or Qp1(c)) & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies (Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Gf1(c)))"
sorry

theorem scheme1_sch_8:
  fixes Cf0 Df0 Ff1 Gf1 Pp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0"
  shows " ex f be PartFuncPARTFUN1M1-of(Cf0,Df0) st f be totalPARTFUN1V1\<^bsub>(Cf0)\<^esub> & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies (Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Ff1(c)) & ( not Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Gf1(c)))"
sorry

theorem scheme1_sch_9:
  fixes Cf0 Df0 Ff1 Gf1 Hf1 Pp1 Qp1 Rp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds ((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Rp1(c))"
  shows " ex f be PartFuncPARTFUN1M1-of(Cf0,Df0) st ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f iff (Pp1(c) or Qp1(c)) or Rp1(c)) & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies ((Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Hf1(c)))"
sorry

theorem scheme1_sch_10:
  fixes Cf0 Df0 Ff1 Gf1 Hf1 Pp1 Qp1 Rp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds ((Pp1(c) & Qp1(c) implies Ff1(c) =XBOOLE-0R4 Gf1(c)) & (Pp1(c) & Rp1(c) implies Ff1(c) =XBOOLE-0R4 Hf1(c))) & (Qp1(c) & Rp1(c) implies Gf1(c) =XBOOLE-0R4 Hf1(c))"
  shows " ex f be PartFuncPARTFUN1M1-of(Cf0,Df0) st ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f iff (Pp1(c) or Qp1(c)) or Rp1(c)) & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies ((Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Hf1(c)))"
sorry

theorem scheme1_sch_11:
  fixes Cf0 Df0 Ff1 Gf1 Hf1 If1 Pp1 Qp1 Rp1 Sp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> If1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds (((((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Pp1(c) implies  not Sp1(c))) & (Qp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Sp1(c))) & (Rp1(c) implies  not Sp1(c))"
  shows " ex f be PartFuncPARTFUN1M1-of(Cf0,Df0) st ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f iff ((Pp1(c) or Qp1(c)) or Rp1(c)) or Sp1(c)) & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies (((Pp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 Hf1(c))) & (Sp1(c) implies f .FUNCT-1K1 c =XBOOLE-0R4 If1(c)))"
sorry

theorem scheme1_sch_12:
  fixes Xf0 Yf0 Ff1 Gf1 Pp1 Qp1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies (Pp1(x) implies  not Qp1(x))" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Pp1(x) implies Ff1(x) inTARSKIR2 Yf0" and
   A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Qp1(x) implies Gf1(x) inTARSKIR2 Yf0"
  shows " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & (Pp1(x) or Qp1(x))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies (Pp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)) & (Qp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Gf1(x)))"
sorry

theorem scheme1_sch_13:
  fixes Xf0 Yf0 Ff1 Gf1 Hf1 Pp1 Qp1 Rp1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ((Pp1(x) implies  not Qp1(x)) & (Pp1(x) implies  not Rp1(x))) & (Qp1(x) implies  not Rp1(x))" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Pp1(x) implies Ff1(x) inTARSKIR2 Yf0" and
   A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Qp1(x) implies Gf1(x) inTARSKIR2 Yf0" and
   A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Rp1(x) implies Hf1(x) inTARSKIR2 Yf0"
  shows " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ((Pp1(x) or Qp1(x)) or Rp1(x))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies ((Pp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)) & (Qp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Gf1(x))) & (Rp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Hf1(x)))"
sorry

theorem scheme1_sch_14:
  fixes Xf0 Yf0 Ff1 Gf1 Hf1 If1 Pp1 Qp1 Rp1 Sp1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> If1(x1) be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies (((((Pp1(x) implies  not Qp1(x)) & (Pp1(x) implies  not Rp1(x))) & (Pp1(x) implies  not Sp1(x))) & (Qp1(x) implies  not Rp1(x))) & (Qp1(x) implies  not Sp1(x))) & (Rp1(x) implies  not Sp1(x))" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Pp1(x) implies Ff1(x) inTARSKIR2 Yf0" and
   A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Qp1(x) implies Gf1(x) inTARSKIR2 Yf0" and
   A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Rp1(x) implies Hf1(x) inTARSKIR2 Yf0" and
   A5: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Sp1(x) implies If1(x) inTARSKIR2 Yf0"
  shows " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & (((Pp1(x) or Qp1(x)) or Rp1(x)) or Sp1(x))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies (((Pp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)) & (Qp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Gf1(x))) & (Rp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 Hf1(x))) & (Sp1(x) implies f .FUNCT-1K1 x =XBOOLE-0R4 If1(x)))"
sorry

theorem scheme1_sch_15:
  fixes Cf0 Df0 Ef0 Ff2 Gf2 Pp2 Qp2 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Ef0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Gf2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds Pp2(c,d) implies  not Qp2(c,d)"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Cf0,Df0 :],Ef0) st ( for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,d ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f iff Pp2(c,d) or Qp2(c,d)) & ( for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,d ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f implies (Pp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Ff2(c,d)) & (Qp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Gf2(c,d)))"
sorry

theorem scheme1_sch_16:
  fixes Cf0 Df0 Ef0 Ff2 Gf2 Hf2 Pp2 Qp2 Rp2 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Ef0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Gf2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Hf2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds  for s be ElementSUBSET-1M1-of Df0 holds ((Pp2(c,s) implies  not Qp2(c,s)) & (Pp2(c,s) implies  not Rp2(c,s))) & (Qp2(c,s) implies  not Rp2(c,s))"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Cf0,Df0 :],Ef0) st ( for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,d ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f iff (Pp2(c,d) or Qp2(c,d)) or Rp2(c,d)) & ( for c be ElementSUBSET-1M1-of Cf0 holds  for r be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,r ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f implies ((Pp2(c,r) implies f .FUNCT-1K1 [TARSKIK4 c,r ] =XBOOLE-0R4 Ff2(c,r)) & (Qp2(c,r) implies f .FUNCT-1K1 [TARSKIK4 c,r ] =XBOOLE-0R4 Gf2(c,r))) & (Rp2(c,r) implies f .FUNCT-1K1 [TARSKIK4 c,r ] =XBOOLE-0R4 Hf2(c,r)))"
sorry

theorem scheme1_sch_17:
  fixes Xf0 Yf0 Zf0 Ff2 Gf2 Pp2 Qp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Gf2(x1,x2) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies (Pp2(x,y) implies  not Qp2(x,y))" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y) implies Ff2(x,y) inHIDDENR3 Zf0" and
   A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Qp2(x,y) implies Gf2(x,y) inHIDDENR3 Zf0"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & (Pp2(x,y) or Qp2(x,y))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies (Pp2(x,y) implies f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 Ff2(x,y)) & (Qp2(x,y) implies f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 Gf2(x,y)))"
sorry

theorem scheme1_sch_18:
  fixes Xf0 Yf0 Zf0 Ff2 Gf2 Hf2 Pp2 Qp2 Rp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Gf2(x1,x2) be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Hf2(x1,x2) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies ((Pp2(x,y) implies  not Qp2(x,y)) & (Pp2(x,y) implies  not Rp2(x,y))) & (Qp2(x,y) implies  not Rp2(x,y))" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies (Pp2(x,y) implies Ff2(x,y) inHIDDENR3 Zf0)" and
   A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies (Qp2(x,y) implies Gf2(x,y) inHIDDENR3 Zf0)" and
   A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies (Rp2(x,y) implies Hf2(x,y) inHIDDENR3 Zf0)"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ((Pp2(x,y) or Qp2(x,y)) or Rp2(x,y))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies ((Pp2(x,y) implies f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 Ff2(x,y)) & (Qp2(x,y) implies f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 Gf2(x,y))) & (Rp2(x,y) implies f .FUNCT-1K1 [TARSKIK4 x,y ] =HIDDENR1 Hf2(x,y)))"
sorry

theorem scheme1_sch_19:
  fixes Cf0 Df0 Ff1 Gf1 Hf1 Pp1 Qp1 Rp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds ((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Rp1(c))" and
   A2: " for c be ElementSUBSET-1M1-of Cf0 holds (Pp1(c) or Qp1(c)) or Rp1(c)"
  shows " ex f be FunctionFUNCT-2M1-of(Cf0,Df0) st  for c be ElementSUBSET-1M1-of Cf0 holds ((Pp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 Gf1(c))) & (Rp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 Hf1(c))"
sorry

theorem scheme1_sch_20:
  fixes Cf0 Df0 Ff1 Gf1 Hf1 If1 Pp1 Qp1 Rp1 Sp1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Hf1(x1) be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> If1(x1) be ElementSUBSET-1M1-of Df0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds (((((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Pp1(c) implies  not Sp1(c))) & (Qp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Sp1(c))) & (Rp1(c) implies  not Sp1(c))" and
   A2: " for c be ElementSUBSET-1M1-of Cf0 holds ((Pp1(c) or Qp1(c)) or Rp1(c)) or Sp1(c)"
  shows " ex f be FunctionFUNCT-2M1-of(Cf0,Df0) st  for c be ElementSUBSET-1M1-of Cf0 holds (((Pp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 Ff1(c)) & (Qp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 Gf1(c))) & (Rp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 Hf1(c))) & (Sp1(c) implies f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> c =XBOOLE-0R4 If1(c))"
sorry

theorem scheme1_sch_21:
  fixes Cf0 Df0 Ef0 Ff2 Gf2 Pp2 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Ef0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Gf2(x1,x2) be ElementSUBSET-1M1-of Ef0"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Cf0,Df0 :],Ef0) st  for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,d ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f implies (Pp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Ff2(c,d)) & ( not Pp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Gf2(c,d))"
sorry

theorem scheme1_sch_22:
  fixes Cf0 Df0 Ef0 Ff2 Gf2 Hf2 Pp2 Qp2 Rp2 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Ef0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Gf2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Hf2(x1,x2) be ElementSUBSET-1M1-of Ef0" and
   A1: " for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds ((Pp2(c,d) implies  not Qp2(c,d)) & (Pp2(c,d) implies  not Rp2(c,d))) & (Qp2(c,d) implies  not Rp2(c,d))" and
   A2: " for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds (Pp2(c,d) or Qp2(c,d)) or Rp2(c,d)"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Cf0,Df0 :],Ef0) st ( for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,d ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f iff (Pp2(c,d) or Qp2(c,d)) or Rp2(c,d)) & ( for c be ElementSUBSET-1M1-of Cf0 holds  for d be ElementSUBSET-1M1-of Df0 holds [TARSKIK4 c,d ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Cf0,Df0 :])\<^esub> f implies ((Pp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Ff2(c,d)) & (Qp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Gf2(c,d))) & (Rp2(c,d) implies f .FUNCT-1K1 [TARSKIK4 c,d ] =XBOOLE-0R4 Hf2(c,d)))"
sorry

end
