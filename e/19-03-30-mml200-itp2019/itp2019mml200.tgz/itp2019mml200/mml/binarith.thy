theory binarith
  imports margrel1 setwop_2 series_1 nat_d trees_3 rfinseq
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem binarith_th_1:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for z be TupleFINSEQ-2M3-of(n,D) holds i inHIDDENR3 SegFINSEQ-1K2 n implies (z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 z /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
sorry

mtheorem binarith_th_2:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for z be TupleFINSEQ-2M3-of(n,D) holds (z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 d"
sorry

abbreviation(input) BINARITHK1(" _ ''or''BINARITHK1  _ " [170,170]170) where
  "x 'or'BINARITHK1 y \<equiv> x 'or'XBOOLEANK5 y"

mtheorem binarith_add_1:
  mlet "x be ElementSUBSET-1M1-of BOOLEANMARGREL1K5", "y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
"cluster x 'or'XBOOLEANK5 y as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "x 'or'XBOOLEANK5 y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
sorry
qed "sorry"

abbreviation(input) BINARITHK2(" _ ''xor''BINARITHK2  _ " [164,164]164) where
  "x 'xor'BINARITHK2 y \<equiv> x 'xor'XBOOLEANK10 y"

mtheorem binarith_add_2:
  mlet "x be ElementSUBSET-1M1-of BOOLEANMARGREL1K5", "y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
"cluster x 'xor'XBOOLEANK10 y as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "x 'xor'XBOOLEANK10 y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
sorry
qed "sorry"

reserve x, y, z for "booleanMARGREL1V2\<bar>objectHIDDENM1"
mtheorem binarith_th_3:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x 'or'XBOOLEANK5 (FALSEMARGREL1K6) =HIDDENR1 x"
   sorry

mtheorem binarith_th_4:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds 'not'MARGREL1K8 (x '&'MARGREL1K9 y) =HIDDENR1 'not'MARGREL1K8 x 'or'XBOOLEANK5 'not'MARGREL1K8 y"
   sorry

mtheorem binarith_th_5:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds 'not'MARGREL1K8 (x 'or'XBOOLEANK5 y) =HIDDENR1 'not'MARGREL1K8 x '&'MARGREL1K9 'not'MARGREL1K8 y"
   sorry

mtheorem binarith_th_6:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x '&'MARGREL1K9 y =HIDDENR1 'not'MARGREL1K8 ('not'MARGREL1K8 x 'or'XBOOLEANK5 'not'MARGREL1K8 y)"
   sorry

mtheorem binarith_th_7:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (TRUEMARGREL1K7)'xor'XBOOLEANK10 x =HIDDENR1 'not'MARGREL1K8 x"
   sorry

mtheorem binarith_th_8:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (FALSEMARGREL1K6)'xor'XBOOLEANK10 x =HIDDENR1 x"
   sorry

mtheorem binarith_th_9:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x '&'MARGREL1K9 x =HIDDENR1 x"
   sorry

mtheorem binarith_th_10:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x 'or'XBOOLEANK5 (TRUEMARGREL1K7) =HIDDENR1 TRUEMARGREL1K7"
   sorry

mtheorem binarith_th_11:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for z be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (x 'or'XBOOLEANK5 y)'or'XBOOLEANK5 z =HIDDENR1 x 'or'XBOOLEANK5 (y 'or'XBOOLEANK5 z)"
   sorry

mtheorem binarith_th_12:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x 'or'XBOOLEANK5 x =HIDDENR1 x"
   sorry

mtheorem binarith_th_13:
"(TRUEMARGREL1K7)'xor'BINARITHK2 (FALSEMARGREL1K6) =XBOOLE-0R4 TRUEMARGREL1K7"
   sorry

reserve i, j, k for "NatNAT-1M1"
reserve n for " non zeroORDINAL1V8\<bar>NatNAT-1M1"
reserve x, y, z1, z2 for "TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
mdef binarith_def_1 ("''not''BINARITHK3\<^bsub>'( _ ')\<^esub>  _ " [0,182]182 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func 'not'BINARITHK3\<^bsub>(n)\<^esub> x \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
sorry
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef binarith_def_2 ("carryBINARITHK4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func carryBINARITHK4\<^bsub>(n)\<^esub>(x,y) \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it. it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
sorry
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)) & (it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef binarith_def_3 ("BinaryBINARITHK5\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func BinaryBINARITHK5\<^bsub>(n)\<^esub> x \<rightarrow> TupleFINSEQ-2M3-of(n,NATNUMBERSK1) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) holds  for it2 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef binarith_def_4 ("AbsvalBINARITHK6\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func AbsvalBINARITHK6\<^bsub>(n)\<^esub> x \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (BinaryBINARITHK5\<^bsub>(n)\<^esub> x)"
proof-
  (*coherence*)
    show "(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (BinaryBINARITHK5\<^bsub>(n)\<^esub> x) be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef binarith_def_5 (" _ +BINARITHK7\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func x +BINARITHK7\<^bsub>(n)\<^esub> y \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
sorry
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef binarith_def_6 ("add-ovflBINARITHK8\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) \<rightarrow> ElementSUBSET-1M1-of BOOLEANMARGREL1K5 equals
  (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n 'or'BINARITHK1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'or'BINARITHK1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
proof-
  (*coherence*)
    show "(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n 'or'BINARITHK1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'or'BINARITHK1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
qed "sorry"

mdef binarith_def_7 ("'( _ , _ ')are-summableBINARITHR1\<^bsub>'( _ ')\<^esub>" [0,0,0]50 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"pred (z1,z2)are-summableBINARITHR1\<^bsub>(n)\<^esub> means
  add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6"..

mtheorem binarith_th_14:
" for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> or z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>"
sorry

mtheorem binarith_th_15:
" for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem binarith_th_16:
" for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =XBOOLE-0R4 \<one>\<^sub>M"
sorry

syntax BINARITHK9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^BINARITHK9\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "z1 ^BINARITHK9\<^bsub>(n1,n2,D)\<^esub> z2" \<rightharpoonup> "z1 ^FINSEQ-1K8 z2"

mtheorem binarith_add_3:
  mlet "n1 be NatNAT-1M1", "n2 be NatNAT-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "z1 be TupleFINSEQ-2M3-of(n1,D)", "z2 be TupleFINSEQ-2M3-of(n2,D)"
"cluster z1 ^FINSEQ-1K8 z2 as-term-is TupleFINSEQ-2M3-of(n1 +XCMPLX-0K2 n2,D)"
proof
(*coherence*)
  show "z1 ^FINSEQ-1K8 z2 be TupleFINSEQ-2M3-of(n1 +XCMPLX-0K2 n2,D)"
    using finseq_2_th_107 sorry
qed "sorry"

syntax BINARITHK10 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*BINARITHK10\<^bsub>'( _ ')\<^esub>  _ *>" [0,0]164)
translations "<*BINARITHK10\<^bsub>(D)\<^esub> d*>" \<rightharpoonup> "<*FINSEQ-1K6 d*>"

mtheorem binarith_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-1K6 d*> as-term-is TupleFINSEQ-2M3-of(\<one>\<^sub>M,D)"
proof
(*coherence*)
  show "<*FINSEQ-1K6 d*> be TupleFINSEQ-2M3-of(\<one>\<^sub>M,D)"
sorry
qed "sorry"

mtheorem binarith_th_17:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
sorry

mtheorem binarith_th_18:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem binarith_th_19:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =FINSEQ-1R1 (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>)"
sorry

mtheorem binarith_th_20:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
sorry

mtheorem binarith_th_21:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
sorry

mtheorem binarith_th_22:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (z1,z2)are-summableBINARITHR1\<^bsub>(n)\<^esub> implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
sorry

end
