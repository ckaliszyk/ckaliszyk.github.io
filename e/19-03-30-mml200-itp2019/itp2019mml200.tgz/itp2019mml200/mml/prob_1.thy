theory prob_1
  imports funct_7 card_3 seq_2 xxreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve Omega for "setHIDDENM2"
reserve X, Y, Z, p, x, y, z for "setHIDDENM2"
reserve D, E for "SubsetSUBSET-1M2-of Omega"
reserve f for "FunctionFUNCT-1M1"
reserve m, n for "NatNAT-1M1"
reserve r, r1 for "RealXREAL-0M1"
reserve seq for "Real-SequenceSEQ-1M1"
mtheorem prob_1_th_1:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 r) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 r"
sorry

mdef prob_1_def_1 ("compl-closedPROB-1V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr compl-closedPROB-1V1\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X means
  (\<lambda>IT.  for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 IT implies A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 IT)"..

mtheorem prob_1_cl_1:
  mlet "X be setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is cap-closedFINSUB-1V2"
proof
(*coherence*)
  show "boolSETFAM-1K9 X be cap-closedFINSUB-1V2"
sorry
qed "sorry"

mtheorem prob_1_cl_2:
  mlet "X be setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is compl-closedPROB-1V1\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show " for it be Subset-FamilySETFAM-1M1-of X holds it =HIDDENR1 boolSETFAM-1K9 X implies it be compl-closedPROB-1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem prob_1_cl_3:
  mlet "X be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>cap-closedFINSUB-1V2 for Subset-FamilySETFAM-1M1-of X"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of X st it be  non emptyXBOOLE-0V1\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>cap-closedFINSUB-1V2"
sorry
qed "sorry"

syntax PROB_1M1 :: " Set \<Rightarrow> Ty" ("Field-SubsetPROB-1M1-of  _ " [70]70)
translations "Field-SubsetPROB-1M1-of X" \<rightharpoonup> " non emptyXBOOLE-0V1\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>cap-closedFINSUB-1V2\<bar>Subset-FamilySETFAM-1M1-of X"

reserve F for "Field-SubsetPROB-1M1-of X"
mtheorem prob_1_th_2:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds {TARSKIK2 A,B } be Subset-FamilySETFAM-1M1-of X"
sorry

mtheorem prob_1_th_3:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 F & B inTARSKIR2 F implies A \\/XBOOLE-0K2 B inTARSKIR2 F"
sorry

mtheorem prob_1_th_4:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds {}XBOOLE-0K1 inTARSKIR2 F"
sorry

mtheorem prob_1_th_5:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds X inTARSKIR2 F"
sorry

mtheorem prob_1_th_6:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F & B inTARSKIR2 F implies A \\SUBSET-1K7\<^bsub>(X)\<^esub> B inTARSKIR2 F"
sorry

mtheorem prob_1_th_7:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A inTARSKIR2 F & B inTARSKIR2 F implies (A \\SUBSET-1K6 B)\\/XBOOLE-0K2 B inTARSKIR2 F"
sorry

mtheorem prob_1_cl_4:
  mlet "X be setHIDDENM2"
"cluster {TARSKIK2 {}XBOOLE-0K1,X } as-term-is cap-closedFINSUB-1V2"
proof
(*coherence*)
  show "{TARSKIK2 {}XBOOLE-0K1,X } be cap-closedFINSUB-1V2"
sorry
qed "sorry"

mtheorem prob_1_th_8:
" for X be setHIDDENM2 holds {TARSKIK2 {}XBOOLE-0K1,X } be Field-SubsetPROB-1M1-of X"
sorry

mtheorem prob_1_th_9:
" for X be setHIDDENM2 holds boolSETFAM-1K9 X be Field-SubsetPROB-1M1-of X"
   sorry

mtheorem prob_1_th_10:
" for X be setHIDDENM2 holds  for F be Field-SubsetPROB-1M1-of X holds {TARSKIK2 {}XBOOLE-0K1,X } c=TARSKIR1 F & F c=TARSKIR1 boolSETFAM-1K9 X"
sorry

abbreviation(input) PROB_1M2("SetSequencePROB-1M2-of  _ " [70]70) where
  "SetSequencePROB-1M2-of X \<equiv> sequenceNAT-1M2-of boolSETFAM-1K9 X"

reserve ASeq, BSeq for "SetSequencePROB-1M2-of Omega"
reserve A1 for "SetSequencePROB-1M2-of X"
mtheorem prob_1_th_11:
" for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds unionTARSKIK3 (rngFUNCT-1K2 A1) be SubsetSUBSET-1M2-of X"
sorry

syntax PROB_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("UnionPROB-1K1\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "UnionPROB-1K1\<^bsub>(X)\<^esub> A1" \<rightharpoonup> "UnionCARD-3K3 A1"

mtheorem prob_1_add_1:
  mlet "X be setHIDDENM2", "A1 be SetSequencePROB-1M2-of X"
"cluster UnionCARD-3K3 A1 as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "UnionCARD-3K3 A1 be SubsetSUBSET-1M2-of X"
    using prob_1_th_11 sorry
qed "sorry"

mtheorem prob_1_th_12:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds x inTARSKIR2 UnionPROB-1K1\<^bsub>(X)\<^esub> A1 iff ( ex n be NatNAT-1M1 st x inTARSKIR2 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
sorry

mdef prob_1_def_2 ("ComplementPROB-1K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "A1 be SetSequencePROB-1M2-of X"
"func ComplementPROB-1K2\<^bsub>(X)\<^esub> A1 \<rightarrow> SetSequencePROB-1M2-of X means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
proof-
  (*existence*)
    show " ex it be SetSequencePROB-1M2-of X st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>"
sorry
  (*uniqueness*)
    show " for it1 be SetSequencePROB-1M2-of X holds  for it2 be SetSequencePROB-1M2-of X holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n =XBOOLE-0R4 (A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)`SUBSET-1K3\<^bsub>(X)\<^esub>) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem PROB_1K2_involutiveness:
  mlet "X be setHIDDENM2"
" for A1 be SetSequencePROB-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1) =HIDDENR1 A1"
sorry

mdef prob_1_def_3 ("IntersectionPROB-1K3\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "A1 be SetSequencePROB-1M2-of X"
"func IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 \<rightarrow> SubsetSUBSET-1M2-of X equals
  (UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1))`SUBSET-1K3\<^bsub>(X)\<^esub>"
proof-
  (*coherence*)
    show "(UnionPROB-1K1\<^bsub>(X)\<^esub> (ComplementPROB-1K2\<^bsub>(X)\<^esub> A1))`SUBSET-1K3\<^bsub>(X)\<^esub> be SubsetSUBSET-1M2-of X"
       sorry
qed "sorry"

mtheorem prob_1_th_13:
" for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 iff ( for n be NatNAT-1M1 holds x inHIDDENR3 A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n)"
sorry

mlemma prob_1_lm_1:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
sorry

mtheorem prob_1_th_14:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds IntersectionPROB-1K3\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B"
sorry

mdef prob_1_def_4 ("non-ascendingPROB-1V2" 70 ) where
"attr non-ascendingPROB-1V2 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f .FUNCT-1K1 m c=TARSKIR1 f .FUNCT-1K1 n)"..

mdef prob_1_def_5 ("non-descendingPROB-1V3" 70 ) where
"attr non-descendingPROB-1V3 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies f .FUNCT-1K1 n c=TARSKIR1 f .FUNCT-1K1 m)"..

mdef prob_1_def_6 ("sigma-multiplicativePROB-1V4\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X means
  (\<lambda>F.  for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 F implies IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 inTARSKIR2 F)"..

mtheorem prob_1_cl_5:
  mlet "X be setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show " for it be Subset-FamilySETFAM-1M1-of X holds it =HIDDENR1 boolSETFAM-1K9 X implies it be sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem prob_1_cl_6:
  mlet "X be setHIDDENM2"
"cluster compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>\<bar> non emptyXBOOLE-0V1 for Subset-FamilySETFAM-1M1-of X"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of X st it be compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>\<bar> non emptyXBOOLE-0V1"
sorry
qed "sorry"

syntax PROB_1M3 :: " Set \<Rightarrow> Ty" ("SigmaFieldPROB-1M3-of  _ " [70]70)
translations "SigmaFieldPROB-1M3-of X" \<rightharpoonup> "compl-closedPROB-1V1\<^bsub>(X)\<^esub>\<bar>sigma-multiplicativePROB-1V4\<^bsub>(X)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"

mtheorem prob_1_th_15:
" for X be setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S be SigmaFieldPROB-1M3-of X iff (S c=TARSKIR1 boolSETFAM-1K9 X & ( for A1 be SetSequencePROB-1M2-of X holds rngFUNCT-1K2 A1 c=TARSKIR1 S implies IntersectionPROB-1K3\<^bsub>(X)\<^esub> A1 inTARSKIR2 S)) & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 S implies A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S)"
  using prob_1_def_1 prob_1_def_6 sorry

mtheorem prob_1_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y be SigmaFieldPROB-1M3-of X implies Y be Field-SubsetPROB-1M1-of X"
sorry

mtheorem prob_1_cl_7:
  mlet "X be setHIDDENM2"
"cluster note-that cap-closedFINSUB-1V2\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub> for SigmaFieldPROB-1M3-of X"
proof
(*coherence*)
  show " for it be SigmaFieldPROB-1M3-of X holds it be cap-closedFINSUB-1V2\<bar>compl-closedPROB-1V1\<^bsub>(X)\<^esub>"
    using prob_1_th_16 sorry
qed "sorry"

reserve Sigma for "SigmaFieldPROB-1M3-of Omega"
reserve Si for "SigmaFieldPROB-1M3-of X"
mtheorem prob_1_cl_8:
  mlet "X be setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"cluster F -valuedRELAT-1V5 for SetSequencePROB-1M2-of X"
proof
(*existence*)
  show " ex it be SetSequencePROB-1M2-of X st it be F -valuedRELAT-1V5"
sorry
qed "sorry"

abbreviation(input) PROB_1M4("SetSequencePROB-1M4\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70) where
  "SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of F \<equiv> F -valuedRELAT-1V5\<bar>SetSequencePROB-1M2-of X"

mtheorem prob_1_th_17:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for ASeq be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si holds UnionPROB-1K1\<^bsub>(X)\<^esub> ASeq inTARSKIR2 Si"
sorry

abbreviation(input) PROB_1M5("EventPROB-1M5-of  _ " [70]70) where
  "EventPROB-1M5-of F \<equiv> ElementSUBSET-1M1-of F"

syntax PROB_1M6 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("EventPROB-1M6\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "EventPROB-1M6\<^bsub>(X)\<^esub>-of F" \<rightharpoonup> "ElementSUBSET-1M1-of F"

mtheorem prob_1_add_2:
  mlet "X be setHIDDENM2", "F be SigmaFieldPROB-1M3-of X"
"cluster note-that SubsetSUBSET-1M2-of X for ElementSUBSET-1M1-of F"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of F holds it be SubsetSUBSET-1M2-of X"
sorry
qed "sorry"

mtheorem prob_1_th_18:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds x inTARSKIR2 Si implies x be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
   sorry

mtheorem prob_1_th_19:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  for B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A /\\SUBSET-1K9\<^bsub>(X)\<^esub> B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using finsub_1_def_2 sorry

mtheorem prob_1_th_20:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A `SUBSET-1K3\<^bsub>(X)\<^esub> be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_def_1 sorry

mtheorem prob_1_th_21:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  for B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A \\/SUBSET-1K4\<^bsub>(X)\<^esub> B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_3 sorry

mtheorem prob_1_th_22:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds {}XBOOLE-0K1 be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_4 sorry

mtheorem prob_1_th_23:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds X be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_5 sorry

mtheorem prob_1_th_24:
" for X be setHIDDENM2 holds  for Si be SigmaFieldPROB-1M3-of X holds  for A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds  for B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si holds A \\SUBSET-1K7\<^bsub>(X)\<^esub> B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
  using prob_1_th_6 sorry

mtheorem prob_1_cl_9:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X"
"cluster emptyXBOOLE-0V1 for EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*existence*)
  show " ex it be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si st it be emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef prob_1_def_7 ("[#]PROB-1K4\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X"
"func [#]PROB-1K4\<^bsub>(X)\<^esub> Si \<rightarrow> EventPROB-1M6\<^bsub>(X)\<^esub>-of Si equals
  X"
proof-
  (*coherence*)
    show "X be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
      using prob_1_th_5 sorry
qed "sorry"

syntax PROB_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\PROB-1K5\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "A /\\PROB-1K5\<^bsub>(X,Si)\<^esub> B" \<rightharpoonup> "A /\\XBOOLE-0K3 B"

mtheorem prob_1_add_3:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X", "A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si", "B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
"cluster A /\\XBOOLE-0K3 B as-term-is EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    using finsub_1_def_2 sorry
qed "sorry"

syntax PROB_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/PROB-1K6\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "A \\/PROB-1K6\<^bsub>(X,Si)\<^esub> B" \<rightharpoonup> "A \\/XBOOLE-0K2 B"

mtheorem prob_1_add_4:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X", "A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si", "B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
"cluster A \\/XBOOLE-0K2 B as-term-is EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*coherence*)
  show "A \\/XBOOLE-0K2 B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    using prob_1_th_3 sorry
qed "sorry"

syntax PROB_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\PROB-1K7\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "A \\PROB-1K7\<^bsub>(X,Si)\<^esub> B" \<rightharpoonup> "A \\XBOOLE-0K4 B"

mtheorem prob_1_add_5:
  mlet "X be setHIDDENM2", "Si be SigmaFieldPROB-1M3-of X", "A be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si", "B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
"cluster A \\XBOOLE-0K4 B as-term-is EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
proof
(*coherence*)
  show "A \\XBOOLE-0K4 B be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si"
    using prob_1_th_6 sorry
qed "sorry"

mtheorem prob_1_th_25:
" for X be setHIDDENM2 holds  for A1 be SetSequencePROB-1M2-of X holds  for Si be SigmaFieldPROB-1M3-of X holds A1 be SetSequencePROB-1M4\<^bsub>(X)\<^esub>-of Si iff ( for n be NatNAT-1M1 holds A1 .NAT-1K8\<^bsub>(boolSETFAM-1K9 X)\<^esub> n be EventPROB-1M6\<^bsub>(X)\<^esub>-of Si)"
sorry

mtheorem prob_1_th_26:
" for Omega be setHIDDENM2 holds  for ASeq be SetSequencePROB-1M2-of Omega holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma implies UnionPROB-1K1\<^bsub>(Omega)\<^esub> ASeq be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
  using prob_1_th_17 sorry

reserve ASeq for "SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
mtheorem prob_1_th_27:
" for Omega be setHIDDENM2 holds  for p be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Sigma & ( for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies f .FUNCT-1K1 D =XBOOLE-0R4 0NUMBERSK6))"
sorry

reserve P for "FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
mtheorem prob_1_th_28:
" for Omega be setHIDDENM2 holds  for p be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  ex P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st  for D be SubsetSUBSET-1M2-of Omega holds D inTARSKIR2 Sigma implies (p inTARSKIR2 D implies P .FUNCT-1K1 D =COMPLEX1R1 \<one>\<^sub>M) & ( not p inTARSKIR2 D implies P .FUNCT-1K1 D =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem prob_1_th_29:
" for Omega be setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) holds P *FUNCT-1K3 ASeq be Real-SequenceSEQ-1M1"
sorry

syntax PROB_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *PROB-1K8\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "P *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq" \<rightharpoonup> "ASeq *RELAT-1K6 P"

mtheorem prob_1_add_6:
  mlet "Omega be setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega", "ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma", "P be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
"cluster ASeq *RELAT-1K6 P as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "ASeq *RELAT-1K6 P be Real-SequenceSEQ-1M1"
    using prob_1_th_29 sorry
qed "sorry"

reserve Omega for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Sigma for "SigmaFieldPROB-1M3-of Omega"
reserve A, B for "EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma"
reserve ASeq for "SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma"
reserve P for "FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2)"
reserve D, E for "SubsetSUBSET-1M2-of Omega"
reserve BSeq for "SetSequencePROB-1M2-of Omega"
mdef prob_1_def_8 ("ProbabilityPROB-1M7\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega"
"mode ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma \<rightarrow> FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) means
  (\<lambda>it. ((( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & it .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M) & ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 implies it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 it .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq)))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(Sigma,REALNUMBERSK2) st ((( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds 0NUMBERSK6 <=XXREAL-0R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A) & it .FUNCT-1K1 Omega =COMPLEX1R1 \<one>\<^sub>M) & ( for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds A missesXBOOLE-0R1 B implies it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 it .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)) & ( for ASeq be SetSequencePROB-1M4\<^bsub>(Omega)\<^esub>-of Sigma holds ASeq be non-ascendingPROB-1V2 implies it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq be convergentSEQ-2V5 & limSEQ-2K1 (it *PROB-1K8\<^bsub>(Omega,Sigma)\<^esub> ASeq) =COMPLEX1R1 it .FUNCT-1K1 (IntersectionPROB-1K3\<^bsub>(Omega)\<^esub> ASeq))"
sorry
qed "sorry"

reserve P for "ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
mtheorem prob_1_cl_10:
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Sigma be SigmaFieldPROB-1M3-of Omega"
"cluster note-that zeroedVALUED-0V14 for ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma"
proof
(*coherence*)
  show " for it be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds it be zeroedVALUED-0V14"
sorry
qed "sorry"

mtheorem prob_1_th_30:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> [#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma =COMPLEX1R1 \<one>\<^sub>M"
  using prob_1_def_8 sorry

mtheorem prob_1_th_31:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem prob_1_th_32:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> ([#]PROB-1K4\<^bsub>(Omega)\<^esub> Sigma \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
sorry

mtheorem prob_1_th_33:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds A c=TARSKIR1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B -REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A"
sorry

mtheorem prob_1_th_34:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds A c=TARSKIR1 B implies P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
sorry

mtheorem prob_1_th_35:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem prob_1_th_36:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A)"
sorry

mtheorem prob_1_th_37:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (B \\PROB-1K7\<^bsub>(Omega,Sigma)\<^esub> A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
sorry

mtheorem prob_1_th_38:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) =COMPLEX1R1 (P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B)-REAL-1K5 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A /\\PROB-1K5\<^bsub>(Omega,Sigma)\<^esub> B)"
sorry

mtheorem prob_1_th_39:
" for Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Sigma be SigmaFieldPROB-1M3-of Omega holds  for A be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for B be EventPROB-1M6\<^bsub>(Omega)\<^esub>-of Sigma holds  for P be ProbabilityPROB-1M7\<^bsub>(Omega)\<^esub>-of Sigma holds P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> (A \\/PROB-1K6\<^bsub>(Omega,Sigma)\<^esub> B) <=XXREAL-0R1 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> A +REAL-1K3 P .FUNCT-2K3\<^bsub>(Sigma,REALNUMBERSK2)\<^esub> B"
sorry

reserve S for "Subset-FamilySETFAM-1M1-of Omega"
mtheorem prob_1_th_40:
" for X be setHIDDENM2 holds boolSETFAM-1K9 X be SigmaFieldPROB-1M3-of X"
   sorry

mdef prob_1_def_9 ("sigmaPROB-1K9\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "Omega be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be Subset-FamilySETFAM-1M1-of Omega"
"func sigmaPROB-1K9\<^bsub>(Omega)\<^esub> X \<rightarrow> SigmaFieldPROB-1M3-of Omega means
  \<lambda>it. X c=TARSKIR1 it & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it c=TARSKIR1 Z)"
proof-
  (*existence*)
    show " ex it be SigmaFieldPROB-1M3-of Omega st X c=TARSKIR1 it & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it c=TARSKIR1 Z)"
sorry
  (*uniqueness*)
    show " for it1 be SigmaFieldPROB-1M3-of Omega holds  for it2 be SigmaFieldPROB-1M3-of Omega holds (X c=TARSKIR1 it1 & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it1 c=TARSKIR1 Z)) & (X c=TARSKIR1 it2 & ( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be SigmaFieldPROB-1M3-of Omega implies it2 c=TARSKIR1 Z)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef prob_1_def_10 ("halflinePROB-1K10  _ " [164]164 ) where
  mlet "r be ExtRealXXREAL-0M1"
"func halflinePROB-1K10 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  ].XXREAL-1K4 -inftyXXREAL-0K2,r .["
proof-
  (*coherence*)
    show "].XXREAL-1K4 -inftyXXREAL-0K2,r .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mdef prob_1_def_11 ("Family-of-halflinesPROB-1K11" 164 ) where
"func Family-of-halflinesPROB-1K11 \<rightarrow> Subset-FamilySETFAM-1M1-of REALNUMBERSK2 equals
  {halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  }"
proof-
  (*coherence*)
    show "{halflinePROB-1K10 r where r be ElementSUBSET-1M1-of REALNUMBERSK2 :  True  } be Subset-FamilySETFAM-1M1-of REALNUMBERSK2"
sorry
qed "sorry"

mdef prob_1_def_12 ("Borel-SetsPROB-1K12" 164 ) where
"func Borel-SetsPROB-1K12 \<rightarrow> SigmaFieldPROB-1M3-of REALNUMBERSK2 equals
  sigmaPROB-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (Family-of-halflinesPROB-1K11)"
proof-
  (*coherence*)
    show "sigmaPROB-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (Family-of-halflinesPROB-1K11) be SigmaFieldPROB-1M3-of REALNUMBERSK2"
       sorry
qed "sorry"

mtheorem prob_1_th_41:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of X holds ComplementPROB-1K2\<^bsub>(X)\<^esub> (A followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,boolZFMISC-1K1 X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> followed-byFUNCT-7K11\<^bsub>(boolZFMISC-1K1 X)\<^esub> B `SUBSET-1K3\<^bsub>(X)\<^esub>"
  using prob_1_lm_1 sorry

syntax PROB_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .PROB-1K13\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [200,0,0,0,200]200)
translations "F .PROB-1K13\<^bsub>(X,Y,A)\<^esub> x" \<rightharpoonup> "F .FUNCT-1K1 x"

mtheorem prob_1_add_7:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "A be Subset-FamilySETFAM-1M1-of X", "F be FunctionFUNCT-2M1-of(Y,boolSETFAM-1K9 A)", "x be setHIDDENM2"
"cluster F .FUNCT-1K1 x as-term-is Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show "F .FUNCT-1K1 x be Subset-FamilySETFAM-1M1-of X"
sorry
qed "sorry"

end
