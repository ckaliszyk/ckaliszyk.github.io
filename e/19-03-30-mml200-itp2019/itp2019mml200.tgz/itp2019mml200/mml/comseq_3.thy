theory comseq_3
  imports series_1 comseq_1 funct_3 arytm_0
   "../mizar_extension/E_number"
begin
(*begin*)
reserve rseq, rseq1, rseq2 for "Real-SequenceSEQ-1M1"
reserve seq, seq1, seq2 for "Complex-SequenceCOMSEQ-1M1"
reserve k, n, n1, n2, m for "NatNAT-1M1"
reserve p, r for "RealXREAL-0M1"
mlemma comseq_3_lm_1:
"0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
   sorry

mtheorem comseq_3_th_1:
" for n be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0cCOMPLEX1K6 & (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8) <>HIDDENR2 0cCOMPLEX1K6"
   sorry

mtheorem comseq_3_th_2:
" for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies ( for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem comseq_3_th_3:
" for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies rseq be absolutely-summableSERIES-1V2"
sorry

mlemma comseq_3_lm_2:
" for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
  using seq_1_th_57 sorry

mtheorem comseq_3_cl_1:
"cluster summableSERIES-1V1 also-is convergentCOMSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be summableSERIES-1V1 implies it be convergentCOMSEQ-2V3"
    using series_1_th_4 sorry
qed "sorry"

mtheorem comseq_3_cl_2:
"cluster absolutely-summableSERIES-1V2 also-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be absolutely-summableSERIES-1V2 implies it be summableSERIES-1V1"
     sorry
qed "sorry"

mtheorem comseq_3_cl_3:
"cluster absolutely-summableSERIES-1V2 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be absolutely-summableSERIES-1V2"
    using comseq_3_lm_2 comseq_3_th_3 sorry
qed "sorry"

mtheorem comseq_3_th_4:
" for rseq be Real-SequenceSEQ-1M1 holds rseq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n <=XXREAL-0R1 m & n <=XXREAL-0R1 l implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p))"
sorry

mtheorem comseq_3_th_5:
" for rseq be Real-SequenceSEQ-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p) implies ( for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 l)"
sorry

mtheorem comseq_3_th_6:
" for rseq be Real-SequenceSEQ-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem comseq_3_th_7:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds  for m be NatNAT-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
sorry

mtheorem comseq_3_th_8:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds  for m be NatNAT-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n +XCMPLX-0K2 l <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mtheorem comseq_3_th_9:
" for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem comseq_3_th_10:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds (seq1 be convergentCOMSEQ-2V3 & seq2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 0cCOMPLEX1K6 implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq2"
sorry

(*begin*)
reserve z for "ComplexXCMPLX-0M1"
reserve Nseq, Nseq1 for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mlemma comseq_3_lm_3:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mdef comseq_3_def_1 (" _ GeoSeqCOMSEQ-3K1" [220]220 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z GeoSeqCOMSEQ-3K1 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)) & (it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

abbreviation(input) COMSEQ_3K2(" _  |^COMSEQ-3K2  _ " [190,190]190) where
  "z  |^COMSEQ-3K2 n \<equiv> z  |^NEWTONK1 n"

mtheorem comseq_3_def_2:
  mlet "z be ComplexXCMPLX-0M1", "n be NatNAT-1M1"
"redefine func z  |^COMSEQ-3K2 n \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z  |^COMSEQ-3K2 n iff it =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
sorry
qed "sorry"

mtheorem comseq_3_add_1:
  mlet "z be ComplexXCMPLX-0M1", "n be NatNAT-1M1"
"cluster z  |^NEWTONK1 n as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z  |^NEWTONK1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem comseq_3_th_11:
" for z be ComplexXCMPLX-0M1 holds z  |^COMSEQ-3K2 (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7"
  using complex1_def_4 newton_th_4 sorry

mdef comseq_3_def_3 ("ReCOMSEQ-3K3  _ " [228]228 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func ReCOMSEQ-3K3 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef comseq_3_def_4 ("ImCOMSEQ-3K4  _ " [228]228 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func ImCOMSEQ-3K4 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem comseq_3_cl_4:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster ReCOMSEQ-3K3 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "ReCOMSEQ-3K3 f be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem comseq_3_cl_5:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster ImCOMSEQ-3K4 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "ImCOMSEQ-3K4 f be real-valuedVALUED-0V7"
sorry
qed "sorry"

syntax COMSEQ_3K5 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("ReCOMSEQ-3K5\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "ReCOMSEQ-3K5\<^bsub>(X)\<^esub> f" \<rightharpoonup> "ReCOMSEQ-3K3 f"

mtheorem comseq_3_add_2:
  mlet "X be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,COMPLEXNUMBERSK3)"
"cluster ReCOMSEQ-3K3 f as-term-is PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
proof
(*coherence*)
  show "ReCOMSEQ-3K3 f be PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
sorry
qed "sorry"

syntax COMSEQ_3K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("ImCOMSEQ-3K6\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "ImCOMSEQ-3K6\<^bsub>(X)\<^esub> f" \<rightharpoonup> "ImCOMSEQ-3K4 f"

mtheorem comseq_3_add_3:
  mlet "X be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,COMPLEXNUMBERSK3)"
"cluster ImCOMSEQ-3K4 f as-term-is PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
proof
(*coherence*)
  show "ImCOMSEQ-3K4 f be PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
sorry
qed "sorry"

abbreviation(input) COMSEQ_3K7("ReCOMSEQ-3K7  _ " [228]228) where
  "ReCOMSEQ-3K7 c \<equiv> ReCOMSEQ-3K3 c"

mtheorem comseq_3_def_5:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"redefine func ReCOMSEQ-3K7 c \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
proof
(*compatibility*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ReCOMSEQ-3K7 c iff ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
sorry
qed "sorry"

mtheorem comseq_3_add_4:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"cluster ReCOMSEQ-3K3 c as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "ReCOMSEQ-3K3 c be Real-SequenceSEQ-1M1"
sorry
qed "sorry"

abbreviation(input) COMSEQ_3K8("ImCOMSEQ-3K8  _ " [228]228) where
  "ImCOMSEQ-3K8 c \<equiv> ImCOMSEQ-3K4 c"

mtheorem comseq_3_def_6:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"redefine func ImCOMSEQ-3K8 c \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
proof
(*compatibility*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ImCOMSEQ-3K8 c iff ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
sorry
qed "sorry"

mtheorem comseq_3_add_5:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"cluster ImCOMSEQ-3K4 c as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "ImCOMSEQ-3K4 c be Real-SequenceSEQ-1M1"
sorry
qed "sorry"

mtheorem comseq_3_th_12:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 z.| +XCMPLX-0K2  |.COMPLEX1K10 ImCOMPLEX1K4 z.|"
sorry

mtheorem comseq_3_th_13:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 ReCOMPLEX1K3 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 ImCOMPLEX1K4 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.|"
sorry

mtheorem comseq_3_th_14:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 & ImCOMSEQ-3K8 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
sorry

mtheorem comseq_3_th_15:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) & ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
sorry

mtheorem comseq_3_th_16:
" for seq be Complex-SequenceCOMSEQ-1M1 holds -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) & -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
sorry

mtheorem comseq_3_th_17:
" for r be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds r *XCMPLX-0K3 ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (r *XCMPLX-0K3 z) & r *XCMPLX-0K3 ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (r *XCMPLX-0K3 z)"
sorry

mtheorem comseq_3_th_18:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) & ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
sorry

mtheorem comseq_3_th_19:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
sorry

mtheorem comseq_3_th_20:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq & ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq"
sorry

mtheorem comseq_3_th_21:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 & ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2"
sorry

abbreviation(input) COMSEQ_3K9(" _ *COMSEQ-3K9  _ " [164,164]164) where
  "seq *COMSEQ-3K9 Nseq \<equiv> Nseq (#)RELAT-1K5 seq"

mtheorem comseq_3_add_6:
  mlet "Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1", "seq be Complex-SequenceCOMSEQ-1M1"
"cluster Nseq (#)RELAT-1K5 seq as-term-is Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show "Nseq (#)RELAT-1K5 seq be Complex-SequenceCOMSEQ-1M1"
sorry
qed "sorry"

mtheorem comseq_3_th_22:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq & ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
sorry

mtheorem comseq_3_th_23:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
sorry

abbreviation(input) COMSEQ_3K10("Partial-SumsCOMSEQ-3K10  _ " [350]350) where
  "Partial-SumsCOMSEQ-3K10 s \<equiv> Partial-SumsSERIES-1K2 s"

mtheorem comseq_3_add_7:
  mlet "s be Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsSERIES-1K2 s as-term-is Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show "Partial-SumsSERIES-1K2 s be Complex-SequenceCOMSEQ-1M1"
sorry
qed "sorry"

mdef comseq_3_def_7 ("SumCOMSEQ-3K11  _ " [260]260 ) where
  mlet "seq be Complex-SequenceCOMSEQ-1M1"
"func SumCOMSEQ-3K11 seq \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq"
proof-
  (*coherence*)
    show "limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem comseq_3_th_24:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies ( for m be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 0cCOMPLEX1K6)"
sorry

mtheorem comseq_3_th_25:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies ( for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem comseq_3_th_26:
" for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq"
sorry

mtheorem comseq_3_th_27:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
  using series_1_th_5 sorry

mtheorem comseq_3_th_28:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
sorry

mtheorem comseq_3_th_29:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq"
sorry

mtheorem comseq_3_th_30:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
sorry

mtheorem comseq_3_th_31:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
sorry

mtheorem comseq_3_th_32:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
sorry

mtheorem comseq_3_th_33:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)) implies Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1"
sorry

mtheorem comseq_3_th_34:
" for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be non-decreasingVALUED-0V11"
sorry

mtheorem comseq_3_cl_6:
  mlet "seq be Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) as-term-is non-decreasingVALUED-0V11 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) implies it be non-decreasingVALUED-0V11"
    using comseq_3_th_34 sorry
qed "sorry"

mtheorem comseq_3_th_35:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for m be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
sorry

mtheorem comseq_3_th_36:
" for z be ComplexXCMPLX-0M1 holds 1rCOMPLEX1K7 <>HIDDENR2 z implies ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
sorry

mtheorem comseq_3_th_37:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)))"
sorry

(*begin*)
mtheorem comseq_3_th_38:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies (a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3 iff c be convergentCOMSEQ-2V3)"
sorry

mtheorem comseq_3_th_39:
" for a be convergentCOMSEQ-2V3\<bar>Real-SequenceSEQ-1M1 holds  for b be convergentCOMSEQ-2V3\<bar>Real-SequenceSEQ-1M1 holds  for c be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies c be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 c =COMPLEX1R1 limSEQ-2K1 a +XCMPLX-0K2 (limSEQ-2K1 b)*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem comseq_3_th_40:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3) & limSEQ-2K1 a =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)) & limSEQ-2K1 b =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
sorry

mtheorem comseq_3_th_41:
" for c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds ((ReCOMSEQ-3K7 c be convergentCOMSEQ-2V3 & ImCOMSEQ-3K8 c be convergentCOMSEQ-2V3) & limSEQ-2K1 ReCOMSEQ-3K7 c =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)) & limSEQ-2K1 ImCOMSEQ-3K8 c =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
sorry

mtheorem comseq_3_cl_7:
  mlet "c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ReCOMSEQ-3K7 c as-term-is convergentCOMSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ReCOMSEQ-3K7 c implies it be convergentCOMSEQ-2V3"
    using comseq_3_th_41 sorry
qed "sorry"

mtheorem comseq_3_cl_8:
  mlet "c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ImCOMSEQ-3K8 c as-term-is convergentCOMSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ImCOMSEQ-3K8 c implies it be convergentCOMSEQ-2V3"
    using comseq_3_th_41 sorry
qed "sorry"

mtheorem comseq_3_th_42:
" for c be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 c be convergentCOMSEQ-2V3 & ImCOMSEQ-3K8 c be convergentCOMSEQ-2V3 implies (c be convergentCOMSEQ-2V3 & ReCOMPLEX1K3 (limCOMSEQ-2K3 c) =COMPLEX1R1 limSEQ-2K1 ReCOMSEQ-3K7 c) & ImCOMPLEX1K4 (limCOMSEQ-2K3 c) =COMPLEX1R1 limSEQ-2K1 ImCOMSEQ-3K8 c"
sorry

mtheorem comseq_3_th_43:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M) & seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 z) & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
sorry

mtheorem comseq_3_th_44:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
sorry

mtheorem comseq_3_th_45:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| >=XXREAL-0R2 r) implies  not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be convergentCOMSEQ-2V3 or limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem comseq_3_th_46:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 iff ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))"
sorry

mtheorem comseq_3_th_47:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n <=XXREAL-0R1 m & n <=XXREAL-0R1 l implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l .| <XXREAL-0R3 p))"
sorry

mtheorem comseq_3_th_48:
" for rseq be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & rseq be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq =COMPLEX1R1 0NUMBERSK6 implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
sorry

(*begin*)
mtheorem comseq_3_th_49:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq1 implies ReCOMSEQ-3K7 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ReCOMSEQ-3K7 seq1 & ImCOMSEQ-3K8 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ImCOMSEQ-3K8 seq1"
sorry

mtheorem comseq_3_th_50:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be boundedCOMSEQ-2V2 implies ( ex seq1 be Complex-SequenceCOMSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be convergentCOMSEQ-2V3)"
sorry

mdef comseq_3_def_8 ("summableCOMSEQ-3V1" 70 ) where
"attr summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1 means
  (\<lambda>seq. Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3)"..

mtheorem comseq_3_cl_9:
"cluster summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be summableCOMSEQ-3V1"
sorry
qed "sorry"

mtheorem comseq_3_cl_10:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsCOMSEQ-3K10 seq as-term-is convergentCOMSEQ-2V3 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq implies it be convergentCOMSEQ-2V3"
    using comseq_3_def_8 sorry
qed "sorry"

mdef comseq_3_def_9 ("absolutely-summableCOMSEQ-3V2" 70 ) where
"attr absolutely-summableCOMSEQ-3V2 for Complex-SequenceCOMSEQ-1M1 means
  (\<lambda>seq.  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1)"..

mtheorem comseq_3_th_51:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies seq be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem comseq_3_cl_11:
"cluster absolutely-summableCOMSEQ-3V2 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be absolutely-summableCOMSEQ-3V2"
sorry
qed "sorry"

mtheorem comseq_3_cl_12:
  mlet "seq be absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| as-term-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| implies it be summableSERIES-1V1"
    using comseq_3_def_9 sorry
qed "sorry"

mtheorem comseq_3_th_52:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
sorry

mtheorem comseq_3_cl_13:
"cluster summableCOMSEQ-3V1 also-is convergentCOMSEQ-2V3 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it be summableCOMSEQ-3V1 implies it be convergentCOMSEQ-2V3"
    using comseq_3_th_52 sorry
qed "sorry"

mtheorem comseq_3_th_53:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies (ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1) & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem comseq_3_cl_14:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ReCOMSEQ-3K7 seq as-term-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ReCOMSEQ-3K7 seq implies it be summableSERIES-1V1"
    using comseq_3_th_53 sorry
qed "sorry"

mtheorem comseq_3_cl_15:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ImCOMSEQ-3K8 seq as-term-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ImCOMSEQ-3K8 seq implies it be summableSERIES-1V1"
    using comseq_3_th_53 sorry
qed "sorry"

mtheorem comseq_3_th_54:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1 implies seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 +XCMPLX-0K2 SumCOMSEQ-3K11 seq2"
sorry

mtheorem comseq_3_th_55:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1 implies seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 -XCMPLX-0K6 SumCOMSEQ-3K11 seq2"
sorry

mtheorem comseq_3_cl_16:
  mlet "seq1 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1", "seq2 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 implies it be summableCOMSEQ-3V1"
    using comseq_3_th_54 sorry
qed "sorry"

mtheorem comseq_3_cl_17:
  mlet "seq1 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1", "seq2 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 implies it be summableCOMSEQ-3V1"
    using comseq_3_th_55 sorry
qed "sorry"

mtheorem comseq_3_th_56:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for z be ComplexXCMPLX-0M1 holds z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =COMPLEX1R1 z *XCMPLX-0K3 SumCOMSEQ-3K11 seq)"
sorry

mtheorem comseq_3_cl_18:
  mlet "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3", "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq implies it be summableCOMSEQ-3V1"
    using comseq_3_th_56 sorry
qed "sorry"

mtheorem comseq_3_th_57:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1 implies seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem comseq_3_th_58:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for n be NatNAT-1M1 holds seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1)"
sorry

mtheorem comseq_3_cl_19:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1", "n be NatNAT-1M1"
"cluster seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies it be summableCOMSEQ-3V1"
    using comseq_3_th_58 sorry
qed "sorry"

mtheorem comseq_3_th_59:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( ex n be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1) implies seq be summableCOMSEQ-3V1"
sorry

mtheorem comseq_3_th_60:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for n be NatNAT-1M1 holds SumCOMSEQ-3K11 seq =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

mtheorem comseq_3_th_61:
" for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3 iff seq be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem comseq_3_cl_20:
  mlet "seq be absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) as-term-is bounded-aboveSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) implies it be bounded-aboveSEQ-2V3"
    using comseq_3_th_61 sorry
qed "sorry"

mtheorem comseq_3_th_62:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 iff ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))"
  using comseq_3_th_46 sorry

mtheorem comseq_3_th_63:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be absolutely-summableCOMSEQ-3V2 implies seq be summableCOMSEQ-3V1"
sorry

mtheorem comseq_3_cl_21:
"cluster absolutely-summableCOMSEQ-3V2 also-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it be absolutely-summableCOMSEQ-3V2 implies it be summableCOMSEQ-3V1"
    using comseq_3_th_63 sorry
qed "sorry"

mtheorem comseq_3_cl_22:
"cluster absolutely-summableCOMSEQ-3V2 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be absolutely-summableCOMSEQ-3V2"
sorry
qed "sorry"

mtheorem comseq_3_th_64:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M implies z GeoSeqCOMSEQ-3K1 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1) =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
sorry

mtheorem comseq_3_th_65:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
sorry

mtheorem comseq_3_th_66:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds rseq1 be summableSERIES-1V1 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq2 be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem comseq_3_th_67:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & seq2 be absolutely-summableCOMSEQ-3V2 implies seq1 be absolutely-summableCOMSEQ-3V2 & SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1.|) <=XXREAL-0R1 SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|)"
  using series_1_th_20 sorry

mtheorem comseq_3_th_68:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not seq be absolutely-summableCOMSEQ-3V2"
  using series_1_th_27 sorry

mtheorem comseq_3_th_69:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M implies seq be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem comseq_3_th_70:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
sorry

mtheorem comseq_3_th_71:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 >XXREAL-0R4 \<one>\<^sub>M implies  not seq be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem comseq_3_th_72:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be non-increasingVALUED-0V12 & ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerPOWERK2 n *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M to-powerPOWERK2 n) implies (seq be absolutely-summableCOMSEQ-3V2 iff rseq1 be summableSERIES-1V1)"
sorry

mtheorem comseq_3_th_73:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for p be RealXREAL-0M1 holds p >XXREAL-0R4 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n to-powerPOWERK2 p) implies seq be absolutely-summableCOMSEQ-3V2"
  using series_1_th_32 sorry

mtheorem comseq_3_th_74:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for p be RealXREAL-0M1 holds p <=XXREAL-0R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n to-powerPOWERK2 p) implies  not seq be absolutely-summableCOMSEQ-3V2"
  using series_1_th_33 sorry

mtheorem comseq_3_th_75:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M implies seq be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem comseq_3_th_76:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not seq be absolutely-summableCOMSEQ-3V2"
sorry

end
