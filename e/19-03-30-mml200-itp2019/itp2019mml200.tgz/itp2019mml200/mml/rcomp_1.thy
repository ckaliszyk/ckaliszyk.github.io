theory rcomp_1
  imports seq_4
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, n1, m, k for "NatNAT-1M1"
reserve s, g, g1, g2, r, p, p2, q, t for "RealXREAL-0M1"
reserve s1, s2, s3 for "Real-SequenceSEQ-1M1"
reserve Nseq for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
reserve X for "SubsetSUBSET-1M2-of REALNUMBERSK2"
abbreviation(input) RCOMP_1K1("[.RCOMP-1K1 _ , _ .]" [0,0]164) where
  "[.RCOMP-1K1 g,s .] \<equiv> [.XXREAL-1K1 g,s .]"

mtheorem rcomp_1_def_1:
  mlet "g be RealXREAL-0M1", "s be RealXREAL-0M1"
"redefine func [.RCOMP-1K1 g,s .] \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 [.RCOMP-1K1 g,s .] iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
sorry
qed "sorry"

mtheorem rcomp_1_add_1:
  mlet "g be RealXREAL-0M1", "s be RealXREAL-0M1"
"cluster [.XXREAL-1K1 g,s .] as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "[.XXREAL-1K1 g,s .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

abbreviation(input) RCOMP_1K2("].RCOMP-1K2 _ , _ .[" [0,0]164) where
  "].RCOMP-1K2 g,s .[ \<equiv> ].XXREAL-1K4 g,s .["

mtheorem rcomp_1_def_2:
  mlet "g be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"redefine func ].RCOMP-1K2 g,s .[ \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <XXREAL-0R3 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].RCOMP-1K2 g,s .[ iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <XXREAL-0R3 s }"
sorry
qed "sorry"

mtheorem rcomp_1_add_2:
  mlet "g be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 g,s .[ as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "].XXREAL-1K4 g,s .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mtheorem rcomp_1_th_1:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .[ iff  |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g"
sorry

mtheorem rcomp_1_th_2:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 p,g .] iff  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p"
sorry

mtheorem rcomp_1_th_3:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p,g .[ iff  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p"
sorry

mdef rcomp_1_def_3 ("compactRCOMP-1V1" 70 ) where
"attr compactRCOMP-1V1 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>X.  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 X implies ( ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X))"..

mdef rcomp_1_def_4 ("closedRCOMP-1V2" 70 ) where
"attr closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>X.  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3 implies limSEQ-2K1 s1 inHIDDENR3 X)"..

mdef rcomp_1_def_5 ("openRCOMP-1V3" 70 ) where
"attr openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>X. X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> be closedRCOMP-1V2)"..

mtheorem rcomp_1_th_4:
" for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .] implies s1 be boundedCOMSEQ-2V1"
sorry

mtheorem rcomp_1_th_5:
" for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds [.RCOMP-1K1 s,g .] be closedRCOMP-1V2"
sorry

mtheorem rcomp_1_th_6:
" for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds [.RCOMP-1K1 s,g .] be compactRCOMP-1V1"
sorry

mtheorem rcomp_1_th_7:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ].RCOMP-1K2 p,q .[ be openRCOMP-1V3"
sorry

mtheorem rcomp_1_cl_1:
  mlet "p be RealXREAL-0M1", "q be RealXREAL-0M1"
"cluster ].RCOMP-1K2 p,q .[ as-term-is openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].RCOMP-1K2 p,q .[ implies it be openRCOMP-1V3"
    using rcomp_1_th_7 sorry
qed "sorry"

mtheorem rcomp_1_cl_2:
  mlet "p be RealXREAL-0M1", "q be RealXREAL-0M1"
"cluster [.RCOMP-1K1 p,q .] as-term-is closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 [.RCOMP-1K1 p,q .] implies it be closedRCOMP-1V2"
    using rcomp_1_th_5 sorry
qed "sorry"

mtheorem rcomp_1_th_8:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 implies X be closedRCOMP-1V2"
sorry

mtheorem rcomp_1_cl_3:
"cluster compactRCOMP-1V1 also-is closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be compactRCOMP-1V1 implies it be closedRCOMP-1V2"
    using rcomp_1_th_8 sorry
qed "sorry"

mtheorem rcomp_1_th_9:
" for s1 be Real-SequenceSEQ-1M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 p .|))) implies ( for s2 be Real-SequenceSEQ-1M1 holds s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 implies  not (s2 be convergentCOMSEQ-2V3 & limSEQ-2K1 s2 inHIDDENR3 X))"
sorry

mtheorem rcomp_1_th_10:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 implies X be real-boundedXXREAL-2V5"
sorry

mtheorem rcomp_1_th_11:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar>closedRCOMP-1V2 implies X be compactRCOMP-1V1"
sorry

mtheorem rcomp_1_th_12:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be closedRCOMP-1V2) & X be bounded-aboveXXREAL-2V4 implies upper-boundSEQ-4K2 X inHIDDENR3 X"
sorry

mtheorem rcomp_1_th_13:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be closedRCOMP-1V2) & X be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 X inHIDDENR3 X"
sorry

mtheorem rcomp_1_th_14:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & X be compactRCOMP-1V1 implies upper-boundSEQ-4K2 X inHIDDENR3 X & lower-boundSEQ-4K3 X inHIDDENR3 X"
sorry

mtheorem rcomp_1_th_15:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 & ( for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X) implies ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 p,g .])"
sorry

mtheorem rcomp_1_cl_4:
"cluster openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be openRCOMP-1V3"
sorry
qed "sorry"

mdef rcomp_1_def_6 ("NeighbourhoodRCOMP-1M1-of  _ " [70]70 ) where
  mlet "r be RealXREAL-0M1"
"mode NeighbourhoodRCOMP-1M1-of r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>it.  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & it =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & it =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .["
sorry
qed "sorry"

mtheorem rcomp_1_cl_5:
  mlet "r be RealXREAL-0M1"
"cluster note-that openRCOMP-1V3 for NeighbourhoodRCOMP-1M1-of r"
proof
(*coherence*)
  show " for it be NeighbourhoodRCOMP-1M1-of r holds it be openRCOMP-1V3"
sorry
qed "sorry"

mtheorem rcomp_1_th_16:
" for r be RealXREAL-0M1 holds  for N be NeighbourhoodRCOMP-1M1-of r holds r inHIDDENR3 N"
sorry

mtheorem rcomp_1_th_17:
" for r be RealXREAL-0M1 holds  for N1 be NeighbourhoodRCOMP-1M1-of r holds  for N2 be NeighbourhoodRCOMP-1M1-of r holds  ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 N1 & N c=TARSKIR1 N2"
sorry

mtheorem rcomp_1_th_18:
" for X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 X)"
sorry

mtheorem rcomp_1_th_19:
" for X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[ c=TARSKIR1 X)"
sorry

mtheorem rcomp_1_th_20:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X implies ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 X)) implies X be openRCOMP-1V3"
sorry

mtheorem rcomp_1_th_21:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3\<bar>bounded-aboveXXREAL-2V4 implies  not upper-boundSEQ-4K2 X inHIDDENR3 X"
sorry

mtheorem rcomp_1_th_22:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3\<bar>bounded-belowXXREAL-2V3 implies  not lower-boundSEQ-4K3 X inHIDDENR3 X"
sorry

mtheorem rcomp_1_th_23:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3\<bar>real-boundedXXREAL-2V5 & ( for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X) implies ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 p,g .[)"
sorry

abbreviation(input) RCOMP_1K3("[.RCOMP-1K3 _ , _ .[" [0,0]164) where
  "[.RCOMP-1K3 g,s .[ \<equiv> [.XXREAL-1K2 g,s .["

mtheorem rcomp_1_def_7:
  mlet "g be RealXREAL-0M1", "s be ExtRealXXREAL-0M1"
"redefine func [.RCOMP-1K3 g,s .[ \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <XXREAL-0R3 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 [.RCOMP-1K3 g,s .[ iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <XXREAL-0R3 s }"
sorry
qed "sorry"

mtheorem rcomp_1_add_3:
  mlet "g be RealXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 g,s .[ as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "[.XXREAL-1K2 g,s .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

abbreviation(input) RCOMP_1K4("].RCOMP-1K4 _ , _ .]" [0,0]164) where
  "].RCOMP-1K4 g,s .] \<equiv> ].XXREAL-1K3 g,s .]"

mtheorem rcomp_1_def_8:
  mlet "g be ExtRealXXREAL-0M1", "s be RealXREAL-0M1"
"redefine func ].RCOMP-1K4 g,s .] \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].RCOMP-1K4 g,s .] iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
sorry
qed "sorry"

mtheorem rcomp_1_add_4:
  mlet "g be ExtRealXXREAL-0M1", "s be RealXREAL-0M1"
"cluster ].XXREAL-1K3 g,s .] as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "].XXREAL-1K3 g,s .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

end
