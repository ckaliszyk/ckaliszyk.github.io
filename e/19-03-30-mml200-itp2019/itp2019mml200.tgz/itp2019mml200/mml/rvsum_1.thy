theory rvsum_1
  imports square_1 binop_2 finseq_4 setwop_2 rfunct_1 xxreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem rvsum_1_cl_1:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n -elementCARD-1V3\<bar>natural-valuedVALUED-0V8 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be n -elementCARD-1V3\<bar>natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem rvsum_1_cl_2:
"cluster real-valuedVALUED-0V7 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be real-valuedVALUED-0V7"
sorry
qed "sorry"

abbreviation(input) RVSUM_1K1("rngRVSUM-1K1  _ " [228]228) where
  "rngRVSUM-1K1 F \<equiv> rngRELAT-1K2 F"

mtheorem rvsum_1_add_1:
  mlet "F be real-valuedVALUED-0V3\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 F as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "rngRELAT-1K2 F be SubsetSUBSET-1M2-of REALNUMBERSK2"
    using valued_0_def_3 sorry
qed "sorry"

mtheorem rvsum_1_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FunctionFUNCT-2M1-of(REALNUMBERSK2,D)", "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F *FUNCT-1K3 F1 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "F *FUNCT-1K3 F1 be FinSequence-likeFINSEQ-1V1"
sorry
qed "sorry"

mtheorem rvsum_1_cl_4:
  mlet "r be RealXREAL-0M1"
"cluster <*FINSEQ-1K10 r*> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-1K10 r*> be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem rvsum_1_cl_5:
  mlet "r1 be RealXREAL-0M1", "r2 be RealXREAL-0M1"
"cluster <*FINSEQ-1K11 r1,r2 *> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-1K11 r1,r2 *> be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem rvsum_1_cl_6:
  mlet "r1 be RealXREAL-0M1", "r2 be RealXREAL-0M1", "r3 be RealXREAL-0M1"
"cluster <*FINSEQ-1K12 r1,r2,r3 *> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-1K12 r1,r2,r3 *> be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem rvsum_1_cl_7:
  mlet "r1 be RealXREAL-0M1", "r2 be RealXREAL-0M1", "r3 be RealXREAL-0M1", "r4 be RealXREAL-0M1"
"cluster <*FINSEQ-4K7 r1,r2,r3,r4 *> as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "<*FINSEQ-4K7 r1,r2,r3,r4 *> be real-valuedVALUED-0V7"
sorry
qed "sorry"

mtheorem rvsum_1_cl_8:
  mlet "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r be RealXREAL-0M1"
"cluster j  |->FINSEQ-2K2 r as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "j  |->FINSEQ-2K2 r be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem rvsum_1_cl_9:
  mlet "f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "g be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be real-valuedVALUED-0V7"
sorry
qed "sorry"

reserve s for "setHIDDENM2"
reserve i, j for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
reserve k for "NatNAT-1M1"
reserve r, r1, r2, r3, r4 for "RealXREAL-0M1"
reserve F, F1, F2, F3 for "real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
reserve R, R1, R2 for "ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
mtheorem rvsum_1_th_1:
"0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
  using binop_2_th_2 setwiseo_th_14 sorry

abbreviation(input) RVSUM_1K2("diffrealRVSUM-1K2" 228) where
  "diffrealRVSUM-1K2 \<equiv> diffrealBINOP-2K10"

mtheorem rvsum_1_def_1:
"redefine func diffrealRVSUM-1K2 \<rightarrow> ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2 :]) equals
  (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 REALNUMBERSK2,REALNUMBERSK2 :],REALNUMBERSK2 :]) holds it =HIDDENR1 diffrealRVSUM-1K2 iff it =HIDDENR1 (addrealBINOP-2K9)*FINSEQOPK7\<^bsub>(REALNUMBERSK2)\<^esub>(idPARTFUN1K6 REALNUMBERSK2,comprealBINOP-2K7)"
sorry
qed "sorry"

mdef rvsum_1_def_2 ("sqrrealRVSUM-1K3" 228 ) where
"func sqrrealRVSUM-1K3 \<rightarrow> UnOpBINOP-1M1-of REALNUMBERSK2 means
  \<lambda>it.  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
proof-
  (*existence*)
    show " ex it be UnOpBINOP-1M1-of REALNUMBERSK2 st  for r be RealXREAL-0M1 holds it .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1"
sorry
  (*uniqueness*)
    show " for it1 be UnOpBINOP-1M1-of REALNUMBERSK2 holds  for it2 be UnOpBINOP-1M1-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds it1 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1) & ( for r be RealXREAL-0M1 holds it2 .FUNCT-1K1 r =XBOOLE-0R4 r ^2SQUARE-1K1) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem rvsum_1_th_2:
"\<one>\<^sub>M is-a-unity-wrtBINOP-1R3\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
  using binop_2_th_7 setwiseo_th_14 sorry

mtheorem rvsum_1_th_3:
"multrealBINOP-2K11 is-distributive-wrtBINOP-1R6\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
sorry

mtheorem rvsum_1_th_4:
"sqrrealRVSUM-1K3 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> multrealBINOP-2K11"
sorry

mdef rvsum_1_def_3 (" _ multrealRVSUM-1K4" [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func x multrealRVSUM-1K4 \<rightarrow> UnOpBINOP-1M1-of REALNUMBERSK2 equals
  (multrealBINOP-2K11)[;]FUNCOP-1K5(x,idPARTFUN1K6 REALNUMBERSK2)"
proof-
  (*coherence*)
    show "(multrealBINOP-2K11)[;]FUNCOP-1K5(x,idPARTFUN1K6 REALNUMBERSK2) be UnOpBINOP-1M1-of REALNUMBERSK2"
sorry
qed "sorry"

mlemma rvsum_1_lm_1:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds ((multrealBINOP-2K11)[;]FUNCOP-1K5(r,idPARTFUN1K6 REALNUMBERSK2)).FUNCT-1K1 r1 =XBOOLE-0R4 r *XCMPLX-0K3 r1"
sorry

mtheorem rvsum_1_th_5:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds (r multrealRVSUM-1K4).FUNCT-1K1 r1 =XBOOLE-0R4 r *XCMPLX-0K3 r1"
  using rvsum_1_lm_1 sorry

mtheorem rvsum_1_th_6:
" for r be RealXREAL-0M1 holds r multrealRVSUM-1K4 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
sorry

mtheorem rvsum_1_th_7:
"comprealBINOP-2K7 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
sorry

mtheorem rvsum_1_th_8:
"addrealBINOP-2K9 be having-an-inverseOpFINSEQOPV1\<^bsub>(REALNUMBERSK2)\<^esub>"
  using rvsum_1_th_7 sorry

mtheorem rvsum_1_th_9:
"the-inverseOp-wrtFINSEQOPK5\<^bsub>(REALNUMBERSK2)\<^esub> (addrealBINOP-2K9) =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
  using rvsum_1_th_7 rvsum_1_th_8 finseqop_def_3 sorry

mtheorem rvsum_1_th_10:
"comprealBINOP-2K7 is-distributive-wrtBINOP-1R12\<^bsub>(REALNUMBERSK2)\<^esub> addrealBINOP-2K9"
  using rvsum_1_th_8 rvsum_1_th_9 finseqop_th_63 sorry

mlemma rvsum_1_lm_2:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
sorry

abbreviation(input) RVSUM_1K5(" _ +RVSUM-1K5  _ " [132,132]132) where
  "F1 +RVSUM-1K5 F2 \<equiv> F1 +VALUED-1K1 F2"

mtheorem rvsum_1_def_4:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func F1 +RVSUM-1K5 F2 \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 F1 +RVSUM-1K5 F2 iff it =HIDDENR1 (addrealBINOP-2K9).:FUNCOP-1K3(F1,F2)"
sorry
qed "sorry"

mtheorem rvsum_1_add_2:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F1 +VALUED-1K1 F2 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F1 +VALUED-1K1 F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

mtheorem RVSUM_1K5_commutativity:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 +RVSUM-1K5 F2 =HIDDENR1 F2 +RVSUM-1K5 F1"
sorry

syntax RVSUM_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +RVSUM-1K6\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2" \<rightharpoonup> "R1 +VALUED-1K1 R2"

mtheorem rvsum_1_add_3:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R1 +VALUED-1K1 R2 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R1 +VALUED-1K1 R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem rvsum_1_th_11:
" for s be setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s +XCMPLX-0K2 R2 .FUNCT-1K1 s"
sorry

mtheorem rvsum_1_th_12:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds <*>FINSEQ-1K7 REALNUMBERSK2 +RVSUM-1K5 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
sorry

mtheorem rvsum_1_th_13:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds <*FINSEQ-1K10 r1*> +RVSUM-1K5 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 +XCMPLX-0K2 r2 *>"
sorry

mtheorem rvsum_1_th_14:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds i  |->FINSEQ-2K2 r1 +RVSUM-1K5 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 +XCMPLX-0K2 r2)"
sorry

mtheorem rvsum_1_th_15:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 +RVSUM-1K5 (F2 +RVSUM-1K5 F3) =FINSEQ-1R1 (F1 +RVSUM-1K5 F2)+RVSUM-1K5 F3"
  using rfunct_1_th_8 sorry

mtheorem rvsum_1_th_16:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R +RVSUM-1K5 i  |->FINSEQ-2K2 (0NUMBERSK6) =FINSEQ-1R1 R"
  using binop_2_th_2 finseqop_th_56 sorry

mtheorem rvsum_1_th_17:
" for s be setHIDDENM2 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (-VALUED-1K32 F).FUNCT-1K1 s =HIDDENR1 -XCMPLX-0K4 F .FUNCT-1K1 s"
  using valued_1_th_8 sorry

abbreviation(input) RVSUM_1K7("-RVSUM-1K7  _ " [132]132) where
  "-RVSUM-1K7 F \<equiv> -VALUED-1K32 F"

mtheorem rvsum_1_def_5:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func -RVSUM-1K7 F \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (comprealBINOP-2K7)*FUNCT-1K3 F"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 -RVSUM-1K7 F iff it =HIDDENR1 (comprealBINOP-2K7)*FUNCT-1K3 F"
sorry
qed "sorry"

mtheorem rvsum_1_add_4:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster -VALUED-1K32 F as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "-VALUED-1K32 F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("-RVSUM-1K8\<^bsub>'( _ ')\<^esub>  _ " [0,132]132)
translations "-RVSUM-1K8\<^bsub>(i)\<^esub> R" \<rightharpoonup> "-VALUED-1K32 R"

mtheorem rvsum_1_add_5:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster -VALUED-1K32 R as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "-VALUED-1K32 R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem rvsum_1_th_18:
" for s be setHIDDENM2 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (-RVSUM-1K7 F).FUNCT-1K1 s =HIDDENR1 -XCMPLX-0K4 F .FUNCT-1K1 s"
  using valued_1_th_8 sorry

mtheorem rvsum_1_th_19:
"-RVSUM-1K7 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
   sorry

mtheorem rvsum_1_th_20:
" for r be RealXREAL-0M1 holds -RVSUM-1K7 <*FINSEQ-1K10 r*> =FINSEQ-1R1 <*FINSEQ-1K10 -XCMPLX-0K4 r *>"
sorry

mtheorem rvsum_1_th_21:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds -RVSUM-1K7 i  |->FINSEQ-2K2 r =FINSEQ-1R1 i  |->FINSEQ-2K2 (-XCMPLX-0K4 r)"
sorry

mtheorem rvsum_1_th_22:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R +RVSUM-1K6\<^bsub>(i)\<^esub> (-RVSUM-1K8\<^bsub>(i)\<^esub> R) =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry

mtheorem rvsum_1_th_23:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2 =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) implies R1 =FINSEQ-1R1 -RVSUM-1K8\<^bsub>(i)\<^esub> R2"
  using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_74 sorry

mtheorem rvsum_1_th_24:
" for R1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for R2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 R1 =FUNCT-1R1 -VALUED-1K32 R2 implies R1 =FUNCT-1R1 R2"
sorry

mtheorem rvsum_1_th_25:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R =FINSEQ-1R1 R2 +RVSUM-1K6\<^bsub>(i)\<^esub> R implies R1 =FINSEQ-1R1 R2"
sorry

mtheorem rvsum_1_th_26:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (-RVSUM-1K7 F1)+RVSUM-1K5 (-RVSUM-1K7 F2)"
sorry

abbreviation(input) RVSUM_1K9(" _ -RVSUM-1K9  _ " [132,132]132) where
  "F1 -RVSUM-1K9 F2 \<equiv> F1 -VALUED-1K47 F2"

mtheorem rvsum_1_def_6:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func F1 -RVSUM-1K9 F2 \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 F1 -RVSUM-1K9 F2 iff it =HIDDENR1 diffrealRVSUM-1K2 .:FUNCOP-1K3(F1,F2)"
sorry
qed "sorry"

mtheorem rvsum_1_add_6:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F1 -VALUED-1K47 F2 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F1 -VALUED-1K47 F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -RVSUM-1K10\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2" \<rightharpoonup> "R1 -VALUED-1K47 R2"

mtheorem rvsum_1_add_7:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R1 -VALUED-1K47 R2 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R1 -VALUED-1K47 R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem rvsum_1_th_27:
" for s be setHIDDENM2 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2).FUNCT-1K1 s =XBOOLE-0R4 R1 .FUNCT-1K1 s -XCMPLX-0K6 R2 .FUNCT-1K1 s"
sorry

mtheorem rvsum_1_th_28:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds <*>FINSEQ-1K7 REALNUMBERSK2 -RVSUM-1K9 F =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2 & F -RVSUM-1K9 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
sorry

mtheorem rvsum_1_th_29:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds <*FINSEQ-1K10 r1*> -RVSUM-1K9 <*FINSEQ-1K10 r2*> =FINSEQ-1R1 <*FINSEQ-1K10 r1 -XCMPLX-0K6 r2 *>"
sorry

mtheorem rvsum_1_th_30:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds i  |->FINSEQ-2K2 r1 -RVSUM-1K9 i  |->FINSEQ-2K2 r2 =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 -XCMPLX-0K6 r2)"
sorry

mtheorem rvsum_1_th_31:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 -RVSUM-1K9 F2 =FINSEQ-1R1 F1 +RVSUM-1K5 (-RVSUM-1K7 F2)"
   sorry

mtheorem rvsum_1_th_32:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R -RVSUM-1K9 i  |->FINSEQ-2K2 (0NUMBERSK6) =FINSEQ-1R1 R"
sorry

mtheorem rvsum_1_th_33:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds i  |->FINSEQ-2K2 (0NUMBERSK6) -RVSUM-1K9 R =FINSEQ-1R1 -RVSUM-1K8\<^bsub>(i)\<^esub> R"
  using binop_2_th_2 finseqop_th_56 sorry

mtheorem rvsum_1_th_34:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 -RVSUM-1K9 (-RVSUM-1K7 F2) =FINSEQ-1R1 F1 +RVSUM-1K5 F2"
   sorry

mtheorem rvsum_1_th_35:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 -RVSUM-1K9 F2) =FINSEQ-1R1 F2 -RVSUM-1K9 F1"
sorry

mtheorem rvsum_1_th_36:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds -RVSUM-1K7 (F1 -RVSUM-1K9 F2) =FINSEQ-1R1 (-RVSUM-1K7 F1)+RVSUM-1K5 F2"
sorry

mtheorem rvsum_1_th_37:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R -RVSUM-1K10\<^bsub>(i)\<^esub> R =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  using rvsum_1_th_8 rvsum_1_th_9 binop_2_th_2 finseqop_th_73 sorry

mtheorem rvsum_1_th_38:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2 =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) implies R1 =FINSEQ-1R1 R2"
sorry

mtheorem rvsum_1_th_39:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (F1 -RVSUM-1K9 F2)-RVSUM-1K9 F3 =FINSEQ-1R1 F1 -RVSUM-1K9 (F2 +RVSUM-1K5 F3)"
  using rfunct_1_th_20 sorry

mtheorem rvsum_1_th_40:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 +RVSUM-1K5 (F2 -RVSUM-1K9 F3) =FINSEQ-1R1 (F1 +RVSUM-1K5 F2)-RVSUM-1K9 F3"
  using rfunct_1_th_23 sorry

mtheorem rvsum_1_th_41:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F1 -RVSUM-1K9 (F2 -RVSUM-1K9 F3) =FINSEQ-1R1 (F1 -RVSUM-1K9 F2)+RVSUM-1K5 F3"
  using rfunct_1_th_22 sorry

mtheorem rvsum_1_th_42:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 =FINSEQ-1R1 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R)-RVSUM-1K10\<^bsub>(i)\<^esub> R"
sorry

mtheorem rvsum_1_th_43:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds R1 =FINSEQ-1R1 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R)+RVSUM-1K6\<^bsub>(i)\<^esub> R"
sorry

abbreviation(input) RVSUM_1K11(" _ *RVSUM-1K11  _ " [164,164]164) where
  "r *RVSUM-1K11 F \<equiv> r (#)VALUED-1K25 F"

mtheorem rvsum_1_th_44:
" for s be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r *RVSUM-1K11 F).FUNCT-1K1 s =XBOOLE-0R4 r *XCMPLX-0K3 F .FUNCT-1K1 s"
  using valued_1_th_6 sorry

abbreviation(input) RVSUM_1K12(" _ *RVSUM-1K12  _ " [164,164]164) where
  "r *RVSUM-1K12 F \<equiv> r (#)VALUED-1K25 F"

mtheorem rvsum_1_def_7:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "r be RealXREAL-0M1"
"redefine func r *RVSUM-1K12 F \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (r multrealRVSUM-1K4)*FUNCT-1K3 F"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 r *RVSUM-1K12 F iff it =HIDDENR1 (r multrealRVSUM-1K4)*FUNCT-1K3 F"
sorry
qed "sorry"

mtheorem rvsum_1_add_8:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 F as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "r (#)VALUED-1K25 F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *RVSUM-1K13\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "r *RVSUM-1K13\<^bsub>(i)\<^esub> R" \<rightharpoonup> "r (#)VALUED-1K25 R"

mtheorem rvsum_1_add_9:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 R as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "r (#)VALUED-1K25 R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem rvsum_1_th_45:
" for s be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r *RVSUM-1K12 F).FUNCT-1K1 s =XBOOLE-0R4 r *XCMPLX-0K3 F .FUNCT-1K1 s"
  using valued_1_th_6 sorry

mtheorem rvsum_1_th_46:
" for r be RealXREAL-0M1 holds r *RVSUM-1K12 <*>FINSEQ-1K7 REALNUMBERSK2 =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
   sorry

mtheorem rvsum_1_th_47:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds r *RVSUM-1K12 (<*FINSEQ-1K10 r1*>) =FINSEQ-1R1 <*FINSEQ-1K10 r *XCMPLX-0K3 r1 *>"
sorry

mtheorem rvsum_1_th_48:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 *RVSUM-1K12 (i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
sorry

mtheorem rvsum_1_th_49:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r1 *XCMPLX-0K3 r2)*RVSUM-1K12 F =FINSEQ-1R1 r1 *RVSUM-1K12 (r2 *RVSUM-1K12 F)"
  using rfunct_1_th_17 sorry

mtheorem rvsum_1_th_50:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (r1 +XCMPLX-0K2 r2)*RVSUM-1K12 F =FINSEQ-1R1 r1 *RVSUM-1K12 F +RVSUM-1K5 r2 *RVSUM-1K12 F"
sorry

mtheorem rvsum_1_th_51:
" for r be RealXREAL-0M1 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds r *RVSUM-1K12 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 r *RVSUM-1K12 F1 +RVSUM-1K5 r *RVSUM-1K12 F2"
  using rfunct_1_th_16 sorry

mtheorem rvsum_1_th_52:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M *RVSUM-1K12 F =FINSEQ-1R1 F"
  using rfunct_1_th_21 sorry

mtheorem rvsum_1_th_53:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (0NUMBERSK6)*RVSUM-1K13\<^bsub>(i)\<^esub> R =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
sorry

mtheorem rvsum_1_th_54:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (-XCMPLX-0K4 \<one>\<^sub>M)*RVSUM-1K12 F =FINSEQ-1R1 -RVSUM-1K7 F"
   sorry

abbreviation(input) RVSUM_1K14("sqrRVSUM-1K14  _ " [228]228) where
  "sqrRVSUM-1K14 F \<equiv> F ^2VALUED-1K41"

abbreviation(input) RVSUM_1K15("sqrRVSUM-1K15  _ " [228]228) where
  "sqrRVSUM-1K15 F \<equiv> F ^2VALUED-1K41"

mtheorem rvsum_1_def_8:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func sqrRVSUM-1K15 F \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  sqrrealRVSUM-1K3 *FUNCT-1K3 F"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 sqrRVSUM-1K15 F iff it =HIDDENR1 sqrrealRVSUM-1K3 *FUNCT-1K3 F"
sorry
qed "sorry"

mtheorem rvsum_1_add_10:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F ^2VALUED-1K41 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F ^2VALUED-1K41 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

syntax RVSUM_1K16 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("sqrRVSUM-1K16\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "sqrRVSUM-1K16\<^bsub>(i)\<^esub> R" \<rightharpoonup> "R ^2VALUED-1K41"

mtheorem rvsum_1_add_11:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R ^2VALUED-1K41 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R ^2VALUED-1K41 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem rvsum_1_th_55:
" for r be RealXREAL-0M1 holds sqrRVSUM-1K15 (<*FINSEQ-1K10 r*>) =FINSEQ-1R1 <*FINSEQ-1K10 r ^2SQUARE-1K1*>"
sorry

mtheorem rvsum_1_th_56:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds sqrRVSUM-1K15 (i  |->FINSEQ-2K2 r) =FINSEQ-1R1 i  |->FINSEQ-2K2 r ^2SQUARE-1K1"
sorry

mtheorem rvsum_1_th_57:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (-RVSUM-1K7 F) =FINSEQ-1R1 sqrRVSUM-1K15 F"
sorry

mtheorem rvsum_1_th_58:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (r *RVSUM-1K12 F) =FINSEQ-1R1 r ^2SQUARE-1K1 *RVSUM-1K12 sqrRVSUM-1K15 F"
sorry

abbreviation(input) RVSUM_1K17("mltRVSUM-1K17'( _ , _ ')" [0,0]228) where
  "mltRVSUM-1K17(F1,F2) \<equiv> F1 (#)VALUED-1K19 F2"

abbreviation(input) RVSUM_1K18("mltRVSUM-1K18'( _ , _ ')" [0,0]228) where
  "mltRVSUM-1K18(F1,F2) \<equiv> F1 (#)VALUED-1K19 F2"

mtheorem rvsum_1_def_9:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"redefine func mltRVSUM-1K18(F1,F2) \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 mltRVSUM-1K18(F1,F2) iff it =HIDDENR1 (multrealBINOP-2K11).:FUNCOP-1K3(F1,F2)"
sorry
qed "sorry"

mtheorem rvsum_1_add_12:
  mlet "F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster F1 (#)VALUED-1K19 F2 as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show "F1 (#)VALUED-1K19 F2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    using rvsum_1_lm_2 sorry
qed "sorry"

mtheorem RVSUM_1K18_commutativity:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(F1,F2) =HIDDENR1 mltRVSUM-1K18(F2,F1)"
sorry

mtheorem rvsum_1_th_59:
" for s be setHIDDENM2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(F1,F2) .FUNCT-1K1 s =XBOOLE-0R4 F1 .FUNCT-1K1 s *XCMPLX-0K3 F2 .FUNCT-1K1 s"
  using valued_1_th_5 sorry

syntax RVSUM_1K19 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("mltRVSUM-1K19\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]228)
translations "mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)" \<rightharpoonup> "R1 (#)VALUED-1K19 R2"

mtheorem rvsum_1_add_13:
  mlet "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2", "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
"cluster R1 (#)VALUED-1K19 R2 as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show "R1 (#)VALUED-1K19 R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem rvsum_1_th_60:
" for s be setHIDDENM2 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(F1,F2) .FUNCT-1K1 s =XBOOLE-0R4 F1 .FUNCT-1K1 s *XCMPLX-0K3 F2 .FUNCT-1K1 s"
  using valued_1_th_5 sorry

mtheorem rvsum_1_th_61:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds mltRVSUM-1K18(<*>FINSEQ-1K7 REALNUMBERSK2,F) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
sorry

mtheorem rvsum_1_th_62:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(<*FINSEQ-1K10 r1*>,<*FINSEQ-1K10 r2*>) =FINSEQ-1R1 <*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>"
sorry

mtheorem rvsum_1_th_63:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds mltRVSUM-1K18(i  |->FINSEQ-2K2 r,R) =FINSEQ-1R1 r *RVSUM-1K13\<^bsub>(i)\<^esub> R"
sorry

mtheorem rvsum_1_th_64:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(i  |->FINSEQ-2K2 r1,i  |->FINSEQ-2K2 r2) =FINSEQ-1R1 i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)"
sorry

mtheorem rvsum_1_th_65:
" for r be RealXREAL-0M1 holds  for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds r *RVSUM-1K12 mltRVSUM-1K18(F1,F2) =FINSEQ-1R1 mltRVSUM-1K18(r *RVSUM-1K12 F1,F2)"
  using rfunct_1_th_12 sorry

mtheorem rvsum_1_th_66:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds r *RVSUM-1K13\<^bsub>(i)\<^esub> R =FINSEQ-1R1 mltRVSUM-1K18(i  |->FINSEQ-2K2 r,R)"
  using rvsum_1_th_63 sorry

mtheorem rvsum_1_th_67:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 F =FINSEQ-1R1 mltRVSUM-1K18(F,F)"
   sorry

mtheorem rvsum_1_th_68:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (F1 +RVSUM-1K5 F2) =FINSEQ-1R1 (sqrRVSUM-1K15 F1 +RVSUM-1K5 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
sorry

mtheorem rvsum_1_th_69:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (F1 -RVSUM-1K9 F2) =FINSEQ-1R1 (sqrRVSUM-1K15 F1 -RVSUM-1K9 \<two>\<^sub>M *RVSUM-1K12 mltRVSUM-1K18(F1,F2))+RVSUM-1K5 sqrRVSUM-1K15 F2"
sorry

mtheorem rvsum_1_th_70:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (mltRVSUM-1K18(F1,F2)) =FINSEQ-1R1 mltRVSUM-1K18(sqrRVSUM-1K15 F1,sqrRVSUM-1K15 F2)"
sorry

mtheorem rvsum_1_cl_10:
"cluster note-that complex-valuedVALUED-0V5 for FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem rvsum_1_cl_11:
"cluster real-valuedVALUED-0V7\<bar>complex-valuedVALUED-0V5 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be real-valuedVALUED-0V7\<bar>complex-valuedVALUED-0V5"
sorry
qed "sorry"

mdef rvsum_1_def_10 ("SumRVSUM-1K20  _ " [260]260 ) where
  mlet "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"func SumRVSUM-1K20 F \<rightarrow> ComplexXCMPLX-0M1 means
  \<lambda>it.  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
sorry
  (*uniqueness*)
    show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it1 =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) & ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it2 =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem rvsum_1_cl_12:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster SumRVSUM-1K20 F as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "SumRVSUM-1K20 F be realXREAL-0V1"
sorry
qed "sorry"

mtheorem rvsum_1_th_71:
" for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds SumRVSUM-1K20 F =HIDDENR1 (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
sorry

abbreviation(input) RVSUM_1K21("SumRVSUM-1K21  _ " [260]260) where
  "SumRVSUM-1K21 F \<equiv> SumRVSUM-1K20 F"

mtheorem rvsum_1_def_11:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func SumRVSUM-1K21 F \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 SumRVSUM-1K21 F iff it =HIDDENR1 addcomplexBINOP-2K3 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
    using rvsum_1_def_10 sorry
qed "sorry"

mtheorem rvsum_1_add_14:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster SumRVSUM-1K20 F as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "SumRVSUM-1K20 F be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

abbreviation(input) RVSUM_1K22("SumRVSUM-1K22  _ " [260]260) where
  "SumRVSUM-1K22 F \<equiv> SumRVSUM-1K20 F"

mtheorem rvsum_1_def_12:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"redefine func SumRVSUM-1K22 F \<rightarrow> RealXREAL-0M1 equals
  (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
proof
(*compatibility*)
  show " for it be RealXREAL-0M1 holds it =HIDDENR1 SumRVSUM-1K22 F iff it =HIDDENR1 (addrealBINOP-2K9)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using rvsum_1_th_71 sorry
qed "sorry"

mtheorem rvsum_1_add_15:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"cluster SumRVSUM-1K20 F as-term-is RealXREAL-0M1"
proof
(*coherence*)
  show "SumRVSUM-1K20 F be RealXREAL-0M1"
     sorry
qed "sorry"

mtheorem rvsum_1_th_72:
"SumRVSUM-1K22 <*>FINSEQ-1K7 REALNUMBERSK2 =HIDDENR1 0NUMBERSK6"
  using binop_2_th_2 finsop_1_th_10 sorry

mtheorem rvsum_1_th_73:
" for r be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
sorry

mtheorem rvsum_1_th_74:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 SumRVSUM-1K20 F +XCMPLX-0K2 r"
sorry

mtheorem rvsum_1_th_75:
" for F1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 SumRVSUM-1K20 F1 +XCMPLX-0K2 SumRVSUM-1K20 F2"
sorry

mtheorem rvsum_1_th_76:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K20 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r +XCMPLX-0K2 SumRVSUM-1K20 F"
sorry

mtheorem rvsum_1_th_77:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 +XCMPLX-0K2 r2"
sorry

mtheorem rvsum_1_th_78:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3"
sorry

mtheorem rvsum_1_th_79:
" for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (0NUMBERSK6)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 R =HIDDENR1 0NUMBERSK6"
  using rvsum_1_th_72 sorry

mtheorem rvsum_1_th_80:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds SumRVSUM-1K20 (i  |->FINSEQ-2K2 r) =HIDDENR1 i *XCMPLX-0K3 r"
sorry

mtheorem rvsum_1_th_81:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SumRVSUM-1K20 (i  |->FINSEQ-2K2 (0NUMBERSK6)) =HIDDENR1 0NUMBERSK6"
sorry

mlemma rvsum_1_lm_3:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2"
sorry

mtheorem rvsum_1_th_82:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K1 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <=XXREAL-0R1 SumRVSUM-1K20 R2"
sorry

mtheorem rvsum_1_th_83:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for R2 be i -elementCARD-1V3\<bar>real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K1 i implies R1 .FUNCT-1K1 j <=XXREAL-0R1 R2 .FUNCT-1K1 j) & ( ex j be NatNAT-1M1 st j inTARSKIR2 SegFINSEQ-1K1 i & R1 .FUNCT-1K1 j <XXREAL-0R3 R2 .FUNCT-1K1 j) implies SumRVSUM-1K20 R1 <XXREAL-0R3 SumRVSUM-1K20 R2"
sorry

mtheorem rvsum_1_th_84:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i) implies 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K20 F"
sorry

mtheorem rvsum_1_th_85:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F implies 0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 i) & ( ex i be NatNAT-1M1 st i inTARSKIR2 domFINSEQ-1K5 F & 0NUMBERSK6 <XXREAL-0R3 F .FUNCT-1K1 i) implies 0NUMBERSK6 <XXREAL-0R3 SumRVSUM-1K20 F"
sorry

mtheorem rvsum_1_th_86:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K15 F)"
sorry

mtheorem rvsum_1_th_87:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K22 (r *RVSUM-1K12 F) =HIDDENR1 r *XCMPLX-0K3 SumRVSUM-1K20 F"
sorry

mtheorem rvsum_1_th_88:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds SumRVSUM-1K22 (-RVSUM-1K7 F) =HIDDENR1 -XCMPLX-0K4 SumRVSUM-1K20 F"
sorry

mtheorem rvsum_1_th_89:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (R1 +RVSUM-1K6\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 +XCMPLX-0K2 SumRVSUM-1K22 R2"
sorry

mtheorem rvsum_1_th_90:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (R1 -RVSUM-1K10\<^bsub>(i)\<^esub> R2) =HIDDENR1 SumRVSUM-1K22 R1 -XCMPLX-0K6 SumRVSUM-1K22 R2"
sorry

mtheorem rvsum_1_th_91:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =HIDDENR1 0NUMBERSK6 implies R =FINSEQ-1R1 i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
sorry

mtheorem rvsum_1_th_92:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)))^2SQUARE-1K1 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R2)"
sorry

mdef rvsum_1_def_13 ("ProductRVSUM-1K23  _ " [228]228 ) where
  mlet "F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"func ProductRVSUM-1K23 F \<rightarrow> ComplexXCMPLX-0M1 means
  \<lambda>it.  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st  ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
sorry
  (*uniqueness*)
    show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it1 =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) & ( ex f be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 st f =FINSEQ-1R1 F & it2 =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem rvsum_1_cl_13:
  mlet "F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"cluster ProductRVSUM-1K23 F as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "ProductRVSUM-1K23 F be realXREAL-0V1"
sorry
qed "sorry"

mtheorem rvsum_1_th_93:
" for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds ProductRVSUM-1K23 F =HIDDENR1 (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
sorry

abbreviation(input) RVSUM_1K24("ProductRVSUM-1K24  _ " [228]228) where
  "ProductRVSUM-1K24 F \<equiv> ProductRVSUM-1K23 F"

mtheorem rvsum_1_def_14:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func ProductRVSUM-1K24 F \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 ProductRVSUM-1K24 F iff it =HIDDENR1 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
    using rvsum_1_def_13 sorry
qed "sorry"

mtheorem rvsum_1_add_16:
  mlet "F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster ProductRVSUM-1K23 F as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "ProductRVSUM-1K23 F be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

abbreviation(input) RVSUM_1K25("ProductRVSUM-1K25  _ " [228]228) where
  "ProductRVSUM-1K25 F \<equiv> ProductRVSUM-1K23 F"

mtheorem rvsum_1_def_15:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"redefine func ProductRVSUM-1K25 F \<rightarrow> RealXREAL-0M1 equals
  (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
proof
(*compatibility*)
  show " for it be RealXREAL-0M1 holds it =HIDDENR1 ProductRVSUM-1K25 F iff it =HIDDENR1 (multrealBINOP-2K11)$$SETWOP-2K5\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using rvsum_1_th_93 sorry
qed "sorry"

mtheorem rvsum_1_add_17:
  mlet "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"cluster ProductRVSUM-1K23 F as-term-is RealXREAL-0M1"
proof
(*coherence*)
  show "ProductRVSUM-1K23 F be RealXREAL-0M1"
     sorry
qed "sorry"

mlemma rvsum_1_lm_4:
" for F be emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 F =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem rvsum_1_th_94:
"ProductRVSUM-1K25 <*>FINSEQ-1K7 REALNUMBERSK2 =HIDDENR1 \<one>\<^sub>M"
  using rvsum_1_lm_4 sorry

mtheorem rvsum_1_cl_14:
  mlet "r be ComplexXCMPLX-0M1"
"cluster <*FINSEQ-1K10 r*> as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "<*FINSEQ-1K10 r*> be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem rvsum_1_cl_15:
  mlet "r1 be ComplexXCMPLX-0M1", "r2 be ComplexXCMPLX-0M1"
"cluster <*FINSEQ-1K11 r1,r2 *> as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "<*FINSEQ-1K11 r1,r2 *> be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem rvsum_1_cl_16:
  mlet "r1 be ComplexXCMPLX-0M1", "r2 be ComplexXCMPLX-0M1", "r3 be ComplexXCMPLX-0M1"
"cluster <*FINSEQ-1K12 r1,r2,r3 *> as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "<*FINSEQ-1K12 r1,r2,r3 *> be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem rvsum_1_cl_17:
  mlet "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "c be ComplexXCMPLX-0M1"
"cluster j  |->FINSEQ-2K2 c as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "j  |->FINSEQ-2K2 c be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem rvsum_1_th_95:
" for r be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (<*FINSEQ-1K10 r*>) =HIDDENR1 r"
sorry

mtheorem rvsum_1_cl_18:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "g be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be complex-valuedVALUED-0V5"
sorry
qed "sorry"

mtheorem rvsum_1_th_96:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  for r be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (F ^FINSEQ-1K8 (<*FINSEQ-1K10 r*>)) =HIDDENR1 ProductRVSUM-1K23 F *XCMPLX-0K3 r"
sorry

mtheorem rvsum_1_th_97:
" for F1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds  for F2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 (F1 ^FINSEQ-1K8 F2) =HIDDENR1 ProductRVSUM-1K23 F1 *XCMPLX-0K3 ProductRVSUM-1K23 F2"
sorry

mtheorem rvsum_1_th_98:
" for r be RealXREAL-0M1 holds  for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds ProductRVSUM-1K23 ((<*FINSEQ-1K10 r*>)^FINSEQ-1K8 F) =HIDDENR1 r *XCMPLX-0K3 ProductRVSUM-1K23 F"
sorry

mtheorem rvsum_1_th_99:
" for r1 be ComplexXCMPLX-0M1 holds  for r2 be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (<*FINSEQ-1K11 r1,r2 *>) =HIDDENR1 r1 *XCMPLX-0K3 r2"
sorry

mtheorem rvsum_1_th_100:
" for r1 be ComplexXCMPLX-0M1 holds  for r2 be ComplexXCMPLX-0M1 holds  for r3 be ComplexXCMPLX-0M1 holds ProductRVSUM-1K23 (<*FINSEQ-1K12 r1,r2,r3 *>) =HIDDENR1 (r1 *XCMPLX-0K3 r2)*XCMPLX-0K3 r3"
sorry

mtheorem rvsum_1_th_101:
" for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (0NUMBERSK6)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 R =HIDDENR1 \<one>\<^sub>M"
  using rvsum_1_lm_4 sorry

mtheorem rvsum_1_th_102:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
sorry

mlemma rvsum_1_lm_5:
" for p be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p <>HIDDENR2 0NUMBERSK6 implies ( ex q be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 st  ex d be ComplexXCMPLX-0M1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 d*>))"
sorry

mtheorem rvsum_1_th_103:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 F & F .FUNCT-1K1 k =XBOOLE-0R4 0NUMBERSK6) iff ProductRVSUM-1K23 F =HIDDENR1 0NUMBERSK6"
sorry

mtheorem rvsum_1_th_104:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds ProductRVSUM-1K23 ((i +XCMPLX-0K2 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 r)"
sorry

mtheorem rvsum_1_th_105:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds ProductRVSUM-1K23 ((i *XCMPLX-0K3 j) |->FINSEQ-2K2 r) =HIDDENR1 ProductRVSUM-1K23 (j  |->FINSEQ-2K2 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r))"
sorry

mtheorem rvsum_1_th_106:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (r1 *XCMPLX-0K3 r2)) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r1) *XCMPLX-0K3 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r2)"
sorry

mtheorem rvsum_1_th_107:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (mltRVSUM-1K19\<^bsub>(i)\<^esub>(R1,R2)) =HIDDENR1 ProductRVSUM-1K25 R1 *XCMPLX-0K3 ProductRVSUM-1K25 R2"
sorry

mtheorem rvsum_1_th_108:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for r be RealXREAL-0M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (r *RVSUM-1K13\<^bsub>(i)\<^esub> R) =HIDDENR1 ProductRVSUM-1K23 (i  |->FINSEQ-2K2 r) *XCMPLX-0K3 ProductRVSUM-1K25 R"
sorry

mtheorem rvsum_1_th_109:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of i -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ProductRVSUM-1K25 (sqrRVSUM-1K16\<^bsub>(i)\<^esub> R) =HIDDENR1 (ProductRVSUM-1K25 R)^2SQUARE-1K1"
  using rvsum_1_th_107 sorry

(*begin*)
reserve z, z1, z2 for "ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
mtheorem rvsum_1_th_110:
" for F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 F =XBOOLE-0R4 multcomplexBINOP-2K5 $$SETWOP-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
   sorry

mtheorem rvsum_1_th_111:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 ((i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) *XCMPLX-0K3 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z)"
sorry

mtheorem rvsum_1_th_112:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K24 ((i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z) =XBOOLE-0R4 ProductRVSUM-1K24 (j  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z))"
sorry

mlemma rvsum_1_lm_6:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
sorry

mtheorem rvsum_1_th_113:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ProductRVSUM-1K23 (i  |->FINSEQ-2K2 (z1 *XCMPLX-0K3 z2)) =HIDDENR1 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1) *XCMPLX-0K3 ProductRVSUM-1K24 (i  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2)"
sorry

(*begin*)
reserve n for "NatNAT-1M1"
reserve x, y, a for "RealXREAL-0M1"
reserve p, p1, p2, p3, q, q1, q2 for "ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
mtheorem rvsum_1_th_114:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (-RVSUM-1K7 x) =XBOOLE-0R4 lenFINSEQ-1K4 x"
sorry

mtheorem rvsum_1_th_115:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies lenFINSEQ-1K4 (x1 +RVSUM-1K5 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
sorry

mtheorem rvsum_1_th_116:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies lenFINSEQ-1K4 (x1 -RVSUM-1K9 x2) =XBOOLE-0R4 lenFINSEQ-1K4 x1"
sorry

mtheorem rvsum_1_th_117:
" for a be RealXREAL-0M1 holds  for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (a *RVSUM-1K12 x) =XBOOLE-0R4 lenFINSEQ-1K4 x"
sorry

mtheorem rvsum_1_th_118:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for z be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & lenFINSEQ-1K4 y =XBOOLE-0R4 lenFINSEQ-1K4 z implies mltRVSUM-1K18(x +RVSUM-1K5 y,z) =FINSEQ-1R1 mltRVSUM-1K18(x,z) +RVSUM-1K5 mltRVSUM-1K18(y,z)"
sorry

(*begin*)
mdef rvsum_1_def_16 (" |'(RVSUM-1K26 _ , _ ')|" [0,0]164 ) where
  mlet "x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"func  |(RVSUM-1K26 x1,x2 )| \<rightarrow> RealXREAL-0M1 equals
  SumRVSUM-1K22 (mltRVSUM-1K18(x1,x2))"
proof-
  (*coherence*)
    show "SumRVSUM-1K22 (mltRVSUM-1K18(x1,x2)) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem RVSUM_1K26_commutativity:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  |(RVSUM-1K26 x1,x2 )| =HIDDENR1  |(RVSUM-1K26 x2,x1 )|"
sorry

mtheorem rvsum_1_th_119:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  |(RVSUM-1K26 x,x )| >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem rvsum_1_th_120:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for z be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & lenFINSEQ-1K4 y =XBOOLE-0R4 lenFINSEQ-1K4 z implies  |(RVSUM-1K26 x +RVSUM-1K5 y,z )| =HIDDENR1  |(RVSUM-1K26 x,z )| +XCMPLX-0K2  |(RVSUM-1K26 y,z )|"
sorry

mtheorem rvsum_1_th_121:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for a be RealXREAL-0M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y implies  |(RVSUM-1K26 a *RVSUM-1K12 x,y )| =HIDDENR1 a *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|)"
sorry

mtheorem rvsum_1_th_122:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies  |(RVSUM-1K26 -RVSUM-1K7 x1,x2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 x1,x2 )|"
sorry

mtheorem rvsum_1_th_123:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 implies  |(RVSUM-1K26 -RVSUM-1K7 x1,-RVSUM-1K7 x2 )| =HIDDENR1  |(RVSUM-1K26 x1,x2 )|"
sorry

mtheorem rvsum_1_th_124:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 x3 implies  |(RVSUM-1K26 x1 -RVSUM-1K9 x2,x3 )| =HIDDENR1  |(RVSUM-1K26 x1,x3 )| -XCMPLX-0K6  |(RVSUM-1K26 x2,x3 )|"
sorry

mtheorem rvsum_1_th_125:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x3 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 x3 implies  |(RVSUM-1K26 x *RVSUM-1K12 x1 +RVSUM-1K5 y *RVSUM-1K12 x2,x3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 x1,x3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 x2,x3 )|)"
sorry

mtheorem rvsum_1_th_126:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1) & lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2 implies  |(RVSUM-1K26 x1 +RVSUM-1K5 x2,y1 +RVSUM-1K5 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| +XCMPLX-0K2  |(RVSUM-1K26 x1,y2 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
sorry

mtheorem rvsum_1_th_127:
" for x1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for x2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y1 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y2 be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 x1 =XBOOLE-0R4 lenFINSEQ-1K4 x2 & lenFINSEQ-1K4 x2 =XBOOLE-0R4 lenFINSEQ-1K4 y1) & lenFINSEQ-1K4 y1 =XBOOLE-0R4 lenFINSEQ-1K4 y2 implies  |(RVSUM-1K26 x1 -RVSUM-1K9 x2,y1 -RVSUM-1K9 y2 )| =HIDDENR1 (( |(RVSUM-1K26 x1,y1 )| -XCMPLX-0K6  |(RVSUM-1K26 x1,y2 )|)-XCMPLX-0K6  |(RVSUM-1K26 x2,y1 )|)+XCMPLX-0K2  |(RVSUM-1K26 x2,y2 )|"
sorry

mtheorem rvsum_1_th_128:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y implies  |(RVSUM-1K26 x +RVSUM-1K5 y,x +RVSUM-1K5 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
sorry

mtheorem rvsum_1_th_129:
" for x be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for y be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y implies  |(RVSUM-1K26 x -RVSUM-1K9 y,x -RVSUM-1K9 y )| =HIDDENR1 ( |(RVSUM-1K26 x,x )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 x,y )|))+XCMPLX-0K2  |(RVSUM-1K26 y,y )|"
sorry

mtheorem rvsum_1_th_130:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| +XCMPLX-0K2  |(RVSUM-1K26 p2,p3 )|"
sorry

mtheorem rvsum_1_th_131:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p2 )|)"
sorry

mtheorem rvsum_1_th_132:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,p2 )| =HIDDENR1 -XCMPLX-0K4  |(RVSUM-1K26 p1,p2 )|"
sorry

mtheorem rvsum_1_th_133:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 -RVSUM-1K8\<^bsub>(n)\<^esub> p1,-RVSUM-1K8\<^bsub>(n)\<^esub> p2 )| =HIDDENR1  |(RVSUM-1K26 p1,p2 )|"
sorry

mtheorem rvsum_1_th_134:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1  |(RVSUM-1K26 p1,p3 )| -XCMPLX-0K6  |(RVSUM-1K26 p2,p3 )|"
sorry

mtheorem rvsum_1_th_135:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p3 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 x *RVSUM-1K13\<^bsub>(n)\<^esub> p1 +RVSUM-1K6\<^bsub>(n)\<^esub> y *RVSUM-1K13\<^bsub>(n)\<^esub> p2,p3 )| =HIDDENR1 x *XCMPLX-0K3 ( |(RVSUM-1K26 p1,p3 )|) +XCMPLX-0K2 y *XCMPLX-0K3 ( |(RVSUM-1K26 p2,p3 )|)"
sorry

mtheorem rvsum_1_th_136:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 +RVSUM-1K6\<^bsub>(n)\<^esub> p2,q1 +RVSUM-1K6\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| +XCMPLX-0K2  |(RVSUM-1K26 p1,q2 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
sorry

mtheorem rvsum_1_th_137:
" for n be NatNAT-1M1 holds  for p1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for p2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p1 -RVSUM-1K10\<^bsub>(n)\<^esub> p2,q1 -RVSUM-1K10\<^bsub>(n)\<^esub> q2 )| =HIDDENR1 (( |(RVSUM-1K26 p1,q1 )| -XCMPLX-0K6  |(RVSUM-1K26 p1,q2 )|)-XCMPLX-0K6  |(RVSUM-1K26 p2,q1 )|)+XCMPLX-0K2  |(RVSUM-1K26 p2,q2 )|"
sorry

mtheorem rvsum_1_th_138:
" for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p +RVSUM-1K6\<^bsub>(n)\<^esub> q,p +RVSUM-1K6\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
sorry

mtheorem rvsum_1_th_139:
" for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p -RVSUM-1K10\<^bsub>(n)\<^esub> q,p -RVSUM-1K10\<^bsub>(n)\<^esub> q )| =HIDDENR1 ( |(RVSUM-1K26 p,p )| -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ( |(RVSUM-1K26 p,q )|))+XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
sorry

mtheorem rvsum_1_th_140:
" for n be NatNAT-1M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  |(RVSUM-1K26 p,q )| <=XXREAL-0R1  |(RVSUM-1K26 p,p )| +XCMPLX-0K2  |(RVSUM-1K26 q,q )|"
sorry

mdef rvsum_1_def_17 ("'( _ , _ ')are-orthogonalRVSUM-1R1" [0,0]50 ) where
  mlet "p be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1", "q be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
"pred (p,q)are-orthogonalRVSUM-1R1 means
   |(RVSUM-1K26 p,q )| =HIDDENR1 0NUMBERSK6"..

mtheorem RVSUM_1R1_symmetry:
" for p be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for q be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds (p,q)are-orthogonalRVSUM-1R1 implies (q,p)are-orthogonalRVSUM-1R1"
sorry

mtheorem rvsum_1_th_141:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds  for p be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for q be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds (p,q)are-orthogonalRVSUM-1R1 implies (a *RVSUM-1K13\<^bsub>(n)\<^esub> p,q)are-orthogonalRVSUM-1R1"
sorry

mtheorem rvsum_1_th_142:
" for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  for r3 be RealXREAL-0M1 holds  for r4 be RealXREAL-0M1 holds SumRVSUM-1K20 (<*FINSEQ-4K7 r1,r2,r3,r4 *>) =HIDDENR1 ((r1 +XCMPLX-0K2 r2)+XCMPLX-0K2 r3)+XCMPLX-0K2 r4"
sorry

reserve f, g for "real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1"
mtheorem rvsum_1_th_143:
" for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 (sqrRVSUM-1K15 f) & domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (sqrRVSUM-1K15 f)"
sorry

mtheorem rvsum_1_th_144:
" for f be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds  for g be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds sqrRVSUM-1K15 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 sqrRVSUM-1K15 f ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> sqrRVSUM-1K15 g"
sorry

mtheorem rvsum_1_th_145:
" for F be real-valuedVALUED-0V7\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
sorry

mtheorem rvsum_1_th_146:
" for F be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1 holds F be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
  using rvsum_1_lm_6 sorry

mtheorem rvsum_1_cl_19:
  mlet "r be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster <*FINSEQ-1K10 r*> as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "<*FINSEQ-1K10 r*> be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem rvsum_1_cl_20:
  mlet "r1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster <*FINSEQ-1K11 r1,r2 *> as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "<*FINSEQ-1K11 r1,r2 *> be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem rvsum_1_cl_21:
  mlet "r1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "r3 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster <*FINSEQ-1K12 r1,r2,r3 *> as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "<*FINSEQ-1K12 r1,r2,r3 *> be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem rvsum_1_cl_22:
  mlet "f be natural-valuedVALUED-0V8\<bar>FinSequenceFINSEQ-1M1", "g be natural-valuedVALUED-0V8\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^FINSEQ-1K8 g as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f ^FINSEQ-1K8 g be natural-valuedVALUED-0V8"
sorry
qed "sorry"

end
