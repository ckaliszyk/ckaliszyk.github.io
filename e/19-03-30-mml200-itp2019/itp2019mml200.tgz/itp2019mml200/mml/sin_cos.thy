theory sin_cos
  imports nat_d comseq_3 fdiff_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve q, th, r for "RealXREAL-0M1"
reserve a, b, p for "RealXREAL-0M1"
reserve w, z for "ComplexXCMPLX-0M1"
reserve k, l, m, n, n1, n2 for "NatNAT-1M1"
reserve seq, seq1, seq2, cq1 for "Complex-SequenceCOMSEQ-1M1"
reserve rseq, rseq1, rseq2 for "Real-SequenceSEQ-1M1"
reserve hy1 for "0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
mdef sin_cos_def_1 ("CHKSIN-COSK1'( _ , _ ')" [0,0]164 ) where
  mlet "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func CHKSIN-COSK1(m,k) \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  \<one>\<^sub>M if m <=XXREAL-0R1 k otherwise 0NUMBERSK6"
proof-
  (*coherence*)
    show "(m <=XXREAL-0R1 k implies \<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) & ( not m <=XXREAL-0R1 k implies 0NUMBERSK6 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
sorry
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True "
sorry
qed "sorry"

mtheorem sin_cos_cl_1:
  mlet "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster CHKSIN-COSK1(m,k) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "CHKSIN-COSK1(m,k) be realXREAL-0V1"
    using sin_cos_def_1 sorry
qed "sorry"

theorem sin_cos_sch_1:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Ff2(x1,x2) be ComplexXCMPLX-0M1"
  shows " for k be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds (n <=XXREAL-0R1 k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff2(k,n)) & (n >XXREAL-0R4 k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
sorry

theorem sin_cos_sch_2:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Ff2(x1,x2) be RealXREAL-0M1"
  shows " for k be NatNAT-1M1 holds  ex rseq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds (n <=XXREAL-0R1 k implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff2(k,n)) & (n >XXREAL-0R4 k implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
sorry

mlemma sin_cos_lm_1:
"\<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
   sorry

mdef sin_cos_def_2 ("Prod-real-nSIN-COSK2" 164 ) where
"func Prod-real-nSIN-COSK2 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))) & (it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

abbreviation(input) SIN_COSK3(" _ !SIN-COSK3" [164]164) where
  "n !SIN-COSK3 \<equiv> n !NEWTONK2"

mtheorem sin_cos_def_3:
  mlet "n be NatNAT-1M1"
"redefine func n !SIN-COSK3 \<rightarrow> setHIDDENM2 equals
  (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 n !SIN-COSK3 iff it =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry
qed "sorry"

mdef sin_cos_def_4 (" _ ExpSeqSIN-COSK4" [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z ExpSeqSIN-COSK4 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_5 (" _ rExpSeqSIN-COSK5" [164]164 ) where
  mlet "a be RealXREAL-0M1"
"func a rExpSeqSIN-COSK5 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem sin_cos_th_1:
" for n be NatNAT-1M1 holds ((0NUMBERSK6)!SIN-COSK3 =COMPLEX1R1 \<one>\<^sub>M & n !SIN-COSK3 <>HIDDENR2 0NUMBERSK6) & (n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3 =COMPLEX1R1 (n !SIN-COSK3)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
  using sin_cos_def_2 sorry

mtheorem sin_cos_th_2:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (0NUMBERSK6 <XXREAL-0R3 k implies ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 k =COMPLEX1R1 k !SIN-COSK3) & (k <=XXREAL-0R1 m implies ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k) =COMPLEX1R1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3)"
sorry

mdef sin_cos_def_6 ("CoefSIN-COSK6  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func CoefSIN-COSK6 n \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_7 ("Coef-eSIN-COSK7  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func Coef-eSIN-COSK7 n \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_8 ("ShiftSIN-COSK8  _ " [164]164 ) where
  mlet "seq be Complex-SequenceCOMSEQ-1M1"
"func ShiftSIN-COSK8 seq \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)) & (it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_9 ("ExpanSIN-COSK9'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1"
"func ExpanSIN-COSK9(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_10 ("Expan-eSIN-COSK10'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1"
"func Expan-eSIN-COSK10(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_11 ("AlfaSIN-COSK11'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1"
"func AlfaSIN-COSK11(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_12 ("ConjSIN-COSK12'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "n be NatNAT-1M1"
"func ConjSIN-COSK12(n,a,b) \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_13 ("ConjSIN-COSK13'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1", "n be NatNAT-1M1"
"func ConjSIN-COSK13(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mlemma sin_cos_lm_2:
" for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds  for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds (p1 +XCMPLX-0K2 g1 *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (p1 *XCMPLX-0K3 p2 -XCMPLX-0K6 g1 *XCMPLX-0K3 g2)+XCMPLX-0K2 (p1 *XCMPLX-0K3 g2 +XCMPLX-0K2 p2 *XCMPLX-0K3 g1)*XCMPLX-0K3 (<i>COMPLEX1K8) & (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9 =COMPLEX1R1 p2 +XCMPLX-0K2 (-XCMPLX-0K4 g2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem sin_cos_th_3:
" for n be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) &  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem sin_cos_th_4:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds 0NUMBERSK6 <XXREAL-0R3 k implies (ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
sorry

mtheorem sin_cos_th_5:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
sorry

mtheorem sin_cos_th_6:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
sorry

mtheorem sin_cos_th_7:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds Expan-eSIN-COSK10(n,z,w) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))"
sorry

mtheorem sin_cos_th_8:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3) =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
sorry

mtheorem sin_cos_th_9:
"0cCOMPLEX1K6 ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2 & SumCOMSEQ-3K11 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) =COMPLEX1R1 1rCOMPLEX1K7"
sorry

mtheorem sin_cos_cl_2:
  mlet "z be ComplexXCMPLX-0M1"
"cluster z ExpSeqSIN-COSK4 as-term-is absolutely-summableCOMSEQ-3V2"
proof
(*coherence*)
  show "z ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2"
sorry
qed "sorry"

mtheorem sin_cos_th_10:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & (ExpanSIN-COSK9(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_11:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =COMPLEX1R1 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
sorry

mtheorem sin_cos_th_12:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
sorry

mtheorem sin_cos_th_13:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (Expan-eSIN-COSK10(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
sorry

mtheorem sin_cos_th_14:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
sorry

mtheorem sin_cos_th_15:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
sorry

mtheorem sin_cos_th_16:
" for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k & Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)) &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
sorry

mtheorem sin_cos_th_17:
" for z be ComplexXCMPLX-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
sorry

mtheorem sin_cos_th_18:
" for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem sin_cos_th_19:
" for z be ComplexXCMPLX-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & (n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem sin_cos_th_20:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem sin_cos_th_21:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p)"
sorry

mtheorem sin_cos_th_22:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0NUMBERSK6"
sorry

mlemma sin_cos_lm_3:
" for z be ComplexXCMPLX-0M1 holds  for w be ComplexXCMPLX-0M1 holds SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (w ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)"
sorry

(*begin*)
mdef sin_cos_def_14 ("expSIN-COSK14" 164 ) where
"func expSIN-COSK14 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it.  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)) & ( for z be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_15 ("expSIN-COSK15  _ " [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func expSIN-COSK15 z \<rightarrow> ComplexXCMPLX-0M1 equals
  (expSIN-COSK14).FUNCT-1K1 z"
proof-
  (*coherence*)
    show "(expSIN-COSK14).FUNCT-1K1 z be ComplexXCMPLX-0M1"
       sorry
qed "sorry"

abbreviation(input) SIN_COSK16("expSIN-COSK16  _ " [164]164) where
  "expSIN-COSK16 z \<equiv> expSIN-COSK15 z"

mtheorem sin_cos_add_1:
  mlet "z be ComplexXCMPLX-0M1"
"cluster expSIN-COSK15 z as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "expSIN-COSK15 z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem sin_cos_th_23:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds expSIN-COSK16 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (expSIN-COSK16 z1)*XCMPLX-0K3 (expSIN-COSK16 z2)"
sorry

(*begin*)
reserve d for "RealXREAL-0M1"
mdef sin_cos_def_16 ("sinSIN-COSK17" 164 ) where
"func sinSIN-COSK17 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_17 ("sinSIN-COSK18  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func sinSIN-COSK18 th \<rightarrow> numberORDINAL1M2 equals
  (sinSIN-COSK17).FUNCT-1K1 th"
proof-
  (*coherence*)
    show "(sinSIN-COSK17).FUNCT-1K1 th be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos_cl_3:
  mlet "th be RealXREAL-0M1"
"cluster sinSIN-COSK18 th as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "sinSIN-COSK18 th be realXREAL-0V1"
     sorry
qed "sorry"

mdef sin_cos_def_18 ("cosSIN-COSK19" 164 ) where
"func cosSIN-COSK19 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_19 ("cosSIN-COSK20  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func cosSIN-COSK20 th \<rightarrow> numberORDINAL1M2 equals
  (cosSIN-COSK19).FUNCT-1K1 th"
proof-
  (*coherence*)
    show "(cosSIN-COSK19).FUNCT-1K1 th be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos_cl_4:
  mlet "th be RealXREAL-0M1"
"cluster cosSIN-COSK20 th as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "cosSIN-COSK20 th be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem sin_cos_th_24:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) =XBOOLE-0R4 REALNUMBERSK2 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mlemma sin_cos_lm_4:
" for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem sin_cos_th_25:
" for th be RealXREAL-0M1 holds expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 cosSIN-COSK20 th +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mlemma sin_cos_lm_5:
" for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9 =COMPLEX1R1 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
sorry

mtheorem sin_cos_th_26:
" for th be RealXREAL-0M1 holds (expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9 =COMPLEX1R1 expSIN-COSK16 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))"
sorry

mlemma sin_cos_lm_6:
" for th be RealXREAL-0M1 holds  for th1 be RealXREAL-0M1 holds th =COMPLEX1R1 th1 implies ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| =COMPLEX1R1 \<one>\<^sub>M &  |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M) &  |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_27:
" for th be RealXREAL-0M1 holds  |.COMPLEX1K10 expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) .| =COMPLEX1R1 \<one>\<^sub>M & ( for th be RealXREAL-0M1 holds  |.COMPLEX1K10 sinSIN-COSK18 th .| <=XXREAL-0R1 \<one>\<^sub>M &  |.COMPLEX1K10 cosSIN-COSK20 th .| <=XXREAL-0R1 \<one>\<^sub>M)"
sorry

reserve th, th1, th2 for "RealXREAL-0M1"
mtheorem sin_cos_th_28:
" for th be RealXREAL-0M1 holds ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_29:
" for th be RealXREAL-0M1 holds (cosSIN-COSK20 th)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 th)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M & (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =COMPLEX1R1 \<one>\<^sub>M"
  using sin_cos_th_28 sorry

mtheorem sin_cos_th_30:
" for th be RealXREAL-0M1 holds (((cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
sorry

mtheorem sin_cos_th_31:
" for th be RealXREAL-0M1 holds ((cosSIN-COSK20 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & sinSIN-COSK18 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) & cosSIN-COSK20 (-XCMPLX-0K4 th) =COMPLEX1R1 cosSIN-COSK20 th) & sinSIN-COSK18 (-XCMPLX-0K4 th) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 th"
  using sin_cos_th_30 sorry

mdef sin_cos_def_20 (" _ P-sinSIN-COSK21" [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func th P-sinSIN-COSK21 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_21 (" _ P-cosSIN-COSK22" [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func th P-cosSIN-COSK22 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem sin_cos_th_32:
" for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 k) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k"
sorry

mtheorem sin_cos_th_33:
" for k be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

(*\$CT*)
mtheorem sin_cos_th_35:
" for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n)"
sorry

mtheorem sin_cos_th_36:
" for th be RealXREAL-0M1 holds ((Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) be convergentCOMSEQ-2V3 & SumSERIES-1K4 (th P-sinSIN-COSK21) =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) be convergentCOMSEQ-2V3) & SumSERIES-1K4 (th P-cosSIN-COSK22) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
sorry

mtheorem sin_cos_th_37:
" for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-cosSIN-COSK22) & (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-sinSIN-COSK21)"
sorry

mtheorem sin_cos_th_38:
" for p be RealXREAL-0M1 holds  for th be RealXREAL-0M1 holds  for rseq be Real-SequenceSEQ-1M1 holds (rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq =COMPLEX1R1 th) & ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 p) implies th >=XXREAL-0R2 p"
  using prepower_th_1 sorry

mlemma sin_cos_lm_7:
" for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds  for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 (th  |^COMSEQ-3K2 n) |^COMSEQ-3K2 \<two>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 \<one>\<^sub>M) & (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_39:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 k implies n !SIN-COSK3 <=XXREAL-0R1 k !SIN-COSK3"
sorry

mtheorem sin_cos_th_40:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 th & th <=XXREAL-0R1 \<one>\<^sub>M) & n <=XXREAL-0R1 k implies th  |^COMSEQ-3K2 k <=XXREAL-0R1 th  |^COMSEQ-3K2 n"
sorry

(*\$CT*)
mtheorem sin_cos_th_42:
" for p be RealXREAL-0M1 holds ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem sin_cos_th_43:
"((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_44:
" for th be RealXREAL-0M1 holds th rExpSeqSIN-COSK5 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4)"
sorry

mtheorem sin_cos_th_45:
" for th be RealXREAL-0M1 holds th rExpSeqSIN-COSK5 be summableSERIES-1V1 & SumSERIES-1K4 (th rExpSeqSIN-COSK5) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
sorry

mlemma sin_cos_lm_8:
" for n be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =COMPLEX1R1 z & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7) &  |.COMPLEX1K10 z  |^COMSEQ-3K2 n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
sorry

mlemma sin_cos_lm_9:
" for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =COMPLEX1R1 SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
sorry

mtheorem sin_cos_th_46:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds SumSERIES-1K4 ((p +XCMPLX-0K2 q)rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
sorry

mdef sin_cos_def_22 ("exp-RSIN-COSK23" 164 ) where
"func exp-RSIN-COSK23 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_23 ("exp-RSIN-COSK24  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func exp-RSIN-COSK24 th \<rightarrow> numberORDINAL1M2 equals
  (exp-RSIN-COSK23).FUNCT-1K1 th"
proof-
  (*coherence*)
    show "(exp-RSIN-COSK23).FUNCT-1K1 th be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos_cl_5:
  mlet "th be RealXREAL-0M1"
"cluster exp-RSIN-COSK24 th as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "exp-RSIN-COSK24 th be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem sin_cos_th_47:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mtheorem sin_cos_th_48:
" for th be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 th =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
sorry

mtheorem sin_cos_th_49:
" for th be RealXREAL-0M1 holds expSIN-COSK16 th =COMPLEX1R1 exp-RSIN-COSK24 th"
sorry

mlemma sin_cos_lm_10:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
sorry

mtheorem sin_cos_th_50:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds exp-RSIN-COSK24 (p +XCMPLX-0K2 q) =COMPLEX1R1 (exp-RSIN-COSK24 p)*XCMPLX-0K3 (exp-RSIN-COSK24 q)"
  using sin_cos_lm_10 sorry

mlemma sin_cos_lm_11:
"(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_51:
"exp-RSIN-COSK24 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
  using sin_cos_lm_11 sorry

mtheorem sin_cos_th_52:
" for th be RealXREAL-0M1 holds th >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_53:
" for th be RealXREAL-0M1 holds th <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3 (exp-RSIN-COSK23).FUNCT-1K1 th & (exp-RSIN-COSK23).FUNCT-1K1 th <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem sin_cos_th_54:
" for th be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos_th_55:
" for th be RealXREAL-0M1 holds exp-RSIN-COSK24 th >XXREAL-0R4 0NUMBERSK6"
  using sin_cos_th_54 sorry

(*begin*)
mdef sin_cos_def_24 (" _ P-dtSIN-COSK25" [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z P-dtSIN-COSK25 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef sin_cos_def_25 (" _ P-tSIN-COSK26" [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z P-tSIN-COSK26 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
sorry
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mlemma sin_cos_lm_12:
" for p be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds ((ReCOMPLEX1K3 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) =COMPLEX1R1 -XCMPLX-0K4 p *XCMPLX-0K3 ImCOMPLEX1K4 z & ImCOMPLEX1K4 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ReCOMPLEX1K3 z) & ReCOMPLEX1K3 (p *XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ReCOMPLEX1K3 z) & ImCOMPLEX1K4 (p *XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ImCOMPLEX1K4 z"
sorry

mlemma sin_cos_lm_13:
" for p be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies (ReCOMPLEX1K3 (z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 ImCOMPLEX1K4 z /XCMPLX-0K7 p & ImCOMPLEX1K4 (z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 -XCMPLX-0K4 ReCOMPLEX1K3 z /XCMPLX-0K7 p) &  |.COMPLEX1K10 z /XCMPLX-0K7 p .| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 p"
sorry

mtheorem sin_cos_th_56:
" for z be ComplexXCMPLX-0M1 holds z P-dtSIN-COSK25 be absolutely-summableCOMSEQ-3V2"
sorry

mtheorem sin_cos_th_57:
" for z be ComplexXCMPLX-0M1 holds z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25) =COMPLEX1R1 (SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 1rCOMPLEX1K7)-XCMPLX-0K6 z"
sorry

mtheorem sin_cos_th_58:
" for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex q be RealXREAL-0M1 st q >XXREAL-0R4 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 q implies  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p))"
sorry

mtheorem sin_cos_th_59:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds SumCOMSEQ-3K11 ((z1 +XCMPLX-0K2 z)ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 z +XCMPLX-0K2 (z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4)"
sorry

mtheorem sin_cos_th_60:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 p =COMPLEX1R1 (-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)-XCMPLX-0K6 q *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
sorry

mtheorem sin_cos_th_61:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
sorry

mtheorem sin_cos_th_62:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25)"
sorry

mtheorem sin_cos_th_63:
" for p be RealXREAL-0M1 holds cosSIN-COSK19 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(cosSIN-COSK19,p) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 p"
sorry

mtheorem sin_cos_th_64:
" for p be RealXREAL-0M1 holds sinSIN-COSK17 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinSIN-COSK17,p) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 p"
sorry

mtheorem sin_cos_th_65:
" for p be RealXREAL-0M1 holds exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(exp-RSIN-COSK23,p) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p"
sorry

mtheorem sin_cos_th_66:
" for th be RealXREAL-0M1 holds exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(exp-RSIN-COSK23,th) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 th"
sorry

mtheorem sin_cos_th_67:
" for th be RealXREAL-0M1 holds cosSIN-COSK19 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(cosSIN-COSK19,th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
sorry

mtheorem sin_cos_th_68:
" for th be RealXREAL-0M1 holds sinSIN-COSK17 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinSIN-COSK17,th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th"
sorry

mtheorem sin_cos_th_69:
" for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies 0NUMBERSK6 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
sorry

mdef sin_cos_def_26 ("tanSIN-COSK27" 164 ) where
"func tanSIN-COSK27 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  (sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
proof-
  (*coherence*)
    show "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef sin_cos_def_27 ("cotSIN-COSK28" 164 ) where
"func cotSIN-COSK28 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  (cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
proof-
  (*coherence*)
    show "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem sin_cos_th_70:
"[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) & ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
sorry

mlemma sin_cos_lm_14:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] & ( for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 th =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th)"
sorry

mlemma sin_cos_lm_15:
"tanSIN-COSK27 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & ( for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ implies diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6)"
sorry

mtheorem sin_cos_th_71:
"(tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) be continuousFCONT-1V1"
sorry

mtheorem sin_cos_th_72:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & th2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[) & (tanSIN-COSK27).FUNCT-1K1 th1 =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th2 implies th1 =COMPLEX1R1 th2"
sorry

mlemma sin_cos_lm_16:
"(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
sorry

(*begin*)
mdef sin_cos_def_28 ("PISIN-COSK29" 164 ) where
"func PISIN-COSK29 \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. (tanSIN-COSK27).FUNCT-1K1 (it /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st (tanSIN-COSK27).FUNCT-1K1 (it /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
sorry
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ((tanSIN-COSK27).FUNCT-1K1 (it1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .[) & ((tanSIN-COSK27).FUNCT-1K1 (it2 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .[) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem sin_cos_th_73:
"(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
sorry

(*begin*)
mtheorem sin_cos_th_74:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2 & (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
sorry

mtheorem sin_cos_th_75:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) & cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
  using sin_cos_th_74 sorry

mtheorem sin_cos_th_76:
"(((((((cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) =COMPLEX1R1 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6) & (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 \<one>\<^sub>M) & (sinSIN-COSK17).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem sin_cos_th_77:
"((((((cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6 & sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M) & cosSIN-COSK20 (PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & sinSIN-COSK18 (PISIN-COSK29) =COMPLEX1R1 0NUMBERSK6) & cosSIN-COSK20 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6) & sinSIN-COSK18 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 \<one>\<^sub>M) & sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 0NUMBERSK6"
  using sin_cos_th_76 sorry

mtheorem sin_cos_th_78:
" for th be RealXREAL-0M1 holds (((((((sinSIN-COSK17).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th) & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
sorry

mtheorem sin_cos_th_79:
" for th be RealXREAL-0M1 holds ((((((sinSIN-COSK18 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 sinSIN-COSK18 th & cosSIN-COSK20 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 cosSIN-COSK20 th) & sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 cosSIN-COSK20 th) & cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 sinSIN-COSK18 th) & sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 cosSIN-COSK20 th) & cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 th) & sinSIN-COSK18 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 th) & cosSIN-COSK20 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 th"
  using sin_cos_th_78 sorry

mlemma sin_cos_lm_17:
" for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies (sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem sin_cos_th_80:
" for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (cosSIN-COSK19).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem sin_cos_th_81:
" for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies cosSIN-COSK20 th >XXREAL-0R4 0NUMBERSK6"
  using sin_cos_th_80 sorry

(*begin*)
mtheorem sin_cos_th_82:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 b) =COMPLEX1R1 (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
sorry

mtheorem sin_cos_th_83:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds cosSIN-COSK20 (a -XCMPLX-0K6 b) =COMPLEX1R1 (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
sorry

mtheorem sin_cos_cl_6:
"cluster sinSIN-COSK17 as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "sinSIN-COSK17 be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem sin_cos_cl_7:
"cluster cosSIN-COSK19 as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "cosSIN-COSK19 be continuousFCONT-1V1"
sorry
qed "sorry"

mtheorem sin_cos_cl_8:
"cluster exp-RSIN-COSK23 as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "exp-RSIN-COSK23 be continuousFCONT-1V1"
sorry
qed "sorry"

end
