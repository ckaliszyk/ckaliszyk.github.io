theory rolle
  imports fdiff_1 xxreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve g, r, s, p, t, x, x0, x1, x2 for "RealXREAL-0M1"
reserve n, n1 for "NatORDINAL1M6"
reserve s1, s2, s3 for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem rolle_th_1:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f .FUNCT-1K1 p =XBOOLE-0R4 f .FUNCT-1K1 g) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 0NUMBERSK6))"
sorry

(*\$N Rolle Theorem*)
mtheorem rolle_th_2:
" for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (x +XCMPLX-0K2 t)) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t) =HIDDENR1 0NUMBERSK6))"
sorry

(*\$N The Mean Value Theorem*)
mtheorem rolle_th_3:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 p)/XCMPLX-0K7 (g -XCMPLX-0K6 p)))"
sorry

(*\$N Lagrange Theorem*)
mtheorem rolle_th_4:
" for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t))))"
sorry

mtheorem rolle_th_5:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds p <XXREAL-0R3 g implies ( for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ implies ( ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ & (f1 .FUNCT-1K1 g -XCMPLX-0K6 f1 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f2,x0)) =XBOOLE-0R4 (f2 .FUNCT-1K1 g -XCMPLX-0K6 f2 .FUNCT-1K1 p)*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))))"
sorry

(*\$N Cauchy Theorem*)
mtheorem rolle_th_6:
" for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies ( for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((((([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & [.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[) & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies diffFDIFF-1K1(f2,x1) <>HIDDENR2 0NUMBERSK6) implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & (f1 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f2 .FUNCT-1K1 x) =XBOOLE-0R4 (diffFDIFF-1K1(f1,x +XCMPLX-0K2 s *XCMPLX-0K3 t))/XCMPLX-0K7 (diffFDIFF-1K1(f2,x +XCMPLX-0K2 s *XCMPLX-0K3 t))))"
sorry

mtheorem rolle_th_7:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) =HIDDENR1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
sorry

mtheorem rolle_th_8:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f2 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f1,x) =HIDDENR1 diffFDIFF-1K1(f2,x)) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5 & ( ex r be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x +XCMPLX-0K2 r)"
sorry

mtheorem rolle_th_9:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9"
sorry

mtheorem rolle_th_10:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10"
sorry

mtheorem rolle_th_11:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-decreasingVALUED-0V11"
sorry

mtheorem rolle_th_12:
" for p be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be non-increasingVALUED-0V12"
sorry

end
