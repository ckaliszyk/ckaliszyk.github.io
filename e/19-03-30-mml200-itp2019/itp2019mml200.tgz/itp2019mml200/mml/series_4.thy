theory series_4
  imports series_3 wsierp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n for "NatNAT-1M1"
reserve a, b, c, d for "RealXREAL-0M1"
reserve s for "Real-SequenceSEQ-1M1"
mlemma series_4_lm_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds \<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M & (a +XCMPLX-0K2 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
sorry

mlemma series_4_lm_2:
" for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
sorry

mlemma series_4_lm_3:
" for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
sorry

mlemma series_4_lm_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M"
sorry

mlemma series_4_lm_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
sorry

mlemma series_4_lm_6:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 \<one>\<^sub>M implies (((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
sorry

mlemma series_4_lm_7:
" for n be NatNAT-1M1 holds \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem series_4_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
sorry

mtheorem series_4_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
sorry

mtheorem series_4_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
sorry

mtheorem series_4_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
sorry

mtheorem series_4_th_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
sorry

mtheorem series_4_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 \<four>\<^sub>M =HIDDENR1 (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M"
sorry

mtheorem series_4_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 d))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 d"
sorry

mtheorem series_4_th_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b))+XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
sorry

mtheorem series_4_th_9:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
sorry

mtheorem series_4_th_10:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
sorry

mtheorem series_4_th_11:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds (a <>HIDDENR2 \<one>\<^sub>M & a <>HIDDENR2 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
sorry

mtheorem series_4_th_12:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
sorry

mtheorem series_4_th_13:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
sorry

mtheorem series_4_th_14:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
sorry

mtheorem series_4_th_15:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)"
sorry

mtheorem series_4_th_16:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)"
sorry

mtheorem series_4_th_17:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)"
sorry

mtheorem series_4_th_18:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem series_4_th_19:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 a  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
sorry

mtheorem series_4_th_20:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 n)) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem series_4_th_21:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem series_4_th_22:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 n +XCMPLX-0K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))"
sorry

mtheorem series_4_th_23:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M))"
sorry

mtheorem series_4_th_24:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)"
sorry

mtheorem series_4_th_25:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
sorry

mtheorem series_4_th_26:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
sorry

mtheorem series_4_th_27:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n !NEWTONK7)"
sorry

mtheorem series_4_th_28:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a /XCMPLX-0K7 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7))"
sorry

mtheorem series_4_th_29:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n)"
sorry

mtheorem series_4_th_30:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 n  |^NEWTONK1 \<two>\<^sub>M & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))"
sorry

end
