theory rpr_1
  imports real_1 finseq_1 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve a for "ElementSUBSET-1M1-of E"
reserve A, B for "SubsetSUBSET-1M2-of E"
reserve Y for "setHIDDENM2"
reserve p for "FinSequenceFINSEQ-1M1"
mtheorem rpr_1_th_1:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of E holds e be SingletonCARD-1M2-of E iff ( for Y be setHIDDENM2 holds Y c=TARSKIR1 e iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 e)"
sorry

mtheorem rpr_1_cl_1:
  mlet "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for SingletonCARD-1M2-of E"
proof
(*coherence*)
  show " for it be SingletonCARD-1M2-of E holds it be finiteFINSET-1V1"
     sorry
qed "sorry"

reserve e, e1, e2 for "SingletonCARD-1M2-of E"
mtheorem rpr_1_th_2:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for e be SingletonCARD-1M2-of E holds e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B & A <>HIDDENR2 B implies A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e or A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem rpr_1_th_3:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for e be SingletonCARD-1M2-of E holds e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B implies (A =XBOOLE-0R4 e & B =XBOOLE-0R4 e or A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1) or A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e"
sorry

mtheorem rpr_1_th_4:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of E holds {DOMAIN-1K6\<^bsub>(E)\<^esub> a} be SingletonCARD-1M2-of E"
   sorry

mtheorem rpr_1_th_5:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e1 be SingletonCARD-1M2-of E holds  for e2 be SingletonCARD-1M2-of E holds e1 c=TARSKIR1 e2 implies e1 =XBOOLE-0R4 e2"
  using rpr_1_th_1 sorry

mtheorem rpr_1_th_6:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  ex a be ElementSUBSET-1M1-of E st a inTARSKIR2 E & e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}"
sorry

mtheorem rpr_1_th_7:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex e be SingletonCARD-1M2-of E st e be SingletonCARD-1M2-of E"
sorry

mtheorem rpr_1_th_8:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  ex p be FinSequenceFINSEQ-1M1 st (p be FinSequenceFINSEQ-1M3-of E & rngFUNCT-1K2 p =XBOOLE-0R4 e) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
sorry

abbreviation(input) RPR_1M1("EventRPR-1M1-of  _ " [70]70) where
  "EventRPR-1M1-of E \<equiv> SubsetSUBSET-1M2-of E"

mtheorem rpr_1_th_9:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  for A be EventRPR-1M1-of E holds e missesXBOOLE-0R1 A or e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 e"
sorry

mtheorem rpr_1_th_10:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds A <>HIDDENR2 {}XBOOLE-0K1 implies ( ex e be SingletonCARD-1M2-of E st e c=TARSKIR1 A)"
sorry

mtheorem rpr_1_th_11:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  for A be EventRPR-1M1-of E holds e c=TARSKIR1 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> implies e c=TARSKIR1 A or e c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
sorry

mtheorem rpr_1_th_12:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e1 be SingletonCARD-1M2-of E holds  for e2 be SingletonCARD-1M2-of E holds e1 =XBOOLE-0R4 e2 or e1 missesSUBSET-1R1 e2"
sorry

mtheorem rpr_1_th_13:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B missesXBOOLE-0R1 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
sorry

mlemma rpr_1_lm_1:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E"
sorry

mdef rpr_1_def_1 ("probRPR-1K1\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2", "A be EventRPR-1M1-of E"
"func probRPR-1K1\<^bsub>(E)\<^esub> A \<rightarrow> RealXREAL-0M1 equals
  cardCARD-1K4 A /XCMPLX-0K7 cardCARD-1K4 E"
proof-
  (*coherence*)
    show "cardCARD-1K4 A /XCMPLX-0K7 cardCARD-1K4 E be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rpr_1_th_14:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds probRPR-1K1\<^bsub>(E)\<^esub> e =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 cardCARD-1K4 E"
  using card_1_def_7 sorry

mtheorem rpr_1_th_15:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds probRPR-1K1\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =HIDDENR1 \<one>\<^sub>M"
  using xcmplx_1_th_60 sorry

mtheorem rpr_1_th_16:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B implies probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 0NUMBERSK6"
  using card_1_th_27 sorry

mtheorem rpr_1_th_17:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem rpr_1_th_18:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds 0NUMBERSK6 <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A"
sorry

mtheorem rpr_1_th_19:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A c=TARSKIR1 B implies probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> B"
sorry

mtheorem rpr_1_th_20:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
sorry

mtheorem rpr_1_th_21:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B implies probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B"
sorry

mtheorem rpr_1_th_22:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> & probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A"
sorry

mtheorem rpr_1_th_23:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
sorry

mtheorem rpr_1_th_24:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds B c=TARSKIR1 A implies probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B"
sorry

mtheorem rpr_1_th_25:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B"
sorry

mtheorem rpr_1_th_26:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
sorry

mtheorem rpr_1_th_27:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A)"
sorry

mtheorem rpr_1_th_28:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =XBOOLE-0R4 probRPR-1K1\<^bsub>(E)\<^esub> B +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> A)"
sorry

mtheorem rpr_1_th_29:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
sorry

mtheorem rpr_1_th_30:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds (A missesXBOOLE-0R1 B & A missesXBOOLE-0R1 C) & B missesXBOOLE-0R1 C implies probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C"
sorry

mtheorem rpr_1_th_31:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)"
sorry

mdef rpr_1_def_2 ("probRPR-1K2\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2", "B be EventRPR-1M1-of E", "A be EventRPR-1M1-of E"
"func probRPR-1K2\<^bsub>(E)\<^esub>(A,B) \<rightarrow> RealXREAL-0M1 equals
  (probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
proof-
  (*coherence*)
    show "(probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rpr_1_th_32:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K2\<^bsub>(E)\<^esub>(A,[#]SUBSET-1K2 E) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A"
sorry

mtheorem rpr_1_th_33:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds probRPR-1K2\<^bsub>(E)\<^esub>([#]SUBSET-1K2 E,[#]SUBSET-1K2 E) =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem rpr_1_th_34:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem rpr_1_th_35:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies 0NUMBERSK6 <=XXREAL-0R1 probRPR-1K2\<^bsub>(E)\<^esub>(A,B)"
sorry

mtheorem rpr_1_th_36:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
sorry

mtheorem rpr_1_th_37:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & A c=TARSKIR1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
sorry

mtheorem rpr_1_th_38:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 0NUMBERSK6"
sorry

mtheorem rpr_1_th_39:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,A)) =XBOOLE-0R4 (probRPR-1K1\<^bsub>(E)\<^esub> B)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))"
sorry

mtheorem rpr_1_th_40:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) & probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A,B)"
sorry

mtheorem rpr_1_th_41:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & B c=TARSKIR1 A implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem rpr_1_th_42:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>([#]SUBSET-1K2 E,B) =HIDDENR1 \<one>\<^sub>M"
  using rpr_1_th_41 sorry

mtheorem rpr_1_th_43:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,A) =HIDDENR1 0NUMBERSK6"
sorry

mtheorem rpr_1_th_44:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K2\<^bsub>(E)\<^esub>(A,A `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 0NUMBERSK6"
sorry

mtheorem rpr_1_th_45:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem rpr_1_th_46:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M) & A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
sorry

mtheorem rpr_1_th_47:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M) & A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
sorry

mtheorem rpr_1_th_48:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> C implies probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,C)))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> C)"
sorry

mtheorem rpr_1_th_49:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
sorry

mtheorem rpr_1_th_50:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds ((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2 implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2)"
sorry

mtheorem rpr_1_th_51:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds  for B3 be EventRPR-1M1-of E holds (((((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3 implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3)"
sorry

mtheorem rpr_1_th_52:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds ((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2 implies probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))"
sorry

mtheorem rpr_1_th_53:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds  for B3 be EventRPR-1M1-of E holds (((((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3 implies probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 (((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3))"
sorry

mdef rpr_1_def_3 ("'( _ , _ ')are-independentRPR-1R1\<^bsub>'( _ ')\<^esub>" [0,0,0]50 ) where
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2", "A be EventRPR-1M1-of E", "B be EventRPR-1M1-of E"
"pred (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> means
  probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)"..

mtheorem RPR_1R1_symmetry:
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2"
" for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies (B,A)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
sorry

mtheorem rpr_1_th_54:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A"
sorry

mtheorem rpr_1_th_55:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> B =HIDDENR1 0NUMBERSK6 implies (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
sorry

mtheorem rpr_1_th_56:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies (A `SUBSET-1K3\<^bsub>(E)\<^esub>,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
sorry

mtheorem rpr_1_th_57:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B & (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 0NUMBERSK6 or probRPR-1K1\<^bsub>(E)\<^esub> B =HIDDENR1 0NUMBERSK6"
  using rpr_1_th_16 xcmplx_1_th_6 sorry

end
