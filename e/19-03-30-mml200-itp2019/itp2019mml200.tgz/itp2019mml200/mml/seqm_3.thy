theory seqm_3
  imports finseq_3 seq_1 rfunct_1 recdef_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "NatNAT-1M1"
reserve r, r1 for "RealXREAL-0M1"
reserve f, seq, seq1 for "Real-SequenceSEQ-1M1"
mlemma seqm_3_lm_1:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies ( ex k be NatNAT-1M1 st m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
sorry

mlemma seqm_3_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k))) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

mlemma seqm_3_lm_3:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

mlemma seqm_3_lm_4:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
sorry

mlemma seqm_3_lm_5:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
sorry

abbreviation(input) SEQM_3V1("increasingSEQM-3V1" 70) where
  "increasingSEQM-3V1 \<equiv> increasingVALUED-0V9"

mtheorem seqm_3_def_1:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr increasingSEQM-3V1 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m <XXREAL-0R3 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be increasingSEQM-3V1 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m <XXREAL-0R3 f .FUNCT-1K1 n)"
sorry
qed "sorry"

abbreviation(input) SEQM_3V2("decreasingSEQM-3V2" 70) where
  "decreasingSEQM-3V2 \<equiv> decreasingVALUED-0V10"

mtheorem seqm_3_def_2:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr decreasingSEQM-3V2 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m >XXREAL-0R4 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be decreasingSEQM-3V2 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m >XXREAL-0R4 f .FUNCT-1K1 n)"
sorry
qed "sorry"

abbreviation(input) SEQM_3V3("non-decreasingSEQM-3V3" 70) where
  "non-decreasingSEQM-3V3 \<equiv> non-decreasingVALUED-0V11"

mtheorem seqm_3_def_3:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr non-decreasingSEQM-3V3 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m <=XXREAL-0R1 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be non-decreasingSEQM-3V3 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m <=XXREAL-0R1 f .FUNCT-1K1 n)"
sorry
qed "sorry"

abbreviation(input) SEQM_3V4("non-increasingSEQM-3V4" 70) where
  "non-increasingSEQM-3V4 \<equiv> non-increasingVALUED-0V12"

mtheorem seqm_3_def_4:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr non-increasingSEQM-3V4 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m >=XXREAL-0R2 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be non-increasingSEQM-3V4 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m >=XXREAL-0R2 f .FUNCT-1K1 n)"
sorry
qed "sorry"

mdef seqm_3_def_5 ("monotoneSEQM-3V5" 70 ) where
"attr monotoneSEQM-3V5 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq. seq be non-decreasingSEQM-3V3 or seq be non-increasingSEQM-3V4)"..

mtheorem seqm_3_th_1:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V1 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
sorry

mtheorem seqm_3_th_2:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V1 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k))"
  using seqm_3_lm_2 sorry

mtheorem seqm_3_th_3:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V2 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_lm_3 sorry

mtheorem seqm_3_th_4:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V2 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem seqm_3_th_5:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))"
  using seqm_3_lm_4 sorry

mtheorem seqm_3_th_6:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
sorry

mtheorem seqm_3_th_7:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_lm_5 sorry

mtheorem seqm_3_th_8:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem seqm_3_th_9:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V1 implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_th_1 sorry

mtheorem seqm_3_th_10:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V2 implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
  using seqm_3_th_4 sorry

mtheorem seqm_3_th_11:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_th_6 sorry

mtheorem seqm_3_th_12:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
  using seqm_3_th_8 sorry

mtheorem seqm_3_cl_1:
"cluster constantFUNCT-1V5 also-is non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 for PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4"
     sorry
qed "sorry"

mtheorem seqm_3_cl_2:
"cluster non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 also-is constantFUNCT-1V5 for PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) holds it be non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 implies it be constantFUNCT-1V5"
sorry
qed "sorry"

mlemma seqm_3_lm_6:
"idPARTFUN1K6 NATNUMBERSK1 be increasingSEQM-3V1\<bar>natural-valuedVALUED-0V8"
   sorry

mtheorem seqm_3_cl_3:
"cluster increasingSEQM-3V1\<bar>natural-valuedVALUED-0V8 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be increasingSEQM-3V1\<bar>natural-valuedVALUED-0V8"
sorry
qed "sorry"

mtheorem seqm_3_cl_4:
"cluster increasingSEQM-3V1 for sequenceNAT-1M2-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be sequenceNAT-1M2-of NATNUMBERSK1 st it be increasingSEQM-3V1"
    using seqm_3_lm_6 sorry
qed "sorry"

mlemma seqm_3_lm_7:
" for f be sequenceNAT-1M2-of NATNUMBERSK1 holds f be increasingSEQM-3V1 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
   sorry

reserve Nseq for "increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mtheorem seqm_3_th_13:
" for seq be Real-SequenceSEQ-1M1 holds seq be sequenceNAT-1M2-of NATNUMBERSK1 iff ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1)"
sorry

mtheorem seqm_3_cl_5:
  mlet "Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1", "k be NatNAT-1M1"
"cluster Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k as-term-is increasingVALUED-0V9\<bar>natural-valuedVALUED-0V8 for ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k implies it be increasingVALUED-0V9\<bar>natural-valuedVALUED-0V8"
sorry
qed "sorry"

abbreviation(input) SEQM_3V6("increasingSEQM-3V6" 70) where
  "increasingSEQM-3V6 \<equiv> increasingVALUED-0V9"

mtheorem seqm_3_def_6:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr increasingSEQM-3V6 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be increasingSEQM-3V6 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
sorry
qed "sorry"

abbreviation(input) SEQM_3V7("decreasingSEQM-3V7" 70) where
  "decreasingSEQM-3V7 \<equiv> decreasingVALUED-0V10"

mtheorem seqm_3_def_7:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr decreasingSEQM-3V7 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be decreasingSEQM-3V7 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
sorry
qed "sorry"

abbreviation(input) SEQM_3V8("non-decreasingSEQM-3V8" 70) where
  "non-decreasingSEQM-3V8 \<equiv> non-decreasingVALUED-0V11"

mtheorem seqm_3_def_8:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr non-decreasingSEQM-3V8 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be non-decreasingSEQM-3V8 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
sorry
qed "sorry"

abbreviation(input) SEQM_3V9("non-increasingSEQM-3V9" 70) where
  "non-increasingSEQM-3V9 \<equiv> non-increasingVALUED-0V12"

mtheorem seqm_3_def_9:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr non-increasingSEQM-3V9 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be non-increasingSEQM-3V9 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
sorry
qed "sorry"

mtheorem seqm_3_th_14:
" for Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n"
sorry

mtheorem seqm_3_cl_6:
  mlet "s be Real-SequenceSEQ-1M1", "k be NatNAT-1M1"
"cluster s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem seqm_3_th_15:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
sorry

mtheorem seqm_3_th_16:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
sorry

mtheorem seqm_3_th_17:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
sorry

mtheorem seqm_3_th_18:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
sorry

mtheorem seqm_3_th_19:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
sorry

mtheorem seqm_3_th_20:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
sorry

mtheorem seqm_3_th_21:
" for k be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
sorry

mtheorem seqm_3_th_22:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V6 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be increasingSEQM-3V6"
sorry

mtheorem seqm_3_th_23:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V7 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be decreasingSEQM-3V7"
sorry

mtheorem seqm_3_th_24:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V8 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be non-decreasingSEQM-3V8"
sorry

mtheorem seqm_3_th_25:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V9 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be non-increasingSEQM-3V9"
sorry

mtheorem seqm_3_th_26:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be monotoneSEQM-3V5"
  using seqm_3_th_25 seqm_3_th_24 sorry

mtheorem seqm_3_th_27:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be bounded-aboveSEQ-2V3"
sorry

mtheorem seqm_3_th_28:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be bounded-belowSEQ-2V4"
sorry

mtheorem seqm_3_th_29:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be boundedSEQ-2V6 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be boundedSEQ-2V6"
  using seqm_3_th_27 seqm_3_th_28 sorry

mtheorem seqm_3_th_30:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ((seq be increasingSEQM-3V6 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6) & (0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15)) & (seq be increasingSEQM-3V6 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7)"
sorry

mtheorem seqm_3_th_31:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be decreasingSEQM-3V7 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7) & (seq be decreasingSEQM-3V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6)"
sorry

mtheorem seqm_3_th_32:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V8 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8) & (seq be non-decreasingSEQM-3V8 & r <=XXREAL-0R1 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9)"
sorry

mtheorem seqm_3_th_33:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be non-increasingSEQM-3V9 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9) & (seq be non-increasingSEQM-3V9 & r <=XXREAL-0R1 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8)"
sorry

mtheorem seqm_3_th_34:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (((seq be increasingSEQM-3V6 & seq1 be increasingSEQM-3V6 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6) & (seq be decreasingSEQM-3V7 & seq1 be decreasingSEQM-3V7 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7)) & (seq be non-decreasingSEQM-3V8 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8)) & (seq be non-increasingSEQM-3V9 & seq1 be non-increasingSEQM-3V9 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9)"
sorry

mtheorem seqm_3_th_35:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (((seq be increasingSEQM-3V6 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6) & (seq be decreasingSEQM-3V7 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7)) & (seq be non-decreasingSEQM-3V8 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8)) & (seq be non-increasingSEQM-3V9 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9)"
sorry

mtheorem seqm_3_th_36:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ((seq be bounded-aboveSEQ-2V3 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-aboveSEQ-2V3) & (0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & (seq be bounded-aboveSEQ-2V3 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-belowSEQ-2V4)"
sorry

mtheorem seqm_3_th_37:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be boundedSEQ-2V6 implies ( for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & (seq be boundedSEQ-2V6 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & (seq be boundedSEQ-2V6 iff absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)"
sorry

mtheorem seqm_3_th_38:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be non-increasingSEQM-3V9 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-aboveSEQ-2V3"
sorry

mtheorem seqm_3_th_39:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-belowSEQ-2V4"
sorry

mtheorem seqm_3_cl_7:
"cluster note-that natural-valuedVALUED-0V8 for FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds it be natural-valuedVALUED-0V8"
     sorry
qed "sorry"

(*begin*)
reserve v for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
reserve r, s for "RealXREAL-0M1"
reserve n, m, i, j, k for "NatNAT-1M1"
(*\$CT*)
mtheorem seqm_3_th_41:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M iff r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
sorry

mtheorem seqm_3_th_42:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M iff  |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j"
sorry

mtheorem seqm_3_th_43:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M iff ( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6)"
sorry

mtheorem seqm_3_th_44:
" for f be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds (lenFINSEQ-1K4 f =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & n inTARSKIR2 domFINSEQ-1K5 f) & k inTARSKIR2 SegFINSEQ-1K2 m implies (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 k or (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
sorry

abbreviation(input) SEQM_3V10("constantSEQM-3V10" 70) where
  "constantSEQM-3V10 \<equiv> constantFUNCT-1V5"

mtheorem seqm_3_def_10:
  mlet "f be FinSequenceFINSEQ-1M1"
"redefine attr constantSEQM-3V10 for FinSequenceFINSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 n =XBOOLE-0R4 f .FUNCT-1K1 m)"
proof
(*compatibility*)
  show " for f be FinSequenceFINSEQ-1M1 holds f be constantSEQM-3V10 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 n =XBOOLE-0R4 f .FUNCT-1K1 m)"
sorry
qed "sorry"

mtheorem seqm_3_cl_8:
"cluster note-that real-valuedVALUED-0V7 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem seqm_3_cl_9:
"cluster  non emptyXBOOLE-0V1\<bar>increasingSEQM-3V1 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>increasingSEQM-3V1"
sorry
qed "sorry"

mtheorem seqm_3_cl_10:
"cluster constantSEQM-3V10 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st it be constantSEQM-3V10"
sorry
qed "sorry"

mtheorem seqm_3_th_45:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds (((((((v <>HIDDENR2 {}XBOOLE-0K1 & rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n) & v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s))) & i inTARSKIR2 SegFINSEQ-1K2 n) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n) & m inTARSKIR2 domFINSEQ-1K5 v) & v .FUNCT-1K1 m =COMPLEX1R1 i) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i implies k <=XXREAL-0R1 m) implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem seqm_3_th_46:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds (((v <>HIDDENR2 {}XBOOLE-0K1 & rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n) & v .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M) & v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s)) implies ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i)) & ( for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds ((((m inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 m =COMPLEX1R1 i) & ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 j =COMPLEX1R1 i implies j <=XXREAL-0R1 m)) & m <XXREAL-0R3 k) & k inTARSKIR2 domFINSEQ-1K5 v) & r =COMPLEX1R1 v .FUNCT-1K1 k implies i <XXREAL-0R3 r)"
sorry

end
