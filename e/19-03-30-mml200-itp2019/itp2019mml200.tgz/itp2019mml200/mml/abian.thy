theory abian
  imports seq_4 eqrel_1 funct_7 scheme1 realset1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, E, E1, E2, E3 for "setHIDDENM2"
reserve sE for "Subset-FamilySETFAM-1M1-of E"
reserve f for "FunctionFUNCT-2M1-of(E,E)"
reserve k, l, m, n for "NatNAT-1M1"
mdef abian_def_1 ("evenABIANV1" 70 ) where
"attr evenABIANV1 for IntegerINT-1M1 means
  (\<lambda>i. \<two>\<^sub>M dividesINT-1R1 i)"..

syntax ABIANV2 :: "Ty" ("oddABIANV2" 70)
translations "oddABIANV2" \<rightharpoonup> " non evenABIANV1"

mlemma abian_lm_1:
" for i be IntegerINT-1M1 holds i be evenABIANV1 iff ( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j)"
  using int_1_def_3 sorry

abbreviation(input) ABIANV3("evenABIANV3" 70) where
  "evenABIANV3 \<equiv> evenABIANV1"

mtheorem abian_def_2:
  mlet "n be NatNAT-1M1"
"redefine attr evenABIANV3 for NatNAT-1M1 means
  (\<lambda>n.  ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)"
proof
(*compatibility*)
  show " for n be NatNAT-1M1 holds n be evenABIANV3 iff ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)"
sorry
qed "sorry"

mtheorem abian_cl_1:
"cluster evenABIANV3 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be evenABIANV3"
sorry
qed "sorry"

mtheorem abian_cl_2:
"cluster oddABIANV2 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_3:
"cluster evenABIANV3 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be evenABIANV3"
sorry
qed "sorry"

mtheorem abian_cl_4:
"cluster oddABIANV2 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_5:
"cluster evenABIANV1 for IntegerINT-1M1"
proof
(*existence*)
  show " ex it be IntegerINT-1M1 st it be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_6:
"cluster oddABIANV2 for IntegerINT-1M1"
proof
(*existence*)
  show " ex it be IntegerINT-1M1 st it be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_th_1:
" for i be IntegerINT-1M1 holds i be oddABIANV2 iff ( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M)"
sorry

mtheorem abian_cl_7:
  mlet "i be IntegerINT-1M1"
"cluster \<two>\<^sub>M *XCMPLX-0K3 i as-term-is evenABIANV1"
proof
(*coherence*)
  show "\<two>\<^sub>M *XCMPLX-0K3 i be evenABIANV1"
    using abian_lm_1 sorry
qed "sorry"

mtheorem abian_cl_8:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 \<one>\<^sub>M as-term-is oddABIANV2"
proof
(*coherence*)
  show "i +XCMPLX-0K2 \<one>\<^sub>M be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_9:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 \<one>\<^sub>M as-term-is evenABIANV1"
proof
(*coherence*)
  show "i +XCMPLX-0K2 \<one>\<^sub>M be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_10:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 \<one>\<^sub>M as-term-is oddABIANV2"
proof
(*coherence*)
  show "i -XCMPLX-0K6 \<one>\<^sub>M be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_11:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 \<one>\<^sub>M as-term-is evenABIANV1"
proof
(*coherence*)
  show "i -XCMPLX-0K6 \<one>\<^sub>M be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_12:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be IntegerINT-1M1"
"cluster i *XCMPLX-0K3 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i *XCMPLX-0K3 j be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_13:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be IntegerINT-1M1"
"cluster j *XCMPLX-0K3 i as-term-is evenABIANV1"
proof
(*coherence*)
  show "j *XCMPLX-0K3 i be evenABIANV1"
     sorry
qed "sorry"

mtheorem abian_cl_14:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i *XCMPLX-0K3 j as-term-is oddABIANV2"
proof
(*coherence*)
  show "i *XCMPLX-0K3 j be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_15:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be evenABIANV1\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i +XCMPLX-0K2 j be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_16:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 j as-term-is oddABIANV2"
proof
(*coherence*)
  show "i +XCMPLX-0K2 j be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_17:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster j +XCMPLX-0K2 i as-term-is oddABIANV2"
proof
(*coherence*)
  show "j +XCMPLX-0K2 i be oddABIANV2"
     sorry
qed "sorry"

mtheorem abian_cl_18:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i +XCMPLX-0K2 j be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_19:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 j as-term-is oddABIANV2"
proof
(*coherence*)
  show "i -XCMPLX-0K6 j be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_20:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster j -XCMPLX-0K6 i as-term-is oddABIANV2"
proof
(*coherence*)
  show "j -XCMPLX-0K6 i be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_21:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i -XCMPLX-0K6 j be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_22:
  mlet "m be evenABIANV1\<bar>IntegerINT-1M1"
"cluster m +XCMPLX-0K2 \<two>\<^sub>M as-term-is evenABIANV1"
proof
(*coherence*)
  show "m +XCMPLX-0K2 \<two>\<^sub>M be evenABIANV1"
sorry
qed "sorry"

mtheorem abian_cl_23:
  mlet "m be oddABIANV2\<bar>IntegerINT-1M1"
"cluster m +XCMPLX-0K2 \<two>\<^sub>M as-term-is oddABIANV2"
proof
(*coherence*)
  show "m +XCMPLX-0K2 \<two>\<^sub>M be oddABIANV2"
sorry
qed "sorry"

syntax ABIANK1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("iterABIANK1\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164)
translations "iterABIANK1\<^bsub>(E)\<^esub>(f,n)" \<rightharpoonup> "iterFUNCT-7K8(f,n)"

mtheorem abian_add_1:
  mlet "E be setHIDDENM2", "f be FunctionFUNCT-2M1-of(E,E)", "n be NatNAT-1M1"
"cluster iterFUNCT-7K8(f,n) as-term-is FunctionFUNCT-2M1-of(E,E)"
proof
(*coherence*)
  show "iterFUNCT-7K8(f,n) be FunctionFUNCT-2M1-of(E,E)"
    using funct_7_th_83 sorry
qed "sorry"

mtheorem abian_th_2:
" for S be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 holds 0NUMBERSK6 inTARSKIR2 S implies minSEQ-4K4 S =XBOOLE-0R4 0NUMBERSK6"
  using xxreal_2_def_7 sorry

mtheorem abian_th_3:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for x be ElementSUBSET-1M1-of E holds (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 x"
sorry

mdef abian_def_3 (" _ is-a-fixpoint-ofABIANR1  _ " [50,50]50 ) where
  mlet "x be objectHIDDENM1", "f be FunctionFUNCT-1M1"
"pred x is-a-fixpoint-ofABIANR1 f means
  x inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 x"..

syntax ABIANR2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ is-a-fixpoint-ofABIANR2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "a is-a-fixpoint-ofABIANR2\<^bsub>(A)\<^esub> f" \<rightharpoonup> "a is-a-fixpoint-ofABIANR1 f"

mtheorem abian_def_4:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "a be ElementSUBSET-1M1-of A", "f be FunctionFUNCT-2M1-of(A,A)"
"redefine pred a is-a-fixpoint-ofABIANR2\<^bsub>(A)\<^esub> f means
  a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
proof
(*compatibility*)
  show "a is-a-fixpoint-ofABIANR2\<^bsub>(A)\<^esub> f iff a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
sorry
qed "sorry"

mdef abian_def_5 ("with-fixpointABIANV4" 70 ) where
"attr with-fixpointABIANV4 for FunctionFUNCT-1M1 means
  (\<lambda>f.  ex x be objectHIDDENM1 st x is-a-fixpoint-ofABIANR1 f)"..

syntax ABIANV5 :: "Ty" ("without-fixpointsABIANV5" 70)
translations "without-fixpointsABIANV5" \<rightharpoonup> " non with-fixpointABIANV4"

mdef abian_def_6 ("coveringABIANV6\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr coveringABIANV6\<^bsub>(X)\<^esub> for ElementSUBSET-1M1-of X means
  (\<lambda>x. unionTARSKIK3 x =XBOOLE-0R4 unionTARSKIK3 (unionTARSKIK3 X))"..

mtheorem abian_th_4:
" for E be setHIDDENM2 holds  for sE be Subset-FamilySETFAM-1M1-of E holds sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub> iff unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E"
sorry

mtheorem abian_cl_24:
  mlet "E be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub> for Subset-FamilySETFAM-1M1-of E"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of E st it be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>"
sorry
qed "sorry"

mtheorem abian_th_5:
" for E be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for sE be  non emptyXBOOLE-0V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>\<bar>Subset-FamilySETFAM-1M1-of E holds ( for X be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of sE holds X missesXBOOLE-0R1 f .:FUNCT-1K5 X) implies f be without-fixpointsABIANV5"
sorry

mdef abian_def_7 ("=-ABIANK2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "E be setHIDDENM2", "f be FunctionFUNCT-2M1-of(E,E)"
"func =-ABIANK2\<^bsub>(E)\<^esub> f \<rightarrow> Equivalence-RelationEQREL-1M2-of E means
  \<lambda>it.  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))"
proof-
  (*existence*)
    show " ex it be Equivalence-RelationEQREL-1M2-of E st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))"
sorry
  (*uniqueness*)
    show " for it1 be Equivalence-RelationEQREL-1M2-of E holds  for it2 be Equivalence-RelationEQREL-1M2-of E holds ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it1 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it2 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem abian_th_6:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds  for e be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 c"
sorry

mtheorem abian_th_7:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds  for e be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds  for n be NatNAT-1M1 holds (iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 c"
sorry

mtheorem abian_cl_25:
"cluster empty-memberedSETFAM-1V2 also-is trivialSUBSET-1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be empty-memberedSETFAM-1V2 implies it be trivialSUBSET-1V2"
     sorry
qed "sorry"

mtheorem abian_cl_26:
  mlet "A be setHIDDENM2", "B be with-non-empty-elementSETFAM-1V3\<bar>setHIDDENM2"
"cluster non-emptyFUNCT-1V4 for FunctionFUNCT-2M1-of(A,B)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(A,B) st it be non-emptyFUNCT-1V4"
sorry
qed "sorry"

mtheorem abian_cl_27:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be with-non-empty-elementSETFAM-1V3\<bar>setHIDDENM2", "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-2M1-of(A,B)", "a be ElementSUBSET-1M1-of A"
"cluster f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mtheorem abian_cl_28:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is with-non-empty-elementSETFAM-1V3"
proof
(*coherence*)
  show "boolSETFAM-1K9 X be with-non-empty-elementSETFAM-1V3"
sorry
qed "sorry"

mtheorem abian_th_8:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds f be without-fixpointsABIANV5 implies ( ex E1 be setHIDDENM2 st  ex E2 be setHIDDENM2 st  ex E3 be setHIDDENM2 st (((E1 \\/XBOOLE-0K2 E2)\\/XBOOLE-0K2 E3 =XBOOLE-0R4 E & f .:FUNCT-1K5 E1 missesXBOOLE-0R1 E1) & f .:FUNCT-1K5 E2 missesXBOOLE-0R1 E2) & f .:FUNCT-1K5 E3 missesXBOOLE-0R1 E3)"
sorry

(*begin*)
mtheorem abian_th_9:
" for n be NatNAT-1M1 holds n be oddABIANV2 iff ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem abian_th_10:
" for n be NatNAT-1M1 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,A) holds  for x be ElementSUBSET-1M1-of A holds (iterABIANK1\<^bsub>(A)\<^esub>(f,n +NAT-1K1 \<one>\<^sub>M)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> ((iterABIANK1\<^bsub>(A)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x)"
sorry

mtheorem abian_th_11:
" for i be IntegerINT-1M1 holds i be evenABIANV1 iff ( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j)"
  using abian_lm_1 sorry

mtheorem abian_cl_29:
"cluster oddABIANV2 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be oddABIANV2"
sorry
qed "sorry"

mtheorem abian_cl_30:
"cluster evenABIANV3 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be evenABIANV3"
sorry
qed "sorry"

mtheorem abian_th_12:
" for n be oddABIANV2\<bar>NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n"
sorry

mtheorem abian_cl_31:
"cluster oddABIANV2 also-is  non zeroORDINAL1V8 for IntegerINT-1M1"
proof
(*coherence*)
  show " for it be IntegerINT-1M1 holds it be oddABIANV2 implies it be  non zeroORDINAL1V8"
    using abian_th_12 sorry
qed "sorry"

end
