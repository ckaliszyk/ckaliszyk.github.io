theory rewrite1
  imports wellord1 eqrel_1 pboole finseq_5 trees_2
   "../mizar_extension/E_number"
begin
(*begin*)
mdef rewrite1_def_1 (" _ $^REWRITE1K1  _ " [164,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"func p $^REWRITE1K1 q \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. it =FINSEQ-1R1 p ^FINSEQ-1K8 q if p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 otherwise \<lambda>it.  ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it =FINSEQ-1R1 r ^FINSEQ-1K8 q"
proof-
  (*existence*)
    show "(p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 implies ( ex it be FinSequenceFINSEQ-1M1 st it =FINSEQ-1R1 p ^FINSEQ-1K8 q)) & ( not (p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1) implies ( ex it be FinSequenceFINSEQ-1M1 st  ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it =FINSEQ-1R1 r ^FINSEQ-1K8 q))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 implies (it1 =FINSEQ-1R1 p ^FINSEQ-1K8 q & it2 =FINSEQ-1R1 p ^FINSEQ-1K8 q implies it1 =HIDDENR1 it2)) & ( not (p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1) implies (( ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it1 =FINSEQ-1R1 r ^FINSEQ-1K8 q) & ( ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it2 =FINSEQ-1R1 r ^FINSEQ-1K8 q) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
qed "sorry"

mlemma rewrite1_lm_1:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds x inTARSKIR2 domFINSEQ-1K5 p implies (x <=XXREAL-0R1 lenFINSEQ-1K4 p & x >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma rewrite1_lm_2:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies x <XXREAL-0R3 lenFINSEQ-1K4 p"
sorry

mlemma rewrite1_lm_3:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds (x <=XXREAL-0R1 lenFINSEQ-1K4 p or x <XXREAL-0R3 lenFINSEQ-1K4 p) & (x >=XXREAL-0R2 \<one>\<^sub>M or x >XXREAL-0R4 0NUMBERSK6) implies x inTARSKIR2 domFINSEQ-1K5 p"
sorry

mlemma rewrite1_lm_4:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds x <XXREAL-0R3 lenFINSEQ-1K4 p implies x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
sorry

reserve p, q, r for "FinSequenceFINSEQ-1M1"
reserve x, y for "objectHIDDENM1"
mtheorem rewrite1_th_1:
" for p be FinSequenceFINSEQ-1M1 holds {}XBOOLE-0K1 $^REWRITE1K1 p =FINSEQ-1R1 p & p $^REWRITE1K1 {}XBOOLE-0K1 =FINSEQ-1R1 p"
sorry

mtheorem rewrite1_th_2:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 q =FINSEQ-1R1 p ^FINSEQ-1K8 q"
sorry

mtheorem rewrite1_th_3:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 ((<*FINSEQ-1K10 y*>)^FINSEQ-1K8 q) =FINSEQ-1R1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 q"
sorry

mtheorem rewrite1_th_4:
" for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies (<*FINSEQ-1K10 x*>)$^REWRITE1K1 q =FINSEQ-1R1 q"
sorry

mtheorem rewrite1_th_5:
" for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
sorry

theorem rewrite1_sch_1:
  fixes pf0 qf0 Pp2 
  assumes
[ty]: "pf0 be FinSequenceFINSEQ-1M1" and
  [ty]: "qf0 be FinSequenceFINSEQ-1M1" and
   A1: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 pf0 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 pf0 implies Pp2(pf0 .FUNCT-1K1 i,pf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))" and
   A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 qf0 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 qf0 implies Pp2(qf0 .FUNCT-1K1 i,qf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))" and
   A3: "(lenFINSEQ-1K4 pf0 >XXREAL-0R4 0NUMBERSK6 & lenFINSEQ-1K4 qf0 >XXREAL-0R4 0NUMBERSK6) & pf0 .FUNCT-1K1 lenFINSEQ-1K4 pf0 =XBOOLE-0R4 qf0 .FUNCT-1K1 \<one>\<^sub>M"
  shows " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (pf0 $^REWRITE1K1 qf0) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (pf0 $^REWRITE1K1 qf0) implies ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x =XBOOLE-0R4 (pf0 $^REWRITE1K1 qf0).FUNCT-1K1 i & y =XBOOLE-0R4 (pf0 $^REWRITE1K1 qf0).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies Pp2(x,y))"
sorry

mdef rewrite1_def_2 ("RedSequenceREWRITE1M1-of  _ " [70]70 ) where
  mlet "R be RelationRELAT-1M1"
"mode RedSequenceREWRITE1M1-of R \<rightarrow> FinSequenceFINSEQ-1M1 means
  (\<lambda>it. lenFINSEQ-1K4 it >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 it implies [TARSKIK4 it .FUNCT-1K1 i,it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 it implies [TARSKIK4 it .FUNCT-1K1 i,it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
sorry
qed "sorry"

mtheorem rewrite1_cl_1:
  mlet "R be RelationRELAT-1M1"
"cluster note-that  non emptyXBOOLE-0V1 for RedSequenceREWRITE1M1-of R"
proof
(*coherence*)
  show " for it be RedSequenceREWRITE1M1-of R holds it be  non emptyXBOOLE-0V1"
    using rewrite1_def_2 card_1_th_27 sorry
qed "sorry"

mtheorem rewrite1_th_6:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds <*FINSEQ-1K10 a*> be RedSequenceREWRITE1M1-of R"
sorry

mtheorem rewrite1_th_7:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies <*FINSEQ-1K11 a,b *> be RedSequenceREWRITE1M1-of R"
sorry

mtheorem rewrite1_th_8:
" for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds  for q be RedSequenceREWRITE1M1-of R holds p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M implies p $^REWRITE1K1 q be RedSequenceREWRITE1M1-of R"
sorry

mtheorem rewrite1_th_9:
" for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds RevFINSEQ-5K3 p be RedSequenceREWRITE1M1-of R ~RELAT-1K4"
sorry

mtheorem rewrite1_th_10:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies ( for p be RedSequenceREWRITE1M1-of R holds p be RedSequenceREWRITE1M1-of Q)"
sorry

(*begin*)
mdef rewrite1_def_3 (" _ reducesREWRITE1R1'( _ , _ ')" [50,0,0]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred R reducesREWRITE1R1(a,b) means
   ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"..

mdef rewrite1_def_4 ("'( _ , _ ')are-convertible-wrtREWRITE1R2  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-convertible-wrtREWRITE1R2 R means
  R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"..

mtheorem rewrite1_th_11:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
sorry

mtheorem rewrite1_th_12:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds R reducesREWRITE1R1(a,a)"
sorry

mtheorem rewrite1_th_13:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds {}XBOOLE-0K1 reducesREWRITE1R1(a,b) implies a =HIDDENR1 b"
sorry

mtheorem rewrite1_th_14:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) &  not a inHIDDENR3 fieldRELAT-1K3 R implies a =HIDDENR1 b"
sorry

mtheorem rewrite1_th_15:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies R reducesREWRITE1R1(a,b)"
sorry

mtheorem rewrite1_th_16:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(b,c) implies R reducesREWRITE1R1(a,c)"
sorry

mtheorem rewrite1_th_17:
" for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p & j inTARSKIR2 domFINSEQ-1K5 p) & i <=XXREAL-0R1 j implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 j)"
sorry

mtheorem rewrite1_th_18:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & a <>HIDDENR2 b implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
sorry

mtheorem rewrite1_th_19:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies (a inHIDDENR3 fieldRELAT-1K3 R iff b inHIDDENR3 fieldRELAT-1K3 R)"
  using rewrite1_th_18 sorry

mtheorem rewrite1_th_20:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff a =HIDDENR1 b or [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19"
sorry

mtheorem rewrite1_th_21:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b)"
sorry

mtheorem rewrite1_th_22:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies Q reducesREWRITE1R1(a,b))"
sorry

mtheorem rewrite1_th_23:
" for R be RelationRELAT-1M1 holds  for X be setHIDDENM2 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff R \\/XBOOLE-0K2 idRELAT-1K7 X reducesREWRITE1R1(a,b)"
sorry

mtheorem rewrite1_th_24:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies R ~RELAT-1K4 reducesREWRITE1R1(b,a)"
sorry

mlemma rewrite1_lm_5:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (b,a)are-convertible-wrtREWRITE1R2 R"
sorry

mtheorem rewrite1_th_25:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies (a,b)are-convertible-wrtREWRITE1R2 R & (b,a)are-convertible-wrtREWRITE1R2 R"
sorry

mtheorem rewrite1_th_26:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds (a,a)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_th_12 sorry

mtheorem rewrite1_th_27:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 {}XBOOLE-0K1 implies a =HIDDENR1 b"
  using rewrite1_th_13 sorry

mtheorem rewrite1_th_28:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R &  not a inHIDDENR3 fieldRELAT-1K3 R implies a =HIDDENR1 b"
sorry

mtheorem rewrite1_th_29:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
sorry

mtheorem rewrite1_th_30:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R & (b,c)are-convertible-wrtREWRITE1R2 R implies (a,c)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_th_16 sorry

mtheorem rewrite1_th_31:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (b,a)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_lm_5 sorry

mtheorem rewrite1_th_32:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R & a <>HIDDENR2 b implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
sorry

mdef rewrite1_def_5 (" _ is-a-normal-form-wrtREWRITE1R3  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1"
"pred a is-a-normal-form-wrtREWRITE1R3 R means
   not ( ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 R)"..

mtheorem rewrite1_th_33:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,b) implies a =HIDDENR1 b"
sorry

mtheorem rewrite1_th_34:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  not a inHIDDENR3 fieldRELAT-1K3 R implies a is-a-normal-form-wrtREWRITE1R3 R"
  using relat_1_th_15 sorry

mdef rewrite1_def_6 (" _ is-a-normal-form-ofREWRITE1R4'( _ , _ ')" [50,0,0]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred b is-a-normal-form-ofREWRITE1R4(a,R) means
  b is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,b)"..

mdef rewrite1_def_7 ("'( _ , _ ')are-convergent-wrtREWRITE1R5  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-convergent-wrtREWRITE1R5 R means
   ex c be objectHIDDENM1 st R reducesREWRITE1R1(a,c) & R reducesREWRITE1R1(b,c)"..

mdef rewrite1_def_8 ("'( _ , _ ')are-divergent-wrtREWRITE1R6  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-divergent-wrtREWRITE1R6 R means
   ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"..

mdef rewrite1_def_9 ("'( _ , _ ')are-convergent<=1-wrtREWRITE1R7  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-convergent<=1-wrtREWRITE1R7 R means
   ex c be objectHIDDENM1 st ([TARSKIK4 a,c ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 b,c ] inHIDDENR3 R or b =HIDDENR1 c)"..

mdef rewrite1_def_10 ("'( _ , _ ')are-divergent<=1-wrtREWRITE1R8  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-divergent<=1-wrtREWRITE1R8 R means
   ex c be objectHIDDENM1 st ([TARSKIK4 c,a ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 c,b ] inHIDDENR3 R or b =HIDDENR1 c)"..

mtheorem rewrite1_th_35:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  not a inHIDDENR3 fieldRELAT-1K3 R implies a is-a-normal-form-ofREWRITE1R4(a,R)"
  using rewrite1_th_12 rewrite1_th_34 sorry

mtheorem rewrite1_th_36:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies (((a,b)are-convergent-wrtREWRITE1R5 R & (a,b)are-divergent-wrtREWRITE1R6 R) & (b,a)are-convergent-wrtREWRITE1R5 R) & (b,a)are-divergent-wrtREWRITE1R6 R"
sorry

mtheorem rewrite1_th_37:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent-wrtREWRITE1R5 R or (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
sorry

mtheorem rewrite1_th_38:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds (a,a)are-convergent-wrtREWRITE1R5 R & (a,a)are-divergent-wrtREWRITE1R6 R"
  using rewrite1_th_12 sorry

mtheorem rewrite1_th_39:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 or (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1 implies a =HIDDENR1 b"
sorry

mtheorem rewrite1_th_40:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent-wrtREWRITE1R5 R implies (b,a)are-convergent-wrtREWRITE1R5 R"
   sorry

mtheorem rewrite1_th_41:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (b,a)are-divergent-wrtREWRITE1R6 R"
   sorry

mtheorem rewrite1_th_42:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & (b,c)are-convergent-wrtREWRITE1R5 R or (a,b)are-convergent-wrtREWRITE1R5 R & R reducesREWRITE1R1(c,b) implies (a,c)are-convergent-wrtREWRITE1R5 R"
sorry

mtheorem rewrite1_th_43:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(b,a) & (b,c)are-divergent-wrtREWRITE1R6 R or (a,b)are-divergent-wrtREWRITE1R6 R & R reducesREWRITE1R1(b,c) implies (a,c)are-divergent-wrtREWRITE1R6 R"
sorry

mtheorem rewrite1_th_44:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent<=1-wrtREWRITE1R7 R implies (a,b)are-convergent-wrtREWRITE1R5 R"
sorry

mtheorem rewrite1_th_45:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent<=1-wrtREWRITE1R8 R implies (a,b)are-divergent-wrtREWRITE1R6 R"
sorry

mdef rewrite1_def_11 (" _ has-a-normal-form-wrtREWRITE1R9  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1"
"pred a has-a-normal-form-wrtREWRITE1R9 R means
   ex b be objectHIDDENM1 st b is-a-normal-form-ofREWRITE1R4(a,R)"..

mtheorem rewrite1_th_46:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  not a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R"
  using rewrite1_th_35 sorry

mdef rewrite1_def_12 ("nfREWRITE1K2'( _ , _ ')" [0,0]164 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1"
"assume a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c) func nfREWRITE1K2(a,R) \<rightarrow> setHIDDENM2 means
  \<lambda>it. it is-a-normal-form-ofREWRITE1R4(a,R)"
proof-
  (*existence*)
    show "a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c) implies ( ex it be setHIDDENM2 st it is-a-normal-form-ofREWRITE1R4(a,R))"
sorry
  (*uniqueness*)
    show "a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c) implies ( for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds it1 is-a-normal-form-ofREWRITE1R4(a,R) & it2 is-a-normal-form-ofREWRITE1R4(a,R) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

(*begin*)
mdef rewrite1_def_13 ("co-well-foundedREWRITE1V1" 70 ) where
"attr co-well-foundedREWRITE1V1 for RelationRELAT-1M1 means
  (\<lambda>R. R ~RELAT-1K4 be well-foundedWELLORD1V1)"..

mdef rewrite1_def_14 ("weakly-normalizingREWRITE1V2" 70 ) where
"attr weakly-normalizingREWRITE1V2 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R)"..

mdef rewrite1_def_15 ("strongly-normalizingREWRITE1V3" 70 ) where
"attr strongly-normalizingREWRITE1V3 for RelationRELAT-1M1 means
  (\<lambda>R.  for f be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  ex i be NatNAT-1M1 st  not [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"..

abbreviation(input) REWRITE1V4("co-well-foundedREWRITE1V4" 70) where
  "co-well-foundedREWRITE1V4 \<equiv> co-well-foundedREWRITE1V1"

mtheorem rewrite1_def_16:
  mlet "R be RelationRELAT-1M1"
"redefine attr co-well-foundedREWRITE1V4 for RelationRELAT-1M1 means
  (\<lambda>R.  for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R)))"
proof
(*compatibility*)
  show " for R be RelationRELAT-1M1 holds R be co-well-foundedREWRITE1V4 iff ( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R)))"
sorry
qed "sorry"

theorem rewrite1_sch_2:
  fixes Rf0 Pp1 
  assumes
[ty]: "Rf0 be RelationRELAT-1M1" and
   A1: "Rf0 be co-well-foundedREWRITE1V4" and
   A2: " for a be objectHIDDENM1 holds ( for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Rf0 & a <>HIDDENR2 b implies Pp1(b)) implies Pp1(a)"
  shows " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 Rf0 implies Pp1(a)"
sorry

mtheorem rewrite1_cl_2:
"cluster strongly-normalizingREWRITE1V3 also-is irreflexiveRELAT-2V2\<bar>co-well-foundedREWRITE1V4 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-normalizingREWRITE1V3 implies it be irreflexiveRELAT-2V2\<bar>co-well-foundedREWRITE1V4"
sorry
qed "sorry"

mtheorem rewrite1_cl_3:
"cluster co-well-foundedREWRITE1V4\<bar>irreflexiveRELAT-2V2 also-is strongly-normalizingREWRITE1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be co-well-foundedREWRITE1V4\<bar>irreflexiveRELAT-2V2 implies it be strongly-normalizingREWRITE1V3"
sorry
qed "sorry"

mtheorem rewrite1_cl_4:
"cluster emptyXBOOLE-0V1 also-is weakly-normalizingREWRITE1V2\<bar>strongly-normalizingREWRITE1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be weakly-normalizingREWRITE1V2\<bar>strongly-normalizingREWRITE1V3"
    using relat_1_th_40 sorry
qed "sorry"

mtheorem rewrite1_th_47:
" for Q be co-well-foundedREWRITE1V4\<bar>RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies R be co-well-foundedREWRITE1V4"
sorry

mtheorem rewrite1_cl_5:
"cluster strongly-normalizingREWRITE1V3 also-is weakly-normalizingREWRITE1V2 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-normalizingREWRITE1V3 implies it be weakly-normalizingREWRITE1V2"
sorry
qed "sorry"

(*begin*)
mdef rewrite1_def_17 (" _ commutes-weakly-withREWRITE1R10  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "Q be RelationRELAT-1M1"
"pred R commutes-weakly-withREWRITE1R10 Q means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"..

mtheorem REWRITE1R10_symmetry:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R commutes-weakly-withREWRITE1R10 Q implies Q commutes-weakly-withREWRITE1R10 R"
sorry

mdef rewrite1_def_18 (" _ commutes-withREWRITE1R11  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "Q be RelationRELAT-1M1"
"pred R commutes-withREWRITE1R11 Q means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"..

mtheorem REWRITE1R11_symmetry:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R commutes-withREWRITE1R11 Q implies Q commutes-withREWRITE1R11 R"
sorry

mtheorem rewrite1_th_48:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R commutes-withREWRITE1R11 Q implies R commutes-weakly-withREWRITE1R10 Q"
sorry

mdef rewrite1_def_19 ("with-UN-propertyREWRITE1V5" 70 ) where
"attr with-UN-propertyREWRITE1V5 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a is-a-normal-form-wrtREWRITE1R3 R & b is-a-normal-form-wrtREWRITE1R3 R) & (a,b)are-convertible-wrtREWRITE1R2 R implies a =HIDDENR1 b)"..

mdef rewrite1_def_20 ("with-NF-propertyREWRITE1V6" 70 ) where
"attr with-NF-propertyREWRITE1V6 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a is-a-normal-form-wrtREWRITE1R3 R & (a,b)are-convertible-wrtREWRITE1R2 R implies R reducesREWRITE1R1(b,a))"..

mdef rewrite1_def_21 ("subcommutativeREWRITE1V7" 70 ) where
"attr subcommutativeREWRITE1V7 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent<=1-wrtREWRITE1R7 R)"..

mdef rewrite1_def_22 ("confluentREWRITE1V8" 70 ) where
"attr confluentREWRITE1V8 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convergent-wrtREWRITE1R5 R)"..

mdef rewrite1_def_23 ("with-Church-Rosser-propertyREWRITE1V9" 70 ) where
"attr with-Church-Rosser-propertyREWRITE1V9 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convergent-wrtREWRITE1R5 R)"..

mdef rewrite1_def_24 ("locally-confluentREWRITE1V10" 70 ) where
"attr locally-confluentREWRITE1V10 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"..

mtheorem rewrite1_th_49:
" for R be RelationRELAT-1M1 holds R be subcommutativeREWRITE1V7 implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"
sorry

mtheorem rewrite1_th_50:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff R commutes-withREWRITE1R11 R"
sorry

mtheorem rewrite1_th_51:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"
sorry

mtheorem rewrite1_th_52:
" for R be RelationRELAT-1M1 holds R be locally-confluentREWRITE1V10 iff R commutes-weakly-withREWRITE1R10 R"
sorry

mtheorem rewrite1_cl_6:
"cluster with-Church-Rosser-propertyREWRITE1V9 also-is confluentREWRITE1V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-Church-Rosser-propertyREWRITE1V9 implies it be confluentREWRITE1V8"
sorry
qed "sorry"

mtheorem rewrite1_cl_7:
"cluster confluentREWRITE1V8 also-is locally-confluentREWRITE1V10\<bar>with-Church-Rosser-propertyREWRITE1V9 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be confluentREWRITE1V8 implies it be locally-confluentREWRITE1V10\<bar>with-Church-Rosser-propertyREWRITE1V9"
sorry
qed "sorry"

mtheorem rewrite1_cl_8:
"cluster subcommutativeREWRITE1V7 also-is confluentREWRITE1V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be subcommutativeREWRITE1V7 implies it be confluentREWRITE1V8"
sorry
qed "sorry"

mtheorem rewrite1_cl_9:
"cluster with-Church-Rosser-propertyREWRITE1V9 also-is with-NF-propertyREWRITE1V6 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-Church-Rosser-propertyREWRITE1V9 implies it be with-NF-propertyREWRITE1V6"
sorry
qed "sorry"

mtheorem rewrite1_cl_10:
"cluster with-NF-propertyREWRITE1V6 also-is with-UN-propertyREWRITE1V5 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-NF-propertyREWRITE1V6 implies it be with-UN-propertyREWRITE1V5"
    using rewrite1_th_33 sorry
qed "sorry"

mtheorem rewrite1_cl_11:
"cluster with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2 also-is with-Church-Rosser-propertyREWRITE1V9 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2 implies it be with-Church-Rosser-propertyREWRITE1V9"
sorry
qed "sorry"

mtheorem rewrite1_cl_12:
"cluster emptyXBOOLE-0V1 also-is subcommutativeREWRITE1V7 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be subcommutativeREWRITE1V7"
     sorry
qed "sorry"

mtheorem rewrite1_th_53:
" for R be with-UN-propertyREWRITE1V5\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c"
sorry

mtheorem rewrite1_th_54:
" for R be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds nfREWRITE1K2(a,R) is-a-normal-form-ofREWRITE1R4(a,R)"
sorry

mtheorem rewrite1_th_55:
" for R be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies nfREWRITE1K2(a,R) =XBOOLE-0R4 nfREWRITE1K2(b,R)"
sorry

mtheorem rewrite1_cl_13:
"cluster strongly-normalizingREWRITE1V3\<bar>locally-confluentREWRITE1V10 also-is confluentREWRITE1V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-normalizingREWRITE1V3\<bar>locally-confluentREWRITE1V10 implies it be confluentREWRITE1V8"
sorry
qed "sorry"

mdef rewrite1_def_25 ("completeREWRITE1V11" 70 ) where
"attr completeREWRITE1V11 for RelationRELAT-1M1 means
  (\<lambda>R. R be confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3)"..

mtheorem rewrite1_cl_14:
"cluster completeREWRITE1V11 also-is confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be completeREWRITE1V11 implies it be confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3"
     sorry
qed "sorry"

mtheorem rewrite1_cl_15:
"cluster confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3 also-is completeREWRITE1V11 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3 implies it be completeREWRITE1V11"
     sorry
qed "sorry"

mtheorem rewrite1_cl_16:
"cluster completeREWRITE1V11 for  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1 st it be completeREWRITE1V11"
sorry
qed "sorry"

mtheorem rewrite1_th_56:
" for R be with-Church-Rosser-propertyREWRITE1V9\<bar>RelationRELAT-1M1 holds  for Q be with-Church-Rosser-propertyREWRITE1V9\<bar>RelationRELAT-1M1 holds R commutes-withREWRITE1R11 Q implies R \\/XBOOLE-0K2 Q be with-Church-Rosser-propertyREWRITE1V9"
sorry

mtheorem rewrite1_th_57:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10"
sorry

mtheorem rewrite1_th_58:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7"
sorry

(*begin*)
mdef rewrite1_def_26 ("'( _ , _ ')are-equivalentREWRITE1R12" [0,0]50 ) where
  mlet "R be RelationRELAT-1M1", "Q be RelationRELAT-1M1"
"pred (R,Q)are-equivalentREWRITE1R12 means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convertible-wrtREWRITE1R2 Q"..

mtheorem REWRITE1R12_symmetry:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds (R,Q)are-equivalentREWRITE1R12 implies (Q,R)are-equivalentREWRITE1R12"
sorry

mdef rewrite1_def_27 ("'( _ , _ ')are-critical-wrtREWRITE1R13  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-critical-wrtREWRITE1R13 R means
  (a,b)are-divergent<=1-wrtREWRITE1R8 R &  not (a,b)are-convergent-wrtREWRITE1R5 R"..

mtheorem rewrite1_th_59:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-critical-wrtREWRITE1R13 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_th_37 rewrite1_th_45 sorry

mtheorem rewrite1_th_60:
" for R be RelationRELAT-1M1 holds  not ( ex a be objectHIDDENM1 st  ex b be objectHIDDENM1 st (a,b)are-critical-wrtREWRITE1R13 R) implies R be locally-confluentREWRITE1V10"
sorry

mtheorem rewrite1_th_61:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Q implies (a,b)are-critical-wrtREWRITE1R13 R) implies (R,R \\/XBOOLE-0K2 Q)are-equivalentREWRITE1R12"
sorry

mtheorem rewrite1_th_62:
" for R be RelationRELAT-1M1 holds  ex Q be completeREWRITE1V11\<bar>RelationRELAT-1M1 st fieldRELAT-1K3 Q c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 Q)"
sorry

mdef rewrite1_def_28 ("CompletionREWRITE1M2-of  _ " [70]70 ) where
  mlet "R be RelationRELAT-1M1"
"mode CompletionREWRITE1M2-of R \<rightarrow> completeREWRITE1V11\<bar>RelationRELAT-1M1 means
  (\<lambda>it.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 it)"
proof-
  (*existence*)
    show " ex it be completeREWRITE1V11\<bar>RelationRELAT-1M1 st  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 it"
sorry
qed "sorry"

mtheorem rewrite1_th_63:
" for R be RelationRELAT-1M1 holds  for C be CompletionREWRITE1M2-of R holds (R,C)are-equivalentREWRITE1R12"
sorry

mtheorem rewrite1_th_64:
" for R be RelationRELAT-1M1 holds  for Q be completeREWRITE1V11\<bar>RelationRELAT-1M1 holds (R,Q)are-equivalentREWRITE1R12 implies Q be CompletionREWRITE1M2-of R"
sorry

mtheorem rewrite1_th_65:
" for R be RelationRELAT-1M1 holds  for C be CompletionREWRITE1M2-of R holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff nfREWRITE1K2(a,C) =XBOOLE-0R4 nfREWRITE1K2(b,C)"
sorry

end
