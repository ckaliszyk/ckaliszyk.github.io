theory polyeq_1
  imports power quin_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, a9, a1, a2, a3, b, b9, c, c9, d, d9, h, p, q, x, x1, x2, x3, u, v, y, z for "RealXREAL-0M1"
mdef polyeq_1_def_1 ("PolynomPOLYEQ-1K1'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"func PolynomPOLYEQ-1K1(a,b,x) \<rightarrow> numberORDINAL1M2 equals
  a *XCMPLX-0K3 x +XCMPLX-0K2 b"
proof-
  (*coherence*)
    show "a *XCMPLX-0K3 x +XCMPLX-0K2 b be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem polyeq_1_cl_1:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-1K1(a,b,x) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K1(a,b,x) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_cl_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster PolynomPOLYEQ-1K1(a,b,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K1(a,b,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_th_1:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K1(a,b,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
sorry

mtheorem polyeq_1_th_2:
" for x be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-1K1(0NUMBERSK6,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem polyeq_1_th_3:
" for b be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 implies  not ( ex x be ComplexXCMPLX-0M1 st PolynomPOLYEQ-1K1(0NUMBERSK6,b,x) =HIDDENR1 0NUMBERSK6)"
   sorry

mdef polyeq_1_def_2 ("PolynomPOLYEQ-1K2'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"func PolynomPOLYEQ-1K2(a,b,c,x) \<rightarrow> numberORDINAL1M2 equals
  (a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c"
proof-
  (*coherence*)
    show "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem polyeq_1_cl_3:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster PolynomPOLYEQ-1K2(a,b,c,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K2(a,b,c,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_cl_4:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-1K2(a,b,c,x) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K2(a,b,c,x) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_th_4:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for a9 be ComplexXCMPLX-0M1 holds  for b9 be ComplexXCMPLX-0M1 holds  for c9 be ComplexXCMPLX-0M1 holds ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-1K2(a,b,c,x) =HIDDENR1 PolynomPOLYEQ-1K2(a9,b9,c9,x)) implies (a =HIDDENR1 a9 & b =HIDDENR1 b9) & c =HIDDENR1 c9"
sorry

mtheorem polyeq_1_th_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-1K2(a,b,c,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
sorry

mtheorem polyeq_1_th_6:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) =HIDDENR1 0NUMBERSK6) & PolynomPOLYEQ-1K2(a,b,c,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
sorry

mtheorem polyeq_1_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6 implies  not ( ex x be RealXREAL-0M1 st PolynomPOLYEQ-1K2(a,b,c,x) =HIDDENR1 0NUMBERSK6)"
sorry

mtheorem polyeq_1_th_8:
" for x be RealXREAL-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-1K2(0NUMBERSK6,b,c,x) =HIDDENR1 0NUMBERSK6) implies x =HIDDENR1 -XCMPLX-0K4 c /XCMPLX-0K7 b"
sorry

mtheorem polyeq_1_th_9:
" for x be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-1K2(0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem polyeq_1_th_10:
" for c be ComplexXCMPLX-0M1 holds c <>HIDDENR2 0NUMBERSK6 implies  not ( ex x be ComplexXCMPLX-0M1 st PolynomPOLYEQ-1K2(0NUMBERSK6,0NUMBERSK6,c,x) =HIDDENR1 0NUMBERSK6)"
   sorry

mdef polyeq_1_def_3 ("QuardPOLYEQ-1K3'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1", "x1 be ComplexXCMPLX-0M1", "x2 be ComplexXCMPLX-0M1"
"func QuardPOLYEQ-1K3(a,x1,x2,x) \<rightarrow> numberORDINAL1M2 equals
  a *XCMPLX-0K3 ((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2))"
proof-
  (*coherence*)
    show "a *XCMPLX-0K3 ((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2)) be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem polyeq_1_cl_5:
  mlet "a be RealXREAL-0M1", "x be RealXREAL-0M1", "x1 be RealXREAL-0M1", "x2 be RealXREAL-0M1"
"cluster QuardPOLYEQ-1K3(a,x1,x2,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "QuardPOLYEQ-1K3(a,x1,x2,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_th_11:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-1K2(a,b,c,x) =HIDDENR1 QuardPOLYEQ-1K3(a,x1,x2,x)) implies b /XCMPLX-0K7 a =HIDDENR1 -XCMPLX-0K4 (x1 +XCMPLX-0K2 x2) & c /XCMPLX-0K7 a =HIDDENR1 x1 *XCMPLX-0K3 x2"
sorry

(*begin*)
mdef polyeq_1_def_4 ("PolynomPOLYEQ-1K4'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"func PolynomPOLYEQ-1K4(a,b,c,d,x) \<rightarrow> numberORDINAL1M2 equals
  ((a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 x)+XCMPLX-0K2 d"
proof-
  (*coherence*)
    show "((a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 x)+XCMPLX-0K2 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem polyeq_1_cl_6:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-1K4(a,b,c,d,x) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K4(a,b,c,d,x) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_cl_7:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "d be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster PolynomPOLYEQ-1K4(a,b,c,d,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K4(a,b,c,d,x) be realXREAL-0V1"
     sorry
qed "sorry"

mlemma
"\<three>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
   sorry

mlemma polyeq_1_lm_1:
"\<three>\<^sub>M be oddABIANV2"
  using abian_th_1 sorry

mtheorem polyeq_1_th_12:
" for a be RealXREAL-0M1 holds  for a9 be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for b9 be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for c9 be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for d9 be RealXREAL-0M1 holds ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-1K4(a,b,c,d,x) =HIDDENR1 PolynomPOLYEQ-1K4(a9,b9,c9,d9,x)) implies ((a =HIDDENR1 a9 & b =HIDDENR1 b9) & c =HIDDENR1 c9) & d =HIDDENR1 d9"
sorry

mdef polyeq_1_def_5 ("TriPOLYEQ-1K5'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1", "x1 be ComplexXCMPLX-0M1", "x2 be ComplexXCMPLX-0M1", "x3 be ComplexXCMPLX-0M1"
"func TriPOLYEQ-1K5(a,x1,x2,x3,x) \<rightarrow> numberORDINAL1M2 equals
  a *XCMPLX-0K3 (((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2))*XCMPLX-0K3 (x -XCMPLX-0K6 x3))"
proof-
  (*coherence*)
    show "a *XCMPLX-0K3 (((x -XCMPLX-0K6 x1)*XCMPLX-0K3 (x -XCMPLX-0K6 x2))*XCMPLX-0K3 (x -XCMPLX-0K6 x3)) be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem polyeq_1_cl_8:
  mlet "a be RealXREAL-0M1", "x be RealXREAL-0M1", "x1 be RealXREAL-0M1", "x2 be RealXREAL-0M1", "x3 be RealXREAL-0M1"
"cluster TriPOLYEQ-1K5(a,x1,x2,x3,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "TriPOLYEQ-1K5(a,x1,x2,x3,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_1_th_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds PolynomPOLYEQ-1K4(a,b,c,d,x) =HIDDENR1 TriPOLYEQ-1K5(a,x1,x2,x3,x)) implies (b /XCMPLX-0K7 a =HIDDENR1 -XCMPLX-0K4 ((x1 +XCMPLX-0K2 x2)+XCMPLX-0K2 x3) & c /XCMPLX-0K7 a =HIDDENR1 (x1 *XCMPLX-0K3 x2 +XCMPLX-0K2 x2 *XCMPLX-0K3 x3)+XCMPLX-0K2 x1 *XCMPLX-0K3 x3) & d /XCMPLX-0K7 a =HIDDENR1 -XCMPLX-0K4 (x1 *XCMPLX-0K3 x2)*XCMPLX-0K3 x3"
sorry

mtheorem polyeq_1_th_14:
" for h be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (y +XCMPLX-0K2 h) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (y  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 h)*XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 h ^2SQUARE-1K1)*XCMPLX-0K3 y))+XCMPLX-0K2 h  |^NEWTONK1 \<three>\<^sub>M"
sorry

mtheorem polyeq_1_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K4(a,b,c,d,x) =HIDDENR1 0NUMBERSK6 implies ( for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for h be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (((y =HIDDENR1 x +XCMPLX-0K2 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a) & h =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) & a1 =HIDDENR1 b /XCMPLX-0K7 a) & a2 =HIDDENR1 c /XCMPLX-0K7 a) & a3 =HIDDENR1 d /XCMPLX-0K7 a implies (y  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 h +XCMPLX-0K2 a1)*XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 h ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (a1 *XCMPLX-0K3 h))+XCMPLX-0K2 a2)*XCMPLX-0K3 y))+XCMPLX-0K2 ((h  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a1 *XCMPLX-0K3 h ^2SQUARE-1K1)+XCMPLX-0K2 (a2 *XCMPLX-0K3 h +XCMPLX-0K2 a3)) =HIDDENR1 0NUMBERSK6)"
sorry

mtheorem polyeq_1_th_16:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K4(a,b,c,d,x) =HIDDENR1 0NUMBERSK6 implies ( for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for h be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (((y =HIDDENR1 x +XCMPLX-0K2 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a) & h =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) & a1 =HIDDENR1 b /XCMPLX-0K7 a) & a2 =HIDDENR1 c /XCMPLX-0K7 a) & a3 =HIDDENR1 d /XCMPLX-0K7 a implies ((y  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 y ^2SQUARE-1K1)+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 y)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) =HIDDENR1 0NUMBERSK6)"
sorry

mtheorem polyeq_1_th_17:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ((y  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 y ^2SQUARE-1K1)+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 y)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) =HIDDENR1 0NUMBERSK6 implies ( for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds p =HIDDENR1 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) & q =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) implies PolynomPOLYEQ-1K4(\<one>\<^sub>M,0NUMBERSK6,p,q,y) =HIDDENR1 0NUMBERSK6)"
   sorry

mtheorem polyeq_1_th_18:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds PolynomPOLYEQ-1K4(\<one>\<^sub>M,0NUMBERSK6,p,q,y) =HIDDENR1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds y =HIDDENR1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 p =HIDDENR1 0NUMBERSK6 implies u  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 v  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 -XCMPLX-0K4 q & u  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 v  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (-XCMPLX-0K4 p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)"
sorry

mtheorem polyeq_1_th_19:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds PolynomPOLYEQ-1K4(\<one>\<^sub>M,0NUMBERSK6,p,q,y) =HIDDENR1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds y =HIDDENR1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 p =HIDDENR1 0NUMBERSK6 implies (y =HIDDENR1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) or y =HIDDENR1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))) or y =HIDDENR1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))"
sorry

mtheorem polyeq_1_th_20:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) >XXREAL-0R4 0NUMBERSK6) & PolynomPOLYEQ-1K4(0NUMBERSK6,b,c,d,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 ((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b) or x =HIDDENR1 ((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)"
sorry

mtheorem polyeq_1_th_21:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds ((a <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 c /XCMPLX-0K7 a) & q =HIDDENR1 d /XCMPLX-0K7 a) & PolynomPOLYEQ-1K4(a,0NUMBERSK6,c,d,x) =HIDDENR1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds x =HIDDENR1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 p =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) or x =HIDDENR1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M))) or x =HIDDENR1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))"
sorry

mtheorem polyeq_1_th_22:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K4(a,b,c,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
sorry

mtheorem polyeq_1_th_23:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & c /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-1K4(a,0NUMBERSK6,c,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 sqrtSQUARE-1K3 (-XCMPLX-0K4 c /XCMPLX-0K7 a)) or x =HIDDENR1 -XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 c /XCMPLX-0K7 a)"
sorry

end
