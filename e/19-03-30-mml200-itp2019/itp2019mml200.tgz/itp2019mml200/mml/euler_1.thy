theory euler_1
  imports int_2 card_2 pre_ff funct_7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, k, l, m, n for "NatNAT-1M1"
reserve i, j, x, y for "IntegerINT-1M1"
mlemma euler_1_lm_1:
" for k be NatNAT-1M1 holds  for j be IntegerINT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & [\\INT-1K2 j /XCMPLX-0K7 k /] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 j /XCMPLX-0K7 k implies k >=XXREAL-0R2 j -XCMPLX-0K6 ([\\INT-1K2 j /XCMPLX-0K7 k /])*XCMPLX-0K3 k"
sorry

mlemma euler_1_lm_2:
" not \<one>\<^sub>M be primeINT-2V1"
  using int_2_def_4 sorry

mtheorem euler_1_th_1:
" for n be NatNAT-1M1 holds (n,n)are-coprimeINT-2R1 iff n =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem euler_1_th_2:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (k <>HIDDENR2 0NUMBERSK6 & k <XXREAL-0R3 n) & n be primeINT-2V1 implies (k,n)are-coprimeINT-2R1"
sorry

mtheorem euler_1_th_3:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n be primeINT-2V1 & k inTARSKIR2 {kk where kk be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,kk)are-coprimeINT-2R1 & kk >=XXREAL-0R2 \<one>\<^sub>M) & kk <=XXREAL-0R1 n } iff (n be primeINT-2V1 & k inTARSKIR2 SegmCARD-1K5 n) &  not k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem euler_1_th_4:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds x inTARSKIR2 A implies cardCARD-1K4 (A \\SUBSET-1K6 {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 A -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 x}"
  using card_2_th_44 zfmisc_1_th_31 sorry

mtheorem euler_1_th_5:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies ( for c be NatNAT-1M1 holds a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =XBOOLE-0R4 c)"
sorry

mtheorem euler_1_th_6:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & c <>HIDDENR2 0NUMBERSK6) & a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =XBOOLE-0R4 c implies (a,b)are-coprimeINT-2R1"
sorry

mtheorem euler_1_th_7:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem euler_1_th_8:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds (a +XCMPLX-0K2 b *XCMPLX-0K3 c)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
sorry

mtheorem euler_1_th_9:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m,n)are-coprimeINT-2R1 implies ( ex k be NatNAT-1M1 st ( ex i0 be IntegerINT-1M1 st  ex j0 be IntegerINT-1M1 st k =XBOOLE-0R4 i0 *XCMPLX-0K3 m +XCMPLX-0K2 j0 *XCMPLX-0K3 n & k >XXREAL-0R4 0NUMBERSK6) & ( for l be NatNAT-1M1 holds ( ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st l =XBOOLE-0R4 i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n & l >XXREAL-0R4 0NUMBERSK6) implies k <=XXREAL-0R1 l))"
sorry

mtheorem euler_1_th_10:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m,n)are-coprimeINT-2R1 implies ( for k be NatNAT-1M1 holds  ex i be IntegerINT-1M1 st  ex j be IntegerINT-1M1 st i *XCMPLX-0K3 m +XCMPLX-0K2 j *XCMPLX-0K3 n =XBOOLE-0R4 k)"
sorry

mtheorem euler_1_th_11:
" for A be setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds f be bijectiveFUNCT-2V3\<^bsub>(A,B)\<^esub> implies cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 B"
sorry

mtheorem euler_1_th_12:
" for i be IntegerINT-1M1 holds  for k be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds (i +XCMPLX-0K2 k *XCMPLX-0K3 n)modINT-1K6 n =HIDDENR1 i modINT-1K6 n"
sorry

mtheorem euler_1_th_13:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds c dividesNAT-DR1 a *XCMPLX-0K3 b & (a,c)are-coprimeINT-2R1 implies c dividesNAT-DR1 b"
sorry

mtheorem euler_1_th_14:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds ((a <>HIDDENR2 0NUMBERSK6 & c <>HIDDENR2 0NUMBERSK6) & (a,c)are-coprimeINT-2R1) & (b,c)are-coprimeINT-2R1 implies (a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
sorry

mtheorem euler_1_th_15:
" for i be IntegerINT-1M1 holds  for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds x <>HIDDENR2 0NUMBERSK6 & i >=XXREAL-0R2 0NUMBERSK6 implies i *XCMPLX-0K3 x gcdINT-2K3 i *XCMPLX-0K3 y =XBOOLE-0R4 i *XCMPLX-0K3 (x gcdINT-2K3 y)"
sorry

mtheorem euler_1_th_16:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for x be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 x *XCMPLX-0K3 b)gcdINT-2K3 b =XBOOLE-0R4 a gcdINT-2K3 b"
sorry

(*begin*)
mdef euler_1_def_1 ("EulerEULER-1K1  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func EulerEULER-1K1 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  cardCARD-1K1 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n })"
proof-
  (*coherence*)
    show "cardCARD-1K1 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n }) be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

mlemma
" for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<one>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<one>\<^sub>M } iff x =HIDDENR1 \<one>\<^sub>M"
sorry

mlemma euler_1_lm_3:
"cardCARD-1K4 {TARSKIK1 \<one>\<^sub>M} =XBOOLE-0R4 EulerEULER-1K1 \<one>\<^sub>M"
  using tarski_def_1 sorry

mtheorem euler_1_th_17:
"EulerEULER-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  using euler_1_lm_3 card_1_th_30 sorry

mlemma
" for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((\<two>\<^sub>M,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 \<two>\<^sub>M } iff x =HIDDENR1 \<one>\<^sub>M"
sorry

mlemma euler_1_lm_4:
"cardCARD-1K4 {TARSKIK1 \<one>\<^sub>M} =XBOOLE-0R4 EulerEULER-1K1 \<two>\<^sub>M"
  using tarski_def_1 sorry

mtheorem euler_1_th_18:
"EulerEULER-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  using euler_1_lm_4 card_1_th_30 sorry

mtheorem euler_1_th_19:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies EulerEULER-1K1 n <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mtheorem euler_1_th_20:
" for n be NatNAT-1M1 holds n be primeINT-2V1 implies EulerEULER-1K1 n =XBOOLE-0R4 n -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mtheorem euler_1_th_21:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m >XXREAL-0R4 \<one>\<^sub>M & n >XXREAL-0R4 \<one>\<^sub>M) & (m,n)are-coprimeINT-2R1 implies EulerEULER-1K1 (m *XCMPLX-0K3 n) =XBOOLE-0R4 EulerEULER-1K1 m *NAT-1K2 EulerEULER-1K1 n"
sorry

end
