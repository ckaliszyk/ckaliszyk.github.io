theory fcont_3
  imports limfunc1 fcont_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, X for "setHIDDENM2"
reserve x0, r1, r2, g, g1, g2, p, s for "RealXREAL-0M1"
reserve r for "RealXREAL-0M1"
reserve n, m for "NatORDINAL1M6"
reserve a, b, d for "Real-SequenceSEQ-1M1"
reserve f for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fcont_3_cl_1:
"cluster [#]SUBSET-1K2 REALNUMBERSK2 as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "[#]SUBSET-1K2 REALNUMBERSK2 be closedRCOMP-1V2"
    using xreal_0_def_1 sorry
qed "sorry"

mtheorem fcont_3_cl_2:
"cluster emptyXBOOLE-0V1 also-is closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be emptyXBOOLE-0V1 implies it be closedRCOMP-1V2"
    using xboole_1_th_3 sorry
qed "sorry"

mtheorem fcont_3_cl_3:
"cluster [#]SUBSET-1K2 REALNUMBERSK2 as-term-is openRCOMP-1V3"
proof
(*coherence*)
  show "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3"
sorry
qed "sorry"

mtheorem fcont_3_cl_4:
"cluster emptyXBOOLE-0V1 also-is openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be emptyXBOOLE-0V1 implies it be openRCOMP-1V3"
sorry
qed "sorry"

mtheorem fcont_3_cl_5:
  mlet "r be RealXREAL-0M1"
"cluster right-closed-halflineLIMFUNC1K3 r as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "right-closed-halflineLIMFUNC1K3 r be closedRCOMP-1V2"
sorry
qed "sorry"

mtheorem fcont_3_cl_6:
  mlet "r be RealXREAL-0M1"
"cluster left-closed-halflineLIMFUNC1K2 r as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "left-closed-halflineLIMFUNC1K2 r be closedRCOMP-1V2"
sorry
qed "sorry"

mtheorem fcont_3_cl_7:
  mlet "r be RealXREAL-0M1"
"cluster right-open-halflineLIMFUNC1K4 r as-term-is openRCOMP-1V3"
proof
(*coherence*)
  show "right-open-halflineLIMFUNC1K4 r be openRCOMP-1V3"
sorry
qed "sorry"

mtheorem fcont_3_cl_8:
  mlet "r be RealXREAL-0M1"
"cluster halflinePROB-1K10 r as-term-is openRCOMP-1V3"
proof
(*coherence*)
  show "halflinePROB-1K10 r be openRCOMP-1V3"
sorry
qed "sorry"

mtheorem fcont_3_th_1:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
sorry

mtheorem fcont_3_th_2:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
sorry

mtheorem fcont_3_th_3:
" for x0 be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g =COMPLEX1R1 x0 +XCMPLX-0K2 r1 &  |.COMPLEX1K10 r1.| <XXREAL-0R3 r implies 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
sorry

mtheorem fcont_3_th_4:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .[ implies 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
sorry

mtheorem fcont_3_th_5:
" for p be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for x0 be RealXREAL-0M1 holds ( for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) implies a be convergentSEQ-2V5 & limSEQ-2K1 a =COMPLEX1R1 x0"
sorry

mtheorem fcont_3_th_6:
" for p be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for x0 be RealXREAL-0M1 holds ( for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) implies a be convergentSEQ-2V5 & limSEQ-2K1 a =COMPLEX1R1 x0"
sorry

mtheorem fcont_3_th_7:
" for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-continuous-inFCONT-1R1 x0 & f .FUNCT-1K1 x0 <>HIDDENR2 r) & ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 N implies f .FUNCT-1K1 g <>HIDDENR2 r))"
sorry

mtheorem fcont_3_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
sorry

mtheorem fcont_3_th_9:
" for X be setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be increasingRFUNCT-2V1"
sorry

mtheorem fcont_3_th_10:
" for X be setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be decreasingRFUNCT-2V2"
sorry

mtheorem fcont_3_th_11:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_12:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_13:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-closed-halflineLIMFUNC1K2 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_14:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-closed-halflineLIMFUNC1K3 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_15:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 ].RCOMP-1K2 p,g .[) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_16:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 REALNUMBERSK2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_17:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2) & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_18:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2) & left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_19:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2) & right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_20:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be decreasingRFUNCT-2V2) & left-closed-halflineLIMFUNC1K2 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_21:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be decreasingRFUNCT-2V2) & right-closed-halflineLIMFUNC1K3 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_22:
" for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2) & f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
sorry

mtheorem fcont_3_th_23:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
sorry

mtheorem fcont_3_th_24:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
sorry

mtheorem fcont_3_th_25:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
sorry

mtheorem fcont_3_th_26:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
sorry

end
