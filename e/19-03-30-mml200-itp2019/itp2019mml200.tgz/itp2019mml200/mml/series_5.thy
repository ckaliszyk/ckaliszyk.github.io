theory series_5
  imports series_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d for "positiveXXREAL-0V2\<bar>RealXREAL-0M1"
reserve m, u, w, x, y, z for "RealXREAL-0M1"
reserve n, k for "NatNAT-1M1"
reserve s, s1 for "Real-SequenceSEQ-1M1"
mlemma series_5_lm_1:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (x -XCMPLX-0K6 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1)"
sorry

mlemma series_5_lm_2:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b)"
sorry

mlemma series_5_lm_3:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 z)"
sorry

mlemma series_5_lm_4:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 b) =COMPLEX1R1 (c /XCMPLX-0K7 a)to-powerPOWERK2 b"
sorry

mlemma series_5_lm_5:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1) >=XXREAL-0R2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 (a +XCMPLX-0K2 d)^2SQUARE-1K1"
sorry

mlemma series_5_lm_6:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((x +XCMPLX-0K2 y)+XCMPLX-0K2 z)^2SQUARE-1K1 =COMPLEX1R1 ((((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 z)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 x"
   sorry

mlemma series_5_lm_7:
" for x be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M implies x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
sorry

mlemma series_5_lm_8:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
sorry

mlemma series_5_lm_9:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =COMPLEX1R1 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M"
sorry

mlemma series_5_lm_10:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
sorry

mlemma series_5_lm_11:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
sorry

mlemma series_5_lm_12:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mlemma series_5_lm_13:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1"
sorry

mlemma series_5_lm_14:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) =COMPLEX1R1 c ^2SQUARE-1K1"
sorry

mlemma series_5_lm_15:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
sorry

mlemma series_5_lm_16:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 =COMPLEX1R1 ((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
sorry

mlemma series_5_lm_17:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies \<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
sorry

mlemma series_5_lm_18:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c) =COMPLEX1R1 \<eight>\<^sub>M"
sorry

mlemma series_5_lm_19:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a =COMPLEX1R1 \<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
sorry

mlemma series_5_lm_20:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
sorry

mlemma series_5_lm_21:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M"
sorry

mlemma series_5_lm_22:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 (((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a"
sorry

mlemma series_5_lm_23:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a >=XXREAL-0R2 \<six>\<^sub>M"
sorry

mtheorem series_5_th_1:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<four>\<^sub>M"
sorry

mtheorem series_5_th_2:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M >=XXREAL-0R2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M"
sorry

mtheorem series_5_th_3:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies \<one>\<^sub>M <XXREAL-0R3 (b +XCMPLX-0K2 c)/XCMPLX-0K7 (a +XCMPLX-0K2 c)"
sorry

mtheorem series_5_th_4:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)"
sorry

mtheorem series_5_th_5:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem series_5_th_6:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
sorry

mtheorem series_5_th_7:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
sorry

mtheorem series_5_th_8:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem series_5_th_9:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
sorry

mtheorem series_5_th_10:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
sorry

mtheorem series_5_th_11:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem series_5_th_12:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem series_5_th_13:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M &  |.COMPLEX1K10 y.| <XXREAL-0R3 \<one>\<^sub>M implies  |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
sorry

mtheorem series_5_th_14:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
sorry

mtheorem series_5_th_15:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem series_5_th_16:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 \<two>\<^sub>M"
sorry

mtheorem series_5_th_17:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b >XXREAL-0R4 c & b +XCMPLX-0K2 c >XXREAL-0R4 a) & a +XCMPLX-0K2 c >XXREAL-0R4 b implies (\<one>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((b +XCMPLX-0K2 c)-XCMPLX-0K6 a))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b) >=XXREAL-0R2 \<nine>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
sorry

mtheorem series_5_th_18:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)) >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d)"
sorry

mtheorem series_5_th_19:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) >=XXREAL-0R2 (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 d"
sorry

mtheorem series_5_th_20:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M"
sorry

mtheorem series_5_th_21:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 a =COMPLEX1R1 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)+XCMPLX-0K2 c >=XXREAL-0R2 sqrtSQUARE-1K3 \<three>\<^sub>M"
sorry

mtheorem series_5_th_22:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((b +XCMPLX-0K2 c)-XCMPLX-0K6 a)/XCMPLX-0K7 a +XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M"
sorry

mtheorem series_5_th_23:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
sorry

mtheorem series_5_th_24:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
sorry

mtheorem series_5_th_25:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds x >XXREAL-0R4 y & y >XXREAL-0R4 z implies (x ^2SQUARE-1K1 *XCMPLX-0K3 y +XCMPLX-0K2 y ^2SQUARE-1K1 *XCMPLX-0K3 z)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 x >XXREAL-0R4 (x *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 y *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 z *XCMPLX-0K3 x ^2SQUARE-1K1"
sorry

mtheorem series_5_th_26:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >XXREAL-0R4 b & b >XXREAL-0R4 c implies b /XCMPLX-0K7 (a -XCMPLX-0K6 b) >XXREAL-0R4 c /XCMPLX-0K7 (a -XCMPLX-0K6 c)"
sorry

mtheorem series_5_th_27:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds b >XXREAL-0R4 a & c >XXREAL-0R4 d implies c /XCMPLX-0K7 (c +XCMPLX-0K2 a) >XXREAL-0R4 d /XCMPLX-0K7 (d +XCMPLX-0K2 b)"
sorry

mtheorem series_5_th_28:
" for m be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
sorry

mtheorem series_5_th_29:
" for m be RealXREAL-0M1 holds  for u be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((m *XCMPLX-0K3 x +XCMPLX-0K2 u *XCMPLX-0K3 y)+XCMPLX-0K2 w *XCMPLX-0K3 z)^2SQUARE-1K1 <=XXREAL-0R1 ((m ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)"
sorry

mtheorem series_5_th_30:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1) <=XXREAL-0R1 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
sorry

mtheorem series_5_th_31:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c <=XXREAL-0R1 (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M)"
sorry

mtheorem series_5_th_32:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

mtheorem series_5_th_33:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))"
sorry

mtheorem series_5_th_34:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)) <=XXREAL-0R1 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c"
sorry

mtheorem series_5_th_35:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<nine>\<^sub>M"
sorry

mtheorem series_5_th_36:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<one>\<seven>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
sorry

mtheorem series_5_th_37:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M"
sorry

mtheorem series_5_th_38:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies ((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<eight>\<^sub>M"
sorry

mtheorem series_5_th_39:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 \<six>\<four>\<^sub>M"
sorry

mtheorem series_5_th_40:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
sorry

mtheorem series_5_th_41:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
sorry

mtheorem series_5_th_42:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >XXREAL-0R4 b & b >XXREAL-0R4 c implies (a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c) >XXREAL-0R4 (a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 b to-powerPOWERK2 (a +XCMPLX-0K2 c))*XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)"
sorry

mtheorem series_5_th_43:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
sorry

mtheorem series_5_th_44:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =COMPLEX1R1 c ^2SQUARE-1K1 & n >=XXREAL-0R2 \<three>\<^sub>M implies a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 c  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
sorry

mtheorem series_5_th_45:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 n <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem series_5_th_46:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & k >=XXREAL-0R2 \<one>\<^sub>M implies (a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
sorry

mtheorem series_5_th_47:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem series_5_th_48:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem series_5_th_49:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M"
sorry

mtheorem series_5_th_50:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem series_5_th_51:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)"
sorry

mtheorem series_5_th_52:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6)"
sorry

mtheorem series_5_th_53:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1)"
sorry

mtheorem series_5_th_54:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
sorry

mtheorem series_5_th_55:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
sorry

mtheorem series_5_th_56:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))"
sorry

mtheorem series_5_th_57:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)"
sorry

end
