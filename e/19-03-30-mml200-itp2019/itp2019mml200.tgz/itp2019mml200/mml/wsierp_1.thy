theory wsierp_1
  imports prepower rvsum_1 trees_4 pre_ff card_4 finseq_5
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z for "RealXREAL-0M1"
reserve a, b, c, d, e, f, g, h for "NatNAT-1M1"
reserve k, l, m, n, m1, n1, m2, n2 for "IntegerINT-1M1"
reserve q for "RationalRAT-1M1"
mtheorem wsierp_1_th_1:
" for x be RealXREAL-0M1 holds x  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 x *XCMPLX-0K3 x & (-XCMPLX-0K4 x) |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 x  |^NEWTONK1 \<two>\<^sub>M"
sorry

mtheorem wsierp_1_th_2:
" for x be RealXREAL-0M1 holds  for a be NatNAT-1M1 holds (-XCMPLX-0K4 x) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 a) =XBOOLE-0R4 x  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 a) & (-XCMPLX-0K4 x) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 a +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 x  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 a +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem wsierp_1_th_3:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for d be NatNAT-1M1 holds ((x >=XXREAL-0R2 0NUMBERSK6 & y >=XXREAL-0R2 0NUMBERSK6) & d >XXREAL-0R4 0NUMBERSK6) & x  |^NEWTONK1 d =XBOOLE-0R4 y  |^NEWTONK1 d implies x =HIDDENR1 y"
sorry

mlemma wsierp_1_lm_1:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (((x >=XXREAL-0R2 0NUMBERSK6 iff x +XCMPLX-0K2 y >=XXREAL-0R2 y) & (x >XXREAL-0R4 0NUMBERSK6 iff x +XCMPLX-0K2 y >XXREAL-0R4 y)) & (x >=XXREAL-0R2 0NUMBERSK6 iff y >=XXREAL-0R2 y -XCMPLX-0K6 x)) & (x >XXREAL-0R4 0NUMBERSK6 iff y >XXREAL-0R4 y -XCMPLX-0K6 x)"
sorry

mlemma wsierp_1_lm_2:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 & y >=XXREAL-0R2 z implies x +XCMPLX-0K2 y >=XXREAL-0R2 z & y >=XXREAL-0R2 z -XCMPLX-0K6 x"
sorry

mlemma wsierp_1_lm_3:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 & y >XXREAL-0R4 z or x >XXREAL-0R4 0NUMBERSK6 & y >=XXREAL-0R2 z implies x +XCMPLX-0K2 y >XXREAL-0R4 z & y >XXREAL-0R4 z -XCMPLX-0K6 x"
sorry

mtheorem wsierp_1_cl_1:
  mlet "k be IntegerINT-1M1", "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster k  |^NEWTONK1 a as-term-is integerINT-1V1"
proof
(*coherence*)
  show "k  |^NEWTONK1 a be integerINT-1V1"
sorry
qed "sorry"

mlemma wsierp_1_lm_4:
" for a be NatNAT-1M1 holds  ex b be NatNAT-1M1 st a =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 b or a =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 b +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_4:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds k dividesINT-1R1 m & k dividesINT-1R1 n implies k dividesINT-1R1 m +XCMPLX-0K2 n"
sorry

mtheorem wsierp_1_th_5:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  for m1 be IntegerINT-1M1 holds  for n1 be IntegerINT-1M1 holds k dividesINT-1R1 m & k dividesINT-1R1 n implies k dividesINT-1R1 m *XCMPLX-0K3 m1 +XCMPLX-0K2 n *XCMPLX-0K3 n1"
sorry

mtheorem wsierp_1_th_6:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds m gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M & k gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M implies m *XCMPLX-0K3 k gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_7:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M & c gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies a *XCMPLX-0K3 c gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
  using wsierp_1_th_6 sorry

mtheorem wsierp_1_th_8:
" for m be IntegerINT-1M1 holds 0NUMBERSK6 gcdINT-2K3 m =XBOOLE-0R4  |.INT-2K1 m.| & \<one>\<^sub>M gcdINT-2K3 m =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_9:
" for k be IntegerINT-1M1 holds (\<one>\<^sub>M,k)are-coprimeINT-2R1"
sorry

mtheorem wsierp_1_th_10:
" for a be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds (k,l)are-coprimeINT-2R1 implies (k  |^NEWTONK1 a,l)are-coprimeINT-2R1"
sorry

mtheorem wsierp_1_th_11:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds (k,l)are-coprimeINT-2R1 implies (k  |^NEWTONK1 a,l  |^NEWTONK1 b)are-coprimeINT-2R1"
sorry

mtheorem wsierp_1_th_12:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds k gcdINT-2K3 l =XBOOLE-0R4 \<one>\<^sub>M implies k gcdINT-2K3 l  |^NEWTONK1 b =XBOOLE-0R4 \<one>\<^sub>M & k  |^NEWTONK1 a gcdINT-2K3 l  |^NEWTONK1 b =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_13:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  |.INT-2K1 m.| dividesINT-1R1 k iff m dividesINT-1R1 k"
sorry

mtheorem wsierp_1_th_14:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a dividesNAT-DR1 b implies a  |^NEWTONK1 c dividesNAT-DR1 b  |^NEWTONK1 c"
sorry

mtheorem wsierp_1_th_15:
" for a be NatNAT-1M1 holds a dividesNAT-DR1 \<one>\<^sub>M implies a =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_16:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for d be NatNAT-1M1 holds d dividesNAT-DR1 a & a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M implies d gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M"
  using wsierp_1_th_15 newton_th_57 sorry

mlemma wsierp_1_lm_5:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies (a dividesNAT-DR1 b iff b /XCMPLX-0K7 a be ElementSUBSET-1M1-of NATNUMBERSK1)"
sorry

mtheorem wsierp_1_th_17:
" for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds k <>HIDDENR2 0NUMBERSK6 implies (k dividesINT-1R1 l iff l /XCMPLX-0K7 k be IntegerINT-1M1)"
sorry

mlemma wsierp_1_lm_6:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds b <>HIDDENR2 0NUMBERSK6 & a *XCMPLX-0K3 k =XBOOLE-0R4 b implies k be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry

mlemma wsierp_1_lm_7:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 c & b <=XXREAL-0R1 c"
sorry

mtheorem wsierp_1_th_18:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a <=XXREAL-0R1 b -XCMPLX-0K6 c implies a <=XXREAL-0R1 b & c <=XXREAL-0R1 b"
sorry

mlemma wsierp_1_lm_8:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds k <XXREAL-0R3 m iff k <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M"
sorry

mlemma wsierp_1_lm_9:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds k <XXREAL-0R3 m +XCMPLX-0K2 \<one>\<^sub>M iff k <=XXREAL-0R1 m"
sorry

reserve fs, fs1, fs2, fs3 for "FinSequenceFINSEQ-1M1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve v, v1, v2, v3 for "objectHIDDENM1"
reserve fp for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
reserve fr, fr1, fr2 for "FinSequenceFINSEQ-1M3-of INTINT-1K1"
reserve ft for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
mtheorem wsierp_1_cl_2:
  mlet "fr be FinSequenceFINSEQ-1M3-of INTINT-1K1"
"cluster ProductRVSUM-1K23 fr as-term-is integerINT-1V1"
proof
(*coherence*)
  show "ProductRVSUM-1K23 fr be integerINT-1V1"
sorry
qed "sorry"

abbreviation(input) WSIERP_1K1("SumWSIERP-1K1  _ " [260]260) where
  "SumWSIERP-1K1 fp \<equiv> SumRVSUM-1K20 fp"

mtheorem wsierp_1_add_1:
  mlet "fp be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
"cluster SumRVSUM-1K20 fp as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "SumRVSUM-1K20 fp be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

abbreviation(input) WSIERP_1K2("ProductWSIERP-1K2  _ " [228]228) where
  "ProductWSIERP-1K2 fp \<equiv> ProductRVSUM-1K23 fp"

mtheorem wsierp_1_add_2:
  mlet "fp be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
"cluster ProductRVSUM-1K23 fp as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "ProductRVSUM-1K23 fp be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry
qed "sorry"

mlemma wsierp_1_lm_10:
" for a be NatNAT-1M1 holds  for fs be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 domFINSEQ-1K5 fs implies ( ex fs1 be FinSequenceFINSEQ-1M1 st  ex fs2 be FinSequenceFINSEQ-1M1 st (fs =FINSEQ-1R1 (fs1 ^FINSEQ-1K8 (<*FINSEQ-1K10 fs .FUNCT-1K1 a*>))^FINSEQ-1K8 fs2 & lenFINSEQ-1K4 fs1 =XBOOLE-0R4 a -XCMPLX-0K6 \<one>\<^sub>M) & lenFINSEQ-1K4 fs2 =XBOOLE-0R4 lenFINSEQ-1K4 fs -XCMPLX-0K6 a)"
sorry

abbreviation(input) WSIERP_1K3("DelWSIERP-1K3'( _ , _ ')" [0,0]164) where
  "DelWSIERP-1K3(fs,a) \<equiv> DelFINSEQ-3K2(fs,a)"

mtheorem wsierp_1_def_1:
  mlet "a be NatNAT-1M1", "fs be FinSequenceFINSEQ-1M1"
"redefine func DelWSIERP-1K3(fs,a) \<rightarrow> setHIDDENM2 means
  \<lambda>it. it =FINSEQ-1R1 fs if  not a inTARSKIR2 domFINSEQ-1K5 fs otherwise \<lambda>it. lenFINSEQ-1K4 it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 fs & ( for b be NatNAT-1M1 holds (b <XXREAL-0R3 a implies it .FUNCT-1K1 b =XBOOLE-0R4 fs .FUNCT-1K1 b) & (b >=XXREAL-0R2 a implies it .FUNCT-1K1 b =XBOOLE-0R4 fs .FUNCT-1K1 (b +NAT-1K1 \<one>\<^sub>M)))"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds ( not a inTARSKIR2 domFINSEQ-1K5 fs implies (it =HIDDENR1 DelWSIERP-1K3(fs,a) iff it =FINSEQ-1R1 fs)) & ( not ( not a inTARSKIR2 domFINSEQ-1K5 fs) implies (it =HIDDENR1 DelWSIERP-1K3(fs,a) iff lenFINSEQ-1K4 it +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 fs & ( for b be NatNAT-1M1 holds (b <XXREAL-0R3 a implies it .FUNCT-1K1 b =XBOOLE-0R4 fs .FUNCT-1K1 b) & (b >=XXREAL-0R2 a implies it .FUNCT-1K1 b =XBOOLE-0R4 fs .FUNCT-1K1 (b +NAT-1K1 \<one>\<^sub>M)))))"
sorry
(*consistency*)
  show " for it be setHIDDENM2 holds  True "
     sorry
qed "sorry"

mlemma wsierp_1_lm_11:
" for a be NatNAT-1M1 holds  for fs be FinSequenceFINSEQ-1M1 holds  for fs1 be FinSequenceFINSEQ-1M1 holds  for fs2 be FinSequenceFINSEQ-1M1 holds  for v be objectHIDDENM1 holds (a inTARSKIR2 domFINSEQ-1K5 fs & fs =FINSEQ-1R1 (fs1 ^FINSEQ-1K8 (<*FINSEQ-1K10 v*>))^FINSEQ-1K8 fs2) & lenFINSEQ-1K4 fs1 =XBOOLE-0R4 a -XCMPLX-0K6 \<one>\<^sub>M implies DelWSIERP-1K3(fs,a) =FINSEQ-1R1 fs1 ^FINSEQ-1K8 fs2"
sorry

mlemma wsierp_1_lm_12:
" for a be NatNAT-1M1 holds  for fs be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 (DelWSIERP-1K3(fs,a)) c=TARSKIR1 domFINSEQ-1K5 fs"
sorry

syntax WSIERP_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("DelWSIERP-1K4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164)
translations "DelWSIERP-1K4\<^bsub>(D)\<^esub>(fs,a)" \<rightharpoonup> "DelFINSEQ-3K2(fs,a)"

mtheorem wsierp_1_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "a be NatNAT-1M1", "fs be FinSequenceFINSEQ-1M3-of D"
"cluster DelFINSEQ-3K2(fs,a) as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "DelFINSEQ-3K2(fs,a) be FinSequenceFINSEQ-1M3-of D"
sorry
qed "sorry"

syntax WSIERP_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("DelWSIERP-1K5\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]164)
translations "DelWSIERP-1K5\<^bsub>(D,D1)\<^esub>(fs,a)" \<rightharpoonup> "DelFINSEQ-3K2(fs,a)"

mtheorem wsierp_1_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of D", "a be NatNAT-1M1", "fs be FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of D1"
"cluster DelFINSEQ-3K2(fs,a) as-term-is FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of D1"
proof
(*coherence*)
  show "DelFINSEQ-3K2(fs,a) be FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of D1"
sorry
qed "sorry"

mlemma wsierp_1_lm_13:
" for a be NatNAT-1M1 holds  for fs1 be FinSequenceFINSEQ-1M1 holds  for fs2 be FinSequenceFINSEQ-1M1 holds (a <=XXREAL-0R1 lenFINSEQ-1K4 fs1 implies DelWSIERP-1K3(fs1 ^FINSEQ-1K8 fs2,a) =FINSEQ-1R1 (DelWSIERP-1K3(fs1,a))^FINSEQ-1K8 fs2) & (a >=XXREAL-0R2 \<one>\<^sub>M implies DelWSIERP-1K3(fs1 ^FINSEQ-1K8 fs2,lenFINSEQ-1K4 fs1 +XCMPLX-0K2 a) =FINSEQ-1R1 fs1 ^FINSEQ-1K8 (DelWSIERP-1K3(fs2,a)))"
sorry

mlemma wsierp_1_lm_14:
" for fs be FinSequenceFINSEQ-1M1 holds  for v be objectHIDDENM1 holds DelWSIERP-1K3((<*FINSEQ-1K10 v*>)^FINSEQ-1K8 fs,\<one>\<^sub>M) =FINSEQ-1R1 fs & DelWSIERP-1K3(fs ^FINSEQ-1K8 (<*FINSEQ-1K10 v*>),lenFINSEQ-1K4 fs +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fs"
sorry

mtheorem wsierp_1_th_19:
" for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds  for v3 be objectHIDDENM1 holds ((((DelWSIERP-1K3(<*FINSEQ-1K10 v1*>,\<one>\<^sub>M) =FINSEQ-1R1 {}XBOOLE-0K1 & DelWSIERP-1K3(<*FINSEQ-1K11 v1,v2 *>,\<one>\<^sub>M) =FINSEQ-1R1 <*FINSEQ-1K10 v2*>) & DelWSIERP-1K3(<*FINSEQ-1K11 v1,v2 *>,\<two>\<^sub>M) =FINSEQ-1R1 <*FINSEQ-1K10 v1*>) & DelWSIERP-1K3(<*FINSEQ-1K12 v1,v2,v3 *>,\<one>\<^sub>M) =FINSEQ-1R1 <*FINSEQ-1K11 v2,v3 *>) & DelWSIERP-1K3(<*FINSEQ-1K12 v1,v2,v3 *>,\<two>\<^sub>M) =FINSEQ-1R1 <*FINSEQ-1K11 v1,v3 *>) & DelWSIERP-1K3(<*FINSEQ-1K12 v1,v2,v3 *>,\<three>\<^sub>M) =FINSEQ-1R1 <*FINSEQ-1K11 v1,v2 *>"
sorry

mlemma wsierp_1_lm_15:
" for fs be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fs implies fs =FINSEQ-1R1 (<*FINSEQ-1K10 fs .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (DelWSIERP-1K3(fs,\<one>\<^sub>M)) & fs =FINSEQ-1R1 (DelWSIERP-1K3(fs,lenFINSEQ-1K4 fs))^FINSEQ-1K8 (<*FINSEQ-1K10 fs .FUNCT-1K1 lenFINSEQ-1K4 fs*>)"
sorry

mlemma wsierp_1_lm_16:
" for a be NatNAT-1M1 holds  for ft be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds a inTARSKIR2 domFINSEQ-1K5 ft implies ProductRVSUM-1K25 (DelWSIERP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(ft,a)) *XCMPLX-0K3 ft .FUNCT-1K1 a =HIDDENR1 ProductRVSUM-1K25 ft"
sorry

mtheorem wsierp_1_th_20:
" for a be NatNAT-1M1 holds  for ft be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds a inTARSKIR2 domFINSEQ-1K5 ft implies SumRVSUM-1K22 (DelWSIERP-1K4\<^bsub>(REALNUMBERSK2)\<^esub>(ft,a)) +XCMPLX-0K2 ft .FUNCT-1K1 a =HIDDENR1 SumRVSUM-1K22 ft"
sorry

mtheorem wsierp_1_th_21:
" for a be NatNAT-1M1 holds  for fp be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a inTARSKIR2 domFINSEQ-1K5 fp implies ProductWSIERP-1K2 fp /XCMPLX-0K7 fp .FUNCT-1K1 a be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry

mtheorem wsierp_1_th_22:
" for q be RationalRAT-1M1 holds (numeratorRAT-1K3 q,denominatorRAT-1K2 q)are-coprimeINT-2R1"
sorry

mtheorem wsierp_1_th_23:
" for a be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds  for q be RationalRAT-1M1 holds (q =HIDDENR1 k /XCMPLX-0K7 a & a <>HIDDENR2 0NUMBERSK6) & (k,a)are-coprimeINT-2R1 implies k =HIDDENR1 numeratorRAT-1K3 q & a =XBOOLE-0R4 denominatorRAT-1K2 q"
sorry

mtheorem wsierp_1_th_24:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds ( ex q be RationalRAT-1M1 st a =XBOOLE-0R4 q  |^NEWTONK1 b) implies ( ex k be IntegerINT-1M1 st a =XBOOLE-0R4 k  |^NEWTONK1 b)"
sorry

mtheorem wsierp_1_th_25:
" for a be NatNAT-1M1 holds  for d be NatNAT-1M1 holds ( ex q be RationalRAT-1M1 st a =XBOOLE-0R4 q  |^NEWTONK1 d) implies ( ex b be NatNAT-1M1 st a =XBOOLE-0R4 b  |^NEWTONK1 d)"
sorry

mtheorem wsierp_1_th_26:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for e be NatNAT-1M1 holds e >XXREAL-0R4 0NUMBERSK6 & a  |^NEWTONK1 e dividesNAT-DR1 b  |^NEWTONK1 e implies a dividesNAT-DR1 b"
sorry

mtheorem wsierp_1_th_27:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st a gcdINT-2K3 b =XBOOLE-0R4 a *XCMPLX-0K3 m +XCMPLX-0K2 b *XCMPLX-0K3 n"
sorry

mtheorem wsierp_1_th_28:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  ex m1 be IntegerINT-1M1 st  ex n1 be IntegerINT-1M1 st m gcdINT-2K3 n =XBOOLE-0R4 m *XCMPLX-0K3 m1 +XCMPLX-0K2 n *XCMPLX-0K3 n1"
sorry

mtheorem wsierp_1_th_29:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds m dividesINT-1R1 n *XCMPLX-0K3 k & m gcdINT-2K3 n =XBOOLE-0R4 \<one>\<^sub>M implies m dividesINT-1R1 k"
sorry

mtheorem wsierp_1_th_30:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M & a dividesNAT-DR1 b *XCMPLX-0K3 c implies a dividesNAT-DR1 c"
  using wsierp_1_th_29 sorry

mtheorem wsierp_1_th_31:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies ( ex c be NatNAT-1M1 st  ex d be NatNAT-1M1 st a gcdINT-2K3 b =XBOOLE-0R4 a *XCMPLX-0K3 c -XCMPLX-0K6 b *XCMPLX-0K3 d)"
sorry

mtheorem wsierp_1_th_32:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for f be NatNAT-1M1 holds  for g be NatNAT-1M1 holds ((f >XXREAL-0R4 0NUMBERSK6 & g >XXREAL-0R4 0NUMBERSK6) & f gcdINT-2K3 g =XBOOLE-0R4 \<one>\<^sub>M) & a  |^NEWTONK1 f =XBOOLE-0R4 b  |^NEWTONK1 g implies ( ex e be NatNAT-1M1 st a =XBOOLE-0R4 e  |^NEWTONK1 g & b =XBOOLE-0R4 e  |^NEWTONK1 f)"
sorry

reserve x, y, t for "IntegerINT-1M1"
mtheorem wsierp_1_th_33:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds ( ex x be IntegerINT-1M1 st  ex y be IntegerINT-1M1 st m *XCMPLX-0K3 x +XCMPLX-0K2 n *XCMPLX-0K3 y =HIDDENR1 k) iff m gcdINT-2K3 n dividesINT-1R1 k"
sorry

mtheorem wsierp_1_th_34:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  for m1 be IntegerINT-1M1 holds  for n1 be IntegerINT-1M1 holds (m <>HIDDENR2 0NUMBERSK6 & n <>HIDDENR2 0NUMBERSK6) & m *XCMPLX-0K3 m1 +XCMPLX-0K2 n *XCMPLX-0K3 n1 =HIDDENR1 k implies ( for x be IntegerINT-1M1 holds  for y be IntegerINT-1M1 holds m *XCMPLX-0K3 x +XCMPLX-0K2 n *XCMPLX-0K3 y =HIDDENR1 k implies ( ex t be IntegerINT-1M1 st x =HIDDENR1 m1 +XCMPLX-0K2 t *XCMPLX-0K3 (n /XCMPLX-0K7 (m gcdINT-2K3 n)) & y =HIDDENR1 n1 -XCMPLX-0K6 t *XCMPLX-0K3 (m /XCMPLX-0K7 (m gcdINT-2K3 n))))"
sorry

mtheorem wsierp_1_th_35:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds  for d be NatNAT-1M1 holds a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M & a *XCMPLX-0K3 b =XBOOLE-0R4 c  |^NEWTONK1 d implies ( ex e be NatNAT-1M1 st  ex f be NatNAT-1M1 st a =XBOOLE-0R4 e  |^NEWTONK1 d & b =XBOOLE-0R4 f  |^NEWTONK1 d)"
sorry

(*\$N Chinese Remainder Theorem*)
mtheorem wsierp_1_th_36:
" for fp be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for d be NatNAT-1M1 holds ( for a be NatNAT-1M1 holds a inTARSKIR2 domFINSEQ-1K5 fp implies fp .FUNCT-1K1 a gcdINT-2K3 d =XBOOLE-0R4 \<one>\<^sub>M) implies ProductWSIERP-1K2 fp gcdINT-2K3 d =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_37:
" for fp be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds lenFINSEQ-1K4 fp >=XXREAL-0R2 \<two>\<^sub>M & ( for b be NatNAT-1M1 holds  for c be NatNAT-1M1 holds (b inTARSKIR2 domFINSEQ-1K5 fp & c inTARSKIR2 domFINSEQ-1K5 fp) & b <>HIDDENR2 c implies fp .FUNCT-1K1 b gcdINT-2K3 fp .FUNCT-1K1 c =XBOOLE-0R4 \<one>\<^sub>M) implies ( for fr be FinSequenceFINSEQ-1M3-of INTINT-1K1 holds lenFINSEQ-1K4 fr =XBOOLE-0R4 lenFINSEQ-1K4 fp implies ( ex fr1 be FinSequenceFINSEQ-1M3-of INTINT-1K1 st lenFINSEQ-1K4 fr1 =XBOOLE-0R4 lenFINSEQ-1K4 fp & ( for b be NatNAT-1M1 holds b inTARSKIR2 domFINSEQ-1K5 fp implies fp .FUNCT-1K1 b *XCMPLX-0K3 fr1 .FUNCT-1K1 b +XCMPLX-0K2 fr .FUNCT-1K1 b =XBOOLE-0R4 fp .FUNCT-1K1 \<one>\<^sub>M *XCMPLX-0K3 fr1 .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 fr .FUNCT-1K1 \<one>\<^sub>M)))"
sorry

mlemma wsierp_1_lm_17:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds k dividesINT-1R1 m iff k dividesINT-1R1  |.INT-2K1 m.|"
sorry

mlemma wsierp_1_lm_18:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds m *XCMPLX-0K3 n modINT-1K6 n =HIDDENR1 0NUMBERSK6"
sorry

mlemma wsierp_1_lm_19:
" for k be IntegerINT-1M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds k modINT-1K6 n =HIDDENR1 m modINT-1K6 n implies (k -XCMPLX-0K6 m)modINT-1K6 n =HIDDENR1 0NUMBERSK6"
sorry

mlemma wsierp_1_lm_20:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & m modINT-1K6 n =HIDDENR1 0NUMBERSK6 implies n dividesINT-1R1 m"
sorry

mlemma wsierp_1_lm_21:
" for x be IntegerINT-1M1 holds (\<one>\<^sub>M <XXREAL-0R3 x implies \<one>\<^sub>M <XXREAL-0R3 sqrtSQUARE-1K3 x & sqrtSQUARE-1K3 x <XXREAL-0R3 x) & (0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M implies (0NUMBERSK6 <XXREAL-0R3 sqrtSQUARE-1K3 x & sqrtSQUARE-1K3 x <XXREAL-0R3 \<one>\<^sub>M) & x <XXREAL-0R3 sqrtSQUARE-1K3 x)"
sorry

(*\$N Thue Theorem*)
mtheorem wsierp_1_th_38:
" for a be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & a gcdINT-2K3 k =XBOOLE-0R4 \<one>\<^sub>M implies ( ex b be NatNAT-1M1 st  ex e be NatNAT-1M1 st (((0NUMBERSK6 <>HIDDENR2 b & 0NUMBERSK6 <>HIDDENR2 e) & b <=XXREAL-0R1 sqrtSQUARE-1K3 a) & e <=XXREAL-0R1 sqrtSQUARE-1K3 a) & (a dividesINT-1R1 k *XCMPLX-0K3 b +XCMPLX-0K2 e or a dividesINT-1R1 k *XCMPLX-0K3 b -XCMPLX-0K6 e))"
sorry

mtheorem wsierp_1_th_39:
" for a be NatNAT-1M1 holds  for fs be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 (DelWSIERP-1K3(fs,a)) c=TARSKIR1 domFINSEQ-1K5 fs"
  using wsierp_1_lm_12 sorry

mtheorem wsierp_1_th_40:
" for fs be FinSequenceFINSEQ-1M1 holds  for v be objectHIDDENM1 holds DelWSIERP-1K3((<*FINSEQ-1K10 v*>)^FINSEQ-1K8 fs,\<one>\<^sub>M) =FINSEQ-1R1 fs & DelWSIERP-1K3(fs ^FINSEQ-1K8 (<*FINSEQ-1K10 v*>),lenFINSEQ-1K4 fs +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fs"
  using wsierp_1_lm_14 sorry

(*begin*)
reserve n for "NatNAT-1M1"
mtheorem wsierp_1_th_41:
" for k be IntegerINT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 & k modINT-1K6 n <>HIDDENR2 0NUMBERSK6 implies -XCMPLX-0K4 (k divINT-1K5 n) =HIDDENR1 ((-XCMPLX-0K4 k)divINT-1K5 n)+XCMPLX-0K2 \<one>\<^sub>M"
sorry

mtheorem wsierp_1_th_42:
" for k be IntegerINT-1M1 holds  for n be NatNAT-1M1 holds k modINT-1K6 n =HIDDENR1 0NUMBERSK6 implies -XCMPLX-0K4 (k divINT-1K5 n) =HIDDENR1 (-XCMPLX-0K4 k)divINT-1K5 n"
sorry

reserve i1, i2, i3 for "IntegerINT-1M1"
mlemma wsierp_1_lm_22:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds i1 dividesINT-1R1 i2 & i1 dividesINT-1R1 i3 implies i1 dividesINT-1R1 i2 -XCMPLX-0K6 i3"
sorry

mtheorem wsierp_1_th_43:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i3 implies i1 gcdINT-2K3 i3 =XBOOLE-0R4 i2 gcdINT-2K3 i3"
sorry

end
