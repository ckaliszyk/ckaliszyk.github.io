theory pre_circ
  imports funct_7 trees_4 orders_1 seq_4 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
theorem pre_circ_sch_1:
  fixes Af0 Ff1 Pp1 
  assumes
[ty]: "Af0 be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } be finiteFINSET-1V1"
sorry

(*begin*)
(*\$CT*)
mtheorem pre_circ_th_2:
" for I be setHIDDENM2 holds  for MSS be ManySortedSetPBOOLEM1-of I holds (MSS #FINSEQ-2K6\<^bsub>(I)\<^esub>).FUNCT-1K1 <*>FINSEQ-1K7 I =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
sorry

reserve i, j, x, y for "objectHIDDENM1"
reserve f, g for "FunctionFUNCT-1M1"
theorem pre_circ_sch_2:
  fixes If0 Ff1 Gf1 Pp1 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1"
  shows " ex f be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds i inTARSKIR2 If0 implies (Pp1(i) implies f .FUNCT-1K1 i =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies f .FUNCT-1K1 i =HIDDENR1 Gf1(i))"
sorry

mtheorem pre_circ_cl_1:
  mlet "I be setHIDDENM2"
"cluster non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3 for ManySortedSetPBOOLEM1-of I"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of I st it be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
sorry
qed "sorry"

mtheorem pre_circ_cl_2:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "A be SubsetSUBSET-1M2-of I"
"cluster M  |RELAT-1K8 A as-term-is totalPARTFUN1V1\<^bsub>(A)\<^esub> for A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 M  |RELAT-1K8 A implies it be totalPARTFUN1V1\<^bsub>(A)\<^esub>"
sorry
qed "sorry"

mtheorem pre_circ_cl_3:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "A be SubsetSUBSET-1M2-of I"
"cluster M  |RELAT-1K8 A as-term-is totalPARTFUN1V1\<^bsub>(A)\<^esub>"
proof
(*coherence*)
  show "M  |RELAT-1K8 A be totalPARTFUN1V1\<^bsub>(A)\<^esub>"
     sorry
qed "sorry"

mtheorem pre_circ_cl_4:
  mlet "M be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1", "A be setHIDDENM2"
"cluster M  |RELAT-1K8 A as-term-is non-emptyFUNCT-1V4"
proof
(*coherence*)
  show "M  |RELAT-1K8 A be non-emptyFUNCT-1V4"
sorry
qed "sorry"

mtheorem pre_circ_th_3:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds unionTARSKIK3 (rngFUNCT-1K2 B) be  non emptyXBOOLE-0V1"
sorry

mtheorem pre_circ_th_4:
" for I be setHIDDENM2 holds uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
sorry

mtheorem pre_circ_th_5:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(I -->FUNCOP-1K7 A,B) holds domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
sorry

theorem pre_circ_sch_3:
  fixes Df0 Af0 Ff2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be ElementSUBSET-1M1-of Df0 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Df0"
  shows "( ex f be sequenceNAT-1M2-of Df0 st f .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f .NAT-1K8\<^bsub>(Df0)\<^esub> i))) & ( for f1 be sequenceNAT-1M2-of Df0 holds  for f2 be sequenceNAT-1M2-of Df0 holds (f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f1 .NAT-1K8\<^bsub>(Df0)\<^esub> i))) & (f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f2 .NAT-1K8\<^bsub>(Df0)\<^esub> i))) implies f1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> f2)"
sorry

theorem pre_circ_sch_4:
  fixes Jf0 If0 Af0 Bf0 Ff1 
  assumes
[ty]: "Jf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "If0 be SubsetSUBSET-1M2-of Jf0" and
  [ty]: "Af0 be ManySortedSetPBOOLEM1-of If0" and
  [ty]: "Bf0 be ManySortedSetPBOOLEM1-of If0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: " for i be ElementSUBSET-1M1-of Jf0 holds i inTARSKIR2 If0 implies Ff1(i) be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i)"
  shows " ex f be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be ElementSUBSET-1M1-of Jf0 holds i inTARSKIR2 If0 implies f .FUNCT-1K1 i =XBOOLE-0R4 Ff1(i)"
sorry

mtheorem pre_circ_th_6:
" for I be setHIDDENM2 holds  for f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for g be FunctionFUNCT-1M1 holds  for s be ElementSUBSET-1M1-of productCARD-3K4 f holds domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f & ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x) implies s +*FUNCT-4K1 g be ElementSUBSET-1M1-of productCARD-3K4 f"
sorry

mtheorem pre_circ_th_7:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of A holds  for InpFs be ManySortedFunctionPBOOLEM5\<^bsub>(A)\<^esub>-of(A -->FUNCOP-1K7 B,C) holds  for b be ElementSUBSET-1M1-of B holds  ex c be ManySortedSetPBOOLEM1-of A st c =FUNCT-1R1 (commuteFUNCT-6K9 InpFs).FUNCT-1K1 b & c inPBOOLER3\<^bsub>(A)\<^esub> C"
sorry

mtheorem pre_circ_th_8:
" for n be NatNAT-1M1 holds  for a be setHIDDENM2 holds productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a}) =XBOOLE-0R4 {TARSKIK1 n  |->FINSEQ-2K2 a }"
sorry

(*begin*)
reserve T, T1 for "finiteFINSET-1V1\<bar>TreeTREES-1M1"
reserve t, p for "ElementTREES-1M2-of T"
reserve t1 for "ElementTREES-1M2-of T1"
mtheorem pre_circ_cl_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of FinTreesTREES-3K5 D holds it be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem pre_circ_cl_6:
  mlet "T be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4", "t be ElementTREES-1M2-of domRELAT-1K1 T"
"cluster T  |TREES-2K5 t as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "T  |TREES-2K5 t be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem pre_circ_th_9:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds (T  |TREES-1K4 p,{t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t })are-equipotentTARSKIR3"
sorry

mtheorem pre_circ_cl_7:
  mlet "T be finiteFINSET-1V1\<bar>DecoratedTree-likeTREES-2V3\<bar>FunctionFUNCT-1M1", "t be ElementTREES-1M2-of domRELAT-1K1 T", "T1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4"
"cluster T with-replacementTREES-2K7(t,T1) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "T with-replacementTREES-2K7(t,T1) be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem pre_circ_th_10:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  })"
sorry

mtheorem pre_circ_th_11:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds f inTARSKIR2 T with-replacementTREES-1K5(p,T1) & p is-a-prefix-ofTREES-1R2 f implies ( ex t1 be ElementTREES-1M2-of T1 st f =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1)"
sorry

mtheorem pre_circ_th_12:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem pre_circ_th_13:
" for q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q implies <*FINSEQ-1K10 k*> inTARSKIR2 treeTREES-3K11 domsFUNCT-6K1 q"
sorry

mtheorem pre_circ_th_14:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i) implies ( for t be TreeTREES-1M1 holds q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t implies treeTREES-3K11 q =TREES-2R1 (treeTREES-3K11 p)with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,t))"
sorry

mtheorem pre_circ_th_15:
" for e1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for e2 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> inTARSKIR2 domRELAT-1K1 e1 & e1 =TREES-4R1 x -treeTREES-4K4 p implies ( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st ((e1 with-replacementTREES-2K7(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,e2) =TREES-4R1 x -treeTREES-4K4 q & lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p) & q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 e2) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies q .FUNCT-1K1 i =FUNCT-1R1 p .FUNCT-1K1 i))"
sorry

mtheorem pre_circ_th_16:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds p <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K4 (T  |TREES-1K4 p) <XXREAL-0R3 cardCARD-1K4 T"
sorry

mtheorem pre_circ_th_17:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds cardCARD-1K4 (T with-replacementTREES-1K5(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-1K4 p) =XBOOLE-0R4 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
sorry

mtheorem pre_circ_th_18:
" for T be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for T1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds cardCARD-1K4 (T with-replacementTREES-2K7(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-2K5 p) =XBOOLE-0R4 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
sorry

mtheorem pre_circ_cl_8:
  mlet "x be objectHIDDENM1"
"cluster root-treeTREES-4K1 x as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "root-treeTREES-4K1 x be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem pre_circ_th_19:
" for x be setHIDDENM2 holds cardCARD-1K4 (root-treeTREES-4K1 x) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

(*begin*)
mtheorem pre_circ_th_20:
" for F be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
sorry

mtheorem pre_circ_th_21:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3 iff (f,g)are-equipotentTARSKIR3"
sorry

mtheorem pre_circ_th_22:
" for f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for g be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g implies cardCARD-1K4 (f +*FUNCT-4K1 g) =XBOOLE-0R4 cardCARD-1K4 f +NAT-1K1 cardCARD-1K4 g"
sorry

mtheorem pre_circ_th_23:
" for n be NatNAT-1M1 holds {k where k be NatNAT-1M1 : k >XXREAL-0R4 n } be infiniteFINSET-1V2"
sorry

mtheorem pre_circ_th_24:
" for D be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for k be NatNAT-1M1 holds cardCARD-1K4 D =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies ( ex x be ElementSUBSET-1M1-of D st  ex C be SubsetSUBSET-1M2-of D st D =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x} & cardCARD-1K4 C =XBOOLE-0R4 k)"
sorry

mtheorem pre_circ_th_25:
" for D be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 D =XBOOLE-0R4 \<one>\<^sub>M implies ( ex x be ElementSUBSET-1M1-of D st D =XBOOLE-0R4 {TARSKIK1 x})"
sorry

reserve k for "NatNAT-1M1"
theorem pre_circ_sch_5:
  fixes Df0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be ElementSUBSET-1M1-of Df0 \<Longrightarrow> Ff1(x1) be RealXREAL-0M1"
  shows " ex x be ElementSUBSET-1M1-of Df0 st  for y be ElementSUBSET-1M1-of Df0 holds Ff1(x) <=XXREAL-0R1 Ff1(y)"
sorry

end
