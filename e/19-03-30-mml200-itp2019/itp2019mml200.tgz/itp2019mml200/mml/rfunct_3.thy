theory rfunct_3
  imports setwop_2 partfun2 limfunc1 rfinseq
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m for "NatNAT-1M1"
reserve r, r1, r2, s, t for "RealXREAL-0M1"
mdef rfunct_3_def_1 ("max+RFUNCT-3K1  _ " [300]300 ) where
  mlet "r be RealXREAL-0M1"
"func max+RFUNCT-3K1 r \<rightarrow> RealXREAL-0M1 equals
  maxXXREAL-0K5(r,0NUMBERSK6)"
proof-
  (*coherence*)
    show "maxXXREAL-0K5(r,0NUMBERSK6) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef rfunct_3_def_2 ("max-RFUNCT-3K2  _ " [300]300 ) where
  mlet "r be RealXREAL-0M1"
"func max-RFUNCT-3K2 r \<rightarrow> RealXREAL-0M1 equals
  maxXXREAL-0K5(-XCMPLX-0K4 r,0NUMBERSK6)"
proof-
  (*coherence*)
    show "maxXXREAL-0K5(-XCMPLX-0K4 r,0NUMBERSK6) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rfunct_3_th_1:
" for r be RealXREAL-0M1 holds r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
sorry

mtheorem rfunct_3_th_2:
" for r be RealXREAL-0M1 holds  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
sorry

mtheorem rfunct_3_th_3:
" for r be RealXREAL-0M1 holds \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K1 r =COMPLEX1R1 r +XCMPLX-0K2  |.COMPLEX1K10 r.|"
sorry

mtheorem rfunct_3_th_4:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r implies max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
sorry

mtheorem rfunct_3_th_5:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
sorry

mlemma rfunct_3_lm_1:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =FINSEQ-1R1 f"
sorry

mlemma rfunct_3_lm_2:
" for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  not x inTARSKIR2 rngFUNCT-1K2 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

(*begin*)
mtheorem rfunct_3_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } =XBOOLE-0R4 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
sorry

mtheorem rfunct_3_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
sorry

mtheorem rfunct_3_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
sorry

mtheorem rfunct_3_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem rfunct_3_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 0NUMBERSK6 implies absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem rfunct_3_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies ((F,G)are-fiberwise-equipotentCLASSES1R2 iff (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2)"
sorry

mtheorem rfunct_3_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 iff (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F,-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
  using rfunct_3_th_11 sorry

mtheorem rfunct_3_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F,absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
sorry

mdef rfunct_3_def_3 ("PartFunc-setRFUNCT-3M1-of'( _ , _ ')" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"mode PartFunc-setRFUNCT-3M1-of(X,Y) \<rightarrow> setHIDDENM2 means
  (\<lambda>it.  for x be ElementSUBSET-1M1-of it holds x be PartFuncPARTFUN1M1-of(X,Y))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be ElementSUBSET-1M1-of it holds x be PartFuncPARTFUN1M1-of(X,Y)"
sorry
qed "sorry"

mtheorem rfunct_3_cl_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for PartFunc-setRFUNCT-3M1-of(X,Y)"
proof
(*existence*)
  show " ex it be PartFunc-setRFUNCT-3M1-of(X,Y) st it be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

abbreviation(input) RFUNCT_3M2("PFUNC-DOMAINRFUNCT-3M2-of'( _ , _ ')" [0,0]70) where
  "PFUNC-DOMAINRFUNCT-3M2-of(X,Y) \<equiv>  non emptyXBOOLE-0V1\<bar>PartFunc-setRFUNCT-3M1-of(X,Y)"

abbreviation(input) RFUNCT_3K3("PFuncsRFUNCT-3K3'( _ , _ ')" [0,0]228) where
  "PFuncsRFUNCT-3K3(X,Y) \<equiv> PFuncsPARTFUN1K4(X,Y)"

mtheorem rfunct_3_add_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is PartFunc-setRFUNCT-3M1-of(X,Y)"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be PartFunc-setRFUNCT-3M1-of(X,Y)"
sorry
qed "sorry"

syntax RFUNCT_3M3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementRFUNCT-3M3\<^bsub>'( _ , _ ')\<^esub>-of  _ " [0,0,70]70)
translations "ElementRFUNCT-3M3\<^bsub>(X,Y)\<^esub>-of P" \<rightharpoonup> "ElementSUBSET-1M1-of P"

mtheorem rfunct_3_add_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "P be  non emptyXBOOLE-0V1\<bar>PartFunc-setRFUNCT-3M1-of(X,Y)"
"cluster note-that PartFuncPARTFUN1M1-of(X,Y) for ElementSUBSET-1M1-of P"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of P holds it be PartFuncPARTFUN1M1-of(X,Y)"
    using rfunct_3_def_3 sorry
qed "sorry"

syntax RFUNCT_3K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -->RFUNCT-3K4\<^bsub>'( _ , _ ')\<^esub>  _ " [116,0,0,116]116)
translations "X -->RFUNCT-3K4\<^bsub>(D,C)\<^esub> c" \<rightharpoonup> "X -->FUNCOP-1K2 c"

mtheorem rfunct_3_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be SubsetSUBSET-1M2-of D", "c be ElementSUBSET-1M1-of C"
"cluster X -->FUNCOP-1K2 c as-term-is ElementRFUNCT-3M3\<^bsub>(D,C)\<^esub>-of PFuncsRFUNCT-3K3(D,C)"
proof
(*coherence*)
  show "X -->FUNCOP-1K2 c be ElementRFUNCT-3M3\<^bsub>(D,C)\<^esub>-of PFuncsRFUNCT-3K3(D,C)"
sorry
qed "sorry"

mtheorem rfunct_3_cl_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster note-that real-valuedVALUED-0V7 for ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
proof
(*coherence*)
  show " for it be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E) holds it be real-valuedVALUED-0V7"
     sorry
qed "sorry"

syntax RFUNCT_3K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +RFUNCT-3K5\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "F1 +RFUNCT-3K5\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 +VALUED-1K1 F2"

mtheorem rfunct_3_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 +VALUED-1K1 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 +VALUED-1K1 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -RFUNCT-3K6\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "F1 -RFUNCT-3K6\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 -VALUED-1K47 F2"

mtheorem rfunct_3_add_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 -VALUED-1K47 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 -VALUED-1K47 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')RFUNCT-3K7\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "F1 (#)RFUNCT-3K7\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 (#)VALUED-1K19 F2"

mtheorem rfunct_3_add_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 (#)VALUED-1K19 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 (#)VALUED-1K19 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/RFUNCT-3K8\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "F1 /RFUNCT-3K8\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 /RFUNCT-1K1 F2"

mtheorem rfunct_3_add_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 /RFUNCT-1K1 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 /RFUNCT-1K1 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absRFUNCT-3K9\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absRFUNCT-3K9\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> " |.VALUED-1K56 F.|"

mtheorem rfunct_3_add_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster  |.VALUED-1K56 F.| as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show " |.VALUED-1K56 F.| be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("-RFUNCT-3K10\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132)
translations "-RFUNCT-3K10\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> "-VALUED-1K32 F"

mtheorem rfunct_3_add_9:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster -VALUED-1K32 F as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "-VALUED-1K32 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^RFUNCT-3K11\<^bsub>'( _ , _ ')\<^esub>" [164,0,0]164)
translations "F ^RFUNCT-3K11\<^bsub>(D,E)\<^esub>" \<rightharpoonup> "F ^RFUNCT-1K4"

mtheorem rfunct_3_add_10:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F ^RFUNCT-1K4 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F ^RFUNCT-1K4 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

syntax RFUNCT_3K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')RFUNCT-3K12\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)RFUNCT-3K12\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> "r (#)VALUED-1K25 F"

mtheorem rfunct_3_add_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 F as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
sorry
qed "sorry"

mdef rfunct_3_def_4 ("addpfuncRFUNCT-3K13  _ " [300]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func addpfuncRFUNCT-3K13 D \<rightarrow> BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) means
  \<lambda>it.  for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st  for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2"
sorry
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for it2 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds ( for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2) & ( for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it2 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem rfunct_3_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds addpfuncRFUNCT-3K13 D be commutativeBINOP-1V1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
sorry

mtheorem rfunct_3_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds addpfuncRFUNCT-3K13 D be associativeBINOP-1V2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
sorry

mtheorem rfunct_3_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D"
sorry

mtheorem rfunct_3_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds the-unity-wrtBINOP-1K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D =FUNCT-1R1 [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
sorry

mtheorem rfunct_3_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds addpfuncRFUNCT-3K13 D be having-a-unitySETWISEOV1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
sorry

mdef rfunct_3_def_5 ("SumRFUNCT-3K14\<^bsub>'( _ ')\<^esub>  _ " [0,260]260 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
"func SumRFUNCT-3K14\<^bsub>(D)\<^esub> f \<rightarrow> ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) equals
  addpfuncRFUNCT-3K13 D $$SETWOP-2K5\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f"
proof-
  (*coherence*)
    show "addpfuncRFUNCT-3K13 D $$SETWOP-2K5\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem rfunct_3_th_19:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2)) =FUNCT-1R1 [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
sorry

mtheorem rfunct_3_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
sorry

mtheorem rfunct_3_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f2) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f2"
sorry

mtheorem rfunct_3_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
sorry

mtheorem rfunct_3_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2"
sorry

mtheorem rfunct_3_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G3 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2,G3 *>) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2)+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G3"
sorry

mtheorem rfunct_3_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (f,g)are-fiberwise-equipotentCLASSES1R2 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
sorry

mdef rfunct_3_def_6 ("CHIRFUNCT-3K15'( _ , _ ')" [0,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M1"
"func CHIRFUNCT-3K15(f,D) \<rightarrow> FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) means
  \<lambda>it. lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for it2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (lenFINSEQ-1K4 it1 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))) & (lenFINSEQ-1K4 it2 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef rfunct_3_def_7 (" _ '(#')RFUNCT-3K16\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)", "R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"func R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f \<rightarrow> FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) means
  \<lambda>it. lenFINSEQ-1K4 it =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 it =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for it2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (lenFINSEQ-1K4 it1 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it1 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it1 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))) & (lenFINSEQ-1K4 it2 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it2 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it2 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef rfunct_3_def_8 (" _ #RFUNCT-3K17\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)", "d be ElementSUBSET-1M1-of D"
"func f #RFUNCT-3K17\<^bsub>(D)\<^esub> d \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 it1 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)) & (lenFINSEQ-1K4 it2 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef rfunct_3_def_9 (" _ is-common-for-domRFUNCT-3R1\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,C)", "d be ElementSUBSET-1M1-of D"
"pred d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f means
   for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 n)"..

mtheorem rfunct_3_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,C) holds  for d be ElementSUBSET-1M1-of D holds  for n be NatNAT-1M1 holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f & n <>HIDDENR2 0NUMBERSK6 implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,C))\<^esub> n"
sorry

mtheorem rfunct_3_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,C) holds  for d be ElementSUBSET-1M1-of D holds  for n be NatNAT-1M1 holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,C))\<^esub> n"
sorry

mtheorem rfunct_3_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f iff d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f)"
sorry

mtheorem rfunct_3_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds  for n be NatNAT-1M1 holds f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D)\<^esub> d =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
sorry

mtheorem rfunct_3_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds  for d be ElementSUBSET-1M1-of D holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> CHIRFUNCT-3K15(f,D)"
sorry

mtheorem rfunct_3_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f"
sorry

mtheorem rfunct_3_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds  for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for d be ElementSUBSET-1M1-of D holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> CHIRFUNCT-3K15(f,D)"
  using rfunct_3_th_30 rfunct_3_th_31 sorry

mtheorem rfunct_3_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
sorry

mdef rfunct_3_def_10 ("max+RFUNCT-3K18\<^bsub>'( _ ')\<^esub>  _ " [0,300]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<rightarrow> PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))"
sorry
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef rfunct_3_def_11 ("max-RFUNCT-3K19\<^bsub>'( _ ')\<^esub>  _ " [0,300]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<rightarrow> PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))"
sorry
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem rfunct_3_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F & absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F) & \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
sorry

mtheorem rfunct_3_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
sorry

mtheorem rfunct_3_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem rfunct_3_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds 0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
sorry

mtheorem rfunct_3_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
sorry

mtheorem rfunct_3_th_39:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem rfunct_3_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds 0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
sorry

mtheorem rfunct_3_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,max+RFUNCT-3K18\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfunct_3_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,max-RFUNCT-3K19\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfunct_3_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"cluster max+RFUNCT-3K18\<^bsub>(D)\<^esub> F as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem rfunct_3_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"cluster max-RFUNCT-3K19\<^bsub>(D)\<^esub> F as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
sorry
qed "sorry"

mtheorem rfunct_3_th_43:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,max+RFUNCT-3K18\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2 & (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,max-RFUNCT-3K19\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2 implies (F,G)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfunct_3_th_44:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
sorry

mtheorem rfunct_3_th_45:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
sorry

mtheorem rfunct_3_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6) implies max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
sorry

mtheorem rfunct_3_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies F .FUNCT-1K1 d <=XXREAL-0R1 0NUMBERSK6) implies max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
sorry

mtheorem rfunct_3_th_48:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6 =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
sorry

mtheorem rfunct_3_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
sorry

mtheorem rfunct_3_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } =XBOOLE-0R4 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
sorry

mtheorem rfunct_3_th_51:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 iff (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
sorry

mdef rfunct_3_def_12 (" _ is-convex-onRFUNCT-3R2  _ " [50,50]50 ) where
  mlet "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred F is-convex-onRFUNCT-3R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies F .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 s))"..

mtheorem rfunct_3_th_52:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds F is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] iff [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 a,b .] & s inHIDDENR3 [.RCOMP-1K1 a,b .] implies F .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 s))"
sorry

mtheorem rfunct_3_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds F is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] iff [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x1 <XXREAL-0R3 x2) & x2 <XXREAL-0R3 x3 implies (F .FUNCT-1K1 x1 -XCMPLX-0K6 F .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (F .FUNCT-1K1 x2 -XCMPLX-0K6 F .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3))"
sorry

mtheorem rfunct_3_th_54:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds F is-convex-onRFUNCT-3R2 X & Y c=TARSKIR1 X implies F is-convex-onRFUNCT-3R2 Y"
sorry

mtheorem rfunct_3_th_55:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds F is-convex-onRFUNCT-3R2 X iff F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X"
sorry

mtheorem rfunct_3_th_56:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies (F is-convex-onRFUNCT-3R2 X iff r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X)"
sorry

mtheorem rfunct_3_th_57:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F implies (0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
sorry

mtheorem rfunct_3_th_58:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds F is-convex-onRFUNCT-3R2 X & G is-convex-onRFUNCT-3R2 X implies F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G is-convex-onRFUNCT-3R2 X"
sorry

mtheorem rfunct_3_th_59:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds F is-convex-onRFUNCT-3R2 X implies max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) is-convex-onRFUNCT-3R2 X"
sorry

mtheorem rfunct_3_th_60:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds F is-convex-onRFUNCT-3R2 X implies max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
sorry

mtheorem rfunct_3_th_61:
"idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) is-convex-onRFUNCT-3R2 REALNUMBERSK2"
sorry

mtheorem rfunct_3_th_62:
" for r be RealXREAL-0M1 holds max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) is-convex-onRFUNCT-3R2 REALNUMBERSK2"
  using rfunct_3_th_59 rfunct_3_th_61 sorry

mdef rfunct_3_def_13 ("FinSRFUNCT-3K20\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"assume domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 func FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) \<rightarrow> non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it)are-fiberwise-equipotentCLASSES1R2"
proof-
  (*existence*)
    show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies ( ex it be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it)are-fiberwise-equipotentCLASSES1R2)"
sorry
  (*uniqueness*)
    show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies ( for it1 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it1)are-fiberwise-equipotentCLASSES1R2 & (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it2)are-fiberwise-equipotentCLASSES1R2 implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem rfunct_3_th_63:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
sorry

mtheorem rfunct_3_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
sorry

mtheorem rfunct_3_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds X be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfunct_3_th_66:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
sorry

mtheorem rfunct_3_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 cardCARD-1K4 Y"
sorry

mtheorem rfunct_3_th_68:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
sorry

mtheorem rfunct_3_th_69:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =FINSEQ-1R1 <*FINSEQ-1K10 F .FUNCT-1K1 d*>"
sorry

mtheorem rfunct_3_th_70:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
sorry

mlemma rfunct_3_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & 0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
sorry

mlemma rfunct_3_lm_4:
" for n be NatNAT-1M1 holds ( for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)) implies ( for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y))"
sorry

mtheorem rfunct_3_th_71:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & Y c=TARSKIR1 X) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
sorry

mtheorem rfunct_3_th_72:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d iff FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d)"
sorry

mtheorem rfunct_3_th_73:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 Z  |->FINSEQ-2K2 r"
sorry

mtheorem rfunct_3_th_74:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
sorry

mtheorem rfunct_3_th_75:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {TARSKIK1 r} implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 cardCARD-1K4 Z  |->FINSEQ-2K2 r"
sorry

mtheorem rfunct_3_th_76:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & X missesXBOOLE-0R1 Y implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
sorry

mdef rfunct_3_def_14 ("SumRFUNCT-3K21\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]260 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"func SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) \<rightarrow> RealXREAL-0M1 equals
  SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
proof-
  (*coherence*)
    show "SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rfunct_3_th_77:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,X) =COMPLEX1R1 r *XCMPLX-0K3 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X)"
sorry

mtheorem rfunct_3_th_78:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
sorry

mtheorem rfunct_3_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
sorry

mtheorem rfunct_3_th_80:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 r *XCMPLX-0K3 cardCARD-1K4 Y"
sorry

mtheorem rfunct_3_th_81:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1) =COMPLEX1R1 0NUMBERSK6"
  using rfunct_3_th_68 rvsum_1_th_72 sorry

mtheorem rfunct_3_th_82:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =COMPLEX1R1 F .FUNCT-1K1 d"
sorry

mtheorem rfunct_3_th_83:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & X missesXBOOLE-0R1 Y implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
sorry

mtheorem rfunct_3_th_84:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
sorry

end
