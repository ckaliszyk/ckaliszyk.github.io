theory card_5
  imports ordinal4 card_4 funct_5 xfamily
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, n, m for "NatNAT-1M1"
reserve A, B, C for "OrdinalORDINAL1M3"
reserve X for "setHIDDENM2"
reserve x, y, z for "objectHIDDENM1"
mlemma card_5_lm_1:
"\<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 \<one>\<^sub>M"
   sorry

mlemma card_5_lm_2:
"\<two>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 \<two>\<^sub>M"
   sorry

(*begin*)
reserve f, g, h, fx for "FunctionFUNCT-1M1"
reserve K, M, N for "CardinalCARD-1M1"
reserve phi, psi for "Ordinal-SequenceORDINAL2M1"
mtheorem card_5_th_1:
" for X be setHIDDENM2 holds nextcardCARD-1K2 (cardCARD-1K1 X) =XBOOLE-0R4 nextcardCARD-1K2 X"
sorry

mtheorem card_5_th_2:
" for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds y inHIDDENR3 UnionCARD-3K3 f iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x)"
sorry

mtheorem card_5_th_3:
" for A be OrdinalORDINAL1M3 holds alephCARD-1K3 A be infiniteFINSET-1V2"
sorry

mtheorem card_5_th_4:
" for M be CardinalCARD-1M1 holds M be infiniteFINSET-1V2 implies ( ex A be OrdinalORDINAL1M3 st M =XBOOLE-0R4 alephCARD-1K3 A)"
sorry

mtheorem card_5_cl_1:
  mlet "phi be Ordinal-SequenceORDINAL2M1"
"cluster UnionCARD-3K3 phi as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "UnionCARD-3K3 phi be ordinalORDINAL1V3"
sorry
qed "sorry"

mtheorem card_5_th_5:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies ( ex phi be Ordinal-SequenceORDINAL2M1 st ((phi =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X) & phi be increasingORDINAL2V2) & domRELAT-1K1 phi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X) & rngFUNCT-1K2 phi =XBOOLE-0R4 X)"
sorry

mtheorem card_5_th_6:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies supORDINAL2K3 X is-cofinal-withORDINAL2R2 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
sorry

mtheorem card_5_th_7:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X)"
sorry

mtheorem card_5_th_8:
" for A be OrdinalORDINAL1M3 holds  ex B be OrdinalORDINAL1M3 st B c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 B"
sorry

mtheorem card_5_th_9:
" for A be OrdinalORDINAL1M3 holds  ex M be CardinalCARD-1M1 st (M c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 M) & ( for B be OrdinalORDINAL1M3 holds A is-cofinal-withORDINAL2R2 B implies M c=ORDINAL1R1 B)"
sorry

mlemma card_5_lm_3:
" for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2) & psi be increasingORDINAL2V2 implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 phi implies A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A)"
sorry

mtheorem card_5_th_10:
" for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2) & psi be increasingORDINAL2V2 implies phi =FUNCT-1R1 psi"
sorry

mtheorem card_5_th_11:
" for phi be Ordinal-SequenceORDINAL2M1 holds phi be increasingORDINAL2V2 implies phi be one-to-oneFUNCT-1V2"
sorry

mtheorem card_5_th_12:
" for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (phi ^ORDINAL4K1 psi) |RELAT-1K8 domRELAT-1K1 phi =FUNCT-1R1 phi"
sorry

mtheorem card_5_th_13:
" for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K1 ({Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 Y inTARSKIR2 M }) c=ORDINAL1R1 M *`CARD-2K2 (expCARD-2K3(cardCARD-1K1 X,M))"
sorry

mtheorem card_5_th_14:
" for M be CardinalCARD-1M1 holds M inTARSKIR2 expCARD-2K3(\<two>\<^sub>M,M)"
sorry

mtheorem card_5_cl_2:
"cluster infiniteFINSET-1V2 for CardinalCARD-1M1"
proof
(*existence*)
  show " ex it be CardinalCARD-1M1 st it be infiniteFINSET-1V2"
sorry
qed "sorry"

mtheorem card_5_cl_3:
"cluster infiniteFINSET-1V2 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be infiniteFINSET-1V2 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

syntax CARD_5M1 :: "Ty" ("AlephCARD-5M1" 70)
translations "AlephCARD-5M1" \<rightharpoonup> "infiniteFINSET-1V2\<bar>CardinalCARD-1M1"

mdef card_5_def_1 ("cfCARD-5K1  _ " [164]164 ) where
  mlet "M be CardinalCARD-1M1"
"func cfCARD-5K1 M \<rightarrow> CardinalCARD-1M1 means
  \<lambda>it. M is-cofinal-withORDINAL2R2 it & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it c=ORDINAL1R1 N)"
proof-
  (*existence*)
    show " ex it be CardinalCARD-1M1 st M is-cofinal-withORDINAL2R2 it & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it c=ORDINAL1R1 N)"
sorry
  (*uniqueness*)
    show " for it1 be CardinalCARD-1M1 holds  for it2 be CardinalCARD-1M1 holds (M is-cofinal-withORDINAL2R2 it1 & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it1 c=ORDINAL1R1 N)) & (M is-cofinal-withORDINAL2R2 it2 & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it2 c=ORDINAL1R1 N)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mdef card_5_def_2 (" _ -powerfunc-ofCARD-5K2  _ " [164,164]164 ) where
  mlet "M be CardinalCARD-1M1", "N be CardinalCARD-1M1"
"func N -powerfunc-ofCARD-5K2 M \<rightarrow> Cardinal-FunctionCARD-3M1 means
  \<lambda>it. ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))"
proof-
  (*existence*)
    show " ex it be Cardinal-FunctionCARD-3M1 st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))"
sorry
  (*uniqueness*)
    show " for it1 be Cardinal-FunctionCARD-3M1 holds  for it2 be Cardinal-FunctionCARD-3M1 holds (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it1 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it2 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem card_5_cl_4:
  mlet "A be OrdinalORDINAL1M3"
"cluster alephCARD-1K3 A as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "alephCARD-1K3 A be infiniteFINSET-1V2"
    using card_5_th_3 sorry
qed "sorry"

(*begin*)
reserve a, b for "AlephCARD-5M1"
(*\$CT*)
mtheorem card_5_th_16:
" for n be NatNAT-1M1 holds  for a be AlephCARD-5M1 holds ((((a <>HIDDENR2 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & a <>HIDDENR2 \<two>\<^sub>M) & a <>HIDDENR2 cardCARD-1K4 n) & cardCARD-1K4 n inTARSKIR2 a) & omegaORDINAL1K4 c=MEMBEREDR6 a"
sorry

mtheorem card_5_th_17:
" for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds a c=ORDINAL1R1 M or a inTARSKIR2 M implies M be AlephCARD-5M1"
sorry

mtheorem card_5_th_18:
" for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds a c=ORDINAL1R1 M or a inTARSKIR2 M implies ((a +`CARD-2K1 M =XBOOLE-0R4 M & M +`CARD-2K1 a =XBOOLE-0R4 M) & a *`CARD-2K2 M =XBOOLE-0R4 M) & M *`CARD-2K2 a =XBOOLE-0R4 M"
sorry

mtheorem card_5_th_19:
" for a be AlephCARD-5M1 holds a +`CARD-2K1 a =XBOOLE-0R4 a & a *`CARD-2K2 a =XBOOLE-0R4 a"
  using card_2_th_75 card_4_th_15 sorry

mtheorem card_5_th_20:
" for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds M c=ORDINAL1R1 expCARD-2K3(M,a)"
sorry

mtheorem card_5_th_21:
" for a be AlephCARD-5M1 holds unionTARSKIK3 a =XBOOLE-0R4 a"
  using ordinal1_def_6 sorry

mtheorem card_5_cl_5:
  mlet "a be AlephCARD-5M1", "M be CardinalCARD-1M1"
"cluster a +`CARD-2K1 M as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "a +`CARD-2K1 M be infiniteFINSET-1V2"
sorry
qed "sorry"

mtheorem card_5_cl_6:
  mlet "M be CardinalCARD-1M1", "a be AlephCARD-5M1"
"cluster M +`CARD-2K1 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "M +`CARD-2K1 a be infiniteFINSET-1V2"
     sorry
qed "sorry"

mtheorem card_5_cl_7:
  mlet "a be AlephCARD-5M1", "b be AlephCARD-5M1"
"cluster a *`CARD-2K2 b as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "a *`CARD-2K2 b be infiniteFINSET-1V2"
sorry
qed "sorry"

mtheorem card_5_cl_8:
  mlet "a be AlephCARD-5M1", "b be AlephCARD-5M1"
"cluster expCARD-2K3(a,b) as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "expCARD-2K3(a,b) be infiniteFINSET-1V2"
sorry
qed "sorry"

(*begin*)
mdef card_5_def_3 ("regularCARD-5V1" 70 ) where
"attr regularCARD-5V1 for AlephCARD-5M1 means
  (\<lambda>IT. cfCARD-5K1 IT =XBOOLE-0R4 IT)"..

syntax CARD_5V2 :: "Ty" ("irregularCARD-5V2" 70)
translations "irregularCARD-5V2" \<rightharpoonup> " non regularCARD-5V1"

mtheorem card_5_cl_9:
  mlet "a be AlephCARD-5M1"
"cluster nextcardCARD-1K2 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "nextcardCARD-1K2 a be infiniteFINSET-1V2"
sorry
qed "sorry"

mtheorem card_5_th_22:
"cfCARD-5K1 omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4"
sorry

mtheorem card_5_th_23:
" for a be AlephCARD-5M1 holds cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
sorry

mtheorem card_5_th_24:
" for a be AlephCARD-5M1 holds omegaORDINAL1K4 c=MEMBEREDR6 cfCARD-5K1 a"
sorry

mtheorem card_5_th_25:
" for n be NatNAT-1M1 holds cfCARD-5K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem card_5_th_26:
" for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X c=TARSKIR1 M & cardCARD-1K1 X inTARSKIR2 cfCARD-5K1 M implies supORDINAL2K3 X inTARSKIR2 M & unionTARSKIK3 X inTARSKIR2 M"
sorry

mtheorem card_5_th_27:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for phi be Ordinal-SequenceORDINAL2M1 holds (domRELAT-1K1 phi =XBOOLE-0R4 M & rngFUNCT-1K2 phi c=TARSKIR1 N) & M inTARSKIR2 cfCARD-5K1 N implies supORDINAL2K4 phi inTARSKIR2 N & UnionCARD-3K3 phi inTARSKIR2 N"
sorry

mtheorem card_5_cl_10:
  mlet "a be AlephCARD-5M1"
"cluster cfCARD-5K1 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "cfCARD-5K1 a be infiniteFINSET-1V2"
    using card_5_th_17 card_5_th_24 sorry
qed "sorry"

mtheorem card_5_th_28:
" for a be AlephCARD-5M1 holds cfCARD-5K1 a inTARSKIR2 a implies a be limit-cardinalCARD-1V2"
sorry

mtheorem card_5_th_29:
" for a be AlephCARD-5M1 holds cfCARD-5K1 a inTARSKIR2 a implies ( ex xi be Ordinal-SequenceORDINAL2M1 st ((((domRELAT-1K1 xi =XBOOLE-0R4 cfCARD-5K1 a & rngFUNCT-1K2 xi c=TARSKIR1 a) & xi be increasingORDINAL2V2) & a =XBOOLE-0R4 supORDINAL2K4 xi) & xi be Cardinal-FunctionCARD-3M1) &  not 0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 xi)"
sorry

mtheorem card_5_th_30:
" for a be AlephCARD-5M1 holds omegaORDINAL1K4 be regularCARD-5V1 & nextcardCARD-1K2 a be regularCARD-5V1"
  using card_5_th_22 card_5_th_23 sorry

(*begin*)
reserve a, b for "AlephCARD-5M1"
mtheorem card_5_th_31:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds a c=ORDINAL1R1 b implies expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,b)"
sorry

mtheorem card_5_th_32:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
sorry

mtheorem card_5_th_33:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 expCARD-2K3(a,b)"
sorry

mtheorem card_5_th_34:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds a be limit-cardinalCARD-1V2 & b inTARSKIR2 cfCARD-5K1 a implies expCARD-2K3(a,b) =XBOOLE-0R4 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
sorry

mtheorem card_5_th_35:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds cfCARD-5K1 a c=ORDINAL1R1 b & b inTARSKIR2 a implies expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a)"
sorry

reserve O for "OrdinalORDINAL1M3"
reserve F for "SubsetSUBSET-1M2-of omegaORDINAL1K4"
mlemma card_5_lm_4:
" for O be OrdinalORDINAL1M3 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X be finiteFINSET-1V1"
sorry

mtheorem card_5_th_36:
" for O be OrdinalORDINAL1M3 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X =XBOOLE-0R4 cardCARD-1K4 X"
sorry

mtheorem card_5_th_37:
" for x be objectHIDDENM1 holds  for O be OrdinalORDINAL1M3 holds {TARSKIK1 x} c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem card_5_th_38:
" for x be objectHIDDENM1 holds  for O be OrdinalORDINAL1M3 holds {TARSKIK1 x} c=TARSKIR1 O implies canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x}),RelInclWELLORD2K1 {TARSKIK1 x}) =FUNCT-1R1 (0NUMBERSK6).-->FUNCOP-1K17 x"
sorry

mtheorem card_5_cl_11:
  mlet "O be OrdinalORDINAL1M3", "X be SubsetSUBSET-1M2-of O", "n be setHIDDENM2"
"cluster (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
sorry
qed "sorry"

mtheorem card_5_cl_12:
  mlet "X be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "n be setHIDDENM2"
"cluster (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
sorry
qed "sorry"

mtheorem card_5_th_39:
" for F be SubsetSUBSET-1M2-of omegaORDINAL1K4 holds cardCARD-1K1 F c=ORDINAL1R1 order-type-ofWELLORD2K2 RelInclWELLORD2K1 F"
sorry

end
