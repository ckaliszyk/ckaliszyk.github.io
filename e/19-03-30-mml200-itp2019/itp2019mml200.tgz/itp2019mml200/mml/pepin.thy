theory pepin
  imports nat_2 euler_2 pre_ff
   "../mizar_extension/E_number"
begin
(*begin*)
reserve d, i, j, k, m, n, p, q, x, k1, k2 for "NatNAT-1M1"
reserve a, c, i1, i2, i3, i5 for "IntegerINT-1M1"
mlemma pepin_lm_1:
" for n be NatNAT-1M1 holds  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds (n >XXREAL-0R4 \<one>\<^sub>M & x >=XXREAL-0R2 \<one>\<^sub>M) & \<one>\<^sub>M =XBOOLE-0R4 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x)+XCMPLX-0K2 y implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
sorry

mlemma pepin_lm_2:
" for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) >XXREAL-0R4 \<one>\<^sub>M"
sorry

mlemma pepin_lm_3:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
sorry

mlemma pepin_lm_4:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M"
sorry

mtheorem pepin_th_1:
" for i be NatNAT-1M1 holds (i,i +NAT-1K1 \<one>\<^sub>M)are-coprimeINT-2R1"
sorry

mtheorem pepin_th_2:
" for m be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 implies (m,p)are-coprimeINT-2R1 or m gcdNAT-DK8 p =XBOOLE-0R4 p"
sorry

mtheorem pepin_th_3:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k dividesNAT-DR1 n *XCMPLX-0K3 m & (n,k)are-coprimeINT-2R1 implies k dividesNAT-DR1 m"
sorry

mtheorem pepin_th_4:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n dividesNAT-DR1 m & k dividesNAT-DR1 m) & (n,k)are-coprimeINT-2R1 implies n *XCMPLX-0K3 k dividesNAT-DR1 m"
sorry

mtheorem pepin_cl_1:
  mlet "i be IntegerINT-1M1"
"cluster i ^2SQUARE-1K1 as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "i ^2SQUARE-1K1 be naturalORDINAL1V7"
sorry
qed "sorry"

mtheorem pepin_th_5:
" for c be IntegerINT-1M1 holds c >XXREAL-0R4 \<one>\<^sub>M implies \<one>\<^sub>M modINT-1K6 c =HIDDENR1 \<one>\<^sub>M"
sorry

mtheorem pepin_th_6:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i dividesNAT-DR1 n iff n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6)"
sorry

mtheorem pepin_th_7:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <>HIDDENR2 0NUMBERSK6 & m dividesNAT-DR1 n modNAT-DK4 m implies m dividesNAT-DR1 n"
sorry

mtheorem pepin_th_8:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n & m modNAT-DK4 n =XBOOLE-0R4 k implies n dividesINT-1R1 m -XCMPLX-0K6 k"
sorry

mtheorem pepin_th_9:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds i *XCMPLX-0K3 p <>HIDDENR2 0NUMBERSK6 & k modNAT-DK4 i *XCMPLX-0K3 p <XXREAL-0R3 p implies k modNAT-DK4 i *XCMPLX-0K3 p =XBOOLE-0R4 k modNAT-DK4 p"
sorry

mtheorem pepin_th_10:
" for p be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
sorry

mtheorem pepin_th_11:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (\<one>\<^sub>M <XXREAL-0R3 m & n *XCMPLX-0K3 k modNAT-DK4 m =XBOOLE-0R4 k modNAT-DK4 m) & (k,m)are-coprimeINT-2R1 implies n modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_12:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p  |^NEWTONK1 k modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 k modNAT-DK4 m"
sorry

mlemma pepin_lm_5:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n"
sorry

mlemma pepin_lm_6:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
sorry

mlemma pepin_lm_7:
"\<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M"
sorry

mtheorem pepin_th_13:
" for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies i ^2SQUARE-1K1 modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_14:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k ^2SQUARE-1K1 <XXREAL-0R3 j & i modNAT-DK4 j =XBOOLE-0R4 k implies i ^2SQUARE-1K1 modNAT-DK4 j =XBOOLE-0R4 k ^2SQUARE-1K1"
sorry

mtheorem pepin_th_15:
" for i be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & i modNAT-DK4 p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies i ^2SQUARE-1K1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_16:
" for n be NatNAT-1M1 holds n be evenABIANV3 implies n +NAT-1K1 \<one>\<^sub>M be oddABIANV2"
   sorry

mtheorem pepin_th_17:
" for p be NatNAT-1M1 holds p >XXREAL-0R4 \<two>\<^sub>M & p be primeINT-2V1 implies p be oddABIANV2"
sorry

mtheorem pepin_th_18:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies \<two>\<^sub>M to-powerPOWERK2 n be evenABIANV1"
sorry

mtheorem pepin_th_19:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i be oddABIANV2 & j be oddABIANV2 implies i *XCMPLX-0K3 j be oddABIANV2"
   sorry

mtheorem pepin_th_20:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i be oddABIANV2 implies i  |^NEWTONK1 k be oddABIANV2"
sorry

mtheorem pepin_th_21:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 k be evenABIANV3"
sorry

mtheorem pepin_th_22:
" for n be NatNAT-1M1 holds \<two>\<^sub>M dividesNAT-DR1 n iff n be evenABIANV3"
sorry

mtheorem pepin_th_23:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m *XCMPLX-0K3 n be evenABIANV3 implies m be evenABIANV3 or n be evenABIANV3"
   sorry

mtheorem pepin_th_24:
" for n be NatNAT-1M1 holds n  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 n ^2SQUARE-1K1"
sorry

mtheorem pepin_th_25:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 \<one>\<^sub>M & n >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M"
sorry

mlemma pepin_lm_8:
" for n be NatNAT-1M1 holds (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
sorry

mtheorem pepin_th_26:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & p <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 p =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M)"
sorry

mtheorem pepin_th_27:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 implies (n  |^NEWTONK1 (m divNAT-DK3 \<two>\<^sub>M))^2SQUARE-1K1 =XBOOLE-0R4 n  |^NEWTONK1 m"
sorry

mtheorem pepin_th_28:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M <=XXREAL-0R1 k implies n  |^NEWTONK1 k divNAT-DK3 n =XBOOLE-0R4 n  |^NEWTONK1 (k -'NAT-DK9 \<one>\<^sub>M)"
sorry

mtheorem pepin_th_29:
" for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n"
sorry

mtheorem pepin_th_30:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k >XXREAL-0R4 \<one>\<^sub>M & k  |^NEWTONK1 n =XBOOLE-0R4 k  |^NEWTONK1 m implies n =XBOOLE-0R4 m"
sorry

mlemma pepin_lm_9:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be NatNAT-1M1 holds k >XXREAL-0R4 n & x >XXREAL-0R4 \<one>\<^sub>M implies x  |^NEWTONK1 k >XXREAL-0R4 x  |^NEWTONK1 n"
sorry

mlemma pepin_lm_10:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n implies m <=XXREAL-0R1 n"
sorry

mtheorem pepin_th_31:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n iff \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n"
  using pepin_lm_6 pepin_lm_10 sorry

mtheorem pepin_th_32:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & i dividesNAT-DR1 p  |^NEWTONK1 n implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
sorry

mtheorem pepin_th_33:
" for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p be primeINT-2V1 & n <XXREAL-0R3 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) implies (n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) iff n dividesNAT-DR1 p  |^NEWTONK1 k)"
sorry

mtheorem pepin_th_34:
" for d be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for k be NatNAT-1M1 holds p be primeINT-2V1 & d dividesNAT-DR1 p  |^NEWTONK1 k implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 k)"
sorry

mtheorem pepin_th_35:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M & i modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_36:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 m modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem pepin_th_37:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (n,p)are-coprimeINT-2R1 implies n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_38:
" for d be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds ((p be primeINT-2V1 & d >XXREAL-0R4 \<one>\<^sub>M) & d dividesNAT-DR1 p  |^NEWTONK1 k) &  not d dividesNAT-DR1 p  |^NEWTONK1 k divNAT-DK3 p implies d =XBOOLE-0R4 p  |^NEWTONK1 k"
sorry

abbreviation(input) PEPINK1(" _ ^2PEPINK1" [354]354) where
  "i ^2PEPINK1 \<equiv> i ^2SQUARE-1K1"

mtheorem pepin_add_1:
  mlet "i be IntegerINT-1M1"
"cluster i ^2SQUARE-1K1 as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "i ^2SQUARE-1K1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mtheorem pepin_th_39:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies (m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M iff (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n)"
sorry

mlemma pepin_lm_11:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n >XXREAL-0R4 \<one>\<^sub>M & m >XXREAL-0R4 \<one>\<^sub>M) & (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n implies m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_40:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i1,i3)are-congruent-modINT-1R3 i5 implies (i2,i3)are-congruent-modINT-1R3 i5"
sorry

mtheorem pepin_th_41:
"\<three>\<^sub>M be primeINT-2V1"
sorry

mtheorem pepin_th_42:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies EulerEULER-1K1 n <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem pepin_th_43:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies -XCMPLX-0K4 n <XXREAL-0R3 n"
   sorry

mtheorem pepin_th_44:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
sorry

(*begin*)
mdef pepin_def_1 ("CryptoPEPINK2'( _ , _ , _ ')" [0,0,0]228 ) where
  mlet "k be NatNAT-1M1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"func CryptoPEPINK2(m,n,k) \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  m  |^NEWTONK1 k modNAT-DK4 n"
proof-
  (*coherence*)
    show "m  |^NEWTONK1 k modNAT-DK4 n be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mtheorem pepin_th_45:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds ((((p be primeINT-2V1 & q be primeINT-2V1) & p <>HIDDENR2 q) & n =XBOOLE-0R4 p *XCMPLX-0K3 q) & (k1,EulerEULER-1K1 n)are-coprimeINT-2R1) & k1 *XCMPLX-0K3 k2 modNAT-DK4 EulerEULER-1K1 n =XBOOLE-0R4 \<one>\<^sub>M implies ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds m <XXREAL-0R3 n implies CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m)"
sorry

(*begin*)
mdef pepin_def_2 ("orderPEPINK3'( _ , _ ')" [0,0]228 ) where
  mlet "i be NatNAT-1M1", "p be NatNAT-1M1"
"assume p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1 func orderPEPINK3(i,p) \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. (it >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it & it <=XXREAL-0R1 k)"
proof-
  (*existence*)
    show "p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st (it >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it & it <=XXREAL-0R1 k))"
sorry
  (*uniqueness*)
    show "p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1 implies ( for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((it1 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it1 & it1 <=XXREAL-0R1 k)) & ((it2 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it2 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it2 & it2 <=XXREAL-0R1 k)) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem pepin_th_46:
" for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M implies orderPEPINK3(\<one>\<^sub>M,p) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_47:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds (p >XXREAL-0R4 \<one>\<^sub>M & i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & (i,p)are-coprimeINT-2R1 implies orderPEPINK3(i,p) dividesNAT-DR1 n"
sorry

mtheorem pepin_th_48:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds (p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1) & orderPEPINK3(i,p) dividesNAT-DR1 n implies i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem pepin_th_49:
" for i be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (i,p)are-coprimeINT-2R1 implies orderPEPINK3(i,p) dividesNAT-DR1 p -'NAT-DK9 \<one>\<^sub>M"
sorry

(*begin*)
mdef pepin_def_3 ("FermatPEPINK4  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func FermatPEPINK4 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) +NAT-1K1 \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) +NAT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mtheorem pepin_th_50:
"FermatPEPINK4 (0NUMBERSK6) =XBOOLE-0R4 \<three>\<^sub>M"
sorry

mtheorem pepin_th_51:
"FermatPEPINK4 \<one>\<^sub>M =XBOOLE-0R4 \<five>\<^sub>M"
sorry

mtheorem pepin_th_52:
"FermatPEPINK4 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<seven>\<^sub>M"
sorry

mtheorem pepin_th_53:
"FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem pepin_th_54:
"FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem pepin_th_55:
" for n be NatNAT-1M1 holds FermatPEPINK4 n >XXREAL-0R4 \<two>\<^sub>M"
sorry

mlemma pepin_lm_12:
" for n be NatNAT-1M1 holds FermatPEPINK4 n >XXREAL-0R4 \<one>\<^sub>M"
sorry

mlemma pepin_lm_13:
" for n be NatNAT-1M1 holds (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
sorry

mlemma pepin_lm_14:
" for n be NatNAT-1M1 holds FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
sorry

mlemma pepin_lm_15:
" for n be NatNAT-1M1 holds FermatPEPINK4 n modNAT-DK4 \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mlemma pepin_lm_16:
" for n be NatNAT-1M1 holds FermatPEPINK4 n be oddABIANV2"
sorry

mtheorem pepin_th_56:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds (p be primeINT-2V1 & p >XXREAL-0R4 \<two>\<^sub>M) & p dividesNAT-DR1 FermatPEPINK4 n implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st p =XBOOLE-0R4 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem pepin_th_57:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (\<three>\<^sub>M,FermatPEPINK4 n)are-coprimeINT-2R1"
sorry

(*begin*)
(*\$N Pepin's test*)
mtheorem pepin_th_58:
" for n be NatNAT-1M1 holds (\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n implies FermatPEPINK4 n be primeINT-2V1"
sorry

mlemma pepin_lm_17:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
sorry

mlemma pepin_lm_18:
"\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M *NAT-1K2 \<nine>\<^sub>M"
sorry

mlemma pepin_lm_19:
"\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M"
sorry

mlemma pepin_lm_20:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M"
sorry

mlemma pepin_lm_21:
" for i be NatNAT-1M1 holds FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 i +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma pepin_lm_22:
"\<two>\<^sub>M to-powerPOWERK2 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M"
   sorry

mlemma pepin_lm_23:
" for n be NatNAT-1M1 holds n =XBOOLE-0R4 \<one>\<^sub>M implies (\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n"
sorry

mlemma pepin_lm_24:
" for n be NatNAT-1M1 holds FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma pepin_lm_25:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
sorry

mlemma pepin_lm_26:
"\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M"
sorry

mlemma pepin_lm_27:
"\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<one>\<three>\<six>\<^sub>M"
sorry

mlemma pepin_lm_28:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
sorry

mlemma pepin_lm_29:
"\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<six>\<four>\<^sub>M"
sorry

mlemma pepin_lm_30:
"\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<four>\<one>\<^sub>M"
sorry

mlemma pepin_lm_31:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M"
sorry

mlemma pepin_lm_32:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
sorry

mlemma pepin_lm_33:
"\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M"
sorry

mlemma pepin_lm_34:
"\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M"
sorry

mlemma pepin_lm_35:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma pepin_lm_36:
"\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M"
sorry

mlemma pepin_lm_37:
"\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma pepin_lm_38:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M"
sorry

mlemma pepin_lm_39:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<eight>\<two>\<^sub>M"
sorry

mlemma pepin_lm_40:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M"
sorry

mlemma pepin_lm_41:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M"
sorry

mlemma pepin_lm_42:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M"
sorry

mlemma pepin_lm_43:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<four>\<^sub>M"
sorry

mlemma pepin_lm_44:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
sorry

mlemma pepin_lm_45:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M"
sorry

mlemma pepin_lm_46:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
sorry

mlemma pepin_lm_47:
"FermatPEPINK4 \<three>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
sorry

mlemma pepin_lm_48:
"FermatPEPINK4 \<four>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<six>\<four>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem pepin_th_59:
"\<five>\<^sub>M be primeINT-2V1"
sorry

mtheorem pepin_th_60:
"\<one>\<seven>\<^sub>M be primeINT-2V1"
sorry

mtheorem pepin_th_61:
"\<two>\<five>\<seven>\<^sub>M be primeINT-2V1"
sorry

mtheorem pepin_th_62:
"\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M be primeINT-2V1"
sorry

mtheorem pepin_th_63:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds j <>HIDDENR2 0NUMBERSK6 & i modINT-1K6 j =HIDDENR1 0NUMBERSK6 implies i divINT-1K5 j =HIDDENR1 i /XCMPLX-0K7 j"
sorry

mtheorem pepin_th_64:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
sorry

reserve r for "RealXREAL-0M1"
mtheorem pepin_th_65:
" for r be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n & \<one>\<^sub>M <XXREAL-0R3 r implies \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 n"
sorry

mtheorem pepin_th_66:
" for r be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds r >XXREAL-0R4 \<one>\<^sub>M & m >XXREAL-0R4 n implies r  |^NEWTONK1 m >XXREAL-0R4 r  |^NEWTONK1 n"
sorry

end
