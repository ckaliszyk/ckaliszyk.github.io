theory genealg1
  imports card_3 finseq_6
   "../mizar_extension/E_number"
begin
(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve f1, f2 for "FinSequenceFINSEQ-1M3-of D"
reserve i, n, n1, n2, n3, n4, n5, n6 for "ElementSUBSET-1M1-of NATNUMBERSK1"
mtheorem genealg1_th_1:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n =FINSEQ-1R1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
sorry

mtheorem genealg1_th_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +NAT-1K1 i) =FINSEQ-1R1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
sorry

syntax GENEALG1M1 :: "Ty" ("Gene-SetGENEALG1M1" 70)
translations "Gene-SetGENEALG1M1" \<rightharpoonup> "non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"

abbreviation(input) GENEALG1K1("GA-SpaceGENEALG1K1  _ " [164]164) where
  "GA-SpaceGENEALG1K1 S \<equiv> UnionCARD-3K3 S"

mtheorem genealg1_cl_1:
  mlet "f be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1"
"cluster UnionCARD-3K3 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "UnionCARD-3K3 f be  non emptyXBOOLE-0V1"
sorry
qed "sorry"

mdef genealg1_def_1 ("IndividualGENEALG1M2-of  _ " [70]70 ) where
  mlet "S be Gene-SetGENEALG1M1"
"mode IndividualGENEALG1M2-of S \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S means
  (\<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i)"
sorry
qed "sorry"

(*begin*)
mdef genealg1_def_2 ("crossoverGENEALG1K2\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
proof-
  (*coherence*)
    show "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_3 ("crossoverGENEALG1K3\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p2,p1,n1),n2)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p2,p1,n1),n2) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_4 ("crossoverGENEALG1K4\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_5 ("crossoverGENEALG1K5\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_6 ("crossoverGENEALG1K6\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_7 ("crossoverGENEALG1K7\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1", "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5),crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5),crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

(*begin*)
reserve S for "Gene-SetGENEALG1M1"
reserve p1, p2 for "IndividualGENEALG1M2-of S"
mtheorem genealg1_th_3:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) be IndividualGENEALG1M2-of S"
sorry

abbreviation(input) GENEALG1K8("crossoverGENEALG1K8\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]164) where
  "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) \<equiv> crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)"

mtheorem genealg1_add_1:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) be IndividualGENEALG1M2-of S"
    using genealg1_th_3 sorry
qed "sorry"

mtheorem genealg1_th_4:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6) =FINSEQ-1R1 p2"
sorry

mtheorem genealg1_th_5:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) =FINSEQ-1R1 p1"
sorry

(*begin*)
mtheorem genealg1_th_6:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) be IndividualGENEALG1M2-of S"
sorry

abbreviation(input) GENEALG1K9("crossoverGENEALG1K9\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0]164) where
  "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) \<equiv> crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"

mtheorem genealg1_add_2:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) be IndividualGENEALG1M2-of S"
    using genealg1_th_6 sorry
qed "sorry"

mtheorem genealg1_th_7:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
sorry

mtheorem genealg1_th_8:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
sorry

mtheorem genealg1_th_9:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
sorry

mtheorem genealg1_th_10:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
sorry

mtheorem genealg1_th_11:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 p1"
sorry

mtheorem genealg1_th_12:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n1) =FINSEQ-1R1 p1"
sorry

mtheorem genealg1_th_13:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
sorry

(*begin*)
mtheorem genealg1_th_14:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) be IndividualGENEALG1M2-of S"
sorry

abbreviation(input) GENEALG1K10("crossoverGENEALG1K10\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164) where
  "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) \<equiv> crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"

mtheorem genealg1_add_3:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) be IndividualGENEALG1M2-of S"
    using genealg1_th_14 sorry
qed "sorry"

mtheorem genealg1_th_15:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
sorry

mtheorem genealg1_th_16:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
sorry

mtheorem genealg1_th_17:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
sorry

mtheorem genealg1_th_18:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
sorry

mtheorem genealg1_th_19:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
sorry

mtheorem genealg1_th_20:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
sorry

mtheorem genealg1_th_21:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
sorry

mtheorem genealg1_th_22:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
sorry

mtheorem genealg1_th_23:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
sorry

mtheorem genealg1_th_24:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 p1"
sorry

mtheorem genealg1_th_25:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2)"
sorry

mtheorem genealg1_th_26:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2)"
sorry

mtheorem genealg1_th_27:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
sorry

(*begin*)
mtheorem genealg1_th_28:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) be IndividualGENEALG1M2-of S"
sorry

abbreviation(input) GENEALG1K11("crossoverGENEALG1K11\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164) where
  "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) \<equiv> crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4)"

mtheorem genealg1_add_4:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) be IndividualGENEALG1M2-of S"
    using genealg1_th_28 sorry
qed "sorry"

mtheorem genealg1_th_29:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3)"
sorry

mtheorem genealg1_th_30:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
sorry

mtheorem genealg1_th_31:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4)"
sorry

mtheorem genealg1_th_32:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p1"
sorry

mtheorem genealg1_th_33:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
sorry

mtheorem genealg1_th_34:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
sorry

mtheorem genealg1_th_35:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
sorry

mtheorem genealg1_th_36:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 p1"
sorry

mtheorem genealg1_th_37:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((((((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n3) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2,n1)"
sorry

mtheorem genealg1_th_38:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
sorry

mtheorem genealg1_th_39:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n3) =FINSEQ-1R1 p1 & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n2) =FINSEQ-1R1 p1) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n1) =FINSEQ-1R1 p1"
sorry

(*begin*)
mtheorem genealg1_th_40:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) be IndividualGENEALG1M2-of S"
sorry

abbreviation(input) GENEALG1K12("crossoverGENEALG1K12\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164) where
  "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) \<equiv> crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5)"

mtheorem genealg1_add_5:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) be IndividualGENEALG1M2-of S"
    using genealg1_th_40 sorry
qed "sorry"

mtheorem genealg1_th_41:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4)"
sorry

mtheorem genealg1_th_42:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
sorry

mtheorem genealg1_th_43:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
sorry

mtheorem genealg1_th_44:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
sorry

mtheorem genealg1_th_45:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
sorry

mtheorem genealg1_th_46:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5))) & (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4))"
sorry

mtheorem genealg1_th_47:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5))) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5))) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
sorry

mtheorem genealg1_th_48:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) & ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
sorry

mtheorem genealg1_th_49:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)) & (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4))) & (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) & (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) & (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
sorry

mtheorem genealg1_th_50:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 p1"
sorry

mtheorem genealg1_th_51:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1)"
sorry

mtheorem genealg1_th_52:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
sorry

(*begin*)
mtheorem genealg1_th_53:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) be IndividualGENEALG1M2-of S"
sorry

abbreviation(input) GENEALG1K13("crossoverGENEALG1K13\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]164) where
  "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) \<equiv> crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6)"

mtheorem genealg1_add_6:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1", "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) be IndividualGENEALG1M2-of S"
    using genealg1_th_53 sorry
qed "sorry"

mtheorem genealg1_th_54:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5)"
sorry

mtheorem genealg1_th_55:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5,n6)) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5,n6))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5,n6))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5,n6))) & (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n6))) & (n6 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5))"
sorry

mtheorem genealg1_th_56:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5,n1)"
sorry

mtheorem genealg1_th_57:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n1) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)"
sorry

end
