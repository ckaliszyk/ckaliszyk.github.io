theory newton
  imports rvsum_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, j, k, n, m, l, s, t for "NatNAT-1M1"
reserve a, b for "RealXREAL-0M1"
reserve F, G, H for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
mtheorem newton_th_1:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies SegFINSEQ-1K2 n =XBOOLE-0R4 ({TARSKIK1 \<one>\<^sub>M} \\/XBOOLE-0K2 ({k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : \<one>\<^sub>M <XXREAL-0R3 k & k <XXREAL-0R3 n }))\\/XBOOLE-0K2 {TARSKIK1 n}"
sorry

mtheorem newton_th_2:
" for a be RealXREAL-0M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 (a *RVSUM-1K12 F) =XBOOLE-0R4 lenFINSEQ-1K4 F"
sorry

mtheorem newton_th_3:
" for a be RealXREAL-0M1 holds  for G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds domFINSEQ-1K5 G =MEMBEREDR12 domFINSEQ-1K5 (a *RVSUM-1K12 G)"
  using valued_1_def_5 sorry

mtheorem newton_cl_1:
  mlet "x be ComplexXCMPLX-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n  |->FINSEQ-2K2 x as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 x be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mdef newton_def_1 (" _  |^NEWTONK1  _ " [190,190]190 ) where
  mlet "x be ComplexXCMPLX-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func x  |^NEWTONK1 n \<rightarrow> numberORDINAL1M2 equals
  ProductRVSUM-1K23 (n  |->FINSEQ-2K2 x)"
proof-
  (*coherence*)
    show "ProductRVSUM-1K23 (n  |->FINSEQ-2K2 x) be numberORDINAL1M2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem newton_cl_2:
  mlet "x be RealXREAL-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster x  |^NEWTONK1 n as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "x  |^NEWTONK1 n be realXREAL-0V1"
     sorry
qed "sorry"

reserve z for "ComplexXCMPLX-0M1"
mtheorem newton_cl_3:
  mlet "z be ComplexXCMPLX-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster z  |^NEWTONK1 n as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "z  |^NEWTONK1 n be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem newton_th_4:
" for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
  using rvsum_1_th_94 sorry

mtheorem newton_th_5:
" for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 z"
sorry

mtheorem newton_reduce_1:
  mlet "a be ComplexXCMPLX-0M1"
"reduce a  |^NEWTONK1 \<one>\<^sub>M to a"
proof
(*reducibility*)
  show "a  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 a"
    using newton_th_5 sorry
qed "sorry"

mtheorem newton_th_6:
" for s be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z  |^NEWTONK1 s *XCMPLX-0K3 z"
sorry

mtheorem newton_cl_4:
  mlet "x be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster x  |^NEWTONK1 n as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "x  |^NEWTONK1 n be naturalORDINAL1V7"
sorry
qed "sorry"

reserve x, y for "ComplexXCMPLX-0M1"
reserve r, s, t for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
mtheorem newton_th_7:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (x *XCMPLX-0K3 y) |^NEWTONK1 s =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 y  |^NEWTONK1 s"
sorry

mtheorem newton_th_8:
" for x be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds x  |^NEWTONK1 (s +XCMPLX-0K2 t) =XBOOLE-0R4 x  |^NEWTONK1 s *XCMPLX-0K3 x  |^NEWTONK1 t"
sorry

mtheorem newton_th_9:
" for x be ComplexXCMPLX-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (x  |^NEWTONK1 s) |^NEWTONK1 t =XBOOLE-0R4 x  |^NEWTONK1 (s *XCMPLX-0K3 t)"
sorry

mtheorem newton_th_10:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M  |^NEWTONK1 s =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem newton_reduce_2:
  mlet "n be NatNAT-1M1"
"reduce \<one>\<^sub>M  |^NEWTONK1 n to \<one>\<^sub>M"
proof
(*reducibility*)
  show "\<one>\<^sub>M  |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M"
    using newton_th_10 sorry
qed "sorry"

mtheorem newton_th_11:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M implies (0NUMBERSK6) |^NEWTONK1 s =XBOOLE-0R4 0NUMBERSK6"
sorry

mtheorem newton_cl_5:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster idseqFINSEQ-2K1 n as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "idseqFINSEQ-2K1 n be natural-valuedVALUED-0V8"
sorry
qed "sorry"

mdef newton_def_2 (" _ !NEWTONK2" [164]164 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func n !NEWTONK2 \<rightarrow> numberORDINAL1M2 equals
  ProductRVSUM-1K23 (idseqFINSEQ-2K1 n)"
proof-
  (*coherence*)
    show "ProductRVSUM-1K23 (idseqFINSEQ-2K1 n) be numberORDINAL1M2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem newton_cl_6:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n !NEWTONK2 as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "n !NEWTONK2 be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem newton_th_12:
"(0NUMBERSK6)!NEWTONK2 =XBOOLE-0R4 \<one>\<^sub>M"
  using rvsum_1_th_94 sorry

mtheorem newton_th_13:
"\<one>\<^sub>M !NEWTONK2 =XBOOLE-0R4 \<one>\<^sub>M"
  using finseq_2_th_50 rvsum_1_th_95 sorry

mtheorem newton_th_14:
"\<two>\<^sub>M !NEWTONK2 =XBOOLE-0R4 \<two>\<^sub>M"
sorry

mtheorem newton_th_15:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (s +NAT-1K1 \<one>\<^sub>M)!NEWTONK2 =XBOOLE-0R4 (s !NEWTONK2)*XCMPLX-0K3 (s +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem newton_th_16:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry

mtheorem newton_cl_7:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n !NEWTONK2 as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n !NEWTONK2 be naturalORDINAL1V7"
    using newton_th_16 sorry
qed "sorry"

mtheorem newton_th_17:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s !NEWTONK2 >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem newton_cl_8:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n !NEWTONK2 as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "n !NEWTONK2 be positiveXXREAL-0V2"
    using newton_th_17 sorry
qed "sorry"

mtheorem newton_th_18:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (s !NEWTONK2)*XCMPLX-0K3 (t !NEWTONK2) <>HIDDENR2 0NUMBERSK6"
   sorry

mdef newton_def_3 (" _ chooseNEWTONK3  _ " [164,164]164 ) where
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func n chooseNEWTONK3 k \<rightarrow> numberORDINAL1M2 means
  \<lambda>it.  for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)) if n >=XXREAL-0R2 k otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*consistency*)
    show " for it be numberORDINAL1M2 holds  True "
       sorry
  (*existence*)
    show "(n >=XXREAL-0R2 k implies ( ex it be numberORDINAL1M2 st  for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2)))) & ( not n >=XXREAL-0R2 k implies ( ex it be numberORDINAL1M2 st it =XBOOLE-0R4 0NUMBERSK6))"
sorry
  (*uniqueness*)
    show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds (n >=XXREAL-0R2 k implies (( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it1 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) & ( for l be NatNAT-1M1 holds l =XBOOLE-0R4 n -XCMPLX-0K6 k implies it2 =XBOOLE-0R4 (n !NEWTONK2)/XCMPLX-0K7 ((k !NEWTONK2)*XCMPLX-0K3 (l !NEWTONK2))) implies it1 =HIDDENR1 it2)) & ( not n >=XXREAL-0R2 k implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
sorry
qed "sorry"

mtheorem newton_cl_9:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n chooseNEWTONK3 k as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "n chooseNEWTONK3 k be realXREAL-0V1"
sorry
qed "sorry"

mtheorem newton_th_19:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem newton_th_20:
" for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 t & r =HIDDENR1 s -XCMPLX-0K6 t implies s chooseNEWTONK3 t =XBOOLE-0R4 s chooseNEWTONK3 r"
sorry

mtheorem newton_th_21:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 s =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem newton_th_22:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (t +NAT-1K1 \<one>\<^sub>M)chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t chooseNEWTONK3 (s +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 t chooseNEWTONK3 s"
sorry

mtheorem newton_th_23:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M implies s chooseNEWTONK3 \<one>\<^sub>M =HIDDENR1 s"
sorry

mtheorem newton_th_24:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s >=XXREAL-0R2 \<one>\<^sub>M & t =HIDDENR1 s -XCMPLX-0K6 \<one>\<^sub>M implies s chooseNEWTONK3 t =HIDDENR1 s"
sorry

mtheorem newton_th_25:
" for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds s chooseNEWTONK3 r be ElementSUBSET-1M1-of NATNUMBERSK1"
sorry

mtheorem newton_th_26:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 F =XBOOLE-0R4 m) & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 F & l =XBOOLE-0R4 (n +XCMPLX-0K2 i)-XCMPLX-0K6 \<one>\<^sub>M implies F .FUNCT-1K1 i =XBOOLE-0R4 l chooseNEWTONK3 n) implies SumRVSUM-1K22 F =HIDDENR1 (n +XCMPLX-0K2 m)chooseNEWTONK3 (n +NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem newton_cl_10:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster n chooseNEWTONK3 k as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n chooseNEWTONK3 k be naturalORDINAL1V7"
    using newton_th_25 sorry
qed "sorry"

abbreviation(input) NEWTONK4(" _ chooseNEWTONK4  _ " [164,164]164) where
  "n chooseNEWTONK4 k \<equiv> n chooseNEWTONK3 k"

mtheorem newton_add_1:
  mlet "k be NatNAT-1M1", "n be NatNAT-1M1"
"cluster n chooseNEWTONK3 k as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "n chooseNEWTONK3 k be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mdef newton_def_4 ("'( _ , _ ')In-PowerNEWTONK5  _ " [0,0,164]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func (a,b)In-PowerNEWTONK5 n \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it1 & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it1 .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 it2 & m =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M) & l =XBOOLE-0R4 n -XCMPLX-0K6 m implies it2 .FUNCT-1K1 i =XBOOLE-0R4 ((n chooseNEWTONK3 m)*XCMPLX-0K3 a  |^NEWTONK1 l)*XCMPLX-0K3 b  |^NEWTONK1 m)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem newton_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a,b)In-PowerNEWTONK5 (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*>"
sorry

mtheorem newton_th_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 a  |^NEWTONK1 s"
sorry

mtheorem newton_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds ((a,b)In-PowerNEWTONK5 s).FUNCT-1K1 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 b  |^NEWTONK1 s"
sorry

mtheorem newton_th_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 ((a,b)In-PowerNEWTONK5 s)"
sorry

mdef newton_def_5 ("Newton-CoeffNEWTONK6  _ " [164]164 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func Newton-CoeffNEWTONK6 n \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 it =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)"
sorry
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it1 & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it1 .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it2 & k =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M implies it2 .FUNCT-1K1 i =XBOOLE-0R4 n chooseNEWTONK3 k)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem newton_th_31:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds Newton-CoeffNEWTONK6 s =FINSEQ-1R1 (\<one>\<^sub>M,\<one>\<^sub>M)In-PowerNEWTONK5 s"
sorry

mtheorem newton_th_32:
" for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<two>\<^sub>M  |^NEWTONK1 s =HIDDENR1 SumRVSUM-1K22 (Newton-CoeffNEWTONK6 s)"
sorry

(*begin*)
mtheorem newton_th_33:
" for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<one>\<^sub>M implies k *XCMPLX-0K3 l >=XXREAL-0R2 k"
sorry

mtheorem newton_th_34:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 k *XCMPLX-0K3 l implies n >=XXREAL-0R2 k"
sorry

abbreviation(input) NEWTONK7(" _ !NEWTONK7" [164]164) where
  "n !NEWTONK7 \<equiv> n !NEWTONK2"

mtheorem newton_add_2:
  mlet "n be NatNAT-1M1"
"cluster n !NEWTONK2 as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "n !NEWTONK2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    using newton_th_16 sorry
qed "sorry"

mtheorem newton_th_35:
" for l be NatNAT-1M1 holds l <>HIDDENR2 0NUMBERSK6 implies l dividesNAT-DR1 l !NEWTONK7"
sorry

mtheorem newton_th_36:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n >XXREAL-0R4 \<one>\<^sub>M"
sorry

mtheorem newton_th_37:
" for k be NatNAT-1M1 holds k /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
sorry

mtheorem newton_th_38:
" for l be NatNAT-1M1 holds l !NEWTONK7 >=XXREAL-0R2 l"
sorry

mtheorem newton_th_39:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m <>HIDDENR2 \<one>\<^sub>M & m dividesNAT-DR1 n implies  not m dividesNAT-DR1 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem newton_th_40:
" for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 (j +XCMPLX-0K2 k)!NEWTONK7"
sorry

mtheorem newton_th_41:
" for j be NatNAT-1M1 holds  for l be NatNAT-1M1 holds j <=XXREAL-0R1 l & j <>HIDDENR2 0NUMBERSK6 implies j dividesNAT-DR1 l !NEWTONK7"
sorry

mtheorem newton_th_42:
" for j be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (j <>HIDDENR2 \<one>\<^sub>M & j <>HIDDENR2 0NUMBERSK6) & j dividesNAT-DR1 l !NEWTONK7 +NAT-1K1 \<one>\<^sub>M implies j >XXREAL-0R4 l"
  using newton_th_39 newton_th_41 sorry

mtheorem newton_th_43:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m lcmNAT-DK6 (n lcmNAT-DK6 k) =XBOOLE-0R4 (m lcmNAT-DK6 n)lcmNAT-DK6 k"
sorry

mtheorem newton_th_44:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n iff m lcmNAT-DK6 n =XBOOLE-0R4 n"
sorry

mtheorem newton_th_45:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n dividesNAT-DR1 m & k dividesNAT-DR1 m iff n lcmNAT-DK6 k dividesNAT-DR1 m"
sorry

mtheorem newton_th_46:
" for m be NatNAT-1M1 holds m lcmNAT-DK6 \<one>\<^sub>M =XBOOLE-0R4 m"
sorry

mtheorem newton_th_47:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m lcmNAT-DK6 n dividesNAT-DR1 m *XCMPLX-0K3 n"
sorry

mtheorem newton_th_48:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (n gcdNAT-DK8 k) =XBOOLE-0R4 (m gcdNAT-DK8 n)gcdNAT-DK8 k"
sorry

mtheorem newton_th_49:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n dividesNAT-DR1 m implies n gcdNAT-DK8 m =XBOOLE-0R4 n"
sorry

mtheorem newton_th_50:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n & m dividesNAT-DR1 k iff m dividesNAT-DR1 n gcdNAT-DK8 k"
sorry

mtheorem newton_th_51:
" for m be NatNAT-1M1 holds m gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
sorry

mtheorem newton_th_52:
" for m be NatNAT-1M1 holds m gcdNAT-DK8 0NUMBERSK6 =XBOOLE-0R4 m"
sorry

mtheorem newton_th_53:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (m gcdNAT-DK8 n)lcmNAT-DK6 n =XBOOLE-0R4 n"
sorry

mtheorem newton_th_54:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 m"
sorry

mtheorem newton_th_55:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m gcdNAT-DK8 (m lcmNAT-DK6 n) =XBOOLE-0R4 (n gcdNAT-DK8 m)lcmNAT-DK6 m"
sorry

mtheorem newton_th_56:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n implies m gcdNAT-DK8 k dividesNAT-DR1 n gcdNAT-DK8 k"
sorry

mtheorem newton_th_57:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m dividesNAT-DR1 n implies k gcdNAT-DK8 m dividesNAT-DR1 k gcdNAT-DK8 n"
sorry

mtheorem newton_th_58:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies n gcdINT-2K3 m >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem newton_th_59:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m >XXREAL-0R4 0NUMBERSK6 & n >XXREAL-0R4 0NUMBERSK6 implies m lcmNAT-DK6 n >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem newton_th_60:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n gcdNAT-DK8 m)lcmNAT-DK6 (n gcdNAT-DK8 k) dividesNAT-DR1 n gcdNAT-DK8 (m lcmNAT-DK6 k)"
sorry

mtheorem newton_th_61:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds m dividesNAT-DR1 l implies m lcmNAT-DK6 (n gcdNAT-DK8 l) dividesNAT-DR1 (m lcmNAT-DK6 n)gcdNAT-DK8 l"
sorry

mtheorem newton_th_62:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n gcdNAT-DK8 m dividesNAT-DR1 n lcmNAT-DK6 m"
sorry

reserve p, q for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
reserve i0, i, i1, i2, i4 for "IntegerINT-1M1"
mtheorem newton_th_63:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 m implies n modNAT-DK4 m =XBOOLE-0R4 n -XCMPLX-0K6 m *XCMPLX-0K3 (n divNAT-DK3 m)"
sorry

mtheorem newton_th_64:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >=XXREAL-0R2 0NUMBERSK6 implies i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
  using int_1_th_57 sorry

mtheorem newton_th_65:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >XXREAL-0R4 0NUMBERSK6 implies i1 modINT-1K6 i2 <XXREAL-0R3 i2"
  using int_1_th_58 sorry

mtheorem newton_th_66:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 <>HIDDENR2 0NUMBERSK6 implies i1 =HIDDENR1 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2)"
  using int_1_th_59 sorry

(*\$N Bezout's identity*)
mtheorem newton_th_67:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  ex i be IntegerINT-1M1 st  ex i1 be IntegerINT-1M1 st i *XCMPLX-0K3 m +XCMPLX-0K2 i1 *XCMPLX-0K3 n =XBOOLE-0R4 m gcdNAT-DK8 n"
  using nat_d_th_68 sorry

mdef newton_def_6 ("SetPrimesNEWTONK8" 164 ) where
"func SetPrimesNEWTONK8 \<rightarrow> SubsetSUBSET-1M2-of NATNUMBERSK1 means
  \<lambda>it.  for n be NatNAT-1M1 holds n inTARSKIR2 it iff n be primeINT-2V1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds n inTARSKIR2 it iff n be primeINT-2V1"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds  for it2 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for n be NatNAT-1M1 holds n inTARSKIR2 it1 iff n be primeINT-2V1) & ( for n be NatNAT-1M1 holds n inTARSKIR2 it2 iff n be primeINT-2V1) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem newton_cl_11:
"cluster primeINT-2V1 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be primeINT-2V1"
    using int_2_th_28 sorry
qed "sorry"

mtheorem newton_cl_12:
"cluster primeINT-2V1 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be primeINT-2V1"
    using int_2_th_28 sorry
qed "sorry"

syntax NEWTONM1 :: "Ty" ("PrimeNEWTONM1" 70)
translations "PrimeNEWTONM1" \<rightharpoonup> "primeINT-2V1\<bar>NatNAT-1M1"

mdef newton_def_7 ("SetPrimenumberNEWTONK9  _ " [164]164 ) where
  mlet "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func SetPrimenumberNEWTONK9 p \<rightarrow> SubsetSUBSET-1M2-of NATNUMBERSK1 means
  \<lambda>it.  for q be NatNAT-1M1 holds q inTARSKIR2 it iff q <XXREAL-0R3 p & q be primeINT-2V1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of NATNUMBERSK1 st  for q be NatNAT-1M1 holds q inTARSKIR2 it iff q <XXREAL-0R3 p & q be primeINT-2V1"
sorry
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds  for it2 be SubsetSUBSET-1M2-of NATNUMBERSK1 holds ( for q be NatNAT-1M1 holds q inTARSKIR2 it1 iff q <XXREAL-0R3 p & q be primeINT-2V1) & ( for q be NatNAT-1M1 holds q inTARSKIR2 it2 iff q <XXREAL-0R3 p & q be primeINT-2V1) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem newton_th_68:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimesNEWTONK8"
sorry

mtheorem newton_th_69:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for q be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds p <=XXREAL-0R1 q implies SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SetPrimenumberNEWTONK9 q"
sorry

mtheorem newton_th_70:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p c=MEMBEREDR6 SegFINSEQ-1K1 p"
sorry

mtheorem newton_th_71:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds SetPrimenumberNEWTONK9 p be finiteFINSET-1V1"
sorry

mtheorem newton_cl_13:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SetPrimenumberNEWTONK9 n as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "SetPrimenumberNEWTONK9 n be finiteFINSET-1V1"
    using newton_th_71 sorry
qed "sorry"

reserve p for "PrimeNEWTONM1"
mtheorem newton_th_72:
" for l be NatNAT-1M1 holds  ex p be PrimeNEWTONM1 st p >XXREAL-0R4 l"
sorry

mlemma newton_lm_1:
"SetPrimenumberNEWTONK9 \<two>\<^sub>M =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem newton_cl_14:
"cluster SetPrimesNEWTONK8 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SetPrimesNEWTONK8 be  non emptyXBOOLE-0V1"
    using newton_def_6 int_2_th_28 sorry
qed "sorry"

mtheorem newton_cl_15:
"cluster SetPrimenumberNEWTONK9 \<two>\<^sub>M as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SetPrimenumberNEWTONK9 \<two>\<^sub>M be emptyXBOOLE-0V1"
    using newton_lm_1 sorry
qed "sorry"

mtheorem newton_th_73:
" for m be NatNAT-1M1 holds SetPrimenumberNEWTONK9 m c=MEMBEREDR6 SegFINSEQ-1K2 m"
sorry

mtheorem newton_th_74:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds k >=XXREAL-0R2 m implies  not k inTARSKIR2 SetPrimenumberNEWTONK9 m"
  using newton_def_7 sorry

mtheorem newton_th_75:
" for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n \\/XBOOLE-0K2 {TARSKIK1 n} be finiteFINSET-1V1"
   sorry

mtheorem newton_th_76:
" for f be PrimeNEWTONM1 holds  for g be NatNAT-1M1 holds f <XXREAL-0R3 g implies SetPrimenumberNEWTONK9 f \\/XBOOLE-0K2 {TARSKIK1 f} c=MEMBEREDR6 SetPrimenumberNEWTONK9 g"
sorry

mtheorem newton_th_77:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds k >=XXREAL-0R2 m implies  not k inTARSKIR2 SetPrimenumberNEWTONK9 m"
  using newton_def_7 sorry

mlemma newton_lm_2:
" for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 }"
sorry

mdef newton_def_8 ("primenumberNEWTONK10  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func primenumberNEWTONK10 n \<rightarrow> primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it)"
proof-
  (*existence*)
    show " ex it be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it)"
sorry
  (*uniqueness*)
    show " for it1 be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be primeINT-2V1\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it1) & n =XBOOLE-0R4 cardCARD-1K4 (SetPrimenumberNEWTONK9 it2) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem newton_th_78:
" for n be NatNAT-1M1 holds SetPrimenumberNEWTONK9 n =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 n & k be primeINT-2V1 }"
  using newton_lm_2 sorry

(*\$N The Infinitude of Primes*)
mtheorem newton_th_79:
"SetPrimesNEWTONK8 be infiniteFINSET-1V2"
sorry

mtheorem newton_cl_16:
"cluster SetPrimesNEWTONK8 as-term-is  non emptyXBOOLE-0V1\<bar>infiniteFINSET-1V2"
proof
(*coherence*)
  show "SetPrimesNEWTONK8 be  non emptyXBOOLE-0V1\<bar>infiniteFINSET-1V2"
    using newton_th_79 sorry
qed "sorry"

reserve i for "NatNAT-1M1"
mtheorem newton_th_80:
" for i be NatNAT-1M1 holds i be primeINT-2V1 implies ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i dividesNAT-DR1 m *XCMPLX-0K3 n implies i dividesNAT-DR1 m or i dividesNAT-DR1 n)"
sorry

mtheorem newton_th_81:
" for x be ComplexXCMPLX-0M1 holds x  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 x *XCMPLX-0K3 x & x ^2SQUARE-1K1 =XBOOLE-0R4 x  |^NEWTONK1 \<two>\<^sub>M"
sorry

mtheorem newton_th_82:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m divINT-1K5 n =HIDDENR1 m divNAT-DK3 n & m modINT-1K6 n =HIDDENR1 m modNAT-DK4 n"
   sorry

reserve x for "RealXREAL-0M1"
mtheorem newton_th_83:
" for k be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem newton_th_84:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (0NUMBERSK6) |^NEWTONK1 n =XBOOLE-0R4 0NUMBERSK6"
sorry

abbreviation(input) NEWTONK11(" _  |^NEWTONK11  _ " [190,190]190) where
  "m  |^NEWTONK11 n \<equiv> m  |^NEWTONK1 n"

mtheorem newton_add_3:
  mlet "m be ElementSUBSET-1M1-of NATNUMBERSK1", "n be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster m  |^NEWTONK1 n as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "m  |^NEWTONK1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mlemma newton_lm_3:
" for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 (0NUMBERSK6) >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
  using rvsum_1_th_94 sorry

mlemma newton_lm_4:
" for n be NatNAT-1M1 holds ( for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M) implies ( for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
sorry

mtheorem newton_th_85:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
sorry

mtheorem newton_th_86:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds \<two>\<^sub>M <=XXREAL-0R1 i implies i  |^NEWTONK1 n >XXREAL-0R4 n"
sorry

reserve k for "NatNAT-1M1"
theorem newton_sch_1:
  fixes Ff1 Gf1 af0 bf0 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Gf1(x1) be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "af0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "bf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
   A1: "0NUMBERSK6 <XXREAL-0R3 bf0" and
   A2: "bf0 <XXREAL-0R3 af0" and
   A3: "Ff1(0NUMBERSK6) =XBOOLE-0R4 af0" and
   A4: "Gf1(0NUMBERSK6) =XBOOLE-0R4 bf0" and
   A5: " for k be NatNAT-1M1 holds Gf1(k) >XXREAL-0R4 0NUMBERSK6 implies Ff1(k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf1(k) & Gf1(k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff1(k) modNAT-DK4 Gf1(k)"
  shows " ex k be NatNAT-1M1 st Ff1(k) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Gf1(k) =XBOOLE-0R4 0NUMBERSK6"
sorry

reserve k, n, n1, n2, m1, m2 for "NatNAT-1M1"
mtheorem newton_th_87:
" for r be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be NatNAT-1M1 holds r <>HIDDENR2 0NUMBERSK6 or n =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
sorry

mlemma newton_lm_5:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 <=XXREAL-0R1 n2"
sorry

mtheorem newton_th_88:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 =XBOOLE-0R4 n2 & m1 =XBOOLE-0R4 m2"
sorry

mtheorem newton_th_89:
" for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
sorry

end
