theory fdiff_2
  imports scheme1 rolle fcont_3 funct_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "objectHIDDENM1"
reserve x0, r, r1, r2, g, g1, g2, p, y0 for "RealXREAL-0M1"
reserve n, m, k, l for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve a, b, d for "Real-SequenceSEQ-1M1"
reserve h, h1, h2 for "non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
reserve c, c1 for "constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
reserve A for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
reserve L for "LinearFuncFDIFF-1M2"
reserve R for "RestFuncFDIFF-1M1"
mtheorem fdiff_2_cl_1:
  mlet "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
"cluster -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h as-term-is non-zeroORDINAL1V9\<bar>convergentCOMSEQ-2V3"
proof
(*coherence*)
  show "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h be non-zeroORDINAL1V9\<bar>convergentCOMSEQ-2V3"
    using seq_1_th_45 sorry
qed "sorry"

mtheorem fdiff_2_th_1:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for d be Real-SequenceSEQ-1M1 holds ((a be convergentSEQ-2V5 & b be convergentSEQ-2V5) & limSEQ-2K1 a =COMPLEX1R1 limSEQ-2K1 b) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies d be convergentSEQ-2V5 & limSEQ-2K1 d =COMPLEX1R1 limSEQ-2K1 a"
sorry

mtheorem fdiff_2_th_2:
" for a be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n) implies a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
sorry

mtheorem fdiff_2_th_3:
" for a be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) implies a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
sorry

mtheorem fdiff_2_th_4:
" for x0 be RealXREAL-0M1 holds  for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} implies ((c be convergentSEQ-2V5 & limSEQ-2K1 c =COMPLEX1R1 x0) & h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5) & limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 x0"
sorry

mtheorem fdiff_2_th_5:
" for r be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 r} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> b =XBOOLE-0R4 {TARSKIK1 r} implies a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b"
sorry

mtheorem fdiff_2_th_6:
" for a be Real-SequenceSEQ-1M1 holds  for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds a be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h implies a be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
sorry

mtheorem fdiff_2_th_7:
" for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies ( for h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for h2 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 limSEQ-2K1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
sorry

mtheorem fdiff_2_th_8:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ( ex h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 st  ex c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 st (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 r} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 r} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
sorry

mtheorem fdiff_2_th_9:
" for a be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
sorry

theorem fdiff_2_sch_1:
  fixes sf0 Pp1 
  assumes
[ty]: "sf0 be Real-SequenceSEQ-1M1" and
   A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
  shows " ex q be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st ( for n be NatNAT-1M1 holds Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> q).FUNCT-1K1 n)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =COMPLEX1R1 sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies Pp1(r)) implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 q .RECDEF-1K1 m))"
sorry

mtheorem fdiff_2_th_10:
" for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f .FUNCT-1K1 x0 <>HIDDENR2 r & f is-differentiable-inFDIFF-1R1 x0 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 N implies f .FUNCT-1K1 g <>HIDDENR2 r))"
  using fcont_3_th_7 fdiff_1_th_24 sorry

mlemma fdiff_2_lm_1:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies f is-differentiable-inFDIFF-1R1 x0 & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
sorry

mtheorem fdiff_2_th_11:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 iff ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5)"
sorry

mtheorem fdiff_2_th_12:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 g iff ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g)"
sorry

mlemma fdiff_2_lm_2:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & f1 is-differentiable-inFDIFF-1R1 x0) & f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
sorry

mtheorem fdiff_2_th_13:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
sorry

mtheorem fdiff_2_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & f1 is-differentiable-inFDIFF-1R1 x0) & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
sorry

mtheorem fdiff_2_th_15:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & f is-differentiable-inFDIFF-1R1 x0 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
sorry

mtheorem fdiff_2_th_16:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-onFDIFF-1R2 A & f `|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A"
sorry

mtheorem fdiff_2_th_17:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
sorry

mtheorem fdiff_2_th_18:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
sorry

mtheorem fdiff_2_th_19:
" for r be RealXREAL-0M1 holds  for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 A & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)"
sorry

mtheorem fdiff_2_th_20:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)"
sorry

mlemma fdiff_2_lm_3:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
sorry

mtheorem fdiff_2_th_21:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
sorry

mtheorem fdiff_2_th_22:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 A & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
sorry

mtheorem fdiff_2_th_23:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 A & f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2) & f2 is-differentiable-onFDIFF-1R2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 A & (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)"
sorry

mtheorem fdiff_2_th_24:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 A & p inHIDDENR3 A implies  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 p .| <=XXREAL-0R1 (r -XCMPLX-0K6 p)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6)"
sorry

mtheorem fdiff_2_th_25:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & r2 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
sorry

mtheorem fdiff_2_th_26:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r & r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be constantFUNCT-1V5"
sorry

mtheorem fdiff_2_th_27:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r & r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be constantFUNCT-1V5"
sorry

mtheorem fdiff_2_th_28:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be constantFUNCT-1V5"
sorry

mtheorem fdiff_2_th_29:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be increasingVALUED-0V9 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2"
sorry

mtheorem fdiff_2_th_30:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be decreasingVALUED-0V10 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2"
sorry

mtheorem fdiff_2_th_31:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-decreasingVALUED-0V11"
sorry

mtheorem fdiff_2_th_32:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-increasingVALUED-0V12"
sorry

mtheorem fdiff_2_th_33:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be increasingVALUED-0V9 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2"
sorry

mtheorem fdiff_2_th_34:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be decreasingVALUED-0V10 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2"
sorry

mtheorem fdiff_2_th_35:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-decreasingVALUED-0V11"
sorry

mtheorem fdiff_2_th_36:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-increasingVALUED-0V12"
sorry

mtheorem fdiff_2_th_37:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingVALUED-0V9 & f be one-to-oneFUNCT-1V2"
sorry

mtheorem fdiff_2_th_38:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingVALUED-0V10 & f be one-to-oneFUNCT-1V2"
sorry

mtheorem fdiff_2_th_39:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-decreasingVALUED-0V11"
sorry

mtheorem fdiff_2_th_40:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-increasingVALUED-0V12"
sorry

mtheorem fdiff_2_th_41:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
sorry

mtheorem fdiff_2_th_42:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
sorry

mtheorem fdiff_2_th_43:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
sorry

mtheorem fdiff_2_th_44:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & (( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
sorry

mtheorem fdiff_2_th_45:
" for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & (( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f be one-to-oneFUNCT-1V2 & f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
sorry

mtheorem fdiff_2_th_46:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be one-to-oneFUNCT-1V2 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
sorry

mtheorem fdiff_2_th_47:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be one-to-oneFUNCT-1V2 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
sorry

mtheorem fdiff_2_th_48:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be one-to-oneFUNCT-1V2 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
sorry

mtheorem fdiff_2_th_49:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)) be convergentSEQ-2V5 & limSEQ-2K1 ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))) =COMPLEX1R1 diffFDIFF-1K1(f,x0))"
sorry

end
