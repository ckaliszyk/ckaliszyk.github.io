theory supinf_2
  imports funct_3 supinf_1 member_1 card_4 valued_1
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) SUPINF_2K1("0.SUPINF-2K1" 228) where
  "0.SUPINF-2K1 \<equiv> 0ORDINAL1K5"

abbreviation(input) SUPINF_2K2("0.SUPINF-2K2" 228) where
  "0.SUPINF-2K2 \<equiv> 0ORDINAL1K5"

mtheorem supinf_2_add_1:
"cluster 0ORDINAL1K5 as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "0ORDINAL1K5 be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K3("-SUPINF-2K3  _ " [132]132) where
  "-SUPINF-2K3 x \<equiv> -XXREAL-3K2 x"

mtheorem supinf_2_add_2:
  mlet "x be R-ealSUPINF-1M1"
"cluster -XXREAL-3K2 x as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "-XXREAL-3K2 x be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K4(" _ +SUPINF-2K4  _ " [132,132]132) where
  "x +SUPINF-2K4 y \<equiv> x +XXREAL-3K1 y"

mtheorem supinf_2_add_3:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster x +XXREAL-3K1 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K5(" _ -SUPINF-2K5  _ " [132,132]132) where
  "x -SUPINF-2K5 y \<equiv> x -XXREAL-3K3 y"

mtheorem supinf_2_add_4:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster x -XXREAL-3K3 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x -XXREAL-3K3 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem supinf_2_th_1:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x +XXREAL-3K1 y =HIDDENR1 a +XCMPLX-0K2 b"
  using xxreal_3_def_2 sorry

mtheorem supinf_2_th_2:
" for x be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds x =HIDDENR1 a implies -XXREAL-3K2 x =HIDDENR1 -XCMPLX-0K4 a"
  using xxreal_3_def_3 sorry

mtheorem supinf_2_th_3:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x -XXREAL-3K3 y =HIDDENR1 a -XCMPLX-0K6 b"
sorry

abbreviation(input) SUPINF_2K6(" _ +SUPINF-2K6  _ " [132,132]132) where
  "X +SUPINF-2K6 Y \<equiv> X ++MEMBER-1K8 Y"

abbreviation(input) SUPINF_2K7(" _ +SUPINF-2K7  _ " [132,132]132) where
  "X +SUPINF-2K7 Y \<equiv> X ++MEMBER-1K8 Y"

mtheorem supinf_2_add_5:
  mlet "X be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster X ++MEMBER-1K8 Y as-term-is SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "X ++MEMBER-1K8 Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    using membered_th_2 sorry
qed "sorry"

abbreviation(input) SUPINF_2K8("-SUPINF-2K8  _ " [132]132) where
  "-SUPINF-2K8 X \<equiv> --MEMBER-1K4 X"

abbreviation(input) SUPINF_2K9("-SUPINF-2K9  _ " [132]132) where
  "-SUPINF-2K9 X \<equiv> --MEMBER-1K4 X"

mtheorem supinf_2_add_6:
  mlet "X be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster --MEMBER-1K4 X as-term-is SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "--MEMBER-1K4 X be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    using membered_th_2 sorry
qed "sorry"

(*\$CT*)
mtheorem supinf_2_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for z be R-ealSUPINF-1M1 holds z inTARSKIR2 X iff -SUPINF-2K3 z inTARSKIR2 -SUPINF-2K9 X"
  using member_1_th_1 sorry

mtheorem supinf_2_th_6:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds X c=MEMBEREDR2 Y iff -SUPINF-2K9 X c=MEMBEREDR2 -SUPINF-2K9 Y"
  using member_1_th_3 sorry

mtheorem supinf_2_th_7:
" for z be R-ealSUPINF-1M1 holds z inTARSKIR2 REALNUMBERSK2 iff -SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2"
sorry

abbreviation(input) SUPINF_2K10("infSUPINF-2K10  _ " [228]228) where
  "infSUPINF-2K10 X \<equiv> infXXREAL-2K2 X"

mtheorem supinf_2_add_7:
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster infXXREAL-2K2 X as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "infXXREAL-2K2 X be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K11("supSUPINF-2K11  _ " [300]300) where
  "supSUPINF-2K11 X \<equiv> supXXREAL-2K1 X"

mtheorem supinf_2_add_8:
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster supXXREAL-2K1 X as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "supXXREAL-2K1 X be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem supinf_2_th_8:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds supSUPINF-2K11 (X +SUPINF-2K7 Y) <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
sorry

mtheorem supinf_2_th_9:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 infSUPINF-2K10 (X +SUPINF-2K7 Y)"
sorry

mtheorem supinf_2_th_10:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds X be bounded-aboveXXREAL-2V4 & Y be bounded-aboveXXREAL-2V4 implies supSUPINF-2K11 (X +SUPINF-2K7 Y) <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
  using supinf_2_th_8 sorry

mtheorem supinf_2_th_11:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds X be bounded-belowXXREAL-2V3 & Y be bounded-belowXXREAL-2V3 implies infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 infSUPINF-2K10 (X +SUPINF-2K7 Y)"
  using supinf_2_th_9 sorry

mtheorem supinf_2_th_12:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for a be R-ealSUPINF-1M1 holds a be UpperBoundXXREAL-2M1-of X iff -SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
sorry

mtheorem supinf_2_th_13:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for a be R-ealSUPINF-1M1 holds a be LowerBoundXXREAL-2M2-of X iff -SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
sorry

mtheorem supinf_2_th_14:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds infSUPINF-2K10 (-SUPINF-2K9 X) =XBOOLE-0R4 -SUPINF-2K3 supSUPINF-2K11 X"
sorry

mtheorem supinf_2_th_15:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds supSUPINF-2K11 (-SUPINF-2K9 X) =XBOOLE-0R4 -SUPINF-2K3 infSUPINF-2K10 X"
sorry

syntax SUPINF_2K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("rngSUPINF-2K12\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228)
translations "rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F" \<rightharpoonup> "rngRELAT-1K2 F"

mtheorem supinf_2_add_9:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "F be FunctionFUNCT-2M1-of(X,Y)"
"cluster rngRELAT-1K2 F as-term-is  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "rngRELAT-1K2 F be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
sorry
qed "sorry"

mdef supinf_2_def_1 ("supSUPINF-2K13\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,300]300 ) where
  mlet "D be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of D", "F be PartFuncPARTFUN1M1-of(X,Y)"
"func supSUPINF-2K13\<^bsub>(D,X,Y)\<^esub> F \<rightarrow> ElementSUBSET-1M1-of ExtREALXXREAL-0K3 equals
  supSUPINF-2K11 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F)"
proof-
  (*coherence*)
    show "supSUPINF-2K11 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F) be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
       sorry
qed "sorry"

mdef supinf_2_def_2 ("infSUPINF-2K14\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228 ) where
  mlet "D be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of D", "F be PartFuncPARTFUN1M1-of(X,Y)"
"func infSUPINF-2K14\<^bsub>(D,X,Y)\<^esub> F \<rightarrow> ElementSUBSET-1M1-of ExtREALXXREAL-0K3 equals
  infSUPINF-2K10 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F)"
proof-
  (*coherence*)
    show "infSUPINF-2K10 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F) be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
       sorry
qed "sorry"

abbreviation(input) SUPINF_2K15(" _ .SUPINF-2K15  _ " [200,200]200) where
  "F .SUPINF-2K15 x \<equiv> F .FUNCT-1K1 x"

mtheorem supinf_2_add_10:
  mlet "F be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1", "x be setHIDDENM2"
"cluster F .FUNCT-1K1 x as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "F .FUNCT-1K1 x be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mdef supinf_2_def_3 (" _ +SUPINF-2K16\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "F be FunctionFUNCT-2M1-of(X,Y)", "G be FunctionFUNCT-2M1-of(X,Z)"
"func F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G \<rightarrow> FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) st  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) holds  for it2 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) holds ( for x be ElementSUBSET-1M1-of X holds it1 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x) & ( for x be ElementSUBSET-1M1-of X holds it2 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem supinf_2_th_16:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds rngSUPINF-2K12\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) c=MEMBEREDR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G"
sorry

mtheorem supinf_2_th_17:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) <=XXREAL-3R1 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> G"
sorry

mtheorem supinf_2_th_18:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> G <=XXREAL-3R1 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G)"
sorry

mdef supinf_2_def_4 ("-SUPINF-2K17\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "F be FunctionFUNCT-2M1-of(X,Y)"
"func -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F \<rightarrow> FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) st  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) holds  for it2 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) holds ( for x be ElementSUBSET-1M1-of X holds it1 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x) & ( for x be ElementSUBSET-1M1-of X holds it2 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem supinf_2_th_19:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =MEMBEREDR8 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
sorry

mtheorem supinf_2_th_20:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =XBOOLE-0R4 -SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =XBOOLE-0R4 -SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
sorry

mdef supinf_2_def_5 ("bounded-aboveSUPINF-2V1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"attr bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y) means
  (\<lambda>F. supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <XXREAL-0R3 +inftySUPINF-1K1)"..

mdef supinf_2_def_6 ("bounded-belowSUPINF-2V2\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"attr bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y) means
  (\<lambda>F. -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F)"..

mdef supinf_2_def_7 ("boundedSUPINF-2V3\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"attr boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y) means
  (\<lambda>F. F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>)"..

mtheorem supinf_2_cl_1:
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> also-is bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,Y) holds it be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> implies it be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
     sorry
qed "sorry"

mtheorem supinf_2_cl_2:
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> also-is boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,Y) holds it be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> implies it be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub>"
     sorry
qed "sorry"

mtheorem supinf_2_th_21:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> iff supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <XXREAL-0R3 +inftySUPINF-1K1 & -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
  using supinf_2_def_5 supinf_2_def_6 sorry

mtheorem supinf_2_th_22:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> iff -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
sorry

mtheorem supinf_2_th_23:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> iff -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
sorry

mtheorem supinf_2_th_24:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> iff -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be boundedSUPINF-2V3\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
  using supinf_2_th_22 supinf_2_th_23 sorry

mtheorem supinf_2_th_25:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds -inftySUPINF-1K2 <=XXREAL-3R1 F .SUPINF-2K15 x & F .SUPINF-2K15 x <=XXREAL-3R1 +inftySUPINF-1K1"
  using xxreal_0_th_4 xxreal_0_th_5 sorry

mtheorem supinf_2_th_26:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds Y c=MEMBEREDR2 REALNUMBERSK2 implies -inftySUPINF-1K2 <XXREAL-0R3 F .SUPINF-2K15 x & F .SUPINF-2K15 x <XXREAL-0R3 +inftySUPINF-1K1"
sorry

mtheorem supinf_2_th_27:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <=XXREAL-3R1 F .SUPINF-2K15 x & F .SUPINF-2K15 x <=XXREAL-3R1 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
sorry

mtheorem supinf_2_th_28:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> iff supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2)"
sorry

mtheorem supinf_2_th_29:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> iff infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2)"
sorry

mtheorem supinf_2_th_30:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> iff infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2)"
  using supinf_2_th_28 supinf_2_th_29 sorry

mtheorem supinf_2_th_31:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F1 be FunctionFUNCT-2M1-of(X,Y) holds  for F2 be FunctionFUNCT-2M1-of(X,Z) holds F1 be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> & F2 be bounded-aboveSUPINF-2V1\<^bsub>(X,Z)\<^esub> implies F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be bounded-aboveSUPINF-2V1\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
sorry

mtheorem supinf_2_th_32:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F1 be FunctionFUNCT-2M1-of(X,Y) holds  for F2 be FunctionFUNCT-2M1-of(X,Z) holds F1 be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> & F2 be bounded-belowSUPINF-2V2\<^bsub>(X,Z)\<^esub> implies F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be bounded-belowSUPINF-2V2\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
sorry

mtheorem supinf_2_th_33:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F1 be FunctionFUNCT-2M1-of(X,Y) holds  for F2 be FunctionFUNCT-2M1-of(X,Z) holds F1 be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> & F2 be boundedSUPINF-2V3\<^bsub>(X,Z)\<^esub> implies F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be boundedSUPINF-2V3\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
  using supinf_2_th_32 supinf_2_th_31 sorry

mtheorem supinf_2_th_34:
"((idPARTFUN1K6 NATNUMBERSK1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 & idPARTFUN1K6 NATNUMBERSK1 be one-to-oneFUNCT-1V2) & NATNUMBERSK1 =MEMBEREDR12 rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> (idPARTFUN1K6 NATNUMBERSK1)) & rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> (idPARTFUN1K6 NATNUMBERSK1) be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
sorry

syntax SUPINF_2V4 :: " Set \<Rightarrow> Ty" ("countableSUPINF-2V4\<^bsub>'( _ ')\<^esub>" [0]70)
translations "countableSUPINF-2V4\<^bsub>(D)\<^esub>" \<rightharpoonup> "countableCARD-3V4"

mtheorem supinf_2_def_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "IT be SubsetSUBSET-1M2-of D"
"redefine attr countableSUPINF-2V4\<^bsub>(D)\<^esub> for SubsetSUBSET-1M2-of D means
  (\<lambda>IT. IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F))"
proof
(*compatibility*)
  show " for IT be SubsetSUBSET-1M2-of D holds IT be countableSUPINF-2V4\<^bsub>(D)\<^esub> iff IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F)"
sorry
qed "sorry"

mtheorem supinf_2_cl_3:
"cluster countableCARD-3V4 for  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st it be countableCARD-3V4"
sorry
qed "sorry"

mdef supinf_2_def_9 ("nonnegativeSUPINF-2V5" 70 ) where
"attr nonnegativeSUPINF-2V5 for setHIDDENM2 means
  (\<lambda>IT.  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 IT implies 0.SUPINF-2K2 <=XXREAL-3R1 x)"..

mtheorem supinf_2_cl_4:
"cluster nonnegativeSUPINF-2V5 for countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*existence*)
  show " ex it be countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st it be nonnegativeSUPINF-2V5"
sorry
qed "sorry"

(*\$CD*)
abbreviation(input) SUPINF_2K18("rngSUPINF-2K18  _ " [228]228) where
  "rngSUPINF-2K18 F \<equiv> rngRELAT-1K2 F"

mtheorem supinf_2_add_11:
  mlet "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
"cluster rngRELAT-1K2 F as-term-is  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "rngRELAT-1K2 F be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
sorry
qed "sorry"

mdef supinf_2_def_11 ("SerSUPINF-2K19  _ " [300]300 ) where
  mlet "N be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
"func SerSUPINF-2K19 N \<rightarrow> sequenceNAT-1M2-of ExtREALXXREAL-0K3 means
  \<lambda>it. it .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it .SUPINF-2K15 n implies it .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st it .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it .SUPINF-2K15 n implies it .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))"
sorry
  (*uniqueness*)
    show " for it1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for it2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds (it1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it1 .SUPINF-2K15 n implies it1 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))) & (it2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it2 .SUPINF-2K15 n implies it2 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

(*\$CT 4*)
mdef supinf_2_def_12 ("nonnegativeSUPINF-2V6" 70 ) where
"attr nonnegativeSUPINF-2V6 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be nonnegativeSUPINF-2V5)"..

mdef supinf_2_def_13 ("SUMSUPINF-2K20  _ " [164]164 ) where
  mlet "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
"func SUMSUPINF-2K20 F \<rightarrow> R-ealSUPINF-1M1 equals
  supSUPINF-2K11 (rngSUPINF-2K18 SerSUPINF-2K19 F)"
proof-
  (*coherence*)
    show "supSUPINF-2K11 (rngSUPINF-2K18 SerSUPINF-2K19 F) be R-ealSUPINF-1M1"
       sorry
qed "sorry"

mtheorem supinf_2_th_39:
" for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds F be nonnegativeSUPINF-2V6 iff ( for n be ElementSUBSET-1M1-of X holds 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n)"
sorry

mtheorem supinf_2_th_40:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for n be NatNAT-1M1 holds F be nonnegativeSUPINF-2V6 implies SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
sorry

mtheorem supinf_2_th_41:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 m))"
sorry

mtheorem supinf_2_th_42:
" for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds SerSUPINF-2K19 F1 .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 n)"
sorry

mtheorem supinf_2_th_43:
" for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies SUMSUPINF-2K20 F1 <=XXREAL-3R1 SUMSUPINF-2K20 F2"
sorry

(*\$CT*)
mtheorem supinf_2_th_45:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies (( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st F .SUPINF-2K15 n =XBOOLE-0R4 +inftySUPINF-1K1) implies SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1)"
sorry

mdef supinf_2_def_14 ("summableSUPINF-2V7" 70 ) where
"attr summableSUPINF-2V7 for sequenceNAT-1M2-of ExtREALXXREAL-0K3 means
  (\<lambda>F. SUMSUPINF-2K20 F inTARSKIR2 REALNUMBERSK2)"..

mtheorem supinf_2_th_46:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies (( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st F .SUPINF-2K15 n =XBOOLE-0R4 +inftySUPINF-1K1) implies  not F be summableSUPINF-2V7)"
  using supinf_2_th_45 sorry

mtheorem supinf_2_th_47:
" for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F1 be nonnegativeSUPINF-2V6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies (F2 be summableSUPINF-2V7 implies F1 be summableSUPINF-2V7)"
sorry

mtheorem supinf_2_th_48:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies ( for n be NatNAT-1M1 holds ( for r be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 r implies F .SUPINF-2K15 r =XBOOLE-0R4 0.SUPINF-2K2) implies SUMSUPINF-2K20 F =XBOOLE-0R4 SerSUPINF-2K19 F .SUPINF-2K15 n)"
sorry

mtheorem supinf_2_th_49:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2) implies ( for n be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2)"
sorry

mtheorem supinf_2_th_50:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 & ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 k implies F .SUPINF-2K15 k =XBOOLE-0R4 0.SUPINF-2K2) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-3R1 n implies F .SUPINF-2K15 k <>HIDDENR2 +inftySUPINF-1K1)) implies F be summableSUPINF-2V7"
sorry

mtheorem supinf_2_th_51:
" for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds F be nonnegativeSUPINF-2V6 iff ( for n be objectHIDDENM1 holds 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n)"
sorry

mtheorem supinf_2_th_52:
" for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds ( for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n) implies F be nonnegativeSUPINF-2V6"
sorry

mdef supinf_2_def_15 ("1.SUPINF-2K21" 164 ) where
"func 1.SUPINF-2K21 \<rightarrow> R-ealSUPINF-1M1 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
qed "sorry"

end
