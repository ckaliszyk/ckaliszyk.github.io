theory seqfunc
  imports fcont_1 classes1 limfunc1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve D1, D2, x, y for "setHIDDENM2"
reserve n, k for "NatNAT-1M1"
reserve p, x1, r for "RealXREAL-0M1"
reserve f for "FunctionFUNCT-1M1"
syntax SEQFUNCM1 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("Functional-SequenceSEQFUNCM1-of'( _ , _ ')" [0,0]70)
translations "Functional-SequenceSEQFUNCM1-of(D1,D2)" \<rightharpoonup> "sequenceNAT-1M2-of PFuncsPARTFUN1K4(D1,D2)"

reserve F for "Functional-SequenceSEQFUNCM1-of(D1,D2)"
syntax SEQFUNCK1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .SEQFUNCK1\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "F .SEQFUNCK1\<^bsub>(D1,D2)\<^esub> n" \<rightharpoonup> "F .FUNCT-1K1 n"

mtheorem seqfunc_add_1:
  mlet "D1 be setHIDDENM2", "D2 be setHIDDENM2", "F be Functional-SequenceSEQFUNCM1-of(D1,D2)", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster F .FUNCT-1K1 n as-term-is PartFuncPARTFUN1M1-of(D1,D2)"
proof
(*coherence*)
  show "F .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2)"
sorry
qed "sorry"

reserve G, H, H1, H2, J for "Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
mlemma seqfunc_lm_1:
" for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be Functional-SequenceSEQFUNCM1-of(D1,D2) iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2))"
sorry

mtheorem seqfunc_th_1:
" for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be Functional-SequenceSEQFUNCM1-of(D1,D2) iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2))"
sorry

theorem seqfunc_sch_1:
  fixes D1f0 D2f0 Ff1 
  assumes
[ty]: "D1f0 be setHIDDENM2" and
  [ty]: "D2f0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be PartFuncPARTFUN1M1-of(D1f0,D2f0)"
  shows " ex G be Functional-SequenceSEQFUNCM1-of(D1f0,D2f0) st  for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D1f0,D2f0)\<^esub> n =RELSET-1R2\<^bsub>(D1f0,D2f0)\<^esub> Ff1(n)"
sorry

mdef seqfunc_def_1 (" _ '(#')SEQFUNCK2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "r be RealXREAL-0M1"
"func r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef seqfunc_def_2 (" _ \<inverse>SEQFUNCK3\<^bsub>'( _ ')\<^esub>" [228,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef seqfunc_def_3 ("-SEQFUNCK4\<^bsub>'( _ ')\<^esub>  _ " [0,132]132 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func -SEQFUNCK4\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem SEQFUNCK4_involutiveness:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds -SEQFUNCK4\<^bsub>(D)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H) =HIDDENR1 H"
sorry

mdef seqfunc_def_4 ("absSEQFUNCK5\<^bsub>'( _ ')\<^esub>  _ " [0,250]250 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func absSEQFUNCK5\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mtheorem SEQFUNCK5_projectivity:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (absSEQFUNCK5\<^bsub>(D)\<^esub> H) =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> H"
sorry

mdef seqfunc_def_5 (" _ +SEQFUNCK6\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G +SEQFUNCK6\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef seqfunc_def_6 (" _ -SEQFUNCK7\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G -SEQFUNCK7\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) equals
  G +SEQFUNCK6\<^bsub>(D)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H)"
proof-
  (*coherence*)
    show "G +SEQFUNCK6\<^bsub>(D)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H) be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef seqfunc_def_7 (" _ '(#')SEQFUNCK8\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
sorry
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef seqfunc_def_8 (" _ '/SEQFUNCK9\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G /SEQFUNCK9\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) equals
  G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
proof-
  (*coherence*)
    show "G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem seqfunc_th_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H iff ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem seqfunc_th_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H iff ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
sorry

mtheorem seqfunc_th_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G +SEQFUNCK6\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H +SEQFUNCK6\<^bsub>(D)\<^esub> G & (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)"
sorry

mtheorem seqfunc_th_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G & (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)"
sorry

mtheorem seqfunc_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J & J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds -SEQFUNCK4\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J & J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)"
sorry

mtheorem seqfunc_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H & r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)"
sorry

mtheorem seqfunc_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds \<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H"
sorry

(*\$CT*)
mtheorem seqfunc_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
sorry

mtheorem seqfunc_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
sorry

mtheorem seqfunc_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>)"
sorry

mtheorem seqfunc_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G /SEQFUNCK9\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> ( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
sorry

reserve x for "ElementSUBSET-1M1-of D"
reserve X, Y for "setHIDDENM2"
reserve S1, S2 for "Real-SequenceSEQ-1M1"
reserve f for "PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
mdef seqfunc_def_9 (" _ common-on-domSEQFUNCR1\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50 ) where
  mlet "D1 be setHIDDENM2", "D2 be setHIDDENM2", "F be Functional-SequenceSEQFUNCM1-of(D1,D2)", "X be setHIDDENM2"
"pred X common-on-domSEQFUNCR1\<^bsub>(D1,D2)\<^esub> F means
  X <>HIDDENR2 {}XBOOLE-0K1 & ( for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D1)\<^esub> (F .SEQFUNCK1\<^bsub>(D1,D2)\<^esub> n))"..

mdef seqfunc_def_10 (" _ #SEQFUNCK10\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "x be ElementSUBSET-1M1-of D"
"func H #SEQFUNCK10\<^bsub>(D)\<^esub> x \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
sorry
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

mdef seqfunc_def_11 (" _ is-point-conv-onSEQFUNCR2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"pred H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X means
  X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))))"..

mtheorem seqfunc_th_19:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X iff X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x))"
sorry

mtheorem seqfunc_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X iff X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5)"
sorry

mdef seqfunc_def_12 (" _ is-unif-conv-onSEQFUNCR3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"pred H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X means
  X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"..

mdef seqfunc_def_13 ("limSEQFUNCK11\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"assume H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X func limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) \<rightarrow> PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
proof-
  (*existence*)
    show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)))"
sorry
  (*uniqueness*)
    show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem seqfunc_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies (f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) iff domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))))"
sorry

mtheorem seqfunc_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
sorry

mtheorem seqfunc_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1) & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies Y common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
sorry

mtheorem seqfunc_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1) & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> Y & (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)"
sorry

mtheorem seqfunc_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1) & H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> Y"
sorry

mtheorem seqfunc_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H)"
sorry

mtheorem seqfunc_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H)"
  using seqfunc_th_26 sorry

mtheorem seqfunc_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x"
sorry

mtheorem seqfunc_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
sorry

mtheorem seqfunc_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
sorry

mtheorem seqfunc_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
sorry

mtheorem seqfunc_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
  using seqfunc_th_29 sorry

mtheorem seqfunc_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
sorry

mtheorem seqfunc_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H1 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
  using seqfunc_th_31 sorry

mtheorem seqfunc_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
  using seqfunc_th_32 sorry

mtheorem seqfunc_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
  using seqfunc_th_33 sorry

mtheorem seqfunc_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2) & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2"
sorry

mtheorem seqfunc_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> -SEQFUNCK4\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_39:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
sorry

mtheorem seqfunc_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H1 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ((((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) & H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) & H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
sorry

mtheorem seqfunc_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ((absSEQFUNCK5\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(absSEQFUNCK5\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|) & -SEQFUNCK4\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & limSEQFUNCK11\<^bsub>(D)\<^esub>(-SEQFUNCK4\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)"
sorry

mtheorem seqfunc_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
sorry

mtheorem seqfunc_th_43:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X iff (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r))"
sorry

reserve H for "Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem seqfunc_th_44:
" for X be setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds H is-unif-conv-onSEQFUNCR3\<^bsub>(REALNUMBERSK2)\<^esub> X & ( for n be NatNAT-1M1 holds (H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) implies (limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
sorry

end
