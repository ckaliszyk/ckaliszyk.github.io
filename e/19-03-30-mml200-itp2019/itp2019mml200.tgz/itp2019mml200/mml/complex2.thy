theory complex2
  imports comptrig funct_4
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem complex2_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies ( ex r be RealXREAL-0M1 st (r =COMPLEX1R1 b *XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 a /XCMPLX-0K7 b /]) +XCMPLX-0K2 a & 0NUMBERSK6 <=XXREAL-0R1 r) & r <XXREAL-0R3 b)"
sorry

mtheorem complex2_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a >XXREAL-0R4 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & c >=XXREAL-0R2 0NUMBERSK6) & b <XXREAL-0R3 a) & c <XXREAL-0R3 a implies ( for i be IntegerINT-1M1 holds b =COMPLEX1R1 c +XCMPLX-0K2 a *XCMPLX-0K3 i implies b =COMPLEX1R1 c)"
sorry

mtheorem complex2_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 b) =COMPLEX1R1 (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b) & cosSIN-COSK20 (a -XCMPLX-0K6 b) =COMPLEX1R1 (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
sorry

mtheorem complex2_th_4:
" for a be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 a & (cosSIN-COSK19).FUNCT-1K1 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 a"
sorry

mtheorem complex2_th_5:
" for a be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 a & cosSIN-COSK20 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 a"
sorry

mtheorem complex2_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ & b inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (a <XXREAL-0R3 b iff sinSIN-COSK18 a <XXREAL-0R3 sinSIN-COSK18 b)"
sorry

mtheorem complex2_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ & b inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies (a <XXREAL-0R3 b iff sinSIN-COSK18 a >XXREAL-0R4 sinSIN-COSK18 b)"
sorry

mtheorem complex2_th_8:
" for a be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds sinSIN-COSK18 a =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 a)"
sorry

mtheorem complex2_th_9:
" for a be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds cosSIN-COSK20 a =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 a)"
sorry

mtheorem complex2_th_10:
" for a be RealXREAL-0M1 holds sinSIN-COSK18 a =COMPLEX1R1 0NUMBERSK6 implies cosSIN-COSK20 a <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem complex2_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((((0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & 0NUMBERSK6 <=XXREAL-0R1 b) & b <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 a =COMPLEX1R1 sinSIN-COSK18 b) & cosSIN-COSK20 a =COMPLEX1R1 cosSIN-COSK20 b implies a =COMPLEX1R1 b"
sorry

(*begin*)
mlemma complex2_lm_1:
"ArgCOMPTRIGK1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
  using comptrig_th_35 sorry

(*\$CT*)
mtheorem complex2_th_13:
" for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29) & (ArgCOMPTRIGK1 z >=XXREAL-0R2 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29)"
sorry

(*\$CT*)
mtheorem complex2_th_15:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 iff z =COMPLEX1R1  |.COMPLEX1K10 z.|"
sorry

mtheorem complex2_th_16:
" for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 iff ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29)"
sorry

mtheorem complex2_th_17:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x <>HIDDENR2 y or x -XCMPLX-0K6 y <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 PISIN-COSK29 iff ArgCOMPTRIGK1 (y -XCMPLX-0K6 x) >=XXREAL-0R2 PISIN-COSK29)"
sorry

mtheorem complex2_th_18:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ iff ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
sorry

mtheorem complex2_th_19:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 iff sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6)"
sorry

mtheorem complex2_th_20:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 x <XXREAL-0R3 PISIN-COSK29 & ArgCOMPTRIGK1 y <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (x +XCMPLX-0K2 y) <XXREAL-0R3 PISIN-COSK29"
sorry

mtheorem complex2_th_21:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 iff ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_22:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 iff ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_23:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 iff ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
sorry

mtheorem complex2_th_24:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z <=XXREAL-0R1 PISIN-COSK29 implies ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
sorry

mtheorem complex2_th_25:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds z <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 z) & sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 z)"
sorry

mtheorem complex2_th_26:
" for a be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|) & sinSIN-COSK18 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
sorry

mtheorem complex2_th_27:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
sorry

mtheorem complex2_th_28:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
sorry

(*begin*)
mdef complex2_def_1 (" _ .|.COMPLEX2K1  _ " [210,210]210 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"func x .|.COMPLEX2K1 y \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  x *XCMPLX-0K3 y *'COMPLEX1K9"
proof-
  (*coherence*)
    show "x *XCMPLX-0K3 y *'COMPLEX1K9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

reserve a, b, c, d, x, y, z for "ComplexXCMPLX-0M1"
mtheorem complex2_th_29:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 y =COMPLEX1R1 (ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y)+XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y)+REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
sorry

mtheorem complex2_th_30:
" for z be ComplexXCMPLX-0M1 holds z .|.COMPLEX2K1 z =COMPLEX1R1 ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z & z .|.COMPLEX2K1 z =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
sorry

mtheorem complex2_th_31:
" for z be ComplexXCMPLX-0M1 holds z .|.COMPLEX2K1 z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 & ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 ReCOMPLEX1K3 (z .|.COMPLEX2K1 z)"
sorry

mtheorem complex2_th_32:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 x .|.COMPLEX2K1 y.| =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
sorry

mtheorem complex2_th_33:
" for x be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_34:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds y .|.COMPLEX2K1 x =COMPLEX1R1 (x .|.COMPLEX2K1 y)*'COMPLEX1K9"
sorry

mtheorem complex2_th_35:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x +XCMPLX-0K2 y).|.COMPLEX2K1 z =COMPLEX1R1 x .|.COMPLEX2K1 z +XCMPLX-0K2 y .|.COMPLEX2K1 z"
   sorry

mtheorem complex2_th_36:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (y +XCMPLX-0K2 z) =COMPLEX1R1 x .|.COMPLEX2K1 y +XCMPLX-0K2 x .|.COMPLEX2K1 z"
sorry

mtheorem complex2_th_37:
" for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x).|.COMPLEX2K1 y =COMPLEX1R1 a *XCMPLX-0K3 x .|.COMPLEX2K1 y"
   sorry

mtheorem complex2_th_38:
" for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (a *XCMPLX-0K3 y) =COMPLEX1R1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y"
sorry

mtheorem complex2_th_39:
" for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x).|.COMPLEX2K1 y =COMPLEX1R1 x .|.COMPLEX2K1 (a *'COMPLEX1K9 *XCMPLX-0K3 y)"
sorry

mtheorem complex2_th_40:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x +XCMPLX-0K2 b *XCMPLX-0K3 y).|.COMPLEX2K1 z =COMPLEX1R1 a *XCMPLX-0K3 x .|.COMPLEX2K1 z +XCMPLX-0K2 b *XCMPLX-0K3 y .|.COMPLEX2K1 z"
   sorry

mtheorem complex2_th_41:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (a *XCMPLX-0K3 y +XCMPLX-0K2 b *XCMPLX-0K3 z) =COMPLEX1R1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y +XCMPLX-0K2 b *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 z"
sorry

mtheorem complex2_th_42:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 y =COMPLEX1R1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
sorry

mtheorem complex2_th_43:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 y =COMPLEX1R1 -XCMPLX-0K4 x .|.COMPLEX2K1 y"
   sorry

mtheorem complex2_th_44:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 x .|.COMPLEX2K1 y =COMPLEX1R1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
sorry

mtheorem complex2_th_45:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 (-XCMPLX-0K4 y) =COMPLEX1R1 x .|.COMPLEX2K1 y"
sorry

mtheorem complex2_th_46:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x -XCMPLX-0K6 y).|.COMPLEX2K1 z =COMPLEX1R1 x .|.COMPLEX2K1 z -XCMPLX-0K6 y .|.COMPLEX2K1 z"
   sorry

mtheorem complex2_th_47:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (y -XCMPLX-0K6 z) =COMPLEX1R1 x .|.COMPLEX2K1 y -XCMPLX-0K6 x .|.COMPLEX2K1 z"
sorry

mtheorem complex2_th_48:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (x +XCMPLX-0K2 y).|.COMPLEX2K1 (x +XCMPLX-0K2 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
sorry

mtheorem complex2_th_49:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
sorry

mlemma complex2_lm_2:
" for z be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
sorry

mtheorem complex2_th_50:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6 iff ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
sorry

(*begin*)
mdef complex2_def_2 ("RotateCOMPLEX2K2'( _ , _ ')" [0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "r be RealXREAL-0M1"
"func RotateCOMPLEX2K2(a,r) \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  (*coherence*)
    show "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

reserve r for "RealXREAL-0M1"
mtheorem complex2_th_51:
" for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,0NUMBERSK6) =COMPLEX1R1 a"
  using comptrig_th_62 sorry

mtheorem complex2_th_52:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6 iff a =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_53:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 RotateCOMPLEX2K2(a,r) .| =COMPLEX1R1  |.COMPLEX1K10 a.|"
sorry

mtheorem complex2_th_54:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ( ex i be IntegerINT-1M1 st ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))"
sorry

mtheorem complex2_th_55:
" for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,-XCMPLX-0K4 ArgCOMPTRIGK1 a) =COMPLEX1R1  |.COMPLEX1K10 a.|"
  using sin_cos_th_31 sorry

mtheorem complex2_th_56:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds ReCOMPLEX1K3 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r) & ImCOMPLEX1K4 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r)"
sorry

mtheorem complex2_th_57:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(a +XCMPLX-0K2 b,r) =COMPLEX1R1 RotateCOMPLEX2K2(a,r) +XCMPLX-0K2 RotateCOMPLEX2K2(b,r)"
sorry

mtheorem complex2_th_58:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =COMPLEX1R1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
sorry

mtheorem complex2_th_59:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(a -XCMPLX-0K6 b,r) =COMPLEX1R1 RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
sorry

mtheorem complex2_th_60:
" for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 a"
sorry

(*begin*)
mdef complex2_def_3 ("angleCOMPLEX2K3'( _ , _ ')" [0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1"
"func angleCOMPLEX2K3(a,b) \<rightarrow> RealXREAL-0M1 equals
  ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) if ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6 otherwise \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 a"
proof-
  (*coherence*)
    show "(ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6 implies ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) be RealXREAL-0M1) & ( not (ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6) implies \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 a be RealXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem complex2_th_61:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds r >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K3(r,a) =COMPLEX1R1 ArgCOMPTRIGK1 a"
sorry

mtheorem complex2_th_62:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b & a <>HIDDENR2 0NUMBERSK6) & b <>HIDDENR2 0NUMBERSK6 implies ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r))"
sorry

mtheorem complex2_th_63:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
sorry

mtheorem complex2_th_64:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b implies ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 b)"
sorry

mtheorem complex2_th_65:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r))"
sorry

mtheorem complex2_th_66:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds (r <XXREAL-0R3 0NUMBERSK6 & a <>HIDDENR2 0NUMBERSK6) & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
sorry

mtheorem complex2_th_67:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(-XCMPLX-0K4 a,-XCMPLX-0K4 b)"
sorry

mtheorem complex2_th_68:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 & angleCOMPLEX2K3(a,b) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,-XCMPLX-0K4 b) =COMPLEX1R1 PISIN-COSK29"
sorry

mtheorem complex2_th_69:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)) & sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
sorry

mdef complex2_def_4 ("angleCOMPLEX2K4'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1", "z be ComplexXCMPLX-0M1"
"func angleCOMPLEX2K4(x,y,z) \<rightarrow> RealXREAL-0M1 equals
  ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) if ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 otherwise \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
proof-
  (*coherence*)
    show "(ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 implies ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) be RealXREAL-0M1) & ( not ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 implies \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)) be RealXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem complex2_th_70:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) & angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
sorry

mtheorem complex2_th_71:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 angleCOMPLEX2K4(x -XCMPLX-0K6 y,0NUMBERSK6,z -XCMPLX-0K6 y)"
sorry

mtheorem complex2_th_72:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for d be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(a +XCMPLX-0K2 d,b +XCMPLX-0K2 d,c +XCMPLX-0K2 d)"
sorry

mtheorem complex2_th_73:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
sorry

mtheorem complex2_th_74:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_75:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies (ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6 iff angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
sorry

mtheorem complex2_th_76:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies (ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) iff angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
sorry

mlemma complex2_lm_3:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds a <>HIDDENR2 b & c <>HIDDENR2 b implies (ReCOMPLEX1K3 ((a -XCMPLX-0K6 b).|.COMPLEX2K1 (c -XCMPLX-0K6 b)) =COMPLEX1R1 0NUMBERSK6 iff angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
sorry

mtheorem complex2_th_77:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x <>HIDDENR2 y & z <>HIDDENR2 y) & (angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) implies ( |.COMPLEX1K10 x -XCMPLX-0K6 y .|)^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1 =COMPLEX1R1 ( |.COMPLEX1K10 x -XCMPLX-0K6 z .|)^2SQUARE-1K1"
sorry

mtheorem complex2_th_78:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds a <>HIDDENR2 b & b <>HIDDENR2 c implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
sorry

mtheorem complex2_th_79:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,a) =COMPLEX1R1 0NUMBERSK6"
sorry

mlemma complex2_lm_4:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
sorry

mtheorem complex2_th_80:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 iff angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
sorry

mtheorem complex2_th_81:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(c,b,a) <>HIDDENR2 0NUMBERSK6"
sorry

mtheorem complex2_th_82:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29 implies angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 PISIN-COSK29"
sorry

mtheorem complex2_th_83:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c implies (angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 or angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6) or angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6"
sorry

mlemma complex2_lm_5:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds ((ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6) & 0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 b) & ArgCOMPTRIGK1 b <XXREAL-0R3 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =COMPLEX1R1 PISIN-COSK29 & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a)) & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6)"
sorry

mtheorem complex2_th_84:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds ((a <>HIDDENR2 b & b <>HIDDENR2 c) & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(a,b,c)) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,c,a)) & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(c,a,b)"
sorry

mtheorem complex2_th_85:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & angleCOMPLEX2K4(b,c,a) >XXREAL-0R4 PISIN-COSK29) & angleCOMPLEX2K4(c,a,b) >XXREAL-0R4 PISIN-COSK29"
sorry

mlemma complex2_lm_6:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6) & ArgCOMPTRIGK1 b =COMPLEX1R1 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,0NUMBERSK6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0NUMBERSK6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0NUMBERSK6) =COMPLEX1R1 PISIN-COSK29 & 0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(0NUMBERSK6,b,a)) & 0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(b,a,0NUMBERSK6)"
sorry

mtheorem complex2_th_86:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29 implies angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_87:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds ((a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem complex2_th_88:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) iff (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
sorry

end
