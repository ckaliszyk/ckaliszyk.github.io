theory limfunc1
  imports prob_1 funct_3 rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, g for "RealXREAL-0M1"
reserve n, m, k for "NatNAT-1M1"
reserve seq, seq1, seq2 for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma limfunc1_lm_1:
" for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 & r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
sorry

mlemma limfunc1_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
sorry

mlemma limfunc1_lm_3:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
sorry

abbreviation(input) LIMFUNC1K1("left-open-halflineLIMFUNC1K1  _ " [164]164) where
  "left-open-halflineLIMFUNC1K1 r \<equiv> halflinePROB-1K10 r"

mdef limfunc1_def_1 ("left-closed-halflineLIMFUNC1K2  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func left-closed-halflineLIMFUNC1K2 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  ].XXREAL-1K3 -inftyXXREAL-0K2,r .]"
proof-
  (*coherence*)
    show "].XXREAL-1K3 -inftyXXREAL-0K2,r .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mdef limfunc1_def_2 ("right-closed-halflineLIMFUNC1K3  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func right-closed-halflineLIMFUNC1K3 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  [.XXREAL-1K2 r,+inftyXXREAL-0K1 .["
proof-
  (*coherence*)
    show "[.XXREAL-1K2 r,+inftyXXREAL-0K1 .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mdef limfunc1_def_3 ("right-open-halflineLIMFUNC1K4  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func right-open-halflineLIMFUNC1K4 r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  ].XXREAL-1K4 r,+inftyXXREAL-0K1 .["
proof-
  (*coherence*)
    show "].XXREAL-1K4 r,+inftyXXREAL-0K1 .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mtheorem limfunc1_th_1:
" for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V8 implies seq be bounded-belowSEQ-2V4) & (seq be non-increasingSEQM-3V9 implies seq be bounded-aboveSEQ-2V3)"
sorry

mtheorem limfunc1_th_2:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-decreasingSEQM-3V8 implies ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6)"
sorry

mtheorem limfunc1_th_3:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-increasingSEQM-3V9 implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n)"
sorry

mtheorem limfunc1_th_4:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 m)"
sorry

mtheorem limfunc1_th_5:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies (limSEQ-2K1 seq)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 seq .FUNCT-1K1 m)"
sorry

reserve r, r1, r2, g, g1, g2 for "RealXREAL-0M1"
mdef limfunc1_def_4 ("divergent-to+inftyLIMFUNC1V1" 70 ) where
"attr divergent-to+inftyLIMFUNC1V1 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies r <XXREAL-0R3 seq .FUNCT-1K1 m)"..

mdef limfunc1_def_5 ("divergent-to-inftyLIMFUNC1V2" 70 ) where
"attr divergent-to-inftyLIMFUNC1V2 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .FUNCT-1K1 m <XXREAL-0R3 r)"..

mtheorem limfunc1_th_6:
" for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m be non-zeroORDINAL1V9)"
sorry

mtheorem limfunc1_th_7:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1 implies seq be divergent-to+inftyLIMFUNC1V1) & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2 implies seq be divergent-to-inftyLIMFUNC1V2)"
sorry

mtheorem limfunc1_th_8:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be divergent-to+inftyLIMFUNC1V1 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_9:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be bounded-belowSEQ-2V4 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_10:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be divergent-to+inftyLIMFUNC1V1 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_11:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_12:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be bounded-aboveSEQ-2V3 implies seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
sorry

mlemma limfunc1_lm_4:
"0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
  using xreal_0_def_1 sorry

mtheorem limfunc1_th_13:
" for seq be Real-SequenceSEQ-1M1 holds  for r be RealXREAL-0M1 holds ((seq be divergent-to+inftyLIMFUNC1V1 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1) & (seq be divergent-to+inftyLIMFUNC1V1 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)) & (r =COMPLEX1R1 0NUMBERSK6 implies rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15)"
sorry

mtheorem limfunc1_th_14:
" for seq be Real-SequenceSEQ-1M1 holds  for r be RealXREAL-0M1 holds ((seq be divergent-to-inftyLIMFUNC1V2 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2) & (seq be divergent-to-inftyLIMFUNC1V2 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)) & (r =COMPLEX1R1 0NUMBERSK6 implies rngFUNCT-1K2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15)"
sorry

mtheorem limfunc1_th_15:
" for seq be Real-SequenceSEQ-1M1 holds (seq be divergent-to+inftyLIMFUNC1V1 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2) & (seq be divergent-to-inftyLIMFUNC1V2 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"
  using limfunc1_th_13 limfunc1_th_14 sorry

mtheorem limfunc1_th_16:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be divergent-to-inftyLIMFUNC1V2 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_17:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be divergent-to+inftyLIMFUNC1V1 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_18:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & seq1 be convergentSEQ-2V5 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to+inftyLIMFUNC1V1"
  using limfunc1_th_9 sorry

mtheorem limfunc1_th_19:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & seq1 be convergentSEQ-2V5 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be divergent-to-inftyLIMFUNC1V2"
  using limfunc1_th_12 sorry

mtheorem limfunc1_th_20:
" for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 n) implies seq be divergent-to+inftyLIMFUNC1V1"
sorry

mlemma limfunc1_lm_5:
" for n be NatNAT-1M1 holds idPARTFUN1K6 NATNUMBERSK1 .RECDEF-1K1 n =COMPLEX1R1 n"
  using ordinal1_def_12 funct_1_th_18 sorry

mtheorem limfunc1_th_21:
" for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 -XCMPLX-0K4 n) implies seq be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_22:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to+inftyLIMFUNC1V1 & ( ex r be RealXREAL-0M1 st r >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_23:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n >=XXREAL-0R2 r)) implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_24:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be divergent-to-inftyLIMFUNC1V2 & seq2 be divergent-to-inftyLIMFUNC1V2 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_25:
" for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_26:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_27:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_28:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (seq1 be divergent-to+inftyLIMFUNC1V1 & seq2 be convergentSEQ-2V5) & 0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 seq2 implies seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_29:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V8 &  not seq be bounded-aboveSEQ-2V3 implies seq be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_30:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V9 &  not seq be bounded-belowSEQ-2V4 implies seq be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_31:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V6 &  not seq be bounded-aboveSEQ-2V3 implies seq be divergent-to+inftyLIMFUNC1V1"
  using limfunc1_th_29 sorry

mtheorem limfunc1_th_32:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V7 &  not seq be bounded-belowSEQ-2V4 implies seq be divergent-to-inftyLIMFUNC1V2"
  using limfunc1_th_30 sorry

mtheorem limfunc1_th_33:
" for seq be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 implies (seq be convergentSEQ-2V5 or seq be divergent-to+inftyLIMFUNC1V1) or seq be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_34:
" for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 or seq be divergent-to-inftyLIMFUNC1V2 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5 & limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc1_th_35:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 seq .FUNCT-1K1 n) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_36:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_37:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-decreasingSEQM-3V8 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
sorry

mtheorem limfunc1_th_38:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be non-increasingSEQM-3V9 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_39:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be increasingSEQM-3V6 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
  using limfunc1_th_37 sorry

mtheorem limfunc1_th_40:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be non-zeroORDINAL1V9 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) & seq be decreasingSEQM-3V7 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
  using limfunc1_th_38 sorry

mtheorem limfunc1_th_41:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be boundedSEQ-2V6 & (seq2 be divergent-to+inftyLIMFUNC1V1 or seq2 be divergent-to-inftyLIMFUNC1V2) implies seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 be convergentSEQ-2V5 & limSEQ-2K1 (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc1_th_42:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n) implies seq1 be divergent-to+inftyLIMFUNC1V1"
sorry

mtheorem limfunc1_th_43:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 n) implies seq1 be divergent-to-inftyLIMFUNC1V2"
sorry

mdef limfunc1_def_6 ("convergent-in+inftyLIMFUNC1V3" 70 ) where
"attr convergent-in+inftyLIMFUNC1V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g))"..

mdef limfunc1_def_7 ("divergent-in+infty-to+inftyLIMFUNC1V4" 70 ) where
"attr divergent-in+infty-to+inftyLIMFUNC1V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1))"..

mdef limfunc1_def_8 ("divergent-in+infty-to-inftyLIMFUNC1V5" 70 ) where
"attr divergent-in+infty-to-inftyLIMFUNC1V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2))"..

mdef limfunc1_def_9 ("convergent-in-inftyLIMFUNC1V6" 70 ) where
"attr convergent-in-inftyLIMFUNC1V6 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g))"..

mdef limfunc1_def_10 ("divergent-in-infty-to+inftyLIMFUNC1V7" 70 ) where
"attr divergent-in-infty-to+inftyLIMFUNC1V7 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1))"..

mdef limfunc1_def_11 ("divergent-in-infty-to-inftyLIMFUNC1V8" 70 ) where
"attr divergent-in-infty-to-inftyLIMFUNC1V8 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f. ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2))"..

mtheorem limfunc1_th_44:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
sorry

mtheorem limfunc1_th_45:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
sorry

mtheorem limfunc1_th_46:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to+inftyLIMFUNC1V4 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)"
sorry

mtheorem limfunc1_th_47:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to-inftyLIMFUNC1V5 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)"
sorry

mtheorem limfunc1_th_48:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to+inftyLIMFUNC1V7 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies g <XXREAL-0R3 f .FUNCT-1K1 r1)"
sorry

mtheorem limfunc1_th_49:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to-inftyLIMFUNC1V8 iff ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g)"
sorry

mtheorem limfunc1_th_50:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & f2 be divergent-in+infty-to+inftyLIMFUNC1V4) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_51:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & f2 be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to-inftyLIMFUNC1V5 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_52:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & f2 be divergent-in-infty-to+inftyLIMFUNC1V7) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_53:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & f2 be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to-inftyLIMFUNC1V8 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_54:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_55:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r1) implies r <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_56:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_57:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r1) implies r <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_58:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (((f be divergent-in+infty-to+inftyLIMFUNC1V4 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4) & (f be divergent-in+infty-to+inftyLIMFUNC1V4 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5)) & (f be divergent-in+infty-to-inftyLIMFUNC1V5 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to-inftyLIMFUNC1V5)) & (f be divergent-in+infty-to-inftyLIMFUNC1V5 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4)"
sorry

mtheorem limfunc1_th_59:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (((f be divergent-in-infty-to+inftyLIMFUNC1V7 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7) & (f be divergent-in-infty-to+inftyLIMFUNC1V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8)) & (f be divergent-in-infty-to-inftyLIMFUNC1V8 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to-inftyLIMFUNC1V8)) & (f be divergent-in-infty-to-inftyLIMFUNC1V8 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7)"
sorry

mtheorem limfunc1_th_60:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_61:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_62:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_63:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
  using limfunc1_th_62 sorry

mtheorem limfunc1_th_64:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
sorry

mtheorem limfunc1_th_65:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be decreasingVALUED-0V10 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
  using limfunc1_th_64 sorry

mtheorem limfunc1_th_66:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-increasingVALUED-0V12 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_67:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be decreasingVALUED-0V10 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-aboveSEQ-2V1) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
  using limfunc1_th_66 sorry

mtheorem limfunc1_th_68:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-decreasingVALUED-0V11 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
sorry

mtheorem limfunc1_th_69:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be bounded-belowSEQ-2V2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
  using limfunc1_th_68 sorry

mtheorem limfunc1_th_70:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_71:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
sorry

mtheorem limfunc1_th_72:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_73:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
sorry

mtheorem limfunc1_th_74:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to+inftyLIMFUNC1V4 & ( ex r be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_75:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in+infty-to-inftyLIMFUNC1V5 & ( ex r be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in+infty-to-inftyLIMFUNC1V5"
sorry

mtheorem limfunc1_th_76:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to+inftyLIMFUNC1V7 & ( ex r be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_77:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 be divergent-in-infty-to-inftyLIMFUNC1V8 & ( ex r be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f be divergent-in-infty-to-inftyLIMFUNC1V8"
sorry

mdef limfunc1_def_12 ("lim-in+inftyLIMFUNC1K5  _ " [164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"assume f be convergent-in+inftyLIMFUNC1V3 func lim-in+inftyLIMFUNC1K5 f \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f be convergent-in+inftyLIMFUNC1V3 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
sorry
  (*uniqueness*)
    show "f be convergent-in+inftyLIMFUNC1V3 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to+inftyLIMFUNC1V1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mdef limfunc1_def_13 ("lim-in-inftyLIMFUNC1K6  _ " [164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"assume f be convergent-in-inftyLIMFUNC1V6 func lim-in-inftyLIMFUNC1K6 f \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f be convergent-in-inftyLIMFUNC1V6 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
sorry
  (*uniqueness*)
    show "f be convergent-in-inftyLIMFUNC1V6 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds seq be divergent-to-inftyLIMFUNC1V2 & rngFUNCT-1K2 seq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
sorry
qed "sorry"

mtheorem limfunc1_th_78:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be RealXREAL-0M1 holds f be convergent-in-inftyLIMFUNC1V6 implies (lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r1 <XXREAL-0R3 r & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
sorry

mtheorem limfunc1_th_79:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be RealXREAL-0M1 holds f be convergent-in+inftyLIMFUNC1V3 implies (lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex r be RealXREAL-0M1 st  for r1 be RealXREAL-0M1 holds r <XXREAL-0R3 r1 & r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
sorry

mtheorem limfunc1_th_80:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds f be convergent-in+inftyLIMFUNC1V3 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f)"
sorry

mtheorem limfunc1_th_81:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 -XCMPLX-0K4 lim-in+inftyLIMFUNC1K5 f"
sorry

mtheorem limfunc1_th_82:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1 +XCMPLX-0K2 lim-in+inftyLIMFUNC1K5 f2"
sorry

mtheorem limfunc1_th_83:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1 -XCMPLX-0K6 lim-in+inftyLIMFUNC1K5 f2"
sorry

mtheorem limfunc1_th_84:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc1_th_85:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in+inftyLIMFUNC1V3 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in+inftyLIMFUNC1K5 f .|"
sorry

mtheorem limfunc1_th_86:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f)\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc1_th_87:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f1)*XCMPLX-0K3 (lim-in+inftyLIMFUNC1K5 f2)"
sorry

mtheorem limfunc1_th_88:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f2 <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in+inftyLIMFUNC1K5 f1)/XCMPLX-0K7 (lim-in+inftyLIMFUNC1K5 f2)"
sorry

mtheorem limfunc1_th_89:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds f be convergent-in-inftyLIMFUNC1V6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 r *XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f)"
sorry

mtheorem limfunc1_th_90:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 -XCMPLX-0K4 lim-in-inftyLIMFUNC1K6 f"
sorry

mtheorem limfunc1_th_91:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1 +XCMPLX-0K2 lim-in-inftyLIMFUNC1K6 f2"
sorry

mtheorem limfunc1_th_92:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1 -XCMPLX-0K6 lim-in-inftyLIMFUNC1K6 f2"
sorry

mtheorem limfunc1_th_93:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc1_th_94:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be convergent-in-inftyLIMFUNC1V6 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f =COMPLEX1R1  |.COMPLEX1K10 lim-in-inftyLIMFUNC1K6 f .|"
sorry

mtheorem limfunc1_th_95:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f)\<inverse>XCMPLX-0K5"
sorry

mtheorem limfunc1_th_96:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f1)*XCMPLX-0K3 (lim-in-inftyLIMFUNC1K6 f2)"
sorry

mtheorem limfunc1_th_97:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f2 <>HIDDENR2 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 (lim-in-inftyLIMFUNC1K6 f1)/XCMPLX-0K7 (lim-in-inftyLIMFUNC1K6 f2)"
sorry

mtheorem limfunc1_th_98:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc1_th_99:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & ( ex r be RealXREAL-0M1 st f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc1_th_100:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
sorry

mtheorem limfunc1_th_101:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & lim-in+inftyLIMFUNC1K5 f1 =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f2) & ( ex r be RealXREAL-0M1 st right-open-halflineLIMFUNC1K4 r c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 lim-in+inftyLIMFUNC1K5 f1"
sorry

mtheorem limfunc1_th_102:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) & ( ex r be RealXREAL-0M1 st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
sorry

mtheorem limfunc1_th_103:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & lim-in-inftyLIMFUNC1K6 f1 =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f2) & ( ex r be RealXREAL-0M1 st left-open-halflineLIMFUNC1K1 r c=TARSKIR1 (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 lim-in-inftyLIMFUNC1K6 f1"
sorry

mtheorem limfunc1_th_104:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in+inftyLIMFUNC1V3 & f2 be convergent-in+inftyLIMFUNC1V3) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies lim-in+inftyLIMFUNC1K5 f1 <=XXREAL-0R1 lim-in+inftyLIMFUNC1K5 f2"
sorry

mtheorem limfunc1_th_105:
" for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 be convergent-in-inftyLIMFUNC1V6 & f2 be convergent-in-inftyLIMFUNC1V6) & ( ex r be RealXREAL-0M1 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies lim-in-inftyLIMFUNC1K6 f1 <=XXREAL-0R1 lim-in-inftyLIMFUNC1K6 f2"
sorry

mtheorem limfunc1_th_106:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in+infty-to+inftyLIMFUNC1V4 or f be divergent-in+infty-to-inftyLIMFUNC1V5) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc1_th_107:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be divergent-in-infty-to+inftyLIMFUNC1V7 or f be divergent-in-infty-to-inftyLIMFUNC1V8) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =COMPLEX1R1 0NUMBERSK6"
sorry

mtheorem limfunc1_th_108:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_109:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5"
sorry

mtheorem limfunc1_th_110:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_111:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( for r be RealXREAL-0M1 holds  ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6)) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8"
sorry

mtheorem limfunc1_th_112:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to+inftyLIMFUNC1V4"
sorry

mtheorem limfunc1_th_113:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in+inftyLIMFUNC1V3 & lim-in+inftyLIMFUNC1K5 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in+infty-to-inftyLIMFUNC1V5"
sorry

mtheorem limfunc1_th_114:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to+inftyLIMFUNC1V7"
sorry

mtheorem limfunc1_th_115:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be convergent-in-inftyLIMFUNC1V6 & lim-in-inftyLIMFUNC1K6 f =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> be divergent-in-infty-to-inftyLIMFUNC1V8"
sorry

end
