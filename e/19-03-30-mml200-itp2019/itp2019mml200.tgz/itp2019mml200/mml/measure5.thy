theory measure5
  imports rcomp_1 supinf_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b for "R-ealSUPINF-1M1"
theorem measure5_sch_1:
  fixes Pp1 
  shows " for X1 be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for X2 be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X1 iff Pp1(x)) & ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X2 iff Pp1(x)) implies X1 =MEMBEREDR9 X2"
sorry

abbreviation(input) MEASURE5K1("].MEASURE5K1 _ , _ .[" [0,0]164) where
  "].MEASURE5K1 a,b .[ \<equiv> ].XXREAL-1K4 a,b .["

mtheorem measure5_def_1:
  mlet "a be R-ealSUPINF-1M1", "b be R-ealSUPINF-1M1"
"redefine func ].MEASURE5K1 a,b .[ \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 means
  \<lambda>it.  for x be R-ealSUPINF-1M1 holds x inTARSKIR2 it iff a <XXREAL-0R3 x & x <XXREAL-0R3 b"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].MEASURE5K1 a,b .[ iff ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 it iff a <XXREAL-0R3 x & x <XXREAL-0R3 b)"
sorry
qed "sorry"

mtheorem measure5_add_1:
  mlet "a be R-ealSUPINF-1M1", "b be R-ealSUPINF-1M1"
"cluster ].XXREAL-1K4 a,b .[ as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "].XXREAL-1K4 a,b .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
sorry
qed "sorry"

mdef measure5_def_2 ("open-intervalMEASURE5V1" 70 ) where
"attr open-intervalMEASURE5V1 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be R-ealSUPINF-1M1 st  ex b be R-ealSUPINF-1M1 st IT =MEMBEREDR9 ].MEASURE5K1 a,b .[)"..

mdef measure5_def_3 ("closed-intervalMEASURE5V2" 70 ) where
"attr closed-intervalMEASURE5V2 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be RealXREAL-0M1 st  ex b be RealXREAL-0M1 st IT =MEMBEREDR9 [.RCOMP-1K1 a,b .])"..

mtheorem measure5_cl_1:
"cluster  non emptyXBOOLE-0V1\<bar>open-intervalMEASURE5V1 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>open-intervalMEASURE5V1"
sorry
qed "sorry"

mtheorem measure5_cl_2:
"cluster  non emptyXBOOLE-0V1\<bar>closed-intervalMEASURE5V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>closed-intervalMEASURE5V2"
sorry
qed "sorry"

mdef measure5_def_4 ("right-open-intervalMEASURE5V3" 70 ) where
"attr right-open-intervalMEASURE5V3 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be RealXREAL-0M1 st  ex b be R-ealSUPINF-1M1 st IT =MEMBEREDR9 [.RCOMP-1K3 a,b .[)"..

abbreviation(input) MEASURE5V4("left-closed-intervalMEASURE5V4" 70) where
  "left-closed-intervalMEASURE5V4 \<equiv> right-open-intervalMEASURE5V3"

mdef measure5_def_5 ("left-open-intervalMEASURE5V5" 70 ) where
"attr left-open-intervalMEASURE5V5 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be R-ealSUPINF-1M1 st  ex b be RealXREAL-0M1 st IT =MEMBEREDR9 ].RCOMP-1K4 a,b .])"..

abbreviation(input) MEASURE5V6("right-closed-intervalMEASURE5V6" 70) where
  "right-closed-intervalMEASURE5V6 \<equiv> left-open-intervalMEASURE5V5"

mtheorem measure5_cl_3:
"cluster  non emptyXBOOLE-0V1\<bar>right-open-intervalMEASURE5V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>right-open-intervalMEASURE5V3"
sorry
qed "sorry"

mtheorem measure5_cl_4:
"cluster  non emptyXBOOLE-0V1\<bar>left-open-intervalMEASURE5V5 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>left-open-intervalMEASURE5V5"
sorry
qed "sorry"

syntax MEASURE5M1 :: "Ty" ("IntervalMEASURE5M1" 70)
translations "IntervalMEASURE5M1" \<rightharpoonup> "intervalXXREAL-2V6\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"

reserve A, B for "IntervalMEASURE5M1"
mtheorem measure5_cl_5:
"cluster open-intervalMEASURE5V1 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be open-intervalMEASURE5V1 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_cl_6:
"cluster closed-intervalMEASURE5V2 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be closed-intervalMEASURE5V2 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_cl_7:
"cluster right-open-intervalMEASURE5V3 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be right-open-intervalMEASURE5V3 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_cl_8:
"cluster left-open-intervalMEASURE5V5 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be left-open-intervalMEASURE5V5 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_th_1:
" for I be intervalXXREAL-2V6\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((I be open-intervalMEASURE5V1 or I be closed-intervalMEASURE5V2) or I be right-open-intervalMEASURE5V3) or I be left-open-intervalMEASURE5V5"
sorry

mtheorem measure5_th_2:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds a <XXREAL-0R3 b implies ( ex x be R-ealSUPINF-1M1 st (a <XXREAL-0R3 x & x <XXREAL-0R3 b) & x inTARSKIR2 REALNUMBERSK2)"
sorry

mtheorem measure5_th_3:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for c be R-ealSUPINF-1M1 holds a <XXREAL-0R3 b & a <XXREAL-0R3 c implies ( ex x be R-ealSUPINF-1M1 st ((a <XXREAL-0R3 x & x <XXREAL-0R3 b) & x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2)"
sorry

mtheorem measure5_th_4:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for c be R-ealSUPINF-1M1 holds a <XXREAL-0R3 c & b <XXREAL-0R3 c implies ( ex x be R-ealSUPINF-1M1 st ((a <XXREAL-0R3 x & b <XXREAL-0R3 x) & x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2)"
sorry

mdef measure5_def_6 ("diameterMEASURE5K2  _ " [164]164 ) where
  mlet "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"func diameterMEASURE5K2 A \<rightarrow> R-ealSUPINF-1M1 equals
  supSUPINF-2K11 A -SUPINF-2K5 infSUPINF-2K10 A if A <>HIDDENR2 {}XBOOLE-0K1 otherwise 0.SUPINF-2K2"
proof-
  (*coherence*)
    show "(A <>HIDDENR2 {}XBOOLE-0K1 implies supSUPINF-2K11 A -SUPINF-2K5 infSUPINF-2K10 A be R-ealSUPINF-1M1) & ( not A <>HIDDENR2 {}XBOOLE-0K1 implies 0.SUPINF-2K2 be R-ealSUPINF-1M1)"
       sorry
  (*consistency*)
    show " for it be R-ealSUPINF-1M1 holds  True "
       sorry
qed "sorry"

mtheorem measure5_th_5:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <XXREAL-0R3 b implies diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <=XXREAL-0R1 a implies diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 0.SUPINF-2K2)"
sorry

mtheorem measure5_th_6:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <=XXREAL-0R1 b implies diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <XXREAL-0R3 a implies diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 0.SUPINF-2K2)"
sorry

mtheorem measure5_th_7:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <XXREAL-0R3 b implies diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <=XXREAL-0R1 a implies diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 0.SUPINF-2K2)"
sorry

mtheorem measure5_th_8:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <XXREAL-0R3 b implies diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <=XXREAL-0R1 a implies diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 0.SUPINF-2K2)"
sorry

mtheorem measure5_th_9:
" for A be IntervalMEASURE5M1 holds  for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1) & (((A =MEMBEREDR9 ].MEASURE5K1 a,b .[ or A =MEMBEREDR8 [.XXREAL-1K1 a,b .]) or A =MEMBEREDR8 [.XXREAL-1K2 a,b .[) or A =MEMBEREDR8 ].XXREAL-1K3 a,b .]) implies diameterMEASURE5K2 A =XBOOLE-0R4 +inftySUPINF-1K1"
sorry

mtheorem measure5_cl_9:
"cluster emptyXBOOLE-0V1 also-is open-intervalMEASURE5V1 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be emptyXBOOLE-0V1 implies it be open-intervalMEASURE5V1"
sorry
qed "sorry"

mtheorem measure5_th_10:
"diameterMEASURE5K2 {}XBOOLE-0K1 =XBOOLE-0R4 0.SUPINF-2K2"
  using measure5_def_6 sorry

mlemma measure5_lm_1:
" for A be IntervalMEASURE5M1 holds diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
sorry

mlemma measure5_lm_2:
" for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds A c=MEMBEREDR3 B implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
sorry

mtheorem measure5_th_11:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds (A c=MEMBEREDR3 B & B =MEMBEREDR8 [.XXREAL-1K1 a,b .]) & b <=XXREAL-0R1 a implies diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
sorry

mtheorem measure5_th_12:
" for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds A c=MEMBEREDR3 B implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
  using measure5_lm_2 sorry

mtheorem measure5_th_13:
" for A be IntervalMEASURE5M1 holds 0.SUPINF-2K2 <=XXREAL-0R1 diameterMEASURE5K2 A"
  using measure5_lm_1 sorry

mtheorem measure5_th_14:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be  non emptyXBOOLE-0V1\<bar>closed-intervalMEASURE5V2 iff ( ex a be RealXREAL-0M1 st  ex b be RealXREAL-0M1 st a <=XXREAL-0R1 b & X =MEMBEREDR9 [.RCOMP-1K1 a,b .])"
  using xxreal_1_th_29 xxreal_1_th_30 sorry

end
