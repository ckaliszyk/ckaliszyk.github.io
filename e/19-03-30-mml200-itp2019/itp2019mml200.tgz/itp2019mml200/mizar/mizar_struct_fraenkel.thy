theory mizar_struct_fraenkel
  imports "../mizar_extension/E_struct"
          "../mizar_extension/E_fraenkel"
	       "../mizar_extension/E_string"
begin

no_notation tarski_def_1 ("{ _ }" [0]90) 
no_notation tarski_def_2 ("{ _ , _}" [0,0]90)
no_notation tarski_def_3 (infixl "c=" 60)
no_notation tarski_def_4 ("union _")
no_notation tarski_def_3 (infixl "\<subseteq>" 60)
no_notation tarski_def_5 ("[_,_]" [0,0]90)
no_notation tarski_def_6 ("_ , _ areequipotent")
  
no_notation E_xboole_0_def_1 ("empty")
no_notation E_xboole_0_def_2 ("{}")
no_notation E_xboole_0_def_3 (infixl "\<union>" 65) 
no_notation E_xboole_0_def_4 (infixl "\<inter>" 70)
  
no_notation E_xboole_0_def_5 (infixl "\\" 70)
no_notation E_xboole_0_def_6 (infixl "\\+\\" 65)
no_notation E_xboole_0_def_9 ("_ , _ are c= comparable"[50,50] 40)
no_notation Succ  ("Succ _" [90] 90) 
  
no_notation E_xtuple_0_def_1  ("pair")
no_notation E_xtuple_0_def_2  ("_ `1" [90] 95)
no_notation E_xtuple_0_def_3  ("_ `2" [90] 95)
no_notation E_xtuple_0_def_12 ("proj1 _" [95] 95)
no_notation E_xtuple_0_def_13 ("proj2 _" [95] 95)
  
no_notation E_zfmisc_1_def_1 ("bool _" [110] 110)
no_notation E_zfmisc_1_def_2 ("[:_ ,_:]")
  
no_notation E_relat_1_def_1 ("Relation'_like")
no_notation relat_1_M_1     ("Relation")  
no_notation relat_1_syn_1   ("dom _" [105] 105)
no_notation relat_1_syn_2   ("rng _" [105] 105)
  
  
no_notation E_relat_1_def_11        (infix "|" 190)
no_notation relat_1_def_11_notation ("_ \<restriction> \<^bsub>_\<^esub>" [190,0] 190)  

no_notation E_funct_1_def_1 ("Function'_like")
no_notation funct_1_M_1     ("Function")
no_notation E_funct_1_def_2 (infix "." 110)

end