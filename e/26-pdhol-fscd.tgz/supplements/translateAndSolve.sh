#!/usr/bin/bash

echo Vampire
./translateAndSolveVampire.sh "$1" | grep "SZS status\|Success in time"
echo Leo
./translateAndSolveLeo.sh "$1" | grep "SZS status"
echo Zipper
./translateAndSolveZipper.sh "$1" | grep "SZS status\|iterations in"

