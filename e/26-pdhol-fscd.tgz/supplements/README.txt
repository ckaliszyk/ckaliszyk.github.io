In this directory are:
- the 'README' file you are currently reading
- the file 'embedproblem' which translates problems and generates their type checking constraints
- the file 'tptp4x' of the TPTP World which pretty prints tptp problem files
- the bash scripts 'translateAndSolve{prover}.sh' automating the process of recreating our
results, where '{prover}' is either 'Vampire', 'Leo' or 'Zipper' each calling the respective
theorem provers.
- the bash script 'translateAndSolve.sh' calling the three previously mentioned scripts and
filtering the output.
- the sub directory 'Problem Files' containing the files used in the case study

The Problem Files sub directory contains eight further sub directories. These contain the
TPTP problem files which are grouped by the conjecture they want to prove.

To run the translateAndSolve{Prover}*.sh scripts, you might first need to make them
executable. Under Unix systems this can be achieved by executing 'chmod +x
translateAndSolve{Prover}*.sh' without the single quotation marks and the name of the prover
substituted in the same directory as the file as a privileged user. Note that embedproblem
requires Java to be installed on your device. The scripts require the presence of their
respective provers in the same directory as they are, called vampire, leo and zipperposition. 

To perform the case studies, execute the translateAndSolve{Prover}.sh scripts from this
directory and pass one of the problem files as arguments, e.g. on a Linux system
'./translateAndSolve.sh "Problem\ Files/list-app-nil/list-app-nil.p"'
without the single quotes. This will print the output of vampire to the console and create one
or more files: the translated problem, potential type checking constraints, and the
translated type checking constraints, should any exist. Type checking constraints will have
file names containing the string 'TCC'.
