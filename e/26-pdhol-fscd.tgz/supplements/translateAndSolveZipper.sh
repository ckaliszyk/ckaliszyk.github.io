#!/usr/bin/bash

sourceDir=$(pwd)

if [[ -d /tmp ]]; then
    cp -R * /tmp
    cd /tmp
fi

if [[ ! -f ./embedproblem ]]; then
    echo "embedproblem not found"
    exit
fi

chmod +x tptp4X
chmod +x embedproblem
chmod +x zipperposition

problemNameWithPath=${1%%.*}
problemName=${problemNameWithPath##*/}

echo "##########################"
echo "$problemName"
echo "##########################"

COUNTER=0
./embedproblem -l \$\$dholtc --output tmp_TCC_"$problemName".p "$1" > /dev/null
for f in tmp_TCC_*.p*
do
    [ -e "$f" ] || continue
    COUNTER=$[$COUNTER +1]
    ./tptp4X "$f" > TCC_"$problemName"_"$COUNTER".p
done

for f in tmp_TCC*.p*
do
    [ -e "$f" ] || continue
    rm "$f"
done

for f in TCC_"$problemName"_*.p
do
    [ -e "$f" ] || continue
    ./embedproblem -l \$\$dhol --output tmp_translated"$f".p "$f" > /dev/null
done

COUNTER=0
for f in tmp_translated*.p
do
    [ -e "$f" ] || continue
    COUNTER=$[$COUNTER +1]
    ./tptp4X "$f" > translated_TCC_"$problemName"_"$COUNTER".p
done

COUNTER=0
./embedproblem -l \$\$dhol --output tmp_translated_"$problemName".p "$1" > /dev/null
for f in tmp_translated_*.p
do
    [ -e "$f" ] || continue
    COUNTER=$[$COUNTER +1]
    ./tptp4X "$f" > translated_"$problemName".p
done

for f in tmp_translated*.p
do
    [ -e "$f" ] || continue
    rm "$f"
done

for f in translated*"$problemName"*.p
do
    echo "Invoking zipperposition with default settings on $f"
    [ -e "$f" ] || continue
    ./zipperposition --ho true --timeout 120 --mode ho-competitive "$f"
    mv "$f" "$sourceDir"
done

if [[ -d /tmp ]]; then
    rm -R "Problem Files"
    rm embedproblem
    rm README.txt
    rm tptp4X
    rm translateAndSolveZipper.sh
    rm zipperposition
fi
