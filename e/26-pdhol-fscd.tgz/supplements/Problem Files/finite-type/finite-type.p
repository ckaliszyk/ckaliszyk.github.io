thf(nat_type,type,
    nat: $tType ).

thf(zero_type,type,
    zero: nat ).

thf(suc_type,type,
    suc: nat > nat ).

thf(fin_type,type,
    fin: nat > $tType ).

thf(fzero_type,type,
    fzero: !>[N: nat]: (fin @ N) ).

thf(fsuc_type,type,
    fsuc: !>[N: nat]: ( (fin @ N) > (fin @ (suc @ N)) ) ).

thf(vec_type,type,
    vec: $tType > nat > $tType ).

thf(nil_type,type,
    nil: !>[A: $tType]: (vec @ A @ zero) ).

thf(cons_type,type,
    cons: !>[A: $tType, N: nat]: (A > (vec @ A @ N) > (vec @ A @ (suc @ N)))).

thf(get_type,type,
    get: !>[A: $tType, N: nat]: ( (vec @ A @ N) > (fin @ N) > A ) ).

thf(get_suc,axiom,
    ![A: $tType, N: nat, X: A, V: vec @ A @ N, F: fin @ N]: ( (get @ A @ (suc @ N) @ (cons @ A @ N @ X @ V) @ (fsuc @ N @ F) ) = (get @ A @ N @ V @ F) ) ).

thf(get_zero,axiom,
    ![A: $tType, N: nat, X: A, V: vec @ A @ N, F: fin @ N]: (get @ A @ (suc @ N) @ (cons @ A @ N @ X @ V) @ (fzero @ N)) = X).

thf(not_nil,conjecture,
    ![A: $tType]: ( ~(?[X:A]: ( ( get @ A @ zero @ (nil @ A) @ (fzero @ zero) ) = X ) ) ) ).
