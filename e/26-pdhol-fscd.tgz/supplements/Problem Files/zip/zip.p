thf(nat_type,type,
    nat: $tType ).

thf(zero_type,type,
    zero: nat ).

thf(suc_type,type,
    suc: nat > nat ).

thf(plus_type,type,
    plus: nat > nat > nat ).

thf(list_type,type,
    list: $tType > nat > $tType ).

thf(nil_type,type,
    nil: 
      !>[A: $tType] : ( list @ A @ zero ) ).

thf(cons_type,type,
    cons: 
      !>[A: $tType,N: nat] : ( A > ( list @ A @ N ) > ( list @ A @ ( suc @ N ) ) ) ).

thf(head_type,type,
    head: 
      !>[A: $tType,N: nat] : ( ( list @ A @ ( suc @ N ) ) > A ) ).

thf(head_def,axiom,
    ! [A: $tType,X: A,N: nat,L: list @ A @ N] :
      ( ( head @ A @ ( suc @ N ) @ ( cons @ A @ N @ X @ L ) )
      = X ) ).

thf(tail_type,type,
    tail: 
      !>[A: $tType,N: nat] : ( ( list @ A @ ( suc @ N ) ) > ( list @ A @ N ) ) ).

thf(tail_def,axiom,
    ! [A: $tType,X: A,N: nat,L: list @ A @ N] :
      ( ( tail @ A @ ( suc @ N ) @ ( cons @ A @ N @ X @ L ) )
      = L ) ).

thf(map_type,type,
    map: 
      !>[A: $tType,B: $tType,N: nat] : ( ( A > B ) > ( list @ A @ N ) > ( list @ B @ N ) ) ).

thf(map_base,axiom,
    ! [A: $tType,B: $tType,F: A > B] :
      ( ( map @ A @ B @ zero @ F @ (nil @ A) )
      = (nil @ B) ) ).

thf(map_step,axiom,
    ! [A: $tType,B: $tType,N: nat,X: A,F: A > B,L: list @ A @ N] :
      ( ( map @ A @ B @ ( suc @ N ) @ F @ ( cons @ A @ N @ X @ L ) )
      = ( cons @ B @ N @ ( F @ X ) @ ( map @ A @ B @ N @ F @ L ) ) ) ).

thf(zip_type,type,
    zip: 
      !>[A: $tType,N: nat,M: nat] : ( ( list @ ( list @ A @ M ) @ N ) > ( list @ ( list @ A @ N ) @ M ) ) ).

thf(zip_base0,axiom,
    ! [A: $tType,M: nat] :
      ( ( zip @ A @ zero @ M @ ( nil @ ( list @ A @ M ) ) )
      = ( nil @ ( list @ A @ M ) ) ) ).

thf(zip_base1,axiom,
    ! [A: $tType,N: nat,L: list @ ( list @ A @ zero ) @ N] :
      ( ( zip @ A @ N @ zero @ L )
      = ( nil @ ( list @ A @ N ) ) ) ).

thf(zip_step,axiom,
    ! [A: $tType,N: nat,M: nat,X: A,Lsub: list @ A @ M,L: list @ ( list @ A @ ( suc @ M ) ) @ N] :
      ( ( zip @ A @ ( suc @ N ) @ ( suc @ M ) @ ( cons @ ( list @ A @ ( suc @ M ) ) @ N @ ( cons @ A @ M @ X @ Lsub ) @ L ) )
      = ( cons @ ( list @ A @ ( suc @ N ) ) @ M @ ( cons @ A @ N @ X @ ( map @ ( list @ A @ ( suc @ M ) ) @ A @ N @ ( head @ A @ M ) @ L ) ) @ ( zip @ A @ ( suc @ N ) @ M @ ( cons @ ( list @ A @ M ) @ N @ Lsub @ ( map @ ( list @ A @ ( suc @ M ) ) @ ( list @ A @ M ) @ N @ ( tail @ A @ M ) @ L ) ) ) ) ) ).

%thf(line,definition,
%    ( l
%    = ( cons @ nat @ ( suc @ zero ) @ zero @ ( cons @ nat @ zero @ zero @ ( nil @ nat ) ) ) ) ).

%thf(square,definition,
%    ( s
%    = ( cons @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) @ ( suc @ zero ) @ l @ ( cons @ ( list @ nat %@ ( suc @ ( suc @ zero ) ) ) @ zero @ l @ ( nil @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) ) ) ) ) ).

thf(square_transpose,conjecture,
    ( ( zip @ nat @ ( suc @ ( suc @ zero ) ) @ ( suc @ ( suc @ zero ) ) @ ( cons @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) @ ( suc @ zero ) @ ( cons @ nat @ ( suc @ zero ) @ zero @ ( cons @ nat @ zero @ zero @ ( nil @ nat ) ) ) @ ( cons @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) @ zero @ ( cons @ nat @ ( suc @ zero ) @ zero @ ( cons @ nat @ zero @ zero @ ( nil @ nat ) ) ) @ ( nil @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) ) ) ) )
    = ( cons @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) @ ( suc @ zero ) @ ( cons @ nat @ ( suc @ zero ) @ zero @ ( cons @ nat @ zero @ zero @ ( nil @ nat ) ) ) @ ( cons @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) @ zero @ ( cons @ nat @ ( suc @ zero ) @ zero @ ( cons @ nat @ zero @ zero @ ( nil @ nat ) ) ) @ ( nil @ ( list @ nat @ ( suc @ ( suc @ zero ) ) ) ) ) ) ) ).
