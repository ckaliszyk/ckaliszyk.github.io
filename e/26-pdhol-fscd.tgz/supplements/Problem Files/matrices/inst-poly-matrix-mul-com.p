thf(nat_type,type,
    nat: $tType ).

thf(zero_type,type,
    zero: nat ).

thf(suc_type,type,
    suc: nat > nat ).

thf(plus_type,type,
    plus: nat > nat > nat ).

thf(mul_type,type,
    mul: nat > nat > nat ).

thf(list_type,type,
    list: $tType > nat > $tType ).

thf(nil_type,type,
    nil: !>[A: $tType]: (list @ A @ zero) ).

thf(cons_type,type,
    cons: 
    !>[A: $tType, N: nat] : ( A > ( list @ A @ N ) > ( list @ A @ ( suc @ N ) ) ) ).

thf(app_type,type,
    app: 
    !>[A: $tType,N: nat,M: nat] : ( ( list @ A @ N ) > ( list @ A @ M ) > ( list @ A @ ( plus @ N @ M ) ) ) ).

thf(matrix_type,type,
    matrix: $tType > nat > nat > $tType ).

thf(mempty_type,type,
    mempty: 
    !>[A: $tType, N: nat] : ( matrix @ A @ zero @ N ) ).

thf(mcons_type,type,
    mcons: 
      !>[A: $tType, M: nat,N: nat] : ( ( list @ A @ N ) > ( matrix @ A @ M @ N ) > ( matrix @ A @ ( suc @ M ) @ N ) ) ).

thf(ladd_type,type,
    ladd: 
      !>[N: nat] : ( ( list @ nat @ N ) > ( list @ nat @ N ) > ( list @ nat @ N ) ) ).

thf(madd_type,type,
    madd: 
      !>[M: nat,N: nat] : ( ( matrix @ nat @ M @ N ) > ( matrix @ nat @ M @ N ) > ( matrix @ nat @ M @ N ) ) ).

thf(lmul_type,type,
    lmul: 
      !>[N: nat] : ( ( list @ nat @ N ) > ( list @ nat @ N ) > ( list @ nat @ N ) ) ).

thf(mmul_type,type,
    mmul: 
      !>[M: nat,N: nat] : ( ( matrix @ nat @ M @ N ) > ( matrix @ nat @ M @ N ) > ( matrix @ nat @ M @ N ) ) ).

thf(peano1,axiom,
    ! [N: nat] :
      ( ( suc @ N )
     != zero ) ).

thf(peano2,axiom,
    ! [N: nat,M: nat] :
      ( ( N != M )
     => ( ( suc @ N )
       != ( suc @ M ) ) ) ).

thf(peano3,axiom,
    ! [P: nat > $o] :
      ( ( P @ zero )
     => ( ! [M: nat] :
            ( ( P @ M )
           => ( P @ ( suc @ M ) ) )
       => ! [N: nat] : ( P @ N ) ) ) ).

thf(peano4,axiom,
! [N: nat] : ( ( plus @ N @ zero ) = N ) ).

thf(peano5,axiom,
    ! [N: nat, M: nat] : ( ( plus @ N @ (suc @ M) ) = ( suc @ (plus @ N @ M ) ) ) ).

thf(peano6,axiom,
    ! [N: nat] : ( (mul @ N @ zero) = zero ) ).

thf(peano7,axiom,
    ! [N: nat, M: nat] : ( (mul @ N @ (suc @ M) ) = (plus @ N @ (mul @ N @ M)))).

thf(ladd_nil,axiom,
    ( ( ladd @ zero @ (nil @ nat) @ (nil @ nat) )
    = (nil @ nat) ) ).

thf(lmul_nil,axiom,
    ( ( lmul @ zero @ (nil @ nat) @ (nil @ nat) )
    = (nil @ nat) ) ).

thf(ladd_cons,axiom,
    ! [N: nat,H1: nat,L1: (list @ nat @ N),H2: nat,L2: (list @ nat @ N)] :
      ( ( ladd @ ( suc @ N ) @ ( cons @ nat @ N @ H1 @ L1 ) @ ( cons @ nat @ N @ H2 @ L2 ) )
      = ( cons @ nat @ N @ ( plus @ H1 @ H2 ) @ ( ladd @ N @ L1 @ L2 ) ) ) ).

thf(lmul_cons,axiom,
    ! [N: nat,H1: nat,L1: (list @ nat @ N),H2: nat,L2: (list @ nat @ N)] :
      ( ( lmul @ ( suc @ N ) @ ( cons @ nat @ N @ H1 @ L1 ) @ ( cons @ nat @ N @ H2 @ L2 ) )
      = ( cons @ nat @ N @ ( mul @ H1 @ H2 ) @ ( lmul @ N @ L1 @ L2 ) ) ) ).

thf(madd_mempty,axiom,
    ! [N: nat] :
      ( ( madd @ zero @ N @ ( mempty @ nat @ N ) @ ( mempty @ nat @ N ) )
      = ( mempty @ nat @ N ) ) ).

thf(mmul_mempty,axiom,
    ! [N: nat] :
      ( ( mmul @ zero @ N @ ( mempty @ nat @ N ) @ ( mempty @ nat @ N ) )
      = ( mempty @ nat @ N ) ) ).

thf(madd_mcons,axiom,
    ! [M: nat,N: nat,L1: (list @ nat @ N),M1: (matrix @ nat @ M @ N),L2: (list @ nat @ N),M2: (matrix @ nat @ M @ N)] :
      ( ( madd @ ( suc @ M ) @ N @ ( mcons @ nat @ M @ N @ L1 @ M1 ) @ ( mcons @ nat @ M @ N @ L2 @ M2 ) )
      = ( mcons @ nat @ M @ N @ ( ladd @ N @ L1 @ L2 ) @ ( madd @ M @ N @ M1 @ M2 ) ) ) ).

thf(mmul_mcons,axiom,
    ! [M: nat,N: nat,L1: (list @ nat @ N),M1: (matrix @ nat @ M @ N),L2: (list @ nat @ N),M2: (matrix @ nat @ M @ N)] :
      ( ( mmul @ ( suc @ M ) @ N @ ( mcons @ nat @ M @ N @ L1 @ M1 ) @ ( mcons @ nat @ M @ N @ L2 @ M2 ) )
      = ( mcons @ nat @ M @ N @ ( lmul @ N @ L1 @ L2 ) @ ( mmul @ M @ N @ M1 @ M2 ) ) ) ).

thf(matrix_mul_com,conjecture,
    ! [M: nat,N: nat,M1: matrix @ nat @ M @ N,M2: matrix @ nat @ M @ N] :
      ( ( mmul @ M @ N @ M1 @ M2 )
      = ( mmul @ M @ N @ M2 @ M1 ) ) ).

