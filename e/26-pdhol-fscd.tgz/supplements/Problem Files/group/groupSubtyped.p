thf(group_type,type,
    group: $tType > $tType ).

thf(group_op,type,
    op_select: 
      !>[A: $tType,G: group @ A] : ( A > A > A ) ).

thf(is_group_type,type,
    is_group: 
      !>[A: $tType] : ( ( A > A > A ) > $o ) ).

thf(is_group,axiom,
    ! [A: $tType,G: group @ A] :
      ( ( is_group @ A @ ( op_select @ A @ G ) )
    <=> ? [N: A] :
        ! [X1: A,X2: A,X3: A,X: A] :
          ( ( ( op_select @ A @ G @ ( op_select @ A @ G @ X1 @ X2 ) @ X3 )
            = ( op_select @ A @ G @ X1 @ ( op_select @ A @ G @ X2 @ X3 ) ) )
          & ( ( op_select @ A @ G @ N @ X )
            = X )
          & ? [I: A] :
              ( ( op_select @ A @ G @ I @ X )
              = N ) ) ) ).

thf(all_groups_are_groups,axiom,
    ! [A: $tType,G: group @ A] : ( is_group @ A @ G ) ).

thf(is_neutral_type,type,
    is_neutral: 
      !>[A: $tType,G: group @ A] : ( A > $o ) ).

thf(is_neutral,axiom,
    ! [A: $tTYpe,G: group @ A,E: A] :
      ( ( is_neutral @ A @ G @ E )
    <=> ! [X: A] :
          ( ( op_select @ A @ G @ X @ E )
          = X ) ) ).

thf(is_homomorphism,type,
    is_homomorphism: 
      !>[A: $tType,B: $tType,G: group @ A,H: group @ B] : ( ( A > B ) > $o ) ).

thf(is_homomorph_axiom,axiom,
    ! [A: $tType,B: $tType,G: group @ A,H: group @ B,M: A > B,A1: A,A2: A] :
      ( ( is_homomorphism @ A @ B @ G @ H @ M )
    <=> ( ( M @ ( op_select @ A @ G @ A1 @ A2 ) )
        = ( op_select @ B @ H @ ( M @ A1 ) @ ( M @ A2 ) ) ) ) ).

thf(homomorphism_type,type,
    homomorphism: ^ [A: $tType,B: $tType,G: group @ A,H: group @ B] :
      ( ( A > B )
     << is_homomorphism @ A @ B @ G @ H ) ).

thf(homomorph_propagates_neutral,conjecture,
    ! [A: $tType,B: $tType,G: group @ A,H: group @ B,M: homomorphism @ A @ B @ G @ H,E: A] :
      ( ( is_neutral @ A @ G @ E )
     => ( is_neutral @ B @ H @ ( M @ E ) ) ) ).
