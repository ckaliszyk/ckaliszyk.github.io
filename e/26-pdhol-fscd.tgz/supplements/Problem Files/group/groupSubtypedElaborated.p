thf(group_type,type,
    group: $tType > $tType ).

thf(group_op,type,
    op_select: 
      !>[A: $tType,G: group @ A] : ( A > A > A ) ).

thf(is_group_type,type,
    is_group: 
      !>[A: $tType] : ( ( A > A > A ) > $o ) ).

thf(is_group,axiom,
    ! [A: $tType,G: group @ A] :
      ( ( is_group @ A @ ( op_select @ A @ G ) )
    <=> ? [N: A] :
        ! [X1: A,X2: A,X3: A,X: A] :
          ( ( ( op_select @ A @ G @ ( op_select @ A @ G @ X1 @ X2 ) @ X3 )
            = ( op_select @ A @ G @ X1 @ ( op_select @ A @ G @ X2 @ X3 ) ) )
          & ( ( op_select @ A @ G @ N @ X )
            = X )
          & ? [I: A] :
              ( ( op_select @ A @ G @ I @ X )
              = N ) ) ) ).

thf(all_groups_are_groups,axiom,
    ! [A: $tType,G: group @ A] : ( is_group @ A @ (op_select @ A @ G) ) ).

thf(is_neutral_type,type,
    is_neutral: 
      !>[A: $tType,G: group @ A] : ( A > $o ) ).

thf(is_neutral,axiom,
    ! [A: $tType,G: group @ A,E: A] :
      ( ( is_neutral @ A @ G @ E )
    <=> ! [X: A] :
          ( ( op_select @ A @ G @ X @ E )
          = X ) ) ).

thf(is_homomorphism,type,
    is_homomorphism: 
      !>[A: $tType,B: $tType,G: group @ A,H: group @ B] : ( ( A > B ) > $o ) ).

thf(is_homomorph_axiom,axiom,
    ! [A: $tType,B: $tType,G: group @ A,H: group @ B,A1: A,A2: A,M: A > B] :
      ( ( is_homomorphism @ A @ B @ G @ H @ M )
    <=> ( ( M @ ( op_select @ A @ G @ A1 @ A2 ) )
        = ( op_select @ B @ H @ ( M @ A1 ) @ ( M @ A2 ) ) ) ) ).

thf(homomorphism_type,type,
    homomorphism: 
      !>[A: $tType,B: $tType] : ( ( group @ A ) > ( group @ B ) > $tType ) ).

thf(homomorphismAbs,type,
    homoAbs: 
      !>[A: $tType,B: $tType,G: group @ A,H: group @ B] : ( ( A > B ) > ( homomorphism @ A @ B @ G @ H ) ) ).

thf(homomorphismRep,type,
    homoRep: 
      !>[A: $tType,B: $tType,G: group @ A,H: group @ B] : ( ( homomorphism @ A @ B @ G @ H ) > A > B ) ).

thf(homomorphismAx1,axiom,
    ! [A: $tType,B: $tType,G: group @ A,H: group @ B,U: homomorphism @ A @ B @ G @ H] :
      ( ( is_homomorphism @ A @ B @ G @ H @ ( homoRep @ A @ B @ G @ H @ U ) )
      & ( ( homoAbs @ A @ B @ G @ H @ ( homoRep @ A @ B @ G @ H @ U ) )
        = U ) ) ).

thf(homomorphismAx2,axiom,
    ! [A: $tType,B: $tType,G: group @ A,H: group @ B,V: A > B] :
      ( ( is_homomorphism @ A @ B @ G @ H @ V )
     => ( ( homoRep @ A @ B @ G @ H @ ( homoAbs @ A @ B @ G @ H @ V ) )
        = V ) ) ).

thf(homomorph_propagates_neutral,conjecture,
    ! [A: $tType,B: $tType,G: group @ A,H: group @ B,M: homomorphism @ A @ B @ G @ H,E: A] :
      ( ( is_neutral @ A @ G @ E )
     => ( is_neutral @ B @ H @ ( homoRep @ A @ B @ G @ H @ M @ E ) ) ) ).
