let lashdir = "/home/johannes/lash/source"
let modedir = ref (lashdir ^ "/../modes")
let picomus = ref (lashdir ^ "/picosat-936/picomus")
