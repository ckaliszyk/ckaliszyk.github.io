(* Lash *)
(* ported from Satallax file: term.ml
   but with major changes to use the C ftm representation
 *)

open String
open Preterm

let exact_dholtypecheck = ref false;;
let basename_no_h=(Hashtbl.create 1000 : (string, int) Hashtbl.t);;
let no_basename_h=(Hashtbl.create 1000 : (int, string) Hashtbl.t);;
let basename_num = ref 0;;
let basename_no name =
  try Hashtbl.find basename_no_h name
  with Not_found ->
    incr basename_num;
    Hashtbl.add basename_no_h name !basename_num;
    Hashtbl.add no_basename_h !basename_num name;
    !basename_num
and no_basename =
  try Hashtbl.find no_basename_h
  with Not_found -> assert false

let tyname_dollar_i = basename_no "$i";;
let tyname_set = basename_no "set";;
let tyname_star = basename_no "*";;
let tyname_underscore = basename_no "_";;
let tyname_dtp_tp = basename_no "_dtp";; (* distinguishing stp for special dtp terms and DBs *)
let tyname_dtp_err = basename_no "should be dtp";;

type stp_internal = Base of int | Prop | Ar of (int * int);;
let ty = Vector.make 1024 Prop;;
let bases = Vector.make 1024 0;;
let ars_hash = Hashtbl.create 1000;;

let ty_num = ref 1;; (* 0 is already prop *)
let mk_prop = 0;;
let mk_base i =
  let ret = Vector.get_default bases i 0 in
  if ret > 0 then ret else begin
    let ret = !ty_num in
    Vector.set ty ret (Base i);
    incr ty_num;
    Vector.set bases i ret; ret
  end;;

let mk_ar l r =
  try Hashtbl.find ars_hash (l, r) with
  | Not_found ->
    let ret = !ty_num in
    Vector.set ty ret (Ar (l, r));
    incr ty_num;
    Hashtbl.add ars_hash (l, r) ret; ret;;

let is_ar a = match Vector.get ty a with Ar(_,_) -> true | _ -> false
let is_base a = match Vector.get ty a with Base _ -> true | _ -> false
let ty_get_l a = match Vector.get ty a with Ar(a1,a2) -> a1 | _ -> assert false
let ty_get_r a = match Vector.get ty a with Ar(a1,a2) -> a2 | _ -> assert false
let ty_get_no a = match Vector.get ty a with Base b -> b | _ -> assert false

type stp = int;;

type trm =
    Name of string * stp
  | False | Imp | Forall of stp | Eq of stp | Choice of stp
  | True | Neg | Or | And | Iff | Exists of stp (*** These are normalized away. ***)
  | DB of int * stp
  | Lam of stp * trm
  | Ap of trm * trm
  | DPi of trm * trm | DForall of trm | DExists of trm | DEq of trm (*** DHOL ***)
  | DLam of trm * trm | DOf of trm * trm | DName of string * trm (*** DHOL ***)

let dtp_tp = mk_base tyname_dtp_tp
let star_trm = Name("*",dtp_tp)
let stp_err_trm = Name("should be stp",dtp_tp)
let typ_trm = Name("_type",dtp_tp)
let prop_trm = DName("_bool",typ_trm)
let ind_trm = DName("_ind",typ_trm)

let mk_base i =
  let ret = Vector.get_default bases i 0 in
  if ret > 0 then ret else begin
    let ret = !ty_num in
    Vector.set ty ret (Base i);
    incr ty_num;
    Vector.set bases i ret; ret
    end;;

type typ = STp of stp | DTp of trm
type ctx = (string * typ) list
type stp_ctx = (string * stp) list
         
exception ExpectedTypeError of pretrm * typ * typ

let stp_pred_over a =
  if is_ar a && ty_get_r a = mk_prop then
    Some(ty_get_l a)
  else
    None
                             
let dtp_pred_over m =
  match m with
  | DPi(m1,m2) -> if m2 = prop_trm then Some(m1) else None
  | _ -> None
                             
let oo = mk_ar mk_prop mk_prop
let ooo = mk_ar mk_prop oo
let oo_dtp = DPi(prop_trm,prop_trm)
let ooo_dtp = DPi(prop_trm,oo_dtp)

let imp x y = Ap(Ap(Imp,x),y)
let preneg x = Ap(Neg,x)
let neg x = imp x False
let normneg m =
  begin
    match m with
    | Ap(Ap(Imp,m1),False) -> m1
    | _ -> neg m
  end
let predisj x y = Ap(Ap(Or,x),y)
let preconj x y = Ap(Ap(And,x),y)
let preiff x y = Ap(Ap(Iff,x),y)
let disj x y = imp (neg x) y
let conj x y = neg (imp x (neg y))
let iff x y = Ap(Ap(Eq(mk_prop),x),y)
let eq a x y = Ap(Ap(Eq(a),x),y)
let forall a m = Ap(Forall(a),Lam(a,m))
let exists a m = neg (forall a (neg m))
let choice a m = Ap(Choice(a),Lam(a,m))
let dforall a m = Ap(DForall(a),DLam(a,m))
let dexists a m = neg (dforall a (neg m))
let deq a x y = Ap(Ap(DEq(a),x),y)                

let existsconst a = let ao = mk_ar a mk_prop in Lam(ao,neg (forall a (neg (Ap(DB(1,ao),DB(0,ao))))))

let lpar p = if p then "(" else ""

let rpar p = if p then ")" else ""

let rec stp_str_rec a p =
  if is_base a then
    no_basename (ty_get_no a)
  else if is_ar a then
    let b = ty_get_l a in
    let c = ty_get_r a in
    (lpar p) ^ (stp_str_rec b true) ^ ">" ^ (stp_str_rec c false) ^ (rpar p)
  else
    "$o"

let stp_str a = stp_str_rec a false

let rec stp_contains a b =
  if is_ar b then
    (stp_contains a (ty_get_l b) || stp_contains a (ty_get_r b))
  else
    a = b

let rec church_num_body m =
  match m with
  | DB(0,_) -> true
  | Ap(DB(1,_),m1) -> church_num_body m1
  | _ -> false

let rec church_num_body_val m =
  match m with
  | DB(0,_) -> 0
  | Ap(DB(1,_),m1) -> 1 + (church_num_body_val m1)
  | _ -> raise (GenericSyntaxError("Falsely thought I had the body of a Church numeral. BUG"))

let rec trm_str_rec m p =
  match m with
    Name(x,_) -> x
  | DName(x,_) -> x
  | Lam(a12,DB(0,_)) when is_ar a12 && (ty_get_l a12 = ty_get_r a12) -> "#1:" ^ (stp_str (ty_get_l a12)) (*** Church Numeral 1 Printed in a special way. - Chad, Feb 2, 2011 ***)
  | Lam(a12,Lam(a3,m)) when is_ar a12 && ty_get_l a12 = ty_get_r a12 && ty_get_l a12 = a3 && church_num_body m -> "#" ^ string_of_int (church_num_body_val m) ^ ":" ^ stp_str (ty_get_l a12) (*** Church Numerals Printed in a special way. - Chad, Feb 2, 2011 ***)
  | False -> "False"
  | Imp -> "imp"
  | Forall(a) -> "Pi:" ^ (stp_str a)
  | Eq(a) -> "eq:" ^ (stp_str a)
  | Choice(a) -> "Sepsilon:" ^ (stp_str a)
  | DB(i,_) -> "^" ^ (string_of_int i)
  | Lam(a,m) -> (lpar p) ^ "\\_:" ^ (stp_str a) ^ "." ^ (trm_str_rec m false) ^ (rpar p)
  | Ap(m1,m2) ->
      begin
	match m1 with
	| Lam _ -> (lpar p) ^ (trm_str_rec m1 true) ^ " " ^ (trm_str_rec m2 true) ^ (rpar p)
	| _ -> (lpar p) ^ (trm_str_rec m1 false) ^ " " ^ (trm_str_rec m2 true) ^ (rpar p)
      end
(*** If logic has not been normalized away ***)
  | True -> "True"
  | Neg -> "not"
  | Or -> "or"
  | And -> "and"
  | Iff -> "iff"
  | Exists(_) -> "Sigma"
  (*** extension to DHOL ***)
  | DPi(m1,m2) -> (lpar p) ^ "DPi:" ^ (trm_str_rec m1 false) ^ "." ^ (trm_str_rec m2 false) ^ (rpar p)
  | DForall(m) -> "DAll:" ^ (trm_str_rec m true)
  | DExists(m) -> "DExists:" ^ (trm_str_rec m false)
  | DEq(m) -> "deq:" ^ (trm_str_rec m true)
  | DLam(m1,m2) -> (lpar p) ^ "\\_:" ^ (trm_str_rec m1 false) ^ "." ^ (trm_str_rec m2 false) ^ (rpar p)
  | DOf(m1,m2) -> (lpar p) ^ (trm_str_rec m1 false) ^ "of" ^ (trm_str_rec m2 false)
let trm_str m = trm_str_rec m false

(*** This function assumes m is well-typed. ***)
let rec tpof m =
  match m with
    Name(_,a) -> a
  | False -> mk_prop
  | Imp -> ooo
  | Forall(a) -> mk_ar (mk_ar a mk_prop) mk_prop
  | Eq(a) -> mk_ar a (mk_ar a mk_prop)
  | Choice(a) -> mk_ar (mk_ar a mk_prop) a
  | DB(_,a) -> a
  | Lam(a,n) -> mk_ar a (tpof n)
  | Ap(f,n) ->
     begin
       let ab = tpof f in
       if is_ar ab then
         ty_get_r ab
       else
         raise (GenericSyntaxError("Non-function applied: " ^ (trm_str m)))
      end
  | _ -> raise (GenericSyntaxError("Unexpected type case - were logical constants normalized away? " ^ (trm_str m)))

let ueq x y = Ap(Ap(Eq(tpof(x)),x),y)

(*** Call this to check application is well typed ***)
let ap (m,n) =
  let ab = tpof m in
  let c = tpof n in
  if is_ar ab && ty_get_l ab = c then
    Ap(m,n)
  else
    raise (GenericSyntaxError("Ill typed application (" ^ (trm_str m) ^ " : " ^ (stp_str ab) ^ ") @ (" ^ (trm_str n) ^ " : " ^ (stp_str c) ^ ")"))

(** Prints type m as a Coq-formatted string on the out_channel c  **)
let rec print_stp_coq c m h p =
  if is_base m then
    let x = ty_get_no m in
    let x = try (Hashtbl.find h (no_basename x)) with Not_found -> failwith("print_stp_coq can't find coqname of "^ (no_basename x)) in
    Printf.fprintf c "%s" x
  else if m = mk_prop then
    Printf.fprintf c "o"
  else if is_ar m then
    begin
      let a = ty_get_l m in
      let b = ty_get_r m in
      if p then Printf.fprintf c "(";
      print_stp_coq c a h true;
      Printf.fprintf c " --> ";
      print_stp_coq c b h false;
      if p then Printf.fprintf c ")"
    end

(*
let rec print_stp_isar c m h p =
  match m with
    | Base x ->
	      let x = try (Hashtbl.find h x) with Not_found -> failwith("print_stp_isar can't find coqname of "^x) in
          Printf.fprintf c "%s" x
    | Prop ->
        Printf.fprintf c "o"
    | Ar(a,b) ->
        begin
	        if p then Printf.fprintf c "(";
	        print_stp_isar c a h true;
	        Printf.fprintf c " => ";
	        print_stp_isar c b h false;
	        if p then Printf.fprintf c ")"
        end
*)
let rec print_stp_isar c m p =
  if is_base m then
    let x = ty_get_no m in
    if x <> tyname_dollar_i then
      Printf.fprintf c "%s" (no_basename x)
    else
      Printf.fprintf c "i"(*FIXME this may clash with a base type that's really called "i"*)
  else if m = mk_prop then
    Printf.fprintf c "o"
  else if is_ar m then
    begin
      (*	        if p then*) Printf.fprintf c "(";
      let a = ty_get_l m in
      let b = ty_get_r m in
      print_stp_isar c a true;
      Printf.fprintf c "=>";
      print_stp_isar c b false;
      (*	        if p then*) Printf.fprintf c ")";
      flush c
    end

let rec print_stp_coq2 c m p =
  if is_base m then
    Printf.fprintf c "set"
  else if m = mk_prop then
    Printf.fprintf c "prop"
  else if is_ar m then
    begin
      let a = ty_get_l m in
      let b = ty_get_r m in
      if p then Printf.fprintf c "(";
      print_stp_coq2 c a true;
      Printf.fprintf c " > ";
      print_stp_coq2 c b false;
      if p then Printf.fprintf c ")"
    end


(*** Shifting, Substitution, Normalization ***)

let rec shift m i j =
  match m with
    DB(k,_) when k < i -> m
  | DB(k,a) -> DB(k + j,a)
  | Lam(a1,m2) -> Lam(a1,shift m2 (i + 1) j)
  | Ap(m1,m2) -> Ap(shift m1 i j,shift m2 i j)
  | DLam(m1,m2) -> DLam(shift m1 i j,shift m2 (i + 1) j)
  | DPi(m1,m2) -> DPi(shift m1 i j,shift m2 (i + 1) j)
  | _ -> m

let rec subst m i n =
  match m with
    DB(k,_) when k < i -> m
  | DB(k,_) when k = i -> n
  | DB(k,a) -> DB(k - 1,a)
  | Lam(a1,m2) -> Lam(a1,subst m2 (i + 1) (shift n 0 1))
  | Ap(m1,m2) -> Ap(subst m1 i n,subst m2 i n)
  | DLam(m1,m2) -> DLam(subst m1 i n,subst m2 (i + 1) (shift n 0 1))
  | DPi(m1,m2) -> DPi(subst m1 i n,subst m2 (i + 1) (shift n 0 1))
  | _ -> m
    
(*** Simultaneous Substitution ***)
(*** Assumes no dangling deBruijn indices. ***)
let rec simulsubst m s =
  match m with
    DB(k,_) ->
      let n = List.nth s k in
      if (m = n) then m else n
  | Lam(a1,m1) ->
      let n1 = simulsubst m1 ((DB(0,a1))::(List.map (fun n -> shift n 0 1) s)) in
      if (m1 = n1) then m else Lam(a1,n1)
  | Ap(m1,m2) ->
      let n1 = simulsubst m1 s in
      let n2 = simulsubst m2 s in
      if ((m1 = n1) && (m2 = n2)) then m else Ap(n1,n2)
  | _ -> m

let rec namesubst m x n =
  match m with
    Name(y,a) when (x = y) -> n
  | Lam(a1,m1) -> Lam(a1,namesubst m1 x n)
  | Ap(m1,m2) -> Ap(namesubst m1 x n,namesubst m2 x n)
  | _ -> m

let gen_lam_body a m =
  match m with
  | Lam(_,m1) -> m1
  | DLam(_,m1) -> m1
  | _ -> Ap(shift m 0 1,DB(0,a))

let rec termNotFreeIn m i =
  match m with
    DB(j,_) when i = j -> false
  | Ap(m1,m2) -> (termNotFreeIn m1 i) && (termNotFreeIn m2 i)
  | Lam(a,m1) -> termNotFreeIn m1 (i + 1)
  | _ -> true

let rec termNotFreeInL m il =
  match m with
    DB(j,_) when (List.mem j il) -> false
  | Ap(m1,m2) -> (termNotFreeInL m1 il) && (termNotFreeInL m2 il)
  | Lam(a,m1) -> termNotFreeInL m1 (List.map (fun i -> i + 1) il) 
  | _ -> true

let rec termNoDBs_rec m i =
  match m with
    DB(j,_) -> if (j < i) then true else false
  | Ap(m1,m2) -> (termNoDBs_rec m1 i) && (termNoDBs_rec m2 i)
  | Lam(a,m1) -> termNoDBs_rec m1 (i + 1)
  | _ -> true

let termNoDBs m = termNoDBs_rec m 0

let rec norm1 d m =
  match m with
    Ap(Lam(_,m1),m2) -> (* beta *)
      let (n1,_) = norm1 d m1 in
      let (n2,_) = norm1 d m2 in
      (subst n1 0 n2,true)
  | Lam(_,Ap(m1,DB(0,_))) when (termNotFreeIn m1 0) -> (* eta *)
       (shift m1 0 (- 1),true)
	(*** dneg ***)
  | Ap(Ap(Imp,Ap(Ap(Imp,m1),False)),False) -> (* double negation reduce *)
      let (n1,_) = norm1 d m1 in
      (n1,true)
  | Name(x,_) ->
      begin
	try
	  (Hashtbl.find d x,true)
	with
	| Not_found -> (m,false)
      end
  | Ap(m1,m2) ->
      let (n1,b1) = norm1 d m1 in
      let (n2,b2) = norm1 d m2 in
      if (b1 || b2) then
	(Ap(n1,n2),true)
      else
	(m,false)
  | Lam(a1,m1) ->
      let (n1,b1) = norm1 d m1 in
      if b1 then
	(Lam(a1,n1),true)
      else
	(m,false)
  | _ -> (m,false)

(* beta-eta-delta-dneg *)    
let rec norm d m =
  let (m1,reduced) = norm1 d m in
  if reduced then (norm d m1) else m

let rec betanorm1 d m =
  match m with
    Ap(Lam(a,m1),m2) -> (* beta *)
      let (n1,_) = betanorm1 d m1 in
      let (n2,_) = betanorm1 d m2 in
      (subst n1 0 n2,true)
  | Name(x,_) ->
      begin
	try
	  (Hashtbl.find d x,true)
	with
	| Not_found -> (m,false)
      end
  | Ap(m1,m2) ->
      let (n1,b1) = betanorm1 d m1 in
      let (n2,b2) = betanorm1 d m2 in
      if (b1 || b2) then
	(Ap(n1,n2),true)
      else
	(m,false)
  | Lam(a1,m1) ->
      let (n1,b1) = betanorm1 d m1 in
      if b1 then
	(Lam(a1,n1),true)
      else
	(m,false)
  | _ -> (m,false)
    
(* beta-delta *)    
let rec betanorm d m =
  let (m1,reduced) = betanorm1 d m in
  if reduced then (betanorm d m1) else m

let rec onlybetanorm1 m =
  match m with
    Ap(Lam(a,m1),m2) -> (* onlybeta *)
      let (n1,_) = onlybetanorm1 m1 in
      let (n2,_) = onlybetanorm1 m2 in
      (subst n1 0 n2,true)
  | Ap(m1,m2) ->
      let (n1,b1) = onlybetanorm1 m1 in
      let (n2,b2) = onlybetanorm1 m2 in
      if (b1 || b2) then
	(Ap(n1,n2),true)
      else
	(m,false)
  | Lam(a1,m1) ->
      let (n1,b1) = onlybetanorm1 m1 in
      if b1 then
	(Lam(a1,n1),true)
      else
	(m,false)
  | _ -> (m,false)
    
(* beta (no delta) *)
let rec onlybetanorm m =
  let (m1,reduced) = onlybetanorm1 m in
  if reduced then (onlybetanorm m1) else m

(** Replaces all occurences of 'Neg' by 'implies False' **)
let rec negnorm1 m =
  match m with
  | Ap(Neg,m1) ->
      let (n1,_) = negnorm1 m1 in
      (imp n1 False,true)
  | Neg -> (Lam(mk_prop,imp (DB(0,mk_prop)) False),true)
  | Ap(m1,m2) ->
      let (n1,b1) = negnorm1 m1 in
      let (n2,b2) = negnorm1 m2 in
      if (b1 || b2) then
	(Ap(n1,n2),true)
      else
	(m,false)
  | Lam(a1,m1) ->
      let (n1,b1) = negnorm1 m1 in
      if b1 then
	(Lam(a1,n1),true)
      else
	(m,false)
  | _ -> (m,false)

(** applies neg- and betanormalization**)
let onlynegnorm m =
  let (n,_) = negnorm1 m in onlybetanorm n

let rec logicnorm1 m =
  match m with
  | True -> (imp False False,true)
  | Ap(Neg,m1) ->
      let (n1,_) = logicnorm1 m1 in
      (imp n1 False,true)
  | Neg -> (Lam(mk_prop,imp (DB(0,mk_prop)) False),true)
  | Ap(Ap(Or,m1),m2) ->
      let (n1,_) = logicnorm1 m1 in
      let (n2,_) = logicnorm1 m2 in
      (disj n1 n2,true)
  | Or -> (Lam(mk_prop,Lam(mk_prop,disj (DB(1,mk_prop)) (DB(0,mk_prop)))),true)
  | Ap(Ap(And,m1),m2) ->
      let (n1,_) = logicnorm1 m1 in
      let (n2,_) = logicnorm1 m2 in
      (conj n1 n2,true)
  | And -> (Lam(mk_prop,Lam(mk_prop,conj (DB(1,mk_prop)) (DB(0,mk_prop)))),true)
  | Ap(Ap(Iff,m1),m2) ->
      let (n1,_) = logicnorm1 m1 in
      let (n2,_) = logicnorm1 m2 in
      (iff n1 n2,true)
  | Iff -> (Lam(mk_prop,Lam(mk_prop,iff (DB(1,mk_prop)) (DB(0,mk_prop)))),true)
  | Ap(Exists(a),Lam(_,m1)) ->
      let (n1,_) = logicnorm1 m1 in
      (exists a n1,true)
  | Exists(a) ->
      let ao = mk_ar a mk_prop in
      (Lam(ao,exists a (Ap(DB(1,ao),DB(0,a)))),true)
  | Ap(m1,m2) ->
      let (n1,b1) = logicnorm1 m1 in
      let (n2,b2) = logicnorm1 m2 in
      if (b1 || b2) then
	(Ap(n1,n2),true)
      else
	(m,false)
  | Lam(a1,m1) ->
      let (n1,b1) = logicnorm1 m1 in
      if b1 then
	(Lam(a1,n1),true)
      else
	(m,false)
  | _ -> (m,false)

(* Reduce logical constants to ->, False, forall, =, choice *)
let rec logicnorm m =
  let (n,_) = logicnorm1 m in n

let ideclared = ref false
let basetypestobool = ref false

(*** conversion of pretrm ***)
exception NotSimpleType
                    
let rec to_stp (m:pretrm) =
  match m with
    PPropTp -> mk_prop
  | PIndTp when !basetypestobool -> mk_prop
  | PName _ when !basetypestobool -> mk_prop
  | PIndTp ->
      if (!ideclared) then mk_base tyname_dollar_i
      else
       begin
        ideclared := true;
        raise DeclareInd
       end
  | PName x ->
     begin
       mk_base (basename_no x)
     end
  | PAr(a,b) -> mk_ar (to_stp a) (to_stp b)
  | _ -> raise NotSimpleType

let rec corresponding_dtp (h:(string,(trm * typ) * bool ref) Hashtbl.t) a =
  try
    begin
      if is_base a then
        begin
          let n = no_basename (ty_get_no a) in
          match n with
            "$i" -> ind_trm
          | _ ->
            begin
              let ((m,_),_) = Hashtbl.find h n in
              match m with
                DName(n',t) -> if n = n' && t = typ_trm then DName(n',typ_trm) else stp_err_trm
              | _ -> stp_err_trm
            end
        end
      else
        begin
          if is_ar a
          then
            let al_dtp = corresponding_dtp h (ty_get_l a) in
            let ar_dtp = corresponding_dtp h (ty_get_r a) in
            if (al_dtp = stp_err_trm || ar_dtp = stp_err_trm)
            then stp_err_trm
            else DPi(al_dtp,ar_dtp)
          else prop_trm
        end
    end
  with
    Not_found -> stp_err_trm

let corresponding_stp m = 
  match m with
    DName(n,_) ->
     begin
       match n with
         "_bool" -> mk_prop
       | "_ind" -> mk_base tyname_dollar_i
       | _ ->
          begin
           try
             mk_base (Hashtbl.find basename_no_h n)
           with Not_found ->
             mk_base tyname_dtp_err
         end
     end
  | _ -> mk_base tyname_dtp_err

(*This is like "head_spine" below, but accepts
  a bound to the number of "Ap"s it is to go
  through before stopping.*)
let bounded_head_spine n m =
  let rec head_spine_aux n m args =
    if n = 0 then (m, args)
    else
      match m with
          Ap (f, a) -> head_spine_aux (n - 1) f (a :: args)
        | _ -> (m, args)
  in
    head_spine_aux n m []

(*Unbounded form of "bounded_head_spine": it
  fully unfolds a term into the head (a non-applicative term)
  and the spine of terms it is applied to.*)
let head_spine m = bounded_head_spine (-1) m

let rec dtp_skeleton m =
  match m with
    DPi(a,b) -> DPi(dtp_skeleton a,dtp_skeleton b)
  | _ -> let (h,_) = head_spine m in h

let rec dtp_check a dtp =
  match a with
    DPi(a1a,a1b) ->
      begin
        match dtp with
          DPi(dtp1a,dtp1b) -> dtp_check a1a dtp1a && dtp_check a1b dtp1b
        | _ -> false
      end
  | _ ->
      begin
       match dtp with
         DPi(_,_) -> false
       | _ ->
         let (h_a,_) = head_spine a in
         let (h_dtp,_) = head_spine dtp in
         h_a = h_dtp
      end
let expected_tp m a stp dtp =
  match a with
    Some(STp(aa)) ->
     if aa = stp then () else raise (ExpectedTypeError(m,STp(aa),STp(stp)))
  | Some(DTp(aa)) ->
     let aa' = dtp_skeleton aa in
     if dtp_check aa dtp then () else raise (ExpectedTypeError(m,DTp(aa'),DTp(dtp)))
  | _ -> ()

let rec to_trm (h:(string,(trm * typ) * bool ref) Hashtbl.t) (g:ctx) (m:pretrm) (a:typ option) =
  match m with
  | PAp(PName "Eps",a) -> let b = to_stp a in (Choice b,STp((mk_ar (mk_ar b mk_prop) b)))
  | PName "In" -> let a = mk_base tyname_set in (Name("In",mk_ar a (mk_ar a mk_prop)), STp(mk_ar a (mk_ar a mk_prop)))
  | PName "Subq" -> let a = mk_base tyname_set in (Lam(a,Lam(a,Ap(Forall(a),Lam(a,Ap(Ap(Imp,Ap(Ap(Name("In",mk_ar a (mk_ar a mk_prop)),DB(0,a)),DB(2,a))),Ap(Ap(Name("In",mk_ar a (mk_ar a mk_prop)),DB(0,a)),DB(1,a))))))),STp(mk_ar a (mk_ar a mk_prop)))
  | PName x ->
      begin(*** look in g, then in h, then fail ***)
	try
	  to_db m x h g a 0
	with
	| Not_found ->
	    try
	      let (zz,o) = Hashtbl.find h x in
	      begin
		(match zz with
                   (_,STp b) -> expected_tp m a b (corresponding_dtp h b)
                 | (_,DTp b) -> expected_tp m a (corresponding_stp b) b
                );
		o := true; (** Mark that it's occurred. - Chad, March 31, 2011 **)
		zz
	      end
	    with
	    | Not_found -> raise (GenericSyntaxError ("Unknown Name " ^ x))
      end
  | PTrue ->
      begin
        expected_tp m a mk_prop prop_trm;
        match a with
          Some(DTp _) -> (True,DTp(prop_trm))
        | _ -> (True,STp(mk_prop))
      end
  | PFalse ->
      begin
        expected_tp m a mk_prop prop_trm;
        match a with
          Some(DTp _) -> (False,DTp(prop_trm))
        | _ -> (False,STp(mk_prop))
      end
  | PNeg ->
      begin
        expected_tp m a oo oo_dtp;
        match a with
          Some(DTp _) -> (Neg,DTp(oo_dtp))
        | _ -> (Neg,STp(oo))
      end
  | POr ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some(DTp _) -> (Or,DTp(ooo_dtp))
        | _ -> (Or,STp(ooo))
      end
  | PAnd ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some(DTp _) -> (And,DTp(ooo_dtp))
        | _ -> (And,STp(ooo))
      end
  | PIff ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some(DTp aa) -> (Iff,DTp(ooo_dtp))
        | _ -> (Iff,STp(ooo))
      end
  | PAp(PAp(PExists,m0),m1) ->
      begin
        try
	  expected_tp m a mk_prop prop_trm;   
	  let n0 = to_stp m0 in
	  let (n1,a1) = to_trm h g m1 (Some(STp(mk_ar n0 mk_prop))) in
          let err = ExpectedTypeError(m1,a1,STp(mk_ar (mk_base tyname_star) mk_prop)) in
          match a1 with
            STp(a1a) ->
              begin
                match stp_pred_over a1a with
	          Some(a1aa) -> (Ap(Exists(a1aa),n1),STp(mk_prop))
	        | _ -> raise err
              end
          | _ -> raise err
        with
        | NotSimpleType ->
           let n0 = to_dtp h g m0 in
           let (n1,a1) = to_trm h g m1 (Some(DTp(DPi(n0,prop_trm)))) in
           let err = ExpectedTypeError(m1,a1,DTp(DPi(star_trm,prop_trm))) in
           match a1 with
             DTp(a1a) ->
               begin
                 match dtp_pred_over a1a with
                   Some(a1aa) -> (Ap(DExists(a1aa),n1),DTp(prop_trm))
                 | _ -> raise err
               end
           | _ -> raise err
      end
  | PAp(PAp(PForall,m0),m1) ->
      begin
        try
	  expected_tp m a mk_prop prop_trm;
	  let n0 = to_stp m0 in
	  let (n1,a1) = to_trm h g m1 (Some(STp(mk_ar n0 mk_prop))) in
          let err = ExpectedTypeError(m1,a1,STp(mk_ar (mk_base tyname_star) mk_prop)) in
          match a1 with
            STp(a1a) ->
              begin
	        match stp_pred_over a1a with
	          Some(a1aa) -> (Ap(Forall(a1aa),n1),STp(mk_prop))
	        | _ -> raise err
              end
          | _ -> raise err
        with
        | NotSimpleType ->
           let n0 = to_dtp h g m0 in
           let (n1,a1) = to_trm h g m1 (Some(DTp(DPi(n0,prop_trm)))) in
           let err = ExpectedTypeError(m1,a1,DTp(DPi(star_trm,prop_trm))) in
           match a1 with
             DTp(a1a) ->
               begin
                 match dtp_pred_over a1a with
                   Some(a1aa) -> (Ap(DForall(a1aa),n1), DTp(prop_trm))
                 | _ -> raise err
               end
           | _ -> raise err
      end
  | PAp(PExists,m1) ->
      begin
	expected_tp m a mk_prop prop_trm;
	let (n1,a1) = to_trm h g m1 None in
        match a1 with
          STp(a1a) ->
            begin
              match stp_pred_over a1a with
	        Some(a1aa) -> (Ap(Exists(a1aa),n1),STp(mk_prop))
	      | _ ->
	        raise (ExpectedTypeError(m1,a1,STp(mk_ar (mk_base tyname_star) mk_prop)))
            end
        |  DTp(a1a) ->
            begin
	      match dtp_pred_over a1a with
                Some(a1aa) -> (Ap(DExists(a1aa),n1),DTp(prop_trm))
	      | _ -> raise (ExpectedTypeError(m1,a1,DTp(DPi(star_trm,prop_trm))))
            end
      end
  | PAp(PForall,m1) ->
       begin
	expected_tp m a mk_prop prop_trm;
	let (n1,a1) = to_trm h g m1 None in
        match a1 with
          STp(a1a) ->
            begin
	      match stp_pred_over a1a with
	        Some(a1aa) -> (Ap(Forall(a1aa),n1),STp(mk_prop))
	      | _ ->
	        raise (ExpectedTypeError(m1,a1,STp((mk_ar (mk_base tyname_star) mk_prop))))
            end
        | DTp(a1a) ->
           begin
             match dtp_pred_over a1a with
	       Some(a1aa) -> (Ap(DForall(a1aa),n1),DTp(prop_trm))
	     | _ -> raise (ExpectedTypeError(m1,a1,DTp(DPi(star_trm,prop_trm))))
           end
      end
  | PAp(PAp(PNIff,m1),m2) ->
      begin
        expected_tp m a mk_prop prop_trm;
        match a with
          Some (DTp _) ->
            (preneg (preiff (to_trm_1 h g m1 (Some (DTp(prop_trm))))
                            (to_trm_1 h g m2 (Some (DTp(prop_trm))))),DTp(prop_trm))
        | _ ->
            (preneg (preiff (to_trm_1 h g m1 (Some(STp(mk_prop))))
                            (to_trm_1 h g m2 (Some(STp(mk_prop))))),STp(mk_prop))
      end
  | PNIff ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
         Some (DTp _) ->
           (DLam(prop_trm,DLam(prop_trm,preneg (preiff (DB(1,mk_prop)) (DB(0,mk_prop))))),DTp(ooo_dtp))
        | _ ->
           (Lam(mk_prop,Lam(mk_prop,preneg (preiff (DB(1,mk_prop)) (DB(0,mk_prop))))),STp(ooo))
      end
  | PImplies ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some (DTp _) ->
            (DLam(prop_trm,DLam(prop_trm,imp (DB(1,mk_prop)) (DB(0,mk_prop)))),DTp(ooo_dtp))
        | _ ->
           (Lam(mk_prop,Lam(mk_prop,imp (DB(1,mk_prop)) (DB(0,mk_prop)))),STp(ooo))
      end
  | PRevImplies ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some (DTp _) ->
           (DLam(prop_trm,DLam(prop_trm,imp (DB(0,mk_prop)) (DB(1,mk_prop)))),DTp(ooo_dtp))
        | _ ->
           (Lam(mk_prop,Lam(mk_prop,imp (DB(0,mk_prop)) (DB(1,mk_prop)))),STp(ooo))
      end
  | PNOr ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some (DTp _) ->
           (DLam(prop_trm,DLam(prop_trm,preneg (predisj (DB(1,mk_prop)) (DB(0,mk_prop))))),DTp(ooo_dtp))
        | _ ->
           (Lam(mk_prop,Lam(mk_prop,preneg (predisj (DB(1,mk_prop)) (DB(0,mk_prop))))),STp(ooo))
       
      end
  | PNAnd ->
      begin
        expected_tp m a ooo ooo_dtp;
        match a with
          Some (DTp _) ->
           (DLam(prop_trm,DLam(prop_trm,preneg (preconj (DB(1,mk_prop)) (DB(0,mk_prop))))),DTp(ooo_dtp))
        | _ ->
           (Lam(mk_prop,Lam(mk_prop,preneg (preconj (DB(1,mk_prop)) (DB(0,mk_prop))))),STp(ooo))
      
      end
  | PAp(PAp(PEq,m1),m2) ->
      begin
        expected_tp m a mk_prop prop_trm;
        let (n1,b1) = to_trm h g m1 None in
        let n2 = to_trm_1 h g m2 (Some b1) in
        match b1 with
          STp(b1b) -> ((eq b1b n1 n2),STp(mk_prop))
        | DTp(b1b) -> ((deq b1b n1 n2),DTp(prop_trm))
     end
  | PEq ->
      begin
	match a with
	| Some(STp(aa)) ->
           let err = ExpectedTypeError(m,STp(aa),STp(mk_ar (mk_base tyname_star) (mk_ar (mk_base tyname_star) mk_prop))) in
           if is_ar aa then
             begin
               let aaa = ty_get_r aa in
               match stp_pred_over aaa with
               | Some(b2) ->
                  if b2 = ty_get_l aa then
                    (Lam(b2,Lam(b2,eq b2 (DB(1,mk_prop)) (DB(0,mk_prop)))),STp(aa))
                  else
	            raise err
               | None -> raise err
             end
           else
	     raise err
        | Some(DTp(DPi(a1,a2))) ->
            begin
              let err = ExpectedTypeError(m,DTp(DPi(a1,a2)),DTp(DPi(star_trm,DPi(star_trm,prop_trm)))) in
              match dtp_pred_over a2 with
                Some(b2) ->
                 expected_tp PEq (Some(DTp(b2))) (mk_base tyname_dtp_err) a1;
                 (DLam(b2,DLam(b2,deq b2 (DB(1,mk_prop)) (DB(0,mk_prop)))),DTp(DPi(a1,a2)))
              | None -> raise err
            end
	| _ -> raise (GenericSyntaxError ("Cannot determine type of unapplied equality"));
      end
  | PAp(PAp(PNEq,m1),m2) ->
      begin
        expected_tp m a mk_prop prop_trm;
        let (n1,b1) = to_trm h g m1 None in
        let n2 = to_trm_1 h g m2 (Some b1) in
        match b1 with
          STp(b1b) -> (preneg (eq b1b n1 n2),STp(mk_prop))
        | DTp(b1b) -> (preneg (deq b1b n1 n2),DTp(prop_trm))
      end  
  | PNEq ->
     begin
       match a with
         Some(STp(aa)) ->
           let err = ExpectedTypeError(m,STp(aa),STp(mk_ar (mk_base tyname_star) (mk_ar (mk_base tyname_star) mk_prop))) in
           if is_ar aa then
             begin
               let aaa = ty_get_r aa in
               match stp_pred_over aaa with
               | Some(b2) ->
                  if b2 = ty_get_l aa then
	            (Lam(b2,Lam(b2,preneg (eq b2 (DB(1,mk_prop)) (DB(0,mk_prop))))),STp(aa))
                  else
	            raise err
               | None ->
	          raise err
             end
           else
	     raise err
        | Some(DTp(DPi(a1,a2))) ->
            begin
              let err = ExpectedTypeError(m,DTp(DPi(a1,a2)),DTp(DPi(star_trm,DPi(star_trm,prop_trm)))) in
              match dtp_pred_over a2 with
                Some(b2) ->
                  expected_tp PNEq (Some(DTp(b2))) (mk_base tyname_dtp_err) a1;
                  (DLam(b2,DLam(b2,preneg (deq b2 (DB(1,mk_prop)) (DB(0,mk_prop))))),DTp(DPi(a1,a2)))
              | None -> raise err
            end  
	| _ ->
	    raise (GenericSyntaxError ("Cannot determine type of unapplied negated equality"));
      end
  | PAp(m1,m2) ->
      begin
	let (n1,a1) = to_trm h g m1 None in
        match a1 with
          STp(aa1) ->
            if is_ar aa1 then
              let aa1a = ty_get_l aa1 in
              let aa1b = ty_get_r aa1 in
	      expected_tp m a aa1b (corresponding_dtp h aa1b);
	      let n2 = to_trm_1 h g m2 (Some(STp(aa1a))) in
	      (Ap(n1,n2),STp(aa1b))
            else
              raise (GenericSyntaxError("Non-function applied: " ^ (trm_str n1)))
        | DTp(DPi(aa1a,aa1b)) ->
           let n2 = to_trm_1 h g m2 (Some(DTp(aa1a))) in
           let aa1b_applied = subst aa1b 0 n2 in
           let aa1b_applied_stp = corresponding_stp aa1b_applied in
           expected_tp m a aa1b_applied_stp aa1b_applied;
           if aa1b_applied_stp = mk_base tyname_dtp_err
           then (Ap(n1,n2),DTp(aa1b_applied))
           else (Ap(n1,n2),STp(aa1b_applied_stp))
        | _ -> raise (GenericSyntaxError("Non-function applied: " ^ (trm_str n1)))
      end
  | PULam(xl,m1) ->
      begin
	match a with
	| Some(aa) -> to_ulam h g xl m1 aa
	| None -> raise (GenericSyntaxError("Cannot infer type omitted from lambda"))
      end
  | PLam(xl,m1) ->
      to_lam h g xl m1 a
  | PAll(xl,m1) ->
      expected_tp m a mk_prop prop_trm;
      (to_all h g xl m1,STp(mk_prop))
  | PEx(xl,m1) ->
      expected_tp m a mk_prop prop_trm;
      (to_exists h g xl m1,STp(mk_prop))
  | PExU(x,a1,m1) ->
      expected_tp m a mk_prop prop_trm;
      begin
        try
	  let atp = to_stp a1 in
	  match to_trm h ((x,STp(atp))::g) m1 (Some(STp(mk_prop))) with
	  | (m1a,_) -> (Ap(Lam(mk_ar atp mk_prop,Ap(Exists(atp),Lam(atp,Ap(Ap(And,Ap(DB(1,mk_ar atp mk_prop),DB(0,atp))),Ap(Forall(atp),Lam(atp,Ap(Ap(Imp,Ap(DB(2,mk_ar atp mk_prop),DB(0,atp))),Ap(Ap(Eq(atp),DB(0,atp)),DB(1,atp))))))))),Lam(atp,m1a)),STp(mk_prop))
        with
        | NotSimpleType -> raise (GenericSyntaxError("ExU only supports simple types for now"))
      end
  | PChoice((x,xa),m1) ->
      begin
        try
          let xaa = to_stp xa in
          let n1 = to_trm_1 h ((x,STp(xaa))::g) m1 (Some(STp(mk_prop))) in
          (choice xaa n1,STp(xaa))
        with
        | NotSimpleType -> raise (GenericSyntaxError("For choice, only simple types are allowed"))
      end
  | POf(m1,m2) ->
     begin
       try
         let b = to_stp m2 in
         expected_tp m1 a b (corresponding_dtp h b);
         to_trm h g m1 (Some(STp(b)))
       with
       | NotSimpleType ->
          let b = to_dtp h g m2 in
          expected_tp m1 a (corresponding_stp b) b;
          let (n1,_) = to_trm h g m1 (Some(DTp(b))) in
          (DOf(n1,b),DTp(b))
     end
  | PDPi(xl,m1) ->
      to_dpi h g xl m1
  | PDef(m1,_) ->
      to_trm h g m1 a
  | PLet(x,m1,m2) ->
     begin
	let (m1a,aa) = to_trm h g m1 None in
	let (m2b,bb) = to_trm h ((x,aa)::g) m2 a in
        match aa with
          STp(aaa) -> (Ap(Lam(aaa,m2b),m1a),bb)
        | DTp(aaa) -> (Ap(DLam(aaa,m2b),m1a),bb)
      end
  | PTLet(x,a1,m1,m2) ->
     begin
        try
	  let (m1a,aa) = to_trm h g m1 (Some(STp(to_stp a1))) in
	  let (m2b,bb) = to_trm h ((x,aa)::g) m2 a in
          match aa with
            STp(aaa) -> (Ap(Lam(aaa,m2b),m1a),bb)
          | _ -> raise NotSimpleType
        with
        | NotSimpleType ->
          let (m1a,aa) = to_trm h g m1 (Some(DTp(to_dtp h g a1))) in
	  let (m2b,bb) = to_trm h ((x,aa)::g) m2 a in
          match aa with
            DTp(aaa) -> (Ap(DLam(aaa,m2b),m1a),bb)
          | STp(aaa) -> raise (GenericSyntaxError ("Should be dependent type: " ^ (no_basename aaa)))
     end
  | PType -> (typ_trm,DTp(typ_trm))
  | PName "$type" -> (typ_trm,DTp(typ_trm))
  | PPropTp -> (prop_trm,DTp(typ_trm))
  | PName "$o" -> (prop_trm,DTp(typ_trm))
  | PAr(m1,m2) -> to_dpi h g [("",m1)] m2 (* "" indicates that DPi binds no variable *)
  | _ -> raise (GenericSyntaxError ("Ill-formed term " ^ (pretrm_str m)))
and to_trm_1 h g m a = let (n,_) = to_trm h g m a in n
and to_ulam h (g:ctx) xl m a =
  match xl with
    (x::xr) ->
     begin
       let err = (ExpectedTypeError(m,a,STp(mk_ar (mk_base tyname_underscore) (mk_base tyname_star)))) in
       match a with
         STp(aa) ->
           if is_ar aa then
            let a1 = ty_get_l aa in
            let a2 = ty_get_r aa in
	    let (n1,_) = to_ulam h ((x,STp(a1))::g) xr m (STp(a2)) in
	    (Lam(a1,n1),a)
           else
	     raise err
       |  _ -> raise err
      end
  | [] -> to_trm h g m (Some a)
and to_lam h (g:ctx) xl m a =
  match xl with
    ((x,xa)::xr) ->
      begin
        try
          let xaa = to_stp xa in
	  match a with
	  | Some(STp(aa)) ->
             if is_ar aa && ty_get_l aa = xaa then
               let a2 = ty_get_r aa in
               let (n1,_) = to_lam h ((x,STp(xaa))::g) xr m (Some(STp(a2))) in
	       (Lam(xaa,n1),STp(aa))
             else
	       raise (ExpectedTypeError(m,STp(aa),STp(mk_ar xaa (mk_base tyname_star))))
	  | None ->
             begin
	       let (n1,b) = to_lam h ((x,STp(xaa))::g) xr m None in
                 match b with
                   STp(b1) -> (Lam(xaa,n1),STp(mk_ar xaa b1))
                 | _ -> raise NotSimpleType
             end
          | Some(_) -> raise NotSimpleType
        with
        | NotSimpleType ->
           let xaa = to_dtp h g xa in
	  match a with
	    Some(DTp(DPi(a1,a2))) ->
               let (n1,_) = to_lam h ((x,DTp(xaa))::g) xr m (Some(DTp(a2))) in
               expected_tp (PName(x)) (Some(DTp(a1))) (mk_base tyname_dtp_err) xaa;
               (DLam(xaa,n1),DTp(DPi(a1,a2)))
          | None ->
             begin
	       let (n1,b) = to_lam h ((x,DTp(xaa))::g) xr m None in
               match b with
                 DTp(b1) -> (DLam(xaa,n1),DTp(DPi(xaa,b1)))
               | STp(b1) -> (DLam(xaa,n1),DTp(DPi(xaa,corresponding_dtp h b1)))
             end
          | Some(aa) ->
             let xaa' = dtp_skeleton xaa in
             raise (ExpectedTypeError(m,aa,DTp(DPi(xaa',star_trm))))
      end
  | [] -> to_trm h g m a
and to_all h (g:ctx) xl m =
  match xl with
    ((x,xa)::xr) ->
      begin
        try
	  let xaa = to_stp xa in
	  let n1 = to_all h ((x,STp(xaa))::g) xr m in
	  forall xaa n1
        with
        | NotSimpleType ->
           let xaa = to_dtp h g xa in
	   let n1 = to_all h ((x,DTp(xaa))::g) xr m in
	   dforall xaa n1
      end
  | [] -> to_trm_1 h g m (Some(STp(mk_prop)))
and to_exists h (g:ctx) xl m =
  match xl with
    ((x,xa)::xr) ->
      begin
        try 
	  let xaa = to_stp xa in
	  let n1 = to_exists h ((x,STp(xaa))::g) xr m in
	  Ap(Exists(xaa),Lam(xaa,n1))
        with
        | NotSimpleType ->
           let xaa = to_dtp h g xa in
	   let n1 = to_exists h ((x,DTp(xaa))::g) xr m in
           Ap(DExists(xaa),DLam(xaa,n1))
      end
  | [] ->
      to_trm_1 h g m (Some(STp(mk_prop)))
and to_db m x h g a i =
  match g with
    ((y,b)::gr) -> 
      if (x = y) then
	begin
          match b with
            STp(bb) ->
              expected_tp m a bb (corresponding_dtp h bb);
              (DB(i,bb),b)
          | DTp(bb) ->
             (* free vars in a type occur at different levels when
                constructing a term. shift is needed to match types correctly. *)
             let bb' = shift bb 0 (i+1) in
             expected_tp m a (corresponding_stp bb) bb';
              (DB(i,dtp_tp),DTp(bb')) 
	end
      else
	to_db m x h gr a (i + 1)
  | [] -> raise Not_found
and to_dpi h (g:ctx) xl m =
  match xl with
    ((x,xa)::xr) ->
       begin
         let xaa = to_dtp h g xa in
         if xaa = typ_trm then raise Polymorphism else
         let (n1,_) = to_dpi h ((x,DTp(xaa))::g) xr m in
         (DPi(xaa,n1),DTp(typ_trm))
       end
  | [] -> to_trm h g m (Some(DTp(typ_trm)))
and to_dtp h (g:ctx) (m:pretrm) =
  match m with
    PPropTp -> prop_trm
  | PIndTp -> ind_trm
  | _ ->
     begin
       let err = GenericSyntaxError ("Not a dependent type: " ^ pretrm_str m) in
       match to_trm h g m (Some(DTp(typ_trm))) with
         (n,DTp(a)) -> if a = typ_trm then n else raise err
       | _ -> raise err
    end

let neg_body m =
  match m with
    Ap(Ap(Imp,n),False) -> Some n
  | _ -> None

let eq_body m =
  match m with
      Ap (Ap (Eq a, x), y) -> Some (a, x, y)
    | _ -> None

let neg_p m =
  match (neg_body m) with Some _ -> true | None -> false

let rec rtp a = if is_ar a then rtp (ty_get_r a) else a

let rec argtps_rtp_rec a =
  if is_ar a then
    let a1 = ty_get_l a in
    let a2 = ty_get_r a in
    let (al,r) = argtps_rtp_rec a2 in
    (a1::al,r)
  else
    ([],a)

let argtps_rtp a = argtps_rtp_rec a


(*List the constants that occur in a term, as name-type pairs.
  NOTE the resulting list doesn't contain duplicate constants.*)
let rec consts_of_trm acc : trm -> stp_ctx = function
    Name (name, stp) ->
    begin
    try
      let stp' = List.assoc name acc
      in
        if stp' <> stp then failwith "Different types for same constant?"
        else acc
    with Not_found ->
      (name, stp) :: acc
    end
  | Lam (_, trm) -> consts_of_trm acc trm
  | Ap (trm1, trm2) ->
    let acc' = consts_of_trm acc trm1
    in consts_of_trm acc' trm2
  | False | Imp | Forall _ | Eq _ | Choice _
  | True | Neg | Or | And | Iff | Exists _
  | DB (_, _) -> acc

(*Produce a list of names (strings) of the base types that occur in a type.
  NOTE the resulting list doesn't contain duplicate names.*)
let rec base_types acc a : int list =
  if is_base a then
    let name = ty_get_no a in
    if List.mem name acc then acc
    else name :: acc
  else if is_ar a then
   let acc' = base_types acc (ty_get_l a)
   in base_types acc' (ty_get_r a)
  else
    acc

(*Lists the base types referenced in a term.
  NOTE the resulting list doesn't contain duplicate elements.*)
let rec base_types_of_trm acc : trm -> int list = function
    Name (name, stp) -> base_types acc stp
  | Lam (stp, trm) ->
    let acc' = base_types acc stp
    in base_types_of_trm acc' trm
  | Ap (trm1, trm2) ->
    let acc' = base_types_of_trm acc trm1
    in base_types_of_trm acc' trm2
  | Forall stp | Eq stp | Choice stp | Exists stp | DB (_, stp) ->
    base_types acc stp
  | False | Imp | True | Neg | Or | And | Iff -> acc

let fresh_prefix = "__"

let make_fresh_name i = fresh_prefix ^ string_of_int i
let is_fresh_name = StringE.starts_with fresh_prefix

let rec map_names f = function
  Name (x,a) -> f x a
| Lam (t,m) -> Lam(t, map_names f m)
| Ap (m,n) -> Ap(map_names f m, map_names f n)
| m -> m

let rec fold_names f acc = function
  Name (x,a) -> f acc x a
| Lam (t,m) -> let (acc', m') = fold_names f acc m in (acc', Lam(t, m'))
| Ap (m,n) ->
    let (acc' , m') = fold_names f acc  m in
    let (acc'', n') = fold_names f acc' n in
    (acc'', Ap(m', n'))
| m -> (acc, m)

let normalize_fresh_uni =
  map_names (fun x a -> Name((if is_fresh_name x then fresh_prefix else x), a))

let normalize_asc_fun p name ((m,i) as acc) x a =
  if p x
  then
  begin
    let (acc', x') =
      try (acc, List.assoc x m)
      with Not_found -> let i' = i+1 in (((x,i')::m,i'), i')
    in (acc', Name(name x', a))
  end
  else (acc, Name (x,a))

let normalize_fresh_asc m =
  fold_names (normalize_asc_fun is_fresh_name make_fresh_name) ([], 0) m

let normalize_asc m =
  fold_names (normalize_asc_fun (fun x -> true) (fun i -> "c" ^ string_of_int i)) ([], 0) m

let contains_fresh_names m = let ((_, i), _) = normalize_fresh_asc m in i > 0

(***
 gives a version with named vars and ~, ->, ! intended to be more readable for the humans.
 partially based on the printer code for Egal
 ***)
let next_var_name a names othernames =
  let basevarnames = ["x";"y";"z";"w";"u";"v"] in
  let predvarnames = ["p";"q";"r"] in
  let funcvarnames = ["f";"g";"h"] in
  let varnames =
    if rtp a = mk_prop then
      predvarnames
    else if is_ar a then
      funcvarnames
    else
      basevarnames
  in
  let numvarnames = List.length varnames in
  let var_name_of j =
    if j < numvarnames then
      List.nth varnames j
    else
      let k = j / numvarnames in
      let m = j mod numvarnames in
      (List.nth varnames m) ^ string_of_int k
  in
  let i = ref 0 in
  let x = ref (var_name_of 0) in
  try
    while true do
      if List.mem !x names || List.mem !x othernames then (incr i; x := var_name_of !i) else raise Exit
    done;
    ""
  with Exit -> !x

let trm_str_nice_paren q (s,p) = if p <= q then s else "(" ^ s ^ ")"

let rec binderp m =
  match m with
  | Lam(_,_) -> true
  | Ap(Forall(_),Lam(_,_)) -> true
  | _ -> false

let rec trm_str_nice_rec m names othernames =
  match m with
    Name(x,_) -> (x,0)
  | Lam(a12,DB(0,_)) when is_ar a12 && (ty_get_l a12 = ty_get_r a12) -> ("#1:" ^ (stp_str (ty_get_l a12)),0) (*** Church Numeral 1 Printed in a special way. - Chad, Feb 2, 2011 ***)
  | Lam(a12,Lam(a3,m)) when is_ar a12 && ty_get_l a12 = ty_get_r a12 && ty_get_l a12 = a3 && church_num_body m -> ("#" ^ string_of_int (church_num_body_val m) ^ ":" ^ stp_str (ty_get_l a12),0) (*** Church Numerals Printed in a special way. - Chad, Feb 2, 2011 ***)
  | False -> ("False",0)
  | Imp -> ("imp",0)
  | Forall(a) -> ("Pi:" ^ (stp_str a),0)
  | Eq(a) -> ("eq:" ^ (stp_str a),0)
  | Choice(a) -> ("Sepsilon:" ^ (stp_str a),0)
  | DB(i,_) ->
      begin
	try
	  let x = List.nth names i in
	  (x,0)
	with Failure(_) ->
	  ("^" ^ (string_of_int (i - List.length names)),0)
      end
  | Lam(a,m1) ->
      let x = next_var_name a names othernames in
      ("\\" ^ x ^ ":" ^ (stp_str a) ^ "." ^ (trm_str_nice_paren 1010 (trm_str_nice_rec m1 (x::names) othernames)),1)
  | Ap(Ap(Eq(_),m1),m2) ->
      if binderp m1 then (*** to properly use 'binderish' I would need a separate 'layout' type; I'll use binderp instead and hope it's OK ***)
	((trm_str_nice_paren (-1) (trm_str_nice_rec m1 names othernames)) ^ " = " ^ (trm_str_nice_paren 502 (trm_str_nice_rec m2 names othernames)),502)
      else
	((trm_str_nice_paren 502 (trm_str_nice_rec m1 names othernames)) ^ " = " ^ (trm_str_nice_paren 502 (trm_str_nice_rec m2 names othernames)),502)
  | Ap(Ap(Imp,Ap(Ap(Eq(_),m1),m2)),False) ->
      if binderp m1 then (*** to properly use 'binderish' I would need a separate 'layout' type; I'll use binderp instead and hope it's OK ***)
	((trm_str_nice_paren (-1) (trm_str_nice_rec m1 names othernames)) ^ " <> " ^ (trm_str_nice_paren 502 (trm_str_nice_rec m2 names othernames)),502)
      else
	((trm_str_nice_paren 502 (trm_str_nice_rec m1 names othernames)) ^ " <> " ^ (trm_str_nice_paren 502 (trm_str_nice_rec m2 names othernames)),502)
  | Ap(Ap(Imp,m1),False) ->
      ("~" ^ (trm_str_nice_paren 701 (trm_str_nice_rec m1 names othernames)),701)
  | Ap(Ap(Imp,m1),m2) ->
      if binderp m1 then (*** to properly use 'binderish' I would need a separate 'layout' type; I'll use binderp instead and hope it's OK ***)
	((trm_str_nice_paren (-1) (trm_str_nice_rec m1 names othernames)) ^ " -> " ^ (trm_str_nice_paren 801 (trm_str_nice_rec m2 names othernames)),800)
      else
	((trm_str_nice_paren 800 (trm_str_nice_rec m1 names othernames)) ^ " -> " ^ (trm_str_nice_paren 801 (trm_str_nice_rec m2 names othernames)),800)
  | Ap(Forall(a),Lam(_,m1)) ->
      let x = next_var_name a names othernames in
      ("!" ^ x ^ ":" ^ (stp_str a) ^ "." ^ (trm_str_nice_paren 1010 (trm_str_nice_rec m1 (x::names) othernames)),1)
  | Ap(m1,m2) ->
      if binderp m1 then (*** to properly use 'binderish' I would need a separate 'layout' type; I'll use binderp instead and hope it's OK ***)
	((trm_str_nice_paren (-1) (trm_str_nice_rec m1 names othernames)) ^ " " ^ (trm_str_nice_paren 0 (trm_str_nice_rec m2 names othernames)),1)
      else
	((trm_str_nice_paren 1 (trm_str_nice_rec m1 names othernames)) ^ " " ^ (trm_str_nice_paren 0 (trm_str_nice_rec m2 names othernames)),1)
(*** If logic has not been normalized away ***)
  | True -> ("True",0)
  | Neg -> ("not",0)
  | Or -> ("or",0)
  | And -> ("and",0)
  | Iff -> ("iff",0)
  | Exists(_) -> ("Sigma",0)

let trm_str_nice m =
  let nl = List.map (fun (x,_) -> x) (consts_of_trm [] m) in
  let (s,_) = trm_str_nice_rec m [] nl in
  s

(** Jan/Feb 2022 using Cezary Kaliszyk's ftm representation **)
(** ftm functions **)
open Ftm

type typ_f = ST of stp | DT of ftm

let is_dt a =
  match a with
  | ST(_) -> false
  | DT(_) -> true

let ty_f ty = ty and ty_f_rev ty = ty;;
(*
let ty_no_h=(Hashtbl.create 1000 : (stp, int) Hashtbl.t);;
let no_ty_h=(Hashtbl.create 1000 : (int, stp) Hashtbl.t);;
let ty_num=ref 0;;

let ty_f ty =
  try Hashtbl.find ty_no_h ty
  with Not_found ->
    incr ty_num;
    Hashtbl.add ty_no_h ty !ty_num;
    Hashtbl.add no_ty_h !ty_num ty;
    !ty_num
and ty_f_rev = Hashtbl.find no_ty_h;;
*)

let name_no_h=(Hashtbl.create 1000 : (string, int) Hashtbl.t);;
let no_name_h=(Hashtbl.create 1000 : (int, string) Hashtbl.t);;
let name_num=ref 0;;

let name_no name =
  try Hashtbl.find name_no_h name
  with Not_found ->
    incr name_num;
    Hashtbl.add name_no_h name !name_num;
    Hashtbl.add no_name_h !name_num name;
    !name_num
and name_no_rev = Hashtbl.find no_name_h;;

let mk_neg t = mk_norm_imp t mk_false
let fneg t = mk_neg t

let rec trm_ftm d m =
  match m with
  | Name(x,_) -> (* drop the type for the ftrm rep *)
     begin
       let xn = name_no x in
       try
         Hashtbl.find d xn
       with Not_found -> mk_name xn
     end
  | DName(x,_) -> (* drop the type for the ftrm rep *)
     begin
       let xn = name_no x in
       try
         Hashtbl.find d xn
       with Not_found -> mk_name xn
     end
  | DB(i,_) -> mk_db i (* drop the type for the ftrm rep *)
  | Lam(a,m1) -> mk_norm_lam (ty_f a) (trm_ftm d m1)
  | DLam(m1,m2) -> mk_norm_dlam (trm_ftm d m1) (trm_ftm d m2)
  | DPi(m1,m2) -> mk_dpi (trm_ftm d m1) (trm_ftm d m2)
  | False -> mk_false
  | Ap(Ap(Imp,m1),m2) -> mk_norm_imp (trm_ftm d m1) (trm_ftm d m2)
  | Ap(Forall(a),m1) -> mk_all (ty_f a) (trm_ftm d (gen_lam_body a m1))
  | Ap(DForall(m1),m2) -> mk_dall (trm_ftm d m1) (trm_ftm d (gen_lam_body dtp_tp m2))
  | Choice(a) -> mk_choice (ty_f a)
  | Ap(Ap(Eq(a),m1),m2) -> mk_norm_eq (ty_f a) (trm_ftm d m1) (trm_ftm d m2)
  | Ap(Ap(DEq(n),m1),m2) -> mk_norm_deq (trm_ftm d n) (trm_ftm d m1) (trm_ftm d m2)
  | Ap(Ap(Iff,m1),m2) -> mk_norm_eq (ty_f mk_prop) (trm_ftm d m1) (trm_ftm d m2)
  | Imp -> trm_ftm d (Lam(mk_prop,Lam(mk_prop,Ap(Ap(Imp,DB(1,mk_prop)),DB(0,mk_prop)))))
  | Forall(a) -> trm_ftm d (Lam(mk_ar a mk_prop,Ap(Forall(a),DB(0,mk_ar a mk_prop))))
  | DForall(m1) -> trm_ftm d (DLam(DPi(m1,prop_trm),Ap(DForall(m1),DB(0,dtp_tp))))
  | Eq(a) -> trm_ftm d (Lam(a,Lam(a,Ap(Ap(Eq(a),DB(1,a)),DB(0,a)))))
  | DEq(m1) -> trm_ftm d (DLam(m1,DLam(m1,Ap(Ap(DEq(m1),DB(1,dtp_tp)),DB(0,dtp_tp)))))
  | Iff -> trm_ftm d (Lam(mk_prop,Lam(mk_prop,Ap(Ap(Eq(mk_prop),DB(1,mk_prop)),DB(0,mk_prop)))))
  | True -> trm_ftm d (Ap(Ap(Imp,False),False))
  | Ap(Neg,m1) -> trm_ftm_neg d m1
  | Neg -> trm_ftm d (Lam(mk_prop,Ap(Neg,DB(0,mk_prop))))
  | Ap(Exists(a),Lam(_,m1)) -> trm_ftm_neg d (Ap(Forall(a),Lam(a,Ap(Neg,m1))))
  | Ap(DExists(m1),Lam(_,m2)) -> trm_ftm_neg d (Ap(DForall(m1),DLam(m1,Ap(Neg,m2))))
  | Exists(a) -> trm_ftm d (Lam(mk_ar a mk_prop,Ap(Neg,Ap(Forall(a),Lam(a,Ap(Neg,Ap(DB(1,mk_ar a mk_prop),DB(0,a))))))))
  | DExists(m1) -> trm_ftm d (DLam(DPi(m1,prop_trm),Ap(Neg,Ap(DForall(m1),DLam(m1,Ap(Neg,Ap(DB(1,dtp_tp),DB(0,dtp_tp))))))))
  | Ap(Ap(Or,m1),m2) -> mk_norm_imp (trm_ftm_neg d m1) (trm_ftm d m2)
  | Ap(Ap(And,m1),m2) -> trm_ftm_neg d (Ap(Ap(Imp,m1),Ap(Ap(Imp,m2),False)))
  | Or -> trm_ftm d (Lam(mk_prop,Lam(mk_prop,Ap(Ap(Imp,Ap(Ap(Imp,DB(1,mk_prop)),False)),DB(0,mk_prop)))))
  | And -> trm_ftm d (Lam(mk_prop,Lam(mk_prop,Ap(Ap(Imp,Ap(Ap(Imp,DB(1,mk_prop)),Ap(Ap(Imp,DB(0,mk_prop)),False))),False))))
  | Ap(m1,m2) -> mk_norm_ap (trm_ftm d m1) (trm_ftm d m2)
  | DOf(m1,m2) -> mk_dof (trm_ftm d m1) (trm_ftm d m2)
and trm_ftm_neg d m = fneg(trm_ftm d m);;

let rec ftm_trm get_name_tp cx m =
  let maincases m =
    match get_tag m with
    | FT_DB -> let i = get_no m in DB(i,List.nth cx i)
    | FT_Name ->
       begin
       let x = get_no m in
       let x2 = name_no_rev x in
         match get_name_tp x with
         | (STp(a)) -> Name(x2,ty_f_rev a)
         | (DTp(m1)) -> DName(x2,m1)
       end
    | FT_Ap -> let m1 = get_l m in let m2 = get_r m in Ap(ftm_trm get_name_tp cx m1,ftm_trm get_name_tp cx m2)
    | FT_Lam -> let a = get_no m in let m1 = get_l m in let a2 = ty_f_rev a in Lam(a2,ftm_trm get_name_tp (a2::cx) m1)
    | FT_Imp -> let m1 = get_l m in let m2 = get_r m in Ap(Ap(Imp,ftm_trm get_name_tp cx m1),ftm_trm get_name_tp cx m2)
    | FT_All -> let a = get_no m in let m1 = get_l m in let a2 = ty_f_rev a in Ap(Forall(a2),Lam(a2,ftm_trm get_name_tp (a2::cx) m1))
    | FT_False -> False
    | FT_Choice -> let a = get_no m in Choice(ty_f_rev a)
    | FT_Eq -> let a = get_no m in let m1 = get_l m in let m2 = get_r m in Ap(Ap(Eq(ty_f_rev a),ftm_trm get_name_tp cx m1),ftm_trm get_name_tp cx m2)
    | FT_DLam -> let m1 = ftm_trm get_name_tp cx (get_dtp m) in let m2 = get_l m in DLam(m1,ftm_trm get_name_tp (dtp_tp::cx) m2)
    | FT_DPi -> let m1 = ftm_trm get_name_tp cx (get_l m) in let m2 = get_r m in DPi(m1,ftm_trm get_name_tp (dtp_tp::cx) m2)
    | FT_DAll -> let m1 = ftm_trm get_name_tp cx (get_dtp m) in let m2 = get_l m in Ap(DForall(m1),DLam(m1,ftm_trm get_name_tp (dtp_tp::cx) m2))
    | FT_None -> raise (Failure "FT_None")
    | FT_DEq -> let n = ftm_trm get_name_tp cx (get_dtp m) in let m1 = get_l m in let m2 = get_r m in Ap(Ap(DEq(n),ftm_trm get_name_tp cx m1),ftm_trm get_name_tp cx m2)
    | FT_DOf -> let m1 = get_l m in let m2 = get_r m in DOf(ftm_trm get_name_tp cx m1,ftm_trm get_name_tp cx m2)
  in
  (** get rid of double negations because proof reconstruction expects it **)
  if get_isneg m then Ap(Ap(Imp,maincases (get_nonnegated m)), False) else maincases m

let rec ftm_trm_2 name_tp cx m =
  let maincases m =
    match get_tag m with
    | FT_DB -> let i = get_no m in DB(i,List.nth cx i)
    | FT_Name -> let x = get_no m in let x2 = name_no_rev x in Name(x2,ty_f_rev (Hashtbl.find name_tp x))
    | FT_Ap -> let m1 = get_l m in let m2 = get_r m in Ap(ftm_trm_2 name_tp cx m1,ftm_trm_2 name_tp cx m2)
    | FT_Lam -> let a = get_no m in let m1 = get_l m in let a2 = ty_f_rev a in Lam(a2,ftm_trm_2 name_tp (a2::cx) m1)
    | FT_Imp -> let m1 = get_l m in let m2 = get_r m in Ap(Ap(Imp,ftm_trm_2 name_tp cx m1),ftm_trm_2 name_tp cx m2)
    | FT_All -> let a = get_no m in let m1 = get_l m in let a2 = ty_f_rev a in Ap(Forall(a2),Lam(a2,ftm_trm_2 name_tp (a2::cx) m1))
    | FT_False -> False
    | FT_Choice -> let a = get_no m in Choice(ty_f_rev a)
    | FT_Eq -> let a = get_no m in let m1 = get_l m in let m2 = get_r m in Ap(Ap(Eq(ty_f_rev a),ftm_trm_2 name_tp cx m1),ftm_trm_2 name_tp cx m2)
    | FT_None -> raise (Failure "FT_None")
    | _ -> raise (Failure "ftm_trm2 only supports simple types")
  in
  (** get rid of double negations because proof reconstruction expects it **)
  if get_isneg m then Ap(Ap(Imp,maincases (get_nonnegated m)), False) else maincases m

let ftm_db_p i m =
  match get_tag m with
  | FT_DB -> get_no m = i
  | _ -> false

let rec ftm_str m =
  match get_tag m with
  | FT_DB -> let i = get_no m in Printf.sprintf "?%d" i
  | FT_Name -> let x = get_no m in Printf.sprintf "\"%s\"" (name_no_rev x)
  | FT_Ap -> let m1 = get_l m in let m2 = get_r m in Printf.sprintf "(Ap %s %s)" (ftm_str m1) (ftm_str m2)
  | FT_Lam -> let m1 = get_l m in Printf.sprintf "(Lam %s)" (ftm_str m1)
  | FT_Imp -> let m1 = get_l m in let m2 = get_r m in Printf.sprintf "(Imp %s %s)" (ftm_str m1) (ftm_str m2)
  | FT_All -> let m1 = get_l m in Printf.sprintf "(All %s)" (ftm_str m1)
  | FT_False -> "(False)"
  | FT_Choice -> let a = get_no m in Printf.sprintf "(Choice %d)" a
  | FT_Eq -> let m1 = get_l m in let m2 = get_r m in Printf.sprintf "(Eq %s %s)" (ftm_str m1) (ftm_str m2)
  | FT_DLam -> let m1 = get_dtp m in let m2 = get_l m in Printf.sprintf "(DLam%s. %s)" (ftm_str m1) (ftm_str m2)
  | FT_DPi -> let m1 = get_l m in let m2 = get_r m in Printf.sprintf "(DPi%s. %s)" (ftm_str m1) (ftm_str m2)
  | FT_DAll -> let m1 = get_dtp m in let m2 = get_l m in Printf.sprintf "(DAll%s. %s)" (ftm_str m1) (ftm_str m2)
  | FT_DEq -> let n = get_dtp m in let m1 = get_l m in let m2 = get_r m in Printf.sprintf "(DEq%s %s %s)" (ftm_str n) (ftm_str m1) (ftm_str m2)
  | FT_DOf -> let m1 = get_l m in let m2 = get_r m in Printf.sprintf "(DOf %s %s)" (ftm_str m1) (ftm_str m2)
  | _ -> "?"

(* Erasure from DHOL to HOL from RRB *)

let rec stp_of_dtp_f m =
  match get_tag m with
  | FT_Name ->
     begin
       let xn = get_no m in
       match name_no_rev xn with
       | "_bool" -> Some(mk_prop)
       | "_ind" -> Some(mk_base tyname_dollar_i)
       | x -> Some(mk_base (basename_no x))
     end
  | FT_DPi ->
     begin
       match stp_of_dtp_f (get_l m) with
       | Some(m1) ->
          begin
            match stp_of_dtp_f (get_r m) with
            | Some(m2) -> Some(mk_ar m1 m2)
            | None -> None
          end
       | None -> None
     end
  | _ -> None

let rec erase_dtp_aux b m =
  match m with
  | Ap(m1,_) -> erase_dtp_aux false m1
  | DName(x,_) ->
     begin
       match x with
       | "_bool" -> mk_prop
       | "_ind" -> mk_base tyname_dollar_i
       | _ -> mk_base (if b then (basename_no x) else basename_no (x ^ "_0"))
     end
  | DPi(m1,m2) -> mk_ar (erase_dtp m1) (erase_dtp m2)
  | _ -> raise (Failure "erase_dtp called on non-dtp")
and erase_dtp m = erase_dtp_aux true m

let rec erase_dtp_aux_f b m =
  match get_tag m with
  | FT_Ap -> let m1 = get_l m in erase_dtp_aux_f false m1
  | FT_Name ->
     begin
       let xn = get_no m in
       match name_no_rev xn with
       | "_bool" -> mk_prop
       | "_ind" -> mk_base tyname_dollar_i
       | x -> mk_base (basename_no (if b then x else x ^ "_0"))
     end
  | FT_DPi -> let m1 = get_l m in let m2 = get_r m in mk_ar (erase_dtp_f m1) (erase_dtp_f m2)
  | _ -> raise (Failure "erase_dtp_f called on non-dtp")

and erase_dtp_f m = erase_dtp_aux_f true m

let rec dpi_get_erased_types_list m =
  match m with
  | DPi(m1,m2) -> erase_dtp m1 :: dpi_get_erased_types_list m2
  | _ -> []

let rec dpi_get_erased_types_list_f m =
  match get_tag m with
  | FT_DPi -> let m1 = get_l m in let m2 = get_r m in erase_dtp_f m1 :: dpi_get_erased_types_list_f m2
  | _ -> []

let rec stp_of_per l a =
  match l with
  | (a1::ll) -> mk_ar a1 (stp_of_per ll a)
  | [] -> mk_ar a (mk_ar a mk_prop)

let rec is_type_constructor_type m =
  match m with
  | Name(x,_) -> x = "_type"
  | DPi(m1,m2) -> is_type_constructor_type m2
  | _ -> false

let rec is_type_constructor_type_f m =
  match get_tag m with
  | FT_Name -> get_no m = name_no "_type"
  | FT_DPi ->
     let m2 = get_r m in
     is_type_constructor_type_f m2
  | _ -> false

let rec mk_per_base get_name_tp hol_base m s t =
  match get_tag m with
  | FT_Ap -> let m1 = get_l m in let m2 = get_r m in mk_norm_ap (mk_per_base get_name_tp false m1 m2 s) t
  | FT_Name ->
     begin
       let xn = get_no m in
       match name_no_rev xn with
       | "_bool" -> mk_norm_eq mk_prop (ftm_to_hol get_name_tp s) (ftm_to_hol get_name_tp t)
       | "_ind" -> mk_norm_eq (mk_base tyname_dollar_i) (ftm_to_hol get_name_tp s) (ftm_to_hol get_name_tp t)
       | x -> if hol_base then mk_norm_eq (mk_base (basename_no x)) (ftm_to_hol get_name_tp s) (ftm_to_hol get_name_tp t)
              else mk_norm_ap (mk_norm_ap (mk_name (name_no (x ^ "_*"))) s) t
     end
  | _ -> raise (Failure "mk_per called on non-dtp")
and mk_per_dpi get_name_tp m s t =
  match get_tag m with
  | FT_Ap -> mk_per_base get_name_tp false m s t
  | FT_Name -> mk_per_base get_name_tp true m s t
  | FT_DPi ->
     begin
       let m1 = get_l m in
       let m2 = get_r m in
       let a = erase_dtp_f m1 in
       match get_tag m1 with
       | FT_Name ->
          (* easier handling of real simple base types *)
          let x = mk_db 0 in
          let m2_star_ap = mk_per_dpi get_name_tp  m2 (mk_norm_ap (uptrm s 0 1) x) (mk_norm_ap (uptrm t 0 1) x) in
          mk_all (ty_f a) m2_star_ap
       | _ ->
          let x = mk_db 1 in
          let y = mk_db 0 in
          let m1_star_ap = mk_per_dpi get_name_tp (uptrm m1 0 2) x y in
          let m2_star_ap = mk_per_dpi get_name_tp (uptrm m2 0 1) (mk_norm_ap (uptrm s 0 2) x) (mk_norm_ap (uptrm t 0 2) y) in
          mk_all (ty_f a) (mk_all (ty_f a) (mk_norm_imp m1_star_ap m2_star_ap))
     end
  | _ -> raise (Failure "mk_per called on non-dtp")
and mk_per get_name_tp m s t = mk_per_dpi get_name_tp m s t
and ftm_to_hol get_name_tp m = (* full translation to hol *)
  match get_tag m with
  | FT_Name ->
     begin
       let xn = get_no m in
       match get_name_tp (get_no m) with
       | DTp(_) ->
          let x = name_no_rev xn in
          let x0 = x ^ "_0" in
          let x0n = name_no x0 in
          mk_name x0n
       | _ -> m
     end
  | FT_Ap ->
     let m1 = get_l m in
     let m2 = get_r m in
     mk_norm_ap (ftm_to_hol get_name_tp m1) (ftm_to_hol get_name_tp m2)
  | FT_Lam ->
     let a = get_no m in
     let m1 = get_l m in
     mk_norm_lam a (ftm_to_hol get_name_tp m1)
  | FT_Imp ->
     let m1 = get_l m in
     let m2 = get_r m in
     mk_norm_imp (ftm_to_hol get_name_tp m1) (ftm_to_hol get_name_tp m2)
  | FT_All ->
     let a = get_no m in
     let m1 = get_l m in
     mk_all a (ftm_to_hol get_name_tp m1)
  | FT_Eq ->
     let a = get_no m in
     let m1 = get_l m in
     let m2 = get_r m in
     mk_norm_eq a (ftm_to_hol get_name_tp m1) (ftm_to_hol get_name_tp m2)
  | FT_DLam ->
     let dtp = get_dtp m in
     let m1 = get_l m in
     mk_norm_lam (erase_dtp_f dtp) (ftm_to_hol get_name_tp m1)
  | FT_DAll ->
     let dtp = get_dtp m in
     let m1 = get_l m in
     mk_all (erase_dtp_f dtp) (mk_norm_imp (mk_per get_name_tp dtp (mk_db 0) (mk_db 0)) (ftm_to_hol get_name_tp m1))
  | FT_DEq ->
     let dtp = get_dtp m in
     let m1 = get_l m in
     let m2 = get_r m in
     mk_per get_name_tp dtp (ftm_to_hol get_name_tp m1) (ftm_to_hol get_name_tp m2)
  | FT_DPi -> raise (Failure "ftm_to_hol called on DPi")
  | _ -> m

let rec mk_alls stpl m =
  match stpl with
  | (a::stpl') -> mk_all a (mk_alls stpl' m)
  | [] -> m

let rec mk_db_ap m i =
  if i = 0 then m else mk_db_ap (mk_norm_ap m (mk_db (i-1))) (i-1)

let mk_per_ax stpl a per_name =
  let m = mk_db_ap (mk_name per_name) (List.length stpl + 2) in
  mk_alls stpl (mk_all a (mk_all a (mk_norm_imp m (mk_norm_eq a (mk_db 1) (mk_db 0)))))

let mk_per_sym_ax stpl a per_name =
  let m = mk_db_ap (mk_name per_name) (List.length stpl) in
  let x = mk_db 1 in
  let y = mk_db 0 in
  mk_alls stpl (mk_all a (mk_all a (mk_norm_imp (mk_norm_ap (mk_norm_ap m x) y) (mk_norm_ap (mk_norm_ap m y) x))))

let mk_per_trans_ax stpl a per_name =
  let m = mk_db_ap (mk_name per_name) (List.length stpl) in
  let x = mk_db 2 in
  let y = mk_db 1 in
  let z = mk_db 0 in
  mk_alls stpl (mk_all a (mk_all a (mk_all a (mk_norm_imp (mk_norm_ap (mk_norm_ap m x) y) (mk_norm_imp (mk_norm_ap (mk_norm_ap m y) z) (mk_norm_ap (mk_norm_ap m x) z))))))

let rec mk_in_per_ax c a per_name =
  let cname = (mk_name c) in
  mk_norm_ap (mk_norm_ap (mk_name per_name) cname) cname

(* end DHOL to HOL erasure *)

type fctx = (int * int) list

(*Lists the base types referenced in a term.
  NOTE the resulting list doesn't contain duplicate elements.*)
let rec base_types_of_trm_f acc (m : ftm) : int list =
  match get_tag m with
  | FT_Lam ->
     let a = get_no m in
     let trm = get_l m in
     let acc' = base_types acc (ty_f_rev a) in
     base_types_of_trm_f acc' trm
  | FT_All ->
     let a = get_no m in
     let trm = get_l m in
     let acc' = base_types acc (ty_f_rev a) in
     base_types_of_trm_f acc' trm
  | FT_Ap ->
     let trm1 = get_l m in
     let trm2 = get_r m in
     let acc' = base_types_of_trm_f acc trm1
     in base_types_of_trm_f acc' trm2
  | FT_Imp ->
     let trm1 = get_l m in
     let trm2 = get_r m in
     let acc' = base_types_of_trm_f acc trm1
     in base_types_of_trm_f acc' trm2
  | FT_Eq ->
     (*let a = get_no m in*)
     let trm1 = get_l m in
     let trm2 = get_r m in
     let acc' = base_types_of_trm_f acc trm1
     in base_types_of_trm_f acc' trm2
  | _ -> acc

(*List the constants that occur in a term, as name-type pairs.
  NOTE the resulting list doesn't contain duplicate constants.*)
let rec consts_of_ftm nh (acc:fctx) (m : ftm) : fctx =
  match get_tag m with
  | FT_Name ->
     let name = get_no m in
     begin
       try
         ignore (List.assoc name acc);
         acc
       with Not_found ->
         (name, Hashtbl.find nh name) :: acc
     end
  | FT_Lam ->
     let trm = get_l m in
     consts_of_ftm nh acc trm
  | FT_All ->
     let trm = get_l m in
     consts_of_ftm nh acc trm
  | FT_Ap ->
     let trm1 = get_l m in
     let trm2 = get_r m in
     let acc' = consts_of_ftm nh acc trm1
     in consts_of_ftm nh acc' trm2
  | FT_Imp ->
     let trm1 = get_l m in
     let trm2 = get_r m in
     let acc' = consts_of_ftm nh acc trm1
     in consts_of_ftm nh acc' trm2
  | FT_Eq ->
     let trm1 = get_l m in
     let trm2 = get_r m in
     let acc' = consts_of_ftm nh acc trm1
     in consts_of_ftm nh acc' trm2
  | _ -> acc
       

let ftm_closedp m =
  let rec ftm_closedp_r j =
    if j >= 0 then
      if get_fv0 m j then
	false
      else
	ftm_closedp_r (j-1)
    else
      true
  in
  ftm_closedp_r (get_maxv m)
