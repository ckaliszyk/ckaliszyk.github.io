val verbosity : int ref
