for FILE in rrb_dhol_format/*
do
    $1embedproblem "$FILE" > translated/$(basename "$FILE")
done


