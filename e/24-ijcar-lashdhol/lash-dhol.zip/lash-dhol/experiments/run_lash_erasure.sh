echo === list-app-nil-indinst.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil-indinst.p
echo === list-app-nil-indinst.p ===
$1lash -t 60 -M ../modes -m dhol_mode_1 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil-indinst.p
echo === list-app-nil-base.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2xfee4 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil-base.p
echo === list-app-nil-base.p ===
$1lash -t 60 -M ../modes -m cade22grackle2xfee4 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil-base.p
echo === list-app-nil-indstep.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2xfee4 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil-indstep.p
echo === list-app-nil-indstep.p ===
$1lash -t 60 -M ../modes -m dhol_mode_2 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil-indstep.p
echo === list-app-nil.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_32 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil.p
echo === list-app-nil.p ===
$1lash -t 60 -M ../modes -m dhol_mode_3 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-nil.p
echo === list-app-assoc-indinst.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2xfee4 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indinst.p
echo === list-app-assoc-indinst.p ===
$1lash -t 60 -M ../modes -m dhol_mode_11 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indinst.p
echo === list-app-assoc-base.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_26 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-base.p
echo === list-app-assoc-base.p ===
$1lash -t 60 -M ../modes -m dhol_mode_4 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-base.p
echo === list-app-assoc-indstep1.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep1.p
echo === list-app-assoc-indstep1.p ===
$1lash -t 60 -M ../modes -m dhol_mode_5 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep1.p
echo === list-app-assoc-indstep2.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep2.p
echo === list-app-assoc-indstep2.p ===
$1lash -t 60 -M ../modes -m dhol_mode_6 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep2.p
echo === list-app-assoc-indstep3.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep3.p
echo === list-app-assoc-indstep3.p ===
$1lash -t 60 -M ../modes -m dhol_mode_7 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep3.p
echo === list-app-assoc-indstep4.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep4.p
echo === list-app-assoc-indstep4.p ===
$1lash -t 60 -M ../modes -m dhol_mode_7 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep4.p
echo === list-app-assoc-indstep5.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_30 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep5.p
echo === list-app-assoc-indstep5.p ===
$1lash -t 60 -M ../modes -m dhol_mode_8 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-indstep5.p
echo === list-app-assoc.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_28 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc.p
echo === list-app-assoc.p ===
$1lash -t 60 -M ../modes -m dhol_mode_19 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc.p
echo === list-app-assoc-m1-step1.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step1.p
echo === list-app-assoc-m1-step1.p ===
$1lash -t 60 -M ../modes -m dhol_mode_13 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step1.p
echo === list-app-assoc-m1-step2.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step2.p
echo === list-app-assoc-m1-step2.p ===
$1lash -t 60 -M ../modes -m dhol_mode_9 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step2.p
echo === list-app-assoc-m1-step3.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step3.p
echo === list-app-assoc-m1-step3.p ===
$1lash -t 60 -M ../modes -m dhol_mode_10 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step3.p
echo === list-app-assoc-m1-step4.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step4.p
echo === list-app-assoc-m1-step4.p ===
$1lash -t 60 -M ../modes -m dhol_mode_18 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step4.p
echo === list-app-assoc-m1-step5.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step5.p
echo === list-app-assoc-m1-step5.p ===
$1lash -t 60 -M ../modes -m dhol_mode_20 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-app-assoc-m1-step5.p
echo === list-rev-invol-lem-indinst.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indinst.p
echo === list-rev-invol-lem-indinst.p ===
$1lash -t 60 -M ../modes -m dhol_mode_11 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indinst.p
echo === list-rev-invol-lem-base-step1.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-base-step1.p
echo === list-rev-invol-lem-base-step1.p ===
$1lash -t 60 -M ../modes -m dhol_mode_12 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-base-step1.p
echo === list-rev-invol-lem-base-step2.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-base-step2.p
echo === list-rev-invol-lem-base-step2.p ===
$1lash -t 60 -M ../modes -m dhol_mode_13 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-base-step2.p
echo === list-rev-invol-lem-base-step3.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-base-step3.p
echo === list-rev-invol-lem-base-step3.p ===
$1lash -t 60 -M ../modes -m dhol_mode_14 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-base-step3.p
echo === list-rev-invol-lem-indstep1.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep1.p
echo === list-rev-invol-lem-indstep1.p ===
$1lash -t 60 -M ../modes -m dhol_mode_19 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep1.p
echo === list-rev-invol-lem-indstep2.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep2.p
echo === list-rev-invol-lem-indstep2.p ===
$1lash -t 60 -M ../modes -m dhol_mode_15 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep2.p
echo === list-rev-invol-lem-indstep3.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep3.p
echo === list-rev-invol-lem-indstep3.p ===
$1lash -t 60 -M ../modes -m dhol_mode_16 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep3.p
echo === list-rev-invol-lem-indstep4.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep4.p
echo === list-rev-invol-lem-indstep4.p ===
$1lash -t 60 -M ../modes -m dhol_mode_22 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep4.p
echo === list-rev-invol-lem-indstep5.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep5.p
echo === list-rev-invol-lem-indstep5.p ===
$1lash -t 60 -M ../modes -m dhol_mode_16 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep5.p
echo === list-rev-invol-lem-indstep6.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep6.p
echo === list-rev-invol-lem-indstep6.p ===
$1lash -t 60 -M ../modes -m dhol_mode_18 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep6.p
echo === list-rev-invol-lem-indstep7.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_29 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep7.p
echo === list-rev-invol-lem-indstep7.p ===
$1lash -t 60 -M ../modes -m dhol_mode_19 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem-indstep7.p
echo === list-rev-invol-lem.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_31 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem.p
echo === list-rev-invol-lem.p ===
$1lash -t 60 -M ../modes -m dhol_mode_20 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-lem.p
echo === list-rev-invol-step1.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_31 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step1.p
echo === list-rev-invol-step1.p ===
$1lash -t 60 -M ../modes -m dhol_mode_21 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step1.p
echo === list-rev-invol-step2.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step2.p
echo === list-rev-invol-step2.p ===
$1lash -t 60 -M ../modes -m dhol_mode_22 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step2.p
echo === list-rev-invol-step3.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step3.p
echo === list-rev-invol-step3.p ===
$1lash -t 60 -M ../modes -m dhol_mode_23 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step3.p
echo === list-rev-invol-step4.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step4.p
echo === list-rev-invol-step4.p ===
$1lash -t 60 -M ../modes -m dhol_mode_24 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step4.p
echo === list-rev-invol-step5.p ===
$1lash -t 60 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step5.p
echo === list-rev-invol-step5.p ===
$1lash -t 60 -M ../modes -m dhol_mode_25 -flag DHOL_ERASURE_ONLY true -flag DHOL_RULES_ONLY false new_dhol_format/list-rev-invol-step5.p
