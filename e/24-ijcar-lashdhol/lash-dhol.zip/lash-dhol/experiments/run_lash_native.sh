echo === list-app-nil-indinst.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-nil-indinst.p
echo === list-app-nil-indinst.p ===
$1lash -t 1 -M ../modes -m dhol_mode_1 new_dhol_format/list-app-nil-indinst.p
echo === list-app-nil-base.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2xfee4 new_dhol_format/list-app-nil-base.p
echo === list-app-nil-base.p ===
$1lash -t 1 -M ../modes -m cade22grackle2xfee4 new_dhol_format/list-app-nil-base.p
echo === list-app-nil-indstep.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2xfee4 new_dhol_format/list-app-nil-indstep.p
echo === list-app-nil-indstep.p ===
$1lash -t 1 -M ../modes -m dhol_mode_2 new_dhol_format/list-app-nil-indstep.p
echo === list-app-nil.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_32 new_dhol_format/list-app-nil.p
echo === list-app-nil.p ===
$1lash -t 5 -M ../modes -m dhol_mode_3 new_dhol_format/list-app-nil.p
echo === list-app-assoc-indinst.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2xfee4 new_dhol_format/list-app-assoc-indinst.p
echo === list-app-assoc-indinst.p ===
$1lash -t 1 -M ../modes -m dhol_mode_11 new_dhol_format/list-app-assoc-indinst.p
echo === list-app-assoc-base.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_26 new_dhol_format/list-app-assoc-base.p
echo === list-app-assoc-base.p ===
$1lash -t 4 -M ../modes -m dhol_mode_4 new_dhol_format/list-app-assoc-base.p
echo === list-app-assoc-indstep1.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-indstep1.p
echo === list-app-assoc-indstep1.p ===
$1lash -t 1 -M ../modes -m dhol_mode_5 new_dhol_format/list-app-assoc-indstep1.p
echo === list-app-assoc-indstep2.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-indstep2.p
echo === list-app-assoc-indstep2.p ===
$1lash -t 1 -M ../modes -m dhol_mode_6 new_dhol_format/list-app-assoc-indstep2.p
echo === list-app-assoc-indstep3.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-indstep3.p
echo === list-app-assoc-indstep3.p ===
$1lash -t 1 -M ../modes -m dhol_mode_7 new_dhol_format/list-app-assoc-indstep3.p
echo === list-app-assoc-indstep4.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-indstep4.p
echo === list-app-assoc-indstep4.p ===
$1lash -t 1 -M ../modes -m dhol_mode_7 new_dhol_format/list-app-assoc-indstep4.p
echo === list-app-assoc-indstep5.p ===
$1lash -t 12 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_30 new_dhol_format/list-app-assoc-indstep5.p
echo === list-app-assoc-indstep5.p ===
$1lash -t 5 -M ../modes -m dhol_mode_8 new_dhol_format/list-app-assoc-indstep5.p
echo === list-app-assoc.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_28 new_dhol_format/list-app-assoc.p
echo === list-app-assoc.p ===
$1lash -t 3 -M ../modes -m dhol_mode_19 new_dhol_format/list-app-assoc.p
echo === list-app-assoc-m1-step1.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-m1-step1.p
echo === list-app-assoc-m1-step1.p ===
$1lash -t 1 -M ../modes -m dhol_mode_13 new_dhol_format/list-app-assoc-m1-step1.p
echo === list-app-assoc-m1-step2.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-m1-step2.p
echo === list-app-assoc-m1-step2.p ===
$1lash -t 1 -M ../modes -m dhol_mode_9 new_dhol_format/list-app-assoc-m1-step2.p
echo === list-app-assoc-m1-step3.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-m1-step3.p
echo === list-app-assoc-m1-step3.p ===
$1lash -t 1 -M ../modes -m dhol_mode_10 new_dhol_format/list-app-assoc-m1-step3.p
echo === list-app-assoc-m1-step4.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-m1-step4.p
echo === list-app-assoc-m1-step4.p ===
$1lash -t 1 -M ../modes -m dhol_mode_18 new_dhol_format/list-app-assoc-m1-step4.p
echo === list-app-assoc-m1-step5.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-app-assoc-m1-step5.p
echo === list-app-assoc-m1-step5.p ===
$1lash -t 1 -M ../modes -m dhol_mode_20 new_dhol_format/list-app-assoc-m1-step5.p
echo === list-rev-invol-lem-indinst.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indinst.p
echo === list-rev-invol-lem-indinst.p ===
$1lash -t 1 -M ../modes -m dhol_mode_11 new_dhol_format/list-rev-invol-lem-indinst.p
echo === list-rev-invol-lem-base-step1.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-base-step1.p
echo === list-rev-invol-lem-base-step1.p ===
$1lash -t 20 -M ../modes -m dhol_mode_12 new_dhol_format/list-rev-invol-lem-base-step1.p
echo === list-rev-invol-lem-base-step2.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-base-step2.p
echo === list-rev-invol-lem-base-step2.p ===
$1lash -t 1 -M ../modes -m dhol_mode_13 new_dhol_format/list-rev-invol-lem-base-step2.p
echo === list-rev-invol-lem-base-step3.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-base-step3.p
echo === list-rev-invol-lem-base-step3.p ===
$1lash -t 5 -M ../modes -m dhol_mode_14 new_dhol_format/list-rev-invol-lem-base-step3.p
echo === list-rev-invol-lem-indstep1.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indstep1.p
echo === list-rev-invol-lem-indstep1.p ===
$1lash -t 1 -M ../modes -m dhol_mode_19 new_dhol_format/list-rev-invol-lem-indstep1.p
echo === list-rev-invol-lem-indstep2.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indstep2.p
echo === list-rev-invol-lem-indstep2.p ===
$1lash -t 5 -M ../modes -m dhol_mode_15 new_dhol_format/list-rev-invol-lem-indstep2.p
echo === list-rev-invol-lem-indstep3.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indstep3.p
echo === list-rev-invol-lem-indstep3.p ===
$1lash -t 5 -M ../modes -m dhol_mode_16 new_dhol_format/list-rev-invol-lem-indstep3.p
echo === list-rev-invol-lem-indstep4.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indstep4.p
echo === list-rev-invol-lem-indstep4.p ===
$1lash -t 1 -M ../modes -m dhol_mode_22 new_dhol_format/list-rev-invol-lem-indstep4.p
echo === list-rev-invol-lem-indstep5.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indstep5.p
echo === list-rev-invol-lem-indstep5.p ===
$1lash -t 1 -M ../modes -m dhol_mode_16 new_dhol_format/list-rev-invol-lem-indstep5.p
echo === list-rev-invol-lem-indstep6.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-lem-indstep6.p
echo === list-rev-invol-lem-indstep6.p ===
$1lash -t 1 -M ../modes -m dhol_mode_18 new_dhol_format/list-rev-invol-lem-indstep6.p
echo === list-rev-invol-lem-indstep7.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_29 new_dhol_format/list-rev-invol-lem-indstep7.p
echo === list-rev-invol-lem-indstep7.p ===
$1lash -t 1 -M ../modes -m dhol_mode_19 new_dhol_format/list-rev-invol-lem-indstep7.p
echo === list-rev-invol-lem.p ===
$1lash -t 1 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_31 new_dhol_format/list-rev-invol-lem.p
echo === list-rev-invol-lem.p ===
$1lash -t 1 -M ../modes -m dhol_mode_20 new_dhol_format/list-rev-invol-lem.p
echo === list-rev-invol-step1.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m dhol_mode_31 new_dhol_format/list-rev-invol-step1.p
echo === list-rev-invol-step1.p ===
$1lash -t 5 -M ../modes -m dhol_mode_21 new_dhol_format/list-rev-invol-step1.p
echo === list-rev-invol-step2.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-step2.p
echo === list-rev-invol-step2.p ===
$1lash -t 1 -M ../modes -m dhol_mode_22 new_dhol_format/list-rev-invol-step2.p
echo === list-rev-invol-step3.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-step3.p
echo === list-rev-invol-step3.p ===
$1lash -t 5 -M ../modes -m dhol_mode_23 new_dhol_format/list-rev-invol-step3.p
echo === list-rev-invol-step4.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-step4.p
echo === list-rev-invol-step4.p ===
$1lash -t 1 -M ../modes -m dhol_mode_24 new_dhol_format/list-rev-invol-step4.p
echo === list-rev-invol-step5.p ===
$1lash -t 5 -typecheckonly -exactdholtypecheck -M ../modes -m cade22grackle2x798d new_dhol_format/list-rev-invol-step5.p
echo === list-rev-invol-step5.p ===
$1lash -t 1 -M ../modes -m dhol_mode_25 new_dhol_format/list-rev-invol-step5.p
