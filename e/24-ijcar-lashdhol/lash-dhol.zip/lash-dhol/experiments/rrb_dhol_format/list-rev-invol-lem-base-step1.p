tff(dhol, logic, $$dhol == []).
thf(elem_type,type,
    elem: $tType ).
thf(nat_type,type,
    nat: $tType ).
thf(zero_type,type,
    zero: nat ).
thf(suc_type,type,
    suc: !> [X:nat]: nat ).
thf(plus_type,type,
    plus: !> [X:nat]: (!> [Y:nat]: nat) ).
thf(list_type,type,
    list: !> [X:nat]: $tType ).
thf(nil_type,type,
    nil: list(zero) ).
thf(cons_type,type,
    cons: !> [N:nat]: (!> [X:elem]: (!> [Y:list(N)]: list(suc(N)))) ).
thf(app_type,type,
    app: !> [N:nat]: (!> [M:nat]: (!> [X:list(N)]: (!> [Y:list(M)]: list(plus(N,M))))) ).
thf(rev_type,type,
    rev: !> [N:nat]: (!> [X:list(N)]: list(N)) ).

thf(peano1,axiom,
    ! [N:nat]: ((suc @ N) != zero) ).
thf(peano2,axiom,
    ! [N:nat,M:nat]: ((N != M) => ((suc @ N) != (suc @ M))) ).
thf(peano3,axiom,
    ! [P:(!> [X:nat]: $o)]: ((P @ zero) => ((! [M:nat]: ((P @ M) => (P @ (suc @ M)))) => (! [N:nat]: (P @ N)))) ).

thf(ax1,axiom,
    ! [N:nat]: ((plus @ zero @ N) = N) ).
thf(ax2,axiom,
    ! [N:nat,M:nat]: ((plus @ (suc @ N) @ M) = (suc @ (plus @ N @ M))) ).
thf(ax3,axiom,
    ! [N:nat,X:list(N)]: ((app @ zero @ N @ nil @ X) = X) ).
thf(ax5,axiom,
    ((rev @ zero @ nil) = nil) ).

thf(plus_zero_r,axiom,(! [M:nat] : ((plus @ M @ zero) = M))).
thf(plus1r,axiom,(! [N:nat]: ((suc @ N) = (plus @ N @ (suc @ zero))))).

%thf(list_app_nil,axiom, ! [N:nat,L:list(N)]: ((app @ N @ zero @ L @ nil) = L)).

thf(list_rev_invol_lem_base_step1,conjecture, (! [M2:nat,L2:list(M2)] : ((rev @ (plus @ zero @ M2) @ (app @ zero @ M2 @ (rev @ zero @ nil) @ L2)) = (rev @ M2 @ L2)))).

