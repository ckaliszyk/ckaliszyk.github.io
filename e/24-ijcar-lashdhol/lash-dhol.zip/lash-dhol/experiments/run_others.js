const tptp = require('tptp');
const tptpClient = tptp.tptpClient;

const fs = require('fs');
const problemFileFolder = './translated/';

const provers = ['agsyHOL---','cocATP---','cvc5---','cvc5-SAT---','E---','HOLyHammer---','Isabelle---','Isabelle-HOT---','Lash---','LEO-II---','Leo-III---','Leo-III-SAT---','Nitpick---','Satallax---','TPS---','Vampire---','Zipperpin---'];

const files = fs.readdirSync(problemFileFolder);

async function runProversOnFiles() {
  for (const file of files) {
    console.log('=== ' + file + ' ===');
    var i = 0;
    for (const prover of provers) {
      const data = await tptpClient.runSystem(prover,problemFileFolder + file);
      if (data.result == 'Theorem') {
        i = i+1;
      }
      console.log(data.systemName, 'says', data.result);
    }
    console.log('[SUMMARY] ',i,'/',provers.length,' provers found a proof.');
  }
}

runProversOnFiles();
