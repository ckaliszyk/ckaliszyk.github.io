theory pre_merge_int
  imports "../mml/real_0" pre_merge_rat
begin

reserve n,m,k for Nat

mtheorem int_0_th_1:
  "(n +\<^sub>\<S>\<^sup>\<nat> k) = m implies m --R n = k"
proof(standard)
  assume A: "n +\<^sub>\<S>\<^sup>\<nat> k = m"
  hence "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m" using arytm_3_th_58 by mty auto
  then show "m--Rn = k" using rat_0_th_1 by auto
qed

mtheorem int_0_th_2:
  "n +\<^sub>\<S>\<^sup>\<nat> k = m & k = {} implies n --R m = {}"
proof
  assume A1: "n +\<^sub>\<S>\<^sup>\<nat> k = m & k = {}"
  hence "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m" using arytm_3_th_58 by mty auto
  thus "n --R m = {}" using A1 rat_0_th_2 by mty auto
qed

mtheorem int_0_th_3:
  "n +\<^sub>\<S>\<^sup>\<nat> k = m & k<>{} implies n --R m = [{},k]"
proof
  assume A1: "n +\<^sub>\<S>\<^sup>\<nat> k = m & k<>{}"
  hence "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m" using arytm_3_th_58 by mty auto
  thus "n --R m = [{},k]" using rat_0_th_3 A1 by mty auto
qed

text_raw {*\DefineSnippet{INT}{*}
mdef numbers_def_4 ("INT") where
 "func INT \<rightarrow> set equals 
     NAT\<union>[:{0\<^sub>\<S>},NAT:] \\ {[0\<^sub>\<S>,0\<^sub>\<S>]}" 
text_raw {*}%EndSnippet*}
  by auto

mtheorem 
  "cluster INT \<rightarrow> non empty"
proof
  have "{} is Nat" by mauto 
  hence "{} in NAT" using ordinal1_def_12 by auto
  then show "INT is non empty" unfolding numbers_def_4 using xboole_0_def_3 xboole_0_def_1 by mty auto
qed

mdef int_1_def_2 ("integer") where
  "attr integer for object means (\<lambda>it . it in INT)"..

mtheorem
  "cluster integer for object"
proof
  have "{} is Nat" by mauto 
  hence "{} in NAT" using ordinal1_def_12 by auto
  hence "{} in INT" unfolding numbers_def_4 using xboole_0_def_3 by mty auto
  thus "inhabited(integer \<bar> object)" using inhabited_def int_1_def_2 by auto
qed

abbreviation
  "Integer \<equiv> integer\<bar>object"

mtheorem cl_nat_int:
  "cluster natural \<rightarrow> integer for object"
proof(auto)
  fix it assume "it be natural"
  hence "it in NAT" using ordinal1_def_12 by auto
  hence "it in INT" unfolding numbers_def_4 using xboole_0_def_3 all_set by auto 
  then show "it be integer" using int_1_def_2 by auto
qed

reserve x for object 

mtheorem int_1_th_1:
  "x is Integer iff x is Nat or (ex k be Nat st k\<noteq>{} & x = [{},k])" 
proof(rule iffI3)
  show "x is Integer implies x is Nat or (ex k be Nat st k\<noteq>{} & x = [{},k])"
  proof(standard,rule disjCI2)
    assume A1: "x is Integer"  "\<not> x be Nat"
    hence "x in INT" "\<not> x in NAT" using int_1_def_2[of x] ordinal1_def_12[of x] all_set by mty auto
    hence A2: "x in [:{ {} },NAT:] & not x in { [{},{}] }" unfolding numbers_def_4 using xboole_0_def_3
       xboole_0_def_5 by mty auto
    then obtain y z where
       A3: "y in {{}} & z in NAT & x=[y,z]" using zfmisc_1_def_2 by mty auto
    hence [ty]:"z be Nat" using ordinal1_def_12 all_set by auto
    have A4: "y = {}" "not x = [{},{}]" using A2 A3 tarski_def_1 by auto
    hence "not z = {}" using A3 xtuple_0_th_1[of y z] by auto
    then show "ex k be Nat st k\<noteq>{} & x = [{},k]" using A3 A4 bexI[of _ z Nat] by auto
  qed
  assume A1: "x be Nat \<or> (\<exists>k : Nat. k \<noteq> {} \<and> x = [{} , k])"
  show "x is Integer"
  proof(cases "x be Nat")
    case True
    hence "x in NAT" using ordinal1_def_12 by auto
    hence "x in INT" unfolding  numbers_def_4 using xboole_0_def_3 by mty auto
    thus "x is Integer" using int_1_def_2 by mty auto
  next
    case False
    then obtain k where [ty]: "k be Nat" and
       A2:"k\<noteq>{} \<and> x = [{},k]" using A1 by auto
    hence "x\<noteq> [{},{}]" using xtuple_0_th_1[of "{}" "{}" "{}" k] by mty auto 
    hence A3: "not x in {[{},{}]}" using tarski_def_1 by auto
    have "{} in {{}} & k in NAT" using tarski_def_1 ordinal1_def_12[of k] by mty auto
    hence "x in [:{{}},NAT:]" using zfmisc_1_def_2 A2 by mty auto
    hence "x in [:{{}},NAT:]\\{[{},{}]}" using A3 xboole_0_def_5 by mty auto
    hence "x in INT" unfolding numbers_def_4 using xboole_0_def_3 by mty auto  
    thus "x is Integer" using int_1_def_2 by mty auto
  qed
qed


mtheorem
  mlet "n is Nat", "m is Nat"
  "cluster n --R m \<rightarrow> Integer"
proof(standard,cases "m c= n")
  case True
  then obtain k where [ty]:"k be Nat" and
    k: "n = m+\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by mty auto           
  have "n --R m = k" using int_0_th_1[of n k m,simplified] k by auto
  thus "n --R m is Integer" by mty auto
next
  case False
  hence "n in m" using ordinal1_th_12[of n m] all_set by mty auto
   then obtain k where [ty]:"k be Nat" and
    k: "k<>{} & m = n+\<^sub>\<S>\<^sup>\<nat> k" using Add_8[of m n] by mty auto           
  have "n --R m = [{},k]" using int_0_th_3[of m k n,simplified] k by auto
  hence "\<exists>k : Nat. k \<noteq> {} \<and> n --R m =\<^sub>\<S> [{} , k]" using k bexI[of _ k Nat] all_set by mty auto
  thus "n --R m is Integer" using  int_1_th_1[of "n --R m"] by mty auto
qed


mtheorem
  "cluster non natural \<rightarrow> non Element-of RAT\<^bsup>\<ge>0\<^bsub> for Integer"
proof(standard,auto)
  fix x assume [ty]: " x be integer" "\<not> x be natural" "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  then obtain k where [ty]:"k be Nat" and
            K:" k\<noteq>{} & x = [{},k]" using int_1_th_1[of x] by mty auto
  hence "x be non Element-of RAT\<^bsup>\<ge>0\<^bsub>" using arytm_3_th_33d by mty auto 
  thus False by mty auto
qed

mtheorem
  "cluster non Element-of RAT\<^bsup>\<ge>0\<^bsub> \<rightarrow> non Element-of REAL\<^bsup>\<ge>0\<^bsub> for Rat"
proof(standard,auto)
  fix x assume [ty]:"x be rational " "\<not> x be Element-of RAT\<^bsup>\<ge>0\<^bsub> " "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
            K:" k\<noteq>{} & x = [{},k]" using rat_0_th_7[of x] by mty auto
  hence "not x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto
  thus False by mty auto
qed

mtheorem pair_int:
  "k<>{} implies [{},k] is Integer"
proof
  assume "k<>{}"
  hence "ex n be Nat st n\<noteq>{} & [{},k] = [{},n]" using bexI[of _ k Nat] by mty auto
  then show "[{},k] is Integer" using int_1_th_1 by auto
qed


mtheorem
  mlet "i be Nat", "j be Nat" 
  "cluster i--Rj \<rightarrow> Integer"
proof(standard,cases "j c= i")
  case T: True
    then obtain k where TY[ty]:"k be Nat" and
      A1: "j +\<^sub>\<S>\<^sup>\<nat> k = i" using Add_9 by auto
    hence "i --R j = k" using int_0_th_1[ of i k j] T by mty auto 
    then show "i --R j be Integer"  using int_1_th_1[of k] by mty auto
  next
  case F: False
    hence "i in j" using ordinal1_th_12[of i j] by mty auto
    then obtain k where TY[ty]:"k be Nat" and
      A1: "k <> {} & i +\<^sub>\<S>\<^sup>\<nat> k = j" using Add_8 by auto
    hence A2: "i --R j = [{},k]" using int_0_th_3[of j k i] by mty auto
    have "[{},k] is Integer" using int_1_th_1[of "[{},k]"] A1 bexI[of _ k Nat] by mty auto
    then show "i --R j be Integer"  using A2 by mty auto
qed                                       

mtheorem int_rat:
  "cluster integer \<rightarrow> rational for object"
proof(standard,auto)
  fix x assume [ty]: "x be integer"
  show "x is rational"
  proof(cases "x is Nat")
    case [ty]:True
    thus "x is rational" by mty auto
  next
    case False
    then obtain k where [ty]:"k be Nat" and
      " k\<noteq>{} & x = [{},k]" using int_1_th_1[of x] by mty auto
    hence "ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k]" using bexI[of _k] by mty auto
     thus "x is rational" using rat_0_th_7 by mty auto
  qed
qed


reserve k,k1,k2 for Nat  

reserve i,j,i1,i2,i3 for Integer

mtheorem
   mlet "r be Nat", "s be Nat"
   "cluster r +\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Nat"
proof
  have "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s   " using real_0_def_4 by mauto
  hence "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using Prat_Preal_add by mauto
  hence "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^sup>\<nat> s" using arytm_3_th_58 by mauto
  thus "r +\<^sub>\<S>\<^sup>\<real> s is Nat" by mty auto
qed

theorem int_1_def_3:
  "n be Nat \<Longrightarrow> m be Nat \<Longrightarrow> n +\<^sub>\<S>\<^sup>\<real> m = n +\<^sub>\<S>\<^sup>\<nat> m"
proof-
  assume [ty]: "n be Nat " "m be Nat"
  have "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m = n +\<^sub>\<S>\<^sup>\<real> m   " using real_0_def_4 by mauto
  hence "n +\<^sub>\<S>\<^sup>\<real> m = n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m" using Prat_Preal_add by mauto
  thus "n +\<^sub>\<S>\<^sup>\<real> m = n +\<^sub>\<S>\<^sup>\<nat> m" using arytm_3_th_58 by mauto
qed

mtheorem int_1_th_4:
  "ex j st i +\<^sub>\<S>\<^sup>\<real> j = {} & j +\<^sub>\<S>\<^sup>\<real> i = {}"
proof(cases "i is Nat")
  case [ty]: True
    show "ex j st i +\<^sub>\<S>\<^sup>\<real> j = {} & j +\<^sub>\<S>\<^sup>\<real> i = {}"
    proof(cases "i={}")
      case True
      then show ?thesis using real_0_th_8 bexI[of _ "{}" Integer] by mty auto
    next case F: False
      hence [ty]:"[{} , i] be integer" using pair_int by mty auto
      hence " i +\<^sub>\<S>\<^sup>\<real> [{},i] = {} & [{},i] +\<^sub>\<S>\<^sup>\<real> i = {}" using real_0_th_9[of i,simplified] F by mty auto
      then show ?thesis using bexI[of _ "[{},i]" Integer,simplified] by auto
    qed
  next 
    case False
    then obtain k where [ty]: "k be Nat" and
      A1: "k<>{} & i=[{},k]" using int_1_th_1[of i] by mty auto
    have [ty]: "k be integer" by mty auto
    hence [ty]:"[{} , k] be integer" using pair_int A1 by mty auto
    hence " k +\<^sub>\<S>\<^sup>\<real> [{},k] = {} & [{},k] +\<^sub>\<S>\<^sup>\<real> k = {}" using real_0_th_9[of k,simplified] A1  by mty auto
    then show ?thesis using  bexI[of _ k Integer,simplified] A1 by auto
  qed

mtheorem
  mlet "r is Integer"
  "cluster -\<^sub>\<S>\<^sup>\<real> r \<rightarrow> Integer"
proof(standard,cases "r ={}")
    case True
    thus "-\<^sub>\<S>\<^sup>\<real> r is Integer" using real_0_th_18 by mty auto
  next case F: False
    show "-\<^sub>\<S>\<^sup>\<real> r is Integer"
    proof(cases "r is Nat")
      case [ty]: True
        hence [ty]: "[{},r] is integer" using pair_int F by auto
        thus ?thesis using  real_0_th_17[of r] F by mty auto
      next case False
        then obtain k where [ty]: "k be Nat"  and 
          A1:"k\<noteq>{} & r = [{},k]" using int_1_th_1[of r] by mty auto
       thus ?thesis using real_0_th_17 F by mty auto
    qed
  qed

mtheorem
  mlet "i be non natural\<bar>Integer"
  "cluster  -\<^sub>\<S>\<^sup>\<real> i \<rightarrow> natural"
proof
  obtain k where [ty]: "k be Nat" and
    A1: "k<>{} & i = [{},k]" using int_1_th_1[of i] by mty auto
  hence "(-\<^sub>\<S>\<^sup>\<real> [{},k]) = k" using real_0_th_17 by mty auto
  then show "-\<^sub>\<S>\<^sup>\<real> i is natural" using A1 by mty auto 
qed

mtheorem
   mlet "r be integer", "s be integer"
   "cluster r +\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Integer"
proof(standard, cases "r is natural")
  case [ty]:True
     hence [ty]: "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
    show "r +\<^sub>\<S>\<^sup>\<real> s is Integer"
    proof(cases "s is natural")
      case [ty]:True
      have "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^sup>\<nat> s" using int_1_def_3 by mauto
      thus "r +\<^sub>\<S>\<^sup>\<real> s is Integer" by mty auto
    next
      case [ty]:False
      hence [ty]: "not s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
      then  obtain k where [ty]: "k be Nat" and
         A1: "k<>{} & s = [{},k]" using int_1_th_1[of s] by mty auto
      hence "r +\<^sub>\<S>\<^sup>\<real> s = r --R k" using real_0_def_4[of r s,simplified] by mty auto
      thus "r +\<^sub>\<S>\<^sup>\<real> s is Integer" by mty auto
    qed
  next
 case [ty]:False
  hence [ty]: "not r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
      obtain l where [ty]: "l be Nat" and
         A2: "l<>{} & r = [{},l]" using int_1_th_1[of r] by mty auto
    show "r +\<^sub>\<S>\<^sup>\<real> s is Integer"
    proof(cases "s is natural")
      case [ty]:True
       hence "r +\<^sub>\<S>\<^sup>\<real> s = s --R l" using A2 real_0_def_4[of r s,simplified] by mty auto
       thus "r +\<^sub>\<S>\<^sup>\<real> s is Integer" by mty auto
    next
      case [ty]:False
      hence [ty]: "not s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
      then  obtain k where [ty]: "k be Nat" and
         A1: "k<>{} & s = [{},k]" using int_1_th_1[of s] by mty auto
      hence "r +\<^sub>\<S>\<^sup>\<real> s = [{}, l +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k ]" using A2 real_0_def_4[of r s,simplified] by mty auto
      hence "r +\<^sub>\<S>\<^sup>\<real> s = [{}, l +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k ]" using Prat_Preal_add by mty auto
      hence "r +\<^sub>\<S>\<^sup>\<real> s = [{}, l +\<^sub>\<S>\<^sup>\<nat> k ]" "l +\<^sub>\<S>\<^sup>\<nat> k <>{}" using arytm_3_th_58 Add_14[of k l] A1 A2 by mty auto
      thus "r +\<^sub>\<S>\<^sup>\<real> s is Integer" using bexI[of _ "l +\<^sub>\<S>\<^sup>\<nat> k" Nat] int_1_th_1 by mty auto
    qed
qed

reserve r,s,t for Integer

theorem int_1_def_5:
  "r is natural \<Longrightarrow> s is natural \<Longrightarrow> r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^sup>\<nat> s"
  "r is natural \<Longrightarrow> s is non natural\<bar>Integer \<Longrightarrow> r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s))"
  "r is non natural\<bar>Integer \<Longrightarrow> s is natural \<Longrightarrow> r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^sup>\<nat>  s)"
  "r is non natural\<bar>Integer \<Longrightarrow> s is non natural\<bar>Integer \<Longrightarrow> r *\<^sub>\<S>\<^sup>\<real> s =  (-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^sup>\<nat>  (-\<^sub>\<S>\<^sup>\<real> s)"
proof-
  assume [ty]: "r is natural " "s is natural"
   have "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = r *\<^sub>\<S>\<^sup>\<real> s   " using real_0_def_7 by mauto
  hence "r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using Prat_Preal_mult by mauto
  thus "r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^sup>\<nat> s" using arytm_3_th_59 by mauto 
next 
  assume [ty]: "r is natural" "s is  non natural\<bar>Integer"
  thus "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s))" using arytm_3_th_59 Prat_Preal_mult[of "r" "-\<^sub>\<S>\<^sup>\<real> s"] 
       real_0_def_7[of r s] by mty auto
next 
  assume [ty]: "r is  non natural\<bar>Integer" "s is natural"
  thus "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^sup>\<nat>  s)" using arytm_3_th_59 Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real> r" s] 
       real_0_def_7[of r s] by mty auto
next
  assume [ty]: "r is non natural\<bar>Integer "" s is non natural\<bar>Integer"
  show " r *\<^sub>\<S>\<^sup>\<real> s =  (-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^sup>\<nat>  (-\<^sub>\<S>\<^sup>\<real> s)"
 using arytm_3_th_59 Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real> r" "-\<^sub>\<S>\<^sup>\<real> s"] 
       real_0_def_7[of r s] by mty auto
qed


mtheorem 
  mlet "r is Integer", "s is Integer"
  "cluster r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Integer"
proof(standard, cases "r is natural")
  case [ty]:True 
  show "r *\<^sub>\<S>\<^sup>\<real> s be Integer" 
    proof(cases "s is natural")
      case [ty]:True
      hence "r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^sup>\<nat> s" using int_1_def_5[of r s] by mty auto
      thus ?thesis by mty auto
    next
      case [ty]:False
      hence "r *\<^sub>\<S>\<^sup>\<real> s =-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s))" using int_1_def_5[of r s] by mty auto
      thus ?thesis by mty auto
    qed
  next
case [ty]:False 
  show "r *\<^sub>\<S>\<^sup>\<real> s be Integer" 
    proof(cases "s is natural")
      case [ty]:True
      hence "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^sup>\<nat>  s)" using int_1_def_5[of r s] by mty auto
      thus ?thesis by mty auto
    next
      case [ty]:False
      hence "r *\<^sub>\<S>\<^sup>\<real> s =(-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^sup>\<nat>  (-\<^sub>\<S>\<^sup>\<real> s)" using int_1_def_5[of r s] by mty auto
      thus ?thesis by mty auto
    qed
  qed

mtheorem 
  mlet "r is non natural\<bar>Integer", "s is non natural\<bar>Integer"
  "cluster r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> natural" 
proof
  have "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)" using  arytm_3_th_59 Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real> r" "-\<^sub>\<S>\<^sup>\<real> s"] 
       real_0_def_7[of r s] by mty auto
  thus "r *\<^sub>\<S>\<^sup>\<real> s be natural" by mty auto
qed

mtheorem int_1_R:
  "r <>{} \<Longrightarrow>
     r is natural \<Longrightarrow>
     s is non natural \<Longrightarrow>
    r *\<^sub>\<S>\<^sup>\<real> s is non natural \<and> s *\<^sub>\<S>\<^sup>\<real> r is non natural"
proof-
  assume R: "r <>{}" and
     T[ty]: "r is natural" "s is non natural"
  have RS: "r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s) <>{}"
  proof
    assume "r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s) ={}"
    hence "-\<^sub>\<S>\<^sup>\<real> s = {}" using Mult_9 R by mauto
    hence "s = {}" "{} is natural" using real_0_th_20a[of s] real_0_th_18 by mauto
    thus False using T by mauto
  qed
  hence "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)) = [{},r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)]" using real_0_th_17 by mauto 
  hence "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)) is non natural" using RS by mauto 
  hence "r *\<^sub>\<S>\<^sup>\<real> s is non natural" using arytm_3_th_59 Prat_Preal_mult[of "r" "-\<^sub>\<S>\<^sup>\<real> s"] 
       real_0_def_7[of r s] by mauto
  thus "r *\<^sub>\<S>\<^sup>\<real> s is non natural \<and> s *\<^sub>\<S>\<^sup>\<real> r is non natural" 
    using real_0_th_21[of r s] by mauto
  
qed




mtheorem int_1_th0:
  "-\<^sub>\<S>\<^sup>\<real> k is natural implies k={} \<and> -\<^sub>\<S>\<^sup>\<real> k={}" 
proof
  assume [ty]:"-\<^sub>\<S>\<^sup>\<real> k is natural"
  thus " k={} \<and> -\<^sub>\<S>\<^sup>\<real> k={}" using rat_0_th_19[of k] by mty auto
qed

mtheorem int_1_th_20:
 "r *\<^sub>\<S>\<^sup>\<real> s = {} \<longrightarrow> r={} \<or> s={}"
proof
  assume AS: "r *\<^sub>\<S>\<^sup>\<real> s = {}"
  show "r={} \<or> s={}"
proof(cases "r is natural")
  case T1[ty]: True
  show"r={} \<or> s={}"
    proof(cases "s is natural")
      case T2[ty]: True
      hence "r*\<^sub>\<S>\<^sup>\<real> s = r*\<^sub>\<S>\<^sup>\<nat> s" 
        using arytm_3_th_59 Prat_Preal_mult[of r s] real_0_def_7[of r s] by mty auto
      then show "r={} \<or> s={}" using Mult_9[of s r] AS by mty auto
    next
      case F2[ty]:False
      hence "\<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
          hence  "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s))" using 
             arytm_3_th_59 Prat_Preal_mult[of r "-\<^sub>\<S>\<^sup>\<real> s"] 
             real_0_def_7[of r s,simplified] by mty auto
          hence "{} = r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)"  using real_0_th_20a[of "r*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)"] real_0_th_18 AS  by mty auto  
          hence "r={} or -\<^sub>\<S>\<^sup>\<real> s ={}" using  Mult_9[of _ r]  by mty auto
          thus "r={} or s ={}" using real_0_th_20a[of s] real_0_th_18  by mty auto
   qed
  next
    case F1[ty]: False
    show "r={} \<or> s={}"
        proof(cases "s is natural")
          case T2[ty]:True
            hence "r*\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^sup>\<nat> s)" using 
            arytm_3_th_59 Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real> r" s] 
             real_0_def_7[of r s,simplified] by mty auto
            hence "{} = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^sup>\<nat> s"  using real_0_th_20a[of "(-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^sup>\<nat> s"] real_0_th_18 AS  by mty auto         
            hence "s={} or -\<^sub>\<S>\<^sup>\<real> r ={}" using  Mult_9[of s "-\<^sub>\<S>\<^sup>\<real> r"] AS by mty auto
            thus "r={} or s ={}" using real_0_th_20a[of r] real_0_th_18  by mty auto          
          next
            case F2[ty]:False
               have "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> s)" using 
               arytm_3_th_59 Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real> r" "-\<^sub>\<S>\<^sup>\<real> s"] 
             real_0_def_7[of r s,simplified] by mty auto
               hence "-\<^sub>\<S>\<^sup>\<real> r={} or -\<^sub>\<S>\<^sup>\<real> s ={}" using  Mult_9[of "-\<^sub>\<S>\<^sup>\<real> s" "-\<^sub>\<S>\<^sup>\<real> r"] AS by mty auto
               hence  "-\<^sub>\<S>\<^sup>\<real> r ={} or s ={}" using real_0_th_20a[of s] real_0_th_18  by mty auto
               thus  "r ={} or s ={}" using real_0_th_20a[of r] real_0_th_18  by mty auto
    qed
  qed
qed

mtheorem int_1_th_21: 
  "r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) ={}" using real_1_th_18[of r] real_0_def_6[of r] by mty auto

mtheorem int_1_th_22: 
  "(r +\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) =s" 
proof-
  have "(r +\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = (s +\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)" using real_0_th_11[of r s] by mty auto
  hence  "(r +\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = s +\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r))" using  real_0_th_15 by mty auto
  thus ?thesis using int_1_th_21 real_0_th_8[of s] by mty auto
qed


end

