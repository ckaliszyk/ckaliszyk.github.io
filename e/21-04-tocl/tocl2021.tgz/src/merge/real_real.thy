theory real_real
  imports rat_rat funct_lam "pre_merge_arytm" "../mml/seq_2"
begin

text_raw {*\DefineSnippet{s2hseq}{*}
definition s2hseq :: "Set \<Rightarrow> (nat \<Rightarrow> rat)" ("\<ss>2\<hh>seq'(_')") where
  "\<ss>2\<hh>seq(f) =\<^sub>\<H> \<ss>2\<hh>f(s2hQ,h2sn,f)"
text_raw {*}%EndSnippet*}

theorem seqAdd:
  assumes [ty]:"x is Function-of NAT,RAT" "y is Function-of NAT,RAT"
  shows  "(\<lambda>n.(\<ss>2\<hh>seq(x))(n) +\<^sub>\<H> (\<ss>2\<hh>seq(y))(n)) =\<^sub>\<H> (\<ss>2\<hh>seq( x (+)y ))"
proof(standard)
  fix n 
  obtain h where
      [ty]:" h is Nat" and h: "h2sn(n) = h" using I2Mprop by auto
  have A: "(\<ss>2\<hh>seq(x))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x . h)" 
       "(\<ss>2\<hh>seq(y))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y . h)" 
       "(\<ss>2\<hh>seq(x (+)y))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>((x (+)y) . h)" 
    using \<ss>2\<hh>f_def[of s2hQ h2sn] s2hseq_def h by auto
  have "(x (+)y) . h = (x. h) +\<^sub>\<S>\<^sup>\<real>  (y . h)" using seq_A by mty auto      
  thus "\<ss>2\<hh>seq(x)(n) +\<^sub>\<H> \<ss>2\<hh>seq(y)(n) =\<^sub>\<H> \<ss>2\<hh>seq(x (+) y)(n)" using A RatAddM[of "y. h"
    "x. h"] by mty auto
qed

theorem seqMult:
  assumes [ty]:"x is Function-of NAT,RAT" "y is Function-of NAT,RAT"
  shows  "(\<lambda>n. (\<ss>2\<hh>seq(x))(n) *\<^sub>\<H> (\<ss>2\<hh>seq(y))(n)) =\<^sub>\<H> (\<ss>2\<hh>seq( x (*)y ))"
proof(standard)
  fix n 
  obtain h where
      [ty]:" h is Nat" and h: "h2sn(n) = h" using I2Mprop by auto
  have A: "(\<ss>2\<hh>seq(x))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x . h)" 
       "(\<ss>2\<hh>seq(y))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y . h)" 
       "(\<ss>2\<hh>seq(x (*)y))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>((x (*)y) . h)" 
    using \<ss>2\<hh>f_def[of s2hQ h2sn] s2hseq_def h by auto
  have "(x (*)y) . h = (x. h) *\<^sub>\<S>\<^sup>\<real> (y . h)" using seq_M by mty auto      
  thus "\<ss>2\<hh>seq(x)(n) *\<^sub>\<H> \<ss>2\<hh>seq(y)(n) =\<^sub>\<H> \<ss>2\<hh>seq(x (*) y)(n)" using A RatMultM[of "y. h"
    "x. h"] by mty auto
qed

theorem seqMinus:
  assumes [ty]:"x is Function-of NAT,RAT" "y is Function-of NAT,RAT"
  shows  "(\<lambda>n. (\<ss>2\<hh>seq(x))(n) -\<^sub>\<H> (\<ss>2\<hh>seq(y))(n)) =\<^sub>\<H> (\<ss>2\<hh>seq(x (-)y ))"
proof(standard)
  fix n 
  obtain h where
      [ty]:" h is Nat" and h: "h2sn(n) = h" using I2Mprop by auto
  have A: "(\<ss>2\<hh>seq(x))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x . h)" 
       "(\<ss>2\<hh>seq(y))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y . h)" 
       "(\<ss>2\<hh>seq(x (-)y))(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>((x (-)y) . h)" 
    using \<ss>2\<hh>f_def[of s2hQ h2sn] s2hseq_def h by auto
  thm seq_M
  have "(x (-)y) . h = ((x. h) -\<^sub>\<S>\<^sup>\<real> (y . h))" using seq_m by mty auto      
  thus "\<ss>2\<hh>seq(x)(n) -\<^sub>\<H> \<ss>2\<hh>seq(y)(n) =\<^sub>\<H> \<ss>2\<hh>seq(x (-) y)(n)" using A RatMM[of "y. h"
    "x. h"] by mty auto
qed

text_raw {*\DefineSnippet{MICauchy}{*}
theorem MICauchy:
  assumes "f is Function-of NAT,RAT"
  shows "f is Cauchy\<^sub>\<S> \<longleftrightarrow> Real.cauchy (\<ss>2\<hh>seq(f))"
text_raw {*}%EndSnippet*}
proof
  have [ty]: "f is Function-of NAT,RAT" using assms by auto
  assume [ty]:"f be Cauchy\<^sub>\<S>"
  show " Real.cauchy(\<ss>2\<hh>seq(f))"
  proof(rule cauchyI)
    fix r :: rat assume r: "0 < r"
    obtain sr where [ty]: "sr is Rat" and sr:"sr = \<hh>2\<ss>\<^sub>\<rat>(r)" using h2sQprop  by mty auto    
    have "{} <\<^sup>\<real> sr" using sr r Ratless Qzero by mty auto
    then obtain N where [ty]: "N be Nat  " and
        N: "for n,m be Nat st N \<subseteq> n & N \<subseteq> m holds
                    |. f . m -\<^sub>\<S>\<^sup>\<real> f . n .| <\<^sup>\<real> sr"
      using CauchyQE[THEN bspec, of f sr,simplified] by mty auto
    let ?N="\<ss>2\<hh>\<^sub>\<nat>(N)"
    show "\<exists>\<^sub>Lk. \<forall>m\<ge>k. \<forall>n\<ge>k. \<bar>\<ss>2\<hh>seq(f)(m) -\<^sub>\<H> \<ss>2\<hh>seq(f)(n)\<bar> < r" 
    proof(rule exI[of _ ?N],intro allI impI)
      fix n m      assume AS:"\<ss>2\<hh>\<^sub>\<nat>(N) \<le> m" "\<ss>2\<hh>\<^sub>\<nat>(N) \<le> n"
      have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(m) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(n) is Nat" using I2Mprop by mty auto
      have A2[ty]: "f.(h2sn(n)) is Rat" "f.(h2sn(m)) is Rat" by mty auto
      have "\<ss>2\<hh>seq(f) =\<^sub>\<H> (\<lambda>x. \<ss>2\<hh>\<^sub>\<rat>(f.(h2sn(x))))" using s2hseq_def \<ss>2\<hh>f_def by mty auto
      hence A3: "\<ss>2\<hh>seq(f)(m) -\<^sub>\<H> \<ss>2\<hh>seq(f)(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(f.(h2sn(m)) -\<^sub>\<S>\<^sup>\<real> f.(h2sn(n)))" using RatMM[OF A2] by mty auto
   
      have "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(N)) c= \<hh>2\<ss>\<^sub>\<nat>(m)" "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(N)) c= \<hh>2\<ss>\<^sub>\<nat>(n)"
        using AS less_eqI by mty auto                   
      hence "N c= \<hh>2\<ss>\<^sub>\<nat>(m)" "N c= \<hh>2\<ss>\<^sub>\<nat>(n)" using MIMprop by mty auto
      hence  "|.(f . \<hh>2\<ss>\<^sub>\<nat>(m)) -\<^sub>\<S>\<^sup>\<real> (f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| <\<^sup>\<real> sr" 
        using N[THEN bspec,THEN bspec, of "\<hh>2\<ss>\<^sub>\<nat>(n)" "\<hh>2\<ss>\<^sub>\<nat>(m)",simplified] by mty auto
     hence  "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>( |.(f . \<hh>2\<ss>\<^sub>\<nat>(m)) -\<^sub>\<S>\<^sup>\<real> (f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| )) <\<^sup>\<real> sr" 
        using MIMQprop by mty auto
      hence  "\<ss>2\<hh>\<^sub>\<rat>( |.(f . \<hh>2\<ss>\<^sub>\<nat>(m)) -\<^sub>\<S>\<^sup>\<real> (f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| ) < r" 
        using sr Ratless[of "\<ss>2\<hh>\<^sub>\<rat>( |.(f . \<hh>2\<ss>\<^sub>\<nat>(m)) -\<^sub>\<S>\<^sup>\<real> (f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| )" r] by mty auto
      hence " \<bar>\<ss>2\<hh>\<^sub>\<rat>((f . \<hh>2\<ss>\<^sub>\<nat>(m)) -\<^sub>\<S>\<^sup>\<real> (f . \<hh>2\<ss>\<^sub>\<nat>(n))) \<bar> < r"
        using rat_abs[of "(f . \<hh>2\<ss>\<^sub>\<nat>(m)) -\<^sub>\<S>\<^sup>\<real> (f . \<hh>2\<ss>\<^sub>\<nat>(n))"] by mty auto
      thus "\<bar>\<ss>2\<hh>seq(f)(m) -\<^sub>\<H> \<ss>2\<hh>seq(f)(n)\<bar> < r" using A3 by simp
    qed 
  qed
next 
  have [ty]: "f is Function-of NAT,RAT" using assms by auto
  assume AS:" Real.cauchy(\<ss>2\<hh>seq(f))"
  show "f be Cauchy\<^sub>\<S>"
  proof(standard,simp,intro ballI impI)
    fix r assume [ty]:"r be Rat" and "{}<\<^sup>\<real> r"
    hence z:"0 < \<ss>2\<hh>\<^sub>\<rat>(r)" using Ratless MIMQprop[of r] MIMQprop[of "{}"] Qzero by mty auto
    obtain k where  
       k: "\<forall>m\<ge>k. \<forall>n\<ge>k. \<bar>\<ss>2\<hh>seq(f)(m) -\<^sub>\<H> \<ss>2\<hh>seq(f)(n)\<bar> < \<ss>2\<hh>\<^sub>\<rat>(r)"
      using cauchyD[OF AS z] by mty auto
    let ?K="h2sn(k)"
    have [ty]:"?K is Nat" using I2Mprop by mty auto
    show "\<exists>N : Nat. \<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<longrightarrow> |. f . m -\<^sub>\<S>\<^sup>\<real> f . n .| <\<^sup>\<real> r"
    proof(rule bexI[of _ ?K], intro ballI impI)
      fix n m assume [ty]:"n be Nat" " m be Nat" and 
         nm: "?K \<subseteq> n \<and> ?K \<subseteq> m"
   
         have R: "h2sn(s2hn(m)) =m " "h2sn(s2hn(n)) =n " using MIMprop by mty auto
      have "\<ss>2\<hh>seq(f) =\<^sub>\<H> (\<lambda>x. \<ss>2\<hh>\<^sub>\<rat>(f.(h2sn(x))))" using s2hseq_def \<ss>2\<hh>f_def by mty auto
      hence A3: "\<ss>2\<hh>seq(f)(s2hn(m)) -\<^sub>\<H> \<ss>2\<hh>seq(f)(s2hn(n)) =\<^sub>\<H> 
        \<ss>2\<hh>\<^sub>\<rat>((f. m) -\<^sub>\<S>\<^sup>\<real> (f. n))" using RatMM[of "f. n" "f. m"] R by mty auto
      have  "k \<le> s2hn(n)" "k \<le> s2hn(m)" using MIMprop less_eqI nm by mty auto
      hence "\<bar> \<ss>2\<hh>seq(f)(s2hn(m)) -\<^sub>\<H> \<ss>2\<hh>seq(f)(s2hn(n))\<bar> < \<ss>2\<hh>\<^sub>\<rat>(r)" using k by mty auto
      hence "\<bar>\<ss>2\<hh>\<^sub>\<rat>((f. m) -\<^sub>\<S>\<^sup>\<real> (f. n))\<bar> < \<ss>2\<hh>\<^sub>\<rat>(r)" using A3 by mty auto
      hence "\<ss>2\<hh>\<^sub>\<rat>(( |.  (f. m) -\<^sub>\<S>\<^sup>\<real> (f. n) .| )) < \<ss>2\<hh>\<^sub>\<rat>(r)" 
        using rat_abs[of "  (f. m) -\<^sub>\<S>\<^sup>\<real> (f. n) "] by mty auto
      hence "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(( |.  (f. m) -\<^sub>\<S>\<^sup>\<real> (f. n) .| ))) <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(r))" 
        using Ratless by mty auto
      thus " |.  (f. m) -\<^sub>\<S>\<^sup>\<real> (f. n) .| <\<^sup>\<real> r" using MIMQprop by mty auto
    qed mauto
  qed mauto
qed

text_raw {*\DefineSnippet{MIvanishesQ}{*}
theorem MIvanishesQ:
  assumes "f is Function-of NAT,RAT"
  shows "f is vanishes\<^sub>\<rat> \<longleftrightarrow> Real.vanishes (\<ss>2\<hh>seq(f))"
text_raw {*}%EndSnippet*}
proof
  have [ty]: "f is Function-of NAT,RAT" using assms by auto
  assume [ty]:"f be vanishes\<^sub>\<rat>"
  show " Real.vanishes(\<ss>2\<hh>seq(f))"
  proof(rule vanishesI)
    fix r :: rat assume r: "0 < r"
    obtain sr where [ty]: "sr is Rat" and sr:"sr = \<hh>2\<ss>\<^sub>\<rat>(r)" using h2sQprop  by mty auto    
    have "{} <\<^sup>\<real> sr" using sr r Ratless Qzero by mty auto
    then obtain N where [ty]: "N be Nat  " and
        N: "for n be Nat st N \<subseteq> n holds
                    |. f . n .| <\<^sup>\<real> sr"
      using vanishesQE[THEN bspec, of f sr,simplified] by mty auto
    let ?N="\<ss>2\<hh>\<^sub>\<nat>(N)"
    show "\<exists>\<^sub>Lk.  \<forall>n\<ge>k. \<bar>\<ss>2\<hh>seq(f)(n)\<bar> < r" 
    proof(rule exI[of _ ?N],intro allI impI)
      fix n      assume AS: "\<ss>2\<hh>\<^sub>\<nat>(N) \<le> n"
      have [ty]:  "\<hh>2\<ss>\<^sub>\<nat>(n) is Nat" using I2Mprop by mty auto
      have A2[ty]: "f.(h2sn(n)) is Rat"  by mty auto
      have "\<ss>2\<hh>seq(f) =\<^sub>\<H> (\<lambda>x. \<ss>2\<hh>\<^sub>\<rat>(f.(h2sn(x))))" using s2hseq_def \<ss>2\<hh>f_def by mty auto
      hence A3: "\<ss>2\<hh>seq(f)(n)  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(f.(h2sn(n)))" by mty auto
   
      have  "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(N)) c= \<hh>2\<ss>\<^sub>\<nat>(n)"
        using AS less_eqI by mty auto                   
      hence  "N c= \<hh>2\<ss>\<^sub>\<nat>(n)" using MIMprop by mty auto
      hence  "|. (f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| <\<^sup>\<real> sr" 
        using N[THEN bspec, of "\<hh>2\<ss>\<^sub>\<nat>(n)",simplified] by mty auto
     hence  "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>( |.(f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| )) <\<^sup>\<real> sr" 
        using MIMQprop by mty auto
      hence  "\<ss>2\<hh>\<^sub>\<rat>( |.(f . \<hh>2\<ss>\<^sub>\<nat>(n))  .| ) < r" 
        using sr Ratless[of "\<ss>2\<hh>\<^sub>\<rat>( |. (f . \<hh>2\<ss>\<^sub>\<nat>(n)) .| )" r] by mty auto
      hence " \<bar>\<ss>2\<hh>\<^sub>\<rat>( (f . \<hh>2\<ss>\<^sub>\<nat>(n))) \<bar> < r"
        using rat_abs[of " (f . \<hh>2\<ss>\<^sub>\<nat>(n))"] by mty auto
      thus "\<bar>\<ss>2\<hh>seq(f)(n)\<bar> < r" using A3 by simp
    qed 
  qed
next 
    have [ty]: "f is Function-of NAT,RAT" using assms by auto
assume AS:" Real.vanishes(\<ss>2\<hh>seq(f))"
  show "f be vanishes\<^sub>\<rat>"
  proof(standard,simp,intro ballI impI)
    fix r assume [ty]:"r be Rat" and "{}<\<^sup>\<real> r"
    hence z:"0 < \<ss>2\<hh>\<^sub>\<rat>(r)" using Ratless MIMQprop[of r] MIMQprop[of "{}"] Qzero by mty auto
    obtain k where  
       k: " \<forall>n\<ge>k. \<bar>\<ss>2\<hh>seq(f)(n)\<bar> < \<ss>2\<hh>\<^sub>\<rat>(r)"
      using vanishesD[OF AS z] by mty auto
    let ?K="h2sn(k)"
    have [ty]:"?K is Nat" using I2Mprop by mty auto
    show "\<exists>N : Nat. \<forall>n : Nat.  N \<subseteq> n  \<longrightarrow> |.  f . n .| <\<^sup>\<real> r"
    proof(rule bexI[of _ ?K], intro ballI impI)
      fix n m assume [ty]:"n be Nat"  and nm: "?K \<subseteq> n "   
       have "\<ss>2\<hh>seq(f) =\<^sub>\<H> (\<lambda>x. \<ss>2\<hh>\<^sub>\<rat>(f.(h2sn(x))))" using s2hseq_def \<ss>2\<hh>f_def by mty auto
      hence A3:  "\<ss>2\<hh>seq(f)(s2hn(n)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>( (f. n))" using  MIMprop by mty auto
      have  "k \<le> s2hn(n)" using MIMprop less_eqI nm by mty auto
      hence "\<bar> \<ss>2\<hh>\<^sub>\<rat>(f. n)\<bar> < \<ss>2\<hh>\<^sub>\<rat>(r)" using k A3 by mty auto
      hence "\<ss>2\<hh>\<^sub>\<rat>(( |.  (f. n) .| )) < \<ss>2\<hh>\<^sub>\<rat>(r)" 
        using rat_abs[of " (f. n) "] by mty auto
      hence "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(( |. (f. n) .| ))) <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(r))" 
        using Ratless by mty auto
      thus " |.   (f. n) .| <\<^sup>\<real> r" using MIMQprop by mty auto
    qed mauto
  qed mauto
qed

text_raw {*\DefineSnippet{s2h_R}{*}
function s2hR :: "Set \<Rightarrow> real" ("\<ss>2\<hh>\<^sub>\<real>'(_')")where
  "\<not>x is MReal \<Longrightarrow> \<ss>2\<hh>\<^sub>\<real>(x) =\<^sub>\<H> undefined"
| "x is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> x\<noteq>0\<^sub>\<S> \<Longrightarrow> \<ss>2\<hh>\<^sub>\<real>(x) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC x))"
| "x is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> x=0\<^sub>\<S> \<Longrightarrow> \<ss>2\<hh>\<^sub>\<real>(x) =\<^sub>\<H> 0"
| "x is MReal \<and> x\<noteq>0\<^sub>\<S> \<and> \<not> x is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> \<ss>2\<hh>\<^sub>\<real>(x) =\<^sub>\<H> -\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC(-\<^sub>\<S>\<^sup>\<real> x)))"
text_raw {*}%EndSnippet*}
proof(auto)
  fix x assume A: "\<not> x be Mreal" and [ty]:"x be Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
  have "x be MReal" by mty auto
  thus " undefined =\<^sub>\<H>  Real.Real(\<ss>2\<hh>seq(rC x ))" using A by simp
next
  assume "\<not>{} be Mreal" "{} be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  thus " undefined =\<^sub>\<H> 0" by mty auto
next
  fix P x
  assume AS:"(\<And>xa. \<not> xa be Mreal \<Longrightarrow> x =\<^sub>\<S> xa \<Longrightarrow> P)"
           "(\<And>xa. xa be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> xa \<noteq> {} \<Longrightarrow> x =\<^sub>\<S> xa \<Longrightarrow> P)"
           "({} be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x =\<^sub>\<S> {} \<Longrightarrow> P)"
           "(\<And>xa. xa be Mreal \<and> xa \<noteq> {} \<and> \<not> xa be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x =\<^sub>\<S> xa \<Longrightarrow> P)"
  show P 
  proof(cases "x is Mreal")
    case False
    thus P using AS by auto
  next
    case [ty]: True
      show P 
      proof(cases "x ={}")
        case T:True      
        thus P using AS(3) by mty auto   
      next
        case F:False
            show P   using AS(2,4)[of "x"] F by mty auto 
          qed
        qed
      qed mauto
      print_theorems 

notation s2hR ("\<ss>2\<hh>\<^sub>\<real>")

termination
  apply standard 
  apply auto done

theorem seqCauchy:
  assumes [ty]: "r is non empty\<bar>Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  shows "Real.cauchy (\<ss>2\<hh>seq(rC r))"
proof-
  have "(rC r) is Cauchy\<^sub>\<S>" by mty auto 
  thus ?thesis using MICauchy[of "rC r"] by mty auto
qed


theorem powerM:
  assumes [ty]: "i be Nat" "n be Nat"
  shows "\<ss>2\<hh>\<^sub>\<int>(i |^ n) =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(i)) ^ (\<ss>2\<hh>\<^sub>\<nat>(n))" 
proof-
  let ?P="\<lambda>n. \<ss>2\<hh>\<^sub>\<int>(i |^ n) =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(i)) ^ (\<ss>2\<hh>\<^sub>\<nat>(n))"
  have "succ {}<> {}"  using NAT_1_6 by mty auto
  hence H: "\<ss>2\<hh>\<^sub>\<nat>(succ {}) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>({}))" using s2hn.simps by mty auto      

  have  "i |^ 0\<^sub>\<S> = 1\<^sub>\<S>" using newton_th_4 by mty auto
  hence P0: "?P({})" by mty auto
  
  have Pn: "for k be Nat st ?P(k) holds ?P(succ k)"
  proof(intro ballI impI)
    fix k assume [ty]:"k be Nat" and AS: "?P(k)"
    have " \<ss>2\<hh>\<^sub>\<int>(i |^ (succ k)) =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<int>(i *\<^sub>\<S>\<^sup>\<nat> (i |^ k))" 
      using newton_th_6 by mty auto
    hence " \<ss>2\<hh>\<^sub>\<int>(i |^ (succ k)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i *\<^sub>\<S>\<^sup>\<real> (i |^ k))" using int_1_def_5 by mty auto
    hence " \<ss>2\<hh>\<^sub>\<int>(i |^ (succ k))  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i )*\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int> (i |^ k)" using MultIntM[of i "i |^ k"] by mty auto
    hence " \<ss>2\<hh>\<^sub>\<int>(i |^ (succ k)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i )*\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int> (i |^ k)" using MultIntM[of i "i |^ k"] by mty auto
    thus  " \<ss>2\<hh>\<^sub>\<int>(i |^ (succ k)) =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(i)) ^ (\<ss>2\<hh>\<^sub>\<nat>(succ k))" using AS by auto
  qed mauto
  show ?thesis using  ordinal_2_sch_19[of n ?P,OF _ P0 Pn] by auto
qed

theorem powerI:
   "0 \<le>i \<longrightarrow> h2sZ(i) |^ h2sn(n) = h2sZ (i ^ n)"
proof
  assume "0 \<le>i"
  hence "\<hh>2\<ss>\<^sub>\<int>(i) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(nat(i))" by auto
  hence [ty]:"h2sZ(i) is Nat" "h2sn(n) is Nat" using I2Mprop by auto
  have "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i) |^ h2sn(n)) =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(h2sZ(i))) ^ (\<ss>2\<hh>\<^sub>\<nat>(h2sn(n)))" 
    using powerM[of "h2sZ(i)" "h2sn(n)"] by mty auto
  hence "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i) |^ h2sn(n)) =\<^sub>\<H> i ^ n" 
    using IMIZprop IMIprop[of n] by mty auto
  hence "h2sZ(\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i) |^ h2sn(n))) = h2sZ(i ^ n)" by auto
  thus "h2sZ(i) |^ h2sn(n) = h2sZ (i ^ n)" using MIMZprop[of "\<hh>2\<ss>\<^sub>\<int>(i) |^ h2sn(n)"] by mty auto
qed

text_raw {*\DefineSnippet{real2seqL}{*}
definition real2seqL :: "real \<Rightarrow> (nat\<Rightarrow>rat)" where
  "real2seqL(r) =\<^sub>\<H> (\<lambda>n::nat. Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n))"
text_raw {*}%EndSnippet*}


text_raw {*\DefineSnippet{real2seqU}{*}
definition real2seqU :: "real \<Rightarrow> (nat\<Rightarrow>rat)" where
  "real2seqU(r) =\<^sub>\<H> (\<lambda>n::nat. Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1,2^n))"
text_raw {*}%EndSnippet*}


text_raw {*\DefineSnippet{real2seqLC}{*}
theorem real_lower_bound:
  "Real.cauchy(real2seqL(s))" 
text_raw {*}%EndSnippet*}
proof(rule cauchyI)
  fix r::rat assume AS: "0 < r"
  then obtain k::nat where 
    n: "(1 / r) < (rat_of_nat(k))"
    using reals_Archimedean2 by blast
  hence "1  < (2 ^ k) *\<^sub>\<H> r"
    using divide_less_eq less_trans of_nat_less_two_power AS by metis 
 hence r: "1/(2 ^ k)  <  r"
   using AS by (simp add: divide_less_eq power_commuting_commutes)
  have le_eq_f:"\<And> i j k::int. 0 < k  \<Longrightarrow> i \<le> j \<Longrightarrow> Fract(i,k) \<le>Fract(j,k)" by simp
  have temp_1:"\<And> a b c d::real. a \<le>b \<Longrightarrow> c \<le>d \<Longrightarrow> a -\<^sub>\<H> d \<le> b -\<^sub>\<H> c" by simp
  have temp_2:"\<And> a b c::int. a \<le> b \<Longrightarrow> b \<le>c \<Longrightarrow> a  \<le>  c" by simp
  have temp_3:"\<And> i j k::int.0 < k  \<Longrightarrow> 0 < i \<Longrightarrow> i \<le> j \<Longrightarrow> Fract(k,j) \<le>Fract(k,i)" by simp 
  show "\<exists>\<^sub>Lk. \<forall>m\<ge>k. \<forall>n\<ge>k. \<bar>real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)\<bar> < r"
  proof(rule exI[of _ k],intro allI impI)
    fix m n assume K: "k \<le> m" "k \<le> n"
    show "\<bar>real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)\<bar> < r"
    proof(cases "n \<le> m")
      case True
      then obtain i::nat where
        m: " m =\<^sub>\<H> n +\<^sub>\<H> i" using le_Suc_ex by auto

      have "\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i) \<ge>  (s *\<^sub>\<H> (2^n) -\<^sub>\<H> 1) *\<^sub>\<H> real_of_int(2^i)" by auto
      hence "\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i) \<ge>  
      ((s *\<^sub>\<H> (2^n)) *\<^sub>\<H> real_of_int(2^i)) -\<^sub>\<H> (1 *\<^sub>\<H> real_of_int(2^i)) "
        by (metis left_diff_distrib')
      hence "\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i) \<ge>  ((s *\<^sub>\<H> (2^n)) *\<^sub>\<H> (2^i)) -\<^sub>\<H> ( real_of_int(2^i)) "
        by auto     
      hence "real_of_int(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) \<ge>  ((s *\<^sub>\<H> (2^m)) -\<^sub>\<H> (real_of_int (2^i))) "
        using m power_add mult.assoc by metis
      hence "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>  -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) \<le>2^i" using of_int_add by linarith
      hence LEq: "Fract ( \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)),
       2^ m)\<le> Fract(2^i,2^m)" using le_eq_f by auto
   
      have MN: "real2seqL(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>,2^m)" 
         "real2seqL(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>,2^n)" 
        using real2seqL_def by auto
      hence "real2seqL(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> *\<^sub>\<H> (2^i),(2^n) *\<^sub>\<H>(2^i))" 
         by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
      hence MN1: "real2seqL(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> *\<^sub>\<H> (2^i),(2^m))" 
        using m power_add by metis
      hence "real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>,2^m)
     -\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> *\<^sub>\<H> (2^i),(2^m))" using MN by auto
      also have "... =\<^sub>\<H> Fract ( (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i))) *\<^sub>\<H> (2^ m),
       (2^ m)*\<^sub>\<H> (2^ m))" using diff_rat
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract ( \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)),
       2^ m)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have H1:"real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n) \<le>Fract(2^i,2^m)" using LEq by auto
    have S1: " real_of_int(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> +\<^sub>\<H> 1) \<ge> (s *\<^sub>\<H> real_of_int((2^m)))" by auto
    have "s *\<^sub>\<H> (2^n) \<ge> \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>" by auto
    hence "(s *\<^sub>\<H> real_of_int((2^n)*\<^sub>\<H> (2^i)))  \<ge> real_of_int(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) " by auto
    hence S2:"(s *\<^sub>\<H> real_of_int(2^m))  \<ge> real_of_int(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) " 
      using m by (simp add: power_add)
    have " real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> *\<^sub>\<H> 2 ^ i) -\<^sub>\<H> real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1)
    \<le> s *\<^sub>\<H> real_of_int(2 ^ m) -\<^sub>\<H> s *\<^sub>\<H> real_of_int(2 ^ m)" 
    using temp_1[OF S2 S1] by auto
    hence " real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> *\<^sub>\<H> 2 ^ i) -\<^sub>\<H> real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> ) \<le> 1" by auto
    hence H:"(\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> *\<^sub>\<H> 2 ^ i) -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> ) \<le> 1" by linarith 
    have "(2^i) \<ge>  (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>" using one_le_power[of 2 i]
        Orderings.order_class.order.trans[OF H] by auto 
    hence F: "Fract(2^i,2^m) \<ge>Fract (  (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> ,
       2^ m)" using le_eq_f by auto
    have "real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> *\<^sub>\<H> (2^i),2^m)
     -\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>,(2^m))" using MN MN1 by auto
    also have "... =\<^sub>\<H> Fract ( ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i))  -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>) *\<^sub>\<H> (2^ m),
       (2^ m)*\<^sub>\<H> (2^ m))" using diff_rat
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract (  (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>*\<^sub>\<H> (2^i)) -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> ,
       2^ m)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have " Fract(2^i,2^m) \<ge> real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m)" using F by auto
    hence " -\<^sub>\<H> Fract(2^i,2^m) \<le> real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)" 
     by linarith
     hence H1: "\<bar>real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)\<bar> \<le>Fract(2^i,2^m)" using H1  by linarith

     have H2: "1 / rat_of_int(2 ^ n ) \<le> 1 / rat_of_int(2 ^ k)" using K by (simp add: divide_left_mono)

     have "Fract(2^i,2^m) =\<^sub>\<H> Fract(2^i *\<^sub>\<H> 1 ,(2^n) *\<^sub>\<H> (2^i))" using m by (simp add: power_add)
     also have "... =\<^sub>\<H> Fract(1 ,2^n )"
      by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
     also have "... =\<^sub>\<H> 1 / (2^n )"
       by (metis (no_types, lifting) divide_rat of_int_1 of_int_add of_int_power of_int_rat one_add_one one_power2 power_add power_one_right push_bit_int_def push_bit_of_1) 
     finally have "Fract(2^i,2^m) =\<^sub>\<H> 1 / rat_of_int(2^n )" by auto
     hence "\<bar>real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)\<bar> \<le> 1 / rat_of_int(2^k )" using H1 H2 by auto
     thus "\<bar>real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)\<bar> < r" using r by auto
   next
     case T:False
     hence "m \<le>n" by auto
      then obtain i::nat where
        m: " n =\<^sub>\<H> m +\<^sub>\<H> i" using le_Suc_ex by auto
      have "\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i) \<ge>  (s *\<^sub>\<H> (2^m) -\<^sub>\<H> 1) *\<^sub>\<H> real_of_int(2^i)" by auto
      hence "\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i) \<ge>  
      ((s *\<^sub>\<H> (2^m)) *\<^sub>\<H> real_of_int(2^i)) -\<^sub>\<H> (1 *\<^sub>\<H> real_of_int(2^i)) "
        by (metis left_diff_distrib')
      hence "\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i) \<ge>  ((s *\<^sub>\<H> (2^m)) *\<^sub>\<H> (2^i)) -\<^sub>\<H> ( real_of_int(2^i)) "
        by auto     
      hence "real_of_int(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) \<ge>  ((s *\<^sub>\<H> (2^n)) -\<^sub>\<H> (real_of_int (2^i))) "
        using m power_add mult.assoc by metis
      hence "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>  -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) \<le>2^i" using of_int_add by linarith
      hence LEq: "Fract ( \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)),
       2^ n)\<le> Fract(2^i,2^n)" using le_eq_f by auto
      have MN: "real2seqL(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>,2^m)" 
         "real2seqL(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>,2^n)" 
        using real2seqL_def by auto
      hence "real2seqL(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> *\<^sub>\<H> (2^i),(2^m) *\<^sub>\<H>(2^i))" 
         by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
      hence MN1: "real2seqL(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> *\<^sub>\<H> (2^i),(2^n))" 
        using m power_add by metis
      hence "real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>,2^n)
     -\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> *\<^sub>\<H> (2^i),(2^n))" using MN by auto
      also have "... =\<^sub>\<H> Fract ( (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i))) *\<^sub>\<H> (2^ n),
       (2^ n)*\<^sub>\<H> (2^ n))" using diff_rat
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract ( \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)),
       2^ n)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have H1:"real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m) \<le>Fract(2^i,2^n)" using LEq by auto
    have S1: " real_of_int(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1) \<ge> (s *\<^sub>\<H> real_of_int((2^n)))" by auto
    have "s *\<^sub>\<H> (2^m) \<ge> \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>" by auto
    hence "(s *\<^sub>\<H> real_of_int((2^m)*\<^sub>\<H> (2^i)))  \<ge> real_of_int(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) " by auto
    hence S2:"(s *\<^sub>\<H> real_of_int(2^n))  \<ge> real_of_int(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) " 
      using m by (simp add: power_add)
    have " real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> *\<^sub>\<H> 2 ^ i) -\<^sub>\<H> real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1)
    \<le> s *\<^sub>\<H> real_of_int(2 ^ n) -\<^sub>\<H> s *\<^sub>\<H> real_of_int(2 ^ n)" 
    using temp_1[OF S2 S1] by auto
    hence " real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> *\<^sub>\<H> 2 ^ i) -\<^sub>\<H> real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> ) \<le> 1" by auto
    hence H:"(\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> *\<^sub>\<H> 2 ^ i) -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> ) \<le> 1" by linarith 
    have "(2^i) \<ge>  (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>" using one_le_power[of 2 i]
        Orderings.order_class.order.trans[OF H] by auto 
    hence F: "Fract(2^i,2^n) \<ge>Fract (  (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> ,
       2^ n)" using le_eq_f by auto
    have "real2seqL(s, m)-\<^sub>\<H> real2seqL(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor> *\<^sub>\<H> (2^i),2^n)
     -\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>,(2^n))" using MN MN1 by auto
    also have "... =\<^sub>\<H> Fract ( ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i))  -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>) *\<^sub>\<H> (2^ n),
       (2^ n)*\<^sub>\<H> (2^ n))" using diff_rat
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract (  (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>*\<^sub>\<H> (2^i)) -\<^sub>\<H> \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor> ,
       2^ n)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have " Fract(2^i,2^n) \<ge> real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)" using F by auto
    hence " -\<^sub>\<H> Fract(2^i,2^n) \<le> real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m)" 
     by linarith
     hence H1: "\<bar>real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m)\<bar> \<le>Fract(2^i,2^n)" using H1  by linarith
     have H2: "1 / rat_of_int(2 ^ m ) \<le> 1 / rat_of_int(2 ^ k)" using K by (simp add: divide_left_mono)
     have "Fract(2^i,2^n) =\<^sub>\<H> Fract(2^i *\<^sub>\<H> 1 ,(2^m) *\<^sub>\<H> (2^i))" using m by (simp add: power_add)
     also have "... =\<^sub>\<H> Fract(1 ,2^m )"
      by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
     also have "... =\<^sub>\<H> 1 / (2^m )"
       by (metis (no_types, lifting) divide_rat of_int_1 of_int_add of_int_power of_int_rat one_add_one one_power2 power_add power_one_right push_bit_int_def push_bit_of_1) 
     finally have "Fract(2^i,2^n) =\<^sub>\<H> 1 / rat_of_int(2^m )" by auto
     hence "\<bar>real2seqL(s, n) -\<^sub>\<H> real2seqL(s, m)\<bar> \<le> 1 / rat_of_int(2^k )" using H1 H2 by auto
     thus "\<bar>real2seqL(s, m) -\<^sub>\<H> real2seqL(s, n)\<bar> < r" using r by auto
   qed
 qed
qed

text_raw {*\DefineSnippet{real2seqLlim}{*}
theorem Real_greater:
  "  Real.Real(real2seqL(r)) \<le> r"
text_raw {*}%EndSnippet*}
proof(rule Real_leI[OF real_lower_bound],standard)
  fix n::nat
  have "r *\<^sub>\<H> real_of_int(2^n) \<ge> real_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> )" by auto
  hence "r \<ge> real_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) / real_of_int(2^n)"
    by (smt of_int_pos pos_le_divide_eq times_divide_eq_left zero_less_power)
  hence "r \<ge> real_of_rat( Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n))" by (simp add: of_rat_rat) 
  thus "r \<ge> real_of_rat(real2seqL(r, n))" using real2seqL_def by auto
qed
text_raw {*\DefineSnippet{real2seqUC}{*}
theorem real_upper_bound:
  "Real.cauchy(real2seqU(s))" 
text_raw {*}%EndSnippet*}
proof(rule cauchyI)
  fix r::rat assume AS: "0 < r"
  then obtain k::nat where 
    n: "(1 / r) < (rat_of_nat(k))"
    using reals_Archimedean2 by blast
  hence "1  < (2 ^ k) *\<^sub>\<H> r"
    using divide_less_eq less_trans of_nat_less_two_power AS by metis 
 hence r: "1/(2 ^ k)  <  r"
   using AS by (simp add: divide_less_eq power_commuting_commutes)
  have le_eq_f:"\<And> i j k::int. 0 < k  \<Longrightarrow> i \<le> j \<Longrightarrow> Fract(i,k) \<le>Fract(j,k)" by simp
  have temp_1:"\<And> a b c d::real. a \<le>b \<Longrightarrow> c \<le>d \<Longrightarrow> a -\<^sub>\<H> d \<le> b -\<^sub>\<H> c" by simp
  have temp_2:"\<And> a b c::int. a \<le> b \<Longrightarrow> b \<le>c \<Longrightarrow> a  \<le>  c" by simp
  have temp_3:"\<And> i j k::int.0 < k  \<Longrightarrow> 0 < i \<Longrightarrow> i \<le> j \<Longrightarrow> Fract(k,j) \<le>Fract(k,i)" by simp 
  show "\<exists>\<^sub>Lk. \<forall>m\<ge>k. \<forall>n\<ge>k. \<bar>real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n)\<bar> < r"
  proof(rule exI[of _ k],intro allI impI)
    fix m n assume K: "k \<le> m" "k \<le> n"
    show "\<bar>real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n)\<bar> < r"
    proof(cases "n \<le> m")
      case T:True
      then obtain i::nat where
        m: " m =\<^sub>\<H> n +\<^sub>\<H> i" using le_Suc_ex by auto
       have H1:"\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1 \<le>  s *\<^sub>\<H> real_of_int(2^m)+\<^sub>\<H> 1" by auto
       have "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i) \<ge>  s *\<^sub>\<H> real_of_int((2^n) *\<^sub>\<H> (2^i))" by auto
       hence H2: "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i) \<ge>  (s *\<^sub>\<H> real_of_int(2^m))"
         using m power_add by metis
       have "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i)) \<le> 
(s *\<^sub>\<H> real_of_int(2^m)+\<^sub>\<H> 1)  -\<^sub>\<H> (s *\<^sub>\<H> real_of_int(2^m))" using temp_1[OF H1 H2] by auto
       hence H: "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i)) \<le> 1" 
        by linarith
       have "(2^i) \<ge>  (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i))" using one_le_power[of 2 i]
        Orderings.order_class.order.trans[OF H, of "2^i"] by auto 
        hence LEq: "Fract ( (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i),
       2^ m)\<le> Fract(2^i,2^m)" using le_eq_f by auto
      have MN: "real2seqU(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1,2^m)" 
         "real2seqU(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1,2^n)" 
        using real2seqU_def by auto
      hence "real2seqU(s, n) =\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^n) *\<^sub>\<H>(2^i))" 
         by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
      hence MN1: "real2seqU(s, n) =\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^m))" 
        using m power_add by metis
      hence "real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n) =\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1),2^m)
     -\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^m))" using MN by auto
      also have "... =\<^sub>\<H> Fract ( ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i))) *\<^sub>\<H> (2^ m),
       (2^ m)*\<^sub>\<H> (2^ m))" using diff_rat
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract (( \<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i)),
       2^ m)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have H1:"real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n) \<le>Fract(2^i,2^m)" using LEq by auto
   have "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>(2^n)+\<^sub>\<H> 1)*\<^sub>\<H> real_of_int(2^i)  " by auto  
   hence "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>(2^n)*\<^sub>\<H> real_of_int(2^i))+\<^sub>\<H>
         1*\<^sub>\<H> real_of_int(2^i)"
     by (simp add: comm_semiring_class.distrib)
    hence "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>real_of_int((2^n)*\<^sub>\<H> (2^i)))+\<^sub>\<H>
          real_of_int(2^i)" by auto
   hence U1: "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>real_of_int((2^m)))+\<^sub>\<H>
          real_of_int(2^i)" using m power_add by metis
    have U2: "\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1 \<ge> s *\<^sub>\<H> (2^m)" by auto
  have "(-\<^sub>\<H>  real_of_int(2 ^ i))
\<le> real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1) -\<^sub>\<H> real_of_int((\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> 2 ^ i)"
      using temp_1[OF U2 U1] by auto
    hence X:"-\<^sub>\<H> (2 ^ i) \<le> (\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> 2 ^ i)"
      by linarith   
    have LEq: "Fract (-\<^sub>\<H>(2 ^ i)  ,
       2^ m)\<le> Fract((\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> 2 ^ i), 2^m)" 
      using le_eq_f[OF _ X] by auto
      have  "real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1,2^m)
     -\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^m))" using MN MN1 by auto
      also have "... =\<^sub>\<H> Fract ( ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i))) *\<^sub>\<H> (2^ m),
       (2^ m)*\<^sub>\<H> (2^ m))" using diff_rat 
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract ( (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i),
       2^ m)" using mult_rat_cancel[of "2^m" _ "2^m"]
        mult.commute power_not_zero[of 2] zero_neq_numeral by metis
    finally have H2:"real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n) \<ge> -\<^sub>\<H> Fract(2^i,2^m)" 
      using LEq by auto
    hence  H: "\<bar>real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n)\<bar> \<le> Fract(2^i,2^m)" 
      using H1 by linarith
     have H2: "1 / rat_of_int(2 ^ n ) \<le> 1 / rat_of_int(2 ^ k)" using K by (simp add: divide_left_mono)
     have "Fract(2^i,2^m) =\<^sub>\<H> Fract(2^i *\<^sub>\<H> 1 ,(2^n) *\<^sub>\<H> (2^i))" using m by (simp add: power_add)
     also have "... =\<^sub>\<H> Fract(1 ,2^n )"
      by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
     also have "... =\<^sub>\<H> 1 / (2^n )"
       by (metis (no_types, lifting) divide_rat of_int_1 of_int_add of_int_power of_int_rat one_add_one one_power2 power_add power_one_right push_bit_int_def push_bit_of_1) 
     finally have "Fract(2^i,2^m) =\<^sub>\<H> 1 / rat_of_int(2^n )" by auto
     hence "\<bar>real2seqU(s, n) -\<^sub>\<H> real2seqU(s, m)\<bar> \<le> 1 / rat_of_int(2^k )" using H2 H by auto
     thus "\<bar>real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n)\<bar> < r" using r by auto
   next
     case F:False
     hence "m \<le>n" by auto
      then obtain i::nat where
        m: " n =\<^sub>\<H> m +\<^sub>\<H> i" using le_Suc_ex by auto
       have H1:"\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1 \<le>  s *\<^sub>\<H> real_of_int(2^n)+\<^sub>\<H> 1" by auto
       have "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i) \<ge>  s *\<^sub>\<H> real_of_int((2^m) *\<^sub>\<H> (2^i))" by auto
       hence H2: "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i) \<ge>  (s *\<^sub>\<H> real_of_int(2^n))"
         using m power_add by metis
       have "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i)) \<le> 
(s *\<^sub>\<H> real_of_int(2^n)+\<^sub>\<H> 1)  -\<^sub>\<H> (s *\<^sub>\<H> real_of_int(2^n))" using temp_1[OF H1 H2] by auto
       hence H: "(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i)) \<le> 1" 
        by linarith
       have "(2^i) \<ge>  (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i))" using one_le_power[of 2 i]
        Orderings.order_class.order.trans[OF H, of "2^i"] by auto 
        hence LEq: "Fract ( (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i),
       2^ n)\<le> Fract(2^i,2^n)" using le_eq_f by auto
      have MN: "real2seqU(s, n) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1,2^n)" 
         "real2seqU(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1,2^m)" 
        using real2seqU_def by auto
      hence "real2seqU(s, m) =\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^m) *\<^sub>\<H>(2^i))" 
         by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
      hence MN1: "real2seqU(s, m) =\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^n))" 
        using m power_add by metis
      hence "real2seqU(s, n) -\<^sub>\<H> real2seqU(s, m) =\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1),2^n)
     -\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^n))" using MN by auto
      also have "... =\<^sub>\<H> Fract ( ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i))) *\<^sub>\<H> (2^ n),
       (2^ n)*\<^sub>\<H> (2^ n))" using diff_rat
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract (( \<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i)),
       2^ n)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have H1:"real2seqU(s, n) -\<^sub>\<H> real2seqU(s, m) \<le>Fract(2^i,2^n)" using LEq by auto
    have "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>(2^m)+\<^sub>\<H> 1)*\<^sub>\<H> real_of_int(2^i)  " by auto
   hence "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>(2^m)*\<^sub>\<H> real_of_int(2^i))+\<^sub>\<H>
         1*\<^sub>\<H> real_of_int(2^i)"
     by (simp add: comm_semiring_class.distrib)
    hence "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>real_of_int((2^m)*\<^sub>\<H> (2^i)))+\<^sub>\<H>
          real_of_int(2^i)" by auto
   hence U1: "(\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i) \<le> (s *\<^sub>\<H>real_of_int((2^n)))+\<^sub>\<H>
          real_of_int(2^i)" using m power_add by metis
    have U2: "\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1 \<ge> s *\<^sub>\<H> (2^n)" by auto
  have "(-\<^sub>\<H>  real_of_int(2 ^ i))
\<le> real_of_int(\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1) -\<^sub>\<H> real_of_int((\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> 2 ^ i)"
      using temp_1[OF U2 U1] by auto
    hence X:"-\<^sub>\<H> (2 ^ i) \<le> (\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> 2 ^ i)"
      by linarith   
    have LEq: "Fract (-\<^sub>\<H>(2 ^ i)  ,
       2^ n)\<le> Fract((\<lfloor>s *\<^sub>\<H> 2 ^ n\<rfloor> +\<^sub>\<H> 1) -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> 2 ^ m\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> 2 ^ i), 2^n)" 
      using le_eq_f[OF _ X] by auto
      have  "real2seqU(s, n) -\<^sub>\<H> real2seqU(s, m) =\<^sub>\<H> Fract(\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1,2^n)
     -\<^sub>\<H> Fract((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1) *\<^sub>\<H> (2^i),(2^n))" using MN MN1 by auto
      also have "... =\<^sub>\<H> Fract ( ((\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> ((\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i))) *\<^sub>\<H> (2^ n),
       (2^ n)*\<^sub>\<H> (2^ n))" using diff_rat 
        by (simp add: left_diff_distrib) 
    also have "... =\<^sub>\<H> Fract ( (\<lfloor>s *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> (\<lfloor>s *\<^sub>\<H> (2^m)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^i),
       2^ n)" using mult_rat_cancel[of "2^n" _ "2^n"]
        mult.commute power_not_zero[of 2] zero_neq_numeral by metis
    finally have H2:"real2seqU(s, n) -\<^sub>\<H> real2seqU(s, m) \<ge> -\<^sub>\<H> Fract(2^i,2^n)" 
      using LEq by auto
    hence  H: "\<bar>real2seqU(s, n) -\<^sub>\<H> real2seqU(s, m)\<bar> \<le> Fract(2^i,2^n)" 
      using H1 by linarith
     have H2: "1 / rat_of_int(2 ^ m ) \<le> 1 / rat_of_int(2 ^ k)" using K by (simp add: divide_left_mono)
     have "Fract(2^i,2^n) =\<^sub>\<H> Fract(2^i *\<^sub>\<H> 1 ,(2^m) *\<^sub>\<H> (2^i))" using m by (simp add: power_add)
     also have "... =\<^sub>\<H> Fract(1 ,2^m )"
      by (metis mult.commute mult_rat_cancel power_not_zero zero_neq_numeral)
     also have "... =\<^sub>\<H> 1 / (2^m )"
       by (metis (no_types, lifting) divide_rat of_int_1 of_int_add of_int_power of_int_rat one_add_one one_power2 power_add power_one_right push_bit_int_def push_bit_of_1) 
     finally have "Fract(2^i,2^n) =\<^sub>\<H> 1 / rat_of_int(2^m )" by auto
     hence "\<bar>real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n)\<bar> \<le> 1 / rat_of_int(2^k )" using H2 H by auto
     thus "\<bar>real2seqU(s, m) -\<^sub>\<H> real2seqU(s, n)\<bar> < r" using r by auto
   qed
 qed
qed

text_raw {*\DefineSnippet{real2seqUlim}{*}
theorem Real_lower:
  "r \<le> Real.Real(real2seqU(r))"
proof(rule le_RealI[OF real_upper_bound],standard)
  fix n::nat
  have "r *\<^sub>\<H> real_of_int(2^n) \<le> real_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1)" by auto
  hence "r \<le> real_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1) / real_of_int(2^n)" by (simp add: pos_le_divide_eq) 
  hence "r \<le> real_of_rat( Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1,2^n))" by (simp add: of_rat_rat) 
  thus "r \<le> real_of_rat(real2seqU(r, n))" using real2seqU_def by auto
qed
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{h2sseq}{*}
definition h2sseq :: "real \<Rightarrow> Set" ("\<hh>2\<ss>seq'(_')") where
  "\<hh>2\<ss>seq(r) = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(r))"
text_raw {*}%EndSnippet*}

theorem SeqProp:
  "\<hh>2\<ss>seq(r) is Function-of NAT, RAT"
  unfolding h2sseq_def using ItoMprop[OF beIsoS_NAT beIsoS_RAT] by mty auto 

text_raw {*\DefineSnippet{seq2Dedekind}{*}
mdef seq2Dedekind where
  mlet "f be Function-of NAT, RAT"
  "func seq2Dedekind(f) \<rightarrow> Subset-of RAT\<^bsup>\<ge>0\<^bsub> means
     \<lambda>it. \<forall>x:Element-of RAT\<^bsup>\<ge>0\<^bsub>. x in it \<longleftrightarrow> (\<exists>k:Nat. x <\<^sup>\<real> (f .k))"
text_raw {*}%EndSnippet*}
proof-
  let ?P ="\<lambda>x . ex k be Nat st x<\<^sup>\<real> (f . k)"
  let ?D = "{x where x be Element-of RAT\<^bsup>\<ge>0\<^bsub>: ?P(x)}"
  obtain DD where "DD is set"
      and dd: "DD=?D" using all_set by auto
  have "?D \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>"
  proof(rule tarski_def_3I[OF all_set all_set], intro ballI impI)
    fix x assume T:"x in ?D"
    obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
       "x=r" "?P(x)" using Fraenkel_A1_ex[OF _ _ T] by mty auto
    thus "x in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" r] by mty auto
  qed mauto
  hence [ty]:"DD is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using dd Subset_of_rule by mty auto
  show "ex D be Subset-of RAT\<^bsup>\<ge>0\<^bsub> st (for x be Element-of RAT\<^bsup>\<ge>0\<^bsub> holds 
         x in D iff (ex k be Nat st x <\<^sup>\<real> (f . k)))"
  proof(rule bexI[of _ DD],rule ballI,standard)
    fix x assume "x in DD"
    hence T:"x in ?D" using dd by auto
    obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
       "x=r" "?P(x)" using Fraenkel_A1_ex[OF _ _ T] by mty auto
    thus "?P(x)" by auto
  next
    fix x assume [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "?P(x)"
    thus "x in DD" using dd Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x ?P ] by mty auto
  qed mauto
next
  let ?P ="\<lambda>x . ex k be Nat st x<\<^sup>\<real> (f . k)"
  fix a b assume [ty]: "a is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" "b is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
           a:"\<forall>x : Element-of RAT\<^bsup>\<ge>0\<^bsub>. x in a \<longleftrightarrow> ?P(x)" and
           b:"\<forall>x : Element-of RAT\<^bsup>\<ge>0\<^bsub>. x in b \<longleftrightarrow> ?P(x)"
  show  "a =\<^sub>\<S> b"
  proof(standard)
    fix x show "x in a iff x in b"
    proof
      assume x:"x in a"
      hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[of x a "RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto  
      thus "x in b" using a b x by mty auto
    next
      assume x:"x in b"
      hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[of x b "RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto  
      thus "x in a" using a b x by mty auto
    qed
  qed mauto   
qed mauto

theorem upper_bound:
  fixes r::real
  fixes k::nat
  fixes n::nat
  shows " Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n) \<le> Fract(\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor> +\<^sub>\<H> 1 ,2^k)"
proof-
   have H1: "(r *\<^sub>\<H> (real_of_nat(2^n)))*\<^sub>\<H> (real_of_nat(2^k)) < 
         (real_of_int( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^k)))\<rfloor>) +\<^sub>\<H> 1) *\<^sub>\<H> (real_of_nat(2^n))" by auto
  have "real_of_int( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^n)))\<rfloor>)*\<^sub>\<H> (real_of_nat(2^k)) \<le> 
(r *\<^sub>\<H> (real_of_nat(2^n)))*\<^sub>\<H> (real_of_nat(2^k))"
   by simp
  hence "real_of_int( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^n)))\<rfloor>)*\<^sub>\<H> (real_of_nat(2^k)) \<le>
(real_of_int( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^k)))\<rfloor>) +\<^sub>\<H> 1) *\<^sub>\<H> (real_of_nat(2^n))" using H1
    by linarith 
  hence "real_of_int(( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^n)))\<rfloor>)*\<^sub>\<H> (2^k)) \<le>
real_of_int( ( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^k))) \<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H>(2^n))" by auto
  hence "(( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^n)))\<rfloor>)*\<^sub>\<H> (2^k)) \<le> 
        ( ( \<lfloor>(r *\<^sub>\<H> (real_of_nat(2^k))) \<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H>(2^n))"   by linarith 
 hence "((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)*\<^sub>\<H> (2^k))  \<le> ((\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> (2^n))" 
   by auto 
  hence "((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)*\<^sub>\<H> (2^k) ) \<le> ((\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> (2^n))" by auto
  hence "((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)*\<^sub>\<H> (2^k) )*\<^sub>\<H> ((2^n)*\<^sub>\<H> (2^k)) \<le> ((\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor> +\<^sub>\<H> 1) *\<^sub>\<H> (2^n))*\<^sub>\<H> ((2^n)*\<^sub>\<H> (2^k))" 
    by auto
  thus "Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n) \<le> Fract(\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor> +\<^sub>\<H> 1 ,2^k)" by auto
qed

text_raw {*\DefineSnippet{real2seqUL}{*}
theorem real2seq_prop:
  "Real.Real(real2seqL(r)) =\<^sub>\<H> r & Real.Real(real2seqU(r)) =\<^sub>\<H> r"
text_raw {*}%EndSnippet*}
proof-
  have "Real.vanishes (\<lambda>n. real2seqU(r,n) -\<^sub>\<H> (real2seqL(r,n)))"
  proof(rule vanishesI)
     fix e::rat assume AS: "0 <e"
     then obtain k::nat where 
       n: "(1 / e) < (rat_of_nat(k))"
       using reals_Archimedean2 by blast
     hence "1  < (2 ^ k) *\<^sub>\<H> e"
       using divide_less_eq less_trans of_nat_less_two_power AS by metis 
     hence r: "1/(2 ^ k)  <  e"
       using AS by (simp add: divide_less_eq power_commuting_commutes)
     show "\<exists>\<^sub>Lk. \<forall>n\<ge>k. \<bar>real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n)\<bar> < e" 
     proof(rule exI[of _ k],standard,standard)
       fix n::nat assume AS: "n \<ge>k"
 
       hence H2: "1 / rat_of_int(2 ^ n ) \<le> 1 / rat_of_int(2 ^ k)" by (simp add: divide_left_mono)

       have "real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n) =\<^sub>\<H> Fract((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1),2^n)
     -\<^sub>\<H> Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>, (2^n))" using real2seqU_def real2seqL_def  by auto
       also have "... =\<^sub>\<H> Fract ( 
         ((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)*\<^sub>\<H> (2^ n))  -\<^sub>\<H> (((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)) *\<^sub>\<H> (2^ n)),
       (2^ n)*\<^sub>\<H> (2^ n))" using diff_rat
         by (simp add: left_diff_distrib) 
       also have "... =\<^sub>\<H> Fract ( 
          ((\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> (\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)) *\<^sub>\<H> (2^ n), (2^ n)*\<^sub>\<H> (2^ n))" 
       by (metis left_diff_distrib)
    also have "... =\<^sub>\<H> Fract (( \<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>+\<^sub>\<H> 1)  -\<^sub>\<H> (\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>),
       2^ n)" using mult_rat_cancel mult.commute power_not_zero zero_neq_numeral by metis
    finally have H1:"real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n) =\<^sub>\<H> Fract(1,2^n)" by simp
   
    have "real2seqL(r, n) \<le> real2seqU(r, n)" unfolding real2seqU_def real2seqL_def 
       using upper_bound by auto
     hence "\<bar> real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n) \<bar> =\<^sub>\<H>
         real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n)" by auto
     hence  "\<bar> real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n) \<bar> =\<^sub>\<H> 1 / rat_of_int(2^n )" using H1
      by (smt Fract_of_int_quotient of_int_1)
       thus  "\<bar> real2seqU(r, n) -\<^sub>\<H> real2seqL(r, n) \<bar> < e" using r H2 by simp
     qed
  qed
  hence "Real.Real(real2seqL(r)) =\<^sub>\<H> Real.Real(real2seqU(r))" using  eq_Real[OF real_upper_bound real_lower_bound, of r r] by auto
  thus ?thesis using Real_lower[of r] Real_greater[of r] by auto
qed

theorem seq2D:
  "seq2Dedekind(\<hh>2\<ss>seq(r)) is Element-of DEDEKIND_CUTS"
proof-
  obtain h where [ty]:"h is Function-of NAT,RAT" and
   h:  "h=\<hh>2\<ss>seq(r)" using SeqProp by mty auto
  let ?S="seq2Dedekind(h)"
  have "?S is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
  let ?M="Fract(\<lfloor>r *\<^sub>\<H> (2^0)\<rfloor> +\<^sub>\<H> 1 ,2^0)"
  obtain M where [ty]:"M is Rat" and
   MM: "M=\<hh>2\<ss>\<^sub>\<rat>(?M)" using h2sQprop by mty auto
  have [ty]:"?S is set" using all_set by auto
  have M: "not M in ?S" 
  proof
    assume A2: "M in seq2Dedekind(h)"

     hence [ty]: "M is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
      obtain k where [ty]: "k be Nat" and
        yy:"M <\<^sup>\<real> (h . k)" using A2  seq2Dedekind by mty auto
      let ?k = "s2hn (k)"
      have "h. k = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(r) ) . h2sn(?k)" using h h2sseq_def 
         MIMprop by mty auto
      hence "h. k = \<hh>2\<ss>\<^sub>\<rat>(real2seqL(r)(?k)) " using HtoSappl[OF beIsoS_NAT beIsoS_RAT]
        by auto
      hence hk: "h . k = \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>r *\<^sub>\<H> (2^?k)\<rfloor>,2^?k))" using real2seqL_def by auto
      have "Fract(\<lfloor>r *\<^sub>\<H> (2^?k)\<rfloor>,2^?k)\<le> ?M" using upper_bound[of r "\<ss>2\<hh>\<^sub>\<nat>(k)" 0] by simp
      hence "(h . k) \<le>\<^sup>\<real> M" using Rateq hk MM by auto                  
      thus False using yy by mty auto
  qed
  have "?S<> RAT\<^bsup>\<ge>0\<^bsub>"
  proof(cases "M in RAT\<^bsup>\<ge>0\<^bsub>")
    case True
    thus "seq2Dedekind(h)<> RAT\<^bsup>\<ge>0\<^bsub>" using M by auto
  next
    case F:False
    hence [ty]:"not (M is Element-of RAT\<^bsup>\<ge>0\<^bsub>)" using Element by mty auto
    have E: "{} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
    have "seq2Dedekind(h) ={}" 
    proof(rule ccontr)
      assume "seq2Dedekind(h) <>{}"
      hence "seq2Dedekind(h) is non empty" using xboole_0_lm_1[of "seq2Dedekind(h)"] 
        xboole_0_def_1 by mty auto 
      then obtain y where
        A2: "y in seq2Dedekind(h)" using xboole_0_def_1 by auto
      hence [ty]: "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
      hence Qy:"{}\<le>\<^sup>\<real> y" using rat_0_Q by mty auto
      
      obtain k where [ty]: "k be Nat" and
        yy:"y <\<^sup>\<real> (h . k)" using A2  seq2Dedekind by mty auto
      hence Qhk:"{} <\<^sup>\<real> (h . k)" using rat_0_def_8t1[OF _ _ _ Qy] by mty auto

      let ?k = "s2hn (k)"
      have "h. k = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(r) ) . h2sn(?k)" using h h2sseq_def 
         MIMprop by mty auto
      hence "h. k = \<hh>2\<ss>\<^sub>\<rat>(real2seqL(r)(?k)) " using HtoSappl[OF beIsoS_NAT beIsoS_RAT]
        by auto
      hence hk: "h . k = \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>r *\<^sub>\<H> (2^?k)\<rfloor>,2^?k))" using real2seqL_def by auto
      have "Fract(\<lfloor>r *\<^sub>\<H> (2^?k)\<rfloor>,2^?k)\<le> ?M" using upper_bound[of r "\<ss>2\<hh>\<^sub>\<nat>(k)" 0] by simp
      hence "(h . k) \<le>\<^sup>\<real> M" using Rateq hk MM by auto
      hence "{} <\<^sup>\<real> M" using rat_0_def_8t2[OF _ _ _ Qhk] by mty auto
      thus False using rat_0_Q[of M] real_0_th_33 by mty auto
    qed
    thus "seq2Dedekind(h)<> RAT\<^bsup>\<ge>0\<^bsub>" using E xb by auto
  qed
  hence T1: "not ?S in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by mty auto
  have "for r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r in ?S holds 
       (for s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?S) & 
       (ex s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s in ?S & r<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s )"
  proof(rule ballI,rule impI,rule conjI)
    fix r assume [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and AS:"r in ?S"
    then obtain k where [ty]:"k be Nat" and
       k: "r <\<^sup>\<real> (h . k)" using seq2Dedekind[of h r]  by mty auto  
    have "{} \<le>\<^sup>\<real> r" using rat_0_Q by mty auto
    hence "{} <\<^sup>\<real> (h . k)" using  rat_0_def_8t1[OF _ _ _ _ k] by mty auto
    hence "{} \<le>\<^sup>\<real> (h . k)" using  real_0_th_33 by mty auto
    hence [ty]:"(h . k) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_Q by  mty auto     
    have kk:" r<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(h . k)" using rat_0_th_29[of r "h . k"] k by mty auto
    then obtain ss where [ty]:"ss is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
       ss: "r<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>ss & ss<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(h . k)" using arytm_3_th_93[of r "h . k"] by mty auto
      
    show "for s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s\<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?S"
    proof(rule ballI, rule impI)
      fix s assume [ty]: "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "s\<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
      hence "s \<le>\<^sup>\<real> r" using rat_0_th_29 by mty auto
      hence "s <\<^sup>\<real> (h . k)" using rat_0_def_8t2[OF _ _ _ k] by mty auto
      thus "s in ?S" using seq2Dedekind[of h s] bexI[of _ k] by mty auto
    qed mauto
    show "ex s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s in ?S & r<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s"
    proof(rule bexI[of _ ss], rule conjI)
      have  "ss <\<^sup>\<real> (h . k)" using ss rat_0_th_29[of ss "h . k"] by mty auto
      thus "ss in ?S" using seq2Dedekind[of h ss] bexI[of _ k] by mty auto
      show "r<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>ss" using ss by mty auto
    qed mauto
  qed mauto
  hence "?S in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" ?S] by mty auto
  hence "?S in IR\\{RAT\<^bsup>\<ge>0\<^bsub>}" using xboole_0_def_5[of IR] T1 all_set by mty auto 
  hence "?S in DEDEKIND_CUTS" using arytm_2_def_1 by auto
  thus "(seq2Dedekind(\<hh>2\<ss>seq(r))) is Element-of DEDEKIND_CUTS" using h Element(6) by auto
qed

theorem non_empty_seq2D: 
  "r>0 \<Longrightarrow> {} in seq2Dedekind(\<hh>2\<ss>seq(r))"
proof-
  assume AS: "r>0"
     then obtain k::nat where 
       k: "(1 / r) < (real_of_nat(k))"
       using reals_Archimedean2 by blast
     hence k1: "1  < (2 ^ k) *\<^sub>\<H> r"
       using divide_less_eq less_trans of_nat_less_two_power AS by metis 
    obtain h where [ty]:"h is Function-of NAT,RAT" and
       h:  "h=\<hh>2\<ss>seq(r)" using SeqProp by mty auto
    let ?k = "h2sn (k)"
      have [ty]: "?k is Nat" using I2Mprop by auto
      have "h. ?k = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(r) ) . ?k" using h h2sseq_def 
         MIMprop by mty auto
      hence "h. ?k = \<hh>2\<ss>\<^sub>\<rat>(real2seqL(r,k)) " using HtoSappl[OF beIsoS_NAT beIsoS_RAT]
        by auto
      hence hk: "h . ?k = \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor>,2^k))" using real2seqL_def by auto
      have "1  <  r *\<^sub>\<H> (2 ^ k)" using k1 by (simp add: mult.commute)
      hence "0 < Fract(\<lfloor>r *\<^sub>\<H> (2^k)\<rfloor>,2^k)" using zero_less_Fract_iff by auto 
      hence Q1: "{} <\<^sup>\<real> h . ?k" using hk Ratless Qzero by auto
      hence "{} \<le>\<^sup>\<real> h . ?k" using real_0_th_33 by mty auto
      hence [ty]:"(h. ?k) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_Q by mty auto
      hence "{} in seq2Dedekind(h)" using seq2Dedekind[of h "{}"] Q1 bexI[of _ ?k] by mty auto
      thus "{} in  seq2Dedekind(\<hh>2\<ss>seq(r))" using h by auto
qed 

text_raw {*\DefineSnippet{h2s_R}{*}
function h2sR :: "real \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>\<real>'(_')")where
  "x > 0  \<Longrightarrow> \<hh>2\<ss>\<^sub>\<real>(x) = GLUED(seq2Dedekind(\<hh>2\<ss>seq(x)))"
| "x =\<^sub>\<H> 0 \<Longrightarrow> \<hh>2\<ss>\<^sub>\<real>(x) = 0\<^sub>\<S>"
| "x < 0 \<Longrightarrow> \<hh>2\<ss>\<^sub>\<real>(x) = -\<^sub>\<S>\<^sup>\<real> GLUED(seq2Dedekind(\<hh>2\<ss>seq(-\<^sub>\<H> x)))"
text_raw {*}%EndSnippet*}
proof(auto)
  fix P 
  fix x::real assume AS: "\<And>xa. 0 < xa \<Longrightarrow> x =\<^sub>\<H> xa \<Longrightarrow> P"
           " x =\<^sub>\<H> 0 \<Longrightarrow> P" 
           "\<And>xa. xa < 0 \<Longrightarrow> x =\<^sub>\<H> xa \<Longrightarrow> P"
  have "0 < x or x =\<^sub>\<H> 0 or 0 > x" by auto
  thus "P" using AS by auto
qed

termination
  apply standard 
  apply auto done

theorem h2sRprop:
  "\<hh>2\<ss>\<^sub>\<real>(x) is MReal"
proof(cases "x >0")
  have [ty]: "seq2Dedekind(\<hh>2\<ss>seq(x)) is Element-of DEDEKIND_CUTS" using seq2D by auto
  case True
    hence "\<hh>2\<ss>\<^sub>\<real>(x) = GLUED(seq2Dedekind(\<hh>2\<ss>seq(x)))" using h2sR.simps(1) by auto
    thus "\<hh>2\<ss>\<^sub>\<real>(x) is MReal" by mty auto
  next
    case F:False
    show "\<hh>2\<ss>\<^sub>\<real>(x) is MReal"
    proof(cases "x=\<^sub>\<H> 0")
      case True
      thus "\<hh>2\<ss>\<^sub>\<real>(x) is MReal" using h2sR.simps(2) by mty auto
    next
     have [ty]: "seq2Dedekind(\<hh>2\<ss>seq(-\<^sub>\<H> x)) is Element-of DEDEKIND_CUTS" using seq2D by auto
      case False
        hence "x<0" using F by auto
        hence "\<hh>2\<ss>\<^sub>\<real>(x) = (-\<^sub>\<S>\<^sup>\<real> GLUED(seq2Dedekind(\<hh>2\<ss>seq(-\<^sub>\<H> x))))" using h2sR.simps(3) by auto
        thus "\<hh>2\<ss>\<^sub>\<real>(x) is MReal" by mty auto
      qed
qed
theorem s2hR_positive:
  "r > 0 \<Longrightarrow> \<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>( r )) =\<^sub>\<H> r"
proof-
  assume ASr: "r >0"
  have [ty]:"\<hh>2\<ss>seq(r) is Function-of NAT, RAT"using SeqProp by auto
  let ?D = "seq2Dedekind(\<hh>2\<ss>seq(r))"
  have [ty]: "?D is (Element-of DEDEKIND_CUTS)\<bar>set" using seq2D all_set by auto
  have "GLUED(?D) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by  mty auto
  then obtain G where  [ty]:"G is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
     G: "G = GLUED(?D)" by mty auto 
  have "{} in ?D" using ASr non_empty_seq2D by mty auto
  hence "?D<>{}" using xb by mty auto
  hence gE: "G <>{}" using arytm_2_lm_11 G by mty auto
  hence [ty]: "G is non empty" using xboole_0_lm_1 by mty auto
  have CD: "Real.cauchy (\<ss>2\<hh>seq(rC G))" using seqCauchy by auto
  have "Real.vanishes (\<lambda>n. real2seqL(r,n) -\<^sub>\<H> \<ss>2\<hh>seq(rC G)(n))" 
  proof(rule vanishesI)
     fix e::rat assume AS: "0 < e"
     then obtain k::nat where 
       n: "(1 / e) < (rat_of_nat(k))" using reals_Archimedean2 by blast
     hence "1  < (2 ^ k) *\<^sub>\<H> e"
       using divide_less_eq less_trans of_nat_less_two_power AS by metis 
     hence r: "1/(2 ^ k)  <  e"
       using AS by (simp add: divide_less_eq power_commuting_commutes)
     show "\<exists>\<^sub>Lk. \<forall>n\<ge>k. \<bar>real2seqL(r, n) -\<^sub>\<H> \<ss>2\<hh>seq(rC G )(n)\<bar> < e" 
     proof(rule exI[of _ k],rule allI,rule impI)
       fix n assume kn: "k \<le> n"      
       have "h2sn(n) is Nat" using I2Mprop by auto
       then obtain nn where [ty]:"nn is Nat" and
              nn:  "nn = h2sn(n)" by auto
      let ?nD="( 2\<^sub>\<S> |^ nn) *\<^sub>D (DEDEKIND_CUT G)"
       have nD1: "DEDEKIND_CUT G<>{}" "2\<^sub>\<S> |^ nn<>{}"  using newton_th_7 gE arytm_2_lm_10 by mty auto
       hence nD: "?nD <>{}" using  arytm_th_1 by mty auto
       have [ty]: "(rC G). nn is Rat" by mty auto
       have "(rC G). nn = (max\<^sub>\<nat> ( ?nD)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ nn)" using Rat2C by auto
       hence C1: "( (rC G). nn) *\<^sub>\<S>\<^sup>\<real> (2\<^sub>\<S> |^ nn) = max\<^sub>\<nat> ( ?nD)"
            using nD1 rat_1_th_6 by mty auto
      have d:"DEDEKIND_CUT G = ?D" using G arytm_2_lm_12[of ?D] by mty auto
      have [ty]: "DEDEKIND_CUT G is Element-of DEDEKIND_CUTS"  by mty auto
      have "max\<^sub>\<nat> (?nD) in ( ?nD)"
        using maxN nD by mty auto
      hence H1: "max\<^sub>\<nat> ( ?nD) in  
          { ( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in DEDEKIND_CUT G}"
        using arytm_def_1[of "2\<^sub>\<S> |^ nn" "DEDEKIND_CUT G"] nD1 by mty auto
      obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
        s: "max\<^sub>\<nat> ( ?nD) = ( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s &   
         s in DEDEKIND_CUT G" using Fraenkel_A1_ex[OF _ _ H1] by mty auto
       have A1:"real2seqL(r, n) =\<^sub>\<H> Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n)" using real2seqL_def by auto
       have A2:"Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n)*\<^sub>\<H> (2^n)  =\<^sub>\<H> \<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> " using Fract_of_int_quotient by auto
         have a2: "Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n)*\<^sub>\<H> (2^n) =\<^sub>\<H> rat_of_int (\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)"
            using A2 of_rat_eq_iff by fastforce        
       have B1:"\<ss>2\<hh>seq(rC G)(n) =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<rat>( (rC G). nn)" using s2hseq_def \<ss>2\<hh>f_def[of s2hQ h2sn] nn by mty auto
         have "s2hQ (2\<^sub>\<S> |^ nn) =\<^sub>\<H> s2hZ(2\<^sub>\<S> |^ nn)" using s2hQZ[of "2\<^sub>\<S> |^ nn"] by mty auto
         also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(2\<^sub>\<S>) ^ \<ss>2\<hh>\<^sub>\<nat>(nn)" using powerM[of "2\<^sub>\<S>" nn] by mty auto
         also have "... =\<^sub>\<H> 2 ^ \<ss>2\<hh>\<^sub>\<nat>(nn)" using Two_Three_Four s2hZ.simps(2) by mty auto
         also have "... =\<^sub>\<H> 2 ^ n" using IMIprop[of n] nn by auto  
         finally have B2: "s2hQ (2\<^sub>\<S> |^ nn) =\<^sub>\<H> 2 ^ n"
           by (metis of_rat_eq_iff of_rat_numeral_eq of_rat_power)         
         hence  "2\<^sub>\<S> |^ nn = \<hh>2\<ss>\<^sub>\<rat>(rat_of_int(2^n))" using MIMQprop[of "2\<^sub>\<S> |^ nn"] by mty auto
         hence b2:"2\<^sub>\<S> |^ nn = h2sZ(2^n)" using s2hQr[of "2^n"] by auto   
          have "\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> \<ge> 0" using ASr by auto 
          hence "h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) = \<hh>2\<ss>\<^sub>\<nat>(nat(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>))" by auto 
          hence [ty]:"h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) is Nat" using I2Mprop by auto        
          have "h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) +\<^sub>\<S>\<^sup>\<real>  (succ {}) = \<hh>2\<ss>\<^sub>\<rat>(rat_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)) +\<^sub>\<S>\<^sup>\<real>  \<hh>2\<ss>\<^sub>\<rat>(rat_of_int(1))" 
            using s2hQr[of "\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>"] s2hQr[of 1] by auto
          hence C2: "h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) +\<^sub>\<S>\<^sup>\<real>  (succ {}) = \<hh>2\<ss>\<^sub>\<rat>(rat_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1))" using RatAddI by simp
        have "real2seqL(r, n) \<ge> \<ss>2\<hh>seq(rC G )(n)"
        proof(rule ccontr)
          have "s in ?D" using d s by auto
          then obtain w where [ty]:"w is Nat" and
            w: "s <\<^sup>\<real>  (\<hh>2\<ss>seq(r)).w" using seq2Dedekind[of "\<hh>2\<ss>seq(r)"] by mty auto
          let ?w = "s2hn (w)"
          have "(\<hh>2\<ss>seq(r)). w = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(r) ) . h2sn(?w)" using h2sseq_def 
              MIMprop by mty auto
          hence "(\<hh>2\<ss>seq(r)). w = \<hh>2\<ss>\<^sub>\<rat>(real2seqL(r)(?w)) " using HtoSappl[OF beIsoS_NAT beIsoS_RAT]
            by auto
          hence hw: "(\<hh>2\<ss>seq(r)) . w = \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>r *\<^sub>\<H> (2^?w)\<rfloor>,2^?w))" using real2seqL_def by auto
          have "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(s)) <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>r *\<^sub>\<H> (2^?w)\<rfloor>,2^?w))" using w hw MIMQprop[of s] by mty auto
          hence C3: "\<ss>2\<hh>\<^sub>\<rat>(s) <  Fract(\<lfloor>r *\<^sub>\<H> (2^?w)\<rfloor>,2^?w)" using Ratless by auto
          assume "not (real2seqL(r, n) \<ge> \<ss>2\<hh>seq(rC G )(n))"
          hence "Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n)*\<^sub>\<H> (2^n) < \<ss>2\<hh>\<^sub>\<rat>( (rC G). nn) *\<^sub>\<H> s2hQ (2\<^sub>\<S> |^ nn)" 
            using A1 B1 B2 by auto
          hence "rat_of_int (\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) < \<ss>2\<hh>\<^sub>\<rat>( (rC G). nn) *\<^sub>\<H> s2hQ (2\<^sub>\<S> |^ nn)" 
            using a2 by auto
          hence "(rat_of_int (\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)) < \<ss>2\<hh>\<^sub>\<rat>(( (rC G). nn) *\<^sub>\<S>\<^sup>\<real> (2\<^sub>\<S> |^ nn))" 
            using RatMultM[of "2\<^sub>\<S> |^ nn" "(rC G). nn"]  by mty auto
 
          hence "h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) <\<^sup>\<real> ( max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ nn) *\<^sub>D (DEDEKIND_CUT G)))" 
            using Ratless MIMQprop s2hQr[of "\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>"] C1 by mty auto
         hence "h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>) +\<^sub>\<S>\<^sup>\<real>  (succ {})  \<le>\<^sup>\<real> ( max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ nn) *\<^sub>D (DEDEKIND_CUT G)))" 
           using nat_1_th_13[of "h2sZ(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>)" "max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ nn) *\<^sub>D (DEDEKIND_CUT G))"]  
            by mty auto
          hence "\<hh>2\<ss>\<^sub>\<rat>(rat_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1))  
               \<le>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>( max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ nn) *\<^sub>D (DEDEKIND_CUT G))))" 
           using C2 MIMQprop[of "max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ nn) *\<^sub>D (DEDEKIND_CUT G))"] by mty auto
         hence "rat_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1) \<le> \<ss>2\<hh>\<^sub>\<rat>( ( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^sup>\<real> s)"
           using Rateq s real_0_def_7[of "2\<^sub>\<S> |^ nn"  s] Prat_Preal_mult by mty auto
       hence "rat_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1) \<le> 2 ^ n *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(s)"
           using RatMultM[of s "2\<^sub>\<S> |^ nn"] B2 by mty auto
        hence "rat_of_int(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1)/ (2 ^ n) \<le>  \<ss>2\<hh>\<^sub>\<rat>(s)"
          by (simp add: divide_le_eq mult.commute)
        hence "Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1,2 ^ n) \<le>  \<ss>2\<hh>\<^sub>\<rat>(s)"
          by (simp add: Fract_of_int_quotient)
        hence "Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor> +\<^sub>\<H> 1,2 ^ n) <  Fract(\<lfloor>r *\<^sub>\<H> (2^?w)\<rfloor>,2^?w)" using C3 by linarith 
        thus False using upper_bound[of r ?w n] by auto
        qed
        hence TH1: "\<bar>real2seqL(r, n) -\<^sub>\<H> \<ss>2\<hh>seq(rC G )(n)\<bar> =\<^sub>\<H> 
              real2seqL(r, n) -\<^sub>\<H> \<ss>2\<hh>seq(rC G )(n)"
          by auto
        have "s2hZ(succ {}) =\<^sub>\<H> 1"
          using  Zero_One s2hZ.simps(2)[of "succ {}"] by mty auto
        hence ONE: "\<ss>2\<hh>\<^sub>\<rat>(succ{}) =\<^sub>\<H> 1" using s2hQZ[of "succ {}"] by mty auto
     
        have H2: "1 / rat_of_int(2 ^ n ) \<le> 1 / rat_of_int(2 ^ k)" 
          using kn by (simp add: divide_left_mono)

        
        have "real2seqL(r, n) \<le> \<ss>2\<hh>seq(rC G )(n) +\<^sub>\<H> Fract(1,2 ^ n)"
        proof(rule ccontr)
          assume AS3:"not real2seqL(r, n) \<le> \<ss>2\<hh>seq(rC G )(n) +\<^sub>\<H> Fract(1,2 ^ n)"
            have "(\<hh>2\<ss>seq(r)). nn = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(r) ) . h2sn(n)" using h2sseq_def 
                   MIMprop nn by mty auto
            hence hw: "(\<hh>2\<ss>seq(r)) . nn = \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n))" 
              using real2seqL_def HtoSappl[OF beIsoS_NAT beIsoS_RAT] by auto   
            have T:"(rC G). nn is Rat" "((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ nn)) is Rat" by mty auto
            have "\<ss>2\<hh>\<^sub>\<rat>( (rC G). nn ) +\<^sub>\<H> Fract(1,2 ^ n) =\<^sub>\<H>
                \<ss>2\<hh>\<^sub>\<rat>( (rC G). nn ) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(h2sZ(1) /\<^sub>\<rat> h2sZ(2 ^ n))" using s2hQI[of "2 ^ n" 1] by auto
            also have "... =\<^sub>\<H>\<ss>2\<hh>\<^sub>\<rat>( (rC G). nn ) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ nn))"     
               using b2 by auto
            also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(   ( (rC G). nn ) +\<^sub>\<S>\<^sup>\<real>   ((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ nn)) )"
              using RatAddM[OF T(2,1)]  by auto
            also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(   ( (rC G). nn ) +\<^sub>\<S>\<^sup>\<real>   ((succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ nn)) )"
              using rat_1_div by mty auto
            also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(   ( (rC G). nn ) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ nn)) )"
              using real_0_def_4 Prat_Preal_add by mty auto
            finally have  H: "\<hh>2\<ss>\<^sub>\<rat>((\<ss>2\<hh>\<^sub>\<rat>( (rC G). nn ) +\<^sub>\<H> Fract(1,2 ^ n))) =
                   ((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn)) " 
              using MIMQprop[of "( (rC G). nn ) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ nn))"] by mty auto          
             have "Fract(\<lfloor>r *\<^sub>\<H> (2^n)\<rfloor>,2^n) > 
                        (\<ss>2\<hh>\<^sub>\<rat>( (rC G). nn ) +\<^sub>\<H> Fract(1,2 ^ n))"
            using A1 B1 B2 AS3 by auto
            hence "((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn)) <\<^sup>\<real> (\<hh>2\<ss>seq(r)) . nn" 
              using Ratless hw H by auto
            hence "((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn)) in ?D" 
               using seq2Dedekind[of "\<hh>2\<ss>seq(r)" "((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn))"] bexI[of _ nn] by mty auto
           hence "((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn)) in DEDEKIND_CUT G" using d by auto 
            hence "( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn))) in
               { ( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in DEDEKIND_CUT G}"
              using Fraenkel_A1_in by mty auto
            hence Y1:"( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn))) in
              ?nD" using arytm_def_1 nD1  by mty auto                   
            have "( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(((rC G). nn) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn))) =
          (( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((rC G). nn)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn)))"
              using arytm_3_th_57[of _ "(rC G). nn" " 2\<^sub>\<S> |^ nn"] by mty auto
            also have "... =
          (( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((rC G). nn)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  
                 ( ((succ {})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ nn)) *\<^sub>\<S>\<^sup>\<real> ( 2\<^sub>\<S> |^ nn))" 
              using rat_1_div[of "succ {}" "2\<^sub>\<S> |^ nn"] 
                  real_0_def_7[of "2\<^sub>\<S> |^ nn" "(succ {})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ nn)"] Prat_Preal_mult
                  real_0_th_21[of "2\<^sub>\<S> |^ nn" "(succ {})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ nn)"] by mty auto
            also have "... =
             (( 2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((rC G). nn)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  
                 ( succ {})" using rat_1_th_6[OF _ _  nD1(2)] by mty auto
            also have "... = (max\<^sub>\<nat>(?nD)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( succ {})" 
              using C1 real_0_def_7 real_0_th_21[of " 2\<^sub>\<S> |^ nn"] Prat_Preal_mult by mty auto
            finally have  "(max\<^sub>\<nat>(?nD)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( succ {}) in ?nD" using Y1 by auto
            hence "(max\<^sub>\<nat>(?nD))+\<^sub>\<S>\<^sup>\<nat> ( succ {}) in ?nD"  
              using arytm_3_th_58  by mty auto
            hence "(max\<^sub>\<nat>(?nD))+\<^sub>\<S>\<^sup>\<nat> ( succ {}) \<subseteq> max\<^sub>\<nat>(?nD)" 
              using nD maxN[of ?nD] by mty auto
         hence "succ(max\<^sub>\<nat>(?nD)) \<subseteq> max\<^sub>\<nat>(?nD)" 
              using Add_5 by mty auto
            thus False using ordinal1_th_1[of "succ(max\<^sub>\<nat>(?nD))" "max\<^sub>\<nat>(?nD)"] 
         ordinal1_th_2[of "max\<^sub>\<nat>(?nD)"] by mty auto
          qed
        hence "real2seqL(r, n) -\<^sub>\<H> \<ss>2\<hh>seq(rC G )(n) \<le> 
         1 / rat_of_int(2 ^ n)" by (simp add: Fract_of_int_quotient) 
        thus "\<bar>real2seqL(r, n) -\<^sub>\<H> \<ss>2\<hh>seq(rC G )(n)\<bar><e" using TH1 r H2 by auto      
      qed
   qed
  hence "Real.Real(real2seqL(r)) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC G))" 
    using eq_Real[OF real_lower_bound CD, of r] by auto
  hence "r =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(G)" using real2seq_prop[of r] gE s2hR.simps[of G] by auto
  thus "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> r" using G ASr by auto
qed

theorem IMIRprop:
  "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> r"
proof(cases "r>0")
  case True
    thus "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> r" using s2hR_positive by auto
  next
  case F:False
    show "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> r"
    proof(cases "r=\<^sub>\<H>0")
      case True
      thus "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> r" using h2sR.simps(2) s2hR.simps(3) by mty auto
    next              
      case F1:False
        have r: "r<0" "-\<^sub>\<H> r >0" using F F1 by auto
        obtain S where [ty]:"S is (Element-of DEDEKIND_CUTS)\<bar>set" and 
         S: "S=seq2Dedekind(\<hh>2\<ss>seq(-\<^sub>\<H> r))" using seq2D all_set by auto
        have [ty]:"(GLUED S) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
        have "{} in S" using r S non_empty_seq2D by mty auto
        hence "S<>{}" using xb by mty auto
        hence gE: "GLUED S <>{}" using arytm_2_lm_11 by mty auto
        hence gE1: "(-\<^sub>\<S>\<^sup>\<real> (GLUED S)) <> {}" 
          using real_0_th_18 real_0_th_20a[of "GLUED S"] by mty auto
        have [ty]:"(-\<^sub>\<S>\<^sup>\<real> GLUED S) is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
          using real_0_th_19[of "GLUED S",simplified] gE by mty auto 
        have "\<hh>2\<ss>\<^sub>\<real>(-\<^sub>\<H> r) =  ( GLUED S)" using h2sR.simps(1) r S by auto
        hence S1: "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(-\<^sub>\<H> r)) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC ( GLUED S) ))" 
          using s2hR.simps(2) gE by mty auto
        have "\<hh>2\<ss>\<^sub>\<real>(r) = (-\<^sub>\<S>\<^sup>\<real> GLUED S)" using S h2sR.simps(3) r by auto         
        hence "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> -\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>( GLUED S) ))))" 
          using s2hR.simps(4) gE1 by mty auto
        hence "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> -\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(-\<^sub>\<H> r))" 
          using S1 real_0_th_20a[of "GLUED S"] by mty auto
        thus "\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(r)) =\<^sub>\<H> r " using r s2hR_positive[of "-\<^sub>\<H> r"]  by auto
      qed
qed


theorem s2hseq_monotone:
  "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> k is Nat \<Longrightarrow> n is Nat \<Longrightarrow>
   k \<subseteq> n \<Longrightarrow> r <>{} \<Longrightarrow> \<ss>2\<hh>seq(rC r)(s2hn(k)) \<le> \<ss>2\<hh>seq(rC r)(s2hn(n))"
proof-
   let ?D="DEDEKIND_CUT r"
  assume [ty]: "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> " "k is Nat" "n is Nat"
  and nk: "k \<subseteq> n" and r:"r<>{}"
  hence D: "?D <>{}" and [ty]: " r is non empty" 
      using arytm_2_lm_10 xboole_0_lm_1 by mty auto
    have K2: "2\<^sub>\<S> |^ k <>{}" using newton_th_7 by mty auto
  hence K3: "(2\<^sub>\<S> |^ k) *\<^sub>D (DEDEKIND_CUT r)<>{}" using D arytm_th_1 by mty auto 
  have C: "Real.cauchy(\<ss>2\<hh>seq(rC r))" using seqCauchy by mty auto
    let ?kD="(2\<^sub>\<S> |^ k) *\<^sub>D ?D"                      
         have "k \<subseteq> n" using nk less_eqI MIMprop by auto
         then obtain kk where [ty]:"kk be Nat" and
          k: "  n = k +\<^sub>\<S>\<^sup>\<nat> kk" using Add_9 by mty auto
         have k1: "n = kk +\<^sub>\<S>\<^sup>\<nat> k" using  Add_6[of k kk] k by mty auto
         hence nk:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ kk)"
           using  newton_th_6a[of kk k] k by mty auto
         hence nk1:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<real> (2\<^sub>\<S> |^ kk)"       
           using int_1_def_5[of "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ kk"] Prat_Preal_mult[of "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ kk"]
             arytm_3_th_59[of "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ kk"]  by mty auto
         have Nk:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ kk)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ k)"
           using  newton_th_6a[of k kk] k Add_6 by mty auto
         have DD:"2\<^sub>\<S> |^ n <>{}" "2\<^sub>\<S> |^ kk <>{}"
           using newton_th_7 by mty auto
         let ?nD="(2\<^sub>\<S> |^ n) *\<^sub>D ?D"   
         have DD1: "?kD <>{}" using arytm_th_1[OF _ _ D K2 ]  by mty auto
         have DD2: "?nD = (2\<^sub>\<S> |^ kk)  *\<^sub>D (?kD)"
           using arytm_def_1M[of ?D "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ kk"] DD Nk K2 by mty auto
         have "(2\<^sub>\<S> |^ kk) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?kD) =  (max\<^sub>\<nat> ?kD)*\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ kk)" 
           using Mult_6[of "2\<^sub>\<S> |^ kk"] by mty auto
         hence "((2\<^sub>\<S> |^ kk) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?kD))/\<^sub>\<rat>(2\<^sub>\<S> |^ n) = 
          ( (max\<^sub>\<nat> ?kD) *\<^sub>\<S>\<^sup>\<real> (2\<^sub>\<S> |^ kk))/\<^sub>\<rat>((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<real> (2\<^sub>\<S> |^ kk))" using nk1 int_1_def_5  
           by mty auto   
         hence HH: "((2\<^sub>\<S> |^ kk) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?kD))/\<^sub>\<rat>(2\<^sub>\<S> |^ n) =
           (max\<^sub>\<nat> ?kD)/\<^sub>\<rat>(2\<^sub>\<S> |^ k)" using rat_1_th_44[of "max\<^sub>\<nat> ?kD" "2\<^sub>\<S> |^ kk" "2\<^sub>\<S> |^ k"] DD K2 by mty auto    
         have  "(2\<^sub>\<S> |^ kk) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?kD) \<subseteq>  (max\<^sub>\<nat> ?nD) "
           using DD1 DD arytm_th_4 DD2 by mty auto
         hence "((2\<^sub>\<S> |^ kk) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?kD))/\<^sub>\<rat>(2\<^sub>\<S> |^ n) \<le>\<^sup>\<real> (max\<^sub>\<nat> ?nD) /\<^sub>\<rat> (2\<^sub>\<S> |^ n)"
           using rat_1_th_23 DD by mty auto
         hence "(max\<^sub>\<nat> ?kD)/\<^sub>\<rat>(2\<^sub>\<S> |^ k) \<le>\<^sup>\<real> (max\<^sub>\<nat> ?nD) /\<^sub>\<rat> (2\<^sub>\<S> |^ n)"
           using HH by auto
   hence "(rC r ).(k) \<le>\<^sup>\<real> (rC r ).(n)" 
           using Rat2C by mty auto
   hence "(\<ss>2\<hh>\<^sub>\<rat>((rC r ).k)) \<le> (\<ss>2\<hh>\<^sub>\<rat>((rC r ).n))" 
           using MIMQprop Rateq by mty auto
   hence "(\<ss>2\<hh>\<^sub>\<rat>((rC r ).h2sn(s2hn(k)))) \<le> (\<ss>2\<hh>\<^sub>\<rat>((rC r ).h2sn(s2hn(n))))" 
           using MIMprop  by mty auto
         thus "\<ss>2\<hh>seq(rC r)(s2hn(k)) \<le> \<ss>2\<hh>seq(rC r)(s2hn(n))"
     unfolding s2hseq_def \<ss>2\<hh>f_def by mty auto      
qed

theorem h2rR_positive1:
  "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> r <>{} \<Longrightarrow> \<ss>2\<hh>\<^sub>\<real>(r) > 0"
proof-
  let ?D="DEDEKIND_CUT r"
  assume [ty]:"r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and r:"r<>{}"
  hence D: "?D <>{}" and [ty]: " r is non empty" 
      using arytm_2_lm_10 xboole_0_lm_1 by mty auto
  have "?D in DEDEKIND_CUTS" using Element(7) by mty auto
  then obtain x where [ty]: "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
   x:   "x in ?D & x <>{} " 
    using D arytm_2_lm_15[of ?D] by mty auto
  obtain k where [ty]:"k be Nat" and
    k: "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x" using x arytm_th_10[of x] by mty auto
  have K2: "2\<^sub>\<S> |^ k <>{}" using newton_th_7 by mty auto
  hence K3: "(2\<^sub>\<S> |^ k) *\<^sub>D (DEDEKIND_CUT r)<>{}" using D arytm_th_1 by mty auto 
  have C: "Real.cauchy(\<ss>2\<hh>seq(rC r))" using seqCauchy by mty auto
    let ?kD="(2\<^sub>\<S> |^ k) *\<^sub>D ?D"
  have "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)\<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x" using arytm_3_th_68 k by mty auto
  hence "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k) in (DEDEKIND_CUT r)"
    using arytm_2_lm_7f[of "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)" x "DEDEKIND_CUT r"] x by mty auto
  hence "( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)) in 
      { ( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in (DEDEKIND_CUT r)}" 
    using Fraenkel_A1_in by mty auto
  hence "(1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S>|^k) in ( 2\<^sub>\<S> |^ k) *\<^sub>D (DEDEKIND_CUT r)"
    using arytm_def_1[of "2\<^sub>\<S>|^k" "DEDEKIND_CUT r"] K2 arytm_3_def_12c[of "2\<^sub>\<S>|^k"] by mty auto
  hence "1\<^sub>\<S> in ( 2\<^sub>\<S> |^ k) *\<^sub>D (DEDEKIND_CUT r)" using arytm_3_TH2 K2 by mty auto
  hence "1\<^sub>\<S> \<subseteq>  (max\<^sub>\<nat> ( ?kD))" using maxN[OF _  K3] by mty auto
  hence "1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k) \<le>\<^sup>\<real>  (max\<^sub>\<nat> ( ?kD))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)" 
    using rat_1_th_23[OF _ _ _ K2] by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)) \<le>  \<ss>2\<hh>\<^sub>\<rat>((max\<^sub>\<nat> ( ?kD))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ k))"
    using Rateq MIMQprop by mty auto
   hence "\<ss>2\<hh>\<^sub>\<rat>(1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)) \<le>  \<ss>2\<hh>\<^sub>\<rat>((max\<^sub>\<nat> ( ?kD))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ k))"
     using Rateq MIMQprop by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)) \<le>  \<ss>2\<hh>\<^sub>\<rat>((rC r ).(h2sn(s2hn(k))))"
           using Rat2C MIMprop[of k] by auto
  hence LL:"\<ss>2\<hh>\<^sub>\<rat>(1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)) \<le> \<ss>2\<hh>seq(rC r)(s2hn(k))"
           unfolding s2hseq_def \<ss>2\<hh>f_def MIMprop by auto

  have "{}<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)" using arytm_3_TH4 K2 by mty auto
  hence "{} <\<^sup>\<real> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)" using rat_0_th_29 by mty auto 
  hence "0 < \<ss>2\<hh>\<^sub>\<rat>(1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k))" using Ratless MIMQprop Qzero by mty auto
  then obtain Lim::rat where
   Lim: "0 < Lim " " Lim < \<ss>2\<hh>\<^sub>\<rat>(1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k))"
  using field_lbound_gt_zero rat_1_div[of "1\<^sub>\<S> " " 2\<^sub>\<S> |^ k"] by mty auto 
  hence L: "Lim < \<ss>2\<hh>seq(rC r)(s2hn(k))" using LL by auto
  
  have "Real.positive (Real.Real (\<ss>2\<hh>seq(rC r)))"
  proof(rule positive_Real[OF C,THEN iffD2], rule exI[of _ "Lim"], 
      rule conjI)
       show ZZ: "0 < Lim" using Lim by simp
       show "\<exists>\<^sub>Lka. \<forall>n\<ge>ka. Lim < \<ss>2\<hh>seq(rC r )(n)"
       proof(rule exI[of _ "s2hn(k)"],rule allI,rule impI)
         fix n::nat
         assume nk: "s2hn(k)\<le> n"
         let ?n= "h2sn(n)"
         have [ty]:"?n is Nat" using I2Mprop by auto
         have "k \<subseteq> ?n" using nk less_eqI MIMprop by auto

         hence "\<ss>2\<hh>seq(rC r )(s2hn(k)) \<le> \<ss>2\<hh>seq(rC r )(s2hn(?n))" 
           using s2hseq_monotone r by auto
         thus "Lim < \<ss>2\<hh>seq(rC r)(n)" using L IMIprop[of n] by auto        
       qed  
     qed
  hence "Real.Real (\<ss>2\<hh>seq(rC r))>0" by (simp add: less_real_def) 
  thus "\<ss>2\<hh>\<^sub>\<real>(r)>0" using s2hR.simps(2) r by mty auto
qed


theorem h2rR_positive2:
  "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> k is Nat \<Longrightarrow> r <>{} \<Longrightarrow> of_rat(\<ss>2\<hh>seq(rC r)(s2hn(k))) \<le> \<ss>2\<hh>\<^sub>\<real>(r)"
proof- 
  assume [ty]:"r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "k is Nat" and r:"r<>{}"
  hence [ty]: " r is non empty" using  xboole_0_lm_1 by mty auto

  let ?L="\<lambda>n. \<ss>2\<hh>seq(rC r)(s2hn(k))"
  have H1: "Real.cauchy(?L)" "Real.cauchy (\<ss>2\<hh>seq(rC r))" using seqCauchy by mty auto

  have "Real.Real(?L) \<le> Real.Real(\<ss>2\<hh>seq(rC r))" 
  proof(rule le_Real[OF H1, THEN iffD2],rule allI, rule impI)
    fix ra::rat
    assume ra: "0 < ra"
    show "\<exists>\<^sub>Lka. \<forall>n\<ge>ka. \<ss>2\<hh>seq(rC r )(\<ss>2\<hh>\<^sub>\<nat>(k)) \<le> \<ss>2\<hh>seq(rC r )(n) +\<^sub>\<H> ra"
    proof(rule exI[of _ "s2hn(k)"],intro allI impI)
      fix n :: nat
      have [ty]: "h2sn(n) is Nat" using I2Mprop by auto
      assume "\<ss>2\<hh>\<^sub>\<nat>(k) \<le> n"
      hence "\<ss>2\<hh>\<^sub>\<nat>(k) \<le> s2hn(h2sn(n))" using IMIprop by auto
      hence "k \<subseteq> h2sn(n)" using less_eqM by mty auto
      hence "\<ss>2\<hh>seq(rC r)(s2hn(k)) \<le> \<ss>2\<hh>seq(rC r)(s2hn(h2sn(n)))" 
        using s2hseq_monotone r  by mty auto
      hence "\<ss>2\<hh>seq(rC r)(s2hn(k)) \<le> \<ss>2\<hh>seq(rC r)(n)" 
        using IMIprop  by mty auto
      thus "\<ss>2\<hh>seq(rC r )(\<ss>2\<hh>\<^sub>\<nat>(k)) \<le> \<ss>2\<hh>seq(rC r )(n) +\<^sub>\<H> ra" using ra
        by linarith 
    qed
  qed
  hence "Real.Real(?L) \<le> \<ss>2\<hh>\<^sub>\<real>(r)" "Real.Real(?L) =\<^sub>\<H> of_rat( \<ss>2\<hh>seq(rC r)(s2hn(k)))"
       using s2hR.simps r of_rat_Real by mty auto
  thus "real_of_rat(\<ss>2\<hh>seq(rC r )(\<ss>2\<hh>\<^sub>\<nat>(k))) \<le> \<ss>2\<hh>\<^sub>\<real>(r)"   by auto 
qed

theorem h2rR_positive:
  "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> r <>{} \<Longrightarrow> \<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r"
proof-
  assume [ty]:"r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and r: "r<>{}"
  hence [ty]: " r is non empty" using  xboole_0_lm_1 r by mty auto
  have s2h: "Real.Real (\<ss>2\<hh>seq(rC r)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(r)" using s2hR.simps r by auto
    let ?D="DEDEKIND_CUT r"
    have "?D in DEDEKIND_CUTS" using Element(7) by mty auto
    hence B:"?D in IR" 
      using arytm_2_def_1 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}" ?D] all_set 
      by mty auto
    obtain D where [ty]:"D is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
      D1: "?D = D"  and
      D2:"for t be Element-of RAT\<^bsup>\<ge>0\<^bsub> st t in D holds 
      (for s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s
 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t holds s in D) & 
        (ex s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s in D & t<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s)" 
      using  Fraenkel_A1_ex[OF _ _ B] by mty auto
    have [ty]: "D is Element-of  DEDEKIND_CUTS" using D1 by mty auto
    have [ty]:"\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r)) is Function-of NAT,RAT" using SeqProp by mty auto
    have DD2: "s2hZ( 2\<^sub>\<S>) =\<^sub>\<H>2" using Two_Three_Four by mty auto 
    have T1: "D c= seq2Dedekind(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r)))" 
      proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
        fix y assume y:"y in D" 
        hence [ty]:"y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[of y] by mty auto
        obtain x where [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
          x: "x in D & y<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x" using D2[THEN bspec,of y] y by mty auto
        hence "y <\<^sup>\<real> x" using rat_0_th_29 by mty auto
        hence yx: "\<ss>2\<hh>\<^sub>\<rat>(y) < \<ss>2\<hh>\<^sub>\<rat>(x)" using Ratless MIMQprop by mty auto 
        obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
          s: "s in D & x<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s" using D2[THEN bspec,of x] x by mty auto
        obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
          z: "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z =s & z <>{}" using arytm_3_def_13l s by mty auto
        then obtain k where [ty]:"k is Nat" and 
          k: "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z" using arytm_th_12[of "1\<^sub>\<S>" z] 
          by mty auto
        have k2: " 2\<^sub>\<S> |^ k <>{}" using newton_th_7 by mty auto
        have d: "D <>{}" using x xb by mty auto
        hence d2:" (2\<^sub>\<S> |^ k)*\<^sub>D D<>{}" using k2 arytm_th_1 by mty auto
        have " ( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s in {( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> w where w be Element-of RAT\<^bsup>\<ge>0\<^bsub>: w in D}"
          using s Fraenkel_A1_in by mty auto
        hence  ss: "( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s in ( 2\<^sub>\<S> |^ k) *\<^sub>D D" 
          using arytm_def_1[of "2\<^sub>\<S> |^ k" D] k2 by mty auto
        obtain L where [ty]: "L is Nat" and
          L: "x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)\<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>L & L<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>((x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>)"
          using rat_1_th_25[of "x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)"] by mty auto
        have K2: "s2hZ( 2\<^sub>\<S> |^ k) =\<^sub>\<H> s2hZ( 2\<^sub>\<S>) ^ s2hn(k)" using powerM[of "2\<^sub>\<S>" k]  by mty auto
        hence sh: "s2hZ( 2\<^sub>\<S> |^ k)>0" "s2hZ( 2\<^sub>\<S> |^ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>( 2\<^sub>\<S> |^ k)" 
          using D2 s2hQZ[of "2\<^sub>\<S> |^ k"] by mty auto
        have [ty]:"L is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto    
        have "s2hZ(L) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(L)" "s2hZ(2\<^sub>\<S> |^ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(2\<^sub>\<S> |^ k)" 
          using s2hQZ[of "2\<^sub>\<S> |^ k"] s2hQZ[of L] by mty auto   
        hence RR: "real_of_int(s2hZ(L)) =\<^sub>\<H> real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(L))" 
            "real_of_int(s2hZ(2\<^sub>\<S> |^ k)) =\<^sub>\<H> real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(2\<^sub>\<S> |^ k))" 
          by (smt of_rat_eq_iff of_rat_of_int_eq)+    
        have "x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k) \<le>\<^sup>\<real> L" using L rat_0_th_29 by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(x*\<^sub>\<S>\<^sup>\<real> ( 2\<^sub>\<S> |^ k)) \<le> \<ss>2\<hh>\<^sub>\<rat>(L)" using 
            Rateq MIMQprop real_0_def_7[of x "2\<^sub>\<S> |^ k"] Prat_Preal_mult by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>( ( 2\<^sub>\<S> |^ k)) \<le> \<ss>2\<hh>\<^sub>\<rat>(L)" using RatMultM[of "2\<^sub>\<S> |^ k" x] by mty auto
        hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>( ( 2\<^sub>\<S> |^ k))) \<le> real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(L))"
          by (simp add: of_rat_less_eq)
        hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) *\<^sub>\<H> real_of_rat(\<ss>2\<hh>\<^sub>\<rat>( ( 2\<^sub>\<S> |^ k))) \<le> real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(L))"
          by (simp add: of_rat_mult)
        hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) \<le> real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(L)) / real_of_rat(\<ss>2\<hh>\<^sub>\<rat>( ( 2\<^sub>\<S> |^ k)))"
          using sh by (metis RR(2) mult_imp_le_div_pos of_int_0_less_iff) 
        hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) \<le> real_of_rat (Fract(s2hZ(L),s2hZ( ( 2\<^sub>\<S> |^ k))))"  
          using RR by (simp add: Fract_of_int_quotient of_rat_divide) 
        hence xx: "\<ss>2\<hh>\<^sub>\<rat>(x) \<le> Fract(s2hZ(L),s2hZ( ( 2\<^sub>\<S> |^ k)))" 
          using of_rat_less_eq by blast
        have  "(1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s"
          using arytm_3_th_76[of "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)" x z] arytm_3_def_11c[of x z] z k by mty auto
        hence "((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)"
          using k2 arytm_3_th_80[of _ s "2\<^sub>\<S> |^ k"] by mty auto
        hence "((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k))<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)"
          using arytm_3_th_57s by mty auto
        hence "1\<^sub>\<S> +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k))<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)"
          using k2 arytm_3_TH2[of "1\<^sub>\<S>" "2\<^sub>\<S> |^ k"] by mty auto
        hence "(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S><\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)" using arytm_3_def_11c by mty auto
        hence "L<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)" using arytm_3_th_70[of "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)" L
              "(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" ]  L by mty auto
        hence "L \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_12c arytm_3_th_68 by mty auto
        hence "L in ( 2\<^sub>\<S> |^ k) *\<^sub>D D" using arytm_2_lm_7f[of L "( 2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] ss by mty auto
        hence "L \<subseteq> max\<^sub>\<nat> (( 2\<^sub>\<S> |^ k) *\<^sub>D D)" using maxN d2 by mty auto  
        hence "L  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k) \<le>\<^sup>\<real> (max\<^sub>\<nat> (( 2\<^sub>\<S> |^ k) *\<^sub>D D)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)" 
          using rat_1_th_23 k2 by mty auto
        hence "L  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k) \<le>\<^sup>\<real> (rC r) . k" using Rat2C[of r k] D1 by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(L  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k)) \<le> \<ss>2\<hh>\<^sub>\<rat>((rC r) . k)" using Rateq MIMQprop by mty auto
        hence FF: "Fract(s2hZ(L),  s2hZ( 2\<^sub>\<S> |^ k)) \<le> \<ss>2\<hh>\<^sub>\<rat>((rC r) . k)" 
          using s2hQM[of L "2\<^sub>\<S> |^ k"] k2 by mty auto
        have App: "(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))). k = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(\<ss>2\<hh>\<^sub>\<real>(r)) ) . h2sn(s2hn(k))" 
          using h2sseq_def MIMprop by mty auto
        have "(\<ss>2\<hh>seq(rC r))(s2hn(k)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>((rC r) . k)" using
          \<ss>2\<hh>f_def[of s2hQ h2sn] s2hseq_def MIMprop[of k] by mty auto
        hence "of_rat(\<ss>2\<hh>\<^sub>\<rat>((rC r) . k)) \<le> \<ss>2\<hh>\<^sub>\<real>(r)" using 
         h2rR_positive2[of r k] r by auto 
        hence "of_rat(Fract(s2hZ(L), s2hZ( 2\<^sub>\<S> |^ k))) \<le> \<ss>2\<hh>\<^sub>\<real>(r)" using FF
          using dual_order.trans of_rat_less_eq by blast
        hence "s2hZ(L) / s2hZ( 2\<^sub>\<S> |^ k) \<le> \<ss>2\<hh>\<^sub>\<real>(r)" 
          by (simp add: Fract_of_int_quotient of_rat_divide) 
        hence "s2hZ(L) \<le> \<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> s2hZ( 2\<^sub>\<S> |^ k)"using sh
          using of_int_0_less_iff pos_divide_le_eq by blast       
        hence "s2hZ(L) \<le> \<lfloor> \<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> s2hZ( 2\<^sub>\<S> |^ k)\<rfloor>"
          using le_floor_iff by blast 
        hence "Fract(s2hZ(L), s2hZ( 2\<^sub>\<S> |^ k))\<le> Fract( \<lfloor> \<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2 ^ s2hn(k))\<rfloor>,
          2 ^ s2hn(k))" using sh DD2 K2 by auto
        hence "Fract(s2hZ(L), s2hZ( 2\<^sub>\<S> |^ k)) \<le> real2seqL(\<ss>2\<hh>\<^sub>\<real>(r))(s2hn(k))"using real2seqL_def
          by auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(x) \<le> real2seqL(\<ss>2\<hh>\<^sub>\<real>(r))(s2hn(k))" using xx
          using dual_order.trans by blast 
        hence "\<ss>2\<hh>\<^sub>\<rat>(y) < real2seqL(\<ss>2\<hh>\<^sub>\<real>(r))(s2hn(k))" using yx
          using dual_order.strict_trans1 by blast
        hence "y <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(real2seqL(\<ss>2\<hh>\<^sub>\<real>(r))(s2hn(k)))" using Ratless MIMQprop[of y] by mty auto  
        hence "y <\<^sup>\<real> (\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))). k" using HtoSappl[OF beIsoS_NAT beIsoS_RAT] h2sseq_def 
            App by auto
        thus "y in seq2Dedekind(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r)))" 
          using seq2Dedekind[of "\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))" y] bexI[of _ k] by mty auto
      qed auto
    have "seq2Dedekind(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))) \<subseteq> D" 
     proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
       fix x assume x: "x in seq2Dedekind(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r)))"
       hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
       obtain k where [ty]:"k be Nat" and
          k:  "x <\<^sup>\<real> \<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r)). k" using seq2Dedekind x by mty auto
       let ?k="s2hn(k)"
       let ?x = "\<ss>2\<hh>\<^sub>\<rat>(x)"
       have K2: "s2hZ( 2\<^sub>\<S> |^ k) =\<^sub>\<H> s2hZ( 2\<^sub>\<S>) ^ ?k" using powerM[of "2\<^sub>\<S>" k]  by mty auto
        hence sh: "s2hZ( 2\<^sub>\<S> |^ k)>0" "s2hZ( 2\<^sub>\<S> |^ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>( 2\<^sub>\<S> |^ k)" 
          using D2 s2hQZ[of "2\<^sub>\<S> |^ k"] by mty auto
       have App: "(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))). k = \<hh>2\<ss>f(s2hn,h2sQ,NAT,real2seqL(\<ss>2\<hh>\<^sub>\<real>(r)) ) . h2sn(?k)"
          using h2sseq_def MIMprop by mty auto
       hence "(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))). k = \<hh>2\<ss>\<^sub>\<rat>(real2seqL(\<ss>2\<hh>\<^sub>\<real>(r))(?k))" 
       using HtoSappl[OF beIsoS_NAT beIsoS_RAT] h2sseq_def 
            App by auto
      hence "x <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(Fract(\<lfloor>\<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2^?k)\<rfloor>,2^?k))" using real2seqL_def k by auto
      hence "\<ss>2\<hh>\<^sub>\<rat>(x) < Fract(\<lfloor>\<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2^?k)\<rfloor>,2^?k)" using Ratless MIMQprop by mty auto
      hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) < real_of_rat(Fract(\<lfloor>\<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2^?k)\<rfloor>,2^?k))"
        using of_rat_less by blast
      hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) < real_of_int(\<lfloor>\<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2^?k)\<rfloor>) / real_of_int(2^?k)"
        by (metis Fract_of_int_quotient of_rat_divide of_rat_of_int_eq) 
      hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x))*\<^sub>\<H> real_of_int(2^?k) < real_of_int(\<lfloor>\<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2^?k)\<rfloor>)"
        by (simp add: pos_less_divide_eq)
      hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x))*\<^sub>\<H> real_of_int(2^?k) < (\<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> (2^?k))"
        by linarith 
      hence "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) < Real.Real (\<ss>2\<hh>seq(rC r))" using s2h by auto
      then obtain n::nat where
        nn: "real_of_rat(\<ss>2\<hh>\<^sub>\<rat>(x)) < of_rat (\<ss>2\<hh>seq(rC r) (n))" using less_RealD seqCauchy[of r] by mty auto
      let ?n = "h2sn(n)"
      have [ty]: "?n is Nat" using I2Mprop by auto
      have N1:"2\<^sub>\<S> |^ ?n <>{}" using newton_th_7 by mty auto
      have "\<ss>2\<hh>\<^sub>\<rat>(x) < \<ss>2\<hh>seq(rC r) (n)" using nn by (simp add: of_rat_less)
      hence "x <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>seq(rC r) (n))" using Ratless MIMQprop by mty auto
      hence "x <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>((rC r).(?n)))" using s2hseq_def[of "rC r"] 
         \<ss>2\<hh>f_def[of s2hQ h2sn] by mty auto
      hence "x <\<^sup>\<real> (rC r).(?n)" using MIMQprop by mty auto
      hence "x <\<^sup>\<real> (max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?n)" using D1 Rat2C[of r ?n] by mty auto
      hence "x<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?n)" using rat_0_th_29[of x] 
                  rat_1_div[of _ " 2\<^sub>\<S> |^ ?n"] by mty auto
      hence "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ ?n)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>((max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?n)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ ?n)" 
        using arytm_3_th_80[of x "(max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?n)" "2\<^sub>\<S> |^ ?n"] N1
        by mty auto
      hence "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ ?n)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>((max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?n)) *\<^sub>\<S>\<^sup>\<real> ( 2\<^sub>\<S> |^ ?n)"
        using real_0_def_7[of "(max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?n)" "2\<^sub>\<S> |^ ?n"]
        rat_1_div[of _ " 2\<^sub>\<S> |^ ?n"] Prat_Preal_mult by mty auto
     hence xn: "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ ?n)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)"
        using rat_1_th_6 N1 by mty auto

      have "D<>{}" using arytm_2_lm_10[of r] D1 r by mty auto
      hence "( 2\<^sub>\<S> |^ ?n) *\<^sub>D D<>{}" using arytm_th_1 N1 by mty auto
      hence "max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D) in ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D)" using maxN by mty auto
      hence m:"max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D) in 
         { ( 2\<^sub>\<S> |^ ?n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in D}" using arytm_def_1 N1 by mty auto
      obtain s where [ty]: "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        s: "max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ ?n) *\<^sub>D D) = ( 2\<^sub>\<S> |^ ?n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "s in D" using Fraenkel_A1_ex[OF _ _ m] by mty auto
      hence "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ ?n)<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( 2\<^sub>\<S> |^ ?n)" using xn arytm_3_def_12c[of s] by mty auto 
      hence "x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s " using  arytm_3_th_82[of "2\<^sub>\<S> |^ ?n" x s] by mty auto 
      hence "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s " using  arytm_3_th_68 by mty auto 
      thus "x in D" using s arytm_2_lm_7f[of x s D] by mty auto
    qed mauto
    hence T0: "seq2Dedekind(\<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(r))) = D" using T1 xboole_0_def_10[OF all_set all_set] 
      by mty auto
  have  "\<ss>2\<hh>\<^sub>\<real>(r) > 0" using r h2rR_positive1 by auto
  hence "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = GLUED ?D" using T0 D1 h2sR.simps(1) by auto
  thus "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r" using arytm_2_lm_23 by mty auto
qed

theorem MIMRprop:
  "r is Mreal \<Longrightarrow> \<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r"
proof-
  assume [ty]:"r is Mreal" 
  show "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r"
  proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & r <>{}")
    case True
    thus "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r" using h2rR_positive by auto
  next
    case F:False
       show "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r"
       proof(cases "r ={}") 
         case T1: True
         thus "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r" using T1 h2sR.simps(2) s2hR.simps(3) by mty auto
       next
         case F1: False
         hence [ty]:"r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F by mty auto
         hence [ty]: "(-\<^sub>\<S>\<^sup>\<real> r) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto

         have H1: "\<ss>2\<hh>\<^sub>\<real>(r) =\<^sub>\<H> -\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC -\<^sub>\<S>\<^sup>\<real> r ))"using s2hR.simps(4)[of r] F1 by mty auto

         have H2: "(-\<^sub>\<S>\<^sup>\<real> r) <>{}" using real_0_th_20a[of r] real_0_th_18 F1 by mty auto
         hence H3: "\<ss>2\<hh>\<^sub>\<real>(-\<^sub>\<S>\<^sup>\<real> r) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC -\<^sub>\<S>\<^sup>\<real> r ))" 
                "\<ss>2\<hh>\<^sub>\<real>(-\<^sub>\<S>\<^sup>\<real> r) >0"using s2hR.simps(2) h2rR_positive1 by mty auto
         hence "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = (-\<^sub>\<S>\<^sup>\<real> (GLUED(seq2Dedekind(
              \<hh>2\<ss>seq(\<ss>2\<hh>\<^sub>\<real>(-\<^sub>\<S>\<^sup>\<real> r))))))" using h2sR.simps(3) H1 by auto
         hence "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = (-\<^sub>\<S>\<^sup>\<real> (\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(-\<^sub>\<S>\<^sup>\<real> r))))" using h2sR.simps(1) H3 by auto
         hence "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r))" using h2rR_positive H2 by auto
         thus "\<hh>2\<ss>\<^sub>\<real>(\<ss>2\<hh>\<^sub>\<real>(r)) = r" using real_0_th_20a by mty auto
       qed
     qed
   qed




theorem Rpositive_add_positive:
  assumes [ty]:"i is MReal" "j is MReal"
  shows "{} \<le>\<^sup>\<real> i & {} \<le>\<^sup>\<real> j implies s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)"
proof
  assume T1: "{} \<le>\<^sup>\<real> i & {} \<le>\<^sup>\<real> j"
  hence [ty]:"i is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "j is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  
  show "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)"
  proof(cases " i={} or j={}")
    case True
    thus "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)" 
        using real_0_th_8 real_0_def_4 by mty auto
    next
      case F:False
       hence [ty]:"i is non empty" "j is non empty" using xboole_0_lm_1 by mty auto
       have R: "i +\<^sub>\<S>\<^sup>\<real> j = i +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> j" using real_0_def_4 by mty auto
       hence [ty]:"(i +\<^sub>\<S>\<^sup>\<real> j) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and ij: "i +\<^sub>\<S>\<^sup>\<real> j <>{}" using arytm_2_th_5[of j i] F by mty auto
       hence [ty]:"(i +\<^sub>\<S>\<^sup>\<real> j) is non empty"  using xboole_0_lm_1 by mty auto
       have E1: "s2hR(i) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC i))" "s2hR(j) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC j))"
            "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC (i +\<^sub>\<S>\<^sup>\<real> j)))"
        using F ij by auto
      have "(rC i) (+) (rC j) is Cauchy\<^sub>\<S>" by mty auto
      hence CS: "Real.cauchy( \<ss>2\<hh>seq( (rC i) (+) (rC j)))" using MICauchy[of "(rC i) (+) (rC j)"]
        by mty auto
      have C: "Real.cauchy (\<ss>2\<hh>seq(rC i))" "Real.cauchy (\<ss>2\<hh>seq(rC j))" 
           "Real.cauchy (\<ss>2\<hh>seq(rC (i+\<^sub>\<S>\<^sup>\<real> j)))"
               using seqCauchy by auto
      have  "s2hR(i) +\<^sub>\<H> s2hR(j) =\<^sub>\<H> Real.Real(\<lambda>n. (\<ss>2\<hh>seq(rC i))(n) +\<^sub>\<H> (\<ss>2\<hh>seq(rC j))(n))"
        using add_Real[OF C(1,2) ] E1 by auto
      hence SA:"s2hR(i) +\<^sub>\<H> s2hR(j) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq( (rC i) (+) (rC j)))" using seqAdd by mty auto
      have "( rC (i +\<^sub>\<S>\<^sup>\<real> j)) (-) ( (rC i) (+) (rC j)) is vanishes\<^sub>\<rat>" 
        using R AddV[of j i] by mty auto
      hence "Real.vanishes(\<ss>2\<hh>seq( ( rC (i+\<^sub>\<S>\<^sup>\<real> j)) (-) ( (rC i) (+) (rC j))))" 
        using MIvanishesQ by mty auto
      hence "Real.vanishes (\<lambda>n. (\<ss>2\<hh>seq(rC (i +\<^sub>\<S>\<^sup>\<real> j))) (n) -\<^sub>\<H> (\<ss>2\<hh>seq( (rC i) (+) (rC j)))( n))"
        using seqMinus by mty auto     
      thus " s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j) "
          using eq_Real[OF C(3) CS] SA E1(3)by auto
      qed
qed

theorem RMinus:
  assumes [ty]:"i is MReal"
  shows "s2hR(-\<^sub>\<S>\<^sup>\<real> i) =\<^sub>\<H> -\<^sub>\<H> s2hR(i)"
proof(cases "{} <\<^sup>\<real> i")
  case T:True
  hence I: "{} \<le>\<^sup>\<real> i & {}<>i" using real_0_th_33 by mty auto
  hence I1: "(-\<^sub>\<S>\<^sup>\<real> i) <>{}" using real_0_th_18 real_0_th_20a[of i] by mty auto
  have [ty]:"i is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using I real_0_R by mty auto
  hence [ty]:"not (-\<^sub>\<S>\<^sup>\<real> i) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using I I1 real_0_th_20a[of i] real_0_th_19[of "-\<^sub>\<S>\<^sup>\<real> i"]
    by mty auto
  hence "s2hR(-\<^sub>\<S>\<^sup>\<real> i) =\<^sub>\<H> -\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC (i)))" 
    using I1 s2hR.psimps(4) real_0_th_20a[of i] by mty auto
  thus "s2hR(-\<^sub>\<S>\<^sup>\<real> i) =\<^sub>\<H> -\<^sub>\<H> s2hR(i)" using  s2hR.psimps(2)[of i] I by mty auto
next
  case F: False
  show "s2hR(-\<^sub>\<S>\<^sup>\<real> i) =\<^sub>\<H> -\<^sub>\<H> s2hR(i)"
proof(cases "{} <\<^sup>\<real> -\<^sub>\<S>\<^sup>\<real> i")
  case T:True
 
  hence I: "{} \<le>\<^sup>\<real> -\<^sub>\<S>\<^sup>\<real> i & {}<> (-\<^sub>\<S>\<^sup>\<real> i)" using real_0_th_33 by mty auto
  hence I1: "(i) <>{}" using real_0_th_18 real_0_th_20a[of i] by mty auto
  have [ty]:"(-\<^sub>\<S>\<^sup>\<real> i) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using I real_0_R by mty auto
  hence [ty]:"not i is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using I I1 real_0_th_20a[of i] real_0_th_19[of "-\<^sub>\<S>\<^sup>\<real> i"]
    by mty auto
  have "s2hR(i) =\<^sub>\<H> -\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC (-\<^sub>\<S>\<^sup>\<real> i)))" 
    using I1 real_0_th_20a[of i] by mty auto
  thus "s2hR(-\<^sub>\<S>\<^sup>\<real> i) =\<^sub>\<H> -\<^sub>\<H> s2hR(i)" using  s2hR.psimps(2)[of i] I by mty auto
next
  case F1:False
  hence " (-\<^sub>\<S>\<^sup>\<real> i) \<le>\<^sup>\<real> {}" "i \<le>\<^sup>\<real> {}" using F by auto
  hence "{} \<le>\<^sup>\<real> i" "i \<le>\<^sup>\<real> {}" using real_0_th_30[of "{}" "-\<^sub>\<S>\<^sup>\<real> i"] 
    real_0_th_20a[of i] real_0_th_18 by mty auto
  hence "i={}" "(-\<^sub>\<S>\<^sup>\<real> i) = {}" using real_0_def_8s[of i "{}"] real_0_th_18 by mty auto
  thus "s2hR(-\<^sub>\<S>\<^sup>\<real> i) =\<^sub>\<H> -\<^sub>\<H> s2hR(i)" by mty auto
qed
qed

theorem Rpositive_add_negative:
   assumes [ty]:"i is MReal" "j is MReal"
  shows "{} \<le>\<^sup>\<real> i &  j <\<^sup>\<real> {} implies s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)"
proof
  assume AS: "{} \<le>\<^sup>\<real> i  \<and> j <\<^sup>\<real> {}"
  hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j " using real_0_th_30 by mty auto
  hence AS1: "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j" using real_0_th_33 real_0_th_18 by mty auto

  show "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)"
  proof(cases "{} \<le>\<^sup>\<real> i +\<^sub>\<S>\<^sup>\<real> j")
    case T: True
    have "(i +\<^sub>\<S>\<^sup>\<real> j) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j) = i" using real_0_def_5[of j] real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real> j" "j"]
     real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real> j" j  i] real_0_th_8 by mty auto
    hence "s2hR(i)   =\<^sub>\<H> s2hR(i +\<^sub>\<S>\<^sup>\<real> j) +\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> j)"
        using Rpositive_add_positive[of "i +\<^sub>\<S>\<^sup>\<real> j" "-\<^sub>\<S>\<^sup>\<real> j"] T AS1 by mty auto
      thus "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)" using RMinus by mty auto
    next
      case False
         hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> (i+\<^sub>\<S>\<^sup>\<real> j) " using real_0_th_30 by mty auto
        hence I:"{}\<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (i +\<^sub>\<S>\<^sup>\<real> j))" using  real_0_th_33 real_0_th_18 by mty auto
      have "(-\<^sub>\<S>\<^sup>\<real> (i +\<^sub>\<S>\<^sup>\<real> j)) +\<^sub>\<S>\<^sup>\<real> i = ((-\<^sub>\<S>\<^sup>\<real> j) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> i)) +\<^sub>\<S>\<^sup>\<real> i" using real_0_th_20 real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real> i" "-\<^sub>\<S>\<^sup>\<real> j"]
        by mty auto      
      hence "(-\<^sub>\<S>\<^sup>\<real> (i +\<^sub>\<S>\<^sup>\<real> j)) +\<^sub>\<S>\<^sup>\<real> i = (-\<^sub>\<S>\<^sup>\<real> j)" using real_0_def_5[of i] 
         real_0_th_15[of "i" "-\<^sub>\<S>\<^sup>\<real> i"  "-\<^sub>\<S>\<^sup>\<real> j"] real_0_th_8 by mty auto
      hence "s2hR(-\<^sub>\<S>\<^sup>\<real> j)   =\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> (i +\<^sub>\<S>\<^sup>\<real> j)) +\<^sub>\<H> s2hR(i)"
        using Rpositive_add_positive[of "-\<^sub>\<S>\<^sup>\<real>(i +\<^sub>\<S>\<^sup>\<real> j)" "i"] I AS by mty auto
     thus "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)" using RMinus by mty auto
  qed
qed


theorem Rnegative_add_positive:
   assumes [ty]:"i is MReal" "j is MReal"
  shows "{} \<le>\<^sup>\<real> j &  i <\<^sup>\<real> {} implies s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)"
proof
  assume AS: "{} \<le>\<^sup>\<real> j  \<and> i <\<^sup>\<real> {}"
  hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> i " using real_0_th_30 by mty auto
  hence AS1: "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> i" using real_0_th_33 real_0_th_18 by mty auto
  have IJ: "i +\<^sub>\<S>\<^sup>\<real> j = j +\<^sub>\<S>\<^sup>\<real> i" using real_0_th_11 by mty auto
  show "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)"
  proof(cases "{} \<le>\<^sup>\<real> j +\<^sub>\<S>\<^sup>\<real> i")
    case T: True
    have "(j +\<^sub>\<S>\<^sup>\<real> i) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> i) = j" using real_0_def_5[of i] real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real> i" "i"]
     real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real> i" i  j] real_0_th_8 by mty auto
    hence "s2hR(j)   =\<^sub>\<H> s2hR(j +\<^sub>\<S>\<^sup>\<real> i) +\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> i)"
        using Rpositive_add_positive[of "j +\<^sub>\<S>\<^sup>\<real> i" "-\<^sub>\<S>\<^sup>\<real> i"] T AS1 by mty auto
      thus "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)" using RMinus IJ by mty auto
    next
      case False
         hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> (j+\<^sub>\<S>\<^sup>\<real> i) " using real_0_th_30 by mty auto
        hence I:"{}\<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (j +\<^sub>\<S>\<^sup>\<real> i))" using  real_0_th_33 real_0_th_18 by mty auto
        have "(-\<^sub>\<S>\<^sup>\<real> (j +\<^sub>\<S>\<^sup>\<real> i)) +\<^sub>\<S>\<^sup>\<real> j = ((-\<^sub>\<S>\<^sup>\<real> i) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)) +\<^sub>\<S>\<^sup>\<real> j" 
          using real_0_th_20 real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real> j" "-\<^sub>\<S>\<^sup>\<real> i"]
        by mty auto      
      hence "(-\<^sub>\<S>\<^sup>\<real> (j +\<^sub>\<S>\<^sup>\<real> i)) +\<^sub>\<S>\<^sup>\<real> j = (-\<^sub>\<S>\<^sup>\<real> i)" using real_0_def_5[of j] 
         real_0_th_15[of "j" "-\<^sub>\<S>\<^sup>\<real> j"  "-\<^sub>\<S>\<^sup>\<real> i"] real_0_th_8 by mty auto
      hence "s2hR(-\<^sub>\<S>\<^sup>\<real> i)   =\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> (j +\<^sub>\<S>\<^sup>\<real> i)) +\<^sub>\<H> s2hR(j)"
        using Rpositive_add_positive[of "-\<^sub>\<S>\<^sup>\<real>(j +\<^sub>\<S>\<^sup>\<real> i)" "j"] I AS by mty auto
     thus "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) +\<^sub>\<H> s2hR(j)" using RMinus IJ by mty auto
  qed
qed


theorem AddRealM:
  assumes [ty]:"i is MReal" "j is MReal"
  shows "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i)+\<^sub>\<H>  s2hR(j)"
proof(cases "{}\<le>\<^sup>\<real> i or {}\<le>\<^sup>\<real> j")
  case True
  thus  "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i)+\<^sub>\<H>  s2hR(j)" using Rpositive_add_positive[of i j]
     Rnegative_add_positive[of i j] Rpositive_add_negative[of i j] by mty auto
  next
    case False
      hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> i " " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j " using real_0_th_30 by mty auto
      hence AS1: "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> i" "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j" using real_0_th_33 real_0_th_18 by mty auto
      have "-\<^sub>\<S>\<^sup>\<real> (i +\<^sub>\<S>\<^sup>\<real> j) = (-\<^sub>\<S>\<^sup>\<real> i) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)" using real_0_th_20 by mty auto
      hence "-\<^sub>\<H> s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> i)+\<^sub>\<H>  s2hR(-\<^sub>\<S>\<^sup>\<real> j)" using AS1 RMinus[of "i +\<^sub>\<S>\<^sup>\<real> j"]
         Rpositive_add_positive[of "-\<^sub>\<S>\<^sup>\<real> i" "-\<^sub>\<S>\<^sup>\<real> j"] by mty auto 
      hence "-\<^sub>\<H> s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> (-\<^sub>\<H> s2hR( i))+\<^sub>\<H>  (-\<^sub>\<H> s2hR( j))" using RMinus[of "i"] RMinus[of "j"]
        by auto
      thus  "s2hR(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i)+\<^sub>\<H>  s2hR(j)" by auto
    qed

theorem AddRealI:
  "h2sR(i +\<^sub>\<H> j) = h2sR(i) +\<^sub>\<S>\<^sup>\<real>  h2sR(j)"
proof -
  have [ty]:"h2sR(i) is MReal" "h2sR(j) is MReal" using h2sRprop by auto
  have "s2hR(h2sR(i) +\<^sub>\<S>\<^sup>\<real>  h2sR(j)) =\<^sub>\<H> s2hR(h2sR(i))+\<^sub>\<H>  s2hR(h2sR(j))" using AddRealM by mty auto
  hence "s2hR(h2sR(i) +\<^sub>\<S>\<^sup>\<real>  h2sR(j)) =\<^sub>\<H> i +\<^sub>\<H>  j" using IMIRprop by auto
  thus ?thesis using MIMRprop[of "h2sR(i) +\<^sub>\<S>\<^sup>\<real>  h2sR(j)"] by mty auto 
qed

theorem Rpositive_mult_positive:
  assumes [ty]:"i is MReal" "j is MReal"
  shows "{} \<le>\<^sup>\<real> i & {} \<le>\<^sup>\<real> j implies s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
proof
  assume T1: "{} \<le>\<^sup>\<real> i & {} \<le>\<^sup>\<real> j"
  hence [ty]:"i is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "j is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  
  show "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
  proof(cases " i={} or j={}")
    case True
    thus "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)" 
      using real_0_th_40 by mty auto
    next
      case F:False
       hence [ty]:"i is non empty" "j is non empty" using xboole_0_lm_1 by mty auto
       have R: "i *\<^sub>\<S>\<^sup>\<real> j = i *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> j" using real_0_def_7 by mty auto
       hence [ty]:"(i *\<^sub>\<S>\<^sup>\<real> j) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
           ij: "i *\<^sub>\<S>\<^sup>\<real> j <>{}" using arytm_2_lm_40[of j i] F by mty auto
       hence [ty]:"(i *\<^sub>\<S>\<^sup>\<real> j) is non empty"  using xboole_0_lm_1 by mty auto
       have E1: "s2hR(i) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC i))" "s2hR(j) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC j))"
            "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq(rC (i *\<^sub>\<S>\<^sup>\<real> j)))"
        using F ij by auto
      have "(rC i) (*) (rC j) is Cauchy\<^sub>\<S>" by mty auto
      hence CS: "Real.cauchy( \<ss>2\<hh>seq( (rC i) (*) (rC j)))" using MICauchy[of "(rC i) (*) (rC j)"]
        by mty auto
      have C: "Real.cauchy (\<ss>2\<hh>seq(rC i))" "Real.cauchy (\<ss>2\<hh>seq(rC j))" 
           "Real.cauchy (\<ss>2\<hh>seq(rC (i*\<^sub>\<S>\<^sup>\<real> j)))"
               using seqCauchy by auto
      have  "s2hR(i) *\<^sub>\<H> s2hR(j) =\<^sub>\<H> Real.Real(\<lambda>n. (\<ss>2\<hh>seq(rC i))(n) *\<^sub>\<H> (\<ss>2\<hh>seq(rC j))(n))"
        using mult_Real[OF C(1,2) ] E1 by auto
      hence SA:"s2hR(i) *\<^sub>\<H> s2hR(j) =\<^sub>\<H> Real.Real(\<ss>2\<hh>seq( (rC i) (*) (rC j)))" using seqMult by mty auto
      have "( rC (i *\<^sub>\<S>\<^sup>\<real> j)) (-) ( (rC i) (*) (rC j)) is vanishes\<^sub>\<rat>" 
        using R MultV[of j i] by mty auto
      hence "Real.vanishes(\<ss>2\<hh>seq( ( rC (i*\<^sub>\<S>\<^sup>\<real> j)) (-) ( (rC i) (*) (rC j))))" 
        using MIvanishesQ by mty auto
      hence "Real.vanishes (\<lambda>n. (\<ss>2\<hh>seq(rC (i*\<^sub>\<S>\<^sup>\<real> j))) (n) -\<^sub>\<H> (\<ss>2\<hh>seq( (rC i) (*) (rC j)))( n))"
        using seqMinus by mty auto     
      thus " s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j) "
          using eq_Real[OF C(3) CS] SA E1(3)by auto
      qed
qed


theorem MultRealM:
   assumes [ty]:"i is MReal" "j is MReal"
  shows "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
proof(cases "{}\<le>\<^sup>\<real> i")
  case I1: True
    show "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
      proof(cases "{}\<le>\<^sup>\<real> j")
        case I2: True
        thus "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
          using Rpositive_mult_positive[of i j] I1 by auto
      next
        case AS:False
           hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j " using real_0_th_30 by mty auto
           hence AS1: "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j" using real_0_th_33 real_0_th_18 by mty auto
           have "i *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j) = (-\<^sub>\<S>\<^sup>\<real> ( i *\<^sub>\<S>\<^sup>\<real> j))" using real_0_th_42[of j i] by mty auto
           hence "-\<^sub>\<H> s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR((-\<^sub>\<S>\<^sup>\<real> j))" using I1 AS1 
             Rpositive_mult_positive[of i "-\<^sub>\<S>\<^sup>\<real> j"] RMinus by mty auto
           thus "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
             using RMinus by auto
         qed
  next
    case False
         hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> i " using real_0_th_30 by mty auto
         hence F1: "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> i" using real_0_th_33 real_0_th_18 by mty auto
        show "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
      proof(cases "{}\<le>\<^sup>\<real> j")
        case I2: True
           have "(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<real> j = (-\<^sub>\<S>\<^sup>\<real> ( i *\<^sub>\<S>\<^sup>\<real> j))" using real_0_th_42[of j i] by mty auto
           hence "-\<^sub>\<H> s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<H> s2hR(j)" using F1 I2 
             Rpositive_mult_positive[of "-\<^sub>\<S>\<^sup>\<real> i" j] RMinus by mty auto
           thus "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)"
             using RMinus by auto
         next
         case AS:False
           hence " -\<^sub>\<S>\<^sup>\<real> {} <\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j " using real_0_th_30 by mty auto
           hence AS1: "{} \<le>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real> j" using real_0_th_33 real_0_th_18 by mty auto
           have "(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j) = (-\<^sub>\<S>\<^sup>\<real> ( (-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<real> j))" using real_0_th_42[of j "-\<^sub>\<S>\<^sup>\<real> i"] by mty auto
           hence "(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j) =  (i *\<^sub>\<S>\<^sup>\<real> j)" 
             using real_0_th_42[of j i] real_0_th_20a[of "i *\<^sub>\<S>\<^sup>\<real> j"]  by mty auto
          hence " s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> (-\<^sub>\<H> s2hR(i)) *\<^sub>\<H> -\<^sub>\<H> s2hR(j)" using F1 AS1 
             Rpositive_mult_positive[of "-\<^sub>\<S>\<^sup>\<real> i" "-\<^sub>\<S>\<^sup>\<real> j"] RMinus by mty auto
        thus "s2hR(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> s2hR(i) *\<^sub>\<H> s2hR(j)" by auto
      qed
    qed


theorem MultRealI:
  "h2sR(i *\<^sub>\<H> j) = h2sR(i) *\<^sub>\<S>\<^sup>\<real>  h2sR(j)"
proof -
  have [ty]:"h2sR(i) is MReal" "h2sR(j) is MReal" using h2sRprop by auto
  have "s2hR(h2sR(i) *\<^sub>\<S>\<^sup>\<real>  h2sR(j)) =\<^sub>\<H> s2hR(h2sR(i))*\<^sub>\<H>  s2hR(h2sR(j))" using MultRealM by mty auto
  hence "s2hR(h2sR(i) *\<^sub>\<S>\<^sup>\<real>  h2sR(j)) =\<^sub>\<H> i *\<^sub>\<H> j" using IMIRprop by auto
  thus ?thesis using MIMRprop[of "h2sR(i) *\<^sub>\<S>\<^sup>\<real>  h2sR(j)"] by mty auto 
qed

theorem non_negative_realI:
  " r\<ge>0 \<longleftrightarrow> h2sR(r) is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
proof
  assume AS:"r\<ge>0"
  show "h2sR(r) is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  proof(cases "r=\<^sub>\<H>0")
    case True
    thus  "h2sR(r) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using h2sR.simps(2) by mty auto
  next
    case False
    hence r:"r >0" using AS by auto
    obtain S where [ty]:"S is (Element-of DEDEKIND_CUTS)\<bar>set" and 
         S: "S=seq2Dedekind(\<hh>2\<ss>seq(r))" using seq2D all_set by auto
       hence "h2sR(r) = GLUED S" using h2sR.simps r by mty auto
       thus "h2sR(r) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
     qed
   next
       have Z: "{} is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
       assume TY[ty]:"h2sR(r) is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
       have " h2sR(r) <>{} or h2sR(r)={}" by auto
       hence "0 < \<ss>2\<hh>\<^sub>\<real>(h2sR(r)) or s2hR(h2sR(r)) =\<^sub>\<H> 0" 
         using h2rR_positive1[OF TY] s2hR.simps(3)[
           rule_format,OF Z] by metis  
        hence H:"0 \<le> \<ss>2\<hh>\<^sub>\<real>(h2sR(r))"  by smt
        thus "r \<ge>0" using IMIRprop[of r] by auto
qed

theorem non_negative_realM:
  assumes [ty]:"r is MReal"
  shows "r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<longleftrightarrow> s2hR(r)\<ge>0"
  using non_negative_realI[of "s2hR(r)"] MIMRprop by mty auto

theorem real_lessI:
  "h2sR(i) \<le>\<^sup>\<real> h2sR(j) \<longleftrightarrow> i \<le> j"
proof
  have [ty]:"h2sR(i) is MReal" "h2sR(j) is MReal" using h2sRprop by auto
  assume "h2sR(i) \<le>\<^sup>\<real> h2sR(j)"
  then obtain z where TY[ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
   z: "h2sR(j) = h2sR(i) +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8 by mty auto
  have H:"0 \<le> \<ss>2\<hh>\<^sub>\<real>(z)"  using non_negative_realM[of z] by mty auto
  have "h2sR(j) = h2sR(i  +\<^sub>\<H> s2hR(z))" using z AddRealI MIMRprop by mty auto
  hence "s2hR(h2sR(j)) =\<^sub>\<H> s2hR(h2sR(i  +\<^sub>\<H> s2hR(z)))" by auto
  hence "j =\<^sub>\<H> i  +\<^sub>\<H> s2hR(z)"
    using  IMIRprop[of j] IMIRprop[of "i  +\<^sub>\<H> s2hR(z)"] by auto
  thus "i \<le> j" using H by auto
next assume "i \<le>j"
  then obtain k::real where
    K:  "j =\<^sub>\<H> i +\<^sub>\<H> k" "k \<ge>0"
    by (metis add.commute add_minus_cancel real_0_le_add_iff)  
   have [ty]:"h2sR(i) is MReal" "h2sR(j) is MReal" using h2sRprop by auto
  have [ty]:"h2sR(k) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using K non_negative_realI by mty auto
  have "h2sR(j) = h2sR(i) +\<^sub>\<S>\<^sup>\<real> h2sR(k)" using K AddRealI by mty auto
  thus "h2sR(i) \<le>\<^sup>\<real> h2sR(j)" using real_0_def_8[of "h2sR(i)" "h2sR(j)"] bexI[of _ "h2sR(k)"]
    by mty auto
qed

theorem real_lessM:
  assumes [ty]:"i is MReal" "j is MReal"
  shows "s2hR(i) \<le> s2hR(j) \<longleftrightarrow> i \<le>\<^sup>\<real> j"
  using real_lessI[of "s2hR(i)" "s2hR(j)" ] MIMRprop by mty auto

theorem beIsoT_Real: "beIsoT(h2sR,s2hR,MReal)"
  unfolding beIsoT_def 
proof(intro conjI)
  show "\<forall>\<^sub>Ly. s2hR(h2sR(y)) =\<^sub>\<H> y" using IMIRprop by auto
  show "\<forall>x:MReal. h2sR(s2hR(x)) = x" using MIMRprop by mty auto
  show "\<forall>\<^sub>Ly. h2sR(y) be MReal"  using h2sRprop by auto
qed


text_raw {*\DefineSnippet{RealBeIso}{*}
theorem beIsoS_Real: 
  "beIsoS(h2sR,s2hR,REAL)"
text_raw {*}%EndSnippet*}
by(auto simp add: real_0_def_3 all_set beIsoS_Type_Set(1)[OF _ beIsoT_Real])


theorem interI:
  assumes [ty]:"x be MReal" "y be MReal" "a be MReal"
  shows "a in [. x,y .] iff s2hR(a) \<in> {s2hR(x) .. s2hR(y)}"
proof
  assume "a in [. x,y .]" 
  hence "x \<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y" using xxreal_1_th_1[of y x a] by mty auto
  hence "s2hR(x) \<le>s2hR(a)" "s2hR(a) \<le>s2hR(y)" 
    using real_lessM [of x a] real_lessM [of a y] by mty auto
  thus "s2hR(a) \<in> {s2hR(x) .. s2hR(y)}" by auto
next
  assume "s2hR(a) \<in> {s2hR(x) .. s2hR(y)}"
  hence "s2hR(x) \<le>s2hR(a)" "s2hR(a) \<le>s2hR(y)" by auto
  hence "x \<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y" using real_lessM [of x a] real_lessM [of a y] by mty auto
  thus "a in [. x,y .]" using xxreal_1_th_1[of y x a] by mty auto
qed

theorem interM:
   "h2sR(a) in [. h2sR(x),h2sR(y) .] iff a \<in> {x .. y}"
  using interI[of "h2sR(x)" "h2sR(y)" "h2sR(a)"] IMIRprop h2sRprop by mty auto



theorem real_abs: 
  assumes [ty]:"x is MReal"
  shows "s2hR( |. x .| ) =\<^sub>\<H> \<bar> s2hR(x) \<bar>" 
proof-
  have Z:"s2hR({}) =\<^sub>\<H> 0" by mty auto
  have X: "h2sR(s2hR(x)) = x" "h2sR(s2hR({})) = {}" using MIMRprop by mty auto
  show  "s2hR( |. x .| ) =\<^sub>\<H> \<bar> s2hR(x) \<bar>" 
proof(cases "{}\<le>\<^sup>\<real> x")
  case T:True
    hence "0 \<le> s2hR(x)" using Z X real_lessM[of "{}"] by mty auto
    hence "\<bar> s2hR(x) \<bar> =\<^sub>\<H>  s2hR(x) " "x = |. x .|" 
      using abs_of_nonneg[of "s2hR(x)"] absvalue_def_1[of x] T by mty auto
    thus "s2hR( |. x .| ) =\<^sub>\<H> \<bar> s2hR(x) \<bar>" by auto
  next
    case F:False
    hence " s2hR(x) <0" using Z X real_lessM[of "{}" x] by mty auto
    hence "\<bar> s2hR(x) \<bar> =\<^sub>\<H>  (-\<^sub>\<H> s2hR(x)) " "(-\<^sub>\<S>\<^sup>\<real> x) = |. x .|" 
      using abs_of_neg[of "s2hR(x)"] absvalue_def_1[of x] F by mty auto
    thus "s2hR( |. x .| ) =\<^sub>\<H> \<bar> s2hR(x) \<bar>" using RMinus[of x] by mty auto
  qed
qed


definition \<hh>2\<ss>fR :: "(real \<Rightarrow> real) \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>f\<real> _ ") where
  "\<hh>2\<ss>\<^sub>f\<real>(f) =\<^sub>\<S> \<hh>2\<ss>\<^sub>f(s2hR,h2sR,REAL,f)"

definition \<ss>2\<hh>fR :: "Set \<Rightarrow> (real \<Rightarrow> real)" ("\<ss>2\<hh>\<^sub>f\<real> _ ") where
  "\<ss>2\<hh>\<^sub>f\<real>(f) =\<^sub>\<H> \<ss>2\<hh>\<^sub>f(s2hR,h2sR,f)"

theorem h2sfR_ty:
  "\<hh>2\<ss>\<^sub>f\<real>(f) is Function-of REAL, REAL"
using ItoMprop[OF beIsoS_Real beIsoS_Real] \<hh>2\<ss>fR_def by auto

theorem h2sfR_appI:
  "\<hh>2\<ss>\<^sub>f\<real>(f) . h2sR(x) = h2sR(f(x))"
using HtoSappl[OF beIsoS_Real beIsoS_Real] \<hh>2\<ss>fR_def by auto

theorem h2sfR_appM:
  assumes [ty]:"x be MReal"
  shows "\<hh>2\<ss>\<^sub>f\<real>(f) . x  = h2sR(f(s2hR(x)))"
proof-
  have "h2sR(s2hR(x)) = x" using MIMRprop by mty auto
  thus "\<hh>2\<ss>\<^sub>f\<real>(f) . x  = h2sR(f(s2hR(x)))" using h2sfR_appI[of f "s2hR(x)"] by auto
qed

theorem s2hfR_appI:
  "\<ss>2\<hh>\<^sub>f\<real>(f) (x) =\<^sub>\<H> s2hR(f. h2sR(x))"
proof-
  have [ty]:"h2sR(x) is MReal" using h2sRprop by auto
  hence "h2sR(x) is Element-of REAL" using real_0_def_3 Element(6) by mty auto
  hence "\<ss>2\<hh>\<^sub>f\<real>(f) (\<ss>2\<hh>\<^sub>\<real>(h2sR(x))) =\<^sub>\<H> s2hR(f. h2sR(x))" using MtoIappl[OF beIsoS_Real] \<ss>2\<hh>fR_def
    by mty auto
  thus ?thesis using IMIRprop by auto
qed

theorem s2hfR_appM:
  assumes [ty]:"x is MReal"
  shows "\<ss>2\<hh>\<^sub>f\<real>(f) (s2hR(x)) =\<^sub>\<H> s2hR(f. x)"
proof-
  have "\<ss>2\<hh>\<^sub>f\<real>(f) (s2hR(x)) =\<^sub>\<H> s2hR(f. h2sR(s2hR(x)))" using s2hfR_appI by auto
  thus ?thesis using MIMRprop by mty auto
qed
 
text_raw {*\DefineSnippet{continuous_atI}{*}
theorem continuous_atI:
  fixes f::"real\<Rightarrow>real"
  shows "isCont(f,a) \<longleftrightarrow> (\<hh>2\<ss>\<^sub>f\<real>(f)) is_continuous_in (h2sR(a))"
text_raw {*}%EndSnippet*}
proof(rule iffI3)
  let ?f ="\<hh>2\<ss>\<^sub>f\<real>(f)" let ?a = "h2sR(a)"
  have [ty]:"?f is Function-of REAL, REAL" using h2sfR_ty by mty auto
  have [ty]:"?a is MReal" using h2sRprop by mty auto
  show "isCont( f,a) \<longrightarrow> ?f is_continuous_in ?a" 
    proof(rule impI)
      assume "isCont( f,a)" 
        hence H1: "f \<midarrow>a\<rightarrow> f(a)" using continuous_at by blast
        hence H1: "(\<forall>r>0. \<exists>s>0. \<forall>\<^sub>Lx. not (x =\<^sub>\<H> a) \<and> 
       norm (x -\<^sub>\<H> a) < s \<longrightarrow> norm (f(x) -\<^sub>\<H> f(a)) < r)" using LIM_eq[of f "f(a)" a] by auto
        have " (for r be MReal st {} <\<^sup>\<real> r 
             ( ex s be MReal st {} <\<^sup>\<real> s & (for x1 be MReal st x1 in dom ?f & 
           |. x1 -\<^sub>\<S>\<^sup>\<real> ?a .| <\<^sup>\<real> s holds |. ?f .x1 -\<^sub>\<S>\<^sup>\<real> ?f . ?a .| <\<^sup>\<real> r)))" 
        proof(rule ballI,rule impI)
          fix r assume [ty]:"r be MReal" and r: "{} <\<^sup>\<real> r"
          hence "s2hR({}) < s2hR(r)" using real_lessM[of r "{}"] by mty auto
          hence "0 < s2hR(r)" using s2hR.simps by mty auto
          then obtain s::real where s:"s>0" 
          " \<forall>\<^sub>Lx. not (x =\<^sub>\<H> a) \<and> norm (x -\<^sub>\<H> a) < s \<longrightarrow> norm (f(x) -\<^sub>\<H> f(a)) < s2hR(r)" 
            using LIM_eq[of f "f(a)" a] H1 by auto 
          let ?s="h2sR(s)" have [ty]:"?s is MReal" using h2sRprop by auto
          show "ex s be MReal st {} <\<^sup>\<real> s & (for x1 be MReal st x1 in dom ?f & 
           |. x1 -\<^sub>\<S>\<^sup>\<real> ?a .| <\<^sup>\<real> s holds |. ?f .x1 -\<^sub>\<S>\<^sup>\<real> ?f . ?a .| <\<^sup>\<real> r)"
          proof(intro bexI[of _ ?s] ballI conjI impI)
            show "{} <\<^sup>\<real> ?s" using s(1) h2sR.simps real_lessI[of s 0] by auto
            fix x1 assume [ty]:"x1 is MReal" and  
               x1:"x1 in dom ?f  \<and> |. x1 -\<^sub>\<S>\<^sup>\<real> ?a .| <\<^sup>\<real> ?s"
            let ?x1 = "s2hR(x1)"
            show "|. ?f  . x1 -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .| <\<^sup>\<real> r"
            proof(cases "x1=?a")
              case True
              hence "|. ?f  . x1 -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .| = |. {} .|" using real_1_th_18 by mty auto
              thus "|. ?f  . x1 -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .| <\<^sup>\<real> r" using r absvalue_th_2[of "{}"] by mty auto
            next
              case False
              hence N:"not ?x1 =\<^sub>\<H> a" using MIMRprop[of x1] by mty auto

              have "h2sR(s2hR( |. x1 -\<^sub>\<S>\<^sup>\<real> ?a .| )) <\<^sup>\<real> ?s" using x1 MIMRprop by mty auto
              hence "s2hR( |. x1 -\<^sub>\<S>\<^sup>\<real> ?a .| ) < s" using  real_lessI[of s] by mty auto
              hence " \<bar> s2hR(x1 +\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real> ?a)) \<bar> < s" using real_abs real_0_def_6[of x1 ?a] by mty auto
              hence " \<bar> ?x1 +\<^sub>\<H> (-\<^sub>\<H> s2hR( ?a)) \<bar> < s" using AddRealM[of x1 "-\<^sub>\<S>\<^sup>\<real> ?a"] 
                    RMinus[of ?a] by mty auto
              hence " \<bar> ?x1 -\<^sub>\<H> a \<bar> < s" using IMIRprop by mty auto
              hence "\<bar>f(?x1) -\<^sub>\<H> f(a)\<bar> < s2hR(r)" using N s by auto
              hence "\<bar>s2hR(h2sR(f(?x1))) -\<^sub>\<H> s2hR(h2sR(f(a)))\<bar> < s2hR(r)" using IMIRprop by auto
              hence "\<bar>s2hR(?f .x1) -\<^sub>\<H> s2hR(?f. ?a)\<bar> < s2hR(r)" 
                using h2sfR_appM[of x1 f] h2sfR_appI[of f a] by auto
              hence "\<bar>s2hR((?f .x1) +\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real> (?f. ?a)))\<bar> < s2hR(r)" 
                using RMinus[of "?f. ?a"] AddRealM[of "?f .x1" "-\<^sub>\<S>\<^sup>\<real> (?f. ?a)"]  by mty auto
              hence "s2hR( |. ((?f .x1) -\<^sub>\<S>\<^sup>\<real> (?f. ?a)) .| ) < s2hR(r)" 
                using real_0_def_6 real_abs[of "(?f .x1) -\<^sub>\<S>\<^sup>\<real> (?f. ?a)"] by mty auto
              thus " |. ((?f .x1) -\<^sub>\<S>\<^sup>\<real> (?f. ?a)) .|  <\<^sup>\<real> r" 
                using real_lessM[of r "|. ((?f .x1) -\<^sub>\<S>\<^sup>\<real> (?f. ?a)) .|"]  by mty auto                         
            qed
          qed mauto          
        qed mauto
        thus "?f is_continuous_in ?a" using fcont_1_th_3[of ?a ?f] by mty auto
      qed
  assume AS: "?f is_continuous_in ?a"  
 
  have  H1: "(\<forall>r>0. \<exists>s>0. \<forall>\<^sub>Lx. not (x =\<^sub>\<H> a) \<and> 
       norm (x -\<^sub>\<H> a) < s \<longrightarrow> norm (f(x) -\<^sub>\<H> f(a)) < r)"
  proof(standard,standard)
    fix r::real let ?r = "h2sR(r)" have [ty]:"?r is MReal" using h2sRprop by mty auto
    assume r:"0 < r"
    hence "{} <\<^sup>\<real> ?r" using real_lessI[of r 0] by auto
    then obtain s where [ty]:"s is  MReal" and
       s: "{} <\<^sup>\<real> s "
       "\<forall>x1 : MReal. x1 in dom ?f  \<and> |. x1 -\<^sub>\<S>\<^sup>\<real> ?a .| <\<^sup>\<real> s \<longrightarrow>
                  |. ?f  . x1 -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .| <\<^sup>\<real> ?r" using 
       fcont_1_th_3[of ?a ?f,THEN iffD1,THEN bspec, of ?r] AS by mty auto
    let ?s = "s2hR(s)"  


    show "\<exists>s>0. \<forall>\<^sub>Lx. not_equal(x, a) \<and> norm(x -\<^sub>\<H> a) < s \<longrightarrow> norm(f(x) -\<^sub>\<H> f(a)) < r"
    proof(intro exI[of _ ?s] conjI allI impI)
      show "0 < ?s" using s(1) real_lessM[of s "{}"] by mty auto
      fix x::real let ?x ="h2sR(x)" have [ty]:"?x is MReal" using h2sRprop by mty auto
      have D: "dom ?f =REAL" "?x in REAL" using real_0_def_3[of ?x] using funct_2_th_52 by mty auto

      have "x -\<^sub>\<H> a =\<^sub>\<H> s2hR(?x +\<^sub>\<S>\<^sup>\<real> h2sR(-\<^sub>\<H> s2hR(?a)))" using IMIRprop[of "x -\<^sub>\<H> a"] 
        AddRealI[of x "-\<^sub>\<H> a"] IMIRprop[of a] by auto
      also have "... =\<^sub>\<H> s2hR(?x +\<^sub>\<S>\<^sup>\<real> h2sR(s2hR(-\<^sub>\<S>\<^sup>\<real> ?a)))" using RMinus[of ?a] by mty auto
      also have "... =\<^sub>\<H> s2hR(?x +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ?a))" using MIMRprop[of "-\<^sub>\<S>\<^sup>\<real> ?a"] by mty auto
      finally have F: "x -\<^sub>\<H> a =\<^sub>\<H> s2hR(?x -\<^sub>\<S>\<^sup>\<real> ?a)" using real_0_def_6 by mty auto
      have " s2hR( ?f  . ?x) =\<^sub>\<H> s2hR(\<hh>2\<ss>\<^sub>\<real>(f(\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(x)))))" using 
            h2sfR_appM[of ?x f,simplified ] by auto
      hence X: "s2hR( ?f  . ?x) =\<^sub>\<H> f(x)" using IMIRprop by auto

      have "s2hR( ?f  . ?a )  =\<^sub>\<H> s2hR(\<hh>2\<ss>\<^sub>\<real>(f(\<ss>2\<hh>\<^sub>\<real>(\<hh>2\<ss>\<^sub>\<real>(a)))))" using 
            h2sfR_appM[of ?a f,simplified ] by auto
      hence A: "s2hR( ?f  . ?a) =\<^sub>\<H> f(a)" using IMIRprop by auto
      assume "not_equal(x, a) \<and> norm(x -\<^sub>\<H> a) < ?s"
      hence "h2sR(\<bar> x -\<^sub>\<H> a \<bar>) <\<^sup>\<real> h2sR(?s)" using real_lessI[of ?s "\<bar> x -\<^sub>\<H> a \<bar>"] by auto 
      hence "h2sR(\<bar>s2hR(?x -\<^sub>\<S>\<^sup>\<real> ?a) \<bar>) <\<^sup>\<real> s" using MIMRprop F by mty auto
      hence "|. ?x -\<^sub>\<S>\<^sup>\<real> ?a .|  <\<^sup>\<real> s" using real_abs MIMRprop[of "|. ?x -\<^sub>\<S>\<^sup>\<real> ?a .|"] 
        by mty auto
      hence "|. ?f  . ?x -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .| <\<^sup>\<real> ?r" using s D by mty auto
      hence "s2hR( |. ?f  . ?x -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .| ) < s2hR(?r)" 
        using real_lessM[of ?r "|. ?f  . ?x -\<^sub>\<S>\<^sup>\<real> ?f  . ?a .|" ] by mty auto
      hence "\<bar> s2hR( ?f  . ?x -\<^sub>\<S>\<^sup>\<real> ?f  . ?a ) \<bar> < r" 
        using real_abs IMIRprop[of r] by mty auto
      hence "\<bar> s2hR( ?f  . ?x +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>( ?f  . ?a ))) \<bar> < r" 
        using real_0_def_6 by mty auto
      hence "\<bar> s2hR( ?f  . ?x) -\<^sub>\<H> s2hR( ?f  . ?a ) \<bar> < r" 
        using  AddRealM RMinus[of "?f  . ?a"] by mty auto
      thus "norm( f(x) -\<^sub>\<H> f(a)  ) < r" using  X A by auto       
      qed
  qed
  hence "f \<midarrow>a\<rightarrow> f(a)" using LIM_eq[of f "f(a)" a] by auto
  thus "isCont(f, a)" using continuous_at by blast
qed

text_raw {*\DefineSnippet{continuous_atM}{*}
theorem continuous_atM:
  fixes f a 
  assumes [ty]:"f be Function-of REAL,REAL" "a is MReal"
  shows "isCont(\<ss>2\<hh>\<^sub>f\<real>(f),s2hR(a)) \<longleftrightarrow> f is_continuous_in a"
text_raw {*}%EndSnippet*}
proof-
  have "\<hh>2\<ss>\<^sub>f\<real>(\<ss>2\<hh>\<^sub>f\<real>(f)) = f" using  MIM_fun_prop[OF beIsoS_Real beIsoS_Real] \<hh>2\<ss>fR_def \<ss>2\<hh>fR_def 
    by mty auto
  thus ?thesis using continuous_atI[of "s2hR(a)" "\<ss>2\<hh>\<^sub>f\<real>(f)" ] MIMRprop[of a] by mty auto
qed


text_raw {*\DefineSnippet{real_real_ivt_miz}{*}
theorem IVTmiz:
  "\<forall>f:Function-of REAL,REAL. \<forall>a,b,v:MReal. f. a \<le>\<^sup>\<real> v & v \<le>\<^sup>\<real> f. b & a \<le>\<^sup>\<real> b &
        f is_continuous_on [.a, b.] \<longrightarrow> 
    (\<exists>x:MReal. a \<le>\<^sup>\<real> x & x \<le>\<^sup>\<real> b & f. x = v)"
text_raw {*}%EndSnippet*}
proof(intro ballI impI)
  fix f a b v assume
  [ty]:"f be Function-of REAL, REAL"
       "a be MReal" "b be MReal" "v be MReal"
  and AS:
       "f . a \<le>\<^sup>\<real> v  \<and> v \<le>\<^sup>\<real> f . b  \<and> a \<le>\<^sup>\<real> b  \<and> f  is_continuous_on [. a , b .]"
  let ?f="\<ss>2\<hh>\<^sub>f\<real>(f)" let ?a = "s2hR(a)" let ?b = "s2hR(b)" let ?v = "s2hR(v)"  
  have "?f(?a) =\<^sub>\<H> s2hR(f. a)" "?f(?b) =\<^sub>\<H> s2hR(f. b)" using s2hfR_appM[of _ f ] by mty auto
  hence H1:"?f(?a) \<le> ?v" "?v \<le>?f(?b)" "?a \<le> ?b" using AS real_lessM by mty auto
  have "\<forall>\<^sub>Lx. ?a \<le> x \<and> x \<le> ?b \<longrightarrow> isCont(?f , x)"
  proof(standard,standard)
    fix x::real 
    have [ty]:"h2sR(x) is MReal" using h2sRprop by auto
    assume "?a \<le> x \<and> x \<le> ?b"
    hence "s2hR(h2sR(x)) \<in> {?a .. ?b}" using IMIRprop by auto
    hence "h2sR(x) in [. a,b.]" using interI[of a b] by mty auto
    hence "f is_continuous_in (h2sR(x))" using 
      AS fcont_1_def_3[of f "[. a,b.]"] using all_set by mty auto
    thus "isCont(?f , x)" using continuous_atM[of f "h2sR(x)"] IMIRprop by mty auto
  qed
  thm IVT
  then obtain x::real where 
     x: "x\<ge>?a &  x \<le> ?b & (?f (x) =\<^sub>\<H> ?v)" using IVT[of ?f ?a ?v ?b] H1 by auto
  let ?x="h2sR(x)" 
  have [ty]:"?x is MReal" using h2sRprop by auto
  show "ex x be MReal st a \<le>\<^sup>\<real> x & x \<le>\<^sup>\<real> b & f. x = v"
  proof(rule bexI[of _ ?x], intro conjI)
    show "a\<le>\<^sup>\<real> ?x" "?x\<le>\<^sup>\<real> b" using x real_lessI[of ?a x] real_lessI[of x ?b] MIMRprop by mty auto
    have "?f (x) =\<^sub>\<H> s2hR ( f . ?x) " using s2hfR_appM[of ?x f] IMIRprop by mty auto
    thus "f . ?x =\<^sub>\<S> v" using x MIMRprop[of "f . ?x"] MIMRprop[of v] by mty auto
  qed mauto
qed mauto

text_raw {*\DefineSnippet{real_real_ivt_img}{*}
theorem IVT_img:
  "\<forall>f:Function-of REAL,REAL. \<forall> a,b:MReal. 
        a \<le>\<^sup>\<real> b \<and> f is_continuous_on [.a, b.] \<longrightarrow> 
     (\<exists>c,d:MReal. c \<le>\<^sup>\<real> d \<and> f .: [. a, b .] =\<^sub>\<S> [. c, d .])"
text_raw {*}%EndSnippet*}
proof(intro ballI impI)
    fix f a b assume
  [ty]:"f be Function-of REAL, REAL"
       "a be MReal" "b be MReal" 
  and AS:
       " a \<le>\<^sup>\<real> b  \<and> f  is_continuous_on [. a , b .]"
  let ?f="\<ss>2\<hh>\<^sub>f\<real>(f)" let ?a = "s2hR(a)" let ?b = "s2hR(b)" 
  have H1: "?a \<le> ?b" using AS real_lessM by mty auto
  have "\<forall>\<^sub>Lx. ?a \<le> x \<and> x \<le> ?b \<longrightarrow> isCont(?f , x)"
  proof(standard,standard)
    fix x::real 
    have [ty]:"h2sR(x) is MReal" using h2sRprop by auto
    assume "?a \<le> x \<and> x \<le> ?b"
    hence "s2hR(h2sR(x)) \<in> {?a .. ?b}" using IMIRprop by auto
    hence "h2sR(x) in [. a,b.]" using interI[of a b] by mty auto
    hence "f is_continuous_in (h2sR(x))" using 
      AS fcont_1_def_3[of f "[. a,b.]"] using all_set by mty auto
    thus "isCont(?f , x)" using continuous_atM[of f "h2sR(x)"] IMIRprop by mty auto
  qed
  then obtain L M where
   LM: "(\<forall>\<^sub>Lx. ?a \<le> x \<and> x \<le> ?b \<longrightarrow> L \<le> ?f (x) \<and> ?f (x) \<le> M) \<and>
    (\<forall>\<^sub>Ly. L \<le> y \<and> y \<le> M \<longrightarrow> (\<exists>x\<ge>?a. x \<le> ?b \<and> (?f (x) =\<^sub>\<H> y)))"
    using isCont_Lb_Ub[of ?a ?b ?f] H1 by auto
  let ?L="h2sR(L)" let ?M="h2sR(M)"
  have [ty]:"?L is MReal" "?M is MReal" using h2sRprop by auto
  have [ty]:"f be Function" using all_set by mty auto
  show "ex c,d be MReal st (c \<le>\<^sup>\<real> d & f .: [. a, b .]  = [. c, d .])"
  proof(rule bexI[of _ ?L], rule bexI[of _ ?M], rule conjI)
    have "L \<le> M" using LM H1 by auto
    thus "?L \<le>\<^sup>\<real> ?M" using real_lessI by auto
    have D: "dom f=REAL" using funct_2_th_52 by mty auto
    show "f .: [. a , b .] =\<^sub>\<S> [. ?L , ?M .]"
    proof(intro xboole_0_def_10I[OF all_set all_set] tarski_def_3I[OF all_set all_set] ballI impI)
      fix y assume  "y in f .: [. a , b .]"
      then obtain x where
        x: "x in dom f & x in [. a , b .] & f .x =y" 
           using funct_1_def_6[of f "[. a, b.]" y] all_set by mty auto
      hence [ty]: "x is MReal" using D real_0_def_3 by auto
      let ?x="s2hR(x)"
      have "?x \<in> {?a..?b}" using x interI by auto
      hence "L \<le> ?f (?x) \<and> ?f (?x) \<le> M" using LM by auto
      hence "L \<le> s2hR(f .x)" "s2hR(f .x) \<le> M" using x s2hfR_appM by mty auto
      hence "s2hR(f .x) \<in> {L..M}" by auto
      hence "f .x in [. ?L , ?M .]" 
        using interM[of "s2hR(f .x)" L M] MIMRprop[of "f .x"] x by mty auto
      thus "y in [. ?L , ?M .]"  using x by auto
    next
      fix y assume  y: "y in  [. ?L , ?M .]"
      hence [ty]:"y is Element-of REAL" using ES by mty auto
      have [ty]:"y is MReal" using real_0_def_3 Element(7)by mty auto
      have "h2sR(s2hR(y)) in [. ?L , ?M .]" using y MIMRprop by mty auto  
      hence "s2hR(y) \<in> {L.. M}" using interM by auto 
      then obtain x where 
      x: "x\<ge>?a & x \<le> ?b & (?f (x) =\<^sub>\<H> s2hR(y))" using LM by auto
      have [ty]:"h2sR(x) is MReal" using h2sRprop by mty auto 
      hence H1: "h2sR(x) in REAL" using real_0_def_3 by auto
      have "?f(x) =\<^sub>\<H> s2hR( f. h2sR(x))" using s2hfR_appM[of"h2sR(x)" f]  IMIRprop[of x] by mty auto
      hence "h2sR(s2hR(y)) = f. h2sR(x)" using x  MIMRprop[of "f. h2sR(x)"] by mty auto
      hence H2: "y = f. h2sR(x)" using x  MIMRprop[of "y"] by mty auto      
      have "s2hR(h2sR(x)) \<in> {?a.. ?b}" using x IMIRprop by auto
      hence "h2sR(x) in [. a, b.]" using interI[of a b "h2sR(x)"] by mty auto
      thus "y in f .: [. a , b .]" using funct_1_def_6[of f "[. a , b .]"] H1 H2 D bexI[of _ "h2sR(x)"] 
        all_set by mty auto 
  qed mauto
qed mauto
qed mauto


theorem nat_real:
  " h2sn(n) = h2sR(of_nat (n))"
proof(induct n) 
  case 0
    thus ?case using h2sR.simps h2sn.simps by mty auto
  next
    have "\<forall>\<^sub>Lr::real. (r *\<^sub>\<H> s2hR(1\<^sub>\<S>) =\<^sub>\<H> r)"
    proof
      fix r::real
      have [ty]:"h2sR(r) is Mreal" using h2sRprop by auto
      have "r *\<^sub>\<H> s2hR(1\<^sub>\<S>) =\<^sub>\<H> (s2hR(h2sR(r))) *\<^sub>\<H> (s2hR(1\<^sub>\<S>))" using IMIRprop by auto
      also have "...  =\<^sub>\<H> s2hR(h2sR(r) *\<^sub>\<S>\<^sup>\<real> 1\<^sub>\<S>)" using MultRealM by mty auto  
      also have "...  =\<^sub>\<H> s2hR(1\<^sub>\<S> *\<^sub>\<S>\<^sup>\<real> h2sR(r))" using MultRealM by mty auto  
      also have "...  =\<^sub>\<H> s2hR(h2sR(r))" using real_1_th_24 by mty auto
      finally show "r *\<^sub>\<H> s2hR(1\<^sub>\<S>) =\<^sub>\<H> r" using IMIRprop by auto
    qed
    hence "s2hR(1\<^sub>\<S>) =\<^sub>\<H> 1" by (metis mult.left_neutral)
    hence ONE: "\<hh>2\<ss>\<^sub>\<real>(1) = 1\<^sub>\<S>" using MIMRprop[of "1\<^sub>\<S>"] by mty auto
    case (Suc n)
      hence H: "\<hh>2\<ss>\<^sub>\<nat>(n) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<real>(real(n))" by auto
      have S: "real(n) +\<^sub>\<H> real(1) =\<^sub>\<H> real(Suc(n))" by simp
      hence "\<hh>2\<ss>\<^sub>\<real>(real(n) +\<^sub>\<H> real(1))=\<^sub>\<H>\<hh>2\<ss>\<^sub>\<real>(real(Suc(n))) "  by presburger
      let ?n="\<hh>2\<ss>\<^sub>\<nat>(n)"
      have [ty]:"?n is Nat" using I2Mprop by auto
      have "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = succ \<hh>2\<ss>\<^sub>\<nat>(n)" by auto
      hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = ?n +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" using Add_5 by mty auto
      hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = ?n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using arytm_3_th_58 by mty auto
     hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = ?n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using Prat_Preal_add by mty auto
     hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = ?n +\<^sub>\<S>\<^sup>\<real> 1\<^sub>\<S>" using real_0_def_4 by mty auto
     hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = ?n +\<^sub>\<S>\<^sup>\<real> 1\<^sub>\<S>" using real_0_def_4 by mty auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = \<hh>2\<ss>\<^sub>\<real>(real(n)) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<real>(real(1))" using H ONE by mty auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = \<hh>2\<ss>\<^sub>\<real>(real(n) +\<^sub>\<H> real(1))" using AddRealI by  auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = \<hh>2\<ss>\<^sub>\<real>(real(Suc(n)))" using S  by presburger
    thus "\<hh>2\<ss>\<^sub>\<nat>(Suc(n)) = \<hh>2\<ss>\<^sub>\<real>((Suc(n)))" by auto
qed


theorem nat_realM:
  "n is Nat \<Longrightarrow> of_nat(s2hn(n)) =\<^sub>\<H> s2hR(n)"
proof-
  assume [ty]: "n is Nat" 
  have "h2sn(s2hn(n)) = h2sR(of_nat (s2hn(n)))" using nat_real by auto
  hence "n = h2sR(of_nat (s2hn(n)))" using MIMprop by auto
  hence "n = h2sR(of_nat (s2hn(n)))" using MIMprop by auto
  thus " of_nat(s2hn(n)) =\<^sub>\<H> s2hR(n)" using IMIRprop[of "of_nat (s2hn(n))"] by mty auto
qed

theorem int_realM:
  "n is Integer \<Longrightarrow> of_int(s2hZ(n)) =\<^sub>\<H> s2hR(n)"
proof-
  assume [ty]: "n is Integer"
  show "of_int(s2hZ(n)) =\<^sub>\<H> s2hR(n)"
  proof(cases "n is Nat")
    case [ty]: True
    have "of_nat(s2hn(n)) =\<^sub>\<H> s2hR(n)" using nat_realM by auto 
    thus "of_int(s2hZ(n)) =\<^sub>\<H> s2hR(n)" using s2hZ.simps by auto
  next
    case False
    hence [ty]:"n is non natural" using all_set by auto
    have [ty]: "(-\<^sub>\<S>\<^sup>\<real> n) is Nat" by mty auto
    have  "\<ss>2\<hh>\<^sub>\<int>(n) =\<^sub>\<H> -\<^sub>\<H> (int(\<ss>2\<hh>\<^sub>\<nat>(-\<^sub>\<S>\<^sup>\<real> n)))" using s2hZ.simps(3)[of n] by mty auto 
    also have "... =\<^sub>\<H>  -\<^sub>\<H> s2hR(-\<^sub>\<S>\<^sup>\<real> n)" using nat_realM by auto
    also have "... =\<^sub>\<H>  s2hR(n)" using RMinus[of n] by mty auto
    finally show "of_int(s2hZ(n)) =\<^sub>\<H> s2hR(n)" by auto
qed
qed

theorem int_ratM:
   "i is Integer \<Longrightarrow> of_rat(\<ss>2\<hh>\<^sub>\<rat>(i)) =\<^sub>\<H> of_int(\<ss>2\<hh>\<^sub>\<int>(i))"
  by (metis of_rat_eq_iff of_rat_of_int_eq s2hQZ) 

theorem rat_realM:
  "x is Rat \<Longrightarrow> of_rat (s2hQ(x)) =\<^sub>\<H> s2hR(x)"
proof-
  let ?n = "numerator\<^sub>\<rat>(x)" let ?d = "denominator\<^sub>\<rat>(x)"
  assume [ty]:"x is Rat"

    have "\<ss>2\<hh>\<^sub>\<int>(?d) =\<^sub>\<H> int(\<ss>2\<hh>\<^sub>\<nat>(?d))" by mty auto
    have S1: "s2hR(?d) =\<^sub>\<H> of_int(s2hZ(?d))" using int_realM[of ?d] by mty auto

  have d: "x = ?n /\<^sub>\<rat> ?d" "?d <>{}" using rat_1_th_1[of x] rat_1_d_zero[of x] by mty auto
  hence "x *\<^sub>\<S>\<^sup>\<real> ?d = ?n" using rat_1_th_6[of ?n ?d] by mty auto
  hence "s2hR(x) *\<^sub>\<H> s2hR(?d) =\<^sub>\<H> s2hR(?n)" using MultRealM[of x "?d"] by mty auto
  hence S:"s2hR(x) *\<^sub>\<H> of_int(s2hZ(?d)) =\<^sub>\<H> of_int(s2hZ(?n))" using int_realM[of ?d] int_realM[of ?n]  by mty auto
  have A1: "\<not>  s2hZ(?d) =\<^sub>\<H> 0" using MIMZprop[of ?d] d zeroZ[of " s2hZ(?d)"] by mty auto
  hence "\<not> real_of_int(s2hZ(?d)) =\<^sub>\<H> 0" using of_int_eq_0_iff[of "s2hZ(?d)"] by metis
  hence Z: "s2hR(x)  =\<^sub>\<H> of_int(s2hZ(?n)) / of_int(s2hZ(?d))" 
    using S by (smt nonzero_mult_div_cancel_right) 
  have "of_int(s2hZ(?n)) / of_int(s2hZ(?d)) 
=\<^sub>\<H> rat_of_int(s2hZ(?n)) / rat_of_int(s2hZ(?d))" by auto
  hence "of_int(s2hZ(?n)) / of_int(s2hZ(?d)) 
=\<^sub>\<H> Fract(s2hZ(?n),1) / Fract(s2hZ(?d),1)" using  of_int_rat[of "s2hZ(?n)"] 
   of_int_rat[of "s2hZ(?d)"]by auto
  hence "of_int(s2hZ(?n)) / of_int(s2hZ(?d)) 
    =\<^sub>\<H> Fract(s2hZ(?n) *\<^sub>\<H> 1 ,s2hZ(?d)*\<^sub>\<H> 1)" using divide_rat by auto
  hence "s2hR(x) =\<^sub>\<H> Fract(s2hZ(?n) *\<^sub>\<H> 1 ,s2hZ(?d)*\<^sub>\<H> 1)" using Z 
   by (metis of_rat_divide of_rat_of_int_eq of_real_divide of_real_of_int_eq)

  hence "s2hR(x)  =\<^sub>\<H> Fract(s2hZ(?n), s2hZ(?d))" by auto 
  hence "s2hR(x)  =\<^sub>\<H> s2hQ(?n /\<^sub>\<rat> ?d)" using s2hQM d by mty auto 
  hence "s2hR(x)  =\<^sub>\<H> s2hQ(x)" using d by mty auto 
  thus " of_rat(s2hQ(x))  =\<^sub>\<H>  s2hR(x)" 
    by (smt A1 Z \<open>complex_of_real(\<ss>2\<hh>\<^sub>\<real>(x)) =\<^sub>\<H> of_rat (Fract (\<ss>2\<hh>\<^sub>\<int>(?n), \<ss>2\<hh>\<^sub>\<int>(?d)))\<close> 
   of_rat_eq_iff of_rat_rat) 
qed

text_raw {*\DefineSnippet{numbers_proj}{*}
theorem
  "n is Nat \<Longrightarrow>     of_nat(\<ss>2\<hh>\<^sub>\<nat>(n)) =\<^sub>\<H> of_int(\<ss>2\<hh>\<^sub>\<int>(n))"
  "i is Integer \<Longrightarrow> of_int(\<ss>2\<hh>\<^sub>\<int>(i)) =\<^sub>\<H> of_rat(\<ss>2\<hh>\<^sub>\<rat>(i))"
  "q is Rat \<Longrightarrow>     of_rat(\<ss>2\<hh>\<^sub>\<rat>(q)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(q)"
text_raw {*}%EndSnippet*}
proof-
  assume [ty]: "n is Nat"
  have "of_nat(s2hn(n)) =\<^sub>\<H> s2hR(n)" using nat_realM by auto
  thus "of_nat(s2hn(n)) =\<^sub>\<H> of_int(s2hZ(n))" using int_realM by mty auto
next
  assume [ty]:"i is Integer"
  have "of_rat(\<ss>2\<hh>\<^sub>\<rat>(i)) =\<^sub>\<H> of_int(\<ss>2\<hh>\<^sub>\<int>(i))" using int_ratM[of i] by auto
  thus "of_int(s2hZ(i)) =\<^sub>\<H> of_rat(s2hQ(i))" by (metis of_rat_of_int_eq)
next
  show "q is Rat \<Longrightarrow> of_rat(\<ss>2\<hh>\<^sub>\<rat>(q)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(q)" using rat_realM by auto
qed



text_raw {*\DefineSnippet{Real_Real_arytm}{*}
theorem Real_to_Real:
  fixes x::real and y::real 
  assumes "r be MReal" and "s be MReal"
  shows "\<hh>2\<ss>\<^sub>\<real>(x +\<^sub>\<H> y) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<real>(x) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<real>(y)"
        "\<ss>2\<hh>\<^sub>\<real>(r +\<^sub>\<S>\<^sup>\<real> s) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(r) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(s)"
        "\<hh>2\<ss>\<^sub>\<real>(x *\<^sub>\<H> y) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<real>(x) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<real>(y)"
        "\<ss>2\<hh>\<^sub>\<real>(r *\<^sub>\<S>\<^sup>\<real> s) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(r) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<real>(s)"
        "x \<le> y \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<real>(x) \<le>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<real>(y)"
        "r \<le>\<^sup>\<real> s \<longleftrightarrow> \<ss>2\<hh>\<^sub>\<real>(r) \<le> \<ss>2\<hh>\<^sub>\<real>(s)"
text_raw {*}%EndSnippet*}
  using AddRealI[of x y] AddRealM[OF assms] MultRealI MultRealM[OF assms] 
  real_lessI real_lessM[OF assms] by mty auto  

end
