theory ring_ring 
  imports group_group "../mml/vectsp_1"
begin

text_raw {*\DefineSnippet{s2hr}{*}
definition s2hr :: "(Set \<Rightarrow> 'a) \<Rightarrow> ('a \<Rightarrow> Set)  \<Rightarrow> Set \<Rightarrow> 'a ring" ("\<ss>2\<hh>\<^sub>R'(_,_,_')")where
  "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r) =\<^sub>\<H> Iring (
     Collect(\<lambda>x. \<hh>2\<ss>c(x) in the carrier of r),      
     \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of r),
     \<ss>2\<hh>c(1\<^sub>r),
     \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of r),
     \<ss>2\<hh>c(0\<^sub>r))"
text_raw {*}%EndSnippet*}

theorem MtoIRMult:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" "the carrier of R = c"
          "x \<in> carrierI(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, R))"
          "y \<in> carrierI(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, R))"
          and
          [ty]: "R is doubleLoopStr" 
   shows "x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y))"
         "\<hh>2\<ss>c(x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)\<^esub> y) = \<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y)"
proof-
  let ?M = "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)"
  have C00: "?M =\<^sub>\<H> Iring (
          Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of R )  , 
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of R),
          \<ss>2\<hh>c(1\<^sub>R),
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of R),
          \<ss>2\<hh>c(0\<^sub>R))" using s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R] by auto
  have C01: "carrierI(?M) =\<^sub>\<H>  Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of R )" using C00[unfolded Iring_def] by auto
  have C02: "mult(?M) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of R)" using C00[unfolded Iring_def] by auto
  have C: "c is non empty" using beIsoS_d[OF assms(1)] by auto
  have "\<hh>2\<ss>c(x) in the carrierM of R" "\<hh>2\<ss>c(y) in the carrierM of R" using C01 assms(1,2,3) beIsoS_def by blast+
  hence [ty]: "\<hh>2\<ss>c(x) is Element-of-struct R" "\<hh>2\<ss>c(y) is Element-of-struct R" using Element(6) all_set by auto
    have "\<ss>2\<hh>c(\<hh>2\<ss>c(x)) =\<^sub>\<H> x" "\<ss>2\<hh>c(\<hh>2\<ss>c(y)) =\<^sub>\<H> y" using beIsoS_i[OF assms(1)] by auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H>  (\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of R))(\<ss>2\<hh>c(\<hh>2\<ss>c(x)),\<ss>2\<hh>c(\<hh>2\<ss>c(y)))" using C02 by auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c((the multF of R).\<lparr>\<hh>2\<ss>c(x),\<hh>2\<ss>c(y)\<rparr>)" using MtoIBinOpS[OF assms(1), of "\<hh>2\<ss>c(x)" "\<hh>2\<ss>c(y)"] assms(2) 
          by mty auto
    then show S1: "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y))" using algstr_0_def_18 assms(2) 
      by mty auto    
    have "\<hh>2\<ss>c(\<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y))) = \<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y)" using beIsoS_e[OF assms(1)] assms by mty auto
    then show "\<hh>2\<ss>c(x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)\<^esub> y) = \<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y)" using S1 by auto
  qed

theorem MtoIRAdd:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" "the carrier of R = c"
          "x \<in> carrierI(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, R))"
          "y \<in> carrierI(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, R))"
          and
          [ty]: "R is doubleLoopStr" 
   shows "x \<oplus>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y))"
         "\<hh>2\<ss>c(x \<oplus>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)\<^esub> y) = \<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)"
proof-
 let ?M = "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)"
  have C00: "?M =\<^sub>\<H> Iring (
          Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of R )  , 
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of R),
          \<ss>2\<hh>c(1\<^sub>R),
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of R),
          \<ss>2\<hh>c(0\<^sub>R))" using s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R] by auto
  have C01: "carrierI(?M) =\<^sub>\<H>  Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of R )" using C00[unfolded Iring_def] by auto
  have C02: "add(?M) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of R)" using C00[unfolded Iring_def] by auto
  have C: "c is non empty" using beIsoS_d[OF assms(1)] by auto
  have "\<hh>2\<ss>c(x) in the carrierM of R" "\<hh>2\<ss>c(y) in the carrierM of R" using C01 assms(1,2,3) beIsoS_def by blast+
  hence [ty]: "\<hh>2\<ss>c(x) is Element-of-struct R" "\<hh>2\<ss>c(y) is Element-of-struct R" using Element(6) all_set by auto
    have "\<ss>2\<hh>c(\<hh>2\<ss>c(x)) =\<^sub>\<H> x" "\<ss>2\<hh>c(\<hh>2\<ss>c(y)) =\<^sub>\<H> y" using beIsoS_i[OF assms(1)] by auto
    hence "x \<oplus>\<^bsub>?M\<^esub> y =\<^sub>\<H>  (\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of R))(\<ss>2\<hh>c(\<hh>2\<ss>c(x)),\<ss>2\<hh>c(\<hh>2\<ss>c(y)))" using C02 by auto
    hence "x \<oplus>\<^bsub>?M\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c((the addF of R).\<lparr>\<hh>2\<ss>c(x),\<hh>2\<ss>c(y)\<rparr>)" using MtoIBinOpS[OF assms(1), of "\<hh>2\<ss>c(x)" "\<hh>2\<ss>c(y)"] assms(2) 
          by mty auto
    then show S1: "x \<oplus>\<^bsub>?M\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y))" using algstr_0_def_1 assms(2) 
      by mty auto    
    have "\<hh>2\<ss>c(\<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y))) = \<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)" using beIsoS_e[OF assms(1)] assms by mty auto
    then show "\<hh>2\<ss>c(x \<oplus>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)\<^esub> y) = \<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)" using S1 by auto
qed

text_raw {*\DefineSnippet{MtoIRingProp}{*}
theorem MtoIRingProp:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "R be Ring" 
    and "the carrier of R =\<^sub>\<S> c"           
  shows "ring(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R))"
text_raw {*}%EndSnippet*}
proof
  have [ty]: "R be Ring" using assms by auto
  let ?M = "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,R)"
  let ?A ="add_monoid(?M)"
  let ?E = "Element-of-struct R"
  have C00: "?M =\<^sub>\<H> Iring (
          Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of R )  , 
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of R),
          \<ss>2\<hh>c(1\<^sub>R),
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of R),
          \<ss>2\<hh>c(0\<^sub>R))" using s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R] by auto
  have C: "carrierI(?M) =\<^sub>\<H>  Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of R )" using C00[unfolded Iring_def] by auto
  have CA: "carrierI(?M) =\<^sub>\<H> carrierI(?A)" by simp 
  show S1: "\<And>x y. x \<in> carrierI(?A) \<Longrightarrow>
           y \<in> carrierI(?A) \<Longrightarrow> x \<otimes>\<^bsub>?A\<^esub> y \<in> carrierI(?A)"
  proof-
    fix x y assume A: "x \<in> carrierI(?A)" "y \<in> carrierI(?A)"
    hence AA:"x \<in> carrierI(?M)" "y \<in> carrierI(?M)" by auto
      have  [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" using A C Element(6) all_set by auto
      have XY: "\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y) in the carrier of R" using Element(7) all_set by mty auto
      have "\<hh>2\<ss>c(x \<oplus>\<^bsub>?M\<^esub> y) =  \<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)"
        using MtoIRAdd(2)[OF assms(1,3)] AA by auto
      hence "\<hh>2\<ss>c(x \<otimes>\<^bsub>?A\<^esub> y) =  \<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)"
        using CA by auto
    then show "x \<otimes>\<^bsub>?A\<^esub> y \<in> carrierI(?A)" using C XY CA by auto
  qed
  show D1: "\<And>x y. x \<in> carrierI(?M) \<Longrightarrow>
           y \<in> carrierI(?M) \<Longrightarrow> x \<otimes>\<^bsub>?M\<^esub> y \<in> carrierI(?M)"
  proof-
    fix x y assume A: "x \<in> carrierI(?M)" "y \<in> carrierI(?M)"
     hence [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" using C Element(6) all_set by auto
  
      have XY: "\<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y) in the carrier of R" using Element(7) all_set by mty auto
      have "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) =  \<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y)" using algstr_0_def_18 assms(3) 
      using MtoIRMult[OF assms(1,3)] A by mty auto
    then show "x \<otimes>\<^bsub>?M\<^esub> y \<in> carrierI(?M)" using C XY by auto
  qed
  show D2: " \<And>x y z.
       x \<in> carrierI(?M) \<Longrightarrow>
       y \<in> carrierI(?M) \<Longrightarrow>
       z \<in> carrierI(?M) \<Longrightarrow> x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> x \<otimes>\<^bsub>?M\<^esub> (y \<otimes>\<^bsub>?M\<^esub> z)"
  proof-
    fix x y z assume A: "x \<in> carrierI(?M)" "y \<in> carrierI(?M)" "z \<in> carrierI(?M)"
    hence A1: "x \<otimes>\<^bsub>?M\<^esub> y  \<in> carrierI(?M)"  "y \<otimes>\<^bsub>?M\<^esub> z  \<in> carrierI(?M)" using D1 by auto
    hence [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" "\<hh>2\<ss>c(z) is ?E" 
            "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) is ?E" "\<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub> z) is ?E" using C A Element(6) all_set by auto
    have A2:"\<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub> z) = \<hh>2\<ss>c(y) \<otimes>\<^sub>R \<hh>2\<ss>c(z)" using  MtoIRMult[OF assms(1,3)] A1 A by mty auto
   
    have "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) = \<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y)" using  MtoIRMult[OF assms(1,3)] A1 A by mty auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>R \<hh>2\<ss>c(y) \<otimes>\<^sub>R \<hh>2\<ss>c(z))" using MtoIRMult[OF assms(1,3)] A1 A by mty auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>R (\<hh>2\<ss>c(y) \<otimes>\<^sub>R \<hh>2\<ss>c(z)))" using  group_1_def_3E[of R] by mty auto
    then show "x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> x \<otimes>\<^bsub>?M\<^esub> (y \<otimes>\<^bsub>?M\<^esub> z)" using  A2 MtoIRMult[OF assms(1,3)] A1 A by mty auto
  qed
  show S2: " \<And>x y z.
       x \<in> carrierI(?A) \<Longrightarrow>
       y \<in> carrierI(?A) \<Longrightarrow>
       z \<in> carrierI(?A) \<Longrightarrow> x \<otimes>\<^bsub>?A\<^esub> y \<otimes>\<^bsub>?A\<^esub> z =\<^sub>\<H> x \<otimes>\<^bsub>?A\<^esub> (y \<otimes>\<^bsub>?A\<^esub> z)"
  proof-
    fix x y z assume A: "x \<in> carrierI(?A)" "y \<in> carrierI(?A)" "z \<in> carrierI(?A)"
    hence A1: "x \<otimes>\<^bsub>?A\<^esub> y  \<in> carrierI(?A)"  "y \<otimes>\<^bsub>?A\<^esub> z  \<in> carrierI(?A)" using S1 by auto
    have [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" "\<hh>2\<ss>c(z) is ?E"
            "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) is ?E" "\<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub> z) is ?E" using C A Element(6) all_set D1 by auto
    have A2:"\<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub> z) = \<hh>2\<ss>c(y) \<otimes>\<^sub>R \<hh>2\<ss>c(z)" using  MtoIRMult[OF assms(1,3)] A1 A by mty auto
   
    have "\<hh>2\<ss>c(x \<otimes>\<^bsub>?A\<^esub> y) = \<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)" using  MtoIRAdd[OF assms(1,3)] A1 A by mty auto
    hence "x \<otimes>\<^bsub>?A\<^esub> y \<otimes>\<^bsub>?A\<^esub> z =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y) \<oplus>\<^sub>R \<hh>2\<ss>c(z))" using MtoIRAdd[OF assms(1,3)] A1 A by mty auto
    hence "x \<otimes>\<^bsub>?A\<^esub> y \<otimes>\<^bsub>?A\<^esub> z =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R (\<hh>2\<ss>c(y) \<oplus>\<^sub>R \<hh>2\<ss>c(z)))" using  rlvect_1_def_3E[of R] by mty auto
    then show "x \<otimes>\<^bsub>?A\<^esub> y \<otimes>\<^bsub>?A\<^esub> z =\<^sub>\<H> x \<otimes>\<^bsub>?A\<^esub> (y \<otimes>\<^bsub>?A\<^esub> z)" using  A2 MtoIRAdd[OF assms(1,3)] A1 A by mty auto
  qed


  have O: "1\<^sub>R in the carrier of R" "0\<^sub>R in the carrier of R" using Element(7) by mty auto
  have II: "\<hh>2\<ss>c(\<ss>2\<hh>c(1\<^sub>R)) = 1\<^sub>R" "\<hh>2\<ss>c(\<ss>2\<hh>c(0\<^sub>R)) = 0\<^sub>R" using beIsoS_e[OF assms(1)] assms(3) by mty auto
  then show S3: "\<one>\<^bsub>?A\<^esub> \<in> carrierI(?A)" "\<one>\<^bsub>?M\<^esub> \<in> carrierI(?M)" using C O C00[unfolded Iring_def] by auto
  have D3: "\<one>\<^bsub>?A\<^esub> =\<^sub>\<H> \<ss>2\<hh>c(0\<^sub>R)" "\<one>\<^bsub>?M\<^esub> =\<^sub>\<H> \<ss>2\<hh>c(1\<^sub>R)" using II C O C00[unfolded Iring_def] by auto
  show "\<And>x. x \<in> carrierI(?M) \<Longrightarrow> \<one>\<^bsub>?M\<^esub> \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> x"
  proof-
    fix x assume A: "x \<in> carrierI(?M)"
    hence [ty]: "\<hh>2\<ss>c(x) is ?E"  using C Element(6) all_set  by auto
    have "\<ss>2\<hh>c(1\<^sub>R) \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> \<ss>2\<hh>c((1\<^sub>R) \<otimes>\<^sub>R \<hh>2\<ss>c(x)) " using MtoIRMult[OF assms(1,3) _ A,of "\<ss>2\<hh>c(1\<^sub>R)",simplified] II S3 C D3 by auto
    hence "\<ss>2\<hh>c(1\<^sub>R) \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x))" using vectsp_1_def_8E[of R,simplified] by mty auto
    then show "\<one>\<^bsub>?M\<^esub> \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> x" using beIsoS_i[OF assms(1), of x] assms(2) C D3 by mty auto
  qed
  show "\<And>x. x \<in> carrierI(?M) \<Longrightarrow> x \<otimes>\<^bsub>?M\<^esub> \<one>\<^bsub>?M\<^esub> =\<^sub>\<H> x"
 proof-
   fix x assume A: "x \<in> carrierI(?M)"
    hence [ty]: "\<hh>2\<ss>c(x) is ?E"  using C Element(6) all_set  by auto
    have "x \<otimes>\<^bsub>?M\<^esub> \<ss>2\<hh>c(1\<^sub>R) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>R (1\<^sub>R)) " using MtoIRMult[OF assms(1,3)] A II S3 C D3 by mty auto
    hence "x \<otimes>\<^bsub>?M\<^esub> \<ss>2\<hh>c(1\<^sub>R) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x))" using vectsp_1_def_4E[of R,simplified] by mty auto
    then show "x \<otimes>\<^bsub>?M\<^esub> \<one>\<^bsub>?M\<^esub> =\<^sub>\<H> x" using beIsoS_i[OF assms(1), of x] assms(2) C D3 by mty auto
  qed
  show "(\<subseteq>)(carrierI(?A), Units(?A))"
  proof
    fix y assume A:"y \<in> carrierI(?A)"
    hence [ty]: "\<hh>2\<ss>c(y) is ?E"  using C Element(6) all_set  by auto
    let ?x = "\<ominus>\<^sub>R(\<hh>2\<ss>c(y))" 
    have [ty]:"?x is ?E" by mty auto
    have O: "?x in the carrier of R" using Element(7) by mty auto
    have X: "\<hh>2\<ss>c(\<ss>2\<hh>c(?x)) = ?x" using beIsoS_e[OF assms(1), of "?x"] assms(3) by mty auto
    have C1:  "\<ss>2\<hh>c(?x)  \<in> carrierI(?M)" using O X C by auto

    hence "\<ss>2\<hh>c(?x) \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(?x \<oplus>\<^sub>R \<hh>2\<ss>c(y))" using MtoIRAdd[OF assms(1,3)] X A by mty auto
    hence C2: "\<ss>2\<hh>c(?x) \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> \<one>\<^bsub>?A\<^esub>" using rlvect_1_th_5 C D3 by mty auto
    have  "y \<otimes>\<^bsub>?A\<^esub> \<ss>2\<hh>c(?x) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(y) \<oplus>\<^sub>R ?x)" using MtoIRAdd[OF assms(1,3)] X A C1 by mty auto
    hence "y \<otimes>\<^bsub>?A\<^esub> \<ss>2\<hh>c(?x) =\<^sub>\<H> \<one>\<^bsub>?A\<^esub>" using rlvect_1_th_5 C D3 by mty auto
    hence "Ex (\<lambda>x . x \<in> carrierI(?M) & x \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> \<one>\<^bsub>?A\<^esub> \<and> y \<otimes>\<^bsub>?A\<^esub> x =\<^sub>\<H> \<one>\<^bsub>?A\<^esub>)" using C1 C2 by auto
    then show "y \<in> Units (?A)" using A Units_def[of ?A] by auto  
  qed
 show "\<And>x. x \<in> carrierI(?A) \<Longrightarrow> \<one>\<^bsub>?A\<^esub> \<otimes>\<^bsub>?A\<^esub> x =\<^sub>\<H> x"
  proof-
    fix x assume A: "x \<in> carrierI(?A)"
    hence [ty]: "\<hh>2\<ss>c(x) is ?E"  using C Element(6) all_set  by auto
    have "\<ss>2\<hh>c(0\<^sub>R) \<otimes>\<^bsub>?A\<^esub> x =\<^sub>\<H> \<ss>2\<hh>c((0\<^sub>R) \<oplus>\<^sub>R \<hh>2\<ss>c(x)) " using MtoIRAdd[OF assms(1,3), of "\<ss>2\<hh>c(0\<^sub>R)" x,simplified] A II S3 C D3 by auto
    hence "\<ss>2\<hh>c(0\<^sub>R) \<otimes>\<^bsub>?A\<^esub> x =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x))" using rlvect_1_th_4[of R,simplified] by mty auto
    then show "\<one>\<^bsub>?A\<^esub> \<otimes>\<^bsub>?A\<^esub> x =\<^sub>\<H> x" using beIsoS_i[OF assms(1), of x] assms(2) C D3 by mty auto
  qed
  show "\<And>x. x \<in> carrierI(?A) \<Longrightarrow> x \<otimes>\<^bsub>?A\<^esub> \<one>\<^bsub>?A\<^esub> =\<^sub>\<H> x"
 proof-
   fix x assume A: "x \<in> carrierI(?A)"
    hence [ty]: "\<hh>2\<ss>c(x) is ?E"  using C Element(6) all_set  by auto
    have "x \<otimes>\<^bsub>?A\<^esub> \<ss>2\<hh>c(0\<^sub>R) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R (0\<^sub>R)) " using MtoIRAdd[OF assms(1,3), of x "\<ss>2\<hh>c(0\<^sub>R)",simplified] A II S3 C D3 by mty auto
    hence "x \<otimes>\<^bsub>?A\<^esub> \<ss>2\<hh>c(0\<^sub>R) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x))" using rlvect_1_th_4[of R,simplified] by mty auto
    then show "x \<otimes>\<^bsub>?A\<^esub> \<one>\<^bsub>?A\<^esub> =\<^sub>\<H> x" using beIsoS_i[OF assms(1), of x] assms(2) C D3 by mty auto
  qed
  show Ab: "\<And>x y. x \<in> carrierI(?A) \<Longrightarrow>
           y \<in> carrierI(?A) \<Longrightarrow> x \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> y \<otimes>\<^bsub>?A\<^esub> x "
  proof-
    fix x y assume A: "x \<in> carrierI(?A)" "y \<in> carrierI(?A)"
    hence AA:"x \<in> carrierI(?M)" "y \<in> carrierI(?M)" by auto
    have  [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" using A C Element(6) all_set by auto
    have "x \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)) " using MtoIRAdd[OF assms(1,3),simplified] A by mty auto 
    hence "x \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(y) \<oplus>\<^sub>R \<hh>2\<ss>c(x)) " using rlvect_1_def_2E by mty auto 
    then show "x \<otimes>\<^bsub>?A\<^esub> y =\<^sub>\<H> y \<otimes>\<^bsub>?A\<^esub> x " using MtoIRAdd[OF assms(1,3),simplified] A by mty auto 
  qed
  fix x y z
  assume A: "x \<in> carrierI(?M)" "y \<in> carrierI(?M)" "z \<in> carrierI(?M)"
  hence A1: "x \<oplus>\<^bsub>?M\<^esub> y  \<in> carrierI(?M)" "x \<otimes>\<^bsub>?M\<^esub> z  \<in> carrierI(?M)"  "y \<otimes>\<^bsub>?M\<^esub> z  \<in> carrierI(?M)"
    "z \<otimes>\<^bsub>?M\<^esub> x  \<in> carrierI(?M)"  "z \<otimes>\<^bsub>?M\<^esub> y  \<in> carrierI(?M)" using S1 D1 by auto
  
  have  [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" "\<hh>2\<ss>c(z) is ?E" using A C Element(6) all_set by auto

  have  "(x \<oplus>\<^bsub>?M\<^esub> y) \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x \<oplus>\<^bsub>?M\<^esub> y) \<otimes>\<^sub>R  \<hh>2\<ss>c(z))" using MtoIRMult[OF assms(1,3),simplified] A A1 by auto
  also have "... =\<^sub>\<H>  \<ss>2\<hh>c((\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)) \<otimes>\<^sub>R  \<hh>2\<ss>c(z))" using MtoIRAdd[OF assms(1,3),simplified] A by auto
 also have "... =\<^sub>\<H>  \<ss>2\<hh>c((\<hh>2\<ss>c(x) \<otimes>\<^sub>R  \<hh>2\<ss>c(z)) \<oplus>\<^sub>R (\<hh>2\<ss>c(y)  \<otimes>\<^sub>R  \<hh>2\<ss>c(z) ))" using vectsp_1_def_7E[of R] by auto
 also have "... =\<^sub>\<H>  \<ss>2\<hh>c( \<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub>  z) \<oplus>\<^sub>R \<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub>  z))" using MtoIRMult[OF assms(1,3),simplified] A by auto
  also have "... =\<^sub>\<H> (x \<otimes>\<^bsub>?M\<^esub> z) \<oplus>\<^bsub>?M\<^esub> (y \<otimes>\<^bsub>?M\<^esub> z)" using MtoIRAdd[OF assms(1,3),simplified] A1 by auto
  finally  show  "(x \<oplus>\<^bsub>?M\<^esub> y) \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> (x \<otimes>\<^bsub>?M\<^esub> z) \<oplus>\<^bsub>?M\<^esub> (y \<otimes>\<^bsub>?M\<^esub> z)" by auto



  have  "z \<otimes>\<^bsub>?M\<^esub> (x \<oplus>\<^bsub>?M\<^esub> y) =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(z)  \<otimes>\<^sub>R \<hh>2\<ss>c(x \<oplus>\<^bsub>?M\<^esub> y))" using MtoIRMult[OF assms(1,3),simplified] A A1 by auto
  also have "... =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(z) \<otimes>\<^sub>R (\<hh>2\<ss>c(x) \<oplus>\<^sub>R \<hh>2\<ss>c(y)))" using MtoIRAdd[OF assms(1,3),simplified] A by auto
 also have "... =\<^sub>\<H>  \<ss>2\<hh>c((\<hh>2\<ss>c(z) \<otimes>\<^sub>R  \<hh>2\<ss>c(x)) \<oplus>\<^sub>R (\<hh>2\<ss>c(z)  \<otimes>\<^sub>R  \<hh>2\<ss>c(y) ))" using vectsp_1_def_7E[of R] by auto
 also have "... =\<^sub>\<H>  \<ss>2\<hh>c( \<hh>2\<ss>c(z \<otimes>\<^bsub>?M\<^esub>  x) \<oplus>\<^sub>R \<hh>2\<ss>c(z \<otimes>\<^bsub>?M\<^esub>  y))" using MtoIRMult[OF assms(1,3),simplified] A by auto
  also have "... =\<^sub>\<H> (z \<otimes>\<^bsub>?M\<^esub> x) \<oplus>\<^bsub>?M\<^esub> (z \<otimes>\<^bsub>?M\<^esub> y)" using MtoIRAdd[OF assms(1,3),simplified] A1(4,5) by mty auto
  finally  show  "z \<otimes>\<^bsub>?M\<^esub> (x \<oplus>\<^bsub>?M\<^esub> y) =\<^sub>\<H> (z \<otimes>\<^bsub>?M\<^esub> x) \<oplus>\<^bsub>?M\<^esub> (z \<otimes>\<^bsub>?M\<^esub> y)" by auto
qed



text_raw {*\DefineSnippet{RRing}{*}
theorem s2hr_Prop:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "r be Ring"
    and "the carrier of r =\<^sub>\<S> c"
    and "x \<in> carrierI(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r))" "y \<in> carrierI(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r))"
  shows "zero(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r)) =\<^sub>\<H> \<ss>2\<hh>c(0\<^sub>r)" 
        "one(\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r)) =\<^sub>\<H> \<ss>2\<hh>c(1\<^sub>r)" 
        "x \<oplus>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r)\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>r \<hh>2\<ss>c(y))"
        "x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r)\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>r \<hh>2\<ss>c(y))"        
        "ring (\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r))"
text_raw {*}%EndSnippet*}
proof-
  let ?M = "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r)"
  have C00: "?M =\<^sub>\<H>  Iring (
     Collect(\<lambda>x. \<hh>2\<ss>c(x) in the carrier of r),      
     \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of r),
     \<ss>2\<hh>c(1\<^sub>r),
     \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the addF of r),
     \<ss>2\<hh>c(0\<^sub>r))" using s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c r] by auto
  show "zero(?M) =\<^sub>\<H>  \<ss>2\<hh>c(0\<^sub>r)" "one(?M) =\<^sub>\<H>  \<ss>2\<hh>c(1\<^sub>r)" using C00[unfolded Iring_def] by auto
  show "x \<oplus>\<^bsub>?M\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<oplus>\<^sub>r \<hh>2\<ss>c(y))" using MtoIRAdd[OF assms(1,3,4,5)] assms(2) by auto
  show "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>r \<hh>2\<ss>c(y))" using MtoIRMult[OF assms(1,3,4,5)] assms(2) by auto
  show "ring (\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,r))"
    using MtoIRingProp[OF assms(1,2)] assms(3) by auto
qed



text_raw {*\DefineSnippet{h2sr}{*}
definition h2sr :: "(Set \<Rightarrow> 'a) \<Rightarrow> ('a \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> 'a ring \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>R'(_,_,_,_')") where
  "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) =\<^sub>\<S> [#
     carrier \<mapsto> c;
     addF  \<mapsto> \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(r));
     ZeroF \<mapsto> \<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>);
     multF  \<mapsto> \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(r));
     OneF \<mapsto> \<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>)#]"
text_raw {*}%EndSnippet*}

theorem \<hh>2\<ss>rProp:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)"
  shows "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) is strict(doubleLoopStr)"
        "the carrierM of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) = c"
        "the ZeroF of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) =\<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>)"
        "the OneF of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) =\<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>)"    
        "the multF of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(r))"
        "the addF of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(r))"

proof-
  let ?I ="\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)"
  let ?M = "\<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(r))" let ?Z="\<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>)"
  let ?A = "\<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(r))" let ?O="(\<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>))"
  let ?R="[#(carrier \<mapsto> c);
          addF  \<mapsto> ?A;
          ZeroF \<mapsto> ?Z;
          multF  \<mapsto> ?M;
          OneF \<mapsto> ?O #]"
  have [ty]: "c be set" using all_set by auto
  have [ty]: "?M is BinOp-of c" using ItoMf2prop[OF assms(1,1,1)] h2sBinOp_def[of \<ss>2\<hh>c] by auto
  have [ty]: "?A is BinOp-of c" using ItoMf2prop[OF assms(1,1,1)] h2sBinOp_def[of \<ss>2\<hh>c] by auto
  have [ty]: "?O is Element-of c" "?Z is Element-of c" using beIsoS_m[OF assms(1)] by auto
  have A1[ty]: "?R is strict(doubleLoopStr)" by mty auto
  then show [ty]: "?I is strict(doubleLoopStr)" unfolding h2sr_def by auto
  have "the carrierM of ?R = c"  "the multF of ?R = ?M" 
"the addF of ?R = ?A" "the ZeroF of ?R = ?Z" "the OneF of ?R = ?O" 
    using the_selector_of_1[of _ carrierM c]  the_selector_of_1[of _ addF ?A] 
the_selector_of_1[of _ ZeroF ?Z] the_selector_of_1[of _ OneF ?O] 
     the_selector_of_1[of _ multF ?M] aggr by auto
  then show "the carrierM of ?I = c" "the addF of ?I = ?A"
    "the ZeroF of ?I = ?Z" "the OneF of ?I = ?O"
        "the multF of ?I = ?M"  unfolding h2sr_def by auto
qed

theorem ItoMrmult:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)"
          "x is Element-of c" "y is Element-of c"
   shows "x \<otimes>\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) y = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))"
         "\<ss>2\<hh>c(x \<otimes>\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) y) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)"
proof-
  let ?I ="\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)"
  have [ty]:"?I is strict(doubleLoopStr)" "c be set" using \<hh>2\<ss>rProp[OF assms(1)] all_set by auto
  have CAR: "the carrier of ?I = c" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  hence XY[ty]: "x is Element-of-struct ?I" "y is Element-of-struct ?I" using assms(2,3) by auto
  have xy: "\<hh>2\<ss>c(\<ss>2\<hh>c(x)) = x" "\<hh>2\<ss>c(\<ss>2\<hh>c(y)) = y" using beIsoS_e[OF assms(1)] CAR XY by mty auto

  have ADD: "the multF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(r))" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  hence "x \<otimes>\<^sub>?I  y = (\<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(r))) . \<lparr>\<hh>2\<ss>c(\<ss>2\<hh>c(x)),\<hh>2\<ss>c(\<ss>2\<hh>c(y))\<rparr>" using xy algstr_0_def_18[of ?I x y] by mty auto
  then show S1: "x \<otimes>\<^sub>?I  y = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))" 
       using ItoMBinOpS[OF assms(1), of "mult(r)" "\<ss>2\<hh>c(x)" "\<ss>2\<hh>c(y)"] by auto
  have "\<ss>2\<hh>c(\<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)" using  beIsoS_i[OF assms(1)] by auto
  then show "\<ss>2\<hh>c(x \<otimes>\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) y) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)" using S1 by auto
qed

theorem ItoMradd:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)"
          "x is Element-of c" "y is Element-of c"
   shows "x \<oplus>\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) y = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))"
         "\<ss>2\<hh>c(x \<oplus>\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) y) =\<^sub>\<H> \<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)"
proof-
  let ?I ="\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)"
  have [ty]:"?I is strict(doubleLoopStr)" "c be set" using \<hh>2\<ss>rProp[OF assms(1)] all_set by auto
  have CAR: "the carrier of ?I = c" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  hence XY[ty]: "x is Element-of-struct ?I" "y is Element-of-struct ?I" using assms(2,3) by auto
  have xy: "\<hh>2\<ss>c(\<ss>2\<hh>c(x)) = x" "\<hh>2\<ss>c(\<ss>2\<hh>c(y)) = y" using beIsoS_e[OF assms(1)] CAR XY by mty auto

  have ADD: "the addF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(r))" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  hence "x \<oplus>\<^sub>?I  y = (\<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(r))) . \<lparr>\<hh>2\<ss>c(\<ss>2\<hh>c(x)),\<hh>2\<ss>c(\<ss>2\<hh>c(y))\<rparr>" using xy algstr_0_def_1[of ?I x y] by mty auto
  then show S1: "x \<oplus>\<^sub>?I  y = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))" 
       using ItoMBinOpS[OF assms(1), of "add(r)" "\<ss>2\<hh>c(x)" "\<ss>2\<hh>c(y)"] by auto
  have "\<ss>2\<hh>c(\<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))) =\<^sub>\<H> \<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)" using  beIsoS_i[OF assms(1)] by auto
  then show "\<ss>2\<hh>c(x \<oplus>\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) y) =\<^sub>\<H> \<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)" using S1 by auto
qed

theorem ItoMrZO:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)"
  shows "0\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) = \<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>)" "1\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) = \<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>)"
proof-
  have  [ty]: "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) is strict(doubleLoopStr)" and
     "the ZeroF of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) =\<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>)" 
     "the OneF of \<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r) =\<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>)" using \<hh>2\<ss>rProp[OF assms] by auto
  then show "0\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) = \<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>)" "1\<^sub>(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) = \<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>)" using struct_0_def_7 struct_0_def_6 by auto
qed

text_raw {*\DefineSnippet{ItoMRingProp}{*}
theorem ItoMRingProp:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" "ring(r)" 
      "carrierI(r) =\<^sub>\<H> Collect(\<lambda>x . \<hh>2\<ss>c(x) in c)"
    shows "(\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)) is Ring"
text_raw {*}%EndSnippet*}
proof(standard,auto)
  have [simp]:"ring(r)" using assms by auto
  have [simp]:" abelian_group(r) \<and> Group.monoid(r) \<and> ring_axioms(r)" using ring_def[of r] by auto
  let ?I = "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,r)"
  let ?E =" Element-of-struct ?I"
  have [ty]: "?I is strict(doubleLoopStr)" and
       A1: "the carrierM of ?I = c" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  then show "?I be doubleLoopStr" by auto
  have A2: "c is non empty" using beIsoS_d[OF assms(1)] by auto

  have M:"\<And> x. x is ?E \<longrightarrow> \<ss>2\<hh>c(x) \<in> carrierI(r)"
  proof
    fix x assume "x is ?E"
    hence "x in c" "\<hh>2\<ss>c(\<ss>2\<hh>c(x)) = x" using A1 Element(7)[of c] A2 beIsoS_e[OF assms(1)] by mty auto
    then show "\<ss>2\<hh>c(x) \<in> carrierI(r)" using assms(3) by auto
  qed
   
  have [ty]:" ?I is non empty-struct"
  proof
    show "\<not> the carrier of ?I is empty" using A1 A2 by simp
  qed mauto
  then show "?I be empty-struct \<Longrightarrow> False" by auto
  show "?I be Abelian"
  proof(standard,auto)
    fix x y assume [ty]: "x be ?E" "y be ?E"
    hence A2: "x be Element-of c" "y be Element-of c" 
        "\<ss>2\<hh>c(x) \<in> carrierI(r)" "\<ss>2\<hh>c(y) \<in> carrierI(r)" using A1 M by auto
    have A3: "\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y) =\<^sub>\<H> \<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(x)" using  abelian_groupE(4)[of r,OF _ A2(3,4)] A2 by auto
    have "x \<oplus>\<^sub>?I y = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y))" using ItoMradd[OF assms(1)] A2 by auto
    then show "x \<oplus>\<^sub>?I y = y \<oplus>\<^sub>?I x"  using  ItoMradd[OF assms(1)] A2 A3 by auto
  qed
  show "?I be add-associative"
  proof(standard,auto)
    fix x y z assume [ty]: "x be ?E" "y be ?E" "z be ?E"
    have [ty]:"(x \<oplus>\<^sub>?I y) be ?E" "(y \<oplus>\<^sub>?I z) be ?E" by mty auto
    have A2: "x be Element-of c" "y be Element-of c" "z be Element-of c"
        "(x \<oplus>\<^sub>?I y) be Element-of c" "(y \<oplus>\<^sub>?I z) be Element-of c"
        "\<ss>2\<hh>c(x) \<in> carrierI(r)" "\<ss>2\<hh>c(y) \<in> carrierI(r)"  "\<ss>2\<hh>c(z) \<in> carrierI(r)" using A1 M ty by auto
    have A3:"\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z) =\<^sub>\<H> \<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> (\<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z))" 
      using abelian_groupE(3)[of r,OF _ ] A2 by auto
    have "x \<oplus>\<^sub>?I y \<oplus>\<^sub>?I z = \<hh>2\<ss>c(\<ss>2\<hh>c(x \<oplus>\<^sub>?I y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z))" using ItoMradd[OF assms(1)] A2 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> (\<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z)))" using ItoMradd[OF assms(1)] A2 A3 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(y \<oplus>\<^sub>?I z))" using ItoMradd[OF assms(1)] A2 A3 by auto
    also have "... = x \<oplus>\<^sub>?I (y \<oplus>\<^sub>?I z)" using ItoMradd[OF assms(1)] A2 A3 by auto
    finally show "x \<oplus>\<^sub>?I y \<oplus>\<^sub>?I z =x \<oplus>\<^sub>?I (y \<oplus>\<^sub>?I z)" by auto
  qed
  have B0[ty]: "0\<^sub>?I is ?E" "1\<^sub>?I is ?E" by mty auto
  hence B4: "0\<^sub>?I be Element-of c" "1\<^sub>?I be Element-of c"  using A1 M by auto
  have B1: "0\<^sub>?I = \<hh>2\<ss>c(\<zero>\<^bsub>r\<^esub>)" "1\<^sub>?I = \<hh>2\<ss>c(\<one>\<^bsub>r\<^esub>)"using ItoMrZO[OF assms(1)] by auto
  hence B2: "\<ss>2\<hh>c(0\<^sub>?I) =\<^sub>\<H> \<zero>\<^bsub>r\<^esub>"  "\<ss>2\<hh>c(1\<^sub>?I) =\<^sub>\<H> \<one>\<^bsub>r\<^esub>" using beIsoS_i[OF assms(1)] by auto
  have B3:"\<ss>2\<hh>c(0\<^sub>?I) \<in> carrierI(r)" using A1 M B0 by auto
  show "?I be right-zeroed"
  proof(standard,auto)
    fix x assume [ty]: "x be ?E"
    hence A2: "x be Element-of c" "\<ss>2\<hh>c(x) \<in> carrierI(r)"  using A1 M by auto
    have A3: "\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<zero>\<^bsub>r\<^esub> =\<^sub>\<H> \<ss>2\<hh>c(x) " using  abelian_groupE(4,5)[of r "\<ss>2\<hh>c(x)" ] A2 B3 B4 B2 by auto
    have "x \<oplus>\<^sub>?I 0\<^sub>?I = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<zero>\<^bsub>r\<^esub>)" using ItoMradd[OF assms(1)] A2 B3 B4 B2 by  auto
    then show "x \<oplus>\<^sub>?I 0\<^sub>?I = x" using beIsoS_e[OF assms(1) ] A2 A3 by auto 
  qed
  show "?I be right-complementable"
  proof(standard,auto,standard,simp,simp)
    fix x assume [ty]: "x be ?E"
    hence A2: "x be Element-of c" "\<ss>2\<hh>c(x) \<in> carrierI(r)"  using A1 M by auto
    then obtain y where
      A3: "y\<in> carrierI(r)" "y \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(x) =\<^sub>\<H> \<zero>\<^bsub>r\<^esub>" using abelian_groupE(6)[of r "\<ss>2\<hh>c(x)"] by auto
    have [ty]: "\<hh>2\<ss>c(y) is Element-of c" using beIsoS_m[OF assms(1)] by auto 
    hence [ty]: "\<hh>2\<ss>c(y) is ?E" using A1 by auto
    show "\<exists>y : Element-of-struct ?I. x \<oplus>\<^sub>?I y = 0\<^sub>?I"
    proof(rule bexI[of _ "\<hh>2\<ss>c(y)"],auto)
      have "x \<oplus>\<^sub>?I \<hh>2\<ss>c(y) = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(\<hh>2\<ss>c(y)))" using ItoMradd[OF assms(1)] A2 by auto
      also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<oplus>\<^bsub>r\<^esub> y)" using beIsoS_i[OF assms(1),of y] by auto
      also have "... = 0\<^sub>?I" using abelian_groupE(4)[of r "\<ss>2\<hh>c(x)" y] A2 A3 B1 by auto
      finally show "x \<oplus>\<^sub>?I \<hh>2\<ss>c(y) = 0\<^sub>?I" by auto
    qed
  qed
  show "?I be associative"
  proof(standard,auto)
   fix x y z assume [ty]: "x be ?E" "y be ?E" "z be ?E"
    have [ty]:"(x \<otimes>\<^sub>?I y) be ?E" "(y \<otimes>\<^sub>?I z) be ?E" by mty auto
    have A2: "x be Element-of c" "y be Element-of c" "z be Element-of c"
        "(x \<otimes>\<^sub>?I y) be Element-of c" "(y \<otimes>\<^sub>?I z) be Element-of c"
        "\<ss>2\<hh>c(x) \<in> carrierI(r)" "\<ss>2\<hh>c(y) \<in> carrierI(r)"  "\<ss>2\<hh>c(z) \<in> carrierI(r)" using A1 M ty by auto
    have A3:"\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(z) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> (\<ss>2\<hh>c(y) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(z))" 
      using monoid.m_assoc[of r] A2 by auto
    have "x \<otimes>\<^sub>?I y \<otimes>\<^sub>?I z = \<hh>2\<ss>c(\<ss>2\<hh>c(x \<otimes>\<^sub>?I y) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(z))" using ItoMrmult[OF assms(1)] A2 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> (\<ss>2\<hh>c(y) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(z)))" using ItoMrmult[OF assms(1)] A2 A3 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y \<otimes>\<^sub>?I z))" using ItoMrmult[OF assms(1)] A2 A3 by auto
    also have "... = x \<otimes>\<^sub>?I (y \<otimes>\<^sub>?I z)" using ItoMrmult[OF assms(1)] A2 A3 by auto
    finally show "x \<otimes>\<^sub>?I y \<otimes>\<^sub>?I z =x \<otimes>\<^sub>?I (y \<otimes>\<^sub>?I z)" by auto
  qed 
  show "?I be well-unital"
  proof(standard,auto)
  fix x assume [ty]: "x be ?E"
    hence A2: "x be Element-of c" "\<ss>2\<hh>c(x) \<in> carrierI(r)"  using A1 M by auto
    have A3: "\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<one>\<^bsub>r\<^esub> =\<^sub>\<H> \<ss>2\<hh>c(x) " "\<one>\<^bsub>r\<^esub> \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x)  =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<one>\<^bsub>r\<^esub> "
      using  abelian_groupE(4,5,3)[of r ] A2 B3 B4 B2 by auto
    have "x \<otimes>\<^sub>?I 1\<^sub>?I = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<one>\<^bsub>r\<^esub>)" "1\<^sub>?I \<otimes>\<^sub>?I x = \<hh>2\<ss>c(\<one>\<^bsub>r\<^esub> \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x))"
      using ItoMrmult[OF assms(1)] A2 B3 B4 B2 by  auto
    then show "x \<otimes>\<^sub>?I 1\<^sub>?I = x" "1\<^sub>?I \<otimes>\<^sub>?I x = x" using beIsoS_e[OF assms(1) ] A2 A3 by auto 
  qed
  show "?I be distributive"
  proof(standard,auto)
      fix x y z assume [ty]: "x be ?E" "y be ?E" "z be ?E"
    have [ty]:"(x \<otimes>\<^sub>?I y) be ?E" "(y \<otimes>\<^sub>?I x) be ?E" "(y \<oplus>\<^sub>?I z) be ?E" "(x \<otimes>\<^sub>?I z) be ?E" "(z \<otimes>\<^sub>?I x) be ?E"  by mty auto
    have A2: "x be Element-of c" "y be Element-of c" "z be Element-of c"
        "(x \<otimes>\<^sub>?I y) be Element-of c" "(y \<otimes>\<^sub>?I x) be Element-of c" "(y \<oplus>\<^sub>?I z) be Element-of c" 
       "(x \<otimes>\<^sub>?I z) be Element-of c" "(z \<otimes>\<^sub>?I x) be Element-of c"
        "\<ss>2\<hh>c(x) \<in> carrierI(r)" "\<ss>2\<hh>c(y) \<in> carrierI(r)"  "\<ss>2\<hh>c(z) \<in> carrierI(r)" using A1 M ty by auto
    have A3:"\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> (\<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z)) =\<^sub>\<H> (\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y)) \<oplus>\<^bsub>r\<^esub> (\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(z))" 
      using ringE[of r] A2 by auto
    have A4:" (\<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z)) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x) =\<^sub>\<H> (\<ss>2\<hh>c(y) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x)) \<oplus>\<^bsub>r\<^esub> (\<ss>2\<hh>c(z) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x))" 
      using ringE[of r] A2 by auto
   
    have "x \<otimes>\<^sub>?I (y \<oplus>\<^sub>?I z) = \<hh>2\<ss>c( \<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(y \<oplus>\<^sub>?I z))" using ItoMrmult[OF assms(1)] A2 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>r\<^esub> (\<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z)))" using ItoMradd[OF assms(1)] A2 A3 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(x \<otimes>\<^sub>?I y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(x \<otimes>\<^sub>?I z))" using ItoMrmult[OF assms(1)] A2 A3 by auto
    also have "... = (x \<otimes>\<^sub>?I y) \<oplus>\<^sub>?I (x \<otimes>\<^sub>?I z)" using ItoMradd[OF assms(1)] A2 by auto
    finally show "x \<otimes>\<^sub>?I (y \<oplus>\<^sub>?I z) = (x \<otimes>\<^sub>?I y) \<oplus>\<^sub>?I (x \<otimes>\<^sub>?I z)" by auto
  have "(y \<oplus>\<^sub>?I z) \<otimes>\<^sub>?I x = \<hh>2\<ss>c(  \<ss>2\<hh>c(y \<oplus>\<^sub>?I z)  \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x))" using ItoMrmult[OF assms(1)] A2 by auto
    also have "... = \<hh>2\<ss>c( (\<ss>2\<hh>c(y) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z)) \<otimes>\<^bsub>r\<^esub> \<ss>2\<hh>c(x))" using ItoMradd[OF assms(1)] A2 A3 by auto
    also have "... = \<hh>2\<ss>c(\<ss>2\<hh>c(y \<otimes>\<^sub>?I x) \<oplus>\<^bsub>r\<^esub> \<ss>2\<hh>c(z \<otimes>\<^sub>?I x))" using ItoMrmult[OF assms(1)] A2 A4 by auto
    also have "... = (y \<otimes>\<^sub>?I x) \<oplus>\<^sub>?I (z \<otimes>\<^sub>?I x)" using ItoMradd[OF assms(1)] A2 by auto
    finally show "(y \<oplus>\<^sub>?I z) \<otimes>\<^sub>?I x= (y \<otimes>\<^sub>?I x) \<oplus>\<^sub>?I (z \<otimes>\<^sub>?I x)" by auto
  qed  
qed
text_raw {*\DefineSnippet{MIMRprop}{*}
theorem MIMRprop:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" 
            "the carrier of R =\<^sub>\<S> c" and [ty]:"R is strict(doubleLoopStr)"
          shows "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, R)) =\<^sub>\<S> R"
text_raw {*}%EndSnippet*}
proof-
  let ?M = "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, R)"
  let ?I = "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,c,?M)"
  have [ty]:"?I is strict(doubleLoopStr)" and
     A1: "the carrierM of ?I = c"
        "the ZeroF of ?I =\<hh>2\<ss>c(\<zero>\<^bsub>?M\<^esub>)"
        "the OneF of ?I =\<hh>2\<ss>c(\<one>\<^bsub>?M\<^esub>)"    
        "the multF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(?M))"
        "the addF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(?M))" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  show "?I = R"
  proof (rule Equal_strict[of _ _ doubleLoopStr],auto)
    fix sel assume "sel in domain_of doubleLoopStr"
    hence S: "sel = carrierM or sel=addF or sel = multF or sel = OneF or sel=ZeroF" 
      using doubleLoopStr_dom string by auto
    have H1:"the carrier of ?I = the carrier of R" using assms(2) A1 by auto
    have  "the ZeroF of ?I =\<hh>2\<ss>c(\<ss>2\<hh>c(0\<^sub>R))" using A1 s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R,unfolded Iring_def] by auto
    also have "... =0\<^sub>R" using beIsoS_e[OF assms(1),of "0\<^sub>R"] assms(2) by mty auto
    finally have H2: "the ZeroF of ?I =the ZeroF of R" using struct_0_def_6 by mty auto
    have  "the OneF of ?I =\<hh>2\<ss>c(\<ss>2\<hh>c(1\<^sub>R))" using A1 s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R,unfolded Iring_def] by auto
    also have "... =1\<^sub>R" using beIsoS_e[OF assms(1),of "1\<^sub>R"] assms(2) by mty auto
    finally have H3: "the OneF of ?I =the OneF of R" using struct_0_def_7 by mty auto

    have "the multF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c, \<hh>2\<ss>c, the multF of R))" 
       using A1 s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R,unfolded Iring_def] by auto
    hence H4:"the multF of ?I =  the multF of R" 
       using MIMBinOp[OF assms(1), of "the multF of R"] assms(2) by mty auto

    have "the addF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c, \<hh>2\<ss>c, the addF of R))" 
       using A1 s2hr_def[of \<ss>2\<hh>c \<hh>2\<ss>c R,unfolded Iring_def] by auto
    hence H5:"the addF of ?I =  the addF of R" 
       using MIMBinOp[OF assms(1), of "the addF of R"] assms(2) by mty auto
    show "the sel of ?I =  the sel of R" using S H1 H2 H3 H4 H5 by auto
  qed
qed
thm ring_eq[of R]

text_raw {*\DefineSnippet{IMIRprop}{*}
theorem IMIRprop:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" 
          "carrierI(R) =\<^sub>\<H> Collect(\<lambda> x. \<hh>2\<ss>c(x) in c)" 
        shows "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>c,\<hh>2\<ss>c,\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c,c, R)) =\<^sub>\<H> R"
text_raw {*}%EndSnippet*}
unfolding s2hr_def
proof(rule ring_eq[of R],intro conjI)
  let ?I="\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>c, \<hh>2\<ss>c, c, R)"
  have [ty]: "?I is strict(doubleLoopStr)" and
        A1: "the carrierM of ?I = c"
        "the ZeroF of ?I =\<hh>2\<ss>c(\<zero>\<^bsub>R\<^esub>)"
        "the OneF of ?I =\<hh>2\<ss>c(\<one>\<^bsub>R\<^esub>)" 
        "the multF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(R))"
         "the addF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,add(R))" using \<hh>2\<ss>rProp[OF assms(1)] by auto
  show "carrierI(R) =\<^sub>\<H> Collect(\<lambda> x. \<hh>2\<ss>c(x) in the' carrierM(?I))" using assms(2) A1 by auto
  show "mult(R) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c, \<hh>2\<ss>c, the multF of ?I)" using A1 IMIBinOpS[OF assms(1)] by auto
  show "add(R) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c, \<hh>2\<ss>c, the addF of ?I)" using A1 IMIBinOpS[OF assms(1)] by auto
  have "1\<^sub>?I =\<hh>2\<ss>c(\<one>\<^bsub>R\<^esub>)" using struct_0_def_7 A1 by auto
  then show "\<one>\<^bsub>R\<^esub> =\<^sub>\<H> \<ss>2\<hh>c(1\<^sub>?I)" using beIsoS_i[OF assms(1)] by auto
  have "0\<^sub>?I =\<hh>2\<ss>c(\<zero>\<^bsub>R\<^esub>)" using struct_0_def_6 A1 by auto
  then show "\<zero>\<^bsub>R\<^esub> =\<^sub>\<H> \<ss>2\<hh>c(0\<^sub>?I)" using beIsoS_i[OF assms(1)] by auto
qed

end