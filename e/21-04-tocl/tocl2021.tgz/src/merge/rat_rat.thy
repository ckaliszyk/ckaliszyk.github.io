theory rat_rat
  imports int_int nat_nat pre_merge_rat2 "../mml/absvalue"
begin

term fst
term "\<hh>2\<ss>\<^sub>\<int>(fst(x))"
term "normalize" (* HOL.Rat"*)

ML \<open> @{term "rat"} \<close>

function h2sQ :: "rat \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>\<rat>'(_')")where
  "\<hh>2\<ss>\<^sub>\<rat>(x) =\<^sub>\<S> ((\<hh>2\<ss>\<^sub>\<int>(fst(quotient_of(x)))) /\<^sub>\<rat> (\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(x)))))"
apply blast apply blast done

termination
  apply standard 
  apply auto done

function s2hQ :: "Set \<Rightarrow> rat" ("\<ss>2\<hh>\<^sub>\<rat>'(_')")where
  "\<not>x is Rat \<Longrightarrow> \<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> undefined"
| "x is Rat \<Longrightarrow>  \<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(numerator\<^sub>\<rat>(x)),\<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(x)))"     
  apply auto done
print_theorems
termination
  apply standard 
  apply auto done


theorem h2sQprop: 
  "\<hh>2\<ss>\<^sub>\<rat>(r) is Rat"
proof-
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>(fst(quotient_of(r))) is Integer" using h2sZprop by auto
  have "snd(quotient_of(r))>0"  by (simp add: quotient_of_denom_pos')
  hence "\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(r))) = \<hh>2\<ss>\<^sub>\<nat>(nat(snd(quotient_of(r))))" by auto
  hence[ty]:"\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(r))) is Nat" using I2Mprop by auto
  have H: "((\<hh>2\<ss>\<^sub>\<int>(fst(quotient_of(r)))) /\<^sub>\<rat> (\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(r))))) is Rat" by mty auto
  have "\<hh>2\<ss>\<^sub>\<rat>(r) =\<^sub>\<S> ((\<hh>2\<ss>\<^sub>\<int>(fst(quotient_of(r)))) /\<^sub>\<rat> (\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(r)))))" by auto
  thus  "\<hh>2\<ss>\<^sub>\<rat>(r) is Rat" using H by auto
qed

reserve a,b for Integer

theorem divZ_M: 
  "a dvd b iff (\<hh>2\<ss>\<^sub>\<int>( a ) divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b))"
proof(rule iffI3)
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>(a) be Integer" "\<hh>2\<ss>\<^sub>\<int>(b) be Integer" using h2sZprop by auto
  show "a dvd b \<longrightarrow> \<hh>2\<ss>\<^sub>\<int>(a) divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b)"
  proof
    assume "a dvd b"
    then obtain c where
      C: "b =\<^sub>\<H> a *\<^sub>\<H>  c" by auto
    have [ty]: "\<hh>2\<ss>\<^sub>\<int>(c) be Integer" using h2sZprop by auto
    have "\<hh>2\<ss>\<^sub>\<int>(b) = h2sZ(a)  *\<^sub>\<S>\<^sup>\<real> h2sZ(c)" using C MultIntI by auto
    thus "\<hh>2\<ss>\<^sub>\<int>( a ) divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b)" using bexI[of _ "h2sZ(c)" Integer] rat_1_divides by mty auto
  qed
  assume "\<hh>2\<ss>\<^sub>\<int>(a) divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b)"
  then obtain c where [ty]: "c be Integer" and
     C: "\<hh>2\<ss>\<^sub>\<int>(b) = h2sZ(a)  *\<^sub>\<S>\<^sup>\<real> c" using rat_1_divides by mty auto
  hence "b =\<^sub>\<H> a *\<^sub>\<H> s2hZ(c)" using MultIntM IMIZprop[of b] IMIZprop[of a] by auto
  thus "a dvd b" by auto
qed

mtheorem divZ_I:
  "\<ss>2\<hh>\<^sub>\<int>(a) dvd \<ss>2\<hh>\<^sub>\<int>(b) iff ( a divides\<^sub>\<int> b)"
proof-
  have "h2sZ(\<ss>2\<hh>\<^sub>\<int>(a)) = a" "h2sZ(\<ss>2\<hh>\<^sub>\<int>(b)) = b" using MIMZprop by mty auto
  thus ?thesis using divZ_M by auto 
qed

theorem coprime_I: 
  "coprime(a,b)  iff coprimeM \<hh>2\<ss>\<^sub>\<int>( a ),\<hh>2\<ss>\<^sub>\<int>( b )"
proof(rule iffI3)
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>(a) be Integer" "\<hh>2\<ss>\<^sub>\<int>(b) be Integer" using h2sZprop by auto
  show "coprime(a,b)  implies coprimeM \<hh>2\<ss>\<^sub>\<int>( a ),\<hh>2\<ss>\<^sub>\<int>( b )"
  proof(rule impI,standard)
    assume AS: "coprime(a, b)"
    show [ty]: "\<hh>2\<ss>\<^sub>\<int>(a) be Integer" "\<hh>2\<ss>\<^sub>\<int>(b) be Integer" using h2sZprop by auto
    show "\<forall>k : Integer. k divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(a)  \<and> k divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b)  \<longrightarrow> k divides\<^sub>\<int> succ {}"
    proof(intro ballI impI)
      fix k assume [ty]:"k be Integer" and A2:"k divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(a)  \<and> k divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b)"
      hence "s2hZ(k) dvd s2hZ(\<hh>2\<ss>\<^sub>\<int>(a))" "s2hZ(k) dvd s2hZ(\<hh>2\<ss>\<^sub>\<int>(b))" using divZ_I[of _ k] by mty auto
      hence "s2hZ(k) dvd a " "s2hZ(k) dvd b" using IMIZprop by mty auto
      hence "s2hZ(k) dvd 1" using AS coprime_common_divisor by blast
      hence "h2sZ(s2hZ(k)) divides\<^sub>\<int> h2sZ(1)" using divZ_M by auto
      thus "k divides\<^sub>\<int> succ {}" using  MIMZprop[of k] by auto
    qed mauto
  qed
  assume AS: "coprimeM \<hh>2\<ss>\<^sub>\<int>( a ),\<hh>2\<ss>\<^sub>\<int>( b )"
  show "coprime(a,b)"
  proof(rule coprimeI)
    fix c 
    have [ty]: "\<hh>2\<ss>\<^sub>\<int>(c) be Integer" using h2sZprop by auto
    assume "c dvd a" "c dvd b"
    hence "\<hh>2\<ss>\<^sub>\<int>( c ) divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(a)" "\<hh>2\<ss>\<^sub>\<int>( c ) divides\<^sub>\<int> \<hh>2\<ss>\<^sub>\<int>(b)" using divZ_M by auto
    hence "\<hh>2\<ss>\<^sub>\<int>( c )  divides\<^sub>\<int> h2sZ(1)" using AS rat_1_coprimeME[of "\<hh>2\<ss>\<^sub>\<int>(a)" "\<hh>2\<ss>\<^sub>\<int>(b)"] by mty auto
    thus "c dvd 1" using divZ_M by auto
  qed
qed

mtheorem coprime_M: 
" coprimeM a,b iff coprime(\<ss>2\<hh>\<^sub>\<int>(a), \<ss>2\<hh>\<^sub>\<int>(b))"
proof-
  have "h2sZ(\<ss>2\<hh>\<^sub>\<int>(a)) = a" "h2sZ(\<ss>2\<hh>\<^sub>\<int>(b)) = b" using MIMZprop by mty auto
  thus ?thesis using coprime_I by auto 
qed

theorem nonzero_snd:
  "\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(x)))<>{}"
proof
  assume "\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(x))) = {}"
  hence "s2hZ(\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(x))))  =\<^sub>\<H> s2hZ({})" "{} is Nat" by mty auto
  hence "snd(quotient_of(x))  =\<^sub>\<H> 0" using IMIZprop by mty auto
  thus False using quotient_of_denom_pos'[of x] by auto
qed

reserve x,y,r,s for Rat

theorem nonzero_denominator:
  "x is Rat \<longrightarrow> \<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(x)) >0"
proof
  assume [ty]: "x is Rat"
  hence "denominator\<^sub>\<rat>(x)<>{}" using  rat_1_d_zero[of x] by mty auto
  thus " \<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(x)) >0" using  MIMZprop[of "denominator\<^sub>\<rat>(x)"] 
     \<hh>2\<ss>_greater_zero[of "\<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(x))"] by mty auto
qed

theorem IMIQprop:
  "\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x)) =\<^sub>\<H> x"
proof-
  let ?f = "fst(quotient_of(x))" let ?s = "snd(quotient_of(x))"
  let ?y= "\<hh>2\<ss>\<^sub>\<int>(?f) /\<^sub>\<rat> (\<hh>2\<ss>\<^sub>\<int>(?s))" 
  have "?s>0" using quotient_of_denom_pos' by auto
  hence [ty]:"\<hh>2\<ss>\<^sub>\<int>(?s) is Nat" using I2Mprop by auto
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>(?f) is Integer" using h2sZprop by auto
  have "coprime(?f,?s)" using quotient_of_coprime by auto
  hence F1: " coprimeM \<hh>2\<ss>\<^sub>\<int>( ?f ),\<hh>2\<ss>\<^sub>\<int>(?s )"
    using coprime_I by mty auto
  hence "numerator\<^sub>\<rat>(?y) = \<hh>2\<ss>\<^sub>\<int>(?f)" "denominator\<^sub>\<rat>(?y) = \<hh>2\<ss>\<^sub>\<int>(?s)" 
    using rat_1_cop_5 nonzero_snd F1 by auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(?y) =\<^sub>\<H> Fract(?f,?s)" using  IMIZprop  IMIprop by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(?y) =\<^sub>\<H> x " 
     using Fract_of_int_quotient quotient_of_div by auto
  thus ?thesis by auto
qed



mtheorem MIMQprop:
  "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) = x"
proof-
  let ?n="\<ss>2\<hh>\<^sub>\<int>(numerator\<^sub>\<rat>(x))" 
  let ?d="\<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(x))"
  let ?f="Fract(?n,?d)"
  have "\<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> ?f" by auto
  hence H: "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) =  ((\<hh>2\<ss>\<^sub>\<int>(fst(quotient_of(?f)))) /\<^sub>\<rat> (\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(?f)))))" by auto
  have  "coprimeM numerator\<^sub>\<rat>(x), denominator\<^sub>\<rat>(x)" using rat_1_cop_2 by auto
  hence "coprime(?n,?d)" "?d >0" using coprime_M nonzero_denominator[of x] by mty auto
  hence "Rat.normalize((?n, ?d)) =\<^sub>\<H> (?n, ?d)"  by auto
  hence "quotient_of(?f) =\<^sub>\<H> (?n, ?d)" using quotient_of_Fract by auto 
  hence "fst(quotient_of(?f)) =\<^sub>\<H> ?n" "snd(quotient_of(?f)) =\<^sub>\<H> ?d" by auto
  hence "\<hh>2\<ss>\<^sub>\<int>(fst(quotient_of(?f))) = numerator\<^sub>\<rat>(x)" "\<hh>2\<ss>\<^sub>\<int>(snd(quotient_of(?f))) =\<^sub>\<H> denominator\<^sub>\<rat>(x)"
       using MIMZprop[of "numerator\<^sub>\<rat>(x)"] MIMZprop[of "denominator\<^sub>\<rat>(x)"] by mty auto
  hence "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) =  ((numerator\<^sub>\<rat>(x)) /\<^sub>\<rat> (denominator\<^sub>\<rat>(x)))" using H by simp
  thus "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) = x" using rat_1_th_1 by mauto
qed 
text_raw {*\DefineSnippet{s2hQM}{*}
theorem s2hQM:
  "i is Integer \<and> n is Nat \<and> n \<noteq> {} \<longrightarrow> \<ss>2\<hh>\<^sub>\<rat>(i /\<^sub>\<rat> n) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(i),\<ss>2\<hh>\<^sub>\<int>(n))"
text_raw {*}%EndSnippet*}
proof
  let ?r = "i /\<^sub>\<rat> n"
  assume N: "i is Integer \<and> n is Nat \<and>n<>{}"
  hence [ty]:"i is Integer \<and> n is Nat" by simp
  obtain a where [ty]:"a be Nat" and 
   A: "a<>{} & a *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(?r)) = i \<and>  a *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(?r)) = n" 
    using rat_1_th_13[of i n] N by mty auto
  have S: "\<ss>2\<hh>\<^sub>\<rat>(?r) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(numerator\<^sub>\<rat>(?r)),\<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(?r)))"  by mty auto
  have Z1: "\<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(?r)) > 0" using nonzero_denominator[of ?r] by mty auto
  have "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(n)) =\<^sub>\<S> n" using  N MIMZprop[of "n"] by mty auto
  hence Z2: "not \<ss>2\<hh>\<^sub>\<int>(n)  =\<^sub>\<H> 0" using  N by force
  have "\<ss>2\<hh>\<^sub>\<int>(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(a) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(?r))"
       "\<ss>2\<hh>\<^sub>\<int>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(a) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(numerator\<^sub>\<rat>(?r))" using A MultIntM[of a "denominator\<^sub>\<rat>(?r)"]
        MultIntM[of a "numerator\<^sub>\<rat>(?r)"]  by mty auto
  hence "\<ss>2\<hh>\<^sub>\<int>(numerator\<^sub>\<rat>(?r)) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(n)  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(?r))" by auto
  thus "\<ss>2\<hh>\<^sub>\<rat>(?r) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(i),\<ss>2\<hh>\<^sub>\<int>(n))" 
    using  S Z1 Z2 eq_rat(1)[of "\<ss>2\<hh>\<^sub>\<int>(denominator\<^sub>\<rat>(?r))" "\<ss>2\<hh>\<^sub>\<int>(n)" "\<ss>2\<hh>\<^sub>\<int>(numerator\<^sub>\<rat>(?r))" "\<ss>2\<hh>\<^sub>\<int>(i)"] 
    by auto
qed
text_raw {*\DefineSnippet{s2hQI}{*}
theorem s2hQI:
  fixes n::nat
  shows "n \<noteq>\<^sub>\<H> 0 \<longrightarrow> Fract(i,n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(h2sZ(i) /\<^sub>\<rat> h2sZ(n)) "
text_raw {*}%EndSnippet*}
proof
  have [ty]:"h2sZ(i) is Integer" "h2sn(n) is Nat" 
       using h2sZprop I2Mprop by auto
  assume "n \<noteq>\<^sub>\<H> 0"
  hence " h2sn(n)<>{}"  by (simp add: EqI)
  hence  "\<ss>2\<hh>\<^sub>\<rat>(h2sZ(i) /\<^sub>\<rat> h2sn(n)) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(h2sZ(i)),\<ss>2\<hh>\<^sub>\<int>(h2sZ(n)))"
    using s2hQM by auto
   hence  "\<ss>2\<hh>\<^sub>\<rat>(h2sZ(i) /\<^sub>\<rat> h2sn(n)) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(h2sZ(i)),\<ss>2\<hh>\<^sub>\<int>(h2sZ(n)))"
    using s2hQM by auto
  thus "Fract(i,n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(h2sZ(i) /\<^sub>\<rat> h2sZ(n))" using IMIZprop[of i] 
   IMIZprop[of n] by auto
qed

theorem s2hQZ:
   "i is Integer \<longrightarrow> \<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i)"
proof
  assume [ty]: "i is Integer"
  have I: "i = (numerator\<^sub>\<rat> i) /\<^sub>\<rat> (denominator\<^sub>\<rat> i)" using rat_1_th_1[of i] by mty auto

  show "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i)"
  proof(cases "i is Nat")
    case T[ty]:True
         have "i in NAT" using ordinal1_def_12[of i] by mauto
         hence "denominator(i) = 1\<^sub>\<S>" "numerator(i) = i" 
           using arytm_3_def_9[of i] arytm_3_def_8[of i]
          by mauto
        hence  "(denominator\<^sub>\<rat> i) = 1\<^sub>\<S>" "(numerator\<^sub>\<rat> i) = i" using rat_1_d rat_1_n
          by mauto
        hence "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(i),\<ss>2\<hh>\<^sub>\<int>(succ {}))" using s2hQM[of "i" "succ {}"] I by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(i),1)" by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i) / 1" 
          by (metis Fract_of_int_quotient div_by_1 of_int_1 of_rat_of_int_eq of_real_of_int_eq)
        thus "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i)" by (smt div_by_1 of_real_of_int_eq) 
      next
        case False
        hence [ty]:"i is non natural" and i: "i<>{}" using all_set by mty auto
        have T[ty]: "-\<^sub>\<S>\<^sup>\<real> i is Nat"  by mty auto

        have  [ty]:"not i is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using i rat_0_th_19[of i] by mty auto
      

        have "(denominator\<^sub>\<rat> i) = denominator(-\<^sub>\<S>\<^sup>\<real> i)"
          "(numerator\<^sub>\<rat> i) = -\<^sub>\<S>\<^sup>\<real> (numerator( -\<^sub>\<S>\<^sup>\<real> i))" "-\<^sub>\<S>\<^sup>\<real> i in NAT" 
          using rat_1_d rat_1_n ordinal1_def_12[of "-\<^sub>\<S>\<^sup>\<real> i"] by mty auto
        
        hence "(denominator\<^sub>\<rat> i) = 1\<^sub>\<S>" "(numerator\<^sub>\<rat> i) = -\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> i)"
           using arytm_3_def_9[of "-\<^sub>\<S>\<^sup>\<real> i"] arytm_3_def_8[of "-\<^sub>\<S>\<^sup>\<real> i"]
          by mauto
        hence  "(denominator\<^sub>\<rat> i) = 1\<^sub>\<S>" "(numerator\<^sub>\<rat> i) = i" using real_0_th_20a
          by mauto
        hence "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(i),\<ss>2\<hh>\<^sub>\<int>(succ {}))" using s2hQM[of "i" "succ {}"] I by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> Fract(\<ss>2\<hh>\<^sub>\<int>(i),1)" by mty auto
        hence "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i) / 1" 
          by (metis Fract_of_int_quotient div_by_1 of_int_1 of_rat_of_int_eq of_real_of_int_eq)
        thus "\<ss>2\<hh>\<^sub>\<rat>(i) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i)" by (smt div_by_1 of_real_of_int_eq)           
      qed
    qed


theorem s2hQr:
  "\<hh>2\<ss>\<^sub>\<rat>(rat_of_int(i)) = \<hh>2\<ss>\<^sub>\<int>(i)"
proof-
  have [ty]:"\<hh>2\<ss>\<^sub>\<int>(i) is Integer" using h2sZprop by auto
  have R1:"\<hh>2\<ss>\<^sub>\<rat>(rat_of_int(i)) is Rat" "\<hh>2\<ss>\<^sub>\<int>(i) is Rat" using h2sQprop by mty auto
  have E:"s2hZ(h2sZ(i)) =\<^sub>\<H>\<ss>2\<hh>\<^sub>\<rat>(h2sZ(i))" using s2hQZ[of "\<hh>2\<ss>\<^sub>\<int>(i)"] by mty auto

  have "rat_of_int(i) =\<^sub>\<H> i" by auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(rat_of_int(i)))  =\<^sub>\<H> s2hZ(h2sZ(i))" using IMIQprop IMIZprop by auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(rat_of_int(i)))  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(h2sZ(i))" using E by auto
  thus "(\<hh>2\<ss>\<^sub>\<rat>(rat_of_int(i)))  =\<^sub>\<H> (h2sZ(i))" using MIMQprop[OF R1(2)]
     MIMQprop[OF R1(1)] by mty auto
qed

mtheorem RatAddM:
  "\<ss>2\<hh>\<^sub>\<rat>(x +\<^sub>\<S>\<^sup>\<real> y) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y)"
proof-  
  let ?nx="numerator\<^sub>\<rat>(x)"
  let ?dx="denominator\<^sub>\<rat>(x)"
  let ?fx="Fract(\<ss>2\<hh>\<^sub>\<int>(?nx),\<ss>2\<hh>\<^sub>\<int>(?dx))"
  let ?ny="numerator\<^sub>\<rat>(y)"
  let ?dy="denominator\<^sub>\<rat>(y)"
  let ?fy="Fract(\<ss>2\<hh>\<^sub>\<int>(?ny),\<ss>2\<hh>\<^sub>\<int>(?dy))"
  have HH:"?dx *\<^sub>\<S>\<^sup>\<nat> ?dy = ?dx *\<^sub>\<S>\<^sup>\<real> ?dy" using int_1_def_5 by mty auto
  have "x = ?nx /\<^sub>\<rat> ?dx" "y = ?ny /\<^sub>\<rat> ?dy" "?dx<>{}" "?dy<>{}" 
    using rat_1_th_1[of x] rat_1_th_1[of y] 
          rat_1_d_zero[of x] rat_1_d_zero[of y] by mty auto 
  hence H: "x +\<^sub>\<S>\<^sup>\<real> y = ((?nx *\<^sub>\<S>\<^sup>\<real> ?dy) +\<^sub>\<S>\<^sup>\<real> (?ny *\<^sub>\<S>\<^sup>\<real> ?dx)) /\<^sub>\<rat> (?dx *\<^sub>\<S>\<^sup>\<nat> ?dy)"
    using rat_1_th_12[of ?ny ?nx ?dy ?dx] HH by mty auto
  have "?dx <>{}" "?dy <>{}" using rat_1_d_zero[of x] rat_1_d_zero[of y] by mty auto
  hence "?dx *\<^sub>\<S>\<^sup>\<nat> ?dy<>{}" using Mult_9[of ?dy ?dx] by mty auto
  hence F:"\<ss>2\<hh>\<^sub>\<rat>(x +\<^sub>\<S>\<^sup>\<real> y) =\<^sub>\<H> Fract(s2hZ((?nx *\<^sub>\<S>\<^sup>\<real> ?dy) +\<^sub>\<S>\<^sup>\<real> (?ny *\<^sub>\<S>\<^sup>\<real> ?dx)),s2hZ(?dx *\<^sub>\<S>\<^sup>\<nat> ?dy))"
    using H s2hQM[of "(?nx *\<^sub>\<S>\<^sup>\<real> ?dy) +\<^sub>\<S>\<^sup>\<real> (?ny *\<^sub>\<S>\<^sup>\<real> ?dx)" "?dx *\<^sub>\<S>\<^sup>\<nat> ?dy" ] by mty auto

  have F1: "s2hZ(?dx *\<^sub>\<S>\<^sup>\<nat> ?dy) =\<^sub>\<H> s2hZ(?dx) *\<^sub>\<H> s2hZ(?dy)" using MultIntM[of ?dx ?dy] HH 
    by mty auto 
   have "s2hZ((?nx *\<^sub>\<S>\<^sup>\<real> ?dy) +\<^sub>\<S>\<^sup>\<real> (?ny *\<^sub>\<S>\<^sup>\<real> ?dx)) =\<^sub>\<H> 
           s2hZ(?nx *\<^sub>\<S>\<^sup>\<real> ?dy) +\<^sub>\<H> s2hZ(?ny *\<^sub>\<S>\<^sup>\<real> ?dx)" using AddIntM by mty auto
   hence F2: "s2hZ((?nx *\<^sub>\<S>\<^sup>\<real> ?dy) +\<^sub>\<S>\<^sup>\<real> (?ny *\<^sub>\<S>\<^sup>\<real> ?dx)) =\<^sub>\<H>  s2hZ(?nx) *\<^sub>\<H> s2hZ(?dy) +\<^sub>\<H> s2hZ(?ny) *\<^sub>\<H> s2hZ(?dx)" 
     using MultIntM by mty auto 

  have S: "\<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> ?fx" "\<ss>2\<hh>\<^sub>\<rat>(y) =\<^sub>\<H> ?fy" by auto
  have "\<ss>2\<hh>\<^sub>\<int>(?dx) >0" "\<ss>2\<hh>\<^sub>\<int>(?dy) >0" using nonzero_denominator[of x] nonzero_denominator[of y] 
    by mty auto
  hence "?fx  +\<^sub>\<H> ?fy =\<^sub>\<H> 
    Fract((\<ss>2\<hh>\<^sub>\<int>(?nx) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(?dy) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(?ny) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(?dx)),(\<ss>2\<hh>\<^sub>\<int>(?dx) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(?dy)))"
    using S add_rat[of "\<ss>2\<hh>\<^sub>\<int>(?dx)" "\<ss>2\<hh>\<^sub>\<int>(?dy)" "\<ss>2\<hh>\<^sub>\<int>(?nx)" "\<ss>2\<hh>\<^sub>\<int>(?ny)"] 
      by auto
  thus "\<ss>2\<hh>\<^sub>\<rat>(x +\<^sub>\<S>\<^sup>\<real> y) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y)" using F F1 F2 by auto
qed

theorem RatAddI:
  "\<hh>2\<ss>\<^sub>\<rat>(x +\<^sub>\<H> y) = \<hh>2\<ss>\<^sub>\<rat>(x) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)" 
proof-
  have T[ty]: "\<hh>2\<ss>\<^sub>\<rat>(x) is Rat" "\<hh>2\<ss>\<^sub>\<rat>(y) is Rat" "\<hh>2\<ss>\<^sub>\<rat>(x +\<^sub>\<H> y) is Rat" 
    using h2sQprop by mty auto
  hence H: "(\<hh>2\<ss>\<^sub>\<rat>(x) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)) be Rat" apply mty using ty by simp 
  have "x +\<^sub>\<H> y =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x))) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(y)))" using IMIQprop by mty auto
  hence "x +\<^sub>\<H> y =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y))" using RatAddM[OF T(2,1)] by simp
  then show "\<hh>2\<ss>\<^sub>\<rat>(x +\<^sub>\<H> y) = \<hh>2\<ss>\<^sub>\<rat>(x) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)" using MIMQprop[OF H]  by simp 
qed

mtheorem RatMultM:
  "\<ss>2\<hh>\<^sub>\<rat>(x *\<^sub>\<S>\<^sup>\<real> y) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y)"
proof-
  let ?nx="numerator\<^sub>\<rat>(x)"
  let ?dx="denominator\<^sub>\<rat>(x)"
  let ?fx="Fract(\<ss>2\<hh>\<^sub>\<int>(?nx),\<ss>2\<hh>\<^sub>\<int>(?dx))"
  let ?ny="numerator\<^sub>\<rat>(y)"
  let ?dy="denominator\<^sub>\<rat>(y)"
  let ?fy="Fract(\<ss>2\<hh>\<^sub>\<int>(?ny),\<ss>2\<hh>\<^sub>\<int>(?dy))"
  have HH:"?dx *\<^sub>\<S>\<^sup>\<nat> ?dy = ?dx *\<^sub>\<S>\<^sup>\<real> ?dy" using int_1_def_5 by mty auto
  have "x = ?nx /\<^sub>\<rat> ?dx" "y = ?ny /\<^sub>\<rat> ?dy" "?dx<>{}" "?dy<>{}" 
    using rat_1_th_1[of x] rat_1_th_1[of y] 
          rat_1_d_zero[of x] rat_1_d_zero[of y] by mty auto 
  hence H: "x *\<^sub>\<S>\<^sup>\<real> y = ((?nx *\<^sub>\<S>\<^sup>\<real> ?ny) ) /\<^sub>\<rat> (?dx *\<^sub>\<S>\<^sup>\<nat> ?dy)"
    using rat_1_th_14[of ?ny ?nx ?dy ?dx] HH by mty auto
  have "?dx <>{}" "?dy <>{}" using rat_1_d_zero[of x] rat_1_d_zero[of y] by mty auto
  hence "?dx *\<^sub>\<S>\<^sup>\<nat> ?dy<>{}" using Mult_9[of ?dy ?dx] by mty auto
  hence F:"\<ss>2\<hh>\<^sub>\<rat>(x *\<^sub>\<S>\<^sup>\<real> y) =\<^sub>\<H> Fract(s2hZ(?nx *\<^sub>\<S>\<^sup>\<real> ?ny),s2hZ(?dx *\<^sub>\<S>\<^sup>\<nat> ?dy))"
    using H s2hQM[ of "?nx *\<^sub>\<S>\<^sup>\<real> ?ny" "?dx *\<^sub>\<S>\<^sup>\<nat> ?dy"] by mty auto
  have F1: "s2hZ(?dx *\<^sub>\<S>\<^sup>\<nat> ?dy) =\<^sub>\<H> s2hZ(?dx) *\<^sub>\<H> s2hZ(?dy)" using MultIntM[of ?dx ?dy] HH by mty auto 
  have F2: "s2hZ(?nx *\<^sub>\<S>\<^sup>\<real> ?ny) =\<^sub>\<H> s2hZ(?nx) *\<^sub>\<H> s2hZ(?ny)" using MultIntM[of ?nx ?ny] HH by mty auto 
  have S: "\<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> ?fx" "\<ss>2\<hh>\<^sub>\<rat>(y) =\<^sub>\<H> ?fy" by auto
  have "\<ss>2\<hh>\<^sub>\<int>(?dx) >0" "\<ss>2\<hh>\<^sub>\<int>(?dy) >0" using nonzero_denominator[of x] nonzero_denominator[of y] by mty auto
  hence "?fx  *\<^sub>\<H> ?fy =\<^sub>\<H> Fract((\<ss>2\<hh>\<^sub>\<int>(?nx) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(?ny)),(\<ss>2\<hh>\<^sub>\<int>(?dx) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(?dy)))"
    using S mult_rat by auto
  thus ?thesis using F F1 F2 by auto
qed

mtheorem RatMultI:
  "\<hh>2\<ss>\<^sub>\<rat>(x *\<^sub>\<H> y) = \<hh>2\<ss>\<^sub>\<rat>(x) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)"
proof-
  have T[ty]: "\<hh>2\<ss>\<^sub>\<rat>(x) is Rat" "\<hh>2\<ss>\<^sub>\<rat>(y) is Rat" "\<hh>2\<ss>\<^sub>\<rat>(x +\<^sub>\<H> y) is Rat" 
    using h2sQprop by mty auto
  hence H: "(\<hh>2\<ss>\<^sub>\<rat>(x) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)) be Rat" apply mty using ty by simp 
  have "x *\<^sub>\<H> y =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x))) *\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(y)))" using IMIQprop by mty auto
  hence "x *\<^sub>\<H> y =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y))" using RatMultM[OF T(2,1)] by simp
  then show "\<hh>2\<ss>\<^sub>\<rat>(x *\<^sub>\<H> y) = \<hh>2\<ss>\<^sub>\<rat>(x) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)" using MIMQprop[OF H]  by simp 
qed

theorem RatPositive: 
  "Rat.positive(x) \<longleftrightarrow> ((\<hh>2\<ss>\<^sub>\<rat>(x) is Element-of RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<hh>2\<ss>\<^sub>\<rat>(x) <> {})  "
proof(rule iffI3)
  have [ty]: "\<hh>2\<ss>\<^sub>\<rat>(x) is Rat" using h2sQprop by mty auto
  let ?q="quotient_of(x)"
  have HS: "\<hh>2\<ss>\<^sub>\<rat>(x) = ((\<hh>2\<ss>\<^sub>\<int>(fst(?q))) /\<^sub>\<rat> (\<hh>2\<ss>\<^sub>\<int>(snd(?q))))" "\<hh>2\<ss>\<^sub>\<int>(snd(?q))<>{}" 
    using nonzero_snd by auto

    have "snd(?q)>0"  by (simp add: quotient_of_denom_pos')
    hence "\<hh>2\<ss>\<^sub>\<int>(snd(?q)) = \<hh>2\<ss>\<^sub>\<nat>(nat(snd(?q)))" by auto
    hence[ty]:"\<hh>2\<ss>\<^sub>\<int>(snd(?q)) is Nat" using I2Mprop by auto

  show "Rat.positive(x) \<longrightarrow> ((\<hh>2\<ss>\<^sub>\<rat>(x) is Element-of RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<hh>2\<ss>\<^sub>\<rat>(x) <> {})"
  proof(intro impI conjI)
    assume R: "Rat.positive(x)"
    hence O: "0 < fst(?q) *\<^sub>\<H> snd(?q)" 
      using Fract_of_int_quotient positive_rat quotient_of_div by fastforce
    have S: "snd(?q) >0"  by (simp add: quotient_of_denom_pos')
    hence F: "fst(?q) >0" using O using zero_less_mult_pos2 by blast
    hence ZN: "\<hh>2\<ss>\<^sub>\<int>(fst(?q)) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(nat(fst(?q)))  " 
      using h2sZ.psimps IMIZprop[of "fst(?q)"]   by auto
    hence [ty]: "\<hh>2\<ss>\<^sub>\<int>(fst(?q)) is Nat" using I2Mprop by auto
    have F0: "\<hh>2\<ss>\<^sub>\<int>(fst(?q))<>{}"
    proof
      assume "\<hh>2\<ss>\<^sub>\<int>(fst(?q)) = {}"
      hence "\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(nat(fst(?q)))) =\<^sub>\<H> 0" using ZN s2hn.simps by auto
      thus False using IMIprop F by auto
     qed

    have R: "\<hh>2\<ss>\<^sub>\<rat>(x) = ((\<hh>2\<ss>\<^sub>\<int>(fst(?q))) /\<^bsub>\<rat>\<ge>0\<^bsup> (\<hh>2\<ss>\<^sub>\<int>(snd(?q))))" using rat_1_div by mty auto
    thus [ty]: "\<hh>2\<ss>\<^sub>\<rat>(x) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto


  have "coprime(fst(?q),snd(?q))" using quotient_of_coprime by auto
  hence " coprimeM \<hh>2\<ss>\<^sub>\<int>( fst(?q) ),\<hh>2\<ss>\<^sub>\<int>(snd(?q) )"
    using coprime_I by mty auto
  hence "numerator\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x)) = \<hh>2\<ss>\<^sub>\<int>(fst(?q))"   
    using rat_1_cop_5[of "\<hh>2\<ss>\<^sub>\<int>( fst(?q) )" "\<hh>2\<ss>\<^sub>\<int>(snd(?q) )",simplified]  HS by mty auto
  hence "numerator(\<hh>2\<ss>\<^sub>\<rat>(x)) = \<hh>2\<ss>\<^sub>\<int>(fst(?q))" using rat_1_n[of "\<hh>2\<ss>\<^sub>\<rat>(x)",simplified] by mty auto 
  thus "\<hh>2\<ss>\<^sub>\<rat>(x)<>{}" using F0 arytm_3_th_37[of "\<hh>2\<ss>\<^sub>\<rat>(x)"] by mty auto
qed
  obtain h where
    H: "h= \<hh>2\<ss>\<^sub>\<rat>(x)" by simp
  have S: "snd(?q) >0"  by (simp add: quotient_of_denom_pos')
  assume A: "((\<hh>2\<ss>\<^sub>\<rat>(x) is Element-of RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<hh>2\<ss>\<^sub>\<rat>(x) <> {})"
  hence [ty]:"h is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using H by auto
  have Z: "numerator(h)<>{}" using arytm_3_th_37[of "h"] A H by auto
  have NN: "numerator\<^sub>\<rat> h =\<^sub>\<S> numerator(h)" using rat_1_n[of h] by mty auto 
  hence NN1[ty]: "(numerator\<^sub>\<rat> h) is Nat" by mty auto
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>( fst(?q) ) is Integer" using h2sZprop by auto
  have "coprime(fst(?q),snd(?q))" using quotient_of_coprime by auto
  hence " coprimeM \<hh>2\<ss>\<^sub>\<int>( fst(?q) ),\<hh>2\<ss>\<^sub>\<int>(snd(?q) )"
    using coprime_I by mty auto
  hence "numerator\<^sub>\<rat>(h) = \<hh>2\<ss>\<^sub>\<int>(fst(?q))"  "denominator\<^sub>\<rat> (h) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<int>(snd(?q))"
    using rat_1_cop_5[of "\<hh>2\<ss>\<^sub>\<int>( fst(?q) )" "\<hh>2\<ss>\<^sub>\<int>(snd(?q) )",simplified]  HS H by mty auto
  hence "fst(?q) >0" using Z NN lessZ[of "fst(?q)"] NN1 by auto
  hence "0 < fst(?q) *\<^sub>\<H> snd(?q)" using S by auto
  thus "Rat.positive(x)" using Fract_of_int_quotient positive_rat quotient_of_div surjective_pairing
    by metis
qed

theorem Ratless:
   "r < s \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<rat>(r) <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(s)"
proof
  let ?sr="s -\<^sub>\<H> r"
  assume "r < s"
  hence "Rat.positive(?sr)" using less_rat_def by auto
  hence "(\<hh>2\<ss>\<^sub>\<rat>(?sr) is Element-of RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<hh>2\<ss>\<^sub>\<rat>(?sr) <> {}"
    using RatPositive by auto
  then obtain sr where [ty]:"sr is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
    A1:"\<hh>2\<ss>\<^sub>\<rat>(?sr) = sr" "sr <>{}" by auto
  have [ty]:"\<hh>2\<ss>\<^sub>\<rat>(s) is Rat" "\<hh>2\<ss>\<^sub>\<rat>(r) is Rat" using h2sQprop by auto
  hence [ty]:"\<hh>2\<ss>\<^sub>\<rat>(s) is MReal" "\<hh>2\<ss>\<^sub>\<rat>(r) is Mreal" using rat_real by mty auto
  have "s -\<^sub>\<H> r +\<^sub>\<H> r =\<^sub>\<H> s" by simp
  hence A2: "\<hh>2\<ss>\<^sub>\<rat>(s) = sr +\<^sub>\<S>\<^sup>\<real>  \<hh>2\<ss>\<^sub>\<rat>(r)" using RatAddI[of ?sr r] A1 by auto
  hence "\<hh>2\<ss>\<^sub>\<rat>(s) =  \<hh>2\<ss>\<^sub>\<rat>(r) +\<^sub>\<S>\<^sup>\<real> sr" using real_0_th_11[of sr "\<hh>2\<ss>\<^sub>\<rat>(r)"] ty by mty auto
  hence A3: "\<hh>2\<ss>\<^sub>\<rat>(r) \<le>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(s)" "\<hh>2\<ss>\<^sub>\<rat>(r) <> \<hh>2\<ss>\<^sub>\<rat>(s)"
    using rat_1_th_15[of sr "\<hh>2\<ss>\<^sub>\<rat>(r)"] A1
      rat_0_def_8 bexI[of _ sr "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] ty by mty auto
  thus "\<hh>2\<ss>\<^sub>\<rat>(r) <\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(s)"  using real_0_def_8s[of "\<hh>2\<ss>\<^sub>\<rat>(r)" "\<hh>2\<ss>\<^sub>\<rat>(s)" ] ty  by mty auto
next
  let ?hr = "\<hh>2\<ss>\<^sub>\<rat>(r)" let ?hs = "\<hh>2\<ss>\<^sub>\<rat>(s)" 
  have [ty]: "?hr is Rat" "?hs is Rat" using h2sQprop by mty auto
  hence [ty]: "?hr is MReal" "?hs is MReal" using rat_real by mty auto
  assume  "?hr <\<^sup>\<real> ?hs"
  hence H0: "?hr \<le>\<^sup>\<real> ?hs" "?hr <> ?hs" using real_0_th_33[of ?hr ?hs] ty by auto
  then obtain  z where W[ty]: "z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    H1:"?hs = ?hr +\<^sub>\<S>\<^sup>\<real> z" using rat_0_def_8 by mauto
  have Z1: "z<>{}" using real_0_th_8 H0 H1 by mauto
  have Z: "z = \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(z))" using MIMQprop[of z] by mty auto
  hence "?hs = \<hh>2\<ss>\<^sub>\<rat>(r +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(z))" using RatAddI H1 by auto
  hence "s  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(r +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(z)))" using IMIQprop[of s] by auto 
  hence  "s  =\<^sub>\<H> r +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(z)" using IMIQprop[of "r +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(z)"] by auto 
  hence Q: "\<ss>2\<hh>\<^sub>\<rat>(z) =\<^sub>\<H> s -\<^sub>\<H> r" by auto
  have "Rat.positive(\<ss>2\<hh>\<^sub>\<rat>(z))" using Z H1 RatPositive[of "\<ss>2\<hh>\<^sub>\<rat>(z)",THEN iffD2] W Z1 by auto
  thus "r < s" using Q less_rat_def by auto
qed

theorem Rateq:
  "r \<le> s \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<rat>(r) \<le>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(s)" using Ratless[of s r] by mty auto


theorem Qzero:
  "\<ss>2\<hh>\<^sub>\<rat>({}) =\<^sub>\<H> 0" "\<hh>2\<ss>\<^sub>\<rat>(0) = {}"
proof-
  have Z: "\<ss>2\<hh>\<^sub>\<int>({})=\<^sub>\<H>0" using IMIZprop[of 0] zeroZ[of "0"]  by mty auto
  have "\<ss>2\<hh>\<^sub>\<int>(succ {})=\<^sub>\<H> 1" by mty auto 
  have "{}= {}/\<^bsub>\<rat>\<ge>0\<^bsup> succ{}"  using arytm_3_th_40 by mauto
  hence "{} = ({} /\<^sub>\<rat> (succ{}))" using rat_1_div by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>({}) =\<^sub>\<H> Fract(0,1)" using s2hQM[of "{}" "succ{}"] by mty auto
  thus "\<ss>2\<hh>\<^sub>\<rat>({}) =\<^sub>\<H> 0" using Zero_rat_def by auto
  thus  "\<hh>2\<ss>\<^sub>\<rat>(0) = {}" using MIMQprop[of "{}"] by mty auto
qed

mtheorem RatMinusM:
  "\<ss>2\<hh>\<^sub>\<rat>(-\<^sub>\<S>\<^sup>\<real> x) =\<^sub>\<H> -\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x)" 
proof-
  have "(-\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<S>\<^sup>\<real> x ={}" using real_0_def_5 by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(-\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>({})"
       using RatAddM[of x "-\<^sub>\<S>\<^sup>\<real> x"] by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(-\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x) =\<^sub>\<H> 0" using Qzero by mty auto
  thus  ?thesis using  eq_neg_iff_add_eq_0[of "\<ss>2\<hh>\<^sub>\<rat>(-\<^sub>\<S>\<^sup>\<real> x)" "\<ss>2\<hh>\<^sub>\<rat>(x)"] by mty auto
qed

mtheorem RatMinusI:
  "\<hh>2\<ss>\<^sub>\<rat>(-\<^sub>\<H> x) = (-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(x))" 
proof-
  obtain h where[ty]: "h is Rat" and
    h: "h=\<hh>2\<ss>\<^sub>\<rat>(x)" using h2sQprop by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(-\<^sub>\<S>\<^sup>\<real> h) =\<^sub>\<H> -\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(x))" using RatMinusM[of "\<hh>2\<ss>\<^sub>\<rat>(x)"]  
      by mty auto
    hence "\<ss>2\<hh>\<^sub>\<rat>(-\<^sub>\<S>\<^sup>\<real> h) =\<^sub>\<H> -\<^sub>\<H> x" using IMIQprop by mty auto
    hence "-\<^sub>\<S>\<^sup>\<real> h = \<hh>2\<ss>\<^sub>\<rat>(-\<^sub>\<H> x)" using MIMQprop[of "-\<^sub>\<S>\<^sup>\<real> h"] by mty auto
    thus ?thesis using h by auto
qed

theorem RatMI:
  "\<hh>2\<ss>\<^sub>\<rat>(x -\<^sub>\<H> y) = \<hh>2\<ss>\<^sub>\<rat>(x) -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)" 
proof-
   have A1[ty]: "\<hh>2\<ss>\<^sub>\<rat>(x) is Rat" "\<hh>2\<ss>\<^sub>\<rat>(y) is Rat" using h2sQprop by auto
   hence A2: "\<hh>2\<ss>\<^sub>\<rat>(x) is MReal" "\<hh>2\<ss>\<^sub>\<rat>(y) is MReal" using rat_real by mty auto
  have "\<hh>2\<ss>\<^sub>\<rat>(x -\<^sub>\<H> y) = \<hh>2\<ss>\<^sub>\<rat>(x +\<^sub>\<H> (-\<^sub>\<H> y))" by auto 
  also have "... = \<hh>2\<ss>\<^sub>\<rat>(x) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(-\<^sub>\<H> y)" using RatAddI[of x "-\<^sub>\<H> y"] by mty auto
  also have "... = \<hh>2\<ss>\<^sub>\<rat>(x) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y))" using RatMinusI[of y] by mty auto
  also have "... = \<hh>2\<ss>\<^sub>\<rat>(x) -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(y)" using real_0_def_6[OF A2(1,2)] by mty auto
  finally show ?thesis by auto
qed

mtheorem RatMM:
  "\<ss>2\<hh>\<^sub>\<rat>(x -\<^sub>\<S>\<^sup>\<real> y) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x) -\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(y)" 
proof-
  have "\<hh>2\<ss>\<^sub>\<rat>((\<ss>2\<hh>\<^sub>\<rat>(x)) -\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(y))) = \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(y))"  
    using RatMI by mty auto
  hence "\<hh>2\<ss>\<^sub>\<rat>((\<ss>2\<hh>\<^sub>\<rat>(x)) -\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(y))) = x -\<^sub>\<S>\<^sup>\<real> y" using MIMQprop by mty auto
  hence "\<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>((\<ss>2\<hh>\<^sub>\<rat>(x)) -\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<rat>(y)))) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x -\<^sub>\<S>\<^sup>\<real> y)" using MIMQprop by mty auto
  thus ?thesis using IMIQprop by mty auto   
qed

mtheorem rat_abs: 
  "\<ss>2\<hh>\<^sub>\<rat>( |. x .| ) =\<^sub>\<H> \<bar> \<ss>2\<hh>\<^sub>\<rat>(x) \<bar>" 
proof-
  have Z:"\<ss>2\<hh>\<^sub>\<rat>({}) =\<^sub>\<H> 0" using Qzero by mty auto
  have X: "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) = x" "\<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>({})) = {}" using MIMQprop by mty auto
  show  "\<ss>2\<hh>\<^sub>\<rat>( |. x .| ) =\<^sub>\<H> \<bar> \<ss>2\<hh>\<^sub>\<rat>(x) \<bar>" 
proof(cases "{}\<le>\<^sup>\<real> x")
  case T:True
    hence "0 \<le> \<ss>2\<hh>\<^sub>\<rat>(x)" using Z X Rateq by mty auto
    hence "\<bar> \<ss>2\<hh>\<^sub>\<rat>(x) \<bar> =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<rat>(x) " "x = |. x .|" 
      using abs_of_nonneg[of "\<ss>2\<hh>\<^sub>\<rat>(x)"] absvalue_def_1[of x] T by mty auto
    thus "\<ss>2\<hh>\<^sub>\<rat>( |. x .| ) =\<^sub>\<H> \<bar> \<ss>2\<hh>\<^sub>\<rat>(x) \<bar>" by auto
  next
    case F:False
    hence " \<ss>2\<hh>\<^sub>\<rat>(x) <0" using Z X Ratless by mty auto
    hence "\<bar> \<ss>2\<hh>\<^sub>\<rat>(x) \<bar> =\<^sub>\<H>  (-\<^sub>\<H> \<ss>2\<hh>\<^sub>\<rat>(x)) " "(-\<^sub>\<S>\<^sup>\<real> x) = |. x .|" 
      using abs_of_neg[of "\<ss>2\<hh>\<^sub>\<rat>(x)"] absvalue_def_1[of x] F by mty auto
    thus "\<ss>2\<hh>\<^sub>\<rat>( |. x .| ) =\<^sub>\<H> \<bar> \<ss>2\<hh>\<^sub>\<rat>(x) \<bar>" using RatMinusM[of x] by mty auto
  qed
qed


theorem beIsoT_Rat: "beIsoT(h2sQ,s2hQ,Rat)"
  unfolding beIsoT_def 
proof(intro conjI)
  show "\<forall>\<^sub>Ly. \<ss>2\<hh>\<^sub>\<rat>(\<hh>2\<ss>\<^sub>\<rat>(y)) =\<^sub>\<H> y" using IMIQprop by auto
  show "\<forall>x:Rat. \<hh>2\<ss>\<^sub>\<rat>(\<ss>2\<hh>\<^sub>\<rat>(x)) = x" using MIMQprop by mty auto
  show "\<forall>\<^sub>Ly. \<hh>2\<ss>\<^sub>\<rat>(y) be Rat"  using h2sQprop by auto
qed

theorem beIsoS_RAT: 
  "beIsoS(h2sQ,s2hQ,RAT)"
  by(auto simp add: rat_0_def_3 all_set beIsoS_Type_Set(1)[OF _ beIsoT_Rat])

end


