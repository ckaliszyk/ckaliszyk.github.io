theory funct_2_lam
  imports beiso "../mml/binop_1"  "../mizar/mizar_fraenkel_2"
begin

(* Functions *)
definition s2hf2 :: "(Set \<Rightarrow> 'b) \<Rightarrow> ('a1 \<Rightarrow> Set) \<Rightarrow> ('a2 \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> ('a1 \<Rightarrow> 'a2 \<Rightarrow>'b)" where
  "s2hf2(s2hr,h2sd1,h2sd2,f) =\<^sub>\<H> (\<lambda>x y. (s2hr (f .\<lparr> (h2sd1(x)) , (h2sd2(y)) \<rparr> )))"

notation s2hf2 ("\<ss>2\<hh>\<^bsub>f2\<^esub>")
definition h2sf2 :: "(Set \<Rightarrow> 'a1) \<Rightarrow> (Set \<Rightarrow> 'a2) \<Rightarrow> ('b \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> Set \<Rightarrow> ('a1 \<Rightarrow> 'a2 \<Rightarrow>'b) \<Rightarrow> Set" where
  "h2sf2(s2hd1,s2hd2,h2sr,d1,d2,f) =\<^sub>\<S> 
   {[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))] 
        where x be Element-of d1, y be Element-of d2 : True}"
notation h2sf2 ("\<hh>2\<ss>\<^bsub>f2\<^esub>")

theorem ItoMf2prop:
  assumes "beIsoS(h2sd1,s2hd1,d1)" "beIsoS(h2sd2,s2hd2,d2)" "beIsoS(h2sr,s2hr,r)"
  shows "\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,f) is Function-of [:d1,d2:],r" 
proof-
  let ?H ="\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,f)"
  have [ty]:"d1 be set" "d2 be set" "r be set" "?H is set" using all_set by auto 
  have [ty]: "d1 is non empty" "d2 is non empty" using beIsoS_d assms by auto
  have [ty]:"?H is Relation_like"
  proof(standard,simp,standard,standard)
    fix x 
    assume "x in ?H"
     then obtain z1 z2 where [ty]:"z1 be Element-of d1" "z2 be Element-of d2" and
      A1: "x = [[z1,z2], h2sr(f(s2hd1(z1),s2hd2(z2)))]" "True"
      using h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] 
       Fraenkel_A2_ex[of "Element-of d1" "Element-of d2" 
       x "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]" "\<lambda> x y. True"] by mty auto
    then show "ex y, z be object st x = [y , z]" by auto
  qed mauto
  have [ty]:"?H is Function_like"
  proof(standard,simp,intro ballI impI)
    fix x y1 y2 
    assume A0:"[x,y1] in ?H \<and> [x,y2] in ?H"
    then obtain z1 z2 where [ty]:"z1 be Element-of d1" "z2 be Element-of d2" and
      A1: "[x,y1] = [[z1,z2], h2sr(f(s2hd1(z1),s2hd2(z2)))]" "True"
      using h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] 
       Fraenkel_A2_ex[of "Element-of d1" "Element-of d2" "[x,y1]" "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]" "\<lambda> x y. True"] by mty auto
    obtain t1 t2 where [ty]:"t1 be Element-of d1" "t2 be Element-of d2" and
      A2: "[x,y2] = [[t1,t2], h2sr(f(s2hd1(t1),s2hd2(t2)))]" "True"
      using h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] 
       Fraenkel_A2_ex[of "Element-of d1" "Element-of d2" "[x,y2]" "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]" "\<lambda> x y. True"] A0 by mty auto
    have A3: "x = [z1,z2]" "y1=h2sr(f(s2hd1(z1),s2hd2(z2)))" "x = [t1,t2]" "y2=h2sr(f(s2hd1(t1),s2hd2(t2)))" 
      using xtuple_0_th_1a A1 A2 by auto+
    hence "z1= t1" "z2=t2"  using xtuple_0_th_1a by auto
    then show "y1=y2" using A3 by simp
  qed mauto
  have D: "dom ?H = [:d1,d2:]"
  proof(rule xboole_0_def_10I,mauto)
    show "dom ?H c= [:d1,d2:]"
    proof(standard,auto)
      fix x assume "x in dom ?H"
      then obtain y where "y be object" and
        A1: " [x,y] in ?H" using xtuple_0_def_12 by auto 
      then obtain z1 z2 where [ty]:"z1 be Element-of d1" "z2 be Element-of d2" and
      A2: "[x,y] = [[z1,z2], h2sr(f(s2hd1(z1),s2hd2(z2)))]" "True"
      using h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] 
        Fraenkel_A2_ex[of "Element-of d1" "Element-of d2" "[x,y]" "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]" "\<lambda> x y. True"] by mty auto
      hence "z1 in d1" "z2 in d2" "x = [z1,z2]" 
        using Element(7) xtuple_0_th_1a by mty auto
      then show "x in [:d1,d2:]" using zfmisc_1_def_2 by auto
    qed
    show "[:d1,d2:] c= dom ?H"
    proof(standard,auto)
      fix x assume "x in [:d1,d2:]"
      then obtain z1 z2 where
        A3: "z1 in d1" "z2 in d2" "x=[z1,z2]" using zfmisc_1_def_2 by auto         
      hence X: "z1 be Element-of d1" "z2 be Element-of d2" 
           using Element(6) by auto
      have "[[z1,z2], h2sr(f(s2hd1(z1),s2hd2(z2)))] in ?H" using 
          Fraenkel_A2_in[of "Element-of d1" "Element-of d2" 
            z1 z2 _ "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]"]
        h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] X by mty auto
      then show "x in dom ?H" using A3 xtuple_0_def_12 by auto
    qed
  qed
  have [ty]: "rng ?H is set" using all_set by auto
  have "rng ?H c= r" 
   proof(standard,auto)
      fix y assume "y in rng ?H"
      then obtain x where "x be object" and
        A1: " [x,y] in ?H" using xtuple_0_def_13 by auto 
      then obtain z1 z2 where [ty]:"z1 be Element-of d1" "z2 be Element-of d2" and
      A2: "[x,y] = [[z1,z2], h2sr(f(s2hd1(z1),s2hd2(z2)))]" "True"
      using h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] 
        Fraenkel_A2_ex[of "Element-of d1" "Element-of d2" "[x,y]" 
        "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]" "\<lambda> x y. True"] by mty auto
      hence "y = h2sr(f(s2hd1(z1),s2hd2(z2)))" using Element(7) xtuple_0_th_1a by mty auto
       then show "y in r" using assms(3) beIsoS_def[of h2sr s2hr r] by auto
    qed
  then show "?H is Function-of [:d1,d2:],r"  using D funct_2_th_3[of r ?H] by mty auto
qed

theorem ItoMf2appl:
  assumes "beIsoS(h2sd1,s2hd1,d1)" "beIsoS(h2sd2,s2hd2,d2)" "beIsoS(h2sr,s2hr,r)"
  shows "\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,f) . \<lparr> (h2sd1(x)) , (h2sd2(y)) \<rparr>  
      = h2sr(f(x,y))"
proof-
  let ?H="\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,f)"
  have [ty]: "?H is Function-of [:d1,d2:],r" "d1 be set" "d2 be set" "r be set" 
      using ItoMf2prop[OF assms(1,2,3)] all_set beIsoS_d assms by auto
  have [ty]: "?H is Function" using relset_1_cl_1[of "[:d1,d2:]" r] by mty auto
  have "{}<>r" using beIsoS_d[OF assms(3)] xboole_0_cl_2  all_set by mty auto
  hence D: "dom ?H = [:d1,d2:]" using funct_2_def_1[of "[:d1,d2:]" r ?H] all_set 
    by mty auto
  have "h2sd1(x) in d1" "h2sd2(y) in d2" 
     using assms beIsoS_def[of h2sd1 s2hd1 d1] beIsoS_def[of h2sd2 s2hd2 d2] by auto
   hence "[h2sd1(x),h2sd2(y)] in dom ?H" using D zfmisc_1_def_2 by auto
  hence "[[h2sd1(x),h2sd2(y)], ?H. [h2sd1(x),h2sd2(y)]] in ?H" using D funct_1_def_2 by auto
  then obtain z1 z2 where [ty]:"z1 be Element-of d1" "z2 be Element-of d2" and
      A1: "[[h2sd1(x),h2sd2(y)], ?H. [h2sd1(x),h2sd2(y)]] = 
       [[z1,z2], h2sr(f(s2hd1(z1),s2hd2(z2)))]" "True"
  using h2sf2_def[of s2hd1 s2hd2 h2sr d1 d2 f] 
        Fraenkel_A2_ex[of "Element-of d1" "Element-of d2" 
        "[[h2sd1(x),h2sd2(y)], ?H. [h2sd1(x),h2sd2(y)]]" 
        "\<lambda> x y.[ [x,y], h2sr(f(s2hd1(x),s2hd2(y)))]" "\<lambda> x y. True"] by mty auto
  have A2: "[h2sd1(x),h2sd2(y)] = [z1,z2]" 
      "(?H. [h2sd1(x),h2sd2(y)]) = h2sr(f(s2hd1(z1),s2hd2(z2)))" 
    using xtuple_0_th_1a A1 by auto
  hence "h2sd1(x) = z1" "h2sd2(y) = z2" using xtuple_0_th_1a by auto
  hence "s2hd1(z1) =\<^sub>\<H> x" "s2hd2(z2) =\<^sub>\<H> y" 
    using assms(1,2) beIsoS_i[of h2sd1 s2hd1 d1 ] beIsoS_i[of h2sd2 s2hd2 d2 ] 
    by mty auto
  hence "?H. [h2sd1(x),h2sd2(y)]=h2sr(f(x,y))" using A2 by auto
  then show "?H. \<lparr> (h2sd1(x)) , (h2sd2(y)) \<rparr>  
      = h2sr(f(x,y))" using binop_0_def_1 by auto
qed

theorem MtoIf2appl:
  assumes "beIsoS(h2sd1,s2hd1,d1)" "beIsoS(h2sd2,s2hd2,d2)"
          "x1 be Element-of d1" "x2 be Element-of d2"
  shows "\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,f) (s2hd1(x1),s2hd2(x2)) =\<^sub>\<H> s2hr(f.\<lparr>x1,x2\<rparr>)"
proof-
  have "\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,f) (s2hd1(x1),s2hd2(x2)) 
     =\<^sub>\<H> s2hr (f . \<lparr>h2sd1(s2hd1(x1)),h2sd2(s2hd2(x2)) \<rparr>)" 
      using s2hf2_def[of s2hr h2sd1 h2sd2 f] by auto
 then show "\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,f) (s2hd1(x1),s2hd2(x2)) =\<^sub>\<H> s2hr(f.\<lparr>x1,x2\<rparr>)" 
      using beIsoS_e[OF assms(1,3)] beIsoS_e[OF assms(2,4)] by auto
qed


theorem MIM_fun2_prop:
  assumes "beIsoS(h2sd1,s2hd1,d1)" "beIsoS(h2sd2,s2hd2,d2)" 
          "beIsoS(h2sr,s2hr,r)" and
          [ty]: "f be Function-of [:d1,d2:],r"
  shows "\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,f)) = f"
proof(rule funct_2_def_7I,simp add:all_set,simp add:all_set)
  have [ty]:"d1 be non empty\<bar>set" "d2 be non empty\<bar>set" 
       "r be non empty\<bar>set" 
    using all_set beIsoS_d assms by auto
  let ?M="\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,f)" let ?I="\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,?M)"
  show [ty]: "?I is Function-of [:d1,d2:], r" "f is Function-of [:d1,d2:], r" 
    using assms ItoMf2prop[of h2sd1 s2hd1 d1 h2sd2 s2hd2 d2 h2sr] by auto
  have [ty]: "?I is Function" "f be Function" using relset_1_cl_1[of "[:d1,d2:]" r] by mty auto

  show "for a be Element-of [:d1,d2:] holds ?I . a = f . a"
  proof
    fix a assume [ty]: "a be Element-of [:d1,d2:]"     
    hence T[ty]: "f . a be Element-of r" 
      using funct_2_def_5[of "[:d1,d2:]" r f a] by mty auto
    have "a in [:d1,d2:]" using Element(7) by mty auto
    then obtain z1 z2 where
       Z: "z1 in d1" "z2 in d2" "a=[z1,z2]" using zfmisc_1_def_2 by auto
    have [ty]: "z1 be Element-of d1" "z2 be Element-of d2" 
      using Element(6) Z by auto
    have AA: "h2sd1(s2hd1(z1)) = z1" "h2sd2(s2hd2(z2)) = z2" using beIsoS_e[OF assms(1)]  
      beIsoS_e[OF assms(2)] by auto
    have "?I . a = ?I. \<lparr> z1, z2 \<rparr>" using Z binop_0_def_1[ of ?I z1 z2 ] by mty auto 
    hence A2:"?I . a = h2sr(?M(s2hd1(z1), s2hd2(z2)))" 
      using ItoMf2appl[OF assms(1,2,3), of ?M "s2hd1(z1)" "s2hd2(z2)" ] AA by auto
    have A3:"?M(s2hd1(z1), s2hd2(z2)) =\<^sub>\<H> s2hr(f. \<lparr>z1,z2\<rparr>)" 
      using MtoIf2appl[OF assms(1,2),of z1 z2  ] by auto
    have "f. a = f. \<lparr>z1,z2\<rparr>" using binop_0_def_1[of f z1 z2] Z by mty auto
    hence "f. \<lparr>z1,z2\<rparr> is Element-of r" using T by mty auto
    hence "h2sr(s2hr(f. \<lparr>z1,z2\<rparr>)) = f. \<lparr>z1,z2\<rparr>"
       using beIsoS_e[OF assms(3), of "f. \<lparr>z1,z2\<rparr>"] by auto
    then show "?I . a = f . a" using A2 A3 binop_0_def_1[of f z1 z2] Z  by auto
  qed mauto
qed

theorem IMI_fun2_prop:
  assumes "beIsoS(h2sd1,s2hd1,d1)" "beIsoS(h2sd2,s2hd2,d2)" "beIsoS(h2sr,s2hr,r)"
  shows "\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,f)) =\<^sub>\<H> f"
proof(standard,standard)
  fix x y
  let ?I="\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2,f)"
  let ?M="\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2,?I)"
  have "h2sd1(x) in d1" "h2sd2(y) in d2" using  beIsoS_def[of h2sd1 s2hd1 d1] 
     beIsoS_def[of h2sd2 s2hd2 d2] assms(1,2) by auto
  hence [ty]: "h2sd1(x) is Element-of d1"  "h2sd2(y) is Element-of d2" using Element(6) all_set by auto
  have A1: "?I. \<lparr>h2sd1(x),h2sd2(y) \<rparr> = h2sr(f(x,y))" using ItoMf2appl[OF assms(1,2,3)] by auto
  have "s2hd1(h2sd1(x)) =\<^sub>\<H> x"  "s2hd2(h2sd2(y)) =\<^sub>\<H> y" using beIsoS_i[OF assms(1)] beIsoS_i[OF assms(2)]  by auto
  hence "?M(x,y) =\<^sub>\<H> s2hr(h2sr(f(x,y)))" using A1 MtoIf2appl[OF assms(1,2), of "h2sd1(x)" "h2sd2(y)" s2hr _] by auto
  then show "?M(x,y) =\<^sub>\<H> f(x,y)" using beIsoS_i[OF assms(3)] by auto
qed



theorem beIsoSf2:
  assumes "beIsoS(h2sd1,s2hd1,d1)" "beIsoS(h2sd2,s2hd2,d2)"  "beIsoS(h2sr,s2hr,r)" 
  shows "beIsoS(\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1,s2hd2,h2sr,d1,d2),\<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr,h2sd1,h2sd2),Funcs([:d1,d2:],r))"
   unfolding beIsoS_def 
 proof(intro conjI)
    have [ty]: "d1 be set" "d2 be set" "r be set" "[:d1,d2:] be set" using all_set by auto 
    show "\<forall>\<^sub>Ly. \<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr, h2sd1, h2sd2, \<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1, s2hd2, h2sr, d1, d2, y)) =\<^sub>\<H> y"  using IMI_fun2_prop[OF assms(1,2,3)] by auto
    show "for x be Element-of Funcs( [:d1,d2:] , r ) holds  \<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1, s2hd2, h2sr, d1, d2, \<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr, h2sd1, h2sd2, x)) = x"
    proof(auto)
      have [ty]: "r be non empty" using beIsoS_d[OF assms(3)] by auto
      fix  x assume A1: "x be Element-of Funcs( [:d1,d2:] , r )"
      have "Funcs( [:d1,d2:] , r ) is non empty" by mty auto
      hence "x in Funcs( [:d1,d2:] , r )" using Element(7)[OF _ A1] by auto
      then obtain f where [ty]:"f be Function" and
         A2: "x=f" "dom f=[:d1,d2:]" "rng f c= r" using funct_2_def_2[of "[:d1,d2:]" r x] by mty auto
      hence "f be Function-of [:d1,d2:],r" using funct_2_th_3[of r f] by mty auto
      then show " \<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1, s2hd2, h2sr, d1, d2, \<ss>2\<hh>\<^bsub>f2\<^esub>(s2hr, h2sd1, h2sd2, x))= x" using MIM_fun2_prop[OF assms, of f] A2 by auto
    qed
    show "\<forall>\<^sub>Ly. \<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1, s2hd2, h2sr, d1, d2, y) in Funcs( [:d1,d2:] , r )"
    proof
      fix y let ?F =  "\<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd1, s2hd2, h2sr, d1, d2, y)"
      have [ty]: "?F is Function-of [:d1,d2:],r" using ItoMf2prop[OF assms] by auto
      have [ty]: "?F is Function" using relset_1_cl_1[of "[:d1,d2:]" r ?F] by mty auto
      have  "{}<>r" using beIsoS_d[OF assms(3)] xboole_0_cl_2  all_set by mty auto
      hence "dom ?F = [:d1,d2:]" "rng ?F c= r"
         using funct_2_def_1[of "[:d1,d2:]" r ?F] all_set relat_1_def_19E[of r ?F,simplified] by mty auto
      then show "?F in Funcs([:d1,d2:],r)" using funct_2_def_2 by mty auto
    qed
  qed


definition s2hBinOp :: "(Set \<Rightarrow> 'a) \<Rightarrow> ('a \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> ('a \<Rightarrow> 'a \<Rightarrow>'a)" where
  "s2hBinOp(s2hd,h2sd,f) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>f2\<^esub>(s2hd,h2sd,h2sd,f)"


definition h2sBinOp :: "(Set \<Rightarrow> 'a) \<Rightarrow> ('a \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> ('a \<Rightarrow> 'a \<Rightarrow>'a) \<Rightarrow> Set" where
  "h2sBinOp(s2hd,h2sd,d,f) = \<hh>2\<ss>\<^bsub>f2\<^esub>(s2hd,s2hd,h2sd,d,d,f)"(* Set.member(s2hd(x), UNIV::'a Set.set)}"*)

notation
  s2hBinOp ("\<ss>2\<hh>\<^bsub>BinOp\<^esub>") and
  h2sBinOp ("\<hh>2\<ss>\<^bsub>BinOp\<^esub>")


theorem MIMBinOp:
 assumes "beIsoS(h2sd,s2hd,d)" "f be BinOp-of d"
 shows "\<hh>2\<ss>\<^bsub>BinOp\<^esub>(s2hd,h2sd,d,\<ss>2\<hh>\<^bsub>BinOp\<^esub>(s2hd,h2sd,f)) = f"
  unfolding h2sBinOp_def s2hBinOp_def using MIM_fun2_prop[OF assms(1,1,1,2)] by simp


theorem IMIBinOpS:
 assumes "beIsoS(h2sd,s2hd,d)" 
 shows "\<ss>2\<hh>\<^bsub>BinOp\<^esub>(s2hd,h2sd,\<hh>2\<ss>\<^bsub>BinOp\<^esub>(s2hd,h2sd,d,f)) =\<^sub>\<H> f"
  unfolding h2sBinOp_def s2hBinOp_def using IMI_fun2_prop[OF assms(1,1,1)] by simp


theorem MtoIBinOpS:
  assumes "beIsoS(h2sd,s2hd,d)" 
          "x1 be Element-of d" "x2 be Element-of d"
 shows "\<ss>2\<hh>\<^bsub>BinOp\<^esub>(s2hd,h2sd,f) (s2hd(x1),s2hd(x2)) =\<^sub>\<H> s2hd(f.\<lparr>x1,x2\<rparr>)"
  using MtoIf2appl[OF assms(1,1,2,3)] s2hBinOp_def[of s2hd h2sd f] by auto


theorem ItoMBinOpS:
  assumes "beIsoS(h2sd,s2hd,d)" 
  shows "\<hh>2\<ss>\<^bsub>BinOp\<^esub>(s2hd,h2sd,d,f) . \<lparr> (h2sd(x)) , (h2sd(y)) \<rparr>  = h2sd(f(x,y))"
  using ItoMf2appl[OF assms assms assms] h2sBinOp_def[of s2hd h2sd d f] by auto
end
