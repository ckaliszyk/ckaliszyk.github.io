theory pre_merge_cauchy
  imports pre_merge_rat2 "../mml/absvalue"
    
begin

mtheorem
  mlet "x be Rat"
  " cluster |. x .| \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof(standard, cases "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
  case [ty]:True
    hence "{} \<le>\<^sup>\<real> x" using rat_0_Q by mty auto
    thus "|. x .| is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using absvalue_def_1[of x] by mty auto
next
  case [ty]:False
  hence "x <\<^sup>\<real> {}" using rat_0_Q by mty auto
  thus "|. x .| is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using absvalue_def_1[of x] by mty auto  
qed  


mdef CauchyQ ("Cauchy\<^sub>\<S>") where
 "attr Cauchy\<^sub>\<S> for Function-of NAT,RAT means
     (\<lambda>IT. for \<epsilon> be Rat st 0\<^sub>\<S> <\<^sup>\<real> \<epsilon> holds
              (ex N be Nat st 
                (for n,m be Nat st N \<subseteq> n & N \<subseteq> m holds
                    |. IT . m -\<^sub>\<S>\<^sup>\<real> IT . n .| <\<^sup>\<real> \<epsilon>)))"..
reserve s1,s2,seq for "Function-of NAT,RAT"

theorem seq_1:
  "f is Function-of NAT,RAT iff f is Function & dom f = NAT & rng f \<subseteq> RAT"
proof
  have "{} in RAT" using rat_0_def_3[of "{}"] by mty auto
  hence R: "RAT<>{}" using xb by mty auto
  assume A[ty]:"f be Function-of omega, RAT"
  hence f1:"f is Function" by mty auto
  have f2: "dom f=NAT" using funct_2_def_1[of NAT RAT f] R by mty auto
  have "rng f \<subseteq>RAT" using relat_1_def_19[of RAT f,simplified] all_set by mty auto
  thus "f is Function & dom f = NAT & rng f \<subseteq> RAT" using f1 f2 by simp
next
  show " f be Function \<and> proj1 f =\<^sub>\<S> omega \<and> proj2 f \<subseteq> RAT \<Longrightarrow> f be Function-of omega, RAT"
    using funct_2_th_3[of RAT f] by mty auto
qed

mtheorem
  mlet "f be Function-of NAT,RAT", "n be Nat"
  "cluster f. n \<rightarrow> Rat"
proof
  have "{} in RAT" using rat_0_def_3[of "{}"] by mty auto
  hence R: "RAT<>{}" "n in NAT" using xb ordinal1_def_12[of n] by mty auto
  hence "f. n in RAT" using funct_2_th_5[of n RAT omega] by mty auto
  thus "f. n is Rat" using rat_0_def_3 by mty auto
qed

mtheorem CauchyI: 
 "seq is CauchyQ iff
     (for \<epsilon> be Element-of RAT\<^bsup>\<ge>0\<^bsub> st 0\<^sub>\<S> <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> \<epsilon> holds
              (ex N be Nat st 
                (for n,m be Nat st N \<subseteq> n & N \<subseteq> m & n in m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> \<epsilon>)))"
proof
  assume AS: "seq is CauchyQ"
  show "for \<epsilon> be Element-of RAT\<^bsup>\<ge>0\<^bsub> st 0\<^sub>\<S> <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> \<epsilon> holds
              (ex N be Nat st 
                (for n,m be Nat st N \<subseteq> n & N \<subseteq> m & n in m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> \<epsilon>))"
  proof(intro ballI impI)
    fix  e assume [ty]:"e be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     e:    "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
    hence "{} <\<^sup>\<real> e" using rat_0_th_29 by mty auto
    then obtain N where [ty]:"N be Nat" and
       N: "for n,m be Nat st N \<subseteq> n & N \<subseteq> m & n in m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e" using AS 
      CauchyQE[of seq,THEN bspec, of e] by mty auto
    show "ex N be Nat st 
                (for n,m be Nat st N \<subseteq> n & N \<subseteq> m & n in m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e)"
    proof(rule bexI[of _ N],intro ballI impI)
      fix n m assume [ty]:"n be Nat" "m be Nat" and
          "N \<subseteq> n \<and> N \<subseteq> m & n in m"
      hence H: "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e" using N by mty auto
      thus "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using
          rat_0_th_29[of "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .|" e,simplified] 
        by mty auto
    qed mauto
  qed mauto
next 
  assume AS: "for \<epsilon> be Element-of RAT\<^bsup>\<ge>0\<^bsub> st 0\<^sub>\<S> <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> \<epsilon> holds
              (ex N be Nat st 
                (for n,m be Nat st N \<subseteq> n & N \<subseteq> m & n in m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> \<epsilon>))"  
  show "seq is CauchyQ"
  proof(standard, simp,intro ballI impI)
    fix  e assume [ty]:"e be Rat" and
     e:    "{} <\<^sup>\<real> e"
    hence "{}\<le>\<^sup>\<real> e" using real_0_th_33 by mty auto
    hence [ty]:"e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_Q by mty auto
    have e1: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using rat_0_th_29 e by mty auto
    then obtain N where [ty]:"N be Nat" and
       N: "for n,m be Nat st N \<subseteq> n & N \<subseteq> m & n in m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using AS[THEN bspec, of e] 
      by mty auto
   
 show "ex N be Nat st 
                (for n,m be Nat st N \<subseteq> n & N \<subseteq> m holds
                    |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e)"
 proof(rule bexI[of _ N],intro ballI impI)
      fix n m assume [ty]:"n be Nat" "m be Nat" and
          NN: "N \<subseteq> n \<and> N \<subseteq> m"
      show "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e"
      proof(cases "n in m")
        case True
         hence "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using N NN by mty auto
         thus "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e" using rat_0_th_29[of "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .|" e] 
           by mty auto
       next
         case F: False
            show "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e"
            proof(cases "n = m")
              case True
              hence "seq . m -\<^sub>\<S>\<^sup>\<real> seq . n = {}" using rat_1_th_18 by mty auto
              thus "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e" using e absvalue_th_2[of "{}"] by mty auto
            next 
              case False
              hence "m in n" using F ordinal1_th_10 by mty auto
              hence H:"|. seq . n -\<^sub>\<S>\<^sup>\<real> seq . m .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using N NN by mty auto
              have "seq . m -\<^sub>\<S>\<^sup>\<real> seq . n is Rat" by mty auto
              have "seq . n -\<^sub>\<S>\<^sup>\<real> seq . m =( -\<^sub>\<S>\<^sup>\<real> (seq . m -\<^sub>\<S>\<^sup>\<real> seq . n))"
                using rat_1_th_22 by mty auto
              hence "|. seq . n -\<^sub>\<S>\<^sup>\<real> seq . m .| = |. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .|" 
                using absvalue_th_7 by mty auto
              thus "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .| <\<^sup>\<real> e"
                using H rat_0_th_29[of "|. seq . m -\<^sub>\<S>\<^sup>\<real> seq . n .|" e] 
                by mty auto
              qed  
    qed mauto
  qed mauto
qed mauto
qed


reserve n,m for Nat

mdef seq_A(infix "'(+')" 110) where
  mlet "f be Function-of NAT,RAT", "g be Function-of NAT,RAT"
  "func f (+) g \<rightarrow> Function-of NAT,RAT means
     \<lambda>it. for n holds it. n = (f. n) +\<^sub>\<S>\<^sup>\<real> (g. n)"
proof-
  let ?FG ="\<lambda>n. f. n +\<^sub>\<S>\<^sup>\<real> g. n"
  have A: "\<forall>x:Element-of NAT. ?FG(x) be Element-of RAT"
  proof
    fix x assume [ty]:"x be Element-of NAT"
    have "(f. x +\<^sub>\<S>\<^sup>\<real> g. x) is Rat" by mty auto
    thus "?FG(x) be Element-of RAT" using rat_0_def_3 Element(6) by mty auto
  qed mauto
  obtain fg where [ty]: "fg be Function-of NAT,RAT" and
     A2: "\<forall>x:Element-of NAT. (fg . x) = ?FG(x)"
    using funct_2_sch_4[OF _ _ A ] by mty auto
  show " \<exists>x : Function-of omega, RAT. \<forall>n : Nat. x . n =\<^sub>\<S> (f . n +\<^sub>\<S>\<^sup>\<real> g . n)"
  proof(rule bexI[of _ fg],auto)
    fix x assume [ty]: "x be natural"
    thus  "fg . x =\<^sub>\<S> f . x +\<^sub>\<S>\<^sup>\<real> g . x" using A2 by mty auto
  qed
  fix fg1 fg2 assume [ty]:"fg1 be Function-of omega, RAT"
           "fg2 be Function-of omega, RAT" and
           FG: "\<forall>n : Nat. fg1 . n =\<^sub>\<S> f . n +\<^sub>\<S>\<^sup>\<real> g . n"
               " \<forall>n : Nat. fg2 . n =\<^sub>\<S> f . n +\<^sub>\<S>\<^sup>\<real> g . n"
  have "for a be Element-of NAT holds fg1 . a = fg2 . a" 
  proof
    fix n assume [ty]:"n is Element-of NAT"
    have  "fg1 . n =\<^sub>\<S> f . n +\<^sub>\<S>\<^sup>\<real> g . n" using FG(1) by mty auto
    thus "fg1. n = fg2. n" using FG(2) by mty auto
  qed mauto
  thus  "fg1 =\<^sub>\<S> fg2" using funct_2_def_7I[of NAT RAT] by mty auto
qed mauto

mdef seq_m(infix "'(-')" 110) where
  mlet "f be Function-of NAT,RAT", "g be Function-of NAT,RAT"
  "func f (-) g \<rightarrow> Function-of NAT,RAT means
     \<lambda>it. for n holds it. n = (f. n) -\<^sub>\<S>\<^sup>\<real> (g. n)"
proof-
  let ?FG ="\<lambda>n. (f. n) -\<^sub>\<S>\<^sup>\<real> (g. n)"
  have A: "\<forall>x:Element-of NAT. ?FG(x) be Element-of RAT"
  proof
    fix x assume [ty]:"x be Element-of NAT"
    have "((f. x) -\<^sub>\<S>\<^sup>\<real> (g. x)) is Rat" by mty auto
    thus "?FG(x) be Element-of RAT" using rat_0_def_3 Element(6) by mty auto
  qed mauto
  obtain fg where [ty]: "fg be Function-of NAT,RAT" and
     A2: "\<forall>x:Element-of NAT. (fg . x) = ?FG(x)"
    using funct_2_sch_4[OF _ _ A ] by mty auto
  show " \<exists>x : Function-of omega, RAT. \<forall>n : Nat. x . n =\<^sub>\<S> (f . n) -\<^sub>\<S>\<^sup>\<real> (g . n)"
  proof(rule bexI[of _ fg],auto)
    fix x assume [ty]: "x be natural"
    thus  "fg . x =\<^sub>\<S> (f . x) -\<^sub>\<S>\<^sup>\<real> (g . x)" using A2 by mty auto
  qed
  fix fg1 fg2 assume [ty]:"fg1 be Function-of omega, RAT"
           "fg2 be Function-of omega, RAT" and
           FG: "\<forall>n : Nat. fg1 . n =\<^sub>\<S> f . n -\<^sub>\<S>\<^sup>\<real> (g . n)"
               " \<forall>n : Nat. fg2 . n =\<^sub>\<S> f . n -\<^sub>\<S>\<^sup>\<real> (g . n)"
  have "for a be Element-of NAT holds fg1 . a = fg2 . a" 
  proof
    fix n assume [ty]:"n is Element-of NAT"
    have  "fg1 . n =\<^sub>\<S> f . n -\<^sub>\<S>\<^sup>\<real> (g . n)" using FG(1) by mty auto
    thus "fg1. n = fg2. n" using FG(2) by mty auto
  qed mauto
  thus  "fg1 =\<^sub>\<S> fg2" using funct_2_def_7I[of NAT RAT] by mty auto
qed mauto

mdef seq_M(infix "'(*')" 110) where
  mlet "f be Function-of NAT,RAT", "g be Function-of NAT,RAT"
  "func f (*) g \<rightarrow> Function-of NAT,RAT means
     \<lambda>it. for n holds it. n = f. n *\<^sub>\<S>\<^sup>\<real> g. n"
proof-
  let ?FG ="\<lambda>n. f. n *\<^sub>\<S>\<^sup>\<real> g. n"
  have A: "\<forall>x:Element-of NAT. ?FG(x) be Element-of RAT"
  proof
    fix x assume [ty]:"x be Element-of NAT"
    have "(f. x *\<^sub>\<S>\<^sup>\<real> g. x) is Rat" by mty auto
    thus "?FG(x) be Element-of RAT" using rat_0_def_3 Element(6) by mty auto
  qed mauto
  obtain fg where [ty]: "fg be Function-of NAT,RAT" and
     A2: "\<forall>x:Element-of NAT. (fg . x) = ?FG(x)"
    using funct_2_sch_4[OF _ _ A ] by mty auto
  show " \<exists>x : Function-of omega, RAT. \<forall>n : Nat. x . n =\<^sub>\<S> (f . n *\<^sub>\<S>\<^sup>\<real> g . n)"
  proof(rule bexI[of _ fg],auto)
    fix x assume [ty]: "x be natural"
    thus  "fg . x =\<^sub>\<S> f . x *\<^sub>\<S>\<^sup>\<real> g . x" using A2 by mty auto
  qed
  fix fg1 fg2 assume [ty]:"fg1 be Function-of omega, RAT"
           "fg2 be Function-of omega, RAT" and
           FG: "\<forall>n : Nat. fg1 . n =\<^sub>\<S> f . n *\<^sub>\<S>\<^sup>\<real> g . n"
               " \<forall>n : Nat. fg2 . n =\<^sub>\<S> f . n *\<^sub>\<S>\<^sup>\<real> g . n"
  have "for a be Element-of NAT holds fg1 . a = fg2 . a" 
  proof
    fix n assume [ty]:"n is Element-of NAT"
    have  "fg1 . n =\<^sub>\<S> f . n *\<^sub>\<S>\<^sup>\<real> g . n" using FG(1) by mty auto
    thus "fg1. n = fg2. n" using FG(2) by mty auto
  qed mauto
  thus  "fg1 =\<^sub>\<S> fg2" using funct_2_def_7I[of NAT RAT] by mty auto
qed mauto

mdef seq_ABS("| _ |" 110) where
  mlet "f be Function-of NAT,RAT"
  "func | f | \<rightarrow> Function-of NAT,RAT means
     \<lambda>it. for n holds it. n = |. f. n .|"
proof-
  let ?F ="\<lambda>n. |. f. n .|"
  have A: "\<forall>x:Element-of NAT. ?F(x) be Element-of RAT"
  proof
    fix x assume [ty]:"x be Element-of NAT"
    have "|. f. x .| is Rat" by mty auto
    thus "?F(x) be Element-of RAT" using rat_0_def_3 Element(6) by mty auto
  qed mauto
  obtain F where [ty]: "F be Function-of NAT,RAT" and
     A2: "\<forall>x:Element-of NAT. (F . x) = ?F(x)"
    using funct_2_sch_4[OF _ _ A ] by mty auto
  show " \<exists>x : Function-of omega, RAT. \<forall>n : Nat. x . n =\<^sub>\<S> |. f . n .|"
  proof(rule bexI[of _ F],auto)
    fix x assume [ty]: "x be natural"
    thus  "F . x =\<^sub>\<S> |. f . x .|" using A2 by mty auto
  qed
  fix fg1 fg2 assume [ty]:"fg1 be Function-of omega, RAT"
           "fg2 be Function-of omega, RAT" and
           FG: "\<forall>n : Nat. fg1 . n =\<^sub>\<S> |. f . n .|"
               " \<forall>n : Nat. fg2 . n =\<^sub>\<S> |. f . n .|"
  have "for a be Element-of NAT holds fg1 . a = fg2 . a" 
  proof
    fix n assume [ty]:"n is Element-of NAT"
    have  "fg1 . n =\<^sub>\<S> |. f . n .|" using FG(1) by mty auto
    thus "fg1. n = fg2. n" using FG(2) by mty auto
  qed mauto
  thus  "fg1 =\<^sub>\<S> fg2" using funct_2_def_7I[of NAT RAT] by mty auto
qed mauto



mtheorem
  mlet 
  "s1 be CauchyQ\<bar>Function-of NAT,RAT",
  "s2 be CauchyQ\<bar>Function-of NAT,RAT" 
  "cluster s1 (+) s2 \<rightarrow> CauchyQ"
proof(standard,rule CauchyI[THEN iffD2],simp,intro ballI impI)
  fix e assume [ty]:"e be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         e: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  have "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>" using arytm_3_TH4 by mty auto
  hence H:"{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using e arytm_3_TH5 by mty auto
  then obtain N1 where [ty]:"N1 is Nat" and
    n1: "\<forall>n : Nat. \<forall>m : Nat. N1 \<subseteq> n \<and> N1 \<subseteq> m \<and> n in m \<longrightarrow> 
      |. s1 . m -\<^sub>\<S>\<^sup>\<real> s1 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" 
      using CauchyI[THEN iffD1, THEN bspec, of s1 "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)"] by mty auto
  obtain N2 where [ty]:"N2 is Nat" and
    n2: "\<forall>n : Nat. \<forall>m : Nat. N2 \<subseteq> n \<and> N2 \<subseteq> m \<and> n in m \<longrightarrow> 
      |. s2 . m -\<^sub>\<S>\<^sup>\<real> s2 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" 
    using CauchyI[THEN iffD1, THEN bspec, of s2 "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)"] H by mty auto
  let ?N="N1 +\<^sub>\<S>\<^sup>\<nat> N2"
  show " \<exists>N :
          Nat. \<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<and> n in m \<longrightarrow> 
      |. (s1 (+) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (+) s2) . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  proof(rule bexI[of _ ?N],intro ballI impI)
    fix n m assume [ty]: "n be Nat" "m be Nat" and
        AS:   "?N \<subseteq> n \<and> ?N \<subseteq> m & n in m "
    have "N1 \<subseteq> ?N" using Add_10 by mty auto
    hence "N1 \<subseteq> m" "N1 \<subseteq> n" 
      using AS xboole_1_th_1 [of _ ?N N1] by mty auto
    hence "|. s1 . m -\<^sub>\<S>\<^sup>\<real> s1 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using n1 AS by mty auto
  hence S1: "|. s1 . m -\<^sub>\<S>\<^sup>\<real> s1 . n .| <\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using rat_0_th_29 by mty auto

    have "N2 \<subseteq> ?N" using Add_10 Add_6 by mty auto
    hence "N2 \<subseteq> m" "N2 \<subseteq> n" 
      using AS xboole_1_th_1 [of _ ?N N2] by mty auto
    hence "|. s2 . m -\<^sub>\<S>\<^sup>\<real> s2 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using n2 AS by mty auto
    hence S2: "|. s2 . m -\<^sub>\<S>\<^sup>\<real> s2 . n .| <\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using rat_0_th_29 by mty auto
    
    have "(s1 (+) s2) . m = (s1. m)  +\<^sub>\<S>\<^sup>\<real> (s2 . m)" 
         "(s1 (+) s2) . n = (s1. n)  +\<^sub>\<S>\<^sup>\<real> (s2 . n)" using seq_A by mty auto 
    hence " ((s1 (+) s2) . m) -\<^sub>\<S>\<^sup>\<real> ((s1 (+) s2) . n) =
              ((s1. m)  +\<^sub>\<S>\<^sup>\<real> (s2 . m)) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  +\<^sub>\<S>\<^sup>\<real> (s2 . n)))" 
      using real_0_def_6[of "(s1. m)  +\<^sub>\<S>\<^sup>\<real> (s2 . m)" "(s1. n)  +\<^sub>\<S>\<^sup>\<real> (s2 . n)",simplified] 
      by mty auto
    also have "... = ((s1. m)  +\<^sub>\<S>\<^sup>\<real> (s2 . m)) +\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> (s1. n))  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n)))"
      using real_0_th_20 by mty auto
    also have "... = (((s1. m)  +\<^sub>\<S>\<^sup>\<real> (s2 . m)) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (s1. n)))  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n))"
      using real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real>(s2 . n)" "-\<^sub>\<S>\<^sup>\<real> (s1. n)"]  by mty auto
   also have "... = ((s1. m)  +\<^sub>\<S>\<^sup>\<real> ( (s2 . m) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (s1. n))) )  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n))"
      using real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real>(s1 . n)" " (s2. m)"]  by mty auto
   also have "... = ((s1. m)  +\<^sub>\<S>\<^sup>\<real> ( (-\<^sub>\<S>\<^sup>\<real> (s1. n)) +\<^sub>\<S>\<^sup>\<real> (s2 . m) ) )  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n))"
      using real_0_th_11[of "(s2. m)" "-\<^sub>\<S>\<^sup>\<real>(s1. n)"]  by mty auto
   also have "... = ((( (s1. m)  +\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real> (s1. n))) +\<^sub>\<S>\<^sup>\<real> (s2 . m) ) )  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n))"
      using real_0_th_15[of "s2. m" "-\<^sub>\<S>\<^sup>\<real> (s1. n)" ]  by mty auto
   also have "... = ((( (s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) +\<^sub>\<S>\<^sup>\<real> (s2 . m) ) )  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n))"
      using real_0_def_6[of "s1. m" "s1. n",simplified]  by mty auto
   also have "... = ( (s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) +\<^sub>\<S>\<^sup>\<real> ((s2 . m) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n)))"
     using real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real>(s2 . n)" "s2 . m"] by mty auto
   finally have " (s1 (+) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (+) s2) . n = 
     ( (s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) +\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))"
     using real_0_def_6[of "s2. m" "s2. n",simplified] by mty auto   
   hence H1: "|. (s1 (+) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (+) s2) . n.| \<le>\<^sup>\<real>
           |. (s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n).| +\<^sub>\<S>\<^sup>\<real> |.(s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n).|"
     using absvalue_th_6[of _ "(s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)"] by mty auto
   have H2: "|. (s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n).| +\<^sub>\<S>\<^sup>\<real> |.(s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n).| 
        <\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) " 
     using rat_1_th_16l[OF _ _ _ _ S1 S2] by mty auto
   
   have "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) =
         (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using real_0_def_4 Prat_Preal_add by mty auto
   also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using arytm_3_th_57 by mty auto
   also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (2\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using arytm_3_th_47 Add_5 by mty auto
  also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using arytm_3_th_41 by mty auto
  finally have "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) = e" using arytm_3_th_53 by mty auto
  hence "|. (s1 (+) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (+) s2) . n.| <\<^sup>\<real> e " 
    using   rat_0_def_8t1[OF _ _ _ H1 H2] by mty auto
  thus "|. (s1 (+) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (+) s2) . n.| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using rat_0_th_29 by mty auto
  qed mauto
qed mauto

mtheorem
  mlet 
  "s be CauchyQ\<bar>Function-of NAT,RAT"
  "cluster  | s |  \<rightarrow> CauchyQ"
proof(standard,rule CauchyI[THEN iffD2],simp,intro ballI impI)
  fix e assume [ty]:"e be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         e: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  then obtain N where [ty]:"N is Nat" and
N:   " \<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<and> n in m \<longrightarrow> 
      |. ( s ) . m -\<^sub>\<S>\<^sup>\<real> ( s ) . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using CauchyI[THEN iffD1,THEN bspec, of s e] by mty auto
  let ?s="|s|"
  show " \<exists>N :
          Nat. \<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<and> n in m \<longrightarrow> 
      |. (?s ) . m -\<^sub>\<S>\<^sup>\<real> ( ?s ) . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
 proof(rule bexI[of _ N],intro ballI impI)
   fix n m assume [ty]: "n be Nat" "m be Nat" and
        AS:   "N \<subseteq> n \<and> N \<subseteq> m \<and> n in m "
   hence "|. ( s ) . m -\<^sub>\<S>\<^sup>\<real> ( s ) . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using N by mty auto
   hence H2: "|. ( s ) . m -\<^sub>\<S>\<^sup>\<real> ( s ) . n .| <\<^sup>\<real> e" using rat_0_th_29 by mty auto

   have "((?s) . m) -\<^sub>\<S>\<^sup>\<real> ((?s) . n) = ( |. s . m .|) -\<^sub>\<S>\<^sup>\<real> ( |. s . n .| )" 
     using seq_ABS[of s] by mty auto
   hence "|. ((?s) . m) -\<^sub>\<S>\<^sup>\<real> ((?s) . n) .| \<le>\<^sup>\<real> |. ( s . m ) -\<^sub>\<S>\<^sup>\<real> ( s . n ).|" using 
    absvalue_th_8 by mty auto
   hence "|. ((?s) . m) -\<^sub>\<S>\<^sup>\<real> ((?s) . n) .| <\<^sup>\<real> e" using rat_0_def_8t2[OF _ _ _ H2] by mty auto
   thus "|. ((?s) . m) -\<^sub>\<S>\<^sup>\<real> ((?s) . n) .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using rat_0_th_29 by mty auto
 qed mauto
qed mauto

mtheorem Cauchy_min:
  "seq be CauchyQ \<longrightarrow> (ex r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r <>{} & (for n holds |. seq . n .| \<le>\<^sup>\<real> r))" 
proof
  let ?s="|seq|"
  assume [ty]: "seq be CauchyQ"
  obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    r: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_94[of "{}"] by mty auto
  have "?s is CauchyQ" by mty auto
  obtain N where [ty]:"N is Nat" and
    n: "\<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<and> n in m \<longrightarrow> 
      |. ?s . m -\<^sub>\<S>\<^sup>\<real> ?s . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" 
      using CauchyI[THEN iffD1, THEN bspec, of ?s "r"] r by mty auto
  let ?P="\<lambda>n. ex x be Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
                 for m st m in n holds |. seq . m .| \<le>\<^sup>\<real> x"
  have P0:"?P({})" using xb bexI[of _ "{}" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
  have Pn:"\<forall>n : Nat. ?P(n) \<longrightarrow> ?P(succ n)"
  proof(intro ballI impI)
    fix n assume [ty]:"n is Nat" and "?P(n)"
    then obtain x where [ty]:"x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
               x:  " for m st m in n holds |. seq . m .| \<le>\<^sup>\<real> x" by auto
    show "?P(succ n)"
    proof(cases "|. seq . n .| \<le>\<^sup>\<real> x")
      case T: True 
      show "?P(succ n)"
      proof(rule bexI[of _ x],intro ballI impI)
        fix m assume [ty]: "m be Nat" and "m in succ n"
        hence "m in n or m=n" using ordinal1_th_4 by mty auto
        thus "|. seq . m .| \<le>\<^sup>\<real> x" using T x by mty auto
      qed mauto
    next
      case  False
      hence F: "x \<le>\<^sup>\<real> |. seq . n .|" using real_0_th_33 by mty auto
      show "?P(succ n)"
      proof(rule bexI[of _ "|. seq . n .|"],intro ballI impI)
        fix m assume [ty]: "m be Nat" and "m in succ n"
        hence "m in n or m=n" using ordinal1_th_4 by mty auto
        hence "|. seq . m .| \<le>\<^sup>\<real> x or m=n" using x by mty auto
        hence "|. seq . m .| \<le>\<^sup>\<real> |. seq . n .| or m=n" using F rat_0_def_8t[OF _ _ _ _ F]
          by mty auto
        thus "|. seq . m .| \<le>\<^sup>\<real> |. seq . n .|" using real_0_def_8r by mty auto
      qed mauto
    qed
  qed mauto
  obtain x where [ty]: "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    x: "for m st m in succ N holds |. seq . m .| \<le>\<^sup>\<real> x"
    using ordinal_2_sch_19[of "succ N", OF _ P0 Pn] by mty auto
  show "ex r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r <>{} & (for n holds |. seq . n .| \<le>\<^sup>\<real> r)"
  proof(rule bexI[of _ "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"],intro conjI ballI)
    have r1:"r <>{}" "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using r arytm_3_def_13r arytm_3_def_11c by mty auto
    thus "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<noteq> {} " using r arytm_3_th_63[of x r] by mty auto
    have r2:"x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_77 by mty auto
    hence r3: "x \<le>\<^sup>\<real> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using rat_0_th_29 by mty auto
    fix n assume [ty]:"n is Nat"
    show "|. seq . n .| \<le>\<^sup>\<real> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
    proof(cases "n in succ N")
      case True
      hence "|. seq . n .| \<le>\<^sup>\<real> x" using x by mty auto
      thus "|. seq . n .| \<le>\<^sup>\<real> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using rat_0_def_8t[OF _ _ _ _ r3] by mty auto
    next 
      case False
        hence "succ N \<subseteq> n" using ordinal1_th_12[of n "succ N"] by mty auto
        hence as: "N in n" using ordinal1_th_17 by mty auto
        hence "N \<subseteq> n" "N \<subseteq> N" using  ordinal1_def_2[of n] xboole_0_def_10[of N N] by mty auto
        hence "|. ?s . n -\<^sub>\<S>\<^sup>\<real> ?s . N .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using n as by mty auto
        hence "|. ?s . n -\<^sub>\<S>\<^sup>\<real> ?s . N .| \<le>\<^sup>\<real> r" using rat_0_th_29 real_0_th_33 by mty auto
        hence "?s . n -\<^sub>\<S>\<^sup>\<real> ?s . N \<le>\<^sup>\<real> r " using absvalue_th_5[of "?s . n -\<^sub>\<S>\<^sup>\<real> ?s . N" r] by mty auto
        hence "?s . n +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ?s . N) \<le>\<^sup>\<real> r " using real_0_def_6 by mty auto
        hence "?s . n  \<le>\<^sup>\<real> r -\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real> ?s . N)" using rat_1_th_20 by mty auto
        hence H1: "?s . n  \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> ( ?s . N)" using real_0_def_6 real_0_th_20a[of "?s . N"] by mty auto
        have [ty]: "x is rational" "r is rational" by mty auto
        have "N in succ N" using ordinal1_th_2 by mty auto
        hence "|. seq . N .| \<le>\<^sup>\<real> x" using x by mty auto
        hence "?s. N \<le>\<^sup>\<real> x" "r \<le>\<^sup>\<real> r" using seq_ABS[of seq] real_0_def_8r by mty auto
        hence "r +\<^sub>\<S>\<^sup>\<real> ( ?s . N) \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> x" using rat_1_th_16 by mty auto
        hence "?s . n  \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> x" using rat_0_def_8t[OF _ _ _ H1] by mty auto
        thus "|. seq . n .| \<le>\<^sup>\<real> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using r1 seq_ABS[of seq n] real_0_def_4[of r x,simplified] 
          Prat_Preal_add by mty auto
      qed
  qed mauto
qed

mtheorem
  mlet 
  "s1 be CauchyQ\<bar>Function-of NAT,RAT",
  "s2 be CauchyQ\<bar>Function-of NAT,RAT" 
  "cluster s1 (*) s2 \<rightarrow> CauchyQ"
proof(standard,rule CauchyI[THEN iffD2],simp,intro ballI impI)
  fix e assume [ty]:"e be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         e: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  obtain r1 where [ty]:"r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and  
    r1: "r1 <>{} & (for n holds |. s1 . n .| \<le>\<^sup>\<real> r1)" using Cauchy_min[of s1] by mty auto
  obtain S1 where [ty]:"S1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    s1: "S1 in omega & r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ{})" using arytm_3_th_95[of r1 "succ {}"] r1 by mty auto
  hence rs1: "{}\<le>\<^sup>\<real> r1" 
      "r1 \<le>\<^sup>\<real> S1" using arytm_3_th_53[of S1] rat_0_Q[of r1] rat_0_th_29 by mty auto
  hence rs11: "{} \<le>\<^sup>\<real> S1" "{} <>S1" using rat_0_def_8t[of S1 r1 "{}"] r1 real_0_def_8s by mty auto
  have [ty]:"S1 is Nat" using s1 ordinal1_def_12 by mty auto
  obtain r2 where [ty]:"r2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and  
    r2: "r2 <>{} & (for n holds |. s2 . n .| \<le>\<^sup>\<real> r2)" using Cauchy_min[of s2] by mty auto
  obtain S2 where [ty]:"S2 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    s2: "S2 in omega & r2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ{})" using arytm_3_th_95[of r2 "succ {}"] r2 by mty auto
  hence rs2: "{}\<le>\<^sup>\<real> r2" 
      "r2 \<le>\<^sup>\<real> S2" using arytm_3_th_53[of S2] rat_0_Q[of r2] rat_0_th_29 by mty auto
  hence rs22: "{} \<le>\<^sup>\<real> S2" "{} <>S2" using rat_0_def_8t[of S2 r2 "{}"] r2 real_0_def_8s by mty auto
  have [ty]:"S2 is Nat" using s2 ordinal1_def_12 by mty auto
  have "2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2 <>{}" using Mult_9[of S2 "2\<^sub>\<S>"] rs22 by mty auto
  hence  "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2)" using arytm_3_TH4 by mty auto
  hence H1:"{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))" using e arytm_3_TH5 by mty auto
  have "2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1 <>{}" using Mult_9[of S1 "2\<^sub>\<S>"] rs11 by mty auto
  hence  "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1)" using arytm_3_TH4 by mty auto
  hence H2:"{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))" using e arytm_3_TH5 by mty auto
  then obtain N2 where [ty]:"N2 is Nat" and
    n2: "\<forall>n : Nat. \<forall>m : Nat. N2 \<subseteq> n \<and> N2 \<subseteq> m \<and> n in m \<longrightarrow> 
      |. s2 . m -\<^sub>\<S>\<^sup>\<real> s2 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))" 
      using CauchyI[THEN iffD1, THEN bspec, of s2 "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))"] by mty auto
  obtain N1 where [ty]:"N1 is Nat" and
    n1: "\<forall>n : Nat. \<forall>m : Nat. N1 \<subseteq> n \<and> N1 \<subseteq> m \<and> n in m \<longrightarrow> 
      |. s1 . m -\<^sub>\<S>\<^sup>\<real> s1 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))" 
      using CauchyI[THEN iffD1, THEN bspec, of s1 "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))"] H1 by mty auto
  let ?N="N1 +\<^sub>\<S>\<^sup>\<nat> N2"
  show " \<exists>N :
          Nat. \<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<and> n in m \<longrightarrow> 
      |. (s1 (*) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (*) s2) . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  proof(rule bexI[of _ ?N],intro ballI impI)
    fix n m assume [ty]: "n be Nat" "m be Nat" and
        AS:   "?N \<subseteq> n \<and> ?N \<subseteq> m \<and> n in m "
    have "N1 \<subseteq> ?N" using Add_10 by mty auto
    hence "N1 \<subseteq> m" "N1 \<subseteq> n" 
      using AS xboole_1_th_1 [of _ ?N N1] by mty auto
    hence Bs1:"|. s1 . m -\<^sub>\<S>\<^sup>\<real> s1 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))" using AS n1 by mty auto
  hence Bss1: "|. s1 . m -\<^sub>\<S>\<^sup>\<real> s1 . n .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))" using arytm_3_th_68 by mty auto
    have "N2 \<subseteq> ?N" using Add_10 Add_6 by mty auto
    hence Z: "N2 \<subseteq> m" "N2 \<subseteq> n" 
      using AS xboole_1_th_1 [of _ ?N N2] by mty auto
    hence As2: "|. s2 . m -\<^sub>\<S>\<^sup>\<real> s2 . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))" using n2 AS by mty auto
    hence Ass2: "|. s2 . m -\<^sub>\<S>\<^sup>\<real> s2 . n .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))" 
      using arytm_3_th_68 by mty auto
    have "{} = (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))) -\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))" using rat_1_th_18 by mty auto
    hence S3: "{} = (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))" 
      using real_0_def_6 by mty auto
    have "-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)) =           
              (s1. m)  *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n))" using real_0_th_42[of "s2 . n" "s1. m"]  by mty auto
    hence "(((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m))  ) +\<^sub>\<S>\<^sup>\<real> 
             ((-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))) = (s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(s2 . n)))"
      using real_0_th_28s by mty auto
    hence H1: "(((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m))  ) +\<^sub>\<S>\<^sup>\<real> 
             ((-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))) = (s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))"
      using real_0_def_6[of "s2. m"] by mty auto
    have "(-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))) = (s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)"
"(-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))) = ((-\<^sub>\<S>\<^sup>\<real> (s1. n))  *\<^sub>\<S>\<^sup>\<real> ( (s2 . n)))"
      using real_0_th_20a[of "(s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)"]
  real_0_th_42[of "s2 . n" "s1 .n"]
      by mty auto
    hence "(-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))) +\<^sub>\<S>\<^sup>\<real> 
             (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))) =((s1. m) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (s1. n))) *\<^sub>\<S>\<^sup>\<real> (s2 . n)" 
      using real_0_th_28[of "s2 . n" "-\<^sub>\<S>\<^sup>\<real>(s1. n)"] by mty auto
    hence H2: "(-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))) +\<^sub>\<S>\<^sup>\<real> 
             (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))) =((s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) *\<^sub>\<S>\<^sup>\<real> (s2 . n)" 
      using real_0_def_6[of "s1 . m"] by mty auto
    
  
 have "(s1 (*) s2) . m = (s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m)"
         "(s1 (*) s2) . n = (s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)" using seq_M by mty auto 
    hence " (s1 (*) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (*) s2) . n =
              ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m)) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))" 
      using real_0_def_6[of "(s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m)" "(s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)",simplified] 
      by mty auto
    also have "... =  (((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m)) +\<^sub>\<S>\<^sup>\<real>
         ((-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))) ) +\<^sub>\<S>\<^sup>\<real> 
                  (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))"
      using real_0_th_8[of "(s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m)"] S3 by mty auto

    
    also have "... =  (( ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m))   +\<^sub>\<S>\<^sup>\<real>
             (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))  +\<^sub>\<S>\<^sup>\<real> 
             (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))) +\<^sub>\<S>\<^sup>\<real> 
             (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))"
     using real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))" "(-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))"] 
       by mty auto
   also have "... =  ( ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . m))   +\<^sub>\<S>\<^sup>\<real> 
             (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))  +\<^sub>\<S>\<^sup>\<real> 
             ((-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n)))) +\<^sub>\<S>\<^sup>\<real> 
             (-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))"
     using real_0_th_15[of "-\<^sub>\<S>\<^sup>\<real> ((s1. n)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))" "(-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((s1. m)  *\<^sub>\<S>\<^sup>\<real> (s2 . n))))"] 
       by mty auto          
     also have "... = ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) +\<^sub>\<S>\<^sup>\<real>
                (((s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) *\<^sub>\<S>\<^sup>\<real> (s2 . n))" using H1 H2 by mty auto
     finally have H3: " |. (s1 (*) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (*) s2) . n .| \<le>\<^sup>\<real> 
       |. ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) .| +\<^sub>\<S>\<^sup>\<real>
                |. (((s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) *\<^sub>\<S>\<^sup>\<real> (s2 . n)) .|" using absvalue_th_6
         [of "((s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) *\<^sub>\<S>\<^sup>\<real> (s2 . n)" "(s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))"]        
       by mty auto
     have "|. s1 . m .| \<le>\<^sup>\<real> r1" using r1 by mty auto
     hence "|. s1 . m .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" "r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1" using s1 rat_0_th_29 arytm_3_th_53 by mty auto
     hence P1: "|. s1 . m .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1" using arytm_3_th_67[of S1 r1] by mty auto
     have "|. ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) .| =
          |. (s1. m) .|  *\<^sub>\<S>\<^sup>\<real> |. ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n)) .|" using absvalue_th_9 by mty auto
     hence HH1: "|. ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) .| = 
          ( |. (s1. m) .|)  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( |. ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n)) .| )" using real_0_def_7 Prat_Preal_mult by mty auto
     have "S1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))) =  (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1)))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1"
       using arytm_3_def_12c by mty auto
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((( 1\<^sub>\<S>  *\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> ) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1)" using 
    Mult_5[of "1\<^sub>\<S>"] arytm_3_th_52[of S1 "((1\<^sub>\<S>) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))" e] by mty auto
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> S1))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1)" using  arytm_3_th_49 by mty auto 
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> S1)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S1))" 
         using  arytm_3_th_52[of S1] by mty auto 
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S>))" 
         using arytm_3_TH2 rs11 by mty auto 
       finally have hh1: "S1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1))) = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ))" 
         using arytm_3_th_53 arytm_3_def_12c[of "1\<^sub>\<S>"] by mty auto 
     have "( |. (s1. m) .|)  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( |. ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n)) .| ) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S1)))"
       using arytm_3_th_82Be
      [OF _ _ _ _ P1 As2] rs11 by mty auto
     hence "|. ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ))" 
       using HH1 hh1 by mty auto
   hence L1: "|. ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) .| <\<^sup>\<real>  e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ))" 
       using rat_0_th_29 by mty auto
     have "|. s2 . n .| \<le>\<^sup>\<real> r2" using r2 by mty auto
     hence "|. s2 . n .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2" "r2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2" using s2 rat_0_th_29 arytm_3_th_53 by mty auto
     hence P1: "|. s2 . n .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2" using arytm_3_th_67[of S2 r2] by mty auto
     have "|.  ((s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n)) *\<^sub>\<S>\<^sup>\<real> (s2. n)  .| =
          |. (s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n) .|  *\<^sub>\<S>\<^sup>\<real> |. (s2 . n) .|" using absvalue_th_9 by mty auto
     hence HH1: "|.  ((s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n)) *\<^sub>\<S>\<^sup>\<real> (s2. n)  .| =
          ( |. (s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n) .| )  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>( |. (s2 . n) .| )" using real_0_def_7 Prat_Preal_mult by mty auto
   have "  (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2)))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2 = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((( 1\<^sub>\<S>  *\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> ) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2)" using 
    Mult_5[of "1\<^sub>\<S>"] arytm_3_th_52[of S2 "((1\<^sub>\<S>) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))" e] by mty auto
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> S2))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2)" using  arytm_3_th_49 by mty auto 
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> S2)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2))" 
         using  arytm_3_th_52[of S2] by mty auto 
    also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S>))" 
         using arytm_3_TH2 rs22 by mty auto 
       finally have hh1: "(e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2 = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ))" 
         using arytm_3_th_53 arytm_3_def_12c[of "1\<^sub>\<S>"] by mty auto 
  have "( |. (s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n) .| )  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>( |. (s2 . n) .| ) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>   (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> S2))) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S2"
       using arytm_3_th_82B
      [OF _ _ _ _ Bss1 P1,simplified] by mty auto
     hence "|.  ((s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n)) *\<^sub>\<S>\<^sup>\<real> (s2. n)  .| \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ))" 
       using HH1 hh1 by mty auto
 hence L2: "|.  ((s1 . m) -\<^sub>\<S>\<^sup>\<real> (s1 . n)) *\<^sub>\<S>\<^sup>\<real> (s2. n)  .| \<le>\<^sup>\<real>  e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> ))" 
   using rat_0_th_29 by mty auto
  have L12:"|. ((s1. m)  *\<^sub>\<S>\<^sup>\<real> ((s2 . m) -\<^sub>\<S>\<^sup>\<real> (s2 . n))) .| +\<^sub>\<S>\<^sup>\<real>
                |. (((s1. m) -\<^sub>\<S>\<^sup>\<real> (s1. n)) *\<^sub>\<S>\<^sup>\<real> (s2 . n)) .| <\<^sup>\<real> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> )) )
           +\<^sub>\<S>\<^sup>\<real> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> )))" using rat_1_th_16l2[OF _ _ _ _ L1 L2 ] by mty auto
  have L: "|. (s1 (*) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (*) s2) . n .|<\<^sup>\<real> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) )"
    using rat_0_def_8t1[OF _ _ _ H3 L12] by mty auto
   have "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) =
         (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using real_0_def_4 Prat_Preal_add by mty auto
   also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using arytm_3_th_57 by mty auto
   also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (2\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using arytm_3_th_47 Add_5 by mty auto
  also have "... = e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using arytm_3_th_41 by mty auto
  finally have "e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> e *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) = e" using arytm_3_th_53 by mty auto
  thus "|. (s1 (*) s2) . m -\<^sub>\<S>\<^sup>\<real> (s1 (*) s2) . n .|<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using L rat_0_th_29 by mty auto
  qed mauto
qed mauto

mdef vanishesQ ("vanishes\<^sub>\<rat>") where
 "attr vanishes\<^sub>\<rat> for Function-of NAT,RAT means
     (\<lambda>IT. for \<epsilon> be Rat st 0\<^sub>\<S> <\<^sup>\<real> \<epsilon> holds
              (ex k be Nat st 
                (for n be Nat st k \<subseteq> n holds
                    |. IT . n .| <\<^sup>\<real> \<epsilon>)))"..

end



