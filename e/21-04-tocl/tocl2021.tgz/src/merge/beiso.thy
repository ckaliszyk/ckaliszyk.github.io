theory beiso
  imports "../mml/subset_1"
begin

(* General *)
text_raw {*\DefineSnippet{beIsoT}{*}
definition "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<longleftrightarrow> ((\<forall>\<^sub>Ly. \<ss>2\<hh>(\<hh>2\<ss>(y)) =\<^sub>\<H> y) \<and> 
  (\<forall> x:T. \<hh>2\<ss>(\<ss>2\<hh>(x)) =\<^sub>\<S> x)\<and> (\<forall>\<^sub>Ly. \<hh>2\<ss>(y) be T))"
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{beIsoS}{*}
definition "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<longleftrightarrow> ((\<forall>\<^sub>Ly. \<ss>2\<hh>(\<hh>2\<ss>(y)) =\<^sub>\<H> y) \<and>
  (\<forall>x:Element-of d. \<hh>2\<ss>(\<ss>2\<hh>(x)) =\<^sub>\<S> x)\<and> (\<forall>\<^sub>Ly. \<hh>2\<ss>(y) in d))"
text_raw {*}%EndSnippet*}


text_raw {*\DefineSnippet{beIsoS_d}{*}
theorem beIsoS_d:
  "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<Longrightarrow> d is non empty" 
text_raw {*}%EndSnippet*}
proof-
  assume "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
  then have "(\<forall>\<^sub>Ly. \<hh>2\<ss>(y) in d)" using beIsoS_def[of \<hh>2\<ss> \<ss>2\<hh> d] by auto
  hence "\<hh>2\<ss>(THE x . True ) in d" by auto
  thus "d is non empty" using xboole_0_def_1 all_set by auto
qed

text_raw {*\DefineSnippet{beIsoT_d}{*}
theorem beIsoT_d:
  "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<Longrightarrow> inhabited(T)" 
text_raw {*}%EndSnippet*}
proof-
  assume "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T)"
  then have "(\<forall>\<^sub>Ly. \<hh>2\<ss>(y) be T)" using beIsoT_def[of \<hh>2\<ss> \<ss>2\<hh> T] by auto
  hence "\<hh>2\<ss>(THE x . True ) be T" by auto
  thus "inhabited(T)" using all_set inhabited_def by auto
qed

text_raw {*\DefineSnippet{beIso_d}{*}
theorem beIsoProp:
  "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<Longrightarrow> d be non empty" 
  "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<Longrightarrow> inhabited(T)" 
text_raw {*}%EndSnippet*}
  using beIsoT_d[of "\<hh>2\<ss>" "\<ss>2\<hh>"]  beIsoS_d[of "\<hh>2\<ss>" "\<ss>2\<hh>"] by auto


text_raw {*\DefineSnippet{beIsoT_m}{*}
theorem beIsoT_m: 
  "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<Longrightarrow> \<hh>2\<ss>(x) be T" 
text_raw {*}%EndSnippet*}
proof-
  assume "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T)"
  thus "\<hh>2\<ss>(x) be T" using beIsoT_def[of \<hh>2\<ss> \<ss>2\<hh> T] by auto
qed

text_raw {*\DefineSnippet{beIsoS_m}{*}
theorem beIsoS_m: 
  "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<Longrightarrow> \<hh>2\<ss>(x) is Element-of d" 
text_raw {*}%EndSnippet*}
proof-
  assume "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
  hence "\<hh>2\<ss>(x) in d" using beIsoS_def[of \<hh>2\<ss> \<ss>2\<hh> d] by auto
  thus "\<hh>2\<ss>(x) is Element-of d" using Element(6) all_set by auto
qed

text_raw {*\DefineSnippet{beIsoS_e}{*}
theorem beIsoS_e: "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<Longrightarrow> 
  x is Element-of d \<Longrightarrow> \<hh>2\<ss>(\<ss>2\<hh>(x)) =\<^sub>\<S> x "
text_raw {*}%EndSnippet*}
proof-
  have [ex]:" inhabited(Element-of d)" using  subset_1_def_1_ex all_set by auto
  assume "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)" " x is Element-of d"
  thus "\<hh>2\<ss>(\<ss>2\<hh>(x)) = x" using beIsoS_def[of \<hh>2\<ss> \<ss>2\<hh> d] all_set by auto
qed

text_raw {*\DefineSnippet{beIsoS_i}{*}
theorem beIsoS_i: 
  "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<Longrightarrow> \<ss>2\<hh>(\<hh>2\<ss>(x)) =\<^sub>\<H> x " using beIsoS_def[of \<hh>2\<ss> \<ss>2\<hh> d] by auto
text_raw {*}%EndSnippet*}


text_raw {*\DefineSnippet{beIsoT_e}{*}
theorem beIsoT_e: "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<Longrightarrow> 
  x be T \<Longrightarrow> \<hh>2\<ss>(\<ss>2\<hh>(x)) =\<^sub>\<S> x "
text_raw {*}%EndSnippet*}
proof-
  assume A:"beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T)" " x be T"
  hence [ex]:" inhabited(T)" using beIsoT_d by auto  
  show "\<hh>2\<ss>(\<ss>2\<hh>(x)) = x" using beIsoT_def[of \<hh>2\<ss> \<ss>2\<hh> T] A by auto
qed

text_raw {*\DefineSnippet{beIsoT_i}{*}
theorem beIsoT_i: 
  "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<Longrightarrow> \<ss>2\<hh>(\<hh>2\<ss>(x)) =\<^sub>\<H> x " using beIsoT_def[of \<hh>2\<ss> \<ss>2\<hh> T] by auto
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{beIsoTS}{*}
theorem beIsoS_Type_Set:
  assumes "\<And> x. x be T iff x in d"
  shows "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T) \<Longrightarrow> beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
        "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d) \<Longrightarrow> beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T)"
text_raw {*}%EndSnippet*}
proof-
  assume A: "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T)"
  show "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)" unfolding beIsoS_def
  proof(intro conjI)
    show "\<forall>\<^sub>Ly. \<ss>2\<hh>(\<hh>2\<ss>(y)) =\<^sub>\<H> y" using A[unfolded beIsoT_def] by auto
    have [ty]:"d be set" using all_set by auto
    have [ex]: "inhabited(T)" using beIsoT_d A by auto
    hence "(the T) be T" by auto
    hence "the T in d" using assms by auto
    hence [ty]: "not d is empty" using xboole_0_def_1 by auto
    show "\<forall>x:Element-of d. \<hh>2\<ss>(\<ss>2\<hh>(x)) = x"
    proof
      fix x assume "x be Element-of d"
      hence "x in d" using Element(7) by auto
      hence "x be T" using assms by auto
      then show "\<hh>2\<ss>(\<ss>2\<hh>(x)) = x"  using A[unfolded beIsoT_def] by auto
    qed mauto
    show "\<forall>\<^sub>Ly. \<hh>2\<ss>(y) in d"
    proof fix y
      have "\<hh>2\<ss>(y) is T" using A[unfolded beIsoT_def] by auto
      then show "\<hh>2\<ss>(y) in d" using assms by auto
    qed
  qed
next
  assume A:"beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
  show "beIsoT(\<hh>2\<ss>,\<ss>2\<hh>,T)" unfolding beIsoT_def
  proof(intro conjI)
    have [ty]:"d be set" using all_set by auto
    show "\<forall>\<^sub>Ly. \<ss>2\<hh>(\<hh>2\<ss>(y)) =\<^sub>\<H> y" using A[unfolded beIsoS_def] by auto 
    have "(\<forall>\<^sub>Ly. \<hh>2\<ss>(y) in d)" using beIsoS_def[of \<hh>2\<ss> \<ss>2\<hh> d] A by auto
    hence "\<hh>2\<ss>(THE x . True ) in d" by auto
    hence "\<hh>2\<ss>(THE x . True ) be T" using assms by auto
    hence [ex]: "inhabited(T)" using inhabited_def by auto
    show "\<forall>x : T. \<hh>2\<ss>(\<ss>2\<hh>(x)) = x" 
    proof
      fix x assume "x be T" hence "x in d" using assms by auto
      hence "x be Element-of d" using Element(6) by auto
      then show "\<hh>2\<ss>(\<ss>2\<hh>(x)) = x" using A[unfolded beIsoS_def] by auto
    qed mauto
    show "\<forall>\<^sub>Ly. \<hh>2\<ss>(y) be T" using assms A[unfolded beIsoS_def] by auto
  qed
qed



text_raw {*\DefineSnippet{TransformHS}{*}
definition TransformHS where
 "func TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2,\<hh>2\<ss>Y,HFun,x1,x2) \<rightarrow> set equals
    \<hh>2\<ss>Y(HFun(\<ss>2\<hh>X1(x1),\<ss>2\<hh>X2(x2)))"
text_raw {*}%EndSnippet*}

schematic_goal TransformHS:
  shows "?X" apply (rule func_equals_property[OF TransformHS_def],simp add:all_set) done



theorem TransformHS_typeS:
  assumes "beIsoS(\<hh>2\<ss>Y,\<ss>2\<hh>Y,Y)"
  shows "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,x1,x2) is Element-of Y"
  using TransformHS[of \<ss>2\<hh>X1 \<ss>2\<hh>X2  \<hh>2\<ss>Y IsaFun] beIsoS_m[OF assms] by auto


theorem Transform_MIS:
  assumes "beIsoS(\<hh>2\<ss>X1,\<ss>2\<hh>X1,X1)" "beIsoS(\<hh>2\<ss>X2,\<ss>2\<hh>X2,X2)"
  shows "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,\<hh>2\<ss>X1(x1),\<hh>2\<ss>X2(x2)) = \<hh>2\<ss>Y (IsaFun(x1,x2))"
proof-
  have "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,\<hh>2\<ss>X1(x1),\<hh>2\<ss>X2(x2)) 
          = \<hh>2\<ss>Y(IsaFun(\<ss>2\<hh>X1(\<hh>2\<ss>X1(x1)),\<ss>2\<hh>X2(\<hh>2\<ss>X2(x2))))" 
    using TransformHS[of \<ss>2\<hh>X1 \<ss>2\<hh>X2 \<hh>2\<ss>Y IsaFun] by mty auto 
  then show "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,\<hh>2\<ss>X1(x1),\<hh>2\<ss>X2(x2))  = \<hh>2\<ss>Y(IsaFun(x1,x2))" 
       using beIsoS_i[OF assms(2)] beIsoS_i[OF assms(1)] by auto
qed

theorem Transform_IMS:
  assumes "beIsoS(\<hh>2\<ss>Y,\<ss>2\<hh>Y,Y)" 
  shows "\<ss>2\<hh>Y (TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,x1,x2)) =\<^sub>\<H> IsaFun(\<ss>2\<hh>X1(x1),\<ss>2\<hh>X2(x2))"
proof-
  let ?T="TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,x1,x2)"
  let ?I="IsaFun(\<ss>2\<hh>X1(x1),\<ss>2\<hh>X2(x2))"
  have "\<ss>2\<hh>Y(?T) =\<^sub>\<H> \<ss>2\<hh>Y(\<hh>2\<ss>Y(?I))" using TransformHS[of \<ss>2\<hh>X1 \<ss>2\<hh>X2 \<hh>2\<ss>Y IsaFun] by mty auto
  then show "\<ss>2\<hh>Y(?T) =\<^sub>\<H> ?I" using beIsoS_i[OF assms] by mty auto 
qed

theorem TransformHS_typeT:
  assumes "beIsoT(\<hh>2\<ss>Y,\<ss>2\<hh>Y,Y)"
  shows "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,x1,x2) is Y"
  using TransformHS[of \<ss>2\<hh>X1 \<ss>2\<hh>X2  \<hh>2\<ss>Y IsaFun] beIsoT_m[OF assms] by auto


theorem Transform_MIT:
  assumes "beIsoT(\<hh>2\<ss>X1,\<ss>2\<hh>X1,X1)" "beIsoT(\<hh>2\<ss>X2,\<ss>2\<hh>X2,X2)"
  shows "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,\<hh>2\<ss>X1(x1),\<hh>2\<ss>X2(x2)) = \<hh>2\<ss>Y (IsaFun(x1,x2))"
proof-
  have "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,\<hh>2\<ss>X1(x1),\<hh>2\<ss>X2(x2)) 
          = \<hh>2\<ss>Y(IsaFun(\<ss>2\<hh>X1(\<hh>2\<ss>X1(x1)),\<ss>2\<hh>X2(\<hh>2\<ss>X2(x2))))" 
    using TransformHS[of \<ss>2\<hh>X1 \<ss>2\<hh>X2 \<hh>2\<ss>Y IsaFun] by mty auto 
  then show "TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,\<hh>2\<ss>X1(x1),\<hh>2\<ss>X2(x2))  = \<hh>2\<ss>Y(IsaFun(x1,x2))" 
       using beIsoT_i[OF assms(2)] beIsoT_i[OF assms(1)] by auto
qed

theorem Transform_IMT:
  assumes "beIsoT(\<hh>2\<ss>Y,\<ss>2\<hh>Y,Y)" 
  shows "\<ss>2\<hh>Y (TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,x1,x2)) =\<^sub>\<H> IsaFun(\<ss>2\<hh>X1(x1),\<ss>2\<hh>X2(x2))"
proof-
  let ?T="TransformHS(\<ss>2\<hh>X1,\<ss>2\<hh>X2, \<hh>2\<ss>Y,IsaFun,x1,x2)"
  let ?I="IsaFun(\<ss>2\<hh>X1(x1),\<ss>2\<hh>X2(x2))"
  have "\<ss>2\<hh>Y(?T) =\<^sub>\<H> \<ss>2\<hh>Y(\<hh>2\<ss>Y(?I))" using TransformHS[of \<ss>2\<hh>X1 \<ss>2\<hh>X2 \<hh>2\<ss>Y IsaFun] by mty auto
  then show "\<ss>2\<hh>Y(?T) =\<^sub>\<H> ?I" using beIsoT_i[OF assms] by mty auto 
qed


end