theory pre_merge_rat2
  imports  pre_merge_int pre_merge_rat 
begin

reserve r for Rat

mdef rat_1_n ("numerator\<^sub>\<rat> _" 90)where
 mlet "x be Rat"
 "func  numerator\<^sub>\<rat> x \<rightarrow> Integer means
     \<lambda>it. it = numerator(x) if x is Element-of RAT\<^bsup>\<ge>0\<^bsub> otherwise \<lambda>it. it = -\<^sub>\<S>\<^sup>\<real> numerator(-\<^sub>\<S>\<^sup>\<real> x)"
proof(auto)
  assume [ty]: "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
  thus "numerator(x) be integer" by mauto
next
  assume [ty]: "\<not> x is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  thus "-\<^sub>\<S>\<^sup>\<real> numerator(-\<^sub>\<S>\<^sup>\<real> x) be integer" by mauto
qed

mdef rat_1_d ("denominator\<^sub>\<rat> _" 90)where
 mlet "x be Rat"
 "func denominator\<^sub>\<rat> x \<rightarrow> Nat means
     \<lambda>it. it = denominator(x) if x is Element-of RAT\<^bsup>\<ge>0\<^bsub> otherwise \<lambda>it. it = denominator(-\<^sub>\<S>\<^sup>\<real> x)"
proof(auto)
  assume [ty]: "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
  thus "denominator(x) be natural" "denominator(x) be set" by mauto
next
  assume [ty]: " \<not> x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
  thus "denominator(-\<^sub>\<S>\<^sup>\<real> x) be natural" "denominator(-\<^sub>\<S>\<^sup>\<real> x) be set" by mauto
qed

mtheorem rat_1_d_zero:
  "{} <> denominator\<^sub>\<rat> r" 
proof (cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
  case [ty]:True
  hence "denominator\<^sub>\<rat> r = denominator(r)" using rat_1_d[of r] by mty auto
  thus "{}<> denominator\<^sub>\<rat> r " using arytm_3_th_35[of r] by mty auto
next 
  case [ty]:False
    hence "denominator\<^sub>\<rat> r = denominator(-\<^sub>\<S>\<^sup>\<real> r)" using rat_1_d[of r] by mty auto
  thus "{}<> denominator\<^sub>\<rat> r " using arytm_3_th_35[of "-\<^sub>\<S>\<^sup>\<real> r"] by mty auto
qed

mdef rat_1_div (infix "'/\<^sub>\<rat>" 90)where                  
  mlet "i be Integer", "j be Nat" 
  "func (i /\<^sub>\<rat> j) \<rightarrow> Rat equals 
   i /\<^bsub>\<rat>\<ge>0\<^bsup> j if i is natural
     otherwise -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> j)"
proof
  show " i be natural \<longrightarrow> (i /\<^bsub>\<rat>\<ge>0\<^bsup> j) be Rat"
  proof
    assume [ty]:"i be natural"
    thus "(i /\<^bsub>\<rat>\<ge>0\<^bsup> j) be Rat" by mauto
  qed
  show "\<not> i be natural implies (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> j)) be Rat"
  proof
    assume [ty]: "\<not> i be natural"
    thus "(-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> j)) be Rat" by mauto
  qed
qed mauto

mtheorem
  mlet "i be Nat","j be Nat"
  "cluster i /\<^sub>\<rat> j \<rightarrow>Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof
  have "i /\<^sub>\<rat> j = i /\<^bsub>\<rat>\<ge>0\<^bsup> j" using rat_1_div by mauto
  thus "(i /\<^sub>\<rat> j) be Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto
qed

mtheorem
  mlet "i be non natural\<bar>Integer","j be non empty\<bar>Nat"
  "cluster i /\<^sub>\<rat> j \<rightarrow>non Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof(standard,rule ccontr)
  assume A: "\<not> (i /\<^sub>\<rat> j) be non Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
  have D: "denominator({})<>{}& j <>{}" using arytm_3_th_35[of "{}"] xboole_0_lm_2 by mauto
  have "i /\<^sub>\<rat> j = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> j))" using rat_1_div by mauto
  hence "(-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> j = (numerator({}))/\<^bsub>\<rat>\<ge>0\<^bsup>(denominator({}))"
     using rat_0_th_19 A arytm_3_th_39 by mauto 
  hence " (-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> denominator({}) =\<^sub>\<S> j *\<^sub>\<S>\<^sup>\<nat> numerator({})" "numerator({}) ={}"
    using arytm_3_th_37 arytm_3_th_45[of "numerator({})" "-\<^sub>\<S>\<^sup>\<real> i" "denominator({})" j] D by mauto
  hence "(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> denominator({}) = {}" using Mult_2 by mauto
  hence "(-\<^sub>\<S>\<^sup>\<real> i) = {}" using D Mult_9 by mauto
  hence "i={}" using real_0_th_20a[of i] real_0_th_18 by mauto 
  hence "i is natural" by mauto
  thus False by mauto
qed

mdef rat_1_divides ("_ divides\<^sub>\<int> _ "[0,0]90) where
 mlet "i be Integer", "j be Integer"
 "pred i  divides\<^sub>\<int> j means ex k be Integer st j = i *\<^sub>\<S>\<^sup>\<real> k"..

mtheorem rat_1_div_nat:
  "for i,j be Nat holds (i  divides\<^sub>\<int> j) iff (i  divides j)"
proof(intro ballI iffI3)
  fix i j assume [ty]:"i be Nat" "j be Nat"
  show "(i  divides\<^sub>\<int> j) implies (i divides j)"
  proof
    assume "i divides\<^sub>\<int> j"
    then obtain ji where [ty]:"ji is Integer" and
      N: "j = i *\<^sub>\<S>\<^sup>\<real> ji" using rat_1_divides by mauto
    show "i divides j"
    proof(cases "ji is natural")
      case [ty]: True
        have "j = i *\<^sub>\<S>\<^sup>\<nat> ji" using N  arytm_3_th_59 Prat_Preal_mult[of i ji] 
       real_0_def_7[of i ji] by mauto
        thus "i divides j" using bexI[of _ ji Nat] N div[of i j] all_set by mauto
    next 
      case [ty]:False
        have "i={}" 
        proof(rule ccontr)
          assume "i<>{}"
          hence "j is non natural" using N int_1_R[of ji i] by mauto
          thus False by mauto
        qed
        hence "j={}" using N real_0_th_22 by mty auto
        thus "i divides j" using div_1 by mauto
    qed
  qed
  assume "i divides j"
  then obtain n where [ty]:"n be Nat" and
    A: "i *\<^sub>\<S>\<^sup>\<nat> n =j " using divE by mauto
  have [ty]:"n be Integer" by mty auto
  hence "j = i *\<^sub>\<S>\<^sup>\<real> n" using A arytm_3_th_59 Prat_Preal_mult[of i n]
       real_0_def_7 by mty auto
  hence "\<exists>k : Integer. j =\<^sub>\<S> i *\<^sub>\<S>\<^sup>\<real> k" using bexI[of _ n Integer] by mty auto
  thus "i divides\<^sub>\<int> j" using rat_1_divides[of i j,THEN iffD2]  by mty auto
qed mauto

mtheorem rat_1_div_1:
  "for i,j be Integer st i  divides\<^sub>\<int> j holds (-\<^sub>\<S>\<^sup>\<real> i)  divides\<^sub>\<int> j & i  divides\<^sub>\<int> (-\<^sub>\<S>\<^sup>\<real> j)"
proof(intro ballI impI)
  fix i j assume [ty]:"i is Integer" "j is Integer" and
  "i  divides\<^sub>\<int> j"
  then obtain k where [ty]: "k be Integer" and
    A: "j = i *\<^sub>\<S>\<^sup>\<real> k" using rat_1_divides by mauto
  have "i *\<^sub>\<S>\<^sup>\<real> k = -\<^sub>\<S>\<^sup>\<real> ( -\<^sub>\<S>\<^sup>\<real> (i *\<^sub>\<S>\<^sup>\<real> k))" using real_0_th_20a[of "i *\<^sub>\<S>\<^sup>\<real> k"] by mty auto
  hence "i *\<^sub>\<S>\<^sup>\<real> k = -\<^sub>\<S>\<^sup>\<real> ( (-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<real> k)" using real_0_th_41 by mauto
  hence "j =   (-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> k)" using A real_0_th_42[of k "-\<^sub>\<S>\<^sup>\<real> i",simplified]  by mty auto
  hence H: "(-\<^sub>\<S>\<^sup>\<real> i)  divides\<^sub>\<int> j" 
    using bexI[of _ "-\<^sub>\<S>\<^sup>\<real> k" Integer] rat_1_divides[of "-\<^sub>\<S>\<^sup>\<real> i" j] by mty auto
  have "-\<^sub>\<S>\<^sup>\<real> j = i *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> k)" using real_0_th_42 A by mauto 
  thus "(-\<^sub>\<S>\<^sup>\<real> i)  divides\<^sub>\<int> j & i  divides\<^sub>\<int> (-\<^sub>\<S>\<^sup>\<real> j)" 
    using bexI[of _ "-\<^sub>\<S>\<^sup>\<real> k" Integer] rat_1_divides[of i "-\<^sub>\<S>\<^sup>\<real> j"] H by mty auto
qed mauto

mdef rat_1_coprimeM ("coprimeM _ , _ "[0,0]90) where
 mlet "i be Integer", "j be Integer"
 "pred coprimeM i,j means 
   (for k be Integer st k  divides\<^sub>\<int> i & k divides\<^sub>\<int> j holds k divides\<^sub>\<int> succ {})"..

mtheorem rat_1_cop_1:
  "for n,m be Nat holds n,m are-coprime iff coprimeM n,m"
proof(intro ballI iffI2)
  fix n m assume [ty]:"n be Nat" "m be Nat"
  show "n , m are-coprime \<longrightarrow> coprimeM n , m"
  proof(standard,standard,auto)   
    assume AS: "n , m are-coprime"
    hence as: " n hcf m = succ {}" using arytm_3_th_20 by mauto
    fix k assume [ty]:"k be integer" and 
       A1: "k divides\<^sub>\<int> n" "k divides\<^sub>\<int> m"
    show "k divides\<^sub>\<int> succ {}"
    proof(cases "k is natural")
      case [ty]:True
        hence "k divides n" "k divides m" using A1 rat_1_div_nat by mauto
        hence "k divides succ {}" using arytm_3_def_5[of n m] as by mauto 
        thus "k divides\<^sub>\<int> succ {}" using rat_1_div_nat by mauto 
    next
      case [ty]:False
      have "(-\<^sub>\<S>\<^sup>\<real> k) divides\<^sub>\<int> n" "(-\<^sub>\<S>\<^sup>\<real> k) divides\<^sub>\<int> m" using rat_1_div_1 A1 by mauto
      hence "(-\<^sub>\<S>\<^sup>\<real> k) divides n" "(-\<^sub>\<S>\<^sup>\<real> k) divides m" using rat_1_div_nat by mauto
      hence "(-\<^sub>\<S>\<^sup>\<real> k) divides succ {}" using arytm_3_def_5[of n m] as by mauto 
      hence "(-\<^sub>\<S>\<^sup>\<real> k) divides\<^sub>\<int> succ {}" using rat_1_div_nat by mauto 
      thus " k divides\<^sub>\<int> succ {}" using rat_1_div_1[of "-\<^sub>\<S>\<^sup>\<real> k" "succ {}"] 
        real_0_th_20a[of k] by mauto
    qed
  qed mauto
  show "coprimeM n , m \<longrightarrow> n , m are-coprime"
  proof(standard,standard,simp,simp,intro ballI impI)
    assume AS: "coprimeM n , m"
    fix c d1 d2 assume [ty]:"c be Nat" "d1 be Nat" "d2 be Nat"
    and " n =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d1 \<and> m =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d2"
    hence " n =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<real> d1 \<and> m =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<real> d2" using int_1_def_5(1) by mauto
    hence " c divides\<^sub>\<int> n \<and> c divides\<^sub>\<int> m" using rat_1_divides bexI[of _ d1 Integer] 
      bexI[of _ d2 Integer] by mauto
    hence "c divides\<^sub>\<int> succ {}" using AS rat_1_coprimeM by mauto
    hence "c divides succ {}" using AS rat_1_div_nat by mauto
    thus "c = succ {}" using div_one by mauto
  qed mauto
qed mauto

mtheorem rat_1_cop_3:
  "for i,j be Integer st coprimeM i,j holds coprimeM (-\<^sub>\<S>\<^sup>\<real> i),j"
proof(intro ballI impI,standard,auto)
  fix i j assume [ty]:"i is integer" "j is integer"
  show "-\<^sub>\<S>\<^sup>\<real> i be integer" by mauto
  fix x assume [ty]: "x is integer" and
  A1: "coprimeM i , j" "x divides\<^sub>\<int> (-\<^sub>\<S>\<^sup>\<real> i) " "x divides\<^sub>\<int> j"
  hence "x divides\<^sub>\<int> i" 
    using rat_1_div_1[of x "-\<^sub>\<S>\<^sup>\<real> i"] real_0_th_20a[of i] by mauto
  thus "x divides\<^sub>\<int> succ {} " using A1 rat_1_coprimeM by mauto
qed mauto


mtheorem rat_1_cop_2: 
  "coprimeM numerator\<^sub>\<rat>(r), denominator\<^sub>\<rat>(r)"
proof(cases "{}\<le>\<^sup>\<real> r")
  case T: True
    hence [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_Q by mauto
    have "numerator(r),denominator(r) are-coprime" using arytm_3_th_34[of r] by mauto
    hence "coprimeM numerator(r), denominator(r)" using rat_1_cop_1 by mauto
    thus "coprimeM numerator\<^sub>\<rat>(r),denominator\<^sub>\<rat>(r)" using rat_1_n T rat_1_d by mauto
  next
    case F: False
    hence [ty]: "r  is non Element-of RAT\<^bsup>\<ge>0\<^bsub>"using rat_0_Q by mauto
    have [ty]:"(-\<^sub>\<S>\<^sup>\<real> r)  is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto
    have "numerator(-\<^sub>\<S>\<^sup>\<real> r),denominator(-\<^sub>\<S>\<^sup>\<real> r) are-coprime" using arytm_3_th_34[of "-\<^sub>\<S>\<^sup>\<real> r"] by mauto
    hence "coprimeM numerator(-\<^sub>\<S>\<^sup>\<real> r), denominator(-\<^sub>\<S>\<^sup>\<real> r)" using rat_1_cop_1 by mauto
    hence "coprimeM -\<^sub>\<S>\<^sup>\<real> numerator(-\<^sub>\<S>\<^sup>\<real> r), denominator(-\<^sub>\<S>\<^sup>\<real> r)" using rat_1_cop_3 by mauto
    thus "coprimeM numerator\<^sub>\<rat>(r),denominator\<^sub>\<rat>(r)" using rat_1_n F rat_1_d by mauto
  qed


mtheorem rat_1_cop_4:
  "for n be Integer, d be Nat st d <>{} holds (-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d = (-\<^sub>\<S>\<^sup>\<real> ( n /\<^sub>\<rat> d))"
proof(intro ballI impI)
  fix n d assume [ty]: "n be Integer" "d be Nat"
   and "d<>{}"
  have "((-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d) +\<^sub>\<S>\<^sup>\<real> (n /\<^sub>\<rat> d) ={}" 
  proof(cases "n={}")
    case T: True
    hence "-\<^sub>\<S>\<^sup>\<real> n = {}" using real_0_th_18 by mauto
    hence "(-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d = {}" "(-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d = (-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d"
          "(n) /\<^bsub>\<rat>\<ge>0\<^bsup> d = {}" "( n) /\<^bsub>\<rat>\<ge>0\<^bsup> d = ( n) /\<^sub>\<rat> d"
      using arytm_3_th_40[of d] T rat_1_div by mauto
    thus "((-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d) +\<^sub>\<S>\<^sup>\<real> (n /\<^sub>\<rat> d) ={}" using real_0_th_8 by mty auto
  next case F: False
    show  "((-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d) +\<^sub>\<S>\<^sup>\<real> (n /\<^sub>\<rat> d) ={}"
    proof(cases "n is natural")
      case [ty]:True
      hence [ty]: "(-\<^sub>\<S>\<^sup>\<real> n) is non natural" using real_0_th_17[of n] F by mauto
      have N: " n /\<^bsub>\<rat>\<ge>0\<^bsup> d =  n /\<^sub>\<rat> d" "(-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d = (-\<^sub>\<S>\<^sup>\<real> ( (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> n)) /\<^bsub>\<rat>\<ge>0\<^bsup> d )) " 
        using rat_1_div[of n d,simplified] rat_1_div[of "-\<^sub>\<S>\<^sup>\<real> n" d] real_0_th_22[of n] by mauto
      hence  "(-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d = (-\<^sub>\<S>\<^sup>\<real> (n /\<^bsub>\<rat>\<ge>0\<^bsup> d)) " using real_0_th_20a[of n] by mty auto
      thus "((-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d) +\<^sub>\<S>\<^sup>\<real> (n /\<^sub>\<rat> d) ={}" using real_0_def_5[of "n /\<^bsub>\<rat>\<ge>0\<^bsup> d"] N  by mauto
    next
      case [ty]: False
         hence [ty]: "(-\<^sub>\<S>\<^sup>\<real> n) is natural" by mauto
         have  " n /\<^sub>\<rat> d =  (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d))"    "(-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d = (-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d " 
        using rat_1_div[of n d] rat_1_div[of "-\<^sub>\<S>\<^sup>\<real> n" d] real_0_th_22[of n,simplified] by mauto
      thus "((-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d) +\<^sub>\<S>\<^sup>\<real> (n /\<^sub>\<rat> d) ={}" using real_0_def_5[of "(-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d"] 
           real_0_th_11[of "n /\<^sub>\<rat> d" "(-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d"] by mauto
    qed
  qed
  thus " (-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d = (-\<^sub>\<S>\<^sup>\<real> ( n /\<^sub>\<rat> d))" using real_0_def_5_uniq[of "n /\<^sub>\<rat> d" "(-\<^sub>\<S>\<^sup>\<real> n) /\<^sub>\<rat> d"] by mauto
qed mauto

mtheorem rat_1_cop_5: 
"for n be Integer, d be Nat st coprimeM n,d & d <>{} holds
     numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) =n & denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) =d"
proof(intro ballI impI)
  fix n d assume [ty]:"n be Integer" "d be Nat" and
  A1: "coprimeM n,d & d<>{} "
  show " numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) =n & denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) =d"
  proof(cases "n be natural")
    case True
    hence [ty]: "n is Nat" using all_set by mauto
     have H: "n,d are-coprime" "d,n are-coprime" using rat_1_cop_1[of n d] A1 arytm_3_def_2s[of d n] by mauto
    have "n /\<^sub>\<rat> d = n /\<^bsub>\<rat>\<ge>0\<^bsup> d"  using rat_1_div by mauto
    hence "numerator(n /\<^sub>\<rat> d) = RED(n,d)" 
          "denominator(n /\<^sub>\<rat> d) = RED(d,n)" 
       using arytm_3_th_42[of n d] A1 by mauto
     thus "numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) = n & denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) = d" 
       using arytm_3_th_23[of d n] arytm_3_th_23[of n d]  H rat_1_n[of "n /\<^sub>\<rat> d"]
       rat_1_d[of "n /\<^sub>\<rat> d"] by mauto
   next
     case F[ty]: False
     hence [ty]: "-\<^sub>\<S>\<^sup>\<real> n is natural" by mauto
     have "coprimeM -\<^sub>\<S>\<^sup>\<real> n , d" using A1 rat_1_cop_3 by mauto
     hence H:"-\<^sub>\<S>\<^sup>\<real> n,d are-coprime" "d,-\<^sub>\<S>\<^sup>\<real> n are-coprime" 
       using rat_1_cop_1[of "-\<^sub>\<S>\<^sup>\<real> n" d] A1 arytm_3_def_2s[of d "-\<^sub>\<S>\<^sup>\<real>n"] by mauto
     
     have [ty]:"d is non empty" using A1 xboole_0_lm_1 by auto

     have [ty]:"(n /\<^sub>\<rat> d) is non Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto
     hence "n /\<^sub>\<rat> d = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d))"  using rat_1_div by mauto
     hence "-\<^sub>\<S>\<^sup>\<real> (n /\<^sub>\<rat> d) = ((-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d)"  using real_0_th_20a[of "(-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d"] by mty auto
     hence "numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) = -\<^sub>\<S>\<^sup>\<real> numerator(((-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d))" 
           "denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) = denominator(((-\<^sub>\<S>\<^sup>\<real> n) /\<^bsub>\<rat>\<ge>0\<^bsup> d))" 
       using rat_1_n rat_1_d by mty auto
     hence "numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) = -\<^sub>\<S>\<^sup>\<real> RED(-\<^sub>\<S>\<^sup>\<real> n,d)" 
           "denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) = RED(d,-\<^sub>\<S>\<^sup>\<real> n)" 
       using arytm_3_th_42[of "-\<^sub>\<S>\<^sup>\<real> n" d] A1 rat_0_th_29 by mty auto
    hence "numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) = -\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> n)" 
           "denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) = d" 
      using H arytm_3_th_23[of d "-\<^sub>\<S>\<^sup>\<real> n"] arytm_3_th_23[of "-\<^sub>\<S>\<^sup>\<real> n" d] by mauto
    thus "numerator\<^sub>\<rat>(n /\<^sub>\<rat> d) = n & denominator\<^sub>\<rat>(n /\<^sub>\<rat> d) = d" 
       using real_0_th_20a by mauto
   qed
 qed mauto

mtheorem rat_1_th_1: 
   "(numerator\<^sub>\<rat> (r)) /\<^sub>\<rat>  (denominator\<^sub>\<rat>(r)) = r"
proof(cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
  case [ty]:True
  hence "numerator\<^sub>\<rat> (r) = numerator(r)" 
      "denominator\<^sub>\<rat> (r) = denominator(r)"using rat_1_n rat_1_d by auto 
  hence  "(numerator\<^sub>\<rat> (r)) /\<^sub>\<rat>  (denominator\<^sub>\<rat>(r)) = ((numerator(r)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (denominator(r)))"
    using rat_1_div by mty auto
  thus "(numerator\<^sub>\<rat> (r)) /\<^sub>\<rat>  (denominator\<^sub>\<rat>(r)) =  r" using arytm_3_th_39 by auto
next   
  case [ty]:False
  have D:" denominator(-\<^sub>\<S>\<^sup>\<real> r)<>{}" using arytm_3_th_35 by mauto
  have "numerator\<^sub>\<rat> (r) = -\<^sub>\<S>\<^sup>\<real> numerator(-\<^sub>\<S>\<^sup>\<real> r)" 
    "denominator\<^sub>\<rat> (r) = denominator(-\<^sub>\<S>\<^sup>\<real> r)" using rat_1_n rat_1_d by auto
  hence  "((numerator\<^sub>\<rat> (r)) /\<^sub>\<rat>  (denominator\<^sub>\<rat>(r))) =
  ( -\<^sub>\<S>\<^sup>\<real> ((numerator(-\<^sub>\<S>\<^sup>\<real> r))  /\<^sub>\<rat> (denominator(-\<^sub>\<S>\<^sup>\<real> r))))" using D rat_1_cop_4 by mty auto
  also have "... =  ( -\<^sub>\<S>\<^sup>\<real> ((numerator(-\<^sub>\<S>\<^sup>\<real> r))  /\<^bsub>\<rat>\<ge>0\<^bsup> (denominator(-\<^sub>\<S>\<^sup>\<real> r))))" using rat_1_div by mty auto
  also have "... = (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r))" using arytm_3_th_39[of "-\<^sub>\<S>\<^sup>\<real> r"] by mty auto  
  finally show "(numerator\<^sub>\<rat> (r)) /\<^sub>\<rat>  (denominator\<^sub>\<rat>(r)) =  r" using real_0_th_20a by auto
qed

reserve i,i1,i2,j,j1,j2 for  Integer
reserve n,m,n1,n2 for Nat
reserve r,s,t,w for Rat

mtheorem rat_1_one:
  "r *\<^sub>\<S>\<^sup>\<real> (succ{}) = r" using real_1_th_24[of r] real_0_th_21[of r] by mty auto



mtheorem rat_1_th_4:
  "r <> {} implies (ex s st r *\<^sub>\<S>\<^sup>\<real> s = 1\<^sub>\<S>)"
proof
  assume R: "r<>{}"
  hence R1:"(-\<^sub>\<S>\<^sup>\<real> r) <>{}" using real_0_th_20a[of r] real_0_th_18 by mty auto
  show "ex s st r *\<^sub>\<S>\<^sup>\<real> s = 1\<^sub>\<S>"
  proof(cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True
    then obtain s where [ty]: "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = 1\<^sub>\<S>" using arytm_3_th_54 R by mauto
    hence "r *\<^sub>\<S>\<^sup>\<real> s = 1\<^sub>\<S>" using real_0_def_7[of r s] Prat_Preal_mult by mauto
    thus "ex s st r *\<^sub>\<S>\<^sup>\<real> s = 1\<^sub>\<S>" using bexI[of _ s Rat] by mauto
  next
    case [ty]:False
    hence [ty]:"(-\<^sub>\<S>\<^sup>\<real> r) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto 
    then obtain s where [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      S: "(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = 1\<^sub>\<S>" using arytm_3_th_54 R1 by mauto
    hence "(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s = 1\<^sub>\<S> " using  real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> r" s] Prat_Preal_mult by mauto
     hence "r *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s) = 1\<^sub>\<S>" using real_0_th_42[of s r,simplified] by mty auto
    thus "ex s st r *\<^sub>\<S>\<^sup>\<real> s = 1\<^sub>\<S>" using bexI[of _ "-\<^sub>\<S>\<^sup>\<real>s" Rat] by mauto
  qed 
qed


mtheorem rat_1_th_5:
  "r *\<^sub>\<S>\<^sup>\<real> t = s *\<^sub>\<S>\<^sup>\<real> t iff (r = s or t={})"
proof(rule iffI3)
  show "r *\<^sub>\<S>\<^sup>\<real> t = s *\<^sub>\<S>\<^sup>\<real> t implies (r = s or t={})"
  proof(rule impI, rule ccontr)
    assume AS: "r *\<^sub>\<S>\<^sup>\<real> t =\<^sub>\<S> s *\<^sub>\<S>\<^sup>\<real> t" "\<not> (r =\<^sub>\<S> s \<or> t =\<^sub>\<S> {})"
    then obtain w where [ty]:"w be Rat" and
      T: "t *\<^sub>\<S>\<^sup>\<real> w = 1\<^sub>\<S>" using rat_1_th_4 by mauto  
    hence E: "(r *\<^sub>\<S>\<^sup>\<real> t) *\<^sub>\<S>\<^sup>\<real> w = r" "(s *\<^sub>\<S>\<^sup>\<real> t) *\<^sub>\<S>\<^sup>\<real> w = s" 
      using real_0_th_26[of w t r] rat_1_one[of r] real_0_th_26[of w t s] rat_1_one[of s]
      by mauto
    have "(r *\<^sub>\<S>\<^sup>\<real> t) *\<^sub>\<S>\<^sup>\<real> w = (s *\<^sub>\<S>\<^sup>\<real> t) *\<^sub>\<S>\<^sup>\<real> w" using AS by simp
    hence "r = s" using E by auto 
    thus False using AS by auto
  qed
  assume "r = s or t={}"
  thus "r *\<^sub>\<S>\<^sup>\<real> t = s *\<^sub>\<S>\<^sup>\<real> t" using real_0_th_22[of r] real_0_th_22[of s] by auto
qed


mtheorem rat_1_th_6:
  "n<>{} \<longrightarrow> (i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = i"
proof
  assume A: "n<>{}"
  have N: "n = n/\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})" using arytm_3_th_40 by mauto
  have "succ {} <>{}" by auto
  show "(i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = i"
  proof (cases "i is natural")
    case [ty]: True
      have "i  /\<^sub>\<rat> n  = i  /\<^bsub>\<rat>\<ge>0\<^bsup> n" using rat_1_div by mauto
      hence "(i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = (i  /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n /\<^bsub>\<rat>\<ge>0\<^bsup> succ {})" using 
        real_0_def_7 N Prat_Preal_mult by mty auto
      also have "... = (i*\<^sub>\<S>\<^sup>\<nat>n)/\<^bsub>\<rat>\<ge>0\<^bsup>(n*\<^sub>\<S>\<^sup>\<nat>succ {})" using arytm_3_th_49 by mty auto
      also have "... = (i*\<^sub>\<S>\<^sup>\<nat>n)/\<^bsub>\<rat>\<ge>0\<^bsup>((succ {})*\<^sub>\<S>\<^sup>\<nat> n)" using Mult_6 by mty auto
      also have "... = (i  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n /\<^bsub>\<rat>\<ge>0\<^bsup> n)" using arytm_3_th_49 by mty auto
      also have "... = (i  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using arytm_3_th_41[of n] A by mty auto
      also have "... = (i  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{})" using arytm_3_th_53 by mty auto
      also have "... = i " using arytm_3_th_40[of i i] all_set by mty auto
      finally show "(i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = i" by auto
    next
      let ?i = "-\<^sub>\<S>\<^sup>\<real> i" 
      case [ty]:False
      hence [ty]: "?i is Nat" by mty auto
      have "?i  /\<^sub>\<rat> n  = ?i  /\<^bsub>\<rat>\<ge>0\<^bsup> n" using rat_1_div[of "?i" n] by mauto
      hence "(?i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = (?i  /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n /\<^bsub>\<rat>\<ge>0\<^bsup> succ {})" 
        using real_0_def_7 N Prat_Preal_mult by mty auto
      also have "... = (?i*\<^sub>\<S>\<^sup>\<nat>n)/\<^bsub>\<rat>\<ge>0\<^bsup>(n*\<^sub>\<S>\<^sup>\<nat>succ {})" using arytm_3_th_49 by mty auto
      also have "... = (?i*\<^sub>\<S>\<^sup>\<nat>n)/\<^bsub>\<rat>\<ge>0\<^bsup>((succ {})*\<^sub>\<S>\<^sup>\<nat> n)" using Mult_6 by mty auto
      also have "... = (?i  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n /\<^bsub>\<rat>\<ge>0\<^bsup> n)" using arytm_3_th_49 by mty auto
      also have "... = (?i  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using arytm_3_th_41[of n] A by mty auto
      also have "... = (?i  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{})" using arytm_3_th_53 by mty auto
      also have "... = ?i " using arytm_3_th_40[of ?i ?i] all_set by mty auto
      finally have H: "(?i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = ?i" by auto

      have "(i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n= (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>(i  /\<^sub>\<rat> n)))*\<^sub>\<S>\<^sup>\<real> n" using real_0_th_20a[of "i  /\<^sub>\<rat> n"] by mauto
      also have"... = (-\<^sub>\<S>\<^sup>\<real>(?i  /\<^sub>\<rat> n))*\<^sub>\<S>\<^sup>\<real> n " using rat_1_cop_4 A by mty auto
      also have"... = (-\<^sub>\<S>\<^sup>\<real> ( (?i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n)) " using real_0_th_42 by mty auto
      also have"... = (-\<^sub>\<S>\<^sup>\<real>  ?i) " using H by mty auto

      finally show "(i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n = i" using real_0_th_20a by mty auto
    qed
  qed

mtheorem rat_1_th_6_a:
 "n<>{} \<and>  r *\<^sub>\<S>\<^sup>\<real> n = i \<longrightarrow> r =  i  /\<^sub>\<rat> n"
proof
  assume N: "n<>{} \<and>  r *\<^sub>\<S>\<^sup>\<real> n = i"
  hence "r *\<^sub>\<S>\<^sup>\<real> n = (i  /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n" using rat_1_th_6 by mty auto 
  thus "r =  i  /\<^sub>\<rat> n" using N rat_1_th_5[of _ n r] by mty auto
qed

mtheorem cl_int_rat:
  "cluster integer \<rightarrow> rational for object"
proof(auto)
  fix x assume [ty]:"x be integer"
  show "x is rational"
  proof (cases "x is natural")
    case [ty]:True
    show "x is rational" by mauto
  next
    case [ty]:False
    then obtain k where [ty]:"k be Nat" and 
      K: "k\<noteq>{} & x = [{},k]" using int_1_th_1[of x] by mty auto  
    hence "ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k]" using bexI[of _ k] by mty auto
    thus "x is rational" using rat_0_th_7 by mauto
  qed
qed

mtheorem rat_1_th_7:
 "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j"
proof(cases "i is natural")
  case [ty]:True
   show "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j"
  proof(cases "j is natural")
    case [ty]: True
    have "i  *\<^sub>\<S>\<^sup>\<real> j = i *\<^sub>\<S>\<^sup>\<nat> j" using real_0_def_7[of i j] Prat_Preal_mult 
       arytm_3_th_59[of j i] by mty auto 
    thus "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j" using int_1_def_5 by auto
  next
    case [ty]:False
    have "i  *\<^sub>\<S>\<^sup>\<real> j = (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<real> j)))" using real_0_th_20a[of "i  *\<^sub>\<S>\<^sup>\<real> j"] by mty auto 
        also have "... = (-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)))" using real_0_th_42 by mauto
        also have "... = (-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> j)))" using real_0_def_7[of i "-\<^sub>\<S>\<^sup>\<real> j"] Prat_Preal_mult by mty auto
        also have "... = (-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> j)))" using arytm_3_th_59[of "-\<^sub>\<S>\<^sup>\<real> j" i] by mty auto
       also have "... = (-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)))" using int_1_def_5[of i "-\<^sub>\<S>\<^sup>\<real> j",simplified] by mty auto
      finally show "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j" using  real_0_th_22[of "i  *\<^sub>\<S>\<^sup>\<real>  j"] real_0_th_41[of j i,simplified] by mty auto
    qed
  next
    case [ty]:False
        show "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j"
        proof(cases "j is natural")
          case [ty]: True
           have "i  *\<^sub>\<S>\<^sup>\<real> j = (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<real> j)))" using real_0_th_20a[of "i  *\<^sub>\<S>\<^sup>\<real> j"] by mty auto 
            also have "... = (-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> i)  *\<^sub>\<S>\<^sup>\<real> j))" using real_0_th_42 by mauto
            also have "... = (-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> i)  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j))" using real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> i" j] 
            Prat_Preal_mult by mty auto
            also have "... = (-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real>i)  *\<^sub>\<S>\<^sup>\<nat> ( j)))" using arytm_3_th_59[of j "-\<^sub>\<S>\<^sup>\<real> i"] by mty auto
           also have "... = (-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real>i)  *\<^sub>\<S>\<^sup>\<real> ( j)))" using int_1_def_5[of "-\<^sub>\<S>\<^sup>\<real> i" j] by mty auto
          finally show "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j" using  real_0_th_22[of "i  *\<^sub>\<S>\<^sup>\<real>  j"] real_0_th_41[of j i,simplified] by mty auto
        next
          case [ty]:False
             have "i  *\<^sub>\<S>\<^sup>\<real> j = (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<real> j)))" using real_0_th_20a[of "i  *\<^sub>\<S>\<^sup>\<real> j"] by mty auto 
            also have "... = (-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> i)  *\<^sub>\<S>\<^sup>\<real> j))" using real_0_th_42 by mauto
            also have "... = ((-\<^sub>\<S>\<^sup>\<real> i)  *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j))" using real_0_th_42[of j "-\<^sub>\<S>\<^sup>\<real> i"] by mty auto
            also have "... = ((-\<^sub>\<S>\<^sup>\<real> i)  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> j))" using real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> i" "-\<^sub>\<S>\<^sup>\<real>j"] 
              Prat_Preal_mult by mty auto
            also have "... = ((-\<^sub>\<S>\<^sup>\<real>i)  *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> j))" using arytm_3_th_59[of "-\<^sub>\<S>\<^sup>\<real>j" "-\<^sub>\<S>\<^sup>\<real> i"] by mty auto
           also have "... = (-\<^sub>\<S>\<^sup>\<real>i)  *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)" using int_1_def_5[of "-\<^sub>\<S>\<^sup>\<real> i" "-\<^sub>\<S>\<^sup>\<real>j"] by mty auto
           also have "... = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real>i)  *\<^sub>\<S>\<^sup>\<real>  j)" using  real_0_th_42[of j "-\<^sub>\<S>\<^sup>\<real>i",simplified]  by mty auto
           also have "... = -\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>(i  *\<^sub>\<S>\<^sup>\<real>  j))" using  real_0_th_41[of j i,simplified]  by mty auto
          also have "... = (i  *\<^sub>\<S>\<^sup>\<real>  j)" using  real_0_th_20a by mty auto
          finally show "i  *\<^sub>\<S>\<^sup>\<real> j = i  *\<^sub>\<S>\<^sup>\<real> j" by auto
        qed
      qed

mtheorem rat_1_th_8:
  "n c= m iff n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m"
proof
  assume "n c= m"
  then obtain k where [ty]:"k be Nat" 
   and "m = n+\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by mauto
  hence "m = n+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" using arytm_3_th_58 by mty auto
  thus "n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m" using arytm_3_def_13 bexI[of _ k] by mauto
next 
  assume "n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m"
  then obtain k where [ty]: "k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A1: "m = n+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" using arytm_3_def_13 by mauto
  let ?n = "numerator(k)" let ?d= "denominator(k)"
  have D:"?d<>{}" using arytm_3_th_35 by mauto
  have MNK: "m= m/\<^bsub>\<rat>\<ge>0\<^bsup> succ{}" "n= n/\<^bsub>\<rat>\<ge>0\<^bsup> succ{}" "k = ?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d" using arytm_3_th_40 arytm_3_th_39[of k] by mauto
  hence "m/\<^bsub>\<rat>\<ge>0\<^bsup> succ{} = (n*\<^sub>\<S>\<^sup>\<nat>?d +\<^sub>\<S>\<^sup>\<nat> ((succ{}) *\<^sub>\<S>\<^sup>\<nat>?n))/\<^bsub>\<rat>\<ge>0\<^bsup> ((succ{})*\<^sub>\<S>\<^sup>\<nat>?d)" 
    using D A1 arytm_3_th_46[of ?n n ?d "succ{}"] by mauto
  hence "m/\<^bsub>\<rat>\<ge>0\<^bsup> succ{} = (n*\<^sub>\<S>\<^sup>\<nat>?d +\<^sub>\<S>\<^sup>\<nat> (?n))/\<^bsub>\<rat>\<ge>0\<^bsup> (?d)" 
    using Mult_5[of ?n] Mult_5[of ?d] by mauto
  hence "m *\<^sub>\<S>\<^sup>\<nat> ?d = (succ{})*\<^sub>\<S>\<^sup>\<nat>(n*\<^sub>\<S>\<^sup>\<nat>?d +\<^sub>\<S>\<^sup>\<nat> (?n))" using arytm_3_th_45[of _ m ?d "succ{}"] D by mauto 
  hence A2: "m *\<^sub>\<S>\<^sup>\<nat> ?d = n*\<^sub>\<S>\<^sup>\<nat>?d +\<^sub>\<S>\<^sup>\<nat> (?n)" using Mult_5 by mauto 
  hence "n *\<^sub>\<S>\<^sup>\<nat> ?d c= m*\<^sub>\<S>\<^sup>\<nat>?d " using Add_9 bexI[of _ ?n Nat] by mty auto 
  hence "n c= m" using Mult_14a_s[of m n ?d] D by mty auto
  then obtain i where [ty]:"i be Nat" and
    I: "m = n +\<^sub>\<S>\<^sup>\<nat> i" using Add_9 by mauto
  hence "n *\<^sub>\<S>\<^sup>\<nat> ?d +\<^sub>\<S>\<^sup>\<nat> i *\<^sub>\<S>\<^sup>\<nat> ?d =\<^sub>\<S>  m *\<^sub>\<S>\<^sup>\<nat> ?d" using Mult_11s[of i ?d n] by mty auto
  hence "i *\<^sub>\<S>\<^sup>\<nat> ?d =\<^sub>\<S> ?n " using Add_11[of _ _ "n *\<^sub>\<S>\<^sup>\<nat> ?d"]  A2 by mty auto 
  hence "?n = ?d *\<^sub>\<S>\<^sup>\<nat> i" "?d = ?d *\<^sub>\<S>\<^sup>\<nat> succ{}" "?n, ?d are-coprime" 
    using Mult_6 Mult_5 arytm_3_th_34[of k] by mty auto
  hence "?d =  1\<^sub>\<S>" using arytm_3_def_2E[of ?n ?d,THEN bspec,THEN bspec,THEN bspec, of ?d i "succ{}"] 
    by mty auto
  hence "k = ?n" using MNK arytm_3_th_40 by mauto
  hence "m = n +\<^sub>\<S>\<^sup>\<nat> ?n" using A1 arytm_3_th_58 by mauto
  thus "n c= m" using Add_9[of  m n] bexI[of _ ?n Nat] A1 by mty auto 
qed




mtheorem  rat_1_th_11:
 "(n<>{} \<and> m<>{}) \<longrightarrow> ((i /\<^sub>\<rat> n) = (j /\<^sub>\<rat> m) iff i  *\<^sub>\<S>\<^sup>\<real> m = j  *\<^sub>\<S>\<^sup>\<real> n)"
proof
  assume A: "n<>{} \<and> m<>{}"
  have "((i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = i *\<^sub>\<S>\<^sup>\<real> m" using  rat_1_th_6 A by auto
  hence A1: "((i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = i  *\<^sub>\<S>\<^sup>\<real> m" using rat_1_th_7 by auto
  have "((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = (j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> (m *\<^sub>\<S>\<^sup>\<real> n)" using  
      real_0_th_26[of m n "j /\<^sub>\<rat> m"]  real_0_th_21[of m n] by mty auto
  have "((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = (j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> (m *\<^sub>\<S>\<^sup>\<real> n)" using
      real_0_th_26[of m n "j /\<^sub>\<rat> m"] real_0_th_21 by mty auto
  hence "((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = ((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> m) *\<^sub>\<S>\<^sup>\<real> n" using   
      real_0_th_26[of n m  "j /\<^sub>\<rat> m"] by mty auto
  hence "((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = j  *\<^sub>\<S>\<^sup>\<real> n" using rat_1_th_6[of j m] A by mty auto
   hence A2: "((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = j  *\<^sub>\<S>\<^sup>\<real> n" using  rat_1_th_7[of n j] by mty auto
  show "(i /\<^sub>\<rat> n) = (j /\<^sub>\<rat> m) iff i  *\<^sub>\<S>\<^sup>\<real> m = j  *\<^sub>\<S>\<^sup>\<real> n"
  proof(rule iffI3)
    show "(i /\<^sub>\<rat> n) = (j /\<^sub>\<rat> m) implies i  *\<^sub>\<S>\<^sup>\<real> m = j  *\<^sub>\<S>\<^sup>\<real> n" using A1 A2 by auto
    assume "i  *\<^sub>\<S>\<^sup>\<real> m = j  *\<^sub>\<S>\<^sup>\<real> n"
    hence "((i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m = ((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n) *\<^sub>\<S>\<^sup>\<real> m" using A1 A2 by auto
    hence "((i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> n) = ((j /\<^sub>\<rat> m) *\<^sub>\<S>\<^sup>\<real> n)" using A rat_1_th_5 by mty auto 
    thus "(i /\<^sub>\<rat> n) = (j /\<^sub>\<rat> m)"  using A rat_1_th_5 by mty auto
  qed
qed



mtheorem rat_1_th_12:
 "n<>{} \<and> m<>{} \<longrightarrow> (i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = ((i *\<^sub>\<S>\<^sup>\<real> m) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> n)) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)"
proof
  assume AS: "n<>{} \<and> m<>{}"
  hence "n *\<^sub>\<S>\<^sup>\<nat> m<>{}" using Mult_9[of m n] by mty auto
  hence AS1: "n *\<^sub>\<S>\<^sup>\<real> m<>{}" using int_1_def_5 by mty auto
  have[ty]:  "(n *\<^sub>\<S>\<^sup>\<real> m) is Nat" using int_1_def_5[of n m] by mty auto
  have "(i /\<^sub>\<rat> n)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = ((i /\<^sub>\<rat> n)*\<^sub>\<S>\<^sup>\<real>  n) *\<^sub>\<S>\<^sup>\<real> m"  using real_0_th_26[of m n "i /\<^sub>\<rat> n"]
     rat_1_th_7[of m n]  by mty auto
  hence "(i /\<^sub>\<rat> n)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = i *\<^sub>\<S>\<^sup>\<real> m" using rat_1_th_6 AS by mty auto
  hence A1: "(i /\<^sub>\<rat> n)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = i *\<^sub>\<S>\<^sup>\<real> m" using rat_1_th_7 by mty auto

  have "(j /\<^sub>\<rat> m)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = (j /\<^sub>\<rat> m)*\<^sub>\<S>\<^sup>\<real>  (m *\<^sub>\<S>\<^sup>\<real> n)"  using real_0_th_21[of m n]
     rat_1_th_7[of m n]  by mty auto
  hence "(j /\<^sub>\<rat> m)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = ((j /\<^sub>\<rat> m)*\<^sub>\<S>\<^sup>\<real>  m) *\<^sub>\<S>\<^sup>\<real> n"  using real_0_th_26[of  n m "j /\<^sub>\<rat> m"]
     by mty auto
  hence  "(j /\<^sub>\<rat> m)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = j *\<^sub>\<S>\<^sup>\<real> n" using rat_1_th_6 AS by mty auto
  hence A2: "(j /\<^sub>\<rat> m)*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = j *\<^sub>\<S>\<^sup>\<real> n" using rat_1_th_7 by mty auto
 
  have "(i *\<^sub>\<S>\<^sup>\<real> m) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> n) is Integer" by mty auto
  
  have "((i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m))*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = (i*\<^sub>\<S>\<^sup>\<real> m) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> n)" using real_0_th_28 A1 A2 by mty auto
  hence "((i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m))*\<^sub>\<S>\<^sup>\<real>  (n *\<^sub>\<S>\<^sup>\<real> m) = (i*\<^sub>\<S>\<^sup>\<real> m) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> n)" by mty auto
  thus "(i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = ((i *\<^sub>\<S>\<^sup>\<real> m) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> n)) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" 
    using rat_1_th_6_a AS1 
    by mty auto
qed

  
mtheorem rat_1_th_13: 
   "n<>{} implies (ex a be Nat st a<>{} & a *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = i 
    \<and>  a *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = n)"
proof
  assume N:"n <>{}"
  have [ty]: "i is set" using all_set by auto
  let ?r="i/\<^sub>\<rat>n"
  show "ex a be Nat st a<>{} & a *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = i \<and>  a *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = n"
  proof (cases "i is natural")
    case [ty]:True
    show "ex a be Nat st a<>{} & a *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = i 
    \<and>  a *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = n"
    proof(rule bexI[of _ "i hcf n" Nat],intro conjI)
      have "n hcf i<>{}" using N arytm_3_th_15[of i n] by auto
      thus "i hcf n<>{}" using arytm_3_def_5c by mty auto
      have "i = (i hcf n) *\<^sub>\<S>\<^sup>\<nat> RED(i,n) " using arytm_3_th_21 Mult_6 by mty auto
      also have "... = (i hcf n) *\<^sub>\<S>\<^sup>\<nat> numerator(i/\<^bsub>\<rat>\<ge>0\<^bsup> n)" 
        using N arytm_3_th_42[of i n,simplified] by mty auto
      also have "... = (i hcf n)  *\<^sub>\<S>\<^sup>\<real> numerator(?r)" 
        using int_1_def_5 rat_1_div by mty auto
      finally show "(i hcf n)  *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(?r)) = i" using rat_1_n[of ?r] by mty auto

      have "n = (n hcf i) *\<^sub>\<S>\<^sup>\<nat> RED(n,i) " using arytm_3_th_21 Mult_6 by mty auto
      also have "... = (i hcf n) *\<^sub>\<S>\<^sup>\<nat> denominator(i/\<^bsub>\<rat>\<ge>0\<^bsup> n)" 
        using N arytm_3_th_42[of i n,simplified] arytm_3_def_5c[of n i] by mty auto
      also have "... = (i hcf n)  *\<^sub>\<S>\<^sup>\<real> denominator(?r)" 
        using int_1_def_5 rat_1_div by mty auto
      finally show "(i hcf n)  *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(?r)) = n" using rat_1_d[of ?r] by mty auto      
    qed mauto
  next case [ty]:False
    let ?i = "-\<^sub>\<S>\<^sup>\<real> i"
    show "ex a be Nat st a<>{} & a *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = i 
    \<and>  a *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(i/\<^sub>\<rat>n)) = n"
    proof(rule bexI[of _ "(?i) hcf n" Nat],intro conjI)     
      have [ty]: "n is non empty\<bar>Nat" using N xboole_0_lm_1 by mty auto
      have [ty]:"?r is non Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto

      have "n hcf ?i<>{}" using N arytm_3_th_15[of ?i n,simplified] by mty auto
      thus "?i hcf n<>{}" using arytm_3_def_5c by mty auto
  
      
      have "?i = (?i hcf n) *\<^sub>\<S>\<^sup>\<nat> RED(?i,n) " using arytm_3_th_21 Mult_6 by mty auto
      also have "... = (?i hcf n) *\<^sub>\<S>\<^sup>\<nat> numerator(?i/\<^bsub>\<rat>\<ge>0\<^bsup> n)" 
        using N arytm_3_th_42[of ?i n,simplified] by mty auto
      also have "... = (?i hcf n)  *\<^sub>\<S>\<^sup>\<real> numerator(?i/\<^sub>\<rat> n)" 
        using int_1_def_5 rat_1_div by mty auto
      finally have "?i = (?i hcf n)  *\<^sub>\<S>\<^sup>\<real> numerator(?i/\<^sub>\<rat> n)"
           using rat_1_th_7[of  "numerator(?i/\<^sub>\<rat> n)" "?i hcf n",simplified]  by mty auto
      hence "i = (-\<^sub>\<S>\<^sup>\<real> ((?i hcf n)  *\<^sub>\<S>\<^sup>\<real> numerator(?i/\<^sub>\<rat> n)))" using real_0_th_20a[of i] by mty auto
      also have "... = (?i hcf n)  *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (numerator(?i/\<^sub>\<rat> n)))" 
          using real_0_th_42[of "numerator(?i/\<^sub>\<rat> n)" "?i hcf n" ] by mty auto 
     also have "... = (?i hcf n)  *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat>(i/\<^sub>\<rat>n))" 
          using rat_1_n[of "i/\<^sub>\<rat>n"] rat_1_cop_4[of i n] N by mty auto
        finally show "(?i hcf n) *\<^sub>\<S>\<^sup>\<real> (numerator\<^sub>\<rat> (i /\<^sub>\<rat> n)) =\<^sub>\<S> i" 
           using rat_1_n[of "i/\<^sub>\<rat>n"] rat_1_cop_4[of i n] N by mty auto

 have "n = (n hcf ?i) *\<^sub>\<S>\<^sup>\<nat> RED(n,?i) " using arytm_3_th_21 Mult_6 by mty auto
      also have "... = (?i hcf n) *\<^sub>\<S>\<^sup>\<nat> denominator(?i/\<^bsub>\<rat>\<ge>0\<^bsup> n)" 
        using N arytm_3_th_42[of ?i n,simplified] arytm_3_def_5c[of n ?i] by mty auto
      also have "... = (?i hcf n)  *\<^sub>\<S>\<^sup>\<real> denominator(?i/\<^sub>\<rat> n)" 
        using int_1_def_5 rat_1_div by mty auto
    also have "... = (?i hcf n)  *\<^sub>\<S>\<^sup>\<real> denominator(-\<^sub>\<S>\<^sup>\<real> ?r)" 
        using rat_1_cop_4 N by mty auto
      finally show "(?i hcf n)  *\<^sub>\<S>\<^sup>\<real> (denominator\<^sub>\<rat>(?r)) = n" 
        using rat_1_d[of ?r,simplified] by mty auto      
     qed mauto
   qed
 qed


mtheorem rat_1_th_14:
 "n<>{} \<and> m<>{} \<longrightarrow> (i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)"
proof
  assume NM:"n<>{} \<and> m<>{}"
  hence [ty]:"n is non empty" "m is non empty" using 
    xboole_0_lm_1[OF all_set] by auto
  have NM1: "n*\<^sub>\<S>\<^sup>\<nat>m <>{}" using NM Mult_9[of m n] by mty auto
  show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)"
  proof(cases "i is natural")
    case [ty]: True
    show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)"
      proof(cases "j is natural")
         case [ty]: True
         have "i /\<^sub>\<rat> n = i /\<^bsub>\<rat>\<ge>0\<^bsup> n  & j /\<^sub>\<rat> m = j/\<^bsub>\<rat>\<ge>0\<^bsup> m" using rat_1_div by mty auto
         hence "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (j /\<^bsub>\<rat>\<ge>0\<^bsup> m)" using real_0_def_7 
           Prat_Preal_mult by mty auto
         also have "... = (i*\<^sub>\<S>\<^sup>\<nat>j) /\<^bsub>\<rat>\<ge>0\<^bsup> (n*\<^sub>\<S>\<^sup>\<nat>m)" using arytm_3_th_49 by mty auto
         also have "... = (i*\<^sub>\<S>\<^sup>\<nat>j)  /\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m)" using rat_1_div by mty auto
         also have "... = (i*\<^sub>\<S>\<^sup>\<real>j)  /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" using int_1_def_5 by mty auto
         finally show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" by auto
       next
         case [ty]:False
         have [ty]: "(-\<^sub>\<S>\<^sup>\<real> (i *\<^sub>\<S>\<^sup>\<real> j)) be integer"
    "(n *\<^sub>\<S>\<^sup>\<nat> m) be natural" by mty auto
         have IJ: "i*\<^sub>\<S>\<^sup>\<nat>(-\<^sub>\<S>\<^sup>\<real> j) = -\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)" "(i*\<^sub>\<S>\<^sup>\<nat>(-\<^sub>\<S>\<^sup>\<real> j)) is Nat" using 
            int_1_def_5 real_0_th_42[of j i] by mty auto
         hence [ty]: "-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j) is Nat" by mty auto
         have [ty]:"(i /\<^sub>\<rat> n) is (Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
         have [ty]:"(j /\<^sub>\<rat> m) is (non Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
  have [ty]:"(i /\<^sub>\<rat> n) is (Element-of REAL\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]:"(j /\<^sub>\<rat> m) is (non Element-of REAL\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]: "((i /\<^sub>\<rat> n)) is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  by mty auto
             have [ty]: "(-\<^sub>\<S>\<^sup>\<real>(j /\<^sub>\<rat> m)) is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  by mty auto
          have "i /\<^sub>\<rat> n = i /\<^bsub>\<rat>\<ge>0\<^bsup> n  & j /\<^sub>\<rat> m = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> j) /\<^bsub>\<rat>\<ge>0\<^bsup> m))" using rat_1_div by mty auto
          hence "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (-\<^sub>\<S>\<^sup>\<real> ( (i /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> j) /\<^bsub>\<rat>\<ge>0\<^bsup> m)))))" 
            using real_0_def_7[of "i /\<^sub>\<rat> n" "j /\<^sub>\<rat> m",simplified] 
             Prat_Preal_mult[of "i /\<^sub>\<rat> n" "-\<^sub>\<S>\<^sup>\<real>(j /\<^sub>\<rat> m)",simplified]  by mty auto
          also have "... = (-\<^sub>\<S>\<^sup>\<real> ( (i /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( (-\<^sub>\<S>\<^sup>\<real> j) /\<^bsub>\<rat>\<ge>0\<^bsup> m)))" using real_0_th_20a by mty auto
          also have "... = (-\<^sub>\<S>\<^sup>\<real> ( (i*\<^sub>\<S>\<^sup>\<nat>(-\<^sub>\<S>\<^sup>\<real> j)) /\<^bsub>\<rat>\<ge>0\<^bsup> (n*\<^sub>\<S>\<^sup>\<nat>m) ))" using arytm_3_th_49 by mty auto
         also have "... = -\<^sub>\<S>\<^sup>\<real>  ((-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)) /\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m) )" using 
           rat_1_div[of "-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)" "n*\<^sub>\<S>\<^sup>\<nat>m",simplified] IJ  by mty auto
         also have "... = (-\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)))/\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m) " 
           using rat_1_cop_4[of "-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)" "n*\<^sub>\<S>\<^sup>\<nat>m",simplified]  NM1 by mty auto
         also have "... = (i *\<^sub>\<S>\<^sup>\<real> j)/\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m) " 
           using real_0_th_20a by mty auto
         finally show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" using int_1_def_5 by auto
       qed
     next
   case [ty]: False
    show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)"
    proof(cases "j is natural")
      case [ty]: True
         have [ty]: "(-\<^sub>\<S>\<^sup>\<real> (i *\<^sub>\<S>\<^sup>\<real> j)) be integer"
    by mty auto
         have IJ: "(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> j = -\<^sub>\<S>\<^sup>\<real> (i *\<^sub>\<S>\<^sup>\<real> j)" "((-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> j) is Nat" using 
            int_1_def_5 real_0_th_41[of j i] by mty auto
         hence [ty]: "-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j) is Nat" by mty auto
         have [ty]:"(i /\<^sub>\<rat> n) is (non Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
         have [ty]:"(j /\<^sub>\<rat> m) is (Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]:"(i /\<^sub>\<rat> n) is (non Element-of REAL\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]:"(j /\<^sub>\<rat> m) is (Element-of REAL\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]: "(-\<^sub>\<S>\<^sup>\<real>(i /\<^sub>\<rat> n)) is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  by mty auto
          have "j /\<^sub>\<rat> m = (j /\<^bsub>\<rat>\<ge>0\<^bsup> m)  & i /\<^sub>\<rat> n = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> n))" using rat_1_div by mty auto
          hence "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (-\<^sub>\<S>\<^sup>\<real> (  (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> n))) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (j /\<^bsub>\<rat>\<ge>0\<^bsup> m)))" 
            using real_0_def_7[of   "i /\<^sub>\<rat> n" "j /\<^sub>\<rat> m" ,simplified] 
            Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real>(i /\<^sub>\<rat> n)" "(j /\<^sub>\<rat> m)",simplified] by mty auto                       
          also have "... = (-\<^sub>\<S>\<^sup>\<real> ( ( (-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (j /\<^bsub>\<rat>\<ge>0\<^bsup> m)))" using real_0_th_20a by mty auto
          also have "... = (-\<^sub>\<S>\<^sup>\<real> ( ((-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> j) /\<^bsub>\<rat>\<ge>0\<^bsup> (n *\<^sub>\<S>\<^sup>\<nat> m) ))" using arytm_3_th_49 by mty auto
         also have "... = -\<^sub>\<S>\<^sup>\<real>  ((-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<nat> m) )" using 
           rat_1_div[of "-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)" "n*\<^sub>\<S>\<^sup>\<nat>m",simplified] IJ  by mty auto
         also have "... = (-\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)))/\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m) " 
           using rat_1_cop_4[of "-\<^sub>\<S>\<^sup>\<real>(i *\<^sub>\<S>\<^sup>\<real> j)" "n*\<^sub>\<S>\<^sup>\<nat>m",simplified]  NM1 by mty auto
         also have "... = (i *\<^sub>\<S>\<^sup>\<real> j)/\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m) " 
           using real_0_th_20a by mty auto
         finally show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" using int_1_def_5 by auto
       next 
         case [ty]: False
         have IJ: "(-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> j) = -\<^sub>\<S>\<^sup>\<real> (i *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j))" 
           "-\<^sub>\<S>\<^sup>\<real> (i *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)) = i *\<^sub>\<S>\<^sup>\<real> j" using int_1_def_5 real_0_th_41[of "-\<^sub>\<S>\<^sup>\<real> j" i] 
           real_0_th_41[of j i] real_0_th_22[of "i *\<^sub>\<S>\<^sup>\<real> j"] by mty auto
         have [ty]:"(i /\<^sub>\<rat> n) is (non Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
         have [ty]:"(j /\<^sub>\<rat> m) is (non Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]:"(i /\<^sub>\<rat> n) is (non Element-of REAL\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]:"(j /\<^sub>\<rat> m) is (non Element-of REAL\<^bsup>\<ge>0\<^bsub>)" by mty auto
          have [ty]: "(-\<^sub>\<S>\<^sup>\<real>(i /\<^sub>\<rat> n)) is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  by mty auto
             have [ty]: "(-\<^sub>\<S>\<^sup>\<real>(j /\<^sub>\<rat> m)) is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  by mty auto
        have "j /\<^sub>\<rat> m = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> j) /\<^bsub>\<rat>\<ge>0\<^bsup> m))  & i /\<^sub>\<rat> n = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> n))"
           using rat_1_div by mty auto
         hence "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> n))) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> j) /\<^bsub>\<rat>\<ge>0\<^bsup> m)))" 
           using real_0_def_7[of "i /\<^sub>\<rat> n" "j /\<^sub>\<rat> m",simplified] 
            Prat_Preal_mult[of "-\<^sub>\<S>\<^sup>\<real>(i /\<^sub>\<rat> n)" "-\<^sub>\<S>\<^sup>\<real>(j /\<^sub>\<rat> m)",simplified] by mty auto
         also have "... =  ((-\<^sub>\<S>\<^sup>\<real> i) /\<^bsub>\<rat>\<ge>0\<^bsup> n) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( (-\<^sub>\<S>\<^sup>\<real> j) /\<^bsub>\<rat>\<ge>0\<^bsup> m)"
            using real_0_th_20a by mty auto
         also have "... =   ((-\<^sub>\<S>\<^sup>\<real> i) *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> j)) /\<^bsub>\<rat>\<ge>0\<^bsup> (n*\<^sub>\<S>\<^sup>\<nat>m) " using arytm_3_th_49 by mty auto
         also have "... =  (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n*\<^sub>\<S>\<^sup>\<nat>m) " using 
           rat_1_div[of "i *\<^sub>\<S>\<^sup>\<real> j" "n*\<^sub>\<S>\<^sup>\<nat>m",simplified] IJ  by mty auto
         finally show "(i /\<^sub>\<rat> n) *\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> m) = (i *\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" using int_1_def_5 by auto
      qed
  qed
qed

mtheorem rat_1_th_44:
 "n<>{} & m <>{} \<longrightarrow> i /\<^sub>\<rat> n = (i *\<^sub>\<S>\<^sup>\<real> m) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)"
proof
  assume m: "n<>{} & m<>{}"
  hence "succ {} = m /\<^bsub>\<rat>\<ge>0\<^bsup> m" using arytm_3_th_41 by mty auto
  hence "succ {} = m /\<^sub>\<rat> m" using rat_1_div by mty auto
  hence "i /\<^sub>\<rat> n = (i /\<^sub>\<rat> n)  *\<^sub>\<S>\<^sup>\<real> (m /\<^sub>\<rat> m)" using rat_1_one by mty auto
  thus "i /\<^sub>\<rat> n = (i *\<^sub>\<S>\<^sup>\<real> m) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> m)" using m rat_1_th_14 by mty auto
qed

mtheorem rat_1_th_47:
 "n<>{}  \<longrightarrow> (i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = (i +\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> n"
proof
  assume N:"n<>{}"
  hence "(i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = ((i *\<^sub>\<S>\<^sup>\<real> n) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> n)) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> n)"
    using rat_1_th_12 by mty auto
  hence "(i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = ((i +\<^sub>\<S>\<^sup>\<real> j )*\<^sub>\<S>\<^sup>\<real> n ) /\<^sub>\<rat> (n *\<^sub>\<S>\<^sup>\<real> n)"
    using real_0_th_28 by mty auto
  thus "(i /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = (i +\<^sub>\<S>\<^sup>\<real> j ) /\<^sub>\<rat> n"
    using rat_1_th_44[of "i +\<^sub>\<S>\<^sup>\<real> j" n n ] N by mty auto
qed


mtheorem rat_1_th_15:
  "r+\<^sub>\<S>\<^sup>\<real> s = r \<longrightarrow> s={}"
proof
  assume "r+\<^sub>\<S>\<^sup>\<real> s = r"
  hence  "r+\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^sup>\<real> {}" using real_0_th_8[of r] by mauto
  thus "s ={}" using real_0_th_16[of "{}" s r] by mauto
qed




mtheorem rat_1_th_16:
  "r \<le>\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
proof
  assume AS: "r \<le>\<^sup>\<real> s  \<and> t \<le>\<^sup>\<real> w"
 then obtain rs where [ty]:"rs  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     rs: "s = r +\<^sub>\<S>\<^sup>\<real> rs" using rat_0_def_8 by mty auto
  obtain tw where [ty]:"tw  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     tw: "w = t +\<^sub>\<S>\<^sup>\<real> tw" using AS rat_0_def_8 by mty auto
  have "s+\<^sub>\<S>\<^sup>\<real> w = ((r +\<^sub>\<S>\<^sup>\<real> rs) +\<^sub>\<S>\<^sup>\<real>  t) +\<^sub>\<S>\<^sup>\<real> tw" using rs tw real_0_th_15[of tw t] by mty auto
  also have "...= (r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real>  t)) +\<^sub>\<S>\<^sup>\<real> tw" using  real_0_th_15[of t rs] by mty auto
  also have "... = (r +\<^sub>\<S>\<^sup>\<real> (t +\<^sub>\<S>\<^sup>\<real>  rs)) +\<^sub>\<S>\<^sup>\<real> tw" using  real_0_th_11 by mty auto
  also have "... = ((r +\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real>  rs) +\<^sub>\<S>\<^sup>\<real> tw" using  real_0_th_15 by mty auto
  also have "... = (r +\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real>  (rs +\<^sub>\<S>\<^sup>\<real> tw)" using  real_0_th_15[of tw rs] by mty auto
  finally show "r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using rat_0_def_8[of "r+\<^sub>\<S>\<^sup>\<real> t" "s+\<^sub>\<S>\<^sup>\<real> w"]
   bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> tw" "Element-of RAT\<^bsup>\<ge>0\<^bsub>",simplified] by mty auto
qed

mtheorem rat_0_def_8l:
  " r <\<^sup>\<real> w \<longleftrightarrow> (ex z be Element-of RAT\<^bsup>\<ge>0\<^bsub> st z<>{} & w = r +\<^sub>\<S>\<^sup>\<real> z)"
proof
  assume "r <\<^sup>\<real> w"
  hence r: "r <> w & r \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  then obtain z where [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   z:  "w = r +\<^sub>\<S>\<^sup>\<real> z" using rat_0_def_8 by mty auto
  hence "z <>{}" using r real_0_th_8 by mty auto
  thus "ex z be Element-of RAT\<^bsup>\<ge>0\<^bsub> st z<>{} & w = r +\<^sub>\<S>\<^sup>\<real> z" 
    using z bexI[of _ z "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
next
  assume  "ex z be Element-of RAT\<^bsup>\<ge>0\<^bsub> st z<>{} & w = r +\<^sub>\<S>\<^sup>\<real> z" 
  then obtain z where [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   z:  "z <>{} & w = r +\<^sub>\<S>\<^sup>\<real> z" by mty auto
  hence "r \<le>\<^sup>\<real> w" "w<>r" using bexI[of _ z] rat_0_def_8 rat_1_th_15[of z r] by mty auto
  thus "r <\<^sup>\<real> w" using real_0_th_33 by mty auto
qed

mtheorem rat_0_def_8t1:
  "r \<le>\<^sup>\<real> s \<and> s <\<^sup>\<real> t implies r <\<^sup>\<real> t"
proof
  assume AS: "r \<le>\<^sup>\<real> s \<and> s <\<^sup>\<real> t"
  then obtain rs where [ty]:"rs  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     rs: "s = r +\<^sub>\<S>\<^sup>\<real> rs" using rat_0_def_8 by mty auto
  obtain ST where [ty]:"ST  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     st: "ST<>{} & t = s +\<^sub>\<S>\<^sup>\<real> ST" using AS rat_0_def_8l by mty auto
  have "rs +\<^sub>\<S>\<^sup>\<real> ST = ST +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rs" using real_0_def_4 Prat_Preal_add real_0_th_11 by mty auto
  hence "t = r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real> ST)" "rs +\<^sub>\<S>\<^sup>\<real> ST <>{}"
       using rs st real_0_th_15 st arytm_3_th_63[of rs ST] by mty auto
  thus "r <\<^sup>\<real> t" using bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> ST"] rat_0_def_8l[of r t] by mty auto
qed

mtheorem rat_0_def_8t2:
  "r <\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t implies r <\<^sup>\<real> t"
proof
  assume AS: "r <\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t"
  then obtain rs where [ty]:"rs  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     rs: "rs<>{} & s = r +\<^sub>\<S>\<^sup>\<real> rs" using rat_0_def_8l by mty auto
  obtain ST where [ty]:"ST  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     st: " t = s +\<^sub>\<S>\<^sup>\<real> ST" using AS rat_0_def_8 by mty auto
  have "rs +\<^sub>\<S>\<^sup>\<real> ST = rs +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ST" using real_0_def_4 Prat_Preal_add real_0_th_11 by mty auto
  hence "t = r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real> ST)" "rs +\<^sub>\<S>\<^sup>\<real> ST <>{}"
       using rs st real_0_th_15 st arytm_3_th_63[of ST] by mty auto
  thus "r <\<^sup>\<real> t" using bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> ST"] rat_0_def_8l[of r t] by mty auto
qed


mtheorem
  mlet "r be Rat", "s be Rat"
  "cluster r -\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Rat"
proof
  have "r -\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)" using real_0_def_6 by mty auto
  thus "r -\<^sub>\<S>\<^sup>\<real> s is Rat" by mty auto
qed


mtheorem rat_1_th_17:
   "r \<le>\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real>  s -\<^sub>\<S>\<^sup>\<real> t"
proof
  assume AS:"r \<le>\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w"
  hence "(-\<^sub>\<S>\<^sup>\<real> w) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> t)" using real_0_th_30 by mty auto
  hence "r+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w) \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> t)" using rat_1_th_16 AS by mty auto
  thus "r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real>  s -\<^sub>\<S>\<^sup>\<real> t" using real_0_def_6 by mty auto
qed 

mtheorem rat_1_th_18:
  "w -\<^sub>\<S>\<^sup>\<real> w ={}"
proof-
  have "w -\<^sub>\<S>\<^sup>\<real> w = w +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w)" using real_0_def_6 by mty auto
  also have "... =  (-\<^sub>\<S>\<^sup>\<real> w) +\<^sub>\<S>\<^sup>\<real> w" using real_0_th_11 by mty auto
  finally show ?thesis using real_0_def_5 by mty auto 
qed

mtheorem rat_1_th_19:
  "(r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w = r" 
proof-
  have "(r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w = (r +\<^sub>\<S>\<^sup>\<real> w) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w)" using real_0_def_6 by mty auto
  also have "... = r +\<^sub>\<S>\<^sup>\<real> (w +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w))" using real_0_th_15 by mty auto
  also have "... = r +\<^sub>\<S>\<^sup>\<real> (w -\<^sub>\<S>\<^sup>\<real> w)" using real_0_def_6 by mty auto
  also have "... = r +\<^sub>\<S>\<^sup>\<real> {}" using rat_1_th_18 by mty auto
  finally show ?thesis using real_0_th_8 by mty auto 
qed


mtheorem rat_1_th_16l:
  "r <\<^sup>\<real> s \<and> t <\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
proof
  have r: "r \<le>\<^sup>\<real> r" "w \<le>\<^sup>\<real> w" using real_0_def_8r by mty auto
  assume AS: "r <\<^sup>\<real> s  \<and> t <\<^sup>\<real> w"
  hence as: "r \<le>\<^sup>\<real> s" "t \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  hence "r +\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> w" using r rat_1_th_16 by mty auto
  hence H1: "(r +\<^sub>\<S>\<^sup>\<real> t) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using r rat_1_th_17 by mty auto
  have h1:"r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using rat_1_th_16 as by mty auto  
 have  "r+\<^sub>\<S>\<^sup>\<real> t <>  s+\<^sub>\<S>\<^sup>\<real> w"
  proof
    assume "r+\<^sub>\<S>\<^sup>\<real> t =  s+\<^sub>\<S>\<^sup>\<real> w"
    hence "(s +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using H1 by mty auto
    hence "s \<le>\<^sup>\<real> r" using rat_1_th_19 by mty auto
    thus False using AS by mty auto
  qed
  thus "r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_0_th_33[of "r+\<^sub>\<S>\<^sup>\<real> t" "s+\<^sub>\<S>\<^sup>\<real> w"] h1 by mty auto
qed

mtheorem rat_1_th_16l2:
  "r <\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
proof
  have r: "r \<le>\<^sup>\<real> r" "w \<le>\<^sup>\<real> w" using real_0_def_8r by mty auto
  assume AS: "r <\<^sup>\<real> s  \<and> t \<le>\<^sup>\<real> w"
  hence as: "r \<le>\<^sup>\<real> s" "t \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  hence "r +\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> w" using r rat_1_th_16 by mty auto
  hence H1: "(r +\<^sub>\<S>\<^sup>\<real> t) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using r rat_1_th_17 by mty auto
  have h1:"r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using rat_1_th_16 as by mty auto  
 have  "r+\<^sub>\<S>\<^sup>\<real> t <>  s+\<^sub>\<S>\<^sup>\<real> w"
  proof
    assume "r+\<^sub>\<S>\<^sup>\<real> t =  s+\<^sub>\<S>\<^sup>\<real> w"
    hence "(s +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using H1 by mty auto
    hence "s \<le>\<^sup>\<real> r" using rat_1_th_19 by mty auto
    thus False using AS by mty auto
  qed
  thus "r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_0_th_33[of "r+\<^sub>\<S>\<^sup>\<real> t" "s+\<^sub>\<S>\<^sup>\<real> w"] h1 by mty auto
qed

mtheorem rat_1_th_16l1:
  "r \<le>\<^sup>\<real> s \<and> t <\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
  using real_0_th_11 rat_1_th_16l2[of s r  t w] by mty auto

mtheorem rat_1_th_20:
  "r +\<^sub>\<S>\<^sup>\<real> s \<le>\<^sup>\<real> w \<longrightarrow> r \<le>\<^sup>\<real> w -\<^sub>\<S>\<^sup>\<real> s"
proof
  have r: "s \<le>\<^sup>\<real> s" using real_0_def_8r by mty auto
  assume "r +\<^sub>\<S>\<^sup>\<real> s \<le>\<^sup>\<real> w"
  hence "(r +\<^sub>\<S>\<^sup>\<real> s) -\<^sub>\<S>\<^sup>\<real> s \<le>\<^sup>\<real> w -\<^sub>\<S>\<^sup>\<real> s"  using r rat_1_th_17 by mty auto 
  thus "r \<le>\<^sup>\<real> w -\<^sub>\<S>\<^sup>\<real> s" using rat_1_th_19 by mty auto
qed

mtheorem rat_1_th_21:
  "r \<le>\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> w \<longrightarrow> r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s"
proof
  have r: "w \<le>\<^sup>\<real> w" using real_0_def_8r by mty auto
  assume "r \<le>\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> w"
  hence "r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (s +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w"  using r rat_1_th_17 by mty auto 
  thus "r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s" using rat_1_th_19 by mty auto
qed

mtheorem rat_1_th_22:
 "-\<^sub>\<S>\<^sup>\<real> (r -\<^sub>\<S>\<^sup>\<real> s) = s -\<^sub>\<S>\<^sup>\<real> r"
proof-
  have "-\<^sub>\<S>\<^sup>\<real> (r -\<^sub>\<S>\<^sup>\<real> s) =( -\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)))" using real_0_def_6 by mty auto
  also have "... = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s))" using real_0_th_20 by mty auto
  also have "... = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> s" using real_0_th_20a by mty auto
  also have "... = s +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)" using real_0_th_11 by mty auto
  finally show ?thesis using real_0_def_6 by mty auto
qed

mtheorem rat_1_th_47m:
 "n<>{}  \<longrightarrow> (i /\<^sub>\<rat> n)  -\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = (i +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)) /\<^sub>\<rat> n"
proof
  assume N: "n<>{}"
  have "(i /\<^sub>\<rat> n)  -\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = (i /\<^sub>\<rat> n)  +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n))" using real_0_def_6 by mty auto
  also have "... = (i /\<^sub>\<rat> n)  +\<^sub>\<S>\<^sup>\<real> ( (-\<^sub>\<S>\<^sup>\<real> j) /\<^sub>\<rat> n)" using rat_1_cop_4 N by mty auto
  finally show "(i /\<^sub>\<rat> n)  -\<^sub>\<S>\<^sup>\<real> (j /\<^sub>\<rat> n) = (i +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> j)) /\<^sub>\<rat> n" using rat_1_th_47 N by mty auto
qed


mtheorem rat_1_th_23:
 "n<>{} \<and> n1 \<subseteq> n2 \<longrightarrow>( n1 /\<^sub>\<rat> n)  \<le>\<^sup>\<real> (n2 /\<^sub>\<rat> n)"
proof
  assume N: "n<>{} \<and> n1 \<subseteq> n2"
  then obtain k where [ty]:"k be Nat" and
   K: "n2 = n1 +\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by mty auto
  hence "n2 = n1 +\<^sub>\<S>\<^sup>\<real> k" using int_1_def_3[of n1 k] by mty auto
  hence A1: "(n1 /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (k /\<^sub>\<rat> n) = (n2) /\<^sub>\<rat> n"using rat_1_th_47[of k n1 n ]  N by mty auto
  have "(k /\<^bsub>\<rat>\<ge>0\<^bsup> n) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
  hence [ty]:"(k /\<^sub>\<rat> n) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_1_div by mty auto
  show "( n1 /\<^sub>\<rat> n)  \<le>\<^sup>\<real> (n2 /\<^sub>\<rat> n)" using A1 rat_0_def_8 bexI[of _ "k /\<^sub>\<rat> n"] by mty auto
qed

mtheorem rat_1_th_24:
 "n<>{} \<and> n1 in n2 \<longrightarrow>( n1 /\<^sub>\<rat> n)  <\<^sup>\<real> (n2 /\<^sub>\<rat> n)"
proof
  assume N: "n<>{} \<and> n1 in n2"
  then obtain k where [ty]:"k be Nat" and
   K: "k<>{} & n2 = n1 +\<^sub>\<S>\<^sup>\<nat> k" using Add_8 by mty auto
  hence "n2 = n1 +\<^sub>\<S>\<^sup>\<real> k" using int_1_def_3[of n1 k] by mty auto
  hence A1: "(n1 /\<^sub>\<rat> n) +\<^sub>\<S>\<^sup>\<real> (k /\<^sub>\<rat> n) = (n2) /\<^sub>\<rat> n"using rat_1_th_47[of k n1 n ]  N by mty auto


  have "k /\<^sub>\<rat> n = k /\<^bsub>\<rat>\<ge>0\<^bsup> n" using rat_1_div by mty auto

  have A2:"k /\<^sub>\<rat> n<>{}"
  proof
    assume "k /\<^sub>\<rat> n={}"
    hence "k /\<^bsub>\<rat>\<ge>0\<^bsup> n = {} /\<^bsub>\<rat>\<ge>0\<^bsup> n" using arytm_3_th_40[of n] rat_1_div by mty auto
    hence "k *\<^sub>\<S>\<^sup>\<nat> n =\<^sub>\<S> {}" using arytm_3_th_45[of "{}" k n n] K N Mult_2[of n]by mty auto
    thus False using Mult_9[of n k] N K by mty auto

  qed
  have "(k /\<^bsub>\<rat>\<ge>0\<^bsup> n) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
  hence [ty]:"(k /\<^sub>\<rat> n) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_1_div by mty auto
  show "( n1 /\<^sub>\<rat> n)  <\<^sup>\<real> (n2 /\<^sub>\<rat> n)" using A1 rat_0_def_8l bexI[of _ "k /\<^sub>\<rat> n"] A2 by mty auto
qed

mtheorem nat_1_th_13:
  "n1 <\<^sup>\<real> n2 \<longrightarrow> n1 +\<^sub>\<S>\<^sup>\<real> 1\<^sub>\<S> \<le>\<^sup>\<real> n2"
proof
  assume "n1 <\<^sup>\<real> n2"
  then obtain z where [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     A1:"z<>{} & n2 = n1 +\<^sub>\<S>\<^sup>\<real> z" using rat_0_def_8l[of n1 n2] by mty auto
  have A2: "n1 +\<^sub>\<S>\<^sup>\<real> z= n1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" "n1 in NAT" "n2 in NAT" 
    using real_0_def_4 ordinal1_def_12[of n1] ordinal1_def_12[of n2] Prat_Preal_add by mty auto
  hence "z in NAT" using arytm_3_th_71[of z n1] A1 by auto
  hence [ty]: "z is Nat" using ordinal1_def_12[of z] by auto 
  let ?p="predecessor z"
  have "z = succ predecessor z" using A1 predec by auto
  hence "z = 1\<^sub>\<S> +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?p" using Add_5[of ?p] arytm_3_th_58  by mty auto
  hence "n2 = (n1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?p" using A2 A1 arytm_3_th_51[of ?p "1\<^sub>\<S>" n1] by mty auto
 hence "n2 = (n1 +\<^sub>\<S>\<^sup>\<real> 1\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> ?p" using real_0_def_4 Prat_Preal_add by mty auto
  thus "n1 +\<^sub>\<S>\<^sup>\<real> 1\<^sub>\<S> \<le>\<^sup>\<real> n2" using rat_0_def_8 bexI[of _ ?p] by mty auto
qed



theorem rat_1_th_25:
  "r is Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> 
   ex n be Nat st r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n & n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>"
proof-
  assume [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  let ?n = "numerator(r)"
  let ?d = "denominator(r)"
  have d:"?d<>{}" using arytm_3_th_35 by mty auto
  have A1: "r = ?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d" "1\<^sub>\<S> = ?d /\<^bsub>\<rat>\<ge>0\<^bsup> ?d " 
     using arytm_3_th_39 arytm_3_th_41[of ?d] d by mty auto
   hence A2: "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> = (?n +\<^sub>\<S>\<^sup>\<nat> ?d)/\<^bsub>\<rat>\<ge>0\<^bsup> ?d" 
     using arytm_3_th_47[of ?d ?n ?d] d by mty auto

  show "ex n be Nat st r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n & n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>"
  proof(cases "r is Nat")
    case [ty]:True
    hence " r c= r" "r in r +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" using ordinal1_th_2 Add_5[of r] 
      xboole_0_def_10[of r r] by mty auto 
    hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" 
      using arytm_3_TH1[of r r] arytm_3_TH1e[of r "r +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>"] by mty auto
    thus "ex n be Nat st r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n & n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" 
      using arytm_3_th_58[of "1\<^sub>\<S>" r] bexI[of _ r Nat] by mty auto
  next
    case F: False
    hence "r <>{}" by mty auto
    hence N:"?n <> {}" using arytm_3_th_37 by mty auto
    then obtain d m where [ty]:"m is Nat" "d is Nat" and
       dm: " ?n =\<^sub>\<S> d *\<^sub>\<S>\<^sup>\<nat> ?d +\<^sub>\<S>\<^sup>\<nat> m \<and> m in ?d" 
      using div_8[of ?n ?d] d by mty auto
    obtain R where [ty]:"R is Nat" and 
      R:"R <>{} & ?d = m+\<^sub>\<S>\<^sup>\<nat> R" using dm Add_8 by mty auto
    have m: "m<>{}"
    proof
        assume "m={}"
      hence "?n =\<^sub>\<S> d *\<^sub>\<S>\<^sup>\<nat> ?d" using Add_3 dm by mty auto
      hence "r = (d *\<^sub>\<S>\<^sup>\<nat> ?d) /\<^bsub>\<rat>\<ge>0\<^bsup>  ((succ {}) *\<^sub>\<S>\<^sup>\<nat> ?d)" 
        using A1 Mult_5[of ?d] by mty auto
      also have "... = (d /\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?d /\<^bsub>\<rat>\<ge>0\<^bsup> ?d)" 
        using arytm_3_th_49 by mty auto
      also have "... = (d ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" 
        using arytm_3_th_40[of d d] arytm_3_th_41[of ?d] d by mty auto
      finally have "r=d" using arytm_3_th_53 by mty auto
      thus False using F by mty auto
    qed
    have nr: " ?n +\<^sub>\<S>\<^sup>\<nat> R = d *\<^sub>\<S>\<^sup>\<nat> ?d +\<^sub>\<S>\<^sup>\<nat> (m +\<^sub>\<S>\<^sup>\<nat> R)" 
        using dm Add_7[of R m "d *\<^sub>\<S>\<^sup>\<nat> ?d"] by mty auto
    hence " (?n +\<^sub>\<S>\<^sup>\<nat> R) +\<^sub>\<S>\<^sup>\<nat> m = (d *\<^sub>\<S>\<^sup>\<nat> ?d +\<^sub>\<S>\<^sup>\<nat> ?d) +\<^sub>\<S>\<^sup>\<nat> m" 
        using  R  by mty auto
    also have "... = d *\<^sub>\<S>\<^sup>\<nat> ?d +\<^sub>\<S>\<^sup>\<nat> (?d +\<^sub>\<S>\<^sup>\<nat> m)"
      using  Add_7[of m ?d "d *\<^sub>\<S>\<^sup>\<nat> ?d"] by mty auto
    also have "... = d *\<^sub>\<S>\<^sup>\<nat> ?d +\<^sub>\<S>\<^sup>\<nat> (m +\<^sub>\<S>\<^sup>\<nat> ?d)"
      using  Add_6[of m ?d ] by mty auto
    also have "... = ?n +\<^sub>\<S>\<^sup>\<nat> ?d"
      using  Add_7[of ?d m "d *\<^sub>\<S>\<^sup>\<nat> ?d"] dm by mty auto
    finally have "?n +\<^sub>\<S>\<^sup>\<nat> R in ?n +\<^sub>\<S>\<^sup>\<nat> ?d" 
      using Add_8[of "?n +\<^sub>\<S>\<^sup>\<nat> ?d" "?n +\<^sub>\<S>\<^sup>\<nat> R"] m bexI[of _ m Nat]
      by mty auto
    hence "(?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^sub>\<rat> ?d <\<^sup>\<real> (?n +\<^sub>\<S>\<^sup>\<nat> ?d)  /\<^sub>\<rat>  ?d"
      using rat_1_th_24[of "?n +\<^sub>\<S>\<^sup>\<nat> ?d" "?n +\<^sub>\<S>\<^sup>\<nat> R" ?d] d 
      by mty auto
    hence Y1: "(?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^bsub>\<rat>\<ge>0\<^bsup> ?d <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>"
      using rat_1_div rat_0_th_29 A2 by mty auto
   
    have "?n \<subseteq> ?n +\<^sub>\<S>\<^sup>\<nat> R" using Add_9[of "?n +\<^sub>\<S>\<^sup>\<nat> R" ?n]
     bexI[of _ R Nat] by mty auto
    hence "?n /\<^sub>\<rat> ?d \<le>\<^sup>\<real> (?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^sub>\<rat> ?d" 
      using rat_1_th_23[of "?n +\<^sub>\<S>\<^sup>\<nat> R" ?n ?d] d by mty auto 
    hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^bsub>\<rat>\<ge>0\<^bsup> ?d" 
      using  rat_1_div rat_0_th_29 A1 by mty auto 

    have "?n +\<^sub>\<S>\<^sup>\<nat> R = (succ d) *\<^sub>\<S>\<^sup>\<nat> ?d " using nr R Mult_4 by mty auto
    hence "(?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^bsub>\<rat>\<ge>0\<^bsup> ?d = ((succ d) *\<^sub>\<S>\<^sup>\<nat> ?d) /\<^bsub>\<rat>\<ge>0\<^bsup>  ((succ {}) *\<^sub>\<S>\<^sup>\<nat> ?d)" 
        using A1 Mult_5[of ?d] by mty auto
      also have "... = ((succ d) /\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?d /\<^bsub>\<rat>\<ge>0\<^bsup> ?d)" 
        using arytm_3_th_49 by mty auto
      also have "... = (succ d ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" 
        using arytm_3_th_40[of "succ d" "succ d"] arytm_3_th_41[of ?d] d by mty auto
      finally have [ty]: "((?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^bsub>\<rat>\<ge>0\<^bsup> ?d) is Nat" using arytm_3_th_53 by mty auto
      have "?n \<subseteq> ?n +\<^sub>\<S>\<^sup>\<nat> R" using Add_9[of "?n +\<^sub>\<S>\<^sup>\<nat> R" ?n]
     bexI[of _ R Nat] by mty auto
    hence "?n /\<^sub>\<rat> ?d \<le>\<^sup>\<real> (?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^sub>\<rat> ?d" 
      using rat_1_th_23[of "?n +\<^sub>\<S>\<^sup>\<nat> R" ?n ?d] d by mty auto 
    hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^bsub>\<rat>\<ge>0\<^bsup> ?d" 
      using  rat_1_div rat_0_th_29 A1 by mty auto  
    thus "ex n be Nat st r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n & n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" 
      using Y1  bexI[of _ "(?n +\<^sub>\<S>\<^sup>\<nat> R) /\<^bsub>\<rat>\<ge>0\<^bsup> ?d" Nat] by mty auto

  qed 
qed

mtheorem rat_real:
  "cluster rational \<rightarrow> Mreal for object" 
proof(standard, intro ballI impI)
  fix x assume [ty]: "x be rational"
  show "x is Mreal"
  proof(cases "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True
      thus "x is Mreal" by mty auto
  next
    case False
    then obtain k where [ty]:"k is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     K:" k \<noteq> {} \<and> x =\<^sub>\<S> [{} , k]" using  rat_0_th_7[of x] by mty auto
    hence "ex k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k]" using bexI[of _ k] by mty auto
    thus "x is Mreal" using real_0_th_7 by mty auto
  qed
qed mauto

end
