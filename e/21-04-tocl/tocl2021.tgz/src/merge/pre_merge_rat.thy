theory pre_merge_rat
  imports "../mml/real_0" 
begin

reserve n,m,k for "Element-of RAT\<^bsup>\<ge>0\<^bsub>"

mtheorem rat_0_th_1:
  "(n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k) = m implies m --R n = k"
proof(standard)
  assume A: "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m"
  hence "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m" using Prat_Preal_add by mty auto
  then show "m--Rn = k" using real_0_th_1 by auto
qed

mtheorem rat_0_th_2:
  "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k = {} implies n --R m = {}"
proof
  assume A1: "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k = {}"
  hence "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m" using Prat_Preal_add by mty auto
  then show "n --R m = {}" using A1 real_0_th_2[of m k n] by mty auto
qed

mtheorem rat_0_th_3:
  "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k<>{} implies n --R m = [{},k]"
proof
  assume A1: "n +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k<>{}"
  hence "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m" using Prat_Preal_add by mty auto
 then show "n--Rm = [{},k]" using real_0_th_3 A1  by auto
qed

mtheorem rat_0_th_4:
  "n --R m is Element-of RAT\<^bsup>\<ge>0\<^bsub> iff m \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n"
proof (standard,rule aaI)
  assume A1: "n--Rm is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "not m \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n"
  hence "n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m" by auto
  then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A2: "k<>{} & n+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k=m " using arytm_3_def_13l by auto 
  hence "n--Rm = [{},k]" using rat_0_th_3 by auto
  then show False using A1 arytm_3_th_33d[of k] A2  by mty auto
next 
  assume "m \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n"
  then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A2:"(m+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k)=n " using arytm_3_def_13 by auto 
  hence "n--Rm =k" using rat_0_th_1 by auto
  then show "n--Rm is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by simp
qed

text_raw {*\DefineSnippet{RAT}{*}
mdef numbers_def_3 ("RAT") where
 "func RAT \<rightarrow> set equals 
     RAT\<^bsup>\<ge>0\<^bsub>\<union>[:{0\<^sub>\<S>},RAT\<^bsup>\<ge>0\<^bsub>:] \\ {[0\<^sub>\<S>,0\<^sub>\<S>]}" 
text_raw {*}%EndSnippet*}
  by auto

mtheorem 
  "cluster RAT \<rightarrow> non empty"
proof
  have "{} is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto 
  hence "{} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" "{}"] by mauto
  then show "RAT is non empty" unfolding numbers_def_3 using xboole_0_def_3 xboole_0_def_1 by mty auto
qed

mdef rat_0_def_3 ("rational") where
  "attr rational for object means (\<lambda>it . it in RAT)"..

mtheorem
  "cluster rational for object"
proof
  have "{} is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto 
  hence "{} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
  hence "{} in RAT" unfolding numbers_def_3 using xboole_0_def_3 by mty auto
  thus "inhabited(rational \<bar> object)" using inhabited_def rat_0_def_3 by auto
qed



abbreviation
  "Rat \<equiv> rational\<bar>object"

mtheorem cl_nat_int:
  "cluster Element-of RAT\<^bsup>\<ge>0\<^bsub> \<rightarrow> rational for object"
proof(auto)
  fix it assume [ty]:"it be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  hence "it in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" it] by mauto
  hence "it in RAT" unfolding numbers_def_3 using xboole_0_def_3 all_set by auto 
  then show "it be rational" using rat_0_def_3 by auto
qed

reserve x for object 

mtheorem rat_0_th_7:
  "x is Rat iff x is Element-of RAT\<^bsup>\<ge>0\<^bsub> or (ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k])" 
proof(rule iffI3)
  show "x is Rat implies x is Element-of RAT\<^bsup>\<ge>0\<^bsub> or (ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k])"
  proof(standard,rule disjCI2)
    assume A1: "x is Rat"  "\<not> x be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
    hence "x in RAT" "\<not> x in RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_def_3[of x] 
        Element(1) all_set by mty auto
    hence A2: "x in [:{ {} },RAT\<^bsup>\<ge>0\<^bsub>:] & not x in { [{},{}] }" unfolding numbers_def_3 using xboole_0_def_3
       xboole_0_def_5 by mty auto
    then obtain y z where
       A3: "y in {{}} & z in RAT\<^bsup>\<ge>0\<^bsub> & x=[y,z]" using zfmisc_1_def_2 by mty auto
    hence [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) all_set by auto
    have A4: "y = {}" "not x = [{},{}]" using A2 A3 tarski_def_1 by auto
    hence "not z = {}" using A3 xtuple_0_th_1[of y z] by auto
    then show "ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k]" using A3 A4 
bexI[of _ z "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by auto
  qed
  assume A1: "x be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<or> (\<exists>k : Element-of RAT\<^bsup>\<ge>0\<^bsub>. k \<noteq> {} \<and> x = [{} , k])"
  show "x is Rat"
  proof(cases "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>")
    case True
    hence "x in RAT\<^bsup>\<ge>0\<^bsub>" using Element(1)[of "RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
    hence "x in RAT" unfolding  numbers_def_3 using xboole_0_def_3 by mty auto
    thus "x is Rat" using rat_0_def_3 by mty auto
  next
    case False
    then obtain k where [ty]: "k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
       A2:"k\<noteq>{} \<and> x = [{},k]" using A1 by auto
    hence "x\<noteq> [{},{}]" using xtuple_0_th_1[of "{}" "{}" "{}" k] by mty auto 
    hence A3: "not x in {[{},{}]}" using tarski_def_1 by auto
    have "{} in {{}} & k in RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1  Element(1)[of "RAT\<^bsup>\<ge>0\<^bsub>" k] by mty auto
    hence "x in [:{{}},RAT\<^bsup>\<ge>0\<^bsub>:]" using zfmisc_1_def_2 A2 by mty auto
    hence "x in [:{{}},RAT\<^bsup>\<ge>0\<^bsub>:]\\{[{},{}]}" using A3 xboole_0_def_5 by mty auto
    hence "x in RAT" unfolding numbers_def_3 using xboole_0_def_3 by mty auto  
    thus "x is Rat" using rat_0_def_3 by mty auto
  qed
qed


mtheorem 
  "cluster rational \<rightarrow> Mreal for object"
proof(standard,auto)
  fix x assume [ty]: "x be rational"
  show "x is Mreal"
  proof(cases "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True
    hence "x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
    thus "x is Mreal" using real_0_th_7 by mty auto
  next
    case False
    then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      " k\<noteq>{} & x = [{},k]" using rat_0_th_7[of x] by mty auto
    hence "ex k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k]" using bexI[of _k] by mty auto
     thus "x is Mreal" using real_0_th_7 by mty auto
  qed
qed

mtheorem pair_int:
  "k<>{} implies [{},k] is Rat"
proof
  assume "k<>{}"
  hence "ex n be Element-of RAT\<^bsup>\<ge>0\<^bsub> st n\<noteq>{} & [{},k] = [{},n]" using bexI[of _ k "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
  then show "[{},k] is Rat" using rat_0_th_7 by auto
qed

reserve k,k1,k2 for "Element-of RAT\<^bsup>\<ge>0\<^bsub>"  

reserve r,s,r1,r2,r3,t,w for Rat

mtheorem
   mlet "r be Element-of RAT\<^bsup>\<ge>0\<^bsub>", "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
   "cluster r +\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof
  have "r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = r +\<^sub>\<S>\<^sup>\<real> s   " using real_0_def_4 by mauto
  hence "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using Prat_Preal_add by mauto
  thus "r +\<^sub>\<S>\<^sup>\<real> s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
qed

mtheorem
   mlet "r be Element-of RAT\<^bsup>\<ge>0\<^bsub>", "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
   "cluster r --R s \<rightarrow> Rat"
proof(standard,cases "s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r")
  case T: True
  hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_2_lm_14 by mty auto
  then obtain z where [ty]:" z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
    and "r = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_def_13 by mty auto
  hence "r = s +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using Prat_Preal_add by mty auto
  hence "r --R s =z" using real_0_th_1 by mty auto
  thus "r --R s is Rat" by mty auto
next
  case F:False
  hence "not s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_2_lm_14 by mty auto
  then obtain z where [ty]:" z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
    and Z: "s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z & z<>{}" using arytm_3_def_13l by mty auto
  hence  "s = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using Prat_Preal_add by mty auto
  hence "r --R s =[{},z]" using Z real_0_th_3 by mty auto
  hence "ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & r --R s = [{},k]" 
    using rat_0_th_7 bexI[of _ z] Z by mty auto
  thus "r --R s is Rat" using rat_0_th_7 by mty auto
qed

mtheorem
  mlet "r be Rat", "s be Rat"
  "cluster r +\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Rat"
proof
  show "r +\<^sub>\<S>\<^sup>\<real> s is Rat"
  proof(cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True
        show "r +\<^sub>\<S>\<^sup>\<real> s is Rat"
          proof(cases "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
            case [ty]:True
            thus "r +\<^sub>\<S>\<^sup>\<real> s is Rat" by mty auto
          next
            case False
            then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
              K: " k\<noteq>{} & s = [{},k]" using rat_0_th_7[of s] by mty auto
            hence [ty]: "not s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto
            have  H: "r +\<^sub>\<S>\<^sup>\<real> s =r --R k" using real_0_def_4[of r s,simplified] K by mty auto
            thus "r +\<^sub>\<S>\<^sup>\<real> s is Rat" by mty auto
          qed
        next
    case False
    then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      K:" k\<noteq>{} & r = [{},k]" using rat_0_th_7[of r] by mty auto
    hence [ty]: "not r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto
 show "r +\<^sub>\<S>\<^sup>\<real> s is Rat"
          proof(cases "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
            case [ty]:True
            have  H: "r +\<^sub>\<S>\<^sup>\<real> s =s --R k" using real_0_def_4[of r s,simplified] K by mty auto
            thus "r +\<^sub>\<S>\<^sup>\<real> s is Rat" by mty auto           
          next
            case False
            then obtain l where [ty]:"l be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
              L: " l\<noteq>{} & s = [{},l]" using rat_0_th_7[of s] by mty auto
            hence [ty]: "not s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto

            have  "r +\<^sub>\<S>\<^sup>\<real> s =[{},k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> l]" using real_0_def_4[of r s,simplified] K L by mty auto
            hence  H: "r +\<^sub>\<S>\<^sup>\<real> s =[{},k +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> l]" "k +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> l<>{}" 
              using Prat_Preal_add arytm_3_th_63[of l k] K L by mty auto
            hence "ex k be Element-of RAT\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & r +\<^sub>\<S>\<^sup>\<real> s = [{},k]" 
                using rat_0_th_7 bexI[of _ "k +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> l"] by mty auto
              thus "r +\<^sub>\<S>\<^sup>\<real> s is Rat" using rat_0_th_7 by mty auto
          qed
        qed
qed



mtheorem rat_0_th_10:
  "ex s st r +\<^sub>\<S>\<^sup>\<real> s = {} & s +\<^sub>\<S>\<^sup>\<real> r = {}"
proof(cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
  case [ty]: True
    show "ex s st r +\<^sub>\<S>\<^sup>\<real> s = {} & s +\<^sub>\<S>\<^sup>\<real> r = {}"
    proof(cases "r={}")
      case True
      then show ?thesis using real_0_th_8[of r] bexI[of _ "{}" Rat] by mty auto
    next case F: False
      hence [ty]:"[{} , r] be rational" using pair_int by mty auto
      hence " r +\<^sub>\<S>\<^sup>\<real> [{},r] = {} & [{},r] +\<^sub>\<S>\<^sup>\<real> r = {}" using real_0_th_9[of r,simplified] F by mty auto
      then show ?thesis using bexI[of _ "[{},r]" Rat,simplified] by auto
    qed
  next 
    case False
    then obtain k where [ty]: "k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      A1: "k<>{} & r=[{},k]" using rat_0_th_7[of r] by mty auto
    have [ty]: "k be rational" by mty auto
    hence [ty]:"[{} , k] be rational" using pair_int A1 by mty auto
    hence " k +\<^sub>\<S>\<^sup>\<real> [{},k] = {} & [{},k] +\<^sub>\<S>\<^sup>\<real> k = {}" using real_0_th_9[of k,simplified] A1  by mty auto
    then show ?thesis using  bexI[of _ k Rat,simplified] A1 by auto
  qed


mtheorem
  mlet "r is Rat"
  "cluster -\<^sub>\<S>\<^sup>\<real> r \<rightarrow> Rat"
proof(standard,cases "r ={}")
    case True
    thus "-\<^sub>\<S>\<^sup>\<real> r is Rat" using real_0_th_18 by mty auto
  next case F: False
    show "-\<^sub>\<S>\<^sup>\<real> r is Rat"
    proof(cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
        hence [ty]: "[{},r] is Rat" using pair_int F by auto
        thus ?thesis using  real_0_th_17[of r] F by mty auto
      next case False
        then obtain k where [ty]: "k be Element-of RAT\<^bsup>\<ge>0\<^bsub>"  and 
          A1:"k\<noteq>{} & r = [{},k]" using rat_0_th_7[of r] by mty auto
       thus ?thesis using real_0_th_17 F by mty auto
    qed
  qed


mtheorem rat_0_th_19:
  "-\<^sub>\<S>\<^sup>\<real> k is Element-of RAT\<^bsup>\<ge>0\<^bsub> implies k={} \<and> -\<^sub>\<S>\<^sup>\<real> k={}"
proof
  assume [ty]:"-\<^sub>\<S>\<^sup>\<real> k is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  thus "k={} \<and> -\<^sub>\<S>\<^sup>\<real> k={}" using real_0_th_19 by mty auto
qed

mtheorem
  mlet "r be non Element-of RAT\<^bsup>\<ge>0\<^bsub>\<bar>Rat"
  "cluster  -\<^sub>\<S>\<^sup>\<real> r \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof
  obtain k where [ty]: "k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A1: "k<>{} & r = [{},k]" using rat_0_th_7[of r] by mty auto
  hence "(-\<^sub>\<S>\<^sup>\<real> [{},k]) = k" using real_0_th_17 by mty auto
  then show "-\<^sub>\<S>\<^sup>\<real> r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using A1 by mty auto 
qed

mtheorem
   mlet "r be Element-of RAT\<^bsup>\<ge>0\<^bsub>", "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
   "cluster r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof
  have "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = r *\<^sub>\<S>\<^sup>\<real> s   " using real_0_def_7 by mauto
  hence "r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using Prat_Preal_mult by mauto
  thus "(r *\<^sub>\<S>\<^sup>\<real> s) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
qed


mtheorem
  mlet "r be Rat", "s be Rat"
  "cluster r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Rat"
proof
  show "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat"
  proof(cases "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True
        show "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat"
          proof(cases "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
            case [ty]:True
            thus "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat" by mty auto
          next
            case F[ty]: False
              then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
                K: " k\<noteq>{} & s = [{},k]" using rat_0_th_7[of s] by mty auto
              hence [ty]: "not s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto             
              have "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) is Rat" by mty auto
              hence T: "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) is Rat" using Prat_Preal_mult by  mty auto            
              have "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" using real_0_def_7[of r s,simplified] by mty auto
              thus "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat" using T by mty auto           
          qed
        next
    case [ty]:False
         then obtain k where [ty]:"k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
            K:" k\<noteq>{} & r = [{},k]" using rat_0_th_7[of r] by mty auto
         hence [ty]: "not r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto
          show "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat"
          proof(cases "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>")
            case [ty]:True
              have "-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) is Rat" by mty auto
              hence T: "-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real>r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  s) is Rat" using Prat_Preal_mult by  mty auto            
              have "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)" using real_0_def_7[of r s,simplified] by mty auto
              thus "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat" using T by mty auto             
          next
            case [ty]:False
            then obtain l where [ty]:"l be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
              L: " l\<noteq>{} & s = [{},l]" using rat_0_th_7[of s] by mty auto
            hence [ty]: "not s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto


            have  "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" using real_0_def_7[of r s,simplified] K L by mty auto
            hence  H: "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)"
              using Prat_Preal_mult  by mty auto
              thus "(r *\<^sub>\<S>\<^sup>\<real> s) is Rat" using rat_0_th_7 by mty auto
          qed
        qed
qed

theorem rat_0_def_8: 
  "r be Rat \<Longrightarrow> s be Rat \<Longrightarrow>
      (r \<le>\<^sup>\<real> s) iff
      (ex z be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^sup>\<real> z)"
proof
  assume [ty]:"r be Rat"  "s be Rat" 
     and "r \<le>\<^sup>\<real> s"
  then obtain z where 
     Z[ty]:"z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and z:"s = r +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8 by mty auto
  hence "s = z +\<^sub>\<S>\<^sup>\<real> r" using real_0_th_11 by mty auto
  hence "s -\<^sub>\<S>\<^sup>\<real> r = z" using real_1_th_19 by mty auto
  hence "s +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = z" using real_0_def_6 by mty auto
  hence [ty]: "z is Rat" by mty auto
  have [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  proof(rule ccontr)
    assume "\<not> z is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
    then obtain k where [ty]: "k be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      K: "k\<noteq>{} & z = [{},k]" using rat_0_th_7[of z] by mty auto
    hence "z = (-\<^sub>\<S>\<^sup>\<real> k)" "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
         using real_0_th_17 Z by mty auto
       thus False using K real_0_th_19[of k,simplified] by mty auto
     qed
     thus "ex z be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^sup>\<real> z" using z bexI[of _ z] by mty auto
   next
     assume [ty]:"r be Rat"  "s be Rat"  and "ex z be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^sup>\<real> z"
     then obtain z where [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
      and "s = r +\<^sub>\<S>\<^sup>\<real> z" by auto
     hence  "ex z be Element-of REAL\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^sup>\<real> z" using bexI[of _ z] by mty auto
     thus "r \<le>\<^sup>\<real> s"  using real_0_def_8[of r s,simplified] by mty auto
qed
                              
mtheorem rat_0_th_29:
  "k1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k2 iff k1 \<le>\<^sup>\<real> k2"
proof
  assume "k1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k2"
  then obtain z where [ty]: "z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    "k2 = k1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_def_13 by mauto
  hence "k2 = k1 +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_4[of k1 z,simplified] Prat_Preal_add[of k1 z] by mauto
  thus "k1 \<le>\<^sup>\<real> k2" using rat_0_def_8[of k1 k2] bexI[of _ z] by mauto
next
  assume "k1 \<le>\<^sup>\<real> k2"
  then obtain z where [ty]: "z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    "k2 = k1 +\<^sub>\<S>\<^sup>\<real> z" using rat_0_def_8 by mauto
  hence "k2 = k1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using real_0_def_4 Prat_Preal_add by mauto
  thus "k1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k2" using arytm_3_def_13I[of k1 k2] bexI[of _ z] by mauto
qed


mtheorem rat_0_def_8t:
  "r \<le>\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t implies r \<le>\<^sup>\<real> t"
proof
  assume AS: "r \<le>\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t"
  then obtain rs where [ty]:"rs  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     rs: "s = r +\<^sub>\<S>\<^sup>\<real> rs" using rat_0_def_8 by mty auto
  obtain ST where [ty]:"ST  be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     st: "t = s +\<^sub>\<S>\<^sup>\<real> ST" using AS rat_0_def_8 by mty auto
  have "t = r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real> ST)" using rs st real_0_th_15 by mty auto
  thus "r \<le>\<^sup>\<real> t" using bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> ST"] rat_0_def_8[of r t] by mty auto
qed

mtheorem rat_0_Q:
  "{} \<le>\<^sup>\<real> r iff r is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof
  assume "{} \<le>\<^sup>\<real> r"
  then obtain z where [ty]: "z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    "r = {} +\<^sub>\<S>\<^sup>\<real> z" using rat_0_def_8[of "{}" r] by mauto
  hence "r=z" using real_0_th_8[of z,simplified] by mauto
  thus "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto
next
  assume [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  have "r={} +\<^sub>\<S>\<^sup>\<real> r" using real_0_th_8 by mauto
  thus "{} \<le>\<^sup>\<real> r" using rat_0_def_8[of "{}" r] bexI[of _ r] by mauto
qed

end