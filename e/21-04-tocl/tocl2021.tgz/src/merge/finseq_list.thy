theory finseq_list
  imports "../mml/finseq_1" nat_nat
begin


lemma wf_ending: "wf (Collect (\<lambda>((a1,  x), (a2, y)). a1 =\<^sub>\<H> a2 \<and> x is FinSequence \<and> y is FinSequence \<and> (x ending-of y)))"
proof (rule wfI[of _ "Collect (case_prod  (\<lambda>b c. (c is FinSequence)))" 
       "Collect (case_prod (\<lambda>b c. (c is FinSequence)))"], simp, blast, case_tac x, simp del: ty_intersection)
  fix x P b c
  assume A1: " \<forall>\<^sub>La b. (\<forall>\<^sub>Lba. ba be FinSequence \<and> b be FinSequence \<and> ba ending-of b \<longrightarrow> P((a,  ba))) \<longrightarrow> P((a, b))"
  assume A2: "c be FinSequence"
  show "P(( b, c))"
  proof(rule ending_induct[of c "\<lambda>c. P(( b, c))", OF A2],intro ballI impI)
    fix n assume A3: "n is FinSequence" "\<forall>m : FinSequence. m ending-of n \<longrightarrow> P(( b, m))"
    show "P((b, n))" using A1[rule_format, of n b] A3 by auto
  qed mauto
qed


text_raw {*\DefineSnippet{h2sfs}{*}
fun h2sfs :: "('a \<Rightarrow> Set) \<Rightarrow> 'a List.list \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>L'(_,_')")where
  "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>, Nil) =\<^sub>\<S> <*>"
| "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>, Cons(h, t)) =\<^sub>\<S> ((<*\<hh>2\<ss>(h)*>) ^M (\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>, t)))"
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{s2hl}{*}
function s2hl :: "(Set \<Rightarrow> 'a) \<Rightarrow> Set \<Rightarrow>'a List.list" ("\<ss>2\<hh>\<^sub>L'(_,_')") where
  "\<not> x be FinSequence \<Longrightarrow> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,x) =\<^sub>\<H> undefined" 
| "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,<*>) =\<^sub>\<H>  Nil"
| "x be FinSequence \<Longrightarrow> x \<noteq> <*> \<Longrightarrow> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,x) =\<^sub>\<H> Cons (\<ss>2\<hh>(x.1\<^sub>\<S>),  \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,x/^M1\<^sub>\<S>  ))" 
text_raw {*}%EndSnippet*}
  using finseq_1_def_6_ty all_set apply auto apply blast done


notation h2sfs ("\<hh>2\<ss>\<^sub>L") and s2hl ("\<ss>2\<hh>\<^sub>L")

termination
  apply standard
  using wf_ending ending_prop rfinseq_1_def_1_ty by mty auto

theorem FLFprop:
  assumes [ty]:"p be FinSequence-of d" and
        G:"beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
  shows "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) = p"
proof-
  let ?P="\<lambda>m. for p be FinSequence-of d  st len p = m holds \<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) = p"
  have P0: "?P({})"
  proof(rule ballI,rule impI)
    fix p assume [ty]:"p be FinSequence-of d" and "len p={}"
    hence "p=<*>" using finseq_1_def_6_p by auto
    thus "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) = p"  using s2hl.simps by mty auto
  qed mauto
  have Pm: "for m be Nat st ?P(m) holds ?P(succ m)"
   proof(intro ballI impI)
     fix m p assume [ty]:"m be Nat" "p be FinSequence-of d" and A1: "?P(m)" "len p = succ m"
     have "len p <>{}" using A1 by auto
     hence L: "p\<noteq> <*>" using finseq_1_def_6_p by auto
     hence "p|(Seg 1\<^sub>\<S>) = <* p. 1\<^sub>\<S> *>" using finseq_5_th_20 finseq_1_def_6 by auto
     hence P: "p = <* p. 1\<^sub>\<S> *> ^M (p/^M1\<^sub>\<S>)" using rfinseq_th_8[of "1\<^sub>\<S>" p] L by mty auto

     have "1\<^sub>\<S> in dom p" using finseq_1_th_C L by mty auto
     hence "p. 1\<^sub>\<S> in rng p" "rng p c= d" using  funct_1_def_3 finseq_1_def_4[of d p] by mty auto
     hence "p. 1\<^sub>\<S> is Element-of d" using Element(6) all_set tarski_def_3E by auto 
     hence I: "\<hh>2\<ss>(\<ss>2\<hh>(p. 1\<^sub>\<S>)) = p. 1\<^sub>\<S>" using beIsoS_e[OF G] by mty auto
     have "len (p/^M1\<^sub>\<S>) = m" using A1 rfinseq_th_c[of m p] by mty auto 
     hence O: "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p/^M1\<^sub>\<S>)) = p/^M1\<^sub>\<S>" using A1 by mty auto
     have "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) =\<^sub>\<H> Cons (\<ss>2\<hh>(p .1\<^sub>\<S>),  \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p/^M1\<^sub>\<S> ) ))" using L by auto
     thus "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) = p" using I O P by auto
   qed mauto
  have "?P(len p)" using ordinal_2_sch_19[of "len p" ?P, OF _ P0 Pm] by mty auto
  thus ?thesis by mty auto    
qed

theorem LtoF:
  "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,p) is FinSequence"
proof(induct p)
  have "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Nil) = <*>" by auto
  thus "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Nil) is FinSequence" by mty auto
 next
   fix a p
   let ?A = "\<hh>2\<ss>(a)" let ?P=  "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>, p)" 
   assume [ty]:"?P is FinSequence"
   have "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p)) = <*?A*> ^M ?P" by auto
   thus "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p)) is FinSequence" by mty auto
 qed

theorem LtoFofD:
  assumes  G:"beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
  shows "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,p) is FinSequence-of d"
proof(induct p)
  have [ty]:" <*> is empty\<bar>set" using finseq_1_def_6 by mty auto
  hence "rng <*> = {}" using xboole_0_lm_1 by mty auto
  hence R: "rng <*> c= d" using tarski_def_3 xb all_set by mty auto
  have "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Nil) = <*>" by auto
  thus "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Nil) is FinSequence-of d" using finseq_1_def_4I R by mty auto
 next
   fix a p
   let ?A = "\<hh>2\<ss>(a)" let ?P=  "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>, p)" 
   have [ty]:"d be set" using all_set by auto
   have "?A in d"  using G beIsoS_def[of \<hh>2\<ss> \<ss>2\<hh> d] by auto
   hence [ty]: "d be non empty" " ?A is Element-of d" using xboole_0_def_1 Element(6) by auto
   have [ty]: "<*?A*> is FinSequence-of d" by mty auto
   assume [ty]:"?P is FinSequence-of d"
   have "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p)) = <*?A*> ^M ?P" by auto
   thus "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p)) is FinSequence-of d" by mty auto
 qed

theorem LFLprop:
  assumes "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,d)"
  shows "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,p)) =\<^sub>\<H> p"
proof(induct p)
   have "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Nil) = <*>" by auto
   thus "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>, \<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Nil)) =\<^sub>\<H> Nil" using s2hl.simps by auto
 next
   fix a p
   let ?A = "\<hh>2\<ss>(a)" let ?P=  "\<hh>2\<ss>\<^sub>L(\<hh>2\<ss>, p)" 
   let ?AP ="<* ?A *> ^M ?P"
   have [ty]:"?P is FinSequence" using LtoF by auto 
   have "<* ?A *> \<noteq> <*>" using finseq_1_lm_1 by auto
   hence AP: "?AP \<noteq> <*>" using finseq_1_th_35[of ?P] by mty auto
   have M: "\<ss>2\<hh>(\<hh>2\<ss>(a)) =\<^sub>\<H> a" using beIsoS_i[OF assms] by auto 

   assume A: "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>, ?P) =\<^sub>\<H> p"
   have  "\<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p)) = ?AP" by auto
   hence "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>, \<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p))) =\<^sub>\<H>  Cons (\<ss>2\<hh>(?AP .1\<^sub>\<S>),  \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(?AP/^M1\<^sub>\<S> ) ))" 
     using AP s2hl.simps by mty auto
   thus "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>, \<hh>2\<ss>\<^sub>L( \<hh>2\<ss>, Cons(a,p))) =\<^sub>\<H>  Cons (a,  p)" 
     using rfinseq_th_e  rfinseq_th_d M A by mty auto
 qed

theorem beIsoS_finseq:
  "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,D) \<Longrightarrow> beIsoS(h2sfs(\<hh>2\<ss>),s2hl(\<ss>2\<hh>),D*)"
proof-
  assume G: "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,D)"
  have [ty]: "D be set" using all_set by auto
  show "beIsoS(\<lambda>list. \<hh>2\<ss>\<^sub>L(\<hh>2\<ss>,list), \<lambda>fin. \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,fin),D*)"
    unfolding beIsoS_def
  proof(intro conjI)
  let ?L = "h2sfs(\<hh>2\<ss>)" 
  let ?F="s2hl(\<ss>2\<hh>)"
  show "\<forall>\<^sub>Ly. ?F(?L(y)) =\<^sub>\<H> y" using G LFLprop by auto
  show "\<forall>x:Element-of D*. ?L(?F(x)) = x" 
  proof(standard)
    fix x assume [ty]: "x be Element-of D*"
    hence "x in D*" using Element(7) by mty auto
    hence "x is FinSequence-of D" using finseq_1_def_11 by mty auto 
    then show "?L(?F(x)) = x" using FLFprop G  by mty auto
  qed simp_all
  show "\<forall>\<^sub>Ly. ?L(y) in D*"
  proof
    fix y have "?L(y) is FinSequence-of D" using G LtoFofD by auto
    then show "?L(y) in D*" using finseq_1_def_11 by auto
  qed
  qed
qed

text_raw {*\DefineSnippet{beIsoSTfinseq}{*}
theorem beIsoST_finseq:
  "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,D) \<Longrightarrow> 
     beIsoT(\<hh>2\<ss>\<^sub>L (\<hh>2\<ss>),\<ss>2\<hh>\<^sub>L (\<ss>2\<hh>),FinSequence-of D)"
text_raw {*}%EndSnippet*}
proof-
  have H: "(\<And>x. x be FinSequence-of D \<longleftrightarrow> x in D*)" using finseq_1_def_11 all_set by auto
  assume A: "beIsoS(\<hh>2\<ss>,\<ss>2\<hh>,D)"
  show "beIsoT(h2sfs(\<hh>2\<ss>), s2hl(\<ss>2\<hh>), FinSequence-of D)" using beIsoS_Type_Set(2)[OF H beIsoS_finseq[OF A]] by auto
qed

text_raw {*\DefineSnippet{s2hlcon}{*}
theorem conc_M:
  assumes [ty]:"p be FinSequence" "q be FinSequence" 
  shows "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p^Mq) =\<^sub>\<H> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q)"
text_raw {*}%EndSnippet*}
proof-                              
  let ?P="\<lambda>m. for p be FinSequence  st len p = m holds \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p^Mq) =\<^sub>\<H> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q)"
  have P0: "?P({})"
  proof(rule ballI,rule impI)
    fix p assume [ty]:"p be FinSequence" and "len p={}"
    hence "p=<*>" using finseq_1_def_6_p by auto
    thus "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p^Mq) =\<^sub>\<H> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q)"  using s2hl.simps finseq_1_th_34 by mty auto
  qed mauto
  have Pm: "for m be Nat st ?P(m) holds ?P(succ m)"
   proof(intro ballI impI)
     fix m p assume [ty]:"m be Nat" "p be FinSequence" and A1: "?P(m)" "len p = succ m"
     have "len p <>{}" using A1 by auto
     hence L: "p\<noteq> <*>" using finseq_1_def_6_p by auto
     hence P: "p .1\<^sub>\<S> = (p^Mq). 1\<^sub>\<S>" using finseq_1_th_C finseq_1_def_7 by mty auto
     have Q: "(p^Mq) <> <*>" using finseq_1_th_35[of q p] finseq_1_def_6_p[of p] A1 by mty auto
     have "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q) =\<^sub>\<H> List.list.Cons (\<ss>2\<hh>(p .1\<^sub>\<S>), \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p/^M1\<^sub>\<S> ))@ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q))" using L s2hl.simps  by auto
     hence "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q) =\<^sub>\<H> List.list.Cons (\<ss>2\<hh>(p .1\<^sub>\<S>), \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p/^M1\<^sub>\<S>)^Mq))" using A1 rfinseq_th_c by mty auto
     hence "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q) =\<^sub>\<H> List.list.Cons (\<ss>2\<hh>((p^Mq) .1\<^sub>\<S>), \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p^Mq)/^M1\<^sub>\<S>))" using rfinseq_th_b A1 P by mty auto
     thus " \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p^Mq) =\<^sub>\<H> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q)" using s2hl.simps Q by mty auto 
   qed mauto
  have "?P(len p)" using ordinal_2_sch_19[of "len p" ?P, OF _ P0 Pm] by mty auto
  thus ?thesis by mty auto    
qed

text_raw {*\DefineSnippet{s2hlsize}{*}
theorem lenght_M:
  assumes [ty]:"p be FinSequence"
  shows "size(\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(len p)"
text_raw {*}%EndSnippet*}
proof-
  let ?P="\<lambda>m. for p be FinSequence  st len p = m holds size(\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(len p)"
  have P0: "?P({})"
  proof(rule ballI,rule impI)
    fix p assume [ty]:"p be FinSequence" and A1: "len p={}"
    hence "p=<*>" using finseq_1_def_6_p by auto
    thus "size(\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(len p)" using  s2hn.simps A1 by auto
  qed mauto
  have Pm: "for m be Nat st ?P(m) holds ?P(succ m)"
   proof(intro ballI impI)
     fix m p assume [ty]:"m be Nat" "p be FinSequence" and A1: "?P(m)" "len p = succ m"
     have "len p <>{}" using A1 by auto
     hence L: "p\<noteq> <*>" using finseq_1_def_6_p by auto
     hence "len (p/^M1\<^sub>\<S>) = m" using A1 rfinseq_th_c by auto     
     hence "size(\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p/^M1\<^sub>\<S> ) )) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" using A1 by mty auto    
     hence "size (\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>(m))" using L s2hl.simps by auto
     thus "size (\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<nat>(len p)) " using A1 EqSuc by auto
   qed mauto
  have "?P(len p)" using ordinal_2_sch_19[of "len p" ?P, OF _ P0 Pm] by mty auto
  thus ?thesis by mty auto    
qed
text_raw {*\DefineSnippet{nthL}{*}
theorem nth_M:
  assumes [ty]:"p be FinSequence" "n be Nat"
     and "n in len p"
   shows "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) ! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>(p. (succ n))"
text_raw {*}%EndSnippet*}
proof-
  let ?P="\<lambda>m. for p be FinSequence  st len p = m holds 
            for n be Nat st n in m holds \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>(p. (succ n))"
  have P0: "?P({})" using xb by auto
  have Pm: "for m be Nat st ?P(m) holds ?P(succ m)"
   proof(intro ballI impI)
     fix m p n assume [ty]:"m be Nat" "n be Nat" "p be FinSequence" and A1: "?P(m)" "len p = succ m" "n in succ m"
     have "len p <>{}" using A1 by auto
     hence L: "p\<noteq> <*>" using finseq_1_def_6_p by auto
     hence A2:"len (p/^M1\<^sub>\<S>) = m"  
       using A1 rfinseq_th_c finseq_1_def_7 by auto
     have PP: "p = <* p. 1\<^sub>\<S> *> ^M (p/^M1\<^sub>\<S>)" using L rfinseq_th_8[of "1\<^sub>\<S>" p] finseq_5_th_20[of p] by mty auto
     have A3: "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) =\<^sub>\<H> Cons (\<ss>2\<hh>(p .1\<^sub>\<S>),  \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p/^M1\<^sub>\<S> ) ))" using L by auto
     show "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>(p. (succ n))"
     proof(cases "n={}")
       case True
         hence "\<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> 0" "succ n = 1\<^sub>\<S>" by auto
         thus "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>(p. (succ n))" using A3 by auto
       next
         let ?p = "predecessor(n)"
       case F: False
          hence N: "n = succ ?p" using NAT_1_5 by mty auto
          hence "\<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>(?p))" using EqSuc[of ?p] by mty auto
          hence B1: "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,(p/^M1\<^sub>\<S> ) )! \<ss>2\<hh>\<^sub>\<nat>(?p)" using A3 by auto    
          have A4: "?p in m " "n c= m" using A1(3) N ordinal1_th_18[of m "succ ?p"] ordinal1_th_17[ of m ?p]  by mty auto
          hence B2: "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p/^M1\<^sub>\<S>)! \<ss>2\<hh>\<^sub>\<nat>(?p) =\<^sub>\<H> \<ss>2\<hh>((p/^M1\<^sub>\<S>) .n)" using A2 A1(1) N by mty auto
          have "1\<^sub>\<S> c= n" using F one2 by mty auto
          hence "n in dom (p/^M1\<^sub>\<S>)" using A4 A2 finseq_1_th_1 finseq_1_def_3 by mty auto
          hence B3: "(p/^M1\<^sub>\<S>) .n = p. ((len <* p. 1\<^sub>\<S>*>) +\<^sub>\<S>\<^sup>\<nat> n)" using finseq_1_def_7[of "<* p. 1\<^sub>\<S>*>" "p/^M1\<^sub>\<S>"] PP by mty auto 
          have "len <* p. 1\<^sub>\<S>*> = 1\<^sub>\<S>" using finseq_1_def_8 finseq_1_def_3_uniq[of "<* p. 1\<^sub>\<S>*>" "1\<^sub>\<S>"] by mty auto
          thus "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>(p .(succ n))" using B1 B2 B3 Add_5 by auto 
        qed
   qed mauto
  have "?P(len p)" using ordinal_2_sch_19[of "len p" ?P, OF _ P0 Pm] by mty auto
  thus ?thesis using assms(3) by mty auto    
qed mauto

text_raw {*\DefineSnippet{s2hLprop}{*}
theorem s2hL_Prop:
  assumes "p be FinSequence" and "q be FinSequence" and "n be Nat" and "n in len p"
  shows  "size(\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(len p)" 
         "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p^Mq) =\<^sub>\<H> \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) @ \<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,q)"
         "\<ss>2\<hh>\<^sub>L(\<ss>2\<hh>,p) ! \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> \<ss>2\<hh>(p. (succ n))"
text_raw {*}%EndSnippet*}
  using nth_M[of p n] lenght_M[of p] conc_M[of p q] assms by auto
end
