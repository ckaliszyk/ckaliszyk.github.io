theory group_group
  imports nat_nat  funct_2_lam "../mml/group_1" "../mml/algstr_0"
begin

abbreviation carrierM where "carrierM \<equiv> mizar_string.carrier"
abbreviation carrierI where "carrierI \<equiv> Congruence.carrier"
text_raw {*\DefineSnippet{s2hg}{*}
definition s2hg ("\<ss>2\<hh>\<^sub>G'(_,_,_')") where
  "\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g) =\<^sub>\<H> Igroup(
     Collect(\<lambda>x. \<hh>2\<ss>c(x) in the carrier of g), 
     \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of g),
     \<ss>2\<hh>c(1.\<^sub>g))"
text_raw {*}%EndSnippet*}

theorem MtoIMult:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" "the carrier of G = c"
          "x \<in> carrierI(\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c, \<hh>2\<ss>c, G))"
          "y \<in> carrierI(\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c, \<hh>2\<ss>c, G))"
          and
          [ty]: "G is multMagma" 
   shows "x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y))"
         "\<hh>2\<ss>c(x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)\<^esub> y) = \<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y)"
proof-
  let ?M = "\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)"
  have C00: "?M =\<^sub>\<H> Igroup (
          Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrier of G )  , 
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of G),
          \<ss>2\<hh>c(1.\<^sub>G))" using s2hg_def[of \<ss>2\<hh>c \<hh>2\<ss>c G] by auto
  have C01: "carrierI(?M) =\<^sub>\<H>  Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of G )" using C00[unfolded Igroup_def] by auto
  have C02: "mult(?M) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of G)" using C00[unfolded Igroup_def] by auto
  have C: "c is non empty" using beIsoS_d[OF assms(1)] by auto
  have [ty]: "\<hh>2\<ss>c(x) is Element-of-struct G" "\<hh>2\<ss>c(y) is Element-of-struct G" using C01 assms Element(6) all_set by auto
    have "\<ss>2\<hh>c(\<hh>2\<ss>c(x)) =\<^sub>\<H> x" "\<ss>2\<hh>c(\<hh>2\<ss>c(y)) =\<^sub>\<H> y" using beIsoS_i[OF assms(1)] by auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H>  (\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of G))(\<ss>2\<hh>c(\<hh>2\<ss>c(x)),\<ss>2\<hh>c(\<hh>2\<ss>c(y)))" using C02 by auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c((the multF of G).\<lparr>\<hh>2\<ss>c(x),\<hh>2\<ss>c(y)\<rparr>)" using MtoIBinOpS[OF assms(1), of "\<hh>2\<ss>c(x)" "\<hh>2\<ss>c(y)"] assms(2) 
          by mty auto
    then show S1: "x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H>  \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y))" using algstr_0_def_18 assms(2) 
      by mty auto    
    have "\<hh>2\<ss>c(\<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y))) = \<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y)" using beIsoS_e[OF assms(1)] assms by mty auto
    then show "\<hh>2\<ss>c(x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)\<^esub> y) = \<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y)" using S1 by auto
  qed
text_raw {*\DefineSnippet{MIGroup}{*}
theorem MtoIGropuProp:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "G is Group"
    and "the carrier of G =\<^sub>\<S> c"  
  shows "group (\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G))"
  text_raw {*}%EndSnippet*}
proof
  have [ty]: "G is Group" using assms by auto
  let ?M = "\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)"
  let ?E = "Element-of-struct G"
  have C00: "?M =\<^sub>\<H> Igroup (
          Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrier of G )  , 
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of G),
          \<ss>2\<hh>c(1.\<^sub>G))" using s2hg_def[of \<ss>2\<hh>c \<hh>2\<ss>c G] by auto
  have C: "carrierI(?M) =\<^sub>\<H>  Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrierM of G )"
            "mult(?M) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of G)" 
            "one(?M) =\<^sub>\<H> \<ss>2\<hh>c(1.\<^sub>G)" using C00[unfolded Igroup_def] by auto
  show S1: "\<And>x y. x \<in> carrierI(?M) \<Longrightarrow>
           y \<in> carrierI(?M) \<Longrightarrow> x \<otimes>\<^bsub>?M\<^esub> y \<in> carrierI(?M)"
  proof-
    fix x y assume A: "x \<in> carrierI(?M)" "y \<in> carrierI(?M)"
     hence [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" using C Element(6) all_set by auto
  
      have XY: "\<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y) in the carrier of G" using Element(7) all_set by mty auto
      have "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) =  \<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y)" using algstr_0_def_18 assms(3) 
      using MtoIMult[OF assms(1) _ A] by mty auto
    then show "x \<otimes>\<^bsub>?M\<^esub> y \<in> carrierI(?M)" using C XY by auto
  qed
  show S2: " \<And>x y z.
       x \<in> carrierI(?M) \<Longrightarrow>
       y \<in> carrierI(?M) \<Longrightarrow>
       z \<in> carrierI(?M) \<Longrightarrow> x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> x \<otimes>\<^bsub>?M\<^esub> (y \<otimes>\<^bsub>?M\<^esub> z)"
  proof-
    fix x y z assume A: "x \<in> carrierI(?M)" "y \<in> carrierI(?M)" "z \<in> carrierI(?M)"
    hence A1: "x \<otimes>\<^bsub>?M\<^esub> y  \<in> carrierI(?M)"  "y \<otimes>\<^bsub>?M\<^esub> z  \<in> carrierI(?M)" using S1 by auto
    hence [ty]: "\<hh>2\<ss>c(x) is ?E" "\<hh>2\<ss>c(y) is ?E" "\<hh>2\<ss>c(z) is ?E" 
            "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) is ?E" "\<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub> z) is ?E" using C A Element(6) all_set by auto
    have A2:"\<hh>2\<ss>c(y \<otimes>\<^bsub>?M\<^esub> z) = \<hh>2\<ss>c(y) \<otimes>\<^sub>G \<hh>2\<ss>c(z)" using  MtoIMult[OF assms(1,3)] A1 A by mty auto
   
    have "\<hh>2\<ss>c(x \<otimes>\<^bsub>?M\<^esub> y) = \<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y)" using  MtoIMult[OF assms(1,3)] A1 A by mty auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>G \<hh>2\<ss>c(y) \<otimes>\<^sub>G \<hh>2\<ss>c(z))" using MtoIMult[OF assms(1,3)] A1 A by mty auto
    hence "x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>G (\<hh>2\<ss>c(y) \<otimes>\<^sub>G \<hh>2\<ss>c(z)))" using  group_1_def_3E[of G] by mty auto
    then show "x \<otimes>\<^bsub>?M\<^esub> y \<otimes>\<^bsub>?M\<^esub> z =\<^sub>\<H> x \<otimes>\<^bsub>?M\<^esub> (y \<otimes>\<^bsub>?M\<^esub> z)" using  A2 MtoIMult[OF assms(1,3)] A1 A by mty auto
  qed
  have O: "1.\<^sub>G in the carrier of G" using Element(7) by mty auto
  have II: "\<hh>2\<ss>c(\<ss>2\<hh>c(1.\<^sub>G)) = 1.\<^sub>G" using beIsoS_e[OF assms(1), of "1.\<^sub>G"] assms(3) by mty auto
  then show S3: " \<one>\<^bsub>?M\<^esub> \<in> carrierI(?M)" using C O by auto
  show "\<And>x. x \<in> carrierI(?M) \<Longrightarrow> \<one>\<^bsub>?M\<^esub> \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> x"
  proof-
    fix x assume A: "x \<in> carrierI(?M)"
    hence [ty]: "\<hh>2\<ss>c(x) is ?E"  using C Element(6) all_set  by auto
    have "\<ss>2\<hh>c(1.\<^sub>G) \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> \<ss>2\<hh>c((1.\<^sub>G) \<otimes>\<^sub>G \<hh>2\<ss>c(x)) " using MtoIMult[OF assms(1,3)] A II S3 C by mty auto
    hence "\<ss>2\<hh>c(1.\<^sub>G) \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x))" using group_1_def_4 by mty auto
    then show "\<one>\<^bsub>?M\<^esub> \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> x" using beIsoS_i[OF assms(1), of x] assms(2) C by mty auto
  qed
  show "\<And>x. x \<in> carrierI(?M) \<Longrightarrow> x \<otimes>\<^bsub>?M\<^esub> \<one>\<^bsub>?M\<^esub> =\<^sub>\<H> x"
 proof-
    fix x assume A: "x \<in> carrierI(?M)"
    hence [ty]: "\<hh>2\<ss>c(x) is ?E"  using C Element(6) all_set  by auto
    have "x \<otimes>\<^bsub>?M\<^esub> \<ss>2\<hh>c(1.\<^sub>G) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>G (1.\<^sub>G)) " using MtoIMult[OF assms(1,3)] A II S3 C by mty auto
    hence "x \<otimes>\<^bsub>?M\<^esub> \<ss>2\<hh>c(1.\<^sub>G) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x))" using group_1_def_4 by mty auto
    then show "x \<otimes>\<^bsub>?M\<^esub> \<one>\<^bsub>?M\<^esub> =\<^sub>\<H> x" using beIsoS_i[OF assms(1), of x] assms(2) C by mty auto
  qed
  show "(\<subseteq>)(carrierI(?M), Units(?M))"
  proof
    fix y assume A:"y \<in> carrierI(?M)"
    hence [ty]: "\<hh>2\<ss>c(y) is ?E"  using C Element(6) all_set  by auto
    let ?x = "(\<hh>2\<ss>c(y))\<^sup>-\<^sup>1\<^sub>G" 
    have [ty]:"?x is ?E" by mty auto
    have O: "?x in the carrier of G" using Element(7) by mty auto
    have X: "\<hh>2\<ss>c(\<ss>2\<hh>c(?x)) = ?x" using beIsoS_e[OF assms(1), of "?x"] assms(3) by mty auto
    have C1:  "\<ss>2\<hh>c(?x)  \<in> carrierI(?M)" using O X C by auto

    hence "\<ss>2\<hh>c(?x) \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(?x \<otimes>\<^sub>G \<hh>2\<ss>c(y))" using MtoIMult[OF assms(1,3)] X A by mty auto
    hence C2: "\<ss>2\<hh>c(?x) \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H> \<one>\<^bsub>?M\<^esub>" using group_1_def_5 C by mty auto
    have  "y \<otimes>\<^bsub>?M\<^esub> \<ss>2\<hh>c(?x) =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(y) \<otimes>\<^sub>G ?x)" using MtoIMult[OF assms(1,3)] X A C1 by mty auto
    hence "y \<otimes>\<^bsub>?M\<^esub> \<ss>2\<hh>c(?x) =\<^sub>\<H> \<one>\<^bsub>?M\<^esub>" using group_1_def_5 C by mty auto
    hence "Ex (\<lambda>x . x \<in> carrierI(?M) & x \<otimes>\<^bsub>?M\<^esub> y =\<^sub>\<H> \<one>\<^bsub>?M\<^esub> \<and> y \<otimes>\<^bsub>?M\<^esub> x =\<^sub>\<H> \<one>\<^bsub>?M\<^esub>)" using C1 C2 by auto
    then show "y \<in> Units (?M)" using A Units_def[of ?M] by auto  
   qed
qed

text_raw {*\DefineSnippet{h2sg}{*}
definition \<hh>2\<ss>g ("\<hh>2\<ss>\<^sub>G'(_,_,_,_')") where
  "\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) =\<^sub>\<S> [#
    carrier \<mapsto> c; 
    multF \<mapsto> \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(g)) #]"
text_raw {*}%EndSnippet*}


theorem h2sgProp:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)"
  shows "\<hh>2\<ss>g (\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) is strict(multMagma)"
        "the carrierM of \<hh>2\<ss>g (\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) = c"
        "the multF of \<hh>2\<ss>g (\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(g))"
proof-
  let ?I ="\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g)"
  let ?B = "\<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(g))"
  let ?M="[#carrierM \<mapsto> c;multF \<mapsto> ?B #]"
  have [ty]: "c be set" using all_set by auto
  have [ty]: "?B is BinOp-of c" using ItoMf2prop[OF assms(1,1,1)] h2sBinOp_def[of \<ss>2\<hh>c] by auto
  have A1[ty]: "?M is strict(multMagma)" by mty auto
  then show [ty]: "?I is strict(multMagma)" unfolding \<hh>2\<ss>g_def by auto
  have "the carrierM of ?M = c" 
       "the multF of ?M = ?B" using the_selector_of_1[of _ carrierM c]  
     the_selector_of_1[of _ multF ?B] aggr by auto
  then show "the carrierM of ?I = c"
        "the multF of ?I = ?B"  unfolding \<hh>2\<ss>g_def by auto
qed

theorem ItoMmult:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)"
          "x is Element-of c" "y is Element-of c"
   shows "x \<otimes>\<^sub>\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) y =\<^sub>\<S> \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(y))"
         "\<ss>2\<hh>c(x \<otimes>\<^sub>\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) y) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(y)"
proof-
  let ?I ="\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g)"
  have [ty]:"?I is strict(multMagma)" "c be set" using h2sgProp[OF assms(1)] all_set by auto
  have CAR: "the carrier of ?I = c" using h2sgProp[OF assms(1)] by auto
  hence XY[ty]: "x is Element-of-struct ?I" "y is Element-of-struct ?I" using assms(2,3) by auto
  have xy: "\<hh>2\<ss>c(\<ss>2\<hh>c(x)) = x" "\<hh>2\<ss>c(\<ss>2\<hh>c(y)) = y" using beIsoS_e[OF assms(1)] CAR XY by mty auto

  have ADD: "the multF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(g))" using h2sgProp[OF assms(1)] by auto
  hence "x \<otimes>\<^sub>?I  y = (\<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(g))) . \<lparr>\<hh>2\<ss>c(\<ss>2\<hh>c(x)),\<hh>2\<ss>c(\<ss>2\<hh>c(y))\<rparr>" using xy algstr_0_def_18[of ?I x y] by mty auto
  then show S1: "x \<otimes>\<^sub>?I  y = \<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(y))" 
       using ItoMBinOpS[OF assms(1), of "mult(g)" "\<ss>2\<hh>c(x)" "\<ss>2\<hh>c(y)"] by auto
  have "\<ss>2\<hh>c(\<hh>2\<ss>c(\<ss>2\<hh>c(x) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(y))) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(y)" using  beIsoS_i[OF assms(1)] by auto
  then show "\<ss>2\<hh>c(x \<otimes>\<^sub>\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) y) =\<^sub>\<H> \<ss>2\<hh>c(x) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(y)" using S1 by auto
qed


text_raw {*\DefineSnippet{IMgroup}{*}
theorem ItoMGroupProp:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "group(g)"
    and "carrierI(g) =\<^sub>\<H> Collect(\<lambda>x .\<hh>2\<ss>c(x) in c)" 
  shows "\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) is Group"
text_raw {*}%EndSnippet*}
proof-
  have [simp]:"group(g)" using assms by auto
  have [simp]:"monoid(g)" using group_def[of g] by auto
  let ?I = "\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g)"
  have [ty]: "?I is strict(multMagma)" and
       A1: "the carrierM of ?I = c" using h2sgProp[OF assms(1)] by auto
  have A2: "c is non empty" using beIsoS_d[OF assms(1)] by auto
  have [ty]:" ?I is non empty-struct" 
  proof
    show "\<not> the carrier of ?I is empty" using A1 A2 by simp
  qed mauto
  let ?e = "\<hh>2\<ss>c(one(g))" 
  have E[ty]: "?e is Element-of-struct ?I" using A1 beIsoS_m[OF assms(1)] by auto
  hence E0:"?e in c" using A1 Element(7)[of c] A2 by mty auto
  have E1: "\<ss>2\<hh>c(?e) =\<^sub>\<H> one(g)" using beIsoS_i[OF assms(1)] by auto
  have [ty]:" ?I is Group-like"
  proof(standard,simp,rule bexI[of _ ?e],intro ballI conjI)
    fix h assume A3[ty]: "h be Element-of-struct ?I"
    hence A4: "h in c" "\<hh>2\<ss>c(\<ss>2\<hh>c(h)) = h" using A1 Element(7)[of c] A2 beIsoS_e[OF assms(1)] by mty auto
    hence A5: "\<ss>2\<hh>c(h) \<in> carrierI(g)" using assms(3) by auto
    have "h \<otimes>\<^sub>?I ?e = \<hh>2\<ss>c(\<ss>2\<hh>c(h) \<otimes>\<^bsub>g\<^esub> one(g))" using ItoMmult[OF assms(1), of h ?e g] A1 E A3 E1 by auto 
    then show "h \<otimes>\<^sub>?I ?e = h" using monoid.r_one[of g] A5 A4 by auto
    have "?e \<otimes>\<^sub>?I h = \<hh>2\<ss>c(one(g) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(h))" using ItoMmult[OF assms(1), of ?e h g] A1 E A3 E1 by auto 
    then show "?e \<otimes>\<^sub>?I h = h" using monoid.r_one[of g] A5 A4 by auto
    let ?g1 = "\<hh>2\<ss>c(inv\<^bsub>g\<^esub> \<ss>2\<hh>c(h))"
    have G[ty]: "?g1 is Element-of-struct ?I" using A1 beIsoS_m[OF assms(1)] by auto
    hence G1:"\<ss>2\<hh>c(?g1) =\<^sub>\<H> inv\<^bsub>g\<^esub> \<ss>2\<hh>c(h)" using A1 Element(7)[of c] A2 beIsoS_i[OF assms(1)] by mty auto    
    show " \<exists>ga : Element-of-struct ?I. h  \<otimes>\<^sub>?I ga = ?e \<and> ga  \<otimes>\<^sub>?I h = ?e"
    proof(rule bexI[of _ ?g1],rule conjI)
      have "h \<otimes>\<^sub>?I ?g1 = \<hh>2\<ss>c(\<ss>2\<hh>c(h)  \<otimes>\<^bsub>g\<^esub>  inv\<^bsub>g\<^esub> \<ss>2\<hh>c(h))" using ItoMmult[OF assms(1), of h ?g1 g] A1 G A3 G1 by auto 
      then show "h \<otimes>\<^sub>?I ?g1 = ?e" using group.r_inv[of g] A5 by auto
      have "?g1 \<otimes>\<^sub>?I h = \<hh>2\<ss>c((inv\<^bsub>g\<^esub> \<ss>2\<hh>c(h))  \<otimes>\<^bsub>g\<^esub>  \<ss>2\<hh>c(h))" using ItoMmult[OF assms(1), of ?g1 h g] A1 G A3 G1 by auto 
      then show "?g1 \<otimes>\<^sub>?I h = ?e" using group.l_inv[of g] A5 by auto
    qed mauto
  qed mauto
  have [ty]:" ?I is  associative"
  proof(standard,simp,intro ballI)
    fix x y z assume Z1[ty]:"x is Element-of-struct ?I" "y is Element-of-struct ?I" "z is Element-of-struct ?I"
    hence A4: "x in c" "\<hh>2\<ss>c(\<ss>2\<hh>c(x)) = x" 
              "y in c" "\<hh>2\<ss>c(\<ss>2\<hh>c(y)) = y"
              "z in c" "\<hh>2\<ss>c(\<ss>2\<hh>c(z)) = z" using A1 Element(7)[of c] A2 beIsoS_e[OF assms(1)] by mty auto        
    hence B4: "\<ss>2\<hh>c(x) \<in> carrierI(g)" "\<ss>2\<hh>c(y) \<in> carrierI(g)" "\<ss>2\<hh>c(z) \<in> carrierI(g)"using assms(3) by auto   
    have A5: "x \<otimes>\<^sub>?I y is Element-of-struct ?I" "y \<otimes>\<^sub>?I z is Element-of-struct ?I" by mty auto
       
    have  "(x \<otimes>\<^sub>?I y) \<otimes>\<^sub>?I z = \<hh>2\<ss>c(\<ss>2\<hh>c(x \<otimes>\<^sub>?I y)  \<otimes>\<^bsub>g\<^esub>  \<ss>2\<hh>c(z))" using ItoMmult[OF assms(1), of "x \<otimes>\<^sub>?I y" z  g,simplified]
      A1  Z1 A5 by mty auto 
    also have "\<dots>=\<hh>2\<ss>c(\<ss>2\<hh>c(x)  \<otimes>\<^bsub>g\<^esub>  \<ss>2\<hh>c(y)  \<otimes>\<^bsub>g\<^esub>  \<ss>2\<hh>c(z))" using ItoMmult[OF assms(1), of x y  g,simplified]
      A1 Z1 by mty auto 
    also have "\<dots>=\<hh>2\<ss>c(\<ss>2\<hh>c(x)  \<otimes>\<^bsub>g\<^esub>  (\<ss>2\<hh>c(y)  \<otimes>\<^bsub>g\<^esub>  \<ss>2\<hh>c(z)))" using monoid.m_assoc[of g] B4 by auto
    also have "\<dots>=\<hh>2\<ss>c(\<ss>2\<hh>c(x)  \<otimes>\<^bsub>g\<^esub>  \<ss>2\<hh>c(y \<otimes>\<^sub>?I z))" using ItoMmult[OF assms(1), of y z g,simplified]
      A1 Z1 by mty auto 
    also have "\<dots>=x \<otimes>\<^sub>?I (y \<otimes>\<^sub>?I z)" using ItoMmult[OF assms(1), of x "y \<otimes>\<^sub>?I z"  g,simplified]
      A1  Z1 A5 by mty auto 
    finally show "x \<otimes>\<^sub>?I y \<otimes>\<^sub>?I z = x \<otimes>\<^sub>?I (y \<otimes>\<^sub>?I z)" by simp
  qed mauto
  show "?I is Group" by mty auto
qed

theorem ItoMGOne:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "group(g)" 
    and "carrierI(g) =\<^sub>\<H> Collect( \<lambda> x . \<hh>2\<ss>c(x) in c )"
  shows "1.\<^sub>\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g) =\<^sub>\<S> \<hh>2\<ss>c(one(g))"
proof-
  let ?I = "\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,g)"
  let ?E="Element-of-struct ?I"
   have [simp]:"monoid(g)" using group_def[of g] assms by auto

  have [ty]:"?I is Group" using ItoMGroupProp[OF assms(1,2,3)] by simp
  have A1: "the carrierM of ?I = c" using h2sgProp[OF assms(1)] by auto
  have A2: "c is non empty" using beIsoS_d[OF assms(1)] by auto
  let ?e = "\<hh>2\<ss>c(one(g))"
  have [ty]: "?I is unital" by mty auto
  have E[ty]:"?e is ?E" using beIsoS_m[OF assms(1)] A1 by mty auto
  have E1: "\<ss>2\<hh>c(?e) =\<^sub>\<H> one(g)" using beIsoS_i[OF assms(1)] by auto

    have "for h being ?E holds
         h \<otimes>\<^sub>?I ?e = h \<and> ?e \<otimes>\<^sub>?I h = h"
    proof 
      fix h assume A3[ty]: "h is ?E"
       hence A4: "h in c" "\<hh>2\<ss>c(\<ss>2\<hh>c(h)) = h" using A1 Element(7)[of c] A2 beIsoS_e[OF assms(1)] by mty auto
    hence A5: "\<ss>2\<hh>c(h) \<in> carrierI(g)" using assms(3) by auto
    have "h \<otimes>\<^sub>?I ?e = \<hh>2\<ss>c(\<ss>2\<hh>c(h) \<otimes>\<^bsub>g\<^esub> one(g))" using ItoMmult[OF assms(1), of h ?e g] A1 E E1 A3 by auto 
    hence H1: "h \<otimes>\<^sub>?I ?e = h" using monoid.r_one[of g] A5 A4 by auto
    have "?e \<otimes>\<^sub>?I h = \<hh>2\<ss>c(one(g) \<otimes>\<^bsub>g\<^esub> \<ss>2\<hh>c(h))" using ItoMmult[OF assms(1), of ?e h g] A1 E E1 A3 by auto 
    then show "h \<otimes>\<^sub>?I ?e = h & ?e \<otimes>\<^sub>?I h = h" using monoid.r_one[of g] A5 A4 H1 by auto
    qed mauto
    then show "1.\<^sub>?I = ?e" using group_1_def_4_uniq[of ?I ?e] by mty auto 
  qed


text_raw {*\DefineSnippet{GGprop}{*}
theorem s2hg_Prop:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "g be Group"
    and "the carrier of g =\<^sub>\<S> c"
    and "x \<in> carrierI(\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c, \<hh>2\<ss>c, g))" 
        "y \<in> carrierI(\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c, \<hh>2\<ss>c, g))"
  shows "one(\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g)) =\<^sub>\<H> \<ss>2\<hh>c(1.\<^sub>g)" 
        "x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g)\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>g \<hh>2\<ss>c(y))"
        "group (\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g))"
text_raw {*}%EndSnippet*}
proof-
  let ?M = "\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g)"
  have C00: "?M =\<^sub>\<H> Igroup (
          Collect( \<lambda> x . \<hh>2\<ss>c(x) in the carrier of g)  , 
          \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of g),
          \<ss>2\<hh>c(1.\<^sub>g))" using s2hg_def[of \<ss>2\<hh>c \<hh>2\<ss>c g] by auto
  show "one(?M) =\<^sub>\<H>  \<ss>2\<hh>c(1.\<^sub>g)" using C00[unfolded Igroup_def] by auto
  show "x \<otimes>\<^bsub>\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g)\<^esub> y =\<^sub>\<H> \<ss>2\<hh>c(\<hh>2\<ss>c(x) \<otimes>\<^sub>g \<hh>2\<ss>c(y))" using MtoIMult[OF assms(1,3,4,5)] assms(2) by auto
  show "group (\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,g))"
        using MtoIGropuProp[OF assms(1,2)] assms(3) by auto
    qed

text_raw {*\DefineSnippet{MIMgroup}{*}
theorem MIMgr_prop:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "G is strict(multMagma)"
    and "the carrier of G =\<^sub>\<S> c"
  shows "\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)) =\<^sub>\<S> G" 
text_raw {*}%EndSnippet*}
proof(rule Equal_strict[of _ _ multMagma])
  have [ty]:"G is strict(multMagma)" using assms by auto
  show "G be Struct" "G is strict(multMagma)" by mty auto
  let ?I="\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,G)"
  let ?M ="\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,?I)"
  have [ty]: "G is strict(multMagma)" "?M is strict(multMagma)" and
       A1: "the carrierM of ?M = c"
       "the multF of ?M = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(?I))" using h2sgProp[OF assms(1)] by auto
  then show "?M is Struct" "?M is strict(multMagma)" by auto

  fix selector
  assume A2: "selector in domain_of multMagma"
  show "the selector of ?M= the selector of G"
  proof(cases "selector = carrier")
    case True
      thus ?thesis using assms(3) A1 by auto
    next
      case False
        hence S: "selector = multF" using A2 multMagma_dom string by auto
        have "mult(?I) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,the multF of G)" using s2hg_def[of \<ss>2\<hh>c \<hh>2\<ss>c G] unfolding Igroup_def by auto
        hence "the multF of ?M = the multF of G" using MIMBinOp[OF assms(1), of "the multF of G"] assms(3) A1 by mty auto
       thus ?thesis using S by auto
     qed
qed

text_raw {*\DefineSnippet{IMIgroup}{*}
theorem IMIgr_prop:
  assumes "beIsoS(\<hh>2\<ss>c,\<ss>2\<hh>c,c)" and "group(G)" 
    and "carrierI(G) =\<^sub>\<H> Collect(\<lambda>x. \<hh>2\<ss>c(x) in c)"
  shows "\<ss>2\<hh>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c,\<hh>2\<ss>c,c,G)) =\<^sub>\<H> G " 
text_raw {*}%EndSnippet*}
  unfolding s2hg_def 
proof(rule group_eq,intro conjI)
  let ?I="\<hh>2\<ss>\<^sub>G(\<ss>2\<hh>c, \<hh>2\<ss>c, c, G)"
  have [ty]: "?I is strict(multMagma)" and
        A1: "the carrierM of  ?I = c"
        "the multF of ?I = \<hh>2\<ss>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c,\<hh>2\<ss>c,c,mult(G))" using h2sgProp[OF assms(1)] by auto
  show "carrierI(G) =\<^sub>\<H> Collect(\<lambda> x. \<hh>2\<ss>c(x) in the' carrierM(?I))" using assms(3) A1 by auto
  show "mult(G) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>c, \<hh>2\<ss>c, the multF of ?I)" using A1 IMIBinOpS[OF assms(1)] by auto
  have "\<hh>2\<ss>c(one(G)) = 1.\<^sub>?I" using ItoMGOne[OF assms(1,2,3)] by auto
  then show H3:"one(G) =\<^sub>\<H> \<ss>2\<hh>c(1.\<^sub>?I)" using beIsoS_i[OF assms(1),of "one(G)"] by auto
qed

end
