theory int_int
  imports nat_nat pre_merge_int "../mml/newton"
begin

notation
  uminus ("-\<^sub>\<H> _" [81] 80)

notation
  minus (infixl "-\<^sub>\<H>" 65)

term "less_eq_int"
(*Dirichlet's Theorem*)
text_raw {*\DefineSnippet{h2sZ}{*}
function h2sZ :: "int \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>\<int>'(_')")where
  "x \<ge> 0 \<Longrightarrow> \<hh>2\<ss>\<^sub>\<int>(x) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(nat(x))"
| "x < 0 \<Longrightarrow> \<hh>2\<ss>\<^sub>\<int>(x) =\<^sub>\<S> -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(x)))"
text_raw {*}%EndSnippet*}
proof(auto)
  fix P and x :: int
  assume a: "\<And>xa. 0 \<le> xa \<Longrightarrow> x =\<^sub>\<H> xa \<Longrightarrow> P"
  assume b: "\<And>xa. xa < 0 \<Longrightarrow> x =\<^sub>\<H> xa \<Longrightarrow> P"
  have "x\<ge>0 \<or> x <0" by linarith
  then show P using a b by blast
qed

notation h2sZ ("\<hh>2\<ss>\<^sub>\<int>")

termination
  apply standard 
  apply auto done
text_raw {*\DefineSnippet{s2hZ}{*}
function s2hZ :: "Set \<Rightarrow> int" ("\<ss>2\<hh>\<^sub>\<int>'(_')")where
  "\<not>x is Integer \<Longrightarrow> \<ss>2\<hh>\<^sub>\<int>(x) =\<^sub>\<H> undefined"
| "x is natural \<Longrightarrow> \<ss>2\<hh>\<^sub>\<int>(x) =\<^sub>\<H> int(\<ss>2\<hh>\<^sub>\<nat>(x))"
| "x is Integer & not x is natural \<Longrightarrow> \<ss>2\<hh>\<^sub>\<int>(x) =\<^sub>\<H> -\<^sub>\<H> (int(\<ss>2\<hh>\<^sub>\<nat>(-\<^sub>\<S>\<^sup>\<real> x))) "
text_raw {*}%EndSnippet*}
proof(auto)
  fix x assume A: "\<not> x be integer" and [ty]:"x be natural" 
  have "x be Integer" by mty auto
  thus " undefined =\<^sub>\<H> int(\<ss>2\<hh>\<^sub>\<nat>(x))" using A by simp
qed

notation s2hZ ("\<ss>2\<hh>\<^sub>\<int>")

termination
  apply standard 
  apply auto done

theorem h2sZprop: 
  "\<hh>2\<ss>\<^sub>\<int>(i) is Integer"
proof(cases "i \<ge>0")
  case True
    hence [ty]: "\<hh>2\<ss>\<^sub>\<int>(i) is Nat" using h2sZ.psimps I2Mprop by auto
    show "\<hh>2\<ss>\<^sub>\<int>(i) is Integer" by mty auto
  next 
  case False      
    hence "i <0" by linarith
    hence A1:"\<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))" using h2sZ.psimps[of i] by auto
    have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) is Nat" using  I2Mprop by auto 
    show "\<hh>2\<ss>\<^sub>\<int>(i) is Integer" using A1 by mty auto
  qed

theorem h2sZpropE:
  "\<hh>2\<ss>\<^sub>\<int>(i) is Element-of INT"
proof-
  have "\<hh>2\<ss>\<^sub>\<int>(i) is Integer" using h2sZprop by auto
  then show "\<hh>2\<ss>\<^sub>\<int>(i) is Element-of INT" using int_1_def_2 Element(6) by mty auto
qed

theorem MIMZprop:
   "i is Integer implies \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) =\<^sub>\<S> i"
proof
  assume [ty]:"i is Integer"
  have [ty]: "i be set" using all_set by auto
  show "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i"
  proof(cases "i is natural")
    case [ty]: True
    then show "\<hh>2\<ss>\<^sub>\<int>(s2hZ (i)) = i" using MIMprop by auto 
  next case F[ty]: False
    hence A1: "s2hZ (i) =\<^sub>\<H>  -\<^sub>\<H> (int(\<ss>2\<hh>\<^sub>\<nat>(-\<^sub>\<S>\<^sup>\<real> i)))" by auto
    have [ty]:"-\<^sub>\<S>\<^sup>\<real> i is Nat" using F by mty auto 
    show ?thesis
    proof(cases "s2hZ (i)<0")
      case True 
        hence " \<hh>2\<ss>\<^sub>\<int>(s2hZ (i)) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>( -\<^sub>\<H> (int(\<ss>2\<hh>\<^sub>\<nat>(-\<^sub>\<S>\<^sup>\<real> i))))))" using A1 by auto
        then show "\<hh>2\<ss>\<^sub>\<int>(s2hZ (i)) =i " using real_0_th_20a MIMprop by mty auto 
      next
        case False 
          hence "s2hZ (i) =\<^sub>\<H> 0" by auto
          hence "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(-\<^sub>\<S>\<^sup>\<real> i)) = {}" using A1 MIMprop by auto
          hence "(-\<^sub>\<S>\<^sup>\<real> i) = {}" using MIMprop by auto
          hence " i = {}" using real_0_th_18 real_0_th_20a[of i] by mty auto                
          then show "\<hh>2\<ss>\<^sub>\<int>(s2hZ (i)) = i" by mty auto
    qed
  qed
qed

theorem \<hh>2\<ss>_less_zero:
  "i <0 implies \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) <> {} & \<hh>2\<ss>\<^sub>\<int>(i) = [{},\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))]" 
proof(standard, standard)
  assume I: "i <0" 
      have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) is Nat" using I2Mprop by auto
      show I1: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) <> {}"
      proof
        assume "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) ={}"
        hence "\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(0))" by auto
        then show False using I IMIprop  by auto
      qed
      then show  "\<hh>2\<ss>\<^sub>\<int>(i) = [{},\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))]" using real_0_th_17 I by mty auto
qed
theorem IMIZprop:
  "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i)) =\<^sub>\<H> i"
proof(cases "i \<ge> 0")
  case T: True
    hence A1: "\<hh>2\<ss>\<^sub>\<int>(i) = \<hh>2\<ss>\<^sub>\<nat>(nat(i))" by auto
    hence [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(i)) is Nat"
       using I2Mprop by auto 
    hence "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i)) =\<^sub>\<H> int(\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(nat(i))))" using s2hZ.simps A1 by auto
    then show "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i)) =\<^sub>\<H> i" using IMIprop A1 T by auto
  next 
    case False
      hence I: "i <0" by linarith
      have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) is Nat" using I2Mprop by auto
      have [ty]:"\<hh>2\<ss>\<^sub>\<int>(i) is Integer" using h2sZprop by auto    
      have A1: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) <> {} & \<hh>2\<ss>\<^sub>\<int>(i) = [{},\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))]" using  \<hh>2\<ss>_less_zero I by auto
      hence "not \<hh>2\<ss>\<^sub>\<int>(i) is natural" by mty auto
      hence "s2hZ (\<hh>2\<ss>\<^sub>\<int>(i)) =\<^sub>\<H>  -\<^sub>\<H> (int(\<ss>2\<hh>\<^sub>\<nat>(-\<^sub>\<S>\<^sup>\<real>  \<hh>2\<ss>\<^sub>\<int>(i))))" using s2hZ.simps(3)[of "\<hh>2\<ss>\<^sub>\<int>(i)"]  by mty auto
      also have "... =\<^sub>\<H> -\<^sub>\<H> (-\<^sub>\<H>(i))" using IMIprop A1 I real_0_th_17[OF ] by mty auto
      finally show "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(i)) =\<^sub>\<H> i" by auto
    qed

text_raw {*\DefineSnippet{beIsoTInt}{*}
theorem beIsoT_Int: 
  "beIsoT(\<hh>2\<ss>\<^sub>\<int>,\<ss>2\<hh>\<^sub>\<int>,Integer)"
text_raw {*}%EndSnippet*}
  unfolding beIsoT_def 
proof(intro conjI)
  show "\<forall>\<^sub>Ly. \<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(y)) =\<^sub>\<H> y" using IMIZprop by auto
  show "\<forall>x:Integer. \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(x)) = x" using MIMZprop by mty auto
  show "\<forall>\<^sub>Ly. \<hh>2\<ss>\<^sub>\<int>(y) be Integer"  using h2sZprop by auto
qed
text_raw {*\DefineSnippet{beIsoSINT}{*}
theorem beIsoS_INT:
  "beIsoS(\<hh>2\<ss>\<^sub>\<int>,\<ss>2\<hh>\<^sub>\<int>,INT)"
text_raw {*}%EndSnippet*}
  by(auto simp add: int_1_def_2 all_set beIsoS_Type_Set(1)[OF _ beIsoT_Int])



theorem positive_add_positive:
   "i \<ge> 0 & j \<ge> 0 implies \<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
proof
  assume T1: "i \<ge> 0 & j \<ge> 0"
  hence E1: "\<hh>2\<ss>\<^sub>\<int>(i) = \<hh>2\<ss>\<^sub>\<nat>(nat(i))" "\<hh>2\<ss>\<^sub>\<int>(j) = \<hh>2\<ss>\<^sub>\<nat>(nat(j))" by auto
  have R1[ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(i)) is Nat" 
             "\<hh>2\<ss>\<^sub>\<nat>(nat(j)) is Nat"  using I2Mprop by auto
  have A1: "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<nat>(nat(i+\<^sub>\<H>j))" using T1 by auto
  have "nat(i+\<^sub>\<H>j) =\<^sub>\<H> nat(i) +\<^sub>\<H> nat(j)" using T1 by auto
  hence "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = (\<hh>2\<ss>\<^sub>\<nat>(nat(i)) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(nat(j)))" using A1 AddI by auto
  then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" 
    using int_1_def_3[of "\<hh>2\<ss>\<^sub>\<nat>(nat(i))" "\<hh>2\<ss>\<^sub>\<nat>(nat(j))",simplified] E1 by mty auto
qed 

theorem positive_add_negative:
  "i \<ge> 0 & j < 0 implies \<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
proof
  let ?I="\<hh>2\<ss>\<^sub>\<nat>(nat(i))"
  let ?MJ="\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H> j))"
  let ?IJ="\<hh>2\<ss>\<^sub>\<nat>(nat(i+\<^sub>\<H>j))"
  let ?MIJ="\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i+\<^sub>\<H>j)))"
  have R1[ty]: "?I is Nat" "?MJ is Nat" "?IJ is Nat" "?MIJ is Nat"
    using I2Mprop by auto
  assume A1: "i \<ge> 0 & j < 0"
  hence A2: "\<hh>2\<ss>\<^sub>\<int>(i) = ?I" "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> j) = ?MJ" "?MJ<>{}"
        "\<hh>2\<ss>\<^sub>\<int>(j) = [{},?MJ]" using \<hh>2\<ss>_less_zero by auto
  have  A[ty]: "\<hh>2\<ss>\<^sub>\<int>(j) is non natural" "\<hh>2\<ss>\<^sub>\<int>(j) is Integer" using h2sZprop[of j] A2 by mty auto
  
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>(i) be Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A2 by mty auto
  have [ty]:"\<not> \<hh>2\<ss>\<^sub>\<int>(j) be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
  have [ty]:"?MJ be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
  have [ty]:"\<hh>2\<ss>\<^sub>\<int>(i) be Mreal" by mty auto
  have [ty]:"\<hh>2\<ss>\<^sub>\<int>(j) be Mreal" by mty auto
  have A3: "\<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j) = ?I --R ?MJ" using real_0_def_4[of "\<hh>2\<ss>\<^sub>\<int>(i)" "\<hh>2\<ss>\<^sub>\<int>(j)",simplified]
    A2 A by mty auto
  show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
  proof(cases "i+\<^sub>\<H>j\<ge>0")
    case T1: True
      hence A4: "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = ?IJ" by auto
      have "nat(i+\<^sub>\<H>j) =\<^sub>\<H> i+\<^sub>\<H>j " using T1 by auto
      have "i+\<^sub>\<H>j +\<^sub>\<H> (-\<^sub>\<H> j) =\<^sub>\<H> i" by auto
      hence "?I = ?IJ +\<^sub>\<S>\<^sup>\<real> ?MJ" using A1 T1 positive_add_positive[of "i+\<^sub>\<H>j" "-\<^sub>\<H> j"] A2 by auto
      hence "?I = ?MJ +\<^sub>\<S>\<^sup>\<nat> ?IJ" using Add_6[of ?IJ ?MJ] int_1_def_3[of ?IJ ?MJ] by mty auto
      hence "?I--R ?MJ = ?IJ" using int_0_th_1[of ?I ?IJ ?MJ,simplified] by mty auto
      then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using A4 A3 by auto
  next
    case False
      hence "i+\<^sub>\<H>j <0" by auto
      hence A4: "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = [{}, ?MIJ]" "?MIJ<>{}" "-\<^sub>\<H>(i+\<^sub>\<H>j) \<ge>0" using \<hh>2\<ss>_less_zero[of "i+\<^sub>\<H>j"] by auto
      have "i+\<^sub>\<H> -\<^sub>\<H> (i+\<^sub>\<H>j) =\<^sub>\<H> -\<^sub>\<H> j" by auto
      hence A5: "?I +\<^sub>\<S>\<^sup>\<real> ?MIJ = ?MJ" using positive_add_positive[of "i" "-\<^sub>\<H> (i+\<^sub>\<H>j)"]  A1 A4(3) by auto
      have R2[ty]: "?MIJ is Integer" "?I is Integer" using R1(4) cl_nat_int by mty auto
      have "?I +\<^sub>\<S>\<^sup>\<real> ?MIJ = ?I +\<^sub>\<S>\<^sup>\<nat> ?MIJ" 
        using int_1_def_3[of ?I ?MIJ] R1 by mty auto
      hence A6: "(?I +\<^sub>\<S>\<^sup>\<nat> ?MIJ) = ?MJ" using A5 by mty auto
      show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using int_0_th_3[of ?MJ ?MIJ ?I,OF R1(2,4,1) A6 A4(2)] A4(1) A3 by mty auto   
    qed
  qed

theorem h2sZp:
  "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(j+\<^sub>\<H>i)"
proof(cases "i+\<^sub>\<H>j \<ge>0")
  case True
    hence " \<hh>2\<ss>\<^sub>\<int>(i +\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<nat>(nat(i +\<^sub>\<H> j))"  "\<hh>2\<ss>\<^sub>\<int>(j +\<^sub>\<H> i) = \<hh>2\<ss>\<^sub>\<nat>(nat(j +\<^sub>\<H> i))" "nat(i +\<^sub>\<H> j) =\<^sub>\<H> nat(j +\<^sub>\<H> i)"
      using h2sZ.simps[of "i+\<^sub>\<H>j"] h2sZ.simps[of "j+\<^sub>\<H>i"] by auto 
    then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(j+\<^sub>\<H>i)" by auto
  next
    case False
     hence " \<hh>2\<ss>\<^sub>\<int>(i +\<^sub>\<H> j) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i +\<^sub>\<H> j)))"  "\<hh>2\<ss>\<^sub>\<int>(j +\<^sub>\<H> i) = -\<^sub>\<S>\<^sup>\<real>  \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(j +\<^sub>\<H> i)))" "nat(-\<^sub>\<H>(i +\<^sub>\<H> j)) =\<^sub>\<H> nat(-\<^sub>\<H>(j +\<^sub>\<H> i))"
      using h2sZ.simps[of "i+\<^sub>\<H>j"] h2sZ.simps[of "j+\<^sub>\<H>i"] by auto 
    then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(j+\<^sub>\<H>i)" by auto
qed

theorem AddIntI:
  "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
proof(cases "i \<ge>0")
  case T1: True
  show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
  proof(cases "j \<ge>0")
    case T2: True
       then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using positive_add_positive T1 by auto
     next 
       case F2: False
       then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using positive_add_negative T1 by auto
  qed  
next
  case False
  hence F1: "i <0" by auto
  show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
  proof(cases "j \<ge>0")
    case T2: True
      have [ty]:"\<hh>2\<ss>\<^sub>\<int>(i) is Integer" "\<hh>2\<ss>\<^sub>\<int>(j) is Integer" using h2sZprop[of i] h2sZprop[of j] by mty auto
    have "\<hh>2\<ss>\<^sub>\<int>(j+\<^sub>\<H>i)= \<hh>2\<ss>\<^sub>\<int>(j) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i)" using T2 positive_add_negative F1 by auto
        also have "...= \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using real_0_th_11   by mty auto
      finally show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) =\<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using h2sZp by auto
    next
      case  False
        hence F2:"j <0" by auto
        let ?I = "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))" let ?J = "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(j)))"  let ?IJ = "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i+\<^sub>\<H>j)))" 
        have [ty]: "?I is Nat" "?J is Nat"  using I2Mprop h2sZprop by auto
        have F3: "i+\<^sub>\<H>j<0" using F1 F2 by auto
        hence D1: "?IJ <>{}" " \<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = [{},?IJ]" using \<hh>2\<ss>_less_zero[of "i+\<^sub>\<H>j"] by auto
        hence D2: "?I <>{}" " \<hh>2\<ss>\<^sub>\<int>(i) = [{},?I]" "?J <>{}" " \<hh>2\<ss>\<^sub>\<int>(j) = [{},?J]" 
          using F1 F2 \<hh>2\<ss>_less_zero by auto+
        hence [ty]: "[{},?I] is Integer" 
             "[{},?J] is Integer" using h2sZprop[of i] h2sZprop[of j] by auto
        have H1: "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H>(i+\<^sub>\<H>j)) = \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i)+\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> j)" using  positive_add_positive[of "-\<^sub>\<H> i" "-\<^sub>\<H> j"] F1 F2 by auto
        have H2: "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H>(i+\<^sub>\<H>j)) = ?IJ" "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> j ) = ?J" "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i ) = ?I" using F1 F2 F3 by auto
        hence "?I +\<^sub>\<S>\<^sup>\<real> ?J = ?I +\<^sub>\<S>\<^sup>\<nat> ?J" using int_1_def_3[of ?I ?J,simplified] by mty auto
        hence D3: "?I +\<^sub>\<S>\<^sup>\<nat> ?J = ?IJ" using H1 H2 by auto

       have "[{},?I] +\<^sub>\<S>\<^sup>\<real> [{},?J] = [{}, (?I +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?J)]"
          using real_0_def_4[of "[{},?I]" "[{},?J]",simplified] using Prat_Preal_add by mty auto
      hence "[{},?I] +\<^sub>\<S>\<^sup>\<real> [{},?J] = [{}, (?I +\<^sub>\<S>\<^sup>\<nat> ?J)]"
          using arytm_3_th_58 by mty auto
        then show "\<hh>2\<ss>\<^sub>\<int>(i+\<^sub>\<H>j) = \<hh>2\<ss>\<^sub>\<int>(i) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using D1 D2 D3 by auto
      qed
qed

theorem AddIntM:
  assumes [ty]: "i is Integer" "j is Integer"
  shows "\<ss>2\<hh>\<^sub>\<int>(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<int>(i) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)"
proof-
  have "i +\<^sub>\<S>\<^sup>\<real> j = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) +\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(j))" using MIMZprop by mty auto
  hence "i +\<^sub>\<S>\<^sup>\<real> j = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j))" using AddIntI[of "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<int>(j)"] by auto
  then show "\<ss>2\<hh>\<^sub>\<int>(i +\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)" using IMIZprop[of "\<ss>2\<hh>\<^sub>\<int>(i) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)"]  by auto 
qed


theorem \<hh>2\<ss>_less_eq_zero:
  "i \<le>0 implies \<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i)"
proof
  assume A1: "i \<le>0"
  have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) is Nat" using I2Mprop by auto
  show "\<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i)" 
  proof (cases "i=\<^sub>\<H> 0")
    case True
    hence "\<hh>2\<ss>\<^sub>\<int>(i) = {}" "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i) = {}" by auto
    then show "\<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i)" using real_0_th_18 by auto
  next
    have [ty]: "\<hh>2\<ss>\<^sub>\<int>(i) is Integer" using h2sZprop[of i] by mty auto
    case False
    hence A2: "i<0" using A1 by auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) <> {} & \<hh>2\<ss>\<^sub>\<int>(i) = [{},\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))]" 
      using \<hh>2\<ss>_less_zero by auto
    hence "-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i) = \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))" using  real_0_th_17 by mty auto
    hence "-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i) = \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H>(i))" using  A2 by auto
    then show "\<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H>(i))" using real_0_th_20a[of "\<hh>2\<ss>\<^sub>\<int>(i)"]  by mty auto
  qed
qed

theorem \<hh>2\<ss>_less_eq_zero_1:
  "i \<le>0 implies -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i) = \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i)"
proof
  have [ty]:"\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i) is Integer" using h2sZprop by mty auto
  assume "i \<le>0"
  hence "\<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H>(i))" using \<hh>2\<ss>_less_eq_zero by auto
  then show "-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i) = \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H>(i))"  using real_0_th_20a[of "\<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> i)"]  by mty auto
qed

theorem \<hh>2\<ss>_less_eq_zero_not_nat:
  "i <0 implies not \<hh>2\<ss>\<^sub>\<int>(i) is natural"
proof
  assume "i <0"
  hence "\<hh>2\<ss>\<^sub>\<int>(i) = [{},\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))]"  using \<hh>2\<ss>_less_zero by auto
  then show "not \<hh>2\<ss>\<^sub>\<int>(i) is natural" by mty auto
qed

theorem \<hh>2\<ss>_greater_zero:
  "0 < i iff \<hh>2\<ss>\<^sub>\<int>(i) is natural \<and> \<hh>2\<ss>\<^sub>\<int>(i)<>{}"
proof(rule iffI3)
  show "0 < i \<longrightarrow> \<hh>2\<ss>\<^sub>\<int>(i) be natural \<and> \<hh>2\<ss>\<^sub>\<int>(i) \<noteq> {}"
  proof(rule impI,rule ccontr)
    assume AS: "0<i" "not( \<hh>2\<ss>\<^sub>\<int>(i) be natural \<and> \<hh>2\<ss>\<^sub>\<int>(i) \<noteq> {})"
    hence "\<hh>2\<ss>\<^sub>\<int>(i) \<noteq> {}" using IMIZprop[of i] by mty auto   
    thus False using AS  using I2Mprop  by mty auto
  qed
  assume AS: "\<hh>2\<ss>\<^sub>\<int>(i) be natural \<and> \<hh>2\<ss>\<^sub>\<int>(i) \<noteq> {}"
  hence N: "not (i=\<^sub>\<H>0)" by auto
  hence "i \<ge>0" using \<hh>2\<ss>_less_eq_zero_not_nat[of i] h2sZ.elims[of i] AS by blast
  thus "0 < i" using N by auto
qed


theorem MultIntI:
  "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
proof(cases "i\<ge>0")
  case T1:True
  hence [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(i)) is Nat" and "\<hh>2\<ss>\<^sub>\<nat>(nat(i)) =\<hh>2\<ss>\<^sub>\<int>(i)" using I2Mprop by auto
  hence [ty]: "\<hh>2\<ss>\<^sub>\<int>(i) is Nat" by auto
  have [ty]: "\<hh>2\<ss>\<^sub>\<int>(i) is Integer" "\<hh>2\<ss>\<^sub>\<int>(j) is Integer" 
    using h2sZprop by auto
  show "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
  proof(cases "j \<ge> 0")
    case T2: True
       have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(j)) is Nat"  using I2Mprop by auto
       have "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<nat>(nat(i *\<^sub>\<H> j))" using T1 T2 by auto
       also have "... =\<^sub>\<H> \<hh>2\<ss>\<^sub>\<nat>(nat(i) *\<^sub>\<H> nat (j)) " using nat_mult_distrib T1 T2 by auto
       also have "... =\<^sub>\<H> \<hh>2\<ss>\<^sub>\<nat>(nat(i)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(nat (j)) " using MultI by auto
       also have "... =\<^sub>\<H> \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using T1 T2 int_1_def_5[of "\<hh>2\<ss>\<^sub>\<int>(i)" "\<hh>2\<ss>\<^sub>\<int>(j)", simplified] by auto
       finally show "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" by auto
     next
       case F2:False
       hence [ty]: "not \<hh>2\<ss>\<^sub>\<int>(j) is natural" using \<hh>2\<ss>_less_eq_zero_not_nat by auto
       have "j \<le> 0" using F2 by auto
         hence F3: "i *\<^sub>\<H> j \<le> 0" using T1 mult_nonneg_nonpos by auto 
         have F5: "-\<^sub>\<H> j \<ge>0" using F2 by auto
         hence F4: "i *\<^sub>\<H> (-\<^sub>\<H> j) \<ge>0" using T1 mult_nonneg_nonneg by blast
         hence "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> (i *\<^sub>\<H> j))" using F3 \<hh>2\<ss>_less_eq_zero by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> (-\<^sub>\<H> j))" by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(i *\<^sub>\<H> (-\<^sub>\<H> j)))" using F4 by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(i) *\<^sub>\<H> nat(-\<^sub>\<H> j)) " using nat_mult_distrib T1 F5 by presburger
         also have "... = -\<^sub>\<S>\<^sup>\<real> (\<hh>2\<ss>\<^sub>\<nat>(nat(i)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(nat (-\<^sub>\<H> j))) " using MultI by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> (\<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(nat (-\<^sub>\<H> j))) " using T1 by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> (\<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j))) " using F5 \<hh>2\<ss>_less_eq_zero_1 by auto
         also have "... = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real>  \<hh>2\<ss>\<^sub>\<int>(j)" using int_1_def_5[of "\<hh>2\<ss>\<^sub>\<int>(i)"]  by auto
      finally show "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" by auto
  qed
next
  case F1: False
       hence [ty]: "not \<hh>2\<ss>\<^sub>\<int>(i) is natural" using \<hh>2\<ss>_less_eq_zero_not_nat by auto
       have I: "i \<le> 0" using F1 by auto
       have F5: "-\<^sub>\<H> i \<ge>0" using F1 by auto
       have [ty]: "\<hh>2\<ss>\<^sub>\<int>(i) is Integer" "\<hh>2\<ss>\<^sub>\<int>(j) is Integer" 
        using h2sZprop by auto

       show "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)"
       proof(cases "j \<ge> 0")
         case T1: True
           hence [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(j)) is Nat" and "\<hh>2\<ss>\<^sub>\<nat>(nat(j)) =\<hh>2\<ss>\<^sub>\<int>(j)" using I2Mprop by auto
           hence [ty]: "\<hh>2\<ss>\<^sub>\<int>(j) is Nat" by auto
           have F3: "i *\<^sub>\<H> j \<le> 0" using T1 mult_nonpos_nonneg[of i j] I by auto     
           have F4: "(-\<^sub>\<H> i) *\<^sub>\<H> j \<ge>0" using T1 mult_nonneg_nonneg F5 by blast
           hence "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(-\<^sub>\<H> (i *\<^sub>\<H> j))" using F3 \<hh>2\<ss>_less_eq_zero by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> (-\<^sub>\<H> j))" by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat((-\<^sub>\<H> i) *\<^sub>\<H> j))" using F4 by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H> i) *\<^sub>\<H> nat(j)) " using nat_mult_distrib T1 F5 by presburger
         also have "... = -\<^sub>\<S>\<^sup>\<real> (\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H> i)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(nat (j))) " using MultI by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> (\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H> i)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<int>(j)) " using T1 by auto
         also have "... = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<int>(j) ) " using F5 \<hh>2\<ss>_less_eq_zero_1 by auto
         also have "... = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real>  \<hh>2\<ss>\<^sub>\<int>(j)" using int_1_def_5[of "\<hh>2\<ss>\<^sub>\<int>(i)"]  by auto
      finally show "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" by auto
    next case G1: False
       hence [ty]: "not \<hh>2\<ss>\<^sub>\<int>(j) is natural" using \<hh>2\<ss>_less_eq_zero_not_nat by auto
       have I: "j \<le> 0" using G1 by auto
       have G5: "-\<^sub>\<H> j \<ge>0" using G1 by auto
       have "-\<^sub>\<H> i >0 " "-\<^sub>\<H> j>0" using F1 G1 by auto
       hence G4: "(-\<^sub>\<H> i) *\<^sub>\<H> (-\<^sub>\<H> j) >0"  using mult_pos_pos by blast
       have  "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>((-\<^sub>\<H> i) *\<^sub>\<H> (-\<^sub>\<H> j))" by auto
       also have "... = \<hh>2\<ss>\<^sub>\<nat>(nat ((-\<^sub>\<H> i) *\<^sub>\<H> (-\<^sub>\<H> j)))" using G4 by auto
       also have "... = \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H> i) *\<^sub>\<H> nat (-\<^sub>\<H> j)) " using nat_mult_distrib G5 F5 by presburger 
       also have "... = \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H> i)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(nat (-\<^sub>\<H> j)) " using MultI by auto
       also have "... = (-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(i)) *\<^sub>\<S>\<^sup>\<nat> (-\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)) " using \<hh>2\<ss>_less_eq_zero_1 G5 F5  by auto
       also have "... = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" using int_1_def_5[of "\<hh>2\<ss>\<^sub>\<int>(i)" "\<hh>2\<ss>\<^sub>\<int>(j)", simplified] by auto
       finally show "\<hh>2\<ss>\<^sub>\<int>(i *\<^sub>\<H> j) = \<hh>2\<ss>\<^sub>\<int>(i) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(j)" by auto
     qed
qed

theorem MultIntM:
  assumes [ty]: "i is Integer" "j is Integer"
  shows "\<ss>2\<hh>\<^sub>\<int>(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)"
proof-
  have "i *\<^sub>\<S>\<^sup>\<real> j = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(j))" using MIMZprop by mty auto
  hence "i *\<^sub>\<S>\<^sup>\<real> j = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j))" using MultIntI[of "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<int>(j)"] by auto
  then show "\<ss>2\<hh>\<^sub>\<int>(i *\<^sub>\<S>\<^sup>\<real> j) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)" using IMIZprop[of "\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)"]  by auto 
qed

theorem AssociativeInt:
  assumes [ty]:"i is Integer" "j is Integer" "k is Integer"
  shows "(i *\<^sub>\<S>\<^sup>\<real> j) *\<^sub>\<S>\<^sup>\<real> k = i *\<^sub>\<S>\<^sup>\<real> (j*\<^sub>\<S>\<^sup>\<real> k)"
proof-
  have [ty]: "i*\<^sub>\<S>\<^sup>\<real> j is Integer" "j*\<^sub>\<S>\<^sup>\<real> k is Integer" by mty auto
  have R: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(k)) = k" "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i*\<^sub>\<S>\<^sup>\<real> j)) = i*\<^sub>\<S>\<^sup>\<real> j" using beIsoT_e[OF beIsoT_Int] by auto

   have L: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i" "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(j*\<^sub>\<S>\<^sup>\<real> k)) = j*\<^sub>\<S>\<^sup>\<real> k" using beIsoT_e[OF beIsoT_Int] by auto  
  have "(i *\<^sub>\<S>\<^sup>\<real> j) *\<^sub>\<S>\<^sup>\<real> k = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i *\<^sub>\<S>\<^sup>\<real> j) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k))" using MultIntI R by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k))" using MultIntM by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(j) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k)))"
    by (simp add: semiring_normalization_rules(18))
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j *\<^sub>\<S>\<^sup>\<real> k))" using MultIntM by auto
  also have "... =i *\<^sub>\<S>\<^sup>\<real> (j*\<^sub>\<S>\<^sup>\<real> k)" using MultIntI L by auto 
  finally show ?thesis by simp
qed

theorem unitalInt:
  assumes [ty]:"i is Integer"
  shows "i *\<^sub>\<S>\<^sup>\<real> (succ {}) = i" "(succ {}) *\<^sub>\<S>\<^sup>\<real> i = i"
proof-
  let ?S = "succ {}"
  have "\<ss>2\<hh>\<^sub>\<nat>(succ {}) =\<^sub>\<H> 1" using EqSuc[of "{}"] by mty auto
  hence M: "\<ss>2\<hh>\<^sub>\<int>(?S) =\<^sub>\<H> 1" using s2hZ.simps[of ?S] by mty auto
  have  "?S is Integer"  by mty auto
  hence L: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i" "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(?S)) = ?S"  using beIsoT_e[OF beIsoT_Int] by auto  
  hence "(i *\<^sub>\<S>\<^sup>\<real> ?S) = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> 1)" using MultIntI[of "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<int>(?S)"] M by mty auto
  then show "(i *\<^sub>\<S>\<^sup>\<real> ?S) = i" using L by mty auto
  have "(?S *\<^sub>\<S>\<^sup>\<real> i) = \<hh>2\<ss>\<^sub>\<int>(1 *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i))" using MultIntI[of "\<ss>2\<hh>\<^sub>\<int>(?S)" "\<ss>2\<hh>\<^sub>\<int>(i)" ] M L by mty auto
  then show "(?S *\<^sub>\<S>\<^sup>\<real> i) = i" using L by mty auto
qed

theorem AbelianInt:
  assumes [ty]:"i is Integer" "j is Integer"
  shows "i *\<^sub>\<S>\<^sup>\<real> j = j *\<^sub>\<S>\<^sup>\<real> i"
proof-
  have  R: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i" "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(j)) = j" using beIsoT_e[OF beIsoT_Int] by auto
  have "i *\<^sub>\<S>\<^sup>\<real> j = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j))" using MultIntI R by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(j) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i))" by (simp add: mult.commute)
  also have "... = j *\<^sub>\<S>\<^sup>\<real> i" using MultIntI R by auto
  finally show ?thesis by auto
qed


theorem distributiveInt:
  assumes [ty]:"i is Integer" "j is Integer" "k is Integer"
  shows "(i +\<^sub>\<S>\<^sup>\<real> j) *\<^sub>\<S>\<^sup>\<real> k = (i *\<^sub>\<S>\<^sup>\<real> k) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> k)"
proof-
  have W[ty]: "i+\<^sub>\<S>\<^sup>\<real> j is Integer" "j*\<^sub>\<S>\<^sup>\<real> k is Integer"  "i*\<^sub>\<S>\<^sup>\<real> k is Integer" by mty auto
  have R: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(k)) = k" "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i+\<^sub>\<S>\<^sup>\<real> j)) = i+\<^sub>\<S>\<^sup>\<real> j" using beIsoT_e[OF beIsoT_Int] by auto

 have L: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i*\<^sub>\<S>\<^sup>\<real> k)) = i*\<^sub>\<S>\<^sup>\<real> k" "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(j*\<^sub>\<S>\<^sup>\<real> k)) = j*\<^sub>\<S>\<^sup>\<real> k" using beIsoT_e[OF beIsoT_Int] by auto  
  
  have "(i +\<^sub>\<S>\<^sup>\<real> j) *\<^sub>\<S>\<^sup>\<real> k = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i +\<^sub>\<S>\<^sup>\<real> j) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k))" using MultIntI R by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j)) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k))" using AddIntM by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k)) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(j) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(k)))"
     using int_distrib(1) by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i *\<^sub>\<S>\<^sup>\<real> k) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(j *\<^sub>\<S>\<^sup>\<real> k))" using MultIntM by auto
  also have "... = (i *\<^sub>\<S>\<^sup>\<real> k) +\<^sub>\<S>\<^sup>\<real> (j *\<^sub>\<S>\<^sup>\<real> k)" using AddIntI L by auto 
  finally show ?thesis by simp
qed


theorem leqZ:   
  "\<hh>2\<ss>\<^sub>\<int>(i) is Nat \<longleftrightarrow> i \<ge>0"
proof(rule iffI2)
  show "\<hh>2\<ss>\<^sub>\<int>(i) is Nat \<longrightarrow> i \<ge>0"
  proof(rule impI, rule ccontr)
    assume A[ty]: "\<hh>2\<ss>\<^sub>\<int>(i) is Nat"
    have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) is Nat" using I2Mprop by mty auto 
    assume "\<not> 0 \<le> i"
    hence L: "i <0" by linarith
    hence A2: "\<hh>2\<ss>\<^sub>\<int>(i) = -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))" using h2sZ.psimps[of i] by auto
    hence A1:" -\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i))) is Nat" using h2sZ.psimps[of i] A by auto    
    hence A3: "\<hh>2\<ss>\<^sub>\<int>(i) = {}" using int_1_th0[of "\<hh>2\<ss>\<^sub>\<nat>(nat(-\<^sub>\<H>(i)))"] A2 by mty auto
    have "\<ss>2\<hh>\<^sub>\<int>({}) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>({})" using  s2hZ.simps by mty auto
    hence "i =\<^sub>\<H> 0" using IMIZprop[of i] s2hZ.simps s2hn.simps A3 by auto
    thus False using L by auto
  qed   
  show "i \<ge>0 \<longrightarrow> (\<hh>2\<ss>\<^sub>\<int>(i) is Nat)" using h2sZ.psimps I2Mprop by mty auto
qed


theorem zeroZ:   
  "\<hh>2\<ss>\<^sub>\<int>(i) ={} \<longleftrightarrow> i =\<^sub>\<H> 0"
proof
    assume A1: "\<hh>2\<ss>\<^sub>\<int>(i) =\<^sub>\<S> {}"
    have "\<ss>2\<hh>\<^sub>\<int>({}) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>({})" by mty auto
    thus "i =\<^sub>\<H> 0" using IMIZprop[of i]  A1 by auto
  next
    assume "i =\<^sub>\<H> 0"
    hence "\<hh>2\<ss>\<^sub>\<int>(i) =\<^sub>\<H> \<hh>2\<ss>\<^sub>\<nat>(0)"  by mty auto
    thus "\<hh>2\<ss>\<^sub>\<int>(i) ={}" by auto
qed

theorem lessZ:   
  "\<hh>2\<ss>\<^sub>\<int>(i) is Nat & \<hh>2\<ss>\<^sub>\<int>(i) <>{} \<longleftrightarrow> i > 0" 
using zeroZ[of i] leqZ[of i] by auto


text_raw {*\DefineSnippet{intpower}{*}
definition int_power :: "Set \<Rightarrow> Set \<Rightarrow> Set" ("_ I^ _"[100,100] 100 ) where
  "int_power \<equiv>  TransformHS(\<ss>2\<hh>\<^sub>\<int>,\<ss>2\<hh>\<^sub>\<nat>,\<hh>2\<ss>\<^sub>\<int>,(^))"
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{intpowerprop}{*}
mtheorem 
  mlet "i be Integer","n be Nat"
  "cluster i I^ n  \<rightarrow> Integer"
text_raw {*}%EndSnippet*}
 unfolding int_power_def using TransformHS_typeT[OF beIsoT_Int,of "\<ss>2\<hh>\<^sub>\<int>" "\<ss>2\<hh>\<^sub>\<nat>"] by auto

theorem power_MM:
  assumes [ty]: "i be Integer" "n be Nat"
  shows "i I^ n = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n))" 
unfolding int_power_def using 
    Transform_MIT[OF beIsoT_Int beIsoT_Nat,of h2sZ "(^)" "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<nat>(n)"] 
     MIMZprop[of i] MIMprop[of n] by auto

theorem power_MI:
  assumes [ty]: "i be Integer" "n be Nat"
  shows "\<ss>2\<hh>\<^sub>\<int>(i I^ n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n)" 
  using power_MM[of i n] IMIZprop[of "\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n)"] by auto


text_raw {*\DefineSnippet{power0}{*}
theorem power_01: 
  assumes "i be Integer"
  shows "i I^ 0\<^sub>\<S> =\<^sub>\<S> 1\<^sub>\<S>" and "i I^ 1\<^sub>\<S> =\<^sub>\<S> i"
text_raw {*}%EndSnippet*}
proof-
  have I: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i" "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>({}))={}" using  assms MIMZprop by auto 
  hence "(i I^ {}) = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>({}))" unfolding int_power_def 
    using Transform_MIT[OF beIsoT_Int beIsoT_Nat,of h2sZ "(^)" "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<nat>({})"] by auto
  then show "i I^ {} = 1\<^sub>\<S>" by auto
    have I: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i" "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>))=1\<^sub>\<S>" using  MIMZprop MIMprop[of "1\<^sub>\<S>"] assms by mty auto 
    hence "(i I^ 1\<^sub>\<S>) = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>))" unfolding int_power_def 
    using Transform_MIT[OF beIsoT_Int beIsoT_Nat,of h2sZ "(^)" "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>)"] I by auto
  then show "i I^ 1\<^sub>\<S> = i" using I  EqSuc[of "{}"] by mty auto

qed

text_raw {*\DefineSnippet{powersum}{*}
theorem power_sum: 
  assumes "i be Integer" and "n1 be Nat" and "n2 be Nat"
  shows "i I^ (n1 +\<^sub>\<S>\<^sup>\<nat> n2) =\<^sub>\<S> (i I^ n1) *\<^sub>\<S>\<^sup>\<real> (i I^ n2)"
text_raw {*}%EndSnippet*}
proof-
  have [ty]:"n1 be Nat" "n2 be Nat" using assms by auto
  have N:  "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(n1))=n1" "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(n2))=n2" using MIMprop[of n1] MIMprop[of n2] assms by auto
  have I: "\<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i)) = i" "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(n1 +\<^sub>\<S>\<^sup>\<nat> n2))=n1 +\<^sub>\<S>\<^sup>\<nat> n2" using MIMprop[of "n1 +\<^sub>\<S>\<^sup>\<nat> n2"] MIMZprop[of i] assms by mty auto 
  hence "(i I^ (n1 +\<^sub>\<S>\<^sup>\<nat> n2)) = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n1 +\<^sub>\<S>\<^sup>\<nat> n2))" unfolding int_power_def 
    using Transform_MIT[OF beIsoT_Int beIsoT_Nat,of h2sZ "(^)" "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<nat>(n1 +\<^sub>\<S>\<^sup>\<nat> n2)"] by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(i) ^ (\<ss>2\<hh>\<^sub>\<nat>(n1)+\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n2)))" using AddM by auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n1)) *\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n2)))" by (simp add:power_add)
  also have "... = \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n1))) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n2)))" using MultIntI  by auto
  also have "... = (i I^ n1) *\<^sub>\<S>\<^sup>\<real> \<hh>2\<ss>\<^sub>\<int>((\<ss>2\<hh>\<^sub>\<int>(i) ^ \<ss>2\<hh>\<^sub>\<nat>(n2)))"  unfolding int_power_def 
    using Transform_MIT[OF beIsoT_Int beIsoT_Nat,of h2sZ "(^)" "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<nat>(n1)"] N I by auto
  also have "... = (i I^ n1) *\<^sub>\<S>\<^sup>\<real> (i I^ n2)"  unfolding int_power_def 
    using Transform_MIT[OF beIsoT_Int beIsoT_Nat,of h2sZ "(^)" "\<ss>2\<hh>\<^sub>\<int>(i)" "\<ss>2\<hh>\<^sub>\<nat>(n2)"] N I by auto
  finally show "i I^ (n1 +\<^sub>\<S>\<^sup>\<nat> n2) = (i I^ n1) *\<^sub>\<S>\<^sup>\<real> (i I^ n2)" by auto
qed



text_raw {*\DefineSnippet{fermat3}{*}
theorem Fermat_3:
  "\<forall>x:Integer. \<forall>y:Integer. \<forall>z:Integer. 
     (x I^ 3\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (y I^3\<^sub>\<S>) = z I^ 3\<^sub>\<S> \<longrightarrow> x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z =\<^sub>\<S> 0\<^sub>\<S>"
text_raw {*}%EndSnippet*}
proof(intro ballI impI)
  fix x y z assume [ty]:"x be Integer" "y be Integer" "z be Integer" and 
    A1: "(x I^ 3\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (y I^3\<^sub>\<S>) = z I^ 3\<^sub>\<S>"
  have [ty]:"3\<^sub>\<S> is Nat" by mty auto
  have "\<ss>2\<hh>\<^sub>\<int>(z) ^ 3 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z) ^ \<ss>2\<hh>\<^sub>\<nat>(3\<^sub>\<S>)" using Two_Three_Four by auto
  also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z I^ 3\<^sub>\<S>)" using power_MI[of _ "3\<^sub>\<S>"]  by auto
  also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>((x I^ 3\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (y I^3\<^sub>\<S>))" using A1 by auto
  also have "...  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(x I^ 3\<^sub>\<S>) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y I^3\<^sub>\<S>))" 
    using AddIntM[of "x I^ 3\<^sub>\<S>" "y I^ 3\<^sub>\<S>",simplified]  by mty auto
  also have "... =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(x) ^ \<ss>2\<hh>\<^sub>\<nat>(3\<^sub>\<S>)) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y) ^ \<ss>2\<hh>\<^sub>\<nat>(3\<^sub>\<S>))" using power_MI[of _ "3\<^sub>\<S>"]  by auto
  also have "... =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(x) ^ 3) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y) ^ 3)" using Two_Three_Four by auto
  finally have A2: "\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z) =\<^sub>\<H> 0" using fermat_3 by auto
 
  have "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>((x *\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^sup>\<real> z))" using MIMZprop by mty auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z))" using MultIntM by mty auto
  also have "... = 0\<^sub>\<S>" using A2 Zero_One by auto
  finally show  "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>" by auto
qed mauto

theorem  Fermat_3dvd:
  "for x,y,z be Integer holds
      for n be Nat st 3\<^sub>\<S> divides n & (x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n) = z I^ n
      holds x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>"
proof(intro ballI impI)
  fix x y z n assume [ty]:"x be Integer" "y be Integer" "z be Integer" "n be Nat" and 
    A1: "3\<^sub>\<S> divides n & (x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n) = z I^ n"  
  have [ty]: "x I^ n is Integer" "y I^ n is Integer" by mty auto
  let ?n="\<ss>2\<hh>\<^sub>\<nat>(n)"
  have "\<ss>2\<hh>\<^sub>\<nat>(3\<^sub>\<S>)  dvd ?n" using dividesM[of n "3\<^sub>\<S>"] A1 by mty auto
  hence A2: "3 dvd ?n" using Two_Three_Four by auto
  have "\<ss>2\<hh>\<^sub>\<int>(z) ^ ?n =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<int>(z I^ n)" using power_MI[of _ n]  by auto
  also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>((x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n))" using A1 by auto
  also have "...  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(x I^ n) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y I^n))" 
    using AddIntM[of "x I^ n" "y I^ n",simplified]  by mty auto
  also have "... =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(x) ^ ?n) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y) ^ ?n)" using power_MI[of _ n]  by auto
  finally have A2: "\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z) =\<^sub>\<H> 0" using fermat_mult3[OF _ A2] by auto
 
  have "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>((x *\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^sup>\<real> z))" using MIMZprop by mty auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z))" using MultIntM by mty auto
  also have "... = 0\<^sub>\<S>" using A2 Zero_One by auto
  finally show  "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>" by auto
qed mauto

theorem Fermat_4:
  "for x,y,z be Integer st (x I^ 4\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (y I^4\<^sub>\<S>) = z I^ 4\<^sub>\<S>
      holds x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>"
proof(intro ballI impI)
  fix x y z assume [ty]:"x be Integer" "y be Integer" "z be Integer" and 
    A1: "(x I^ 4\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (y I^4\<^sub>\<S>) = z I^ 4\<^sub>\<S>"
  have [ty]:"4\<^sub>\<S> is Nat" by mty auto
  have "\<ss>2\<hh>\<^sub>\<int>(z) ^ 4 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z) ^ \<ss>2\<hh>\<^sub>\<nat>(4\<^sub>\<S>)" using Two_Three_Four by auto
  also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z I^ 4\<^sub>\<S>)" using power_MI[of _ "4\<^sub>\<S>"]  by auto
  also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>((x I^ 4\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (y I^4\<^sub>\<S>))" using A1 by auto
  also have "...  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(x I^ 4\<^sub>\<S>) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y I^4\<^sub>\<S>))" 
    using AddIntM[of "x I^ 4\<^sub>\<S>" "y I^ 4\<^sub>\<S>",simplified]  by mty auto
  also have "... =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(x) ^ \<ss>2\<hh>\<^sub>\<nat>(4\<^sub>\<S>)) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y) ^ \<ss>2\<hh>\<^sub>\<nat>(4\<^sub>\<S>))" using power_MI[of _ "4\<^sub>\<S>"]  by auto
  also have "... =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(x) ^ 4) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y) ^ 4)" using Two_Three_Four by auto
  finally have A2: "\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z) =\<^sub>\<H> 0" using fermat_4 by auto
 
  have "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>((x *\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^sup>\<real> z))" using MIMZprop by mty auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z))" using MultIntM by mty auto
  also have "... = 0\<^sub>\<S>" using A2 Zero_One by auto
  finally show  "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>" by auto
qed mauto


theorem  Fermat_4dvd:
  "for x,y,z be Integer holds
      for n be Nat st 4\<^sub>\<S> divides n & (x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n) = z I^ n
      holds x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>"
proof(intro ballI impI)
  fix x y z n assume [ty]:"x be Integer" "y be Integer" "z be Integer" "n be Nat" and 
    A1: "4\<^sub>\<S> divides n & (x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n) = z I^ n"  
  have [ty]: "x I^ n is Integer" "y I^ n is Integer" by mty auto
  let ?n="\<ss>2\<hh>\<^sub>\<nat>(n)"
  have "\<ss>2\<hh>\<^sub>\<nat>(4\<^sub>\<S>)  dvd ?n" using dividesM[of n "4\<^sub>\<S>"] A1 by mty auto
  hence A2: "4 dvd ?n" using Two_Three_Four by auto
  have "\<ss>2\<hh>\<^sub>\<int>(z) ^ ?n =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<int>(z I^ n)" using power_MI[of _ n]  by auto
  also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>((x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n))" using A1 by auto
  also have "...  =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(x I^ n) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y I^n))" 
    using AddIntM[of "x I^ n" "y I^ n",simplified]  by mty auto
  also have "... =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(x) ^ ?n) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<int>(y) ^ ?n)" using power_MI[of _ n]  by auto
  finally have A2: "\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z) =\<^sub>\<H> 0" using fermat_mult4[OF _ A2] by auto
 
  have "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>((x *\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^sup>\<real> z))" using MIMZprop by mty auto
  also have "... = \<hh>2\<ss>\<^sub>\<int>(\<ss>2\<hh>\<^sub>\<int>(x) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(y) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(z))" using MultIntM by mty auto
  also have "... = 0\<^sub>\<S>" using A2 Zero_One by auto
  finally show  "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>" by auto
qed mauto

text_raw {*\DefineSnippet{fermat34}{*}
theorem Fermat_divides_3_4:
  "\<forall>x,y,z:Integer. \<forall>n:Nat.
    (3\<^sub>\<S> divides n \<or> 4\<^sub>\<S> divides n) \<and> (x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n) =\<^sub>\<S> z I^n
   \<longrightarrow> x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z =\<^sub>\<S> 0\<^sub>\<S>"
text_raw {*}%EndSnippet*}
proof(intro ballI impI)
  fix x y z n assume [ty]:"x be Integer" "y be Integer" "z be Integer" "n be Nat" and 
     A1:"(3\<^sub>\<S> divides n or 4\<^sub>\<S> divides n) & 
                     (x I^ n) +\<^sub>\<S>\<^sup>\<real> (y I^n) = z I^ n"
  then show "x *\<^sub>\<S>\<^sup>\<real> y *\<^sub>\<S>\<^sup>\<real> z = 0\<^sub>\<S>" using Fermat_4dvd[THEN bspec,THEN bspec,THEN bspec,THEN bspec,of x y z n,simplified] 
                                    Fermat_3dvd[THEN bspec,THEN bspec,THEN bspec,THEN bspec,of x y z n,simplified] by mty auto
qed mauto

end

