theory funct_lam
  imports beiso "../mml/funct_2"
begin

(* Functions *)
text_raw {*\DefineSnippet{s2hf}{*}
definition \<ss>2\<hh>f :: "(Set \<Rightarrow> 'b) \<Rightarrow> ('a \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> ('a \<Rightarrow> 'b)" ("\<ss>2\<hh>\<^sub>f'(_,_,_')") where
  "\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f) =\<^sub>\<H> (\<lambda>x. \<ss>2\<hh>r(f.(\<hh>2\<ss>d(x))))"
text_raw {*}%EndSnippet*}

text_raw {*\DefineSnippet{h2sf}{*}
definition \<hh>2\<ss>f :: "(Set \<Rightarrow> 'a) \<Rightarrow> ('b \<Rightarrow> Set) \<Rightarrow> Set \<Rightarrow> ('a \<Rightarrow> 'b) \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>f'(_,_,_,_')") where
  "\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f) =\<^sub>\<S> the set-of-all [x,\<hh>2\<ss>r(f(\<ss>2\<hh>d(x)))] where x be Element-of d"
text_raw {*}%EndSnippet*}

theorem ItoMprop:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)" "beIsoS(\<hh>2\<ss>r,\<ss>2\<hh>r,r)"
  shows "\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f) is Function-of d,r" 
proof-
  let ?H ="\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f)"
  have [ty]:"d be set" "r be set" "?H is set" using all_set by auto 
  have [ty]: "d is non empty" using beIsoS_d assms by auto
  have [ty]:"?H is Relation_like"
  proof(standard,simp,standard,standard)
    fix x 
    assume "x in ?H"
    then obtain y where [ty]:"y be Element-of d" and
      A1: "x = [y, \<hh>2\<ss>r(f(\<ss>2\<hh>d(y)))]" using Set_of_All_ex[of  "Element-of d" ] \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] by mty auto
    then show "ex y, z be object st x = [y , z]" by auto
  qed mauto
  have [ty]:"?H is Function_like"
  proof(standard,simp,intro ballI impI)
    fix x y1 y2 
    assume A0:"[x,y1] in ?H \<and> [x,y2] in ?H"
    then obtain z1 where [ty]:"z1 be Element-of d" and
      A1: "[x,y1] = [z1, \<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))]" using Set_of_All_ex[of  "Element-of d" ] \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] by mty auto
    obtain z2 where [ty]:"z2 be Element-of d" and
      A2: "[x,y2] = [z2, \<hh>2\<ss>r(f(\<ss>2\<hh>d(z2)))]" using Set_of_All_ex[of  "Element-of d" ] \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] A0 by mty auto
    have "x = z1" "y1=\<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))" "x = z2" "y2=\<hh>2\<ss>r(f(\<ss>2\<hh>d(z2)))" using xtuple_0_th_1a A1 A2 by auto+
    then show "y1=y2" by simp
  qed mauto
  have D: "dom ?H = d"
  proof(rule xboole_0_def_10I,mauto)
    show "dom ?H c= d"
    proof(standard,auto)
      fix x assume "x in dom ?H"
      then obtain y where "y be object" and
        A1: " [x,y] in ?H" using xtuple_0_def_12 by auto 
      then obtain z1 where [ty]:"z1 be Element-of d" and
       A2: "[x,y] = [z1, \<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))]" 
         using Set_of_All_ex[of  "Element-of d" ] \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] by mty auto
      hence "z1 in d" "x = z1" using Element(7) xtuple_0_th_1a by mty auto
      then show "x in d" by simp
    qed
    show "d c= dom ?H"
    proof(standard,auto)
      fix x assume "x in d"
      hence X: "x be Element-of d" using Element(6) by auto
      have "[x, \<hh>2\<ss>r(f(\<ss>2\<hh>d(x)))] in ?H" using Set_of_All_in[OF _ X]
        \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] by auto
      then show "x in dom ?H" using xtuple_0_def_12 by auto
    qed
  qed
  have [ty]: "rng ?H is set" using all_set by auto
  have "rng ?H c= r" 
   proof(standard,auto)
      fix y assume "y in rng ?H"
      then obtain x where "x be object" and
        A1: " [x,y] in ?H" using xtuple_0_def_13 by auto 
      then obtain z1 where [ty]:"z1 be Element-of d" and
       A2: "[x,y] = [z1, \<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))]" 
         using Set_of_All_ex[of  "Element-of d" ] \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] by mty auto
       hence "y = \<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))" using Element(7) xtuple_0_th_1a by mty auto
       then show "y in r" using assms(2) beIsoS_def[of \<hh>2\<ss>r \<ss>2\<hh>r r] by auto
    qed
  then show "?H is Function-of d,r"  using D funct_2_th_3[of r ?H] by mty auto
qed

text_raw {*\DefineSnippet{itomappl}{*}
theorem HtoSappl:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)" and "beIsoS(\<hh>2\<ss>r,\<ss>2\<hh>r,r)"
  shows "\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f).\<hh>2\<ss>d(x) =\<^sub>\<S> \<hh>2\<ss>r(f(x))"
text_raw {*}%EndSnippet*}
proof-
  let ?H="\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f)"
  have [ty]: "?H is Function-of d,r" "d be set" "r be set" using ItoMprop[OF assms(1,2)] all_set 
     beIsoS_d[OF assms(1)] beIsoS_d[OF assms(2)] by auto
  have [ty]: "?H is Function" using relset_1_cl_1[of d r] by mty auto
  have "{}<>r" using beIsoS_d[OF assms(2)] xboole_0_cl_2  all_set by mty auto
  hence D: "dom ?H = d" using funct_2_def_1[of d r ?H] all_set by mty auto
  have "\<hh>2\<ss>d(x) in d" using assms beIsoS_def[of \<hh>2\<ss>d \<ss>2\<hh>d d] by auto
  hence "[\<hh>2\<ss>d(x), ?H. \<hh>2\<ss>d(x)] in ?H" using D funct_1_def_2 by auto
  then obtain z1 where [ty]:"z1 be Element-of d" and
      A1: "[\<hh>2\<ss>d(x), ?H. \<hh>2\<ss>d(x)] = [z1, \<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))]" 
    using Set_of_All_ex[of  "Element-of d" ] \<hh>2\<ss>f_def[of \<ss>2\<hh>d \<hh>2\<ss>r d f] by mty auto
  have A2: "\<hh>2\<ss>d(x) = z1" "?H. \<hh>2\<ss>d(x)=\<hh>2\<ss>r(f(\<ss>2\<hh>d(z1)))" using xtuple_0_th_1a A1 by auto
  hence "\<ss>2\<hh>d(z1) =\<^sub>\<H> x" using assms(1) beIsoS_i[of \<hh>2\<ss>d \<ss>2\<hh>d d x] by mty auto
  then show "?H. \<hh>2\<ss>d(x)=\<hh>2\<ss>r(f(x))" using A2 by auto
qed

theorem MtoIappl:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)"
          "x be Element-of d"
  shows "\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f) (\<ss>2\<hh>d(x)) =\<^sub>\<H> \<ss>2\<hh>r(f. x)"
proof-
   have "\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f) (\<ss>2\<hh>d(x)) =\<^sub>\<H> \<ss>2\<hh>r (f . (\<hh>2\<ss>d(\<ss>2\<hh>d(x))))" using \<ss>2\<hh>f_def[of \<ss>2\<hh>r \<hh>2\<ss>d f] by auto
   then show "\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f) (\<ss>2\<hh>d(x)) =\<^sub>\<H> \<ss>2\<hh>r(f. x)" using beIsoS_e[OF assms] by auto
qed


theorem MIM_fun_prop:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)" "beIsoS(\<hh>2\<ss>r,\<ss>2\<hh>r,r)" and
          [ty]: "f be Function-of d,r"
  shows "\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f)) = f"
proof(rule funct_2_def_7I,simp add:all_set,simp add:all_set)
  have [ty]:"d be non empty\<bar>set" "r be non empty\<bar>set" 
    using all_set beIsoS_d[OF assms(1)] beIsoS_d[OF assms(2)]by auto
  let ?M="\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f)" let ?I="\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,?M)"
  show "?I is Function-of d, r" "f is Function-of d, r" using assms ItoMprop[of \<hh>2\<ss>d \<ss>2\<hh>d d \<hh>2\<ss>r] by auto
  show "for a be Element-of d holds ?I . a = f . a"
  proof
    fix a assume [ty]: "a be Element-of d"     
    hence [ty]: "f . a be Element-of r" using funct_2_def_5[of d r f a] by auto
    have "\<hh>2\<ss>d(\<ss>2\<hh>d(a)) = a" using beIsoS_e[OF assms(1), of a] by auto
    hence A2:"?I .a = \<hh>2\<ss>r(?M(\<ss>2\<hh>d(a)))" using HtoSappl[OF assms(1,2), of ?M "\<ss>2\<hh>d(a)"] by auto
    have A3:"?M(\<ss>2\<hh>d(a)) =\<^sub>\<H> \<ss>2\<hh>r(f. a)" using MtoIappl[OF assms(1),of a \<ss>2\<hh>r] by auto
    have "\<hh>2\<ss>r(\<ss>2\<hh>r(f. a)) = f. a" using beIsoS_e[OF assms(2), of "f. a"] by auto
    then show "?I . a = f . a" using A2 A3 by auto
  qed mauto
qed

theorem IMI_fun_prop:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)" "beIsoS(\<hh>2\<ss>r,\<ss>2\<hh>r,r)"
  shows "\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f)) =\<^sub>\<H> f"
proof
  fix x
  let ?I="\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f)"
  let ?M="\<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,?I)"
  have "\<hh>2\<ss>d(x) in d" using  beIsoS_def[of \<hh>2\<ss>d \<ss>2\<hh>d d] assms(1) by auto
  hence [ty]: "\<hh>2\<ss>d(x) is Element-of d" using Element(6) all_set by auto
  have A1: "?I. \<hh>2\<ss>d(x) =\<hh>2\<ss>r(f(x))" using HtoSappl[OF assms(1,2)] by auto
  have "\<ss>2\<hh>d(\<hh>2\<ss>d(x)) =\<^sub>\<H> x" using beIsoS_i[OF assms(1)] by auto
  hence "?M(x) =\<^sub>\<H> \<ss>2\<hh>r(\<hh>2\<ss>r(f(x)))" using A1 MtoIappl[OF assms(1), of "\<hh>2\<ss>d(x)" \<ss>2\<hh>r ?I] by auto
  then show "?M(x) =\<^sub>\<H> f(x)" using beIsoS_i[OF assms(2)] by auto
qed



theorem beIsoS_Funcs:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)" "beIsoS(\<hh>2\<ss>r,\<ss>2\<hh>r,r)" 
  shows "beIsoS(\<lambda>f. \<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f),\<lambda>f. \<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f),Funcs(d,r))"
   unfolding beIsoS_def
 proof(intro conjI)
    have [ty]: "d be set" "r be set" using all_set by auto 
    show "\<forall>\<^sub>Ly. \<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r, \<hh>2\<ss>d, \<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d, \<hh>2\<ss>r, d, y)) =\<^sub>\<H> y"  using IMI_fun_prop[OF assms(1,2)] by auto
    show "for x be Element-of Funcs( d , r ) holds \<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d, \<hh>2\<ss>r, d, \<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r, \<hh>2\<ss>d, x)) = x"
    proof(auto)
      have [ty]: "r be non empty" using beIsoS_d[OF assms(2)] by auto
      fix  x assume A1: "x be Element-of Funcs( d , r )"
      have "Funcs( d , r ) is non empty" by mty auto
      hence "x in Funcs( d , r )" using Element(7)[OF _ A1] by auto
      then obtain f where [ty]:"f be Function" and
         A2: "x=f" "dom f=d" "rng f c= r" using funct_2_def_2[of d r x] by mty auto
      hence "f be Function-of d,r" using funct_2_th_3 by auto
      then show "\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d, \<hh>2\<ss>r, d, \<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r, \<hh>2\<ss>d, x)) = x" using MIM_fun_prop[OF assms, of f] A2 by auto
    qed
    show "\<forall>\<^sub>Ly. \<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d, \<hh>2\<ss>r, d, y) in Funcs( d , r )"
    proof
      fix y let ?F =  "\<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d, \<hh>2\<ss>r, d, y)"
      have [ty]: "?F is Function-of d,r" using ItoMprop[OF assms] by auto
      have [ty]: "?F is Function" using relset_1_cl_1[of d r ?F] by mty auto
      have  "{}<>r" using beIsoS_d[OF assms(2)] xboole_0_cl_2  all_set by mty auto
      hence "dom ?F = d" "rng ?F c= r" using funct_2_def_1[of d r ?F] all_set relat_1_def_19E by mty auto
      then show "?F in Funcs(d,r)" using funct_2_def_2 by auto
    qed
  qed
text_raw {*\DefineSnippet{beIsoTF}{*}
theorem beIsoT_Function:
  assumes "beIsoS(\<hh>2\<ss>d,\<ss>2\<hh>d,d)"  "beIsoS(\<hh>2\<ss>r,\<ss>2\<hh>r,r)" 
  shows "beIsoT(\<lambda>f. \<hh>2\<ss>\<^sub>f(\<ss>2\<hh>d,\<hh>2\<ss>r,d,f),\<lambda>f. \<ss>2\<hh>\<^sub>f(\<ss>2\<hh>r,\<hh>2\<ss>d,f),Function-of d,r)"
text_raw {*}%EndSnippet*}
proof-
  have [ty]:"d is non empty\<bar>set" "r is non empty\<bar>set" using beIsoS_d assms all_set by auto
  have R: "r \<noteq> {}" using xb1 ty xboole_0_def_1 empty2 by auto
  
  have H: "\<And>x. x be Function-of d,r \<longleftrightarrow> x in Funcs( d , r )"
  proof(rule iffI3)
    fix x
    show "x be Function-of d,r \<longrightarrow> x in Funcs(d,r)"
    proof
      assume [ty]:"x be Function-of d,r" 
      have [ty]: "x be Function" using relset_1_cl_1[of d r] by mty auto 
      have dx:"dom x=d" using funct_2_def_1E[of d r x,simplified] R by mty auto
      have dy: "rng x c= r" using relat_1_def_19E[of r x,simplified] all_set by mty auto
      then show "x in Funcs(d,r)" using funct_2_def_2[of d r x] bexI[of _ x] dx by auto  
    qed
    assume "x in Funcs(d,r)"
    then obtain f where [ty]:"f be Function" and
      A1: "x=f & dom f=d & rng f c= r" using funct_2_def_2[of d r x] by mty auto
    hence "f be Function-of d,r" using funct_2_th_3 by auto
    thus "x be Function-of d,r" using A1 by auto
  qed
  show ?thesis using beIsoS_Type_Set(2)[OF H beIsoS_Funcs[OF assms]] by auto
qed

end
