theory int_ring 
  imports int_int "../mml/binop_2" "../mml/vectsp_1" ring_ring finseq_list
begin
text_raw {*\DefineSnippet{ZRing}{*}
mdef int_3_def_3 ("\<int>-ring") where 
  "func \<int>-ring \<rightarrow> strict(doubleLoopStr) equals [# 
    carrier \<mapsto> INT; 
    addF \<mapsto> addint; 
    ZeroF \<mapsto> 0\<^sub>\<S>; 
    multF \<mapsto> multint; 
    OneF \<mapsto> 1\<^sub>\<S>#]"
text_raw {*}%EndSnippet*}
proof-
  have "{} in INT" "succ{} in INT" using int_1_def_2[of "succ{}"] int_1_def_2[of "{}"] by mty auto
  hence [ty]:"{} is Element-of INT" "(succ{}) is Element-of INT" using Element(6) by mty auto
  show "[# carrierM \<mapsto> INT; addF \<mapsto> addint ; ZeroF \<mapsto> {} ; multF \<mapsto> multint ; OneF \<mapsto> succ {} #] be strict(doubleLoopStr)" by mty auto
qed

mtheorem
  "cluster \<rightarrow> integer for Element-of-struct \<int>-ring"
proof(standard,standard)
  have "[carrier,INT] in \<int>-ring" unfolding int_3_def_3 using  aggr by auto
  hence E1: "the carrier of \<int>-ring = INT" using the_selector_of_1[of "\<int>-ring" "carrier" INT] aggr by mty auto 
  fix it assume [ty]: "it be Element-of-struct \<int>-ring"
  hence "it in INT" using E1 Element(7) by mty auto
  then show "it is integer" using int_1_def_2 by auto
qed mauto

mtheorem
  "cluster \<rightarrow> Element-of-struct \<int>-ring for Integer"
proof(standard,standard)
  have "[carrier,INT] in \<int>-ring" unfolding int_3_def_3 using  aggr by auto
  hence E1: "the carrier of \<int>-ring = INT" using the_selector_of_1[of "\<int>-ring" "carrier" INT] aggr by mty auto 
  fix x assume "x be Integer"
  hence "x in the carrier of \<int>-ring" using E1 int_1_def_2 by auto
  then show "x is Element-of-struct \<int>-ring" using Element(6) by auto
qed mauto

mtheorem int_3_def_3_Zero:
  "0\<^sub>\<int>-ring = 0\<^sub>\<S>"
proof-
  have "[ZeroF,{}] in \<int>-ring" unfolding int_3_def_3 using  aggr by auto
  hence "the ZeroF of \<int>-ring = {}" using the_selector_of_1[of "\<int>-ring" ZeroF "{}"] aggr by mty auto 
  then show "0\<^sub>\<int>-ring = {}" using struct_0_def_6 by auto
qed

mtheorem int_3_def_3_One:
  "1\<^sub>\<int>-ring = 1\<^sub>\<S>"
proof-
  have "[OneF,succ {}] in \<int>-ring" unfolding int_3_def_3 using  aggr by auto
  hence "the OneF of \<int>-ring = succ {}" using the_selector_of_1[of "\<int>-ring" OneF "succ {}"] aggr by mty auto 
  then show "1\<^sub>\<int>-ring = succ {}" using struct_0_def_7 by auto
qed

reserve i1,i2 for Integer

mtheorem int_3_def_3_Add:
  "i1 +\<^sub>\<S>\<^sup>\<real> i2 = i1 \<oplus>\<^sub>\<int>-ring i2"
proof-
  have "[addF,addint] in \<int>-ring" unfolding int_3_def_3 using aggr by auto
  hence E1: "the addF of \<int>-ring = addint" using the_selector_of_1[of "\<int>-ring" addF addint] aggr int_3_def_3 by mty auto 
  hence "i1 \<oplus>\<^sub>\<int>-ring i2 = addint.\<lparr> i1,i2 \<rparr>" using algstr_0_def_1[of "\<int>-ring" i1 i2,simplified] by mty auto
  then show "i1 +\<^sub>\<S>\<^sup>\<real> i2 = i1 \<oplus>\<^sub>\<int>-ring i2" using binop_2_def_20 by auto
qed

mtheorem int_3_def_3_Mult:
  "i1 *\<^sub>\<S>\<^sup>\<real> i2 = i1 \<otimes>\<^sub>\<int>-ring i2"
proof-
  have "[multF,multint] in \<int>-ring" unfolding int_3_def_3 using aggr by auto
  hence E1: "the multF of \<int>-ring = multint" using the_selector_of_1[of "\<int>-ring" multF multint] aggr int_3_def_3 by mty auto 
  hence "i1 \<otimes>\<^sub>\<int>-ring i2 = multint.\<lparr> i1,i2 \<rparr>" using algstr_0_def_18[of "\<int>-ring" i1 i2,simplified] by mty auto
  then show "i1 *\<^sub>\<S>\<^sup>\<real> i2 = i1 \<otimes>\<^sub>\<int>-ring i2" using binop_2_def_22 by auto
qed

mtheorem 
  "cluster \<int>-ring \<rightarrow> Abelian \<bar> add-associative \<bar> right-zeroed \<bar>
          right-complementable \<bar> associative \<bar>
          well-unital \<bar> distributive \<bar>
          non empty-struct"
proof(standard,standard,standard,standard,standard,standard,standard,standard)
  let ?E="Element-of-struct \<int>-ring"
  have [ty]: "\<int>-ring is strict(doubleLoopStr)" by mty auto
  show Z_non_empty[ty]: "\<int>-ring be non empty-struct"
  proof
    have "[carrier,INT] in \<int>-ring" unfolding int_3_def_3 using  aggr by auto
    hence E1: "the carrier of \<int>-ring = INT" using the_selector_of_1[of "\<int>-ring" "carrier" INT] aggr by mty auto 
    hence "{} in the carrier of \<int>-ring" using int_1_def_2[of "{}"] by mty auto
    then show "not the carrier of \<int>-ring is empty" using xboole_0_def_1 by mty auto
  qed mauto
  show "\<int>-ring be Abelian"
  proof(standard,auto) 
    fix x y assume [ty]:"x is ?E" "y is ?E"
    have "x \<oplus>\<^sub>\<int>-ring y = x +\<^sub>\<S>\<^sup>\<real> y" using int_3_def_3_Add by mty auto
    also have "... = y +\<^sub>\<S>\<^sup>\<real> x" using real_0_th_11 by mty auto
    finally show "x \<oplus>\<^sub>\<int>-ring y = y \<oplus>\<^sub>\<int>-ring x" using int_3_def_3_Add by mty auto
  qed
  show "\<int>-ring is add-associative"
  proof(standard,mauto)
    fix x y z assume [ty]: "x is ?E" "y is ?E" "z is ?E"
    have "(x \<oplus>\<^sub>\<int>-ring y) \<oplus>\<^sub>\<int>-ring z = (x +\<^sub>\<S>\<^sup>\<real> y) +\<^sub>\<S>\<^sup>\<real> z" using int_3_def_3_Add  by mty auto
    also have "\<dots>=x +\<^sub>\<S>\<^sup>\<real> (y +\<^sub>\<S>\<^sup>\<real> z)" using real_0_th_15 by mty auto 
    also have "\<dots>=x \<oplus>\<^sub>\<int>-ring (y \<oplus>\<^sub>\<int>-ring z)" using int_3_def_3_Add  by mty auto
    finally show "(x \<oplus>\<^sub>\<int>-ring y) \<oplus>\<^sub>\<int>-ring z=x \<oplus>\<^sub>\<int>-ring (y \<oplus>\<^sub>\<int>-ring z)" by auto
  qed
  have O1: "0\<^sub>\<int>-ring = {}" using int_3_def_3_Zero by auto
  hence [ty]:"{} is ?E" by mty auto

  show "\<int>-ring is right-zeroed"
  proof(standard,mauto)
    fix h assume [ty]: "h be ?E"
    have "h \<oplus>\<^sub>\<int>-ring {} = h +\<^sub>\<S>\<^sup>\<real> {}" using int_3_def_3_Add  by mty auto
    then show "h \<oplus>\<^sub>\<int>-ring (0\<^sub>\<int>-ring) = h" using O1 real_0_th_8[of h] by mty auto
  qed
  show "\<int>-ring is right-complementable"
  proof(standard,mauto,standard,simp,simp)
    fix h assume [ty]: "h be ?E"
       obtain g where [ty]: "g be Integer" and
       A1: "g  +\<^sub>\<S>\<^sup>\<real> h = {}" "h +\<^sub>\<S>\<^sup>\<real> g = {}" using int_1_th_4[of h] by mty auto
    show " ex g be ?E st h \<oplus>\<^sub>\<int>-ring g = 0\<^sub>\<int>-ring "
    proof (rule bexI[of _ g],mauto)
      have "h \<oplus>\<^sub>\<int>-ring g = h +\<^sub>\<S>\<^sup>\<real> g"  using int_3_def_3_Add  by mty auto
      then show "h \<oplus>\<^sub>\<int>-ring g = 0\<^sub>\<int>-ring"  using O1 A1 by auto 
    qed
  qed
  show "\<int>-ring be associative"
  proof(standard,mauto)
    fix x y z assume [ty]:"x be ?E" "y be ?E" "z be ?E" 
    have "x \<otimes>\<^sub>\<int>-ring y \<otimes>\<^sub>\<int>-ring z = (x *\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^sup>\<real> z" using int_3_def_3_Mult by mty auto
    hence "x \<otimes>\<^sub>\<int>-ring y \<otimes>\<^sub>\<int>-ring z = x *\<^sub>\<S>\<^sup>\<real> (y *\<^sub>\<S>\<^sup>\<real> z)" using  AssociativeInt[of x y z] by mty auto
    then show "x \<otimes>\<^sub>\<int>-ring y \<otimes>\<^sub>\<int>-ring z = x \<otimes>\<^sub>\<int>-ring (y \<otimes>\<^sub>\<int>-ring z)" using int_3_def_3_Mult by mty auto
  qed
  show "\<int>-ring be well-unital"
  proof(standard,mauto)
    fix x assume [ty]:"x be ?E"
    have O: "1\<^sub>\<int>-ring = succ {}" using  int_3_def_3_One by auto
    hence "x \<otimes>\<^sub>\<int>-ring 1\<^sub>\<int>-ring = x *\<^sub>\<S>\<^sup>\<real> (succ {})"  "1\<^sub>\<int>-ring \<otimes>\<^sub>\<int>-ring x = (succ {}) *\<^sub>\<S>\<^sup>\<real> x"
            using int_3_def_3_Mult by mty auto
    then show  "x \<otimes>\<^sub>\<int>-ring 1\<^sub>\<int>-ring = x" "1\<^sub>\<int>-ring \<otimes>\<^sub>\<int>-ring x = x"  using unitalInt by mty auto
  qed mauto
  show "\<int>-ring be distributive"
  proof(standard,mauto)
    fix x y z assume [ty]:"x be ?E" "y be ?E" "z be ?E" 
    have "x \<otimes>\<^sub>\<int>-ring (y \<oplus>\<^sub>\<int>-ring z) = x *\<^sub>\<S>\<^sup>\<real> (y +\<^sub>\<S>\<^sup>\<real> z)" using int_3_def_3_Mult int_3_def_3_Add by mty auto
    also have  "... = (y +\<^sub>\<S>\<^sup>\<real> z) *\<^sub>\<S>\<^sup>\<real> x" using AbelianInt by mty auto
    also have  "... = (y *\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<S>\<^sup>\<real> (z *\<^sub>\<S>\<^sup>\<real> x)" using distributiveInt by mty auto
    also have  "... = (x *\<^sub>\<S>\<^sup>\<real> y) +\<^sub>\<S>\<^sup>\<real> (x *\<^sub>\<S>\<^sup>\<real> z)" using AbelianInt by mty auto
    also have  "... = (x \<otimes>\<^sub>\<int>-ring y) +\<^sub>\<S>\<^sup>\<real> (x \<otimes>\<^sub>\<int>-ring z)" using int_3_def_3_Mult  by mty auto
    also have  "... = (x \<otimes>\<^sub>\<int>-ring y) \<oplus>\<^sub>\<int>-ring (x \<otimes>\<^sub>\<int>-ring z)" using int_3_def_3_Add  by mty auto
    finally show "x \<otimes>\<^sub>\<int>-ring (y \<oplus>\<^sub>\<int>-ring z) = (x \<otimes>\<^sub>\<int>-ring y) \<oplus>\<^sub>\<int>-ring (x \<otimes>\<^sub>\<int>-ring z)" by auto
     have "(y \<oplus>\<^sub>\<int>-ring z)  \<otimes>\<^sub>\<int>-ring x =  (y +\<^sub>\<S>\<^sup>\<real> z) *\<^sub>\<S>\<^sup>\<real> x" using int_3_def_3_Mult int_3_def_3_Add by mty auto
    also have  "... = (y *\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<S>\<^sup>\<real> (z *\<^sub>\<S>\<^sup>\<real> x)" using distributiveInt by mty auto
    also have  "... = (y \<otimes>\<^sub>\<int>-ring x) +\<^sub>\<S>\<^sup>\<real> (z \<otimes>\<^sub>\<int>-ring x)" using int_3_def_3_Mult  by mty auto
    also have  "... = (y \<otimes>\<^sub>\<int>-ring x) \<oplus>\<^sub>\<int>-ring (z \<otimes>\<^sub>\<int>-ring x)" using int_3_def_3_Add  by mty auto
    finally show "(y \<oplus>\<^sub>\<int>-ring z)  \<otimes>\<^sub>\<int>-ring x = (y \<otimes>\<^sub>\<int>-ring x) \<oplus>\<^sub>\<int>-ring (z \<otimes>\<^sub>\<int>-ring x)" by auto
  qed
qed

theorem carrierZ:
  "carrierI(\<Z>) =\<^sub>\<H> Collect( \<lambda> x . \<hh>2\<ss>\<^sub>\<int>(x) in INT )"
proof(standard,auto)
  fix x 
  have "\<hh>2\<ss>\<^sub>\<int>(x) is Integer" using h2sZprop by auto
  then show "h2sZ(x) in INT" using int_1_def_2 by auto
qed

text_raw {*\DefineSnippet{MIring}{*}
theorem SRingtoHRing:
  "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, \<int>-ring) =\<^sub>\<H> \<Z>"
text_raw {*}%EndSnippet*}
unfolding s2hr_def
proof(rule ring_eq,intro conjI)
  let ?Z="\<int>-ring"
  let ?E="Element-of-struct ?Z"
  have [ty]: "?Z is strict(doubleLoopStr)" "?Z is Ring" by mty auto
  have "[carrier,INT] in ?Z" unfolding int_3_def_3 using  aggr by auto
  hence E1: "the carrier of ?Z = INT" using the_selector_of_1[of "?Z" "carrier" INT] aggr by mty auto 
  then show "carrierI(\<Z>) =\<^sub>\<H> Collect( \<lambda> x . \<hh>2\<ss>\<^sub>\<int>(x) in the carrier of ?Z )" using carrierZ by auto
  show "(\<otimes>\<^bsub>\<Z>\<^esub>) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, the multF of ?Z)" 
  proof(standard,standard)
    fix x y
    have [ty]: "\<hh>2\<ss>\<^sub>\<int>(x) is Element-of INT" 
               "\<hh>2\<ss>\<^sub>\<int>(y) is Element-of INT" using h2sZpropE by auto
    hence [ty]: "\<hh>2\<ss>\<^sub>\<int>(x) is ?E" "\<hh>2\<ss>\<^sub>\<int>(y) is ?E" using E1 by auto
    have "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(x)) =\<^sub>\<H> x" "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(y)) =\<^sub>\<H> y" using IMIZprop by auto 
    hence "\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, the multF of ?Z, x, y) =\<^sub>\<H>
           \<ss>2\<hh>\<^sub>\<int>( (the multF of ?Z). \<lparr>\<hh>2\<ss>\<^sub>\<int>(x),\<hh>2\<ss>\<^sub>\<int>(y)\<rparr>)" 
      using MtoIBinOpS[OF beIsoS_INT, of "\<hh>2\<ss>\<^sub>\<int>(x)" "\<hh>2\<ss>\<^sub>\<int>(y)"] by mty auto 
    also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(x) \<otimes>\<^sub>?Z \<hh>2\<ss>\<^sub>\<int>(y))" using algstr_0_def_18[of ?Z] by mty auto
    also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(x *\<^sub>\<H> y))" using MultIntI int_3_def_3_Mult by mty auto
   also have "... =\<^sub>\<H> (x *\<^sub>\<H> y)" using IMIZprop by mty auto
   also have "... =\<^sub>\<H> (x \<otimes>\<^bsub>\<Z>\<^esub> y)" by simp
   finally show "x \<otimes>\<^bsub>\<Z>\<^esub> y =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, the multF of ?Z, x, y)" by auto
 qed 
  show "(\<oplus>\<^bsub>\<Z>\<^esub>) =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, the addF of ?Z)" 
  proof(standard,standard)
    fix x y
    have [ty]: "\<hh>2\<ss>\<^sub>\<int>(x) is Element-of INT" 
               "\<hh>2\<ss>\<^sub>\<int>(y) is Element-of INT" using h2sZpropE by auto
    hence [ty]: "\<hh>2\<ss>\<^sub>\<int>(x) is ?E" "\<hh>2\<ss>\<^sub>\<int>(y) is ?E" using E1 by auto
    have "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(x)) =\<^sub>\<H> x" "\<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(y)) =\<^sub>\<H> y" using IMIZprop by auto 
    hence "\<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, the addF of ?Z, x, y) =\<^sub>\<H>
           \<ss>2\<hh>\<^sub>\<int>( (the addF of ?Z). \<lparr>\<hh>2\<ss>\<^sub>\<int>(x),\<hh>2\<ss>\<^sub>\<int>(y)\<rparr>)" 
      using MtoIBinOpS[OF beIsoS_INT, of "\<hh>2\<ss>\<^sub>\<int>(x)" "\<hh>2\<ss>\<^sub>\<int>(y)"] by mty auto 
    also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(x) \<oplus>\<^sub>?Z \<hh>2\<ss>\<^sub>\<int>(y))" using algstr_0_def_1[of ?Z] by mty auto
    also have "... =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(\<hh>2\<ss>\<^sub>\<int>(x +\<^sub>\<H> y))" using AddIntI int_3_def_3_Add by mty auto
   also have "... =\<^sub>\<H> (x +\<^sub>\<H> y)" using IMIZprop by mty auto
   also have "... =\<^sub>\<H> (x \<oplus>\<^bsub>\<Z>\<^esub> y)" by simp
   finally show "x \<oplus>\<^bsub>\<Z>\<^esub> y =\<^sub>\<H> \<ss>2\<hh>\<^bsub>BinOp\<^esub>(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, the addF of ?Z, x, y)" by auto
 qed 
  have "\<ss>2\<hh>\<^sub>\<nat>(succ {}) =\<^sub>\<H> 1" using EqSuc[of "{}"] by mty auto
  hence "\<ss>2\<hh>\<^sub>\<int>(succ {}) =\<^sub>\<H> 1" using s2hZ.simps[of "succ {}"] by mty auto
  hence "\<ss>2\<hh>\<^sub>\<int>(1\<^sub>?Z) =\<^sub>\<H> 1" using int_3_def_3_One by auto
  then show "\<one>\<^bsub>\<Z>\<^esub> =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(1\<^sub>?Z)" by auto
  have "\<ss>2\<hh>\<^sub>\<int>({}) =\<^sub>\<H> 0"  by mty auto
  hence "\<ss>2\<hh>\<^sub>\<int>(0\<^sub>?Z) =\<^sub>\<H> 0" using int_3_def_3_Zero by auto
  then show " \<zero>\<^bsub>\<Z>\<^esub> =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<int>(0\<^sub>?Z)" by auto
qed

text_raw {*\DefineSnippet{IMring}{*}
theorem HRingtoSRing:
  "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>,INT,\<Z>) =\<^sub>\<S> \<int>-ring"
text_raw {*}%EndSnippet*}
proof-
  have "[carrier,INT] in \<int>-ring" unfolding int_3_def_3 using  aggr by auto
  hence E1: "the carrier of \<int>-ring = INT" using the_selector_of_1[of "\<int>-ring" "carrier" INT] aggr by mty auto 
  have "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, \<int>-ring) =\<^sub>\<H> \<Z>" using SRingtoHRing by auto
  then show "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>,INT, \<Z>) = \<int>-ring" using MIMRprop[OF beIsoS_INT E1] E1 by mty auto
qed

text_raw {*\DefineSnippet{RingtoRing}{*}
theorem H_Zring_to_S_Zring:
  "\<hh>2\<ss>\<^sub>R(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>,INT,\<Z>) =\<^sub>\<S> \<int>-ring"
  "\<ss>2\<hh>\<^sub>R(\<ss>2\<hh>\<^sub>\<int>, \<hh>2\<ss>\<^sub>\<int>, \<int>-ring) =\<^sub>\<H> \<Z>"
  text_raw {*}%EndSnippet*} 
  using HRingtoSRing SRingtoHRing by auto

end
