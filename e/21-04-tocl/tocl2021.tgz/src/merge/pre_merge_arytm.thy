theory pre_merge_arytm
  imports "../mml/arytm_2" "../mml/newton" pre_merge_rat   pre_merge_cauchy
begin


reserve r,s,t for "Element-of RAT\<^bsup>\<ge>0\<^bsub>"
reserve n,k,l,d for Nat
text_raw {*\DefineSnippet{arytm_def_1}{*}
mdef arytm_def_1 (infix "*\<^sub>D" 110) where
  mlet "r be Nat", "A be Element-of DEDEKIND_CUTS" 
  "assume r <> {} 
   func r *\<^sub>D A \<rightarrow> Element-of DEDEKIND_CUTS equals
     { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}"
text_raw {*}%EndSnippet*}
proof(standard,auto,cases "A={}")
  case T: True
  have "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A }={}"
  proof(rule ccontr)
    assume "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}<>{}"
    then obtain x where
     X: "x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}" 
      using  xboole_0_th_7 all_set by mty auto
    obtain s where [ty]:  "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             x: " x = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s in A" using Fraenkel_A1_ex[OF _ _ X] by auto
    thus False using x T xb by auto
  qed
  thus "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where  s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A} 
      in DEDEKIND_CUTS" using T Element(7)[of "DEDEKIND_CUTS" A,simplified] by mty auto
next
  assume TT:"r<>{}"
  case A3: False
  let ?C="{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}"
  show "?C in DEDEKIND_CUTS"
  proof-
    have "?C c= RAT\<^bsup>\<ge>0\<^bsub>"
      proof(standard,simp,simp,intro ballI impI)
        fix e assume E: "e in ?C"
        obtain t where [ty]:  "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             e: " e = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t &  t in A" using Fraenkel_A1_ex[OF _ _ E] by auto
        have "r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
        thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using e by auto
      qed mauto
      hence [ty]: "?C is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by auto
      have AB: "A in DEDEKIND_CUTS" 
         using Element(7)[of "DEDEKIND_CUTS"] by mty auto
      hence "not A in {RAT\<^bsup>\<ge>0\<^bsub>}" unfolding arytm_2_def_1 using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
        all_set by mty auto
      hence "A<>RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 by auto 
      hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> A" using xboole_0_def_10 Subset_in_rule by mty auto
      then obtain a0 where
A1:   "a0 in RAT\<^bsup>\<ge>0\<^bsub>" "not a0 in A" using tarski_def_3 by auto 
      hence [ty]:"a0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by auto
      have "for r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r in ?C 
          holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?C) & (ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
      proof(rule  ballI,rule impI,rule conjI)
        fix R assume [ty]:"R be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and r: "R in ?C"
        obtain s0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2:     "R = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" and
A4:     "s0 in A" using Fraenkel_A1_ex[OF _ _ r] by mty auto
        show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> R holds s in ?C"
        proof(auto)
          fix s 
          assume [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> R"
          then obtain t1 where [ty]: "t1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A5:       "s = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" and
A6:       " t1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A2 arytm_3_th_79[of s0 r s] by mty auto
          have "t1 in A" using A4 A6  
            arytm_2_lm_16[of t1 s0 A] AB by mty auto
          thus "s in ?C" using A3 A5 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t1]
            by mty auto
        qed
       obtain t0 where [ty]: "t0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A9:     "t0 in A" and
A10:    "s0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A4 arytm_2_lm_7[of s0 A] AB by mty auto
       
          have "s0 <> t0" using A10  arytm_3_def_13r by auto
          hence
A17:      "R <> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A2 TT arytm_3_th_56[of _ _ r] by mty auto
        show "ex s st s in ?C & R <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
         proof(rule bexI[of _ "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"],rule conjI)         
           show "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 in ?C" using A3 A9 Fraenkel_A1_in by auto
           have "R \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using arytm_3_def_13c[of s0 t0] A2 A10 
             arytm_3_def_12c[of t0 r]arytm_3_def_12c[of s0 r]
             arytm_3_th_82[of r t0 s0] by mty auto
           thus "R <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A17 arytm_3_th_68 by mty auto
         qed mauto
     qed mauto
      hence A18:"?C in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" ?C,simplified] by mty auto  
      obtain s0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A20:  "not s0 in A" using arytm_2_lm_24[of A] by mty auto
      have "not r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in ?C"
      proof
        assume A:"r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in ?C"
        obtain  s where [ty]:  "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             A21: " r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s in A" using Fraenkel_A1_ex[OF _ _ A] by auto
        have "s0 = s" using  A21 TT arytm_3_th_56[of s0 s r] by mty auto
        thus False using A20 A21 by mty auto
      qed
      hence "?C <> RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0"] by mty auto
      hence "not ?C in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by auto
      thus "?C in DEDEKIND_CUTS" unfolding arytm_2_def_1 using A18 xboole_0_def_5 all_set by mty auto
    qed
  qed

reserve A,B for "Element-of DEDEKIND_CUTS"
reserve n,m for Nat

mtheorem arytm_th_1:
  "A<>{} \<Longrightarrow> n <> {} \<Longrightarrow> n*\<^sub>D A <> {}"
proof-
  assume AS: "A \<noteq> {}" "n \<noteq> {}"
  then obtain a where
     a:"a in A" using xboole_0_th_7[of A] by mty auto
  have [ty]:"a is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using a ES by mty auto 
  have "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> a in  { n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}" 
    using Fraenkel_A1_in a by mty auto
  hence "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> a in n *\<^sub>D A" using AS arytm_def_1 by mty auto
  thus "n*\<^sub>D A <> {}" using xb by mty auto
qed



mtheorem arytm_th_1_one:
  "A<>{} \<Longrightarrow> (succ {}) *\<^sub>D A =A"
proof(standard,auto)
  fix x assume A: "A<>{}"
  have [ty]: "(succ {}) is Nat" by mty auto
  assume "x in (succ {}) *\<^sub>D A"
   then obtain s where [ty]:" s is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
     and s: "x = (succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s in A" using arytm_def_1[of "succ {}" "A",simplified] 
      Fraenkel_A1_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" x,simplified] by mty auto
   hence  "x = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using arytm_3_def_12c by mty auto   
   thus " x in A" using arytm_3_th_53 s by mty auto
next  
  fix x assume A: "A<>{}"
  assume X: " x in A"
  hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto 
  have "x = x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using arytm_3_th_53 by mty auto
  hence xs: "x = (succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_12c by mty auto
  have "(succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x in  { (succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}" 
    using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x "\<lambda>x. x in A",simplified] X by mty auto
  thus "x in (succ {}) *\<^sub>D A" using A arytm_def_1 xs by mty auto
qed

mtheorem arytm_def_1M:
  " n <>{} & m<>{} implies
      n *\<^sub>D (m*\<^sub>D A) =  (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D A"
proof(rule impI)
  assume A: " n <>{} & m<>{}"
  hence A1: "n *\<^sub>\<S>\<^sup>\<nat> m <>{}" 
    using arytm_th_1 Mult_9[of m n] by mty auto
  show "n *\<^sub>D (m*\<^sub>D A) =  (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D A"
  proof(standard,auto)
    fix x assume "x in n *\<^sub>D (m*\<^sub>D A)"
    then obtain s where [ty]:" s is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
     and s: "x = n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s in m*\<^sub>D A" using arytm_def_1[of n "m*\<^sub>D A"] 
      Fraenkel_A1_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" x] A1 A by mty auto
    then obtain r where [ty]:" r is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
     and r: "s = m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r& r in A" using arytm_def_1[of m "A"]
      Fraenkel_A1_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" s] A1 A by mty auto
    have [ty]: "(n *\<^sub>\<S>\<^sup>\<nat> m) be Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
    have "x = (n*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using s r arytm_3_th_52 by mty auto 
    hence "x = (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using  arytm_3_th_59 by mty auto
    thus "x in (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D A" 
       using r Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r" "\<lambda>s. s in A",simplified] 
      arytm_def_1[of "n *\<^sub>\<S>\<^sup>\<nat> m" " A" ] A1 by mty auto
   next
     fix x assume  "x in (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D A"
      then obtain s where [ty]:" s is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
        and s: "x = (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s in A" using arytm_def_1[of "n *\<^sub>\<S>\<^sup>\<nat> m" "A"] 
      Fraenkel_A1_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" x] A1 A by mty auto

      have " m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s in  m *\<^sub>D A" 
       using s Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s" "\<lambda>s. s in A",simplified] 
      arytm_def_1[of "m" "A" ] A  by mty auto
     hence h:"n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s) in n *\<^sub>D (m*\<^sub>D A)" using 
       Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "\<lambda>s. s in (m *\<^sub>D A)",simplified] 
      arytm_def_1[of "n" "m *\<^sub>D A" ] A1 A  by mty auto
     have "x = (n*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using s arytm_3_th_59  by mty auto 
     thus  "x in n *\<^sub>D (m*\<^sub>D A)" using h arytm_3_th_52  by mty auto
   qed
 qed

mtheorem arytm_def_1A:
  " n <>{}  implies
      n *\<^sub>D ( A +D B) =  (n *\<^sub>D A) +D  (n *\<^sub>D B)"
proof
  assume A: " n <>{}"
  show "n *\<^sub>D ( A +D B) =  (n *\<^sub>D A) +D  (n *\<^sub>D B)"
  proof(standard,auto)
    fix x assume "x in n *\<^sub>D (A +D B)"
    then obtain rs where [ty]:" rs is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      s: "x = n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rs & rs in A +D B " using arytm_def_1[of n "A +D B"] 
      Fraenkel_A1_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" x] A by mty auto
    obtain r s where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      rs: "rs = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r in A  & s in B " using arytm_2_def_6[of A B,simplified] 
      Fraenkel_A2_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" " Element-of RAT\<^bsup>\<ge>0\<^bsub>" rs "(+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>)" "\<lambda>r s. r in A \<and> s in B"] 
       s by mty auto
    have R: "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) in n *\<^sub>D A" using arytm_def_1[of n A,simplified] A 
         Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r "\<lambda>s. s in A"] rs by mty auto 
    have S: "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) in n *\<^sub>D B" using arytm_def_1[of n B,simplified] A 
         Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s "\<lambda>s. s in B"] rs by mty auto 
    have RS: "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) in (n *\<^sub>D A) +D  (n *\<^sub>D B)"
     using arytm_2_def_6[of "n *\<^sub>D A" "n *\<^sub>D B"] 
     using R S Fraenkel_A2_in[ of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] 
     by mty auto
   thus " x in (n *\<^sub>D A) +D (n *\<^sub>D B)" using s rs arytm_3_th_57[of s r n] by mty auto
 next
   fix x 
   assume "x in (n *\<^sub>D A) +D (n *\<^sub>D B)"
   then obtain r s where [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
      and rs: "x= r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "r in n *\<^sub>D A" "s in n *\<^sub>D B" 
     using  arytm_2_def_6[of "n *\<^sub>D A" "n *\<^sub>D B",simplified]
     Fraenkel_A2_ex[ of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x "(+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>)" " \<lambda>r s. r in n *\<^sub>D A \<and> s in n *\<^sub>D B",
     simplified]
     by mty auto
   obtain R where [ty]: "R is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      r: "r= n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> R" "R in A" using rs arytm_def_1[of n A] A 
       Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r,simplified] by mty auto
   obtain S where [ty]: "S is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      s: "s= n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S" "S in B" using rs arytm_def_1[of n B] A 
       Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s,simplified] by mty auto
   have "R +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S in  A +D B" using r s 
     arytm_2_def_6[of A  B,simplified]
     Fraenkel_A2_in[ of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" R S,
     simplified] by mty auto
   hence "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (R +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S) in n *\<^sub>D (A +D B)" using arytm_def_1[of n "A +D B"] A 
     Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "R +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S",simplified] by mty auto
   thus " x in n *\<^sub>D (A +D B)" using s r rs arytm_3_th_57[of S R n] by mty auto
  qed
qed


mtheorem arytm_def_1MM:
  " n <>{} & m <>{}  implies
      (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D ( A *D B) =  (n *\<^sub>D A) *D  (m *\<^sub>D B)"
proof
   assume A: " n <>{} & m <>{}"
  hence A1: "n *\<^sub>\<S>\<^sup>\<nat> m <>{}" using Mult_9[of m n] by mty auto
  show "(n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D ( A *D B) =  (n *\<^sub>D A) *D  (m *\<^sub>D B)"
  proof(standard,auto)
    fix x assume "x in (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D (A *D B)"
    then obtain rs where [ty]:" rs is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      s: "x = (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rs & rs in ( A *D B) " using 
      arytm_def_1[of "n *\<^sub>\<S>\<^sup>\<nat> m" "A *D B",simplified] 
      Fraenkel_A1_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" x] A1 by mty auto
    obtain r s where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      rs: "rs = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r in A  & s in B " using arytm_2_def_7[of A B,simplified] 
      Fraenkel_A2_ex[of " Element-of RAT\<^bsup>\<ge>0\<^bsub>" " Element-of RAT\<^bsup>\<ge>0\<^bsub>" rs "(*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>)" "\<lambda>r s. r in A \<and> s in B"] 
       s by mty auto
    have R: "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) in n *\<^sub>D A" using arytm_def_1[of n A,simplified] A 
         Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r "\<lambda>s. s in A"] rs by mty auto 
    have S: "(m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) in m *\<^sub>D B" using arytm_def_1[of m B,simplified] A 
         Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s "\<lambda>s. s in B"] rs by mty auto 
    have RS: "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) in (n *\<^sub>D A) *D  (m *\<^sub>D B)"
     using arytm_2_def_7[of "n *\<^sub>D A" "m *\<^sub>D B"] 
     using R S Fraenkel_A2_in[ of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] 
     by mty auto

   have "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) = ((n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s" using arytm_3_th_52[of s m] by mty auto
   also have "... = (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s" using arytm_3_th_52[of  m r] by mty auto
   also have "... = (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s" using arytm_3_def_12c by mty auto
  also have "... = ((n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s" using arytm_3_th_52 by mty auto
  finally have "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) = (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s)" 
     using arytm_3_th_52[of s r] by mty auto
   hence "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s) = x" using s rs arytm_3_th_59 by mty auto   
   thus " x in (n *\<^sub>D A) *D (m *\<^sub>D B)" using RS by mty auto
 next
   fix x 
   assume "x in (n *\<^sub>D A) *D (m *\<^sub>D B)"
   then obtain r s where [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
      and rs: "x= r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "r in n *\<^sub>D A" "s in m *\<^sub>D B" 
     using  arytm_2_def_7[of "n *\<^sub>D A" "m *\<^sub>D B",simplified]
     Fraenkel_A2_ex[ of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x "(*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>)" " \<lambda>r s. r in n *\<^sub>D A \<and> s in m *\<^sub>D B",
     simplified]
     by mty auto
   obtain R where [ty]: "R is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      r: "r= n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> R" "R in A" using rs arytm_def_1[of n A] A 
       Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r,simplified] by mty auto
   obtain S where [ty]: "S is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      s: "s= m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S" "S in B" using rs arytm_def_1[of m B] A 
       Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s,simplified] by mty auto
   have "R *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S in  A *D B" using r s 
     arytm_2_def_7[of A  B,simplified]
     Fraenkel_A2_in[ of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" R S,
     simplified] by mty auto
   hence RS: "(n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (R *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S) in (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D (A *D B)" 
     using arytm_def_1[of "n *\<^sub>\<S>\<^sup>\<nat> m" "A *D B"] A1 
     Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "R *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S",simplified] by mty auto
  have "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  R) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S) = ((n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  R) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S" using arytm_3_th_52[of S m] by mty auto
   also have "... = (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (R *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S" using arytm_3_th_52[of  m R] by mty auto
   also have "... = (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> R)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S" using arytm_3_def_12c by mty auto
  also have "... = ((n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> R) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S" using arytm_3_th_52 by mty auto
  finally have "(n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  R) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (m *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S) = (n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (R *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  S)" 
     using arytm_3_th_52[of S R] by mty auto
   hence "(n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (R *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S) = x" using r s rs arytm_3_th_59 by mty auto   
   thus " x in (n *\<^sub>\<S>\<^sup>\<nat> m) *\<^sub>D ( A *D B)" using RS by mty auto
  qed
qed

mtheorem arytm_th_2:
  "A<>{} \<Longrightarrow> {} in A"
proof-
  assume "A<>{}"
 then obtain a where
     a:"a in A" using xboole_0_th_7[of A] by mty auto
  have [ty]:"a is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using a ES by mty auto 
  have "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> a" using  arytm_3_th_64 by mty auto
  thus "{} in A" using  arytm_2_lm_7f[of "{}" a] a by mty auto
qed
text_raw {*\DefineSnippet{maxN}{*}
mdef maxN ("max\<^sub>\<nat> _" ) where
  mlet "A be Element-of DEDEKIND_CUTS" 
  "assume A <> {} 
   func max\<^sub>\<nat> A \<rightarrow> Nat means
     \<lambda>it. it in A & (for k be Nat st k in A holds k c= it)"
text_raw {*}%EndSnippet*}
proof-
  assume AS: "A \<noteq> {}"
  let ?P="\<lambda>x. x in A" 
  obtain r where [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    r: " not r in A" using arytm_2_lm_24[of A] by mty auto
  let ?d = "denominator(r)" let ?n = "numerator(r)"

  have A: "?d<>{}" using arytm_3_th_35 by mty auto
  have N: "?d = ?d/\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})" using arytm_3_th_40 by mauto
  have "succ {} <>{}" by auto

  have "?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d =\<^sub>\<S> r" using arytm_3_th_39[of r]
    by auto 

  hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?d  = (?n  /\<^bsub>\<rat>\<ge>0\<^bsup> ?d) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?d /\<^bsub>\<rat>\<ge>0\<^bsup> succ {})" using N  by mty auto
  also have "... = (?n*\<^sub>\<S>\<^sup>\<nat>?d)/\<^bsub>\<rat>\<ge>0\<^bsup>(?d*\<^sub>\<S>\<^sup>\<nat>succ {})" using arytm_3_th_49 by mty auto
  also have "... = (?n*\<^sub>\<S>\<^sup>\<nat>?d)/\<^bsub>\<rat>\<ge>0\<^bsup>((succ {})*\<^sub>\<S>\<^sup>\<nat> ?d)" using Mult_6 by mty auto
  also have "... = (?n  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?d /\<^bsub>\<rat>\<ge>0\<^bsup> ?d)" using arytm_3_th_49 by mty auto
  also have "... = (?n  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using arytm_3_th_41[of ?d] A by mty auto
  also have "... = (?n  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{})" using arytm_3_th_53 by mty auto
  also have "... = ?n " using arytm_3_th_40[of ?n ?n] all_set by mty auto
  finally have NN: "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?d = ?n" by auto
  have "succ {} c= ?d" using A one2 one1 by mty auto
  hence "succ {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?d" using arytm_3_TH1 by mty auto
  hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {}) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?d)" using arytm_3_th_82[of r ?d "succ {}",simplified] 
   arytm_3_def_12c[of r ?d,simplified] arytm_3_def_12c[of r "succ {}",simplified] by mty auto
  hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?d)" using arytm_3_th_53 
   arytm_3_def_12c[of r ?d,simplified] arytm_3_def_12c[of r "succ {}",simplified] by mty auto
  hence nA: "not ?n in A" using NN arytm_2_lm_7f[of r "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?d"  A] r by mty auto

  have T1:"\<forall>n:Nat. ?P(n) \<longrightarrow> n \<subseteq> ?n"
  proof(intro ballI impI, rule ccontr)
    fix n assume [ty]:"n is Nat" and 
      as: "n in A" "\<not> n \<subseteq> ?n"
    hence "?n \<subseteq> n" using ordinal1_def_5c[of n] by mty auto
    hence "?n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_3_TH1 by mty auto
    thus False using nA arytm_2_lm_7f[of ?n n A] as by mty auto
  qed mauto
  have "{} in A" using AS arytm_th_2 by mty auto
  hence T2:"\<exists>n : Nat. ?P(n)" using bexI[of _ "{}" Nat] by mty auto  
  show  "\<exists>x : Nat. x in A \<and> (\<forall>k : Nat. k in A \<longrightarrow> k \<subseteq> x)" 
   using MaxInd[OF _ T1 T2] by mty auto
next
  fix x y assume  "A \<noteq> {}" and
           [ty]: "x be Nat"
           "y be Nat" and
           A1 :"x in A \<and> (\<forall>k : Nat. k in A \<longrightarrow> k \<subseteq> x)"
               " y in A \<and> (\<forall>k : Nat. k in A \<longrightarrow> k \<subseteq> y)"
  hence " x \<subseteq> y " "y \<subseteq> x" by mty auto
  thus "x=y" using xboole_0_def_10I by mty auto
qed mauto

mtheorem arytm_th_3:
  "A<>{} \<Longrightarrow> not succ(max\<^sub>\<nat> A) in A"
proof
  have M:"max\<^sub>\<nat> A in succ max\<^sub>\<nat> A" using ordinal1_th_2 by mty auto
  assume "A <> {}" "succ max\<^sub>\<nat> A in A"
  hence "succ max\<^sub>\<nat> A \<subseteq> max\<^sub>\<nat> A" using maxN by auto
  thus False using M  ordinal1_th_1 by mty auto
qed

mtheorem arytm_th_4:
  "A<>{} \<and> n<>{} \<Longrightarrow> n *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) \<subseteq>  (max\<^sub>\<nat> (n *\<^sub>D A))"
proof-
  let ?m="max\<^sub>\<nat> A"
  assume AS: "A<>{} \<and> n<>{}"
  have A1:"n *\<^sub>D A<>{}" using arytm_th_1 AS  by mty auto
  have "?m in A" using maxN AS by mty auto
  hence "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?m in  { n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}" 
    using Fraenkel_A1_in by mty auto
  hence "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?m in n *\<^sub>D A" using AS arytm_def_1 by mty auto
  hence "n *\<^sub>\<S>\<^sup>\<nat> ?m in n *\<^sub>D A" using arytm_3_th_59 by mty auto
  thus "n *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) \<subseteq>  (max\<^sub>\<nat> (n *\<^sub>D A))" using maxN A1 by mty auto 
qed

mtheorem arytm_th_5:
  "A<>{} \<and> n<>{}  \<Longrightarrow> 
      (max\<^sub>\<nat> ((succ n) *\<^sub>D A)) \<subseteq> (succ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  n "
proof(rule ccontr)
  let ?s = "succ n"

  have "succ (?s *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  n) = ?s *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> ?s" 
    using Add_1 by mty auto
  hence ss: "succ (?s *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  n) = ?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A)" 
    using Mult_3 by mty auto
  
  assume A: "A<>{} \<and> n<>{}" "\<not> (max\<^sub>\<nat> (?s *\<^sub>D A)) \<subseteq> ?s *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  n"
  hence S: "?s<>{}" "?s *\<^sub>D A<>{}" using arytm_th_1 by auto
  hence M:"max\<^sub>\<nat> (?s *\<^sub>D A) in ?s *\<^sub>D A" using maxN by auto
  have "?s *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  n in (max\<^sub>\<nat> (?s *\<^sub>D A))" using 
    ordinal1_th_12[of "?s *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  n" "max\<^sub>\<nat> (?s *\<^sub>D A)"] A(2) by mty auto
  hence "?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A) c= (max\<^sub>\<nat> (?s *\<^sub>D A))" using ss ordinal1_th_17 by mty auto
  hence "?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (max\<^sub>\<nat> (?s *\<^sub>D A))" using arytm_3_TH1 by mty auto
  hence "?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A) in ?s *\<^sub>D A" using M 
    arytm_2_lm_7f[of "?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A)" "max\<^sub>\<nat> (?s *\<^sub>D A)" "?s *\<^sub>D A"] by mty auto
  hence Z: "?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A) in { ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A}"
    using arytm_def_1 by mty auto
  obtain S where [ty]:"S is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   D: "?s *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A) =?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S & S in A" using Fraenkel_A1_ex[OF _ _ Z] by mty auto   
  hence "?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ (max\<^sub>\<nat> A)) = ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S " using arytm_3_th_59 by mty auto
  hence " (succ (max\<^sub>\<nat> A)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s = S *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s " using arytm_3_def_12c[of S ?s,simplified] 
      arytm_3_def_12c[of ?s "succ (max\<^sub>\<nat> A)",simplified] by mty auto
  hence "succ (max\<^sub>\<nat> A) = S" using arytm_3_th_82f[of "succ (max\<^sub>\<nat> A)" S ?s] S by mty auto
  hence "succ (max\<^sub>\<nat> A) c= max\<^sub>\<nat> A" using D maxN A by mty auto
  thus False using  ordinal1_th_1 ordinal1_th_2 by mty auto
qed


mtheorem arytm_th_5C:
   "A<>{}  \<Longrightarrow> 
      max\<^sub>\<nat> ( (2\<^sub>\<S> |^ n) *\<^sub>D A) \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A)"
proof-
  assume a:"A<>{}"
  have h: "max\<^sub>\<nat> ( (2\<^sub>\<S> |^ n) *\<^sub>D A) \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  (2\<^sub>\<S> |^ n)"
  proof(cases "n={}")
  case T: True
  have  "2\<^sub>\<S> |^ n = succ {}" using T newton_th_4 by mty auto
  hence "(2\<^sub>\<S> |^ n) *\<^sub>D A = A" "(2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) = (max\<^sub>\<nat> A)"
     using arytm_th_1_one Mult_5 a by mty auto
   thus "max\<^sub>\<nat> ( (2\<^sub>\<S> |^ n) *\<^sub>D A) \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  (2\<^sub>\<S> |^ n)" using 
     Add_10 by mty auto
 next 
   case F:False
    have D: "2\<^sub>\<S> |^ n<>{}" using newton_th_7 by mty auto
    let ?p="predecessor (2\<^sub>\<S> |^ n)"
    have pp: "succ ?p = (2\<^sub>\<S> |^ n)" using predec D by mty auto
    have "{} in n" using one1 one2 F by mty auto
    hence "2\<^sub>\<S> |^ {} in 2\<^sub>\<S> |^ n" using newton_th_8 xboole_0_def_10[of "2\<^sub>\<S>" "2\<^sub>\<S>"] all_set by mty auto
    hence "succ {} in 2\<^sub>\<S> |^ n" using newton_th_4 by mty auto
    hence "succ {} \<subseteq> ?p"  using ordinal1_th_18[of "?p"] pp by mty auto
    hence "{} in ?p" using ordinal1_th_17 by mty auto
    hence  sp: "?p <>{}" using xb by auto
    have x: "(max\<^sub>\<nat> ((2\<^sub>\<S> |^ n) *\<^sub>D A)) \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  ?p"
      using  arytm_th_5[of ?p A] a sp pp by mty auto
    have "?p \<subseteq> (2\<^sub>\<S> |^ n)" using ordinal1_th_2a[of ?p] pp by mty auto
    hence "(2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> ?p \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ n)"
      using Add_13[of "(2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A)"] by mty auto
    thus "max\<^sub>\<nat> ( (2\<^sub>\<S> |^ n) *\<^sub>D A) \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  (2\<^sub>\<S> |^ n)"
      using xboole_1_th_1[OF _ _ _ x] by mty auto
  qed

  have "(2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  (2\<^sub>\<S> |^ n) = (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (succ{})"
    using Mult_5 by mty auto
  also have "... = (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat>  (succ{}))" using Mult_11 by mty auto
  also have "... = (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> (succ (max\<^sub>\<nat> A))" using Add_5 by mty auto
  finally show "max\<^sub>\<nat> ( (2\<^sub>\<S> |^ n) *\<^sub>D A) \<subseteq> (2\<^sub>\<S> |^ n) *\<^sub>\<S>\<^sup>\<nat> succ (max\<^sub>\<nat> A)" using h by mty auto
qed


mtheorem arytm_th_6:
  "A<>{} \<Longrightarrow> B <> {} \<Longrightarrow> A +D B <> {}"
proof-
  assume AS: "A \<noteq> {}" "B \<noteq> {}"
  then obtain a b where
     a:"a in A" "b in B" using xboole_0_th_7[of A]  xboole_0_th_7[of B] by mty auto
  have [ty]:"a is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "b is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using a ES by mty auto 
  have "a +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b in  { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}" 
    using Fraenkel_A2_in a by mty auto
  hence "a +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b in A +D B" using AS arytm_2_def_6 by mty auto
  thus "A +D B <> {}" using xb by mty auto
qed

mtheorem arytm_th_6M:
  "A<>{} \<Longrightarrow> B <> {} \<Longrightarrow> A *D B <> {}"
proof-
  assume AS: "A \<noteq> {}" "B \<noteq> {}"
  then obtain a b where
     a:"a in A" "b in B" using xboole_0_th_7[of A]  xboole_0_th_7[of B] by mty auto
  have [ty]:"a is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "b is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using a ES by mty auto 
  have "a *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}" 
    using Fraenkel_A2_in a by mty auto
  hence "a *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b in A *D B" using AS arytm_2_def_7 by mty auto
  thus "A *D B <> {}" using xb by mty auto
qed

mtheorem arytm_th_7:
  "A <> {} & B <> {} \<Longrightarrow> (max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) \<subseteq>  max\<^sub>\<nat> (A +D B)"
proof-
  assume AS: "A <> {} & B <> {}"
  hence "(max\<^sub>\<nat> A) in A" "(max\<^sub>\<nat> B) in B" using maxN by mty auto
  hence "(max\<^sub>\<nat> A) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (max\<^sub>\<nat> B) in 
     { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
    using Fraenkel_A2_in by mty auto
  hence "(max\<^sub>\<nat> A) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (max\<^sub>\<nat> B) in A +D B" using arytm_2_def_6 by mty auto
  hence "(max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) in A +D B" using  arytm_3_th_58 by mty auto
  thus "(max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) \<subseteq>  max\<^sub>\<nat> (A +D B)" using maxN[of "A +D B"] 
    arytm_th_6[of B A] AS by mty auto
qed

mtheorem arytm_th_7M:
  "A <> {} & B <> {} \<Longrightarrow> (max\<^sub>\<nat> A) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) \<subseteq>  max\<^sub>\<nat> (A *D B)"
proof-
  assume AS: "A <> {} & B <> {}"
  hence "(max\<^sub>\<nat> A) in A" "(max\<^sub>\<nat> B) in B" using maxN by mty auto
  hence "(max\<^sub>\<nat> A) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (max\<^sub>\<nat> B) in 
     { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
    using Fraenkel_A2_in by mty auto
  hence "(max\<^sub>\<nat> A) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (max\<^sub>\<nat> B) in A *D B" using arytm_2_def_7 by mty auto
  hence "(max\<^sub>\<nat> A) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) in A *D B" using  arytm_3_th_59 by mty auto
  thus "(max\<^sub>\<nat> A) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) \<subseteq>  max\<^sub>\<nat> (A *D B)" using maxN[of "A *D B"] 
    arytm_th_6M[of B A] AS by mty auto
qed

mtheorem arytm_th_8:
  "A<>{} \<and> B<>{} & n<>{}  \<Longrightarrow> 
      max\<^sub>\<nat> ((succ n) *\<^sub>D (A +D B)) \<subseteq> ((succ n) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B))) +\<^sub>\<S>\<^sup>\<nat> ( (succ n) +\<^sub>\<S>\<^sup>\<nat> n)" 
proof(rule ccontr)
  let ?s = "succ n" let ?mA ="max\<^sub>\<nat> A" let ?mB ="max\<^sub>\<nat> B" 
  let ?AB ="A +D B" 
  have " succ(?s +\<^sub>\<S>\<^sup>\<nat> n) = (?s +\<^sub>\<S>\<^sup>\<nat> ?s)"
    using Add_1 by mty auto
  hence "succ  (?s +\<^sub>\<S>\<^sup>\<nat> n) =  ?s *\<^sub>\<S>\<^sup>\<nat> succ {} +\<^sub>\<S>\<^sup>\<nat> ?s *\<^sub>\<S>\<^sup>\<nat> succ {}"
    using Mult_5 by mty auto
  hence "succ  (?s +\<^sub>\<S>\<^sup>\<nat> n) =  ?s *\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})"
    using Mult_11 by mty auto
  hence "succ (?s *\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat>  (?s +\<^sub>\<S>\<^sup>\<nat> n)) = 
      ?s *\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> ?s *\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})" 
    using Add_1[of "?s +\<^sub>\<S>\<^sup>\<nat> n"] by mty auto
 hence ss: "succ (?s *\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat>  (?s +\<^sub>\<S>\<^sup>\<nat> n)) = 
      ?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {}))" 
    using Mult_11 by mty auto
  assume A: "A<>{} \<and> B<>{} & n<>{}"
    "not  max\<^sub>\<nat> (?s *\<^sub>D (A +D B)) \<subseteq> (?s *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B))) +\<^sub>\<S>\<^sup>\<nat>  (?s +\<^sub>\<S>\<^sup>\<nat> n)"
  have "A+D B <>{}" using A arytm_th_6 by mty auto
  hence S: "?s<>{}" "?s *\<^sub>D (A+D B)<>{}" using arytm_th_1 by auto
  hence M:"max\<^sub>\<nat> (?s *\<^sub>D (A+D B)) in ?s *\<^sub>D (A+D B)" using maxN by auto
  have "(?s *\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB)) +\<^sub>\<S>\<^sup>\<nat>  (?s +\<^sub>\<S>\<^sup>\<nat> n) in  max\<^sub>\<nat> (?s *\<^sub>D (A +D B))" using
    ordinal1_th_12[of "(?s *\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB)) +\<^sub>\<S>\<^sup>\<nat>  (?s +\<^sub>\<S>\<^sup>\<nat> n)"  
    "max\<^sub>\<nat> (?s *\<^sub>D (A +D B))"] A(2) by mty auto
  hence "?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) c= (max\<^sub>\<nat> (?s *\<^sub>D ?AB))" 
    using ss ordinal1_th_17 by mty auto
 hence "?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (max\<^sub>\<nat> (?s *\<^sub>D ?AB))" 
    using arytm_3_TH1 by mty auto
  hence "?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) in ?s *\<^sub>D ?AB" using M 
    arytm_2_lm_7f[of "?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {}))" "max\<^sub>\<nat> (?s *\<^sub>D ?AB)" 
  "?s *\<^sub>D ?AB"] by mty auto
  hence Z: "?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) 
      in { ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in (A +D B)}"
    using arytm_def_1 by mty auto
  obtain S where [ty]:"S is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   D: "?s *\<^sub>\<S>\<^sup>\<nat> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) =?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S & S in ?AB" 
     using Fraenkel_A1_ex[OF _ _ Z] by mty auto   
 hence "?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) = ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S " using arytm_3_th_59 by mty auto
  hence " ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s = S *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s " using arytm_3_def_12c[of S ?s,simplified] 
      arytm_3_def_12c[of ?s "((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {}))",simplified] by mty auto
  hence "S = (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})" 
     using arytm_3_th_82f[of "((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {}))" S ?s] S by mty auto
   also have "... = ((?mA +\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> succ {}) +\<^sub>\<S>\<^sup>\<nat> succ {}" using Add_7[of "succ {}" "succ {}" ] 
     by mty auto
   also have "... = (?mA +\<^sub>\<S>\<^sup>\<nat> (?mB +\<^sub>\<S>\<^sup>\<nat> succ {})) +\<^sub>\<S>\<^sup>\<nat> succ {}" using Add_7[of "succ {}" ?mB ] 
     by mty auto
   also have "... = ((?mB +\<^sub>\<S>\<^sup>\<nat> succ {}) +\<^sub>\<S>\<^sup>\<nat> ?mA) +\<^sub>\<S>\<^sup>\<nat> succ {}" using Add_6[of ?mA ] 
     by mty auto
   also have "... = (?mB +\<^sub>\<S>\<^sup>\<nat> succ {}) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> succ {})" using Add_7[of "succ {}" ?mA ] 
     by mty auto
   finally have "S= (?mA +\<^sub>\<S>\<^sup>\<nat> succ {}) +\<^sub>\<S>\<^sup>\<nat> (?mB +\<^sub>\<S>\<^sup>\<nat> succ {})" using Add_6[of "?mA +\<^sub>\<S>\<^sup>\<nat> succ {}"] 
     by mty auto
   hence A2: "S= (?mA +\<^sub>\<S>\<^sup>\<nat> succ {}) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?mB +\<^sub>\<S>\<^sup>\<nat> succ {})" using arytm_3_th_58 by mty auto
   have s: "S in  { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}" 
     using arytm_2_def_6 D by mty auto 
   obtain r s where [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>"  "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     rs: "S= r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r in A & s in B" using Fraenkel_A2_ex[OF _ _ _ _ s] by mty auto
   show False
   proof(cases " ?mA +\<^sub>\<S>\<^sup>\<nat> succ {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r")
     case True
       hence "?mA +\<^sub>\<S>\<^sup>\<nat> (succ {}) in A" using rs arytm_2_lm_7f[of _ r A] by mty auto
       hence "?mA +\<^sub>\<S>\<^sup>\<nat> (succ {}) \<subseteq> ?mA" using maxN A by mty auto
       hence "succ (?mA) \<subseteq> ?mA" using Add_5 by mty auto
       thus False using  ordinal1_th_1 ordinal1_th_2 by mty auto

     next
     case False
     hence " ?mB +\<^sub>\<S>\<^sup>\<nat> succ {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using rs A2 
      arytm_3_th_81[of "?mA +\<^sub>\<S>\<^sup>\<nat> succ {}" "?mB +\<^sub>\<S>\<^sup>\<nat> succ {}" r s] by mty auto
     hence "?mB +\<^sub>\<S>\<^sup>\<nat> (succ {}) in B" using rs arytm_2_lm_7f[of _ s B] by mty auto
       hence "?mB +\<^sub>\<S>\<^sup>\<nat> (succ {}) \<subseteq> ?mB" using maxN A by mty auto
       hence "succ (?mB) \<subseteq> ?mB" using Add_5 by mty auto
       thus False using  ordinal1_th_1 ordinal1_th_2 by mty auto
   qed
qed

mtheorem arytm_th_8M:
  "A<>{} \<and> B<>{} & n<>{}  \<Longrightarrow> 
      max\<^sub>\<nat> (n *\<^sub>D (A *D B)) in n *\<^sub>\<S>\<^sup>\<nat> (((max\<^sub>\<nat> A) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B)) +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> A) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> B) +\<^sub>\<S>\<^sup>\<nat> succ{} ))" 
proof(rule ccontr)
  let ?mA ="max\<^sub>\<nat> A" let ?mB ="max\<^sub>\<nat> B" 
  let ?AB ="A *D B" 
  assume AS: "A<>{} \<and> B<>{} & n<>{}"
  " \<not> (max\<^sub>\<nat> (n *\<^sub>D ?AB) in n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )))"
  hence A2:"n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) \<subseteq> max\<^sub>\<nat> (n *\<^sub>D ?AB)"
    using ordinal1_th_12[of " max\<^sub>\<nat> (n *\<^sub>D ?AB)" "n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} ))"] 
    by mty auto
  hence A3: "n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> max\<^sub>\<nat> (n *\<^sub>D ?AB)" using arytm_3_TH1 by mty auto 
  have "?AB <>{}" using AS arytm_th_6M by mty auto
  hence "n *\<^sub>D ?AB<>{}" using AS arytm_th_1 by mty auto
  hence "max\<^sub>\<nat> (n *\<^sub>D ?AB) in (n *\<^sub>D ?AB)" using maxN by mty auto
  hence "n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) in n *\<^sub>D ?AB" 
     using arytm_2_lm_7f[OF _ _ _ _ A3] by mty auto
   hence "n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) in n *\<^sub>D ?AB" using 
   ordinal1_th_8[of _ "max\<^sub>\<nat> (n *\<^sub>D ?AB)""(n *\<^sub>D ?AB)"]
    by mty auto
  hence A4: "n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) in 
           { n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in ?AB}" using arytm_def_1 AS by mty auto
  obtain S where [ty]:"S is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   D: "n *\<^sub>\<S>\<^sup>\<nat> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) =n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S & S in ?AB" 
     using Fraenkel_A1_ex[OF _ _ A4] by mty auto 
   hence X: "S in 
     { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}" 
     using arytm_2_def_7 by mty auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      x: " S = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex [OF _ _ _ _ X] by mty auto


   have  "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) =n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> S"
     using arytm_3_th_59 D by mty auto
   hence "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) =S *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n"  using arytm_3_def_12c 
     by mty auto
   hence "((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} ))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n =S *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n"  using arytm_3_def_12c 
     by mty auto
   hence "((?mA *\<^sub>\<S>\<^sup>\<nat> ?mB) +\<^sub>\<S>\<^sup>\<nat> (?mA +\<^sub>\<S>\<^sup>\<nat> ?mB +\<^sub>\<S>\<^sup>\<nat> succ{} )) =S" 
     using arytm_3_th_82f[of S _ n] AS by mty auto 
   hence " (succ (?mA))*\<^sub>\<S>\<^sup>\<nat> (succ(?mB)) =s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using  x Mult_17[of ?mB ?mA] by mty auto
   hence A5: " (succ (?mA))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(succ(?mB)) =s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_59 by mty auto
   have A6:"not succ (?mA) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" 
   proof
     assume "succ (?mA) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
     hence "succ (?mA) in A" using x arytm_2_lm_7f[of _ s] by mty auto
     thus False using AS arytm_th_3 by mty auto
   qed
   have "not succ (?mB) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"  
   proof
     assume "succ (?mB) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
     hence "succ (?mB) in B" using x arytm_2_lm_7f[of _ t] by mty auto
     thus False using AS arytm_th_3 by mty auto
   qed
   thus False using arytm_3_th_83[OF _ _ _ _ A5] A6 by mty auto
qed

mtheorem arytm_th_9:
  "2\<^sub>\<S> \<subseteq> n  \<longrightarrow> (ex k st l in n|^k)"
proof(rule impI, rule ccontr)
  let ?P= "\<lambda>it. ex k st it= n|^k"
  assume A: "2\<^sub>\<S> \<subseteq> n" "\<not> (\<exists>k : Nat. l in n |^ k)"

  have A1:"\<forall>n:Nat. ?P(n) \<longrightarrow> n \<subseteq> l"
  proof(rule ballI, rule impI)
    fix N assume [ty]:" N be Nat" and "?P(N)"
    then obtain k where [ty]:"k be Nat" and
      N:"N = n |^k" by auto
    hence "not l in n|^k" using A(2) by auto
    thus "N c=l "using N ordinal1_th_12[of l "n|^k"] by mty auto
  qed mauto
  have "?P(succ {})" using newton_th_4[of n] bexI[of _ "{}" Nat] by mty auto
  hence A2: "\<exists>n : Nat. ?P(n)" using bexI[of _ "succ {}" Nat] by mty auto
  obtain k where [ty]: "k is Nat" and 
    P: "?P(k) \<and> (\<forall>n:Nat. ?P(n) \<longrightarrow> n \<subseteq> k)" using MaxInd[OF _ A1 A2]  by mty auto
  then obtain N where [ty]:"N is Nat" and 
    N: "k = n |^ N" by mty auto
  have "?P(n |^ (succ (N)))" using bexI[of _ "succ (N)" Nat] by mty auto
  hence P1: "n |^ (succ (N)) \<subseteq> k" using P by mty auto
  have "N in succ (N)" using ordinal1_th_2 by mty auto
  hence "k in n |^ (succ (N))" using A N newton_th_8 by mty auto
  thus False using P1 ordinal1_th_1 by mty auto 
qed

mtheorem arytm_th_10:
  "r <>{} \<longrightarrow> (ex k st 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)"
proof
  assume R: "r <>{}"
  let ?d = "denominator(r)" let ?n = "numerator(r)"
  have A: "?d<>{}" "?n <>{}" using arytm_3_th_35[of r] arytm_3_th_37[of r] R by mty auto
  obtain k where [ty]:"k is Nat" and
    K:"?d in 2\<^sub>\<S> |^k" using arytm_th_9[of ?d "2\<^sub>\<S>"] xboole_0_def_10[of "2\<^sub>\<S>" "2\<^sub>\<S>"] 
    all_set by mty auto
  have "succ {} \<subseteq> ?n" using one2 A by mty auto
  hence "(succ {}) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^k) \<subseteq> ?n *\<^sub>\<S>\<^sup>\<nat> ( 2\<^sub>\<S> |^ k)" using Mult_12s[of "2\<^sub>\<S> |^ k" ?n "succ {}",
      simplified] 
    by mty auto
  hence "(2\<^sub>\<S> |^k) \<subseteq> ?n *\<^sub>\<S>\<^sup>\<nat> ( 2\<^sub>\<S> |^ k)" using Mult_5 by mty auto
  hence "?d in ?n *\<^sub>\<S>\<^sup>\<nat> ( 2\<^sub>\<S> |^ k)" using K tarski_def_3 by mty auto
  hence "1\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> ?d in ?n *\<^sub>\<S>\<^sup>\<nat> ( 2\<^sub>\<S> |^ k)" using Mult_5 by mty auto
  hence "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d" 
    using A arytm_3_TH3[of "2\<^sub>\<S> |^ k" ?n "1\<^sub>\<S>" ?d] by mty auto
  hence "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k)  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" 
    using arytm_3_th_39[of r] by mty auto
  thus "ex k st 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using bexI[of _ k Nat] by mty auto
qed

mtheorem arytm_th_11:
  "n <>{} \<longrightarrow> (n |^ l) /\<^sub>\<rat> n |^ (l +\<^sub>\<S>\<^sup>\<nat> k) = 1\<^sub>\<S> /\<^sub>\<rat> (n |^ k)"
proof
  assume N:"n <>{}" 
  hence D: "n |^ l<>{}" "n |^ k<>{}" using newton_th_7 by mty auto
  have "(n |^ l) /\<^sub>\<rat> n |^ (l +\<^sub>\<S>\<^sup>\<nat> k) = ((n |^ l) *\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>) /\<^sub>\<rat> ((n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n |^ k))" 
    using newton_th_6a Mult_5[of "n |^ l"] by mty auto
  also have "...= ((n |^ l) *\<^sub>\<S>\<^sup>\<real>  1\<^sub>\<S>) /\<^sub>\<rat> ((n |^ l) *\<^sub>\<S>\<^sup>\<real>  (n |^ k))" using int_1_def_5 by mty auto
  also have "... = ((n |^ l) /\<^sub>\<rat> (n |^ l)) *\<^sub>\<S>\<^sup>\<real>  (1\<^sub>\<S> /\<^sub>\<rat>  (n |^ k))" using D rat_1_th_14 by mty auto
  also have "... = (succ {})*\<^sub>\<S>\<^sup>\<real>  (1\<^sub>\<S> /\<^sub>\<rat>  (n |^ k))" using rat_1_div D arytm_3_th_41[of "n |^ l"] by mty auto
  finally show  "(n |^ l) /\<^sub>\<rat> n |^ (l +\<^sub>\<S>\<^sup>\<nat> k) =  (1\<^sub>\<S> /\<^sub>\<rat>  (n |^ k))" using 
       rat_1_one[of "1\<^sub>\<S> /\<^sub>\<rat>  (n |^ k)"] real_0_th_21[of "succ {}" "1\<^sub>\<S> /\<^sub>\<rat>  (n |^ k)"]
    by mty auto
qed


mtheorem arytm_th_12:
  "r <>{} & n <>{} \<longrightarrow> (ex k st n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)"
proof
  assume AS:"r<>{} & n <>{}"
  then obtain n1 where  [ty]: "n1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    n1:"n  *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n1 =\<^sub>\<S> succ {}" using arytm_3_th_54[of n] by mty auto 
  hence "n1 <>{}" using arytm_3_th_48 by mty auto
  then obtain n2 where [ty]:"n2 be Nat" and
    n2: "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ n2) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n1" using arytm_th_10[of n1] by mty auto
  obtain n3 where [ty]:"n3 be Nat" and
    n3: "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ n3) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_th_10[of r] AS by mty auto
  hence N3:"1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ n3) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_68 by mty auto
  let ?N="n3 +\<^sub>\<S>\<^sup>\<nat> n2"
  show "ex k st n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  proof(rule bexI[of _ "?N"])
    have F1: "((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ n2)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_3_th_82e AS n2 by mty auto   

    have "n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N) = (n *\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> (( 2\<^sub>\<S> |^ ?N)*\<^sub>\<S>\<^sup>\<nat> succ{})"
       using arytm_3_th_44 by mty auto
    also have "... = (( succ {}) *\<^sub>\<S>\<^sup>\<nat> n) /\<^bsub>\<rat>\<ge>0\<^bsup> (( 2\<^sub>\<S> |^ ?N)*\<^sub>\<S>\<^sup>\<nat> succ{})" using Mult_6 by mty auto
    also have "... = (( succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n /\<^bsub>\<rat>\<ge>0\<^bsup> succ{})" using arytm_3_th_49 by mty auto
    also have "... = (( succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_3_th_40[of n n] by mty auto   
    also have "... = ((( succ {})*\<^sub>\<S>\<^sup>\<nat> (succ {})) /\<^bsub>\<rat>\<ge>0\<^bsup> ((2\<^sub>\<S> |^ n3) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ n2))) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n" 
      using newton_th_6a[of n2 n3 "2\<^sub>\<S>"] Mult_5[of "succ {}"] by mty auto   
    also have "... = ( (( succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ n3)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ n2))) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n"
      using  arytm_3_th_49[of _ "succ {}" _ "succ {}"] by mty auto
    finally have "n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N) =  (( succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ n3)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (((succ {})/\<^bsub>\<rat>\<ge>0\<^bsup> (2\<^sub>\<S> |^ n2)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n)"
      using  arytm_3_th_52[of n] by mty auto
    hence "n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (n1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n)" using F1 N3 AS arytm_3_th_82Be by mty auto
    hence "n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using n1 arytm_3_def_12c by mty auto
    thus "n /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ ?N) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_53 by mty auto
  qed mauto
qed




text_raw {*\DefineSnippet{Rat2C}{*}
mdef Rat2C("rC _ " 110) where
  mlet "r be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  "func rC r  \<rightarrow> Function-of NAT,RAT means
     \<lambda>it. \<forall> n:Nat. it. n = (max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ n) *\<^sub>D (DEDEKIND_CUT r))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
text_raw {*}%EndSnippet*}
proof-
  let ?F ="\<lambda>n. (max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ n) *\<^sub>D (DEDEKIND_CUT r))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
  have A: "\<forall>x:Element-of NAT. ?F(x) be Element-of RAT"
  proof
    fix x assume [ty]:"x be Element-of NAT"
    have "?F(x) is Rat" by mty auto
    thus "?F(x) be Element-of RAT" using rat_0_def_3 Element(6) by mty auto
  qed mauto
  obtain F where [ty]: "F be Function-of NAT,RAT" and
     A2: "\<forall>x:Element-of NAT. (F . x) = ?F(x)"
    using funct_2_sch_4[OF _ _ A ] by mty auto
  show " \<exists>x : Function-of omega, RAT. \<forall>n : Nat. x . n =\<^sub>\<S> ?F(n)"
  proof(rule bexI[of _ F],auto)
    fix x assume [ty]: "x be natural"
    thus  "F . x =\<^sub>\<S> ?F(x)" using A2 by mty auto
  qed
  fix fg1 fg2 assume [ty]:"fg1 be Function-of omega, RAT"
           "fg2 be Function-of omega, RAT" and
           FG: "\<forall>n : Nat. fg1 . n =\<^sub>\<S> ?F(n)"
               " \<forall>n : Nat. fg2 . n =\<^sub>\<S> ?F(n)"
  have "for a be Element-of NAT holds fg1 . a = fg2 . a" 
  proof
    fix n assume [ty]:"n is Element-of NAT"
    have  "fg1 . n =\<^sub>\<S> ?F(n)" using FG(1) by mty auto
    thus "fg1. n = fg2. n" using FG(2) by mty auto
  qed mauto
  thus  "fg1 =\<^sub>\<S> fg2" using funct_2_def_7I[of NAT RAT] by mty auto
qed mauto

mtheorem
   mlet "r be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "x be object"
   "cluster (rC r). x \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub>"
proof(standard, cases "x is Nat")
  case [ty]: True
  hence "(rC r). x = (max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ x) *\<^sub>D (DEDEKIND_CUT r))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ x)" 
    using Rat2C by mty auto
  hence "(rC r). x = (max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ x) *\<^sub>D (DEDEKIND_CUT r))) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ x)" 
    using rat_1_div by mty auto
  thus "(rC r). x is (Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
next
  case False
  hence n:"not x in NAT" using ordinal1_def_12[of x] all_set by mty auto
  have [ty]:"rC r is Function" using all_set by mty auto
  have "RAT \<noteq> {}" using xboole_0_lm_2[of "RAT"] by mty auto
  hence "(dom rC r) = NAT" using funct_2_def_1[of NAT RAT "rC r"] by mty auto
  hence "(rC r). x = {}" using funct_1_def_2[of "rC r" x] n by mty auto 
  thus "(rC r). x is (Element-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
qed
text_raw {*\DefineSnippet{rCCauchy}{*}
mtheorem
   mlet "r be non empty\<bar>Element-of REAL\<^bsup>\<ge>0\<^bsub>"
   "cluster rC r \<rightarrow> Cauchy\<^sub>\<S>"
text_raw {*}%EndSnippet*}
proof(standard,rule CauchyI[THEN iffD2],simp,intro ballI impI)
  let ?D="DEDEKIND_CUT r"
  let ?r="rC r"
  have r:"r <>{}" using xboole_0_lm_2 by mty auto
  hence DD:"?D <>{}" using arytm_2_lm_10 by mty auto
  fix e assume [ty]: "e be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
        and "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  hence "e<>{}" using arytm_3_th_68 by mty auto
  then obtain N where [ty]:"N be Nat" and
     N: "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using arytm_th_10[of e] by mty auto
  hence "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N) <\<^sup>\<real> e" using rat_0_th_29 by mty auto
  hence N1: "1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) <\<^sup>\<real> e" using rat_1_div by mty auto
  show "\<exists>N : Nat. \<forall>n : Nat. \<forall>m : Nat. N \<subseteq> n \<and> N \<subseteq> m \<and> n in m \<longrightarrow> |. ?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n .| <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e"
  proof(rule bexI[of _ N],intro ballI impI)
    fix n m assume [ty]: "n be Nat" "m be Nat" and nm:"N \<subseteq> n \<and> N \<subseteq> m & n in m"
    then obtain k where [ty]:"k be Nat" and
      k: "k<>{} & m = n +\<^sub>\<S>\<^sup>\<nat> k" using Add_8 by mty auto
    hence nk:" 2\<^sub>\<S> |^ m =  (2\<^sub>\<S> |^ n)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ k)"       
      using  newton_th_6a by mty auto
    hence nk1: " 2\<^sub>\<S> |^ m =  (2\<^sub>\<S> |^ n)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)" 
      using int_1_def_5[of "2\<^sub>\<S> |^ n" "2\<^sub>\<S> |^ k"]  by mty auto
    have nk2: " 2\<^sub>\<S> |^ m =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ n)"   using Mult_6 nk by mty auto
    have D: "2\<^sub>\<S> |^ k<>{}" "2\<^sub>\<S> |^ n <>{}" "2\<^sub>\<S> |^ m <>{}" using newton_th_7 by mty auto
    let ?nD="(2\<^sub>\<S> |^ n) *\<^sub>D ?D"
    have DD1: "?nD <>{}" using arytm_th_1 D DD by mty auto
    have DD2: "( 2\<^sub>\<S> |^ m) *\<^sub>D ?D = (2\<^sub>\<S> |^ k)  *\<^sub>D ((2\<^sub>\<S> |^ n) *\<^sub>D ?D)" 
      using arytm_def_1M[of ?D "2\<^sub>\<S> |^ n" "2\<^sub>\<S> |^ k"] 
         D DD nk2 by mty auto
    let ?p="predecessor (2\<^sub>\<S> |^ k)"
    have pp: "succ ?p = (2\<^sub>\<S> |^ k)" using predec D by mty auto
    have "{} in k" using k one1 one2 by mty auto
    hence "2\<^sub>\<S> |^ {} in 2\<^sub>\<S> |^ k" using newton_th_8 xboole_0_def_10[of "2\<^sub>\<S>" "2\<^sub>\<S>"] all_set by mty auto
    hence "succ {} in 2\<^sub>\<S> |^ k" using newton_th_4 by mty auto
    hence "succ {} \<subseteq> ?p"  using ordinal1_th_18[of "?p"] pp by mty auto
    hence "{} in ?p" using ordinal1_th_17 by mty auto
    hence  sp: "?p <>{}" using xb by auto
    have "(max\<^sub>\<nat> ((2\<^sub>\<S> |^ k) *\<^sub>D ?nD)) \<subseteq> (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) +\<^sub>\<S>\<^sup>\<nat>  ?p" using  
         arytm_th_5[OF _ _  DD1 sp ] pp by mty auto 
    hence T1: "(max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ m) *\<^sub>D ?D)) \<subseteq> (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) +\<^sub>\<S>\<^sup>\<nat>  ?p" using DD2 by mty auto
   have L1: "(2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) \<subseteq> (max\<^sub>\<nat> (( 2\<^sub>\<S> |^ m) *\<^sub>D ?D))" using  
         arytm_th_4[OF _ _ DD1 D(1)] DD2 by mty auto 
    have rm: "?r . m = (max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ m) *\<^sub>D ?D)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ m)"
      using Rat2C[of r m] rat_1_div by mty auto
    hence rm1: "?r .m \<le>\<^sup>\<real> ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) +\<^sub>\<S>\<^sup>\<nat>  ?p)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m)" 
      using rat_1_th_23[OF _ _ _ _ T1] D by mty auto
    have " ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m) \<le>\<^sup>\<real> ?r .m" 
      using rat_1_th_23[OF _ _ _ _ L1 ] D rm by mty auto
    hence " ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?nD))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m) \<le>\<^sup>\<real> ?r .m" 
       using int_1_def_5 by mty auto
     hence rm2: " ( (max\<^sub>\<nat> ?nD) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m) \<le>\<^sup>\<real> ?r .m" using real_0_th_21 
       by mty auto
    have "?r . n = (max\<^sub>\<nat> (?nD)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"  using Rat2C[of r n] rat_1_div by mty auto
    hence "?r . n = ((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)) 
      /\<^sub>\<rat> (2\<^sub>\<S> |^ m) " using nk1 D rat_1_th_44[of _ "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ n"] by mty auto
  hence rn: " ((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)) 
      /\<^sub>\<rat> (2\<^sub>\<S> |^ m) \<le>\<^sup>\<real> ?r . n "     
    "?r . n \<le>\<^sup>\<real> ((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k))/\<^sub>\<rat> (2\<^sub>\<S> |^ m)"
    using real_0_def_8r by mty auto
  have R1: "(?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) \<le>\<^sup>\<real> ( ( ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) +\<^sub>\<S>\<^sup>\<nat>  ?p)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m) ) -\<^sub>\<S>\<^sup>\<real> 
(((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)) /\<^sub>\<rat> (2\<^sub>\<S> |^ m)))" using rat_1_th_17[OF _ _ _ _ rm1 rn(1)] by mty auto
  have "(( (max\<^sub>\<nat> ?nD) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m)) -\<^sub>\<S>\<^sup>\<real> 
(( (max\<^sub>\<nat> ?nD) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m))
\<le>\<^sup>\<real> (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n)  " using rat_1_th_17[OF _ _ _ _ rm2 rn(2)]  by mty auto
  hence R2: "{} \<le>\<^sup>\<real> (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n)" using rat_1_th_18 by mty auto
  have "( ( ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) +\<^sub>\<S>\<^sup>\<nat>  ?p)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ m) ) -\<^sub>\<S>\<^sup>\<real> 
(((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))) = 
( ( ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nD) +\<^sub>\<S>\<^sup>\<nat>  ?p)  +\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)))) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))"
    using rat_1_th_47m D by mty auto 
  also have "... =
( ( (((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?nD)) +\<^sub>\<S>\<^sup>\<real>   ?p)  +\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)))) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))"
    using int_1_def_5 int_1_def_3[of _ "?p"] by mty auto
  also have "... =
( ( (( (max\<^sub>\<nat> ?nD) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)) +\<^sub>\<S>\<^sup>\<real>   ?p)  +\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ( ?nD))*\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)))) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))"
    using real_0_th_21 by mty auto
  also have "... =   ((?p) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))" using 
    int_1_th_22[of ?p] by mty auto
  finally have "(?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) \<le>\<^sup>\<real> ((?p) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))" using R1 by mty auto
  hence G: "|. (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) .| \<le>\<^sup>\<real> ((?p) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))" using absvalue_def_1 R2 by mty auto
have K1:" m = k +\<^sub>\<S>\<^sup>\<nat> n" using k Add_6 by mty auto
 have "?p in (2\<^sub>\<S> |^ k)" using pp ordinal1_th_2[of ?p] by mty auto
  hence "((?p) /\<^sub>\<rat> (2\<^sub>\<S> |^ m)) <\<^sup>\<real> ((2\<^sub>\<S> |^ k) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))" using D rat_1_th_24 by mty auto
  hence "|. (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) .| <\<^sup>\<real> ((2\<^sub>\<S> |^ k) /\<^sub>\<rat> (2\<^sub>\<S> |^ m))" 
    using G rat_0_def_8t1[OF _ _ _ G] by mty auto
  hence RG: "|. (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) .| <\<^sup>\<real> ((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ n))" 
    using K1 arytm_th_11 by mty auto
  obtain kk where [ty]:"kk be Nat" and
      kk: " n = N +\<^sub>\<S>\<^sup>\<nat> kk" using nm Add_9[of n N] by mty auto
  hence kk1: " n = kk +\<^sub>\<S>\<^sup>\<nat> N" using Add_6 by mty auto
  have "(2\<^sub>\<S> |^ kk)<>{}" using  newton_th_7 by mty auto
  hence "succ {} \<subseteq> (2\<^sub>\<S> |^ kk)" using one1 one2 by mty auto
  hence "((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ n))\<le>\<^sup>\<real>  ((2\<^sub>\<S> |^ kk) /\<^sub>\<rat> (2\<^sub>\<S> |^ n))" 
    using rat_1_th_23[of "2\<^sub>\<S> |^ kk" "succ {}" "2\<^sub>\<S> |^ n"] D by mty auto
  hence "((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ n))\<le>\<^sup>\<real>  ((succ{}) /\<^sub>\<rat> (2\<^sub>\<S> |^ N))"  
     using kk1 arytm_th_11[of _ kk "2\<^sub>\<S>"] by mty auto
  hence "((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ n)) <\<^sup>\<real> e" using rat_0_def_8t1[OF _ _ _ _ N1] by mty auto
  hence  "((succ {}) /\<^sub>\<rat> (2\<^sub>\<S> |^ n)) \<le>\<^sup>\<real> e" using real_0_th_33 by mty auto
  hence  "|. (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) .|<\<^sup>\<real> e" using rat_0_def_8t2[OF _ _ _ RG] by mty auto
  thus  "|. (?r . m -\<^sub>\<S>\<^sup>\<real> ?r . n) .|<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using rat_0_th_29 by mty auto
qed mauto
qed mauto


reserve r,s for "non empty\<bar>Element-of REAL\<^bsup>\<ge>0\<^bsub>"
text_raw {*\DefineSnippet{MultV}{*}
mtheorem MultV:
   "(rC (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) (-) ((rC r) (*) (rC s)) is vanishes\<^sub>\<rat>" 
text_raw {*}%EndSnippet*}
proof(standard,simp,intro ballI impI)
    fix e assume [ty]: "e be Rat"
         and
         E: "{} <\<^sup>\<real> e"
  hence E1: "{}\<le>\<^sup>\<real> e" "e<>{}" using real_0_th_33 by mty auto
  hence [ty]: "e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_Q by mty auto
  have R: "{}<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using E rat_0_th_29 by mty auto
  obtain  r1 where [ty]:"r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    r1: " r1 <>{} & (for n holds |. (rC r) . n .| \<le>\<^sup>\<real> r1)" using Cauchy_min[of "rC r"] by mty auto
  obtain rM where [ty]:"rM is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    rM:"rM in omega & r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rM *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ{})" using arytm_3_th_95[of r1 "succ{}"] by mty auto
  hence [ty]:"rM is Element-of NAT" using Element(6)[of NAT] by mty auto 
  obtain  s1 where [ty]:"s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    s1: " s1 <>{} & (for n holds |. (rC s) . n .| \<le>\<^sup>\<real> s1)" using Cauchy_min[of "rC s"] by mty auto
  obtain sM where [ty]:"rM is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    sM:"sM in omega & s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> sM *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ{})" using arytm_3_th_95[of s1 "succ{}"] by mty auto
  hence [ty]:"sM is Element-of NAT" using Element(6)[of NAT] by mty auto 
  let ?N ="rM +\<^sub>\<S>\<^sup>\<nat> (sM  +\<^sub>\<S>\<^sup>\<nat> (succ {}))"
  have "sM  +\<^sub>\<S>\<^sup>\<nat> (succ {}) <>{}" using Add_14[of "succ {}" sM] by mty auto
  hence "?N <>{}" using Add_14[of _ rM] by mty auto
  then obtain N where [ty]:"N is Nat" and 
   N:    "?N /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using arytm_th_12[of ?N e] R E1 by mty auto
  hence "?N /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N) <\<^sup>\<real> e" using rat_0_th_29 by mty auto
  hence NQ: "?N /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) <\<^sup>\<real> e" using rat_1_div by mty auto
  let ?r="rC r" let ?s="rC s"
  let ?rs="rC (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
  let ?R="DEDEKIND_CUT r"
  let ?S="DEDEKIND_CUT s"
  have r:"r <>{}" "s<>{}" using xboole_0_lm_2 by mty auto
  hence DD:"?R <>{}" "?S<>{}" using arytm_2_lm_10 by mty auto
  let ?NN="N +\<^sub>\<S>\<^sup>\<nat> N"
  show "\<exists>k : Nat. \<forall>n : Nat. k \<subseteq> n \<longrightarrow> |. ((rC (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) ) (-) ((rC r ) (*) (rC s ))) . n .| <\<^sup>\<real> e"
  proof(rule bexI[of _ ?NN], intro ballI impI)
  fix n assume [ty]: "n be Nat" and nm:" ?NN \<subseteq> n "
        then obtain k where [ty]:"k be Nat" and
      k: "  n = ?NN +\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by mty auto
        let ?kN = "k +\<^sub>\<S>\<^sup>\<nat>  N"
    have k1: "n = k +\<^sub>\<S>\<^sup>\<nat> ?NN" using  Add_6[of ?NN k] k by mty auto
    hence k2: "n =  ?kN +\<^sub>\<S>\<^sup>\<nat>  N" using Add_7 by mty auto
    hence nk:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ ?NN)"
             " 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ ?kN)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ N)" 
             "2\<^sub>\<S> |^ ?NN = (2\<^sub>\<S> |^ N) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ N)" 
      using  newton_th_6a[of ?NN k] newton_th_6a[of N ?kN] 
             newton_th_6a[of N N] k1 by mty auto
    hence nk1:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ ?NN)"       
              "2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ ?kN)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ N)"
              "2\<^sub>\<S> |^ ?NN =  (2\<^sub>\<S> |^ N)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ N)"
      using int_1_def_5[of "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ ?NN"] 
            int_1_def_5[of "2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"]
               int_1_def_5[of "2\<^sub>\<S> |^ N" "2\<^sub>\<S> |^ N"]
            by mty auto
    have D: "2\<^sub>\<S> |^ k<>{}" "2\<^sub>\<S> |^ n <>{}" "2\<^sub>\<S> |^ N <>{}" "2\<^sub>\<S> |^ ?kN <>{}" "2\<^sub>\<S> |^ ?NN <>{}"
     using newton_th_7 by mty auto
    let ?NR="(2\<^sub>\<S> |^ N) *\<^sub>D ?R"
    let ?NS="(2\<^sub>\<S> |^ N) *\<^sub>D ?S"
    let ?nR="(2\<^sub>\<S> |^ n) *\<^sub>D ?R"
    let ?nS="(2\<^sub>\<S> |^ n) *\<^sub>D ?S"
    have DD1: "?NR <>{}" "?NS <>{}" "?nR<>{}" "?nS<>{}" 
      using arytm_th_1 D DD by mty auto
    hence dd1:"?NR *D ?NS<>{}" "?R *D ?S <>{}"
      using arytm_th_6M D DD by mty auto
    hence dd2:"(2\<^sub>\<S> |^ n) *\<^sub>D (?R *D ?S) <>{}" using arytm_th_1 D DD by mty auto  
    have DD2: "( 2\<^sub>\<S> |^ n) *\<^sub>D ?R = (2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NR)"
              "( 2\<^sub>\<S> |^ n) *\<^sub>D ?S = (2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NS)"
      using arytm_def_1M[of _ "2\<^sub>\<S> |^ N" "2\<^sub>\<S> |^ ?kN"] 
         D DD nk  by mty auto
    have  "max\<^sub>\<nat> ((2\<^sub>\<S> |^ k) *\<^sub>D (?NR *D ?NS)) in
    ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})))"
      using arytm_th_8M[of "2\<^sub>\<S> |^ k" ?NS ?NR] DD1 D by mty auto
    hence M: "max\<^sub>\<nat> ((2\<^sub>\<S> |^ k) *\<^sub>D (?NR *D ?NS)) \<subseteq>
      ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})))"
      using  ordinal1_def_2[of "((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})))"]
       all_set by mty auto
    have "(DEDEKIND_CUT (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = DEDEKIND_CUT(GLUED((DEDEKIND_CUT r) *D (DEDEKIND_CUT s)))" 
      using r arytm_2_def_9[of r s] by mty auto
    hence DRS: "(DEDEKIND_CUT (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) =?R *D ?S"
      using arytm_2_lm_12 by mty auto
    have cs0: "( 2\<^sub>\<S> |^ n) *\<^sub>D (?R *D ?S) = (2\<^sub>\<S> |^ k)  *\<^sub>D ( (2\<^sub>\<S> |^ ?NN) *\<^sub>D (?R *D ?S))" 
        using arytm_def_1M[of _  "2\<^sub>\<S> |^ ?NN" "2\<^sub>\<S> |^ k"] D nk by mty auto
    hence cs2: "( 2\<^sub>\<S> |^ n) *\<^sub>D (?R *D ?S) = (2\<^sub>\<S> |^ k) *\<^sub>D (?NR *D ?NS)"
      using D nk arytm_def_1MM[of ?S ?R "2\<^sub>\<S> |^ N" "2\<^sub>\<S> |^ N"] by mty auto  
    hence  cs1: "((?rs) .n) = ((max\<^sub>\<nat> ((2\<^sub>\<S> |^ k) *\<^sub>D (?NR *D ?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))"
      using Rat2C[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" n,simplified] DRS by mty auto
    hence t1:"((?rs) .n) \<le>\<^sup>\<real> (((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))))
           /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using rat_1_th_23[OF _ _ _ _ M] D by mty auto 
    have "(2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))
 = (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<real>  (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))"
      using int_1_def_5[of "2\<^sub>\<S> |^ k"]  by mty auto 
    hence "(2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))
 =  (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)"
      using real_0_th_21  by mty auto    
    hence"((?rs) .n) \<le>\<^sup>\<real> ((( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k))
           /\<^sub>\<rat> ((2\<^sub>\<S> |^ ?NN)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k))" using t1 nk1 real_0_th_21[of "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ ?NN"] 
      by mty auto    
    hence T1: "((?rs) .n) \<le>\<^sup>\<real>
         (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))
           /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" using 
      rat_1_th_44[of "( (( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})))"
           "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ ?NN"] D  by mty auto
    have P1: "?r . n = (max\<^sub>\<nat> ((2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
         "?s . n = (max\<^sub>\<nat> (( 2\<^sub>\<S> |^ ?kN) *\<^sub>D ?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
      using Rat2C[of _ n] rat_1_div DD2 by mty auto    
    have P2: "((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) \<subseteq> (max\<^sub>\<nat> ((2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NR)))"
             "((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) \<subseteq> (max\<^sub>\<nat> ((2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NS)))"
      using arytm_th_4 DD1 D by mty auto
    have [ty]:"(  (max\<^sub>\<nat> (?NR)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (  (max\<^sub>\<nat> (?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) 
        is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
    have [ty]:"(?r. n )*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?s.n) is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto    
    have "(?r (*) ?s) . n= (?r. n )*\<^sub>\<S>\<^sup>\<real>  (?s.n)" using seq_M[of ?r ?s] by mty auto
    hence P3: "(?r (*) ?s) . n= (?r. n )*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?s.n)" using real_0_def_7 Prat_Preal_mult by mty auto
    have "((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)
      = (  (max\<^sub>\<nat> (?NR))  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ ?kN)  ) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using Mult_6 by mty auto 
    also have "... = (  (max\<^sub>\<nat> (?NR))  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ ?kN)  ) /\<^sub>\<rat> ((2\<^sub>\<S> |^ N)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ ?kN))"
      using int_1_def_5[of _ "2\<^sub>\<S> |^ ?kN"] nk1 real_0_th_21[of "2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"]  by mty auto
    finally have I1: "((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = ((max\<^sub>\<nat> (?NR))  ) /\<^sub>\<rat> ((2\<^sub>\<S> |^ N)  )" 
      using  rat_1_th_44[of "max\<^sub>\<nat> (?NR)" "2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"] D by mty auto 
    have "((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)
      = (  (max\<^sub>\<nat> (?NS))  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ ?kN)  ) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using Mult_6 by mty auto 
    also have "... = (  (max\<^sub>\<nat> (?NS))  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ ?kN)  ) /\<^sub>\<rat> ((2\<^sub>\<S> |^ N)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ ?kN))"
      using int_1_def_5[of _ "2\<^sub>\<S> |^ ?kN"] nk1 real_0_th_21[of "2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"]  by mty auto
    finally have I2: "((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = ((max\<^sub>\<nat> (?NS))  ) /\<^sub>\<rat> ((2\<^sub>\<S> |^ N)  )" 
      using  rat_1_th_44[of "max\<^sub>\<nat> (?NS)" "2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"] D by mty auto 
    have " (((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))  \<le>\<^sup>\<real>
        ((max\<^sub>\<nat> ((2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NR)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))" 
         " (((2\<^sub>\<S> |^ ?kN)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))  \<le>\<^sup>\<real> 
        ((max\<^sub>\<nat> ((2\<^sub>\<S> |^ ?kN)  *\<^sub>D (?NS)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))"
      using rat_1_th_23[OF _ _ _ D(2) P2(1)] rat_1_th_23[OF _ _ _ D(2) P2(2)]
              by mty auto            
    hence "(  (max\<^sub>\<nat> (?NR)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?r.n"
          "((max\<^sub>\<nat> (?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s.n"
      using P1 rat_0_th_29 I1 I2 by mty auto
    hence R: "(  (max\<^sub>\<nat> (?NR)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (  (max\<^sub>\<nat> (?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))
      \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((?r. n )*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?s.n))" using P3 arytm_3_th_82B by mty auto 
    have  R1: "((max\<^sub>\<nat> (?NR)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (  (max\<^sub>\<nat> (?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))
      \<le>\<^sup>\<real> ((?r (*) ?s) . n)" using rat_0_th_29[THEN iffD1, OF _ _ R]  P3  by mty auto 
    have "((max\<^sub>\<nat> (?NR)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (  (max\<^sub>\<nat> (?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) = 
     ((max\<^sub>\<nat> (?NR)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^sup>\<real>  (  (max\<^sub>\<nat> (?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" using real_0_def_7 
      Prat_Preal_mult by mty auto
    also have "... = ((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> (( 2\<^sub>\<S> |^ ?NN)) "
      using rat_1_th_14[OF _ _ _ _ D(3) D(3)] nk1(3) by mty auto
    finally have R2:"((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> (( 2\<^sub>\<S> |^ ?NN)) \<le>\<^sup>\<real> ((?r (*) ?s) . n)" 
      using R1 by mty auto
    have [ty]: "(max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS) is Nat" using int_1_def_5(1)[of "max\<^sub>\<nat> ?NR" "max\<^sub>\<nat> ?NS"] 
      by mty auto
    have [ty]:"((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) is Nat" by mty auto
      have "((( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))
           /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN))-\<^sub>\<S>\<^sup>\<real> (((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> (( 2\<^sub>\<S> |^ ?NN))) =      
   (( ( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})) 
     +\<^sub>\<S>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real>  (((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" 
      using rat_1_th_47m[OF _ _ _  D(5),of "(max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))"]  by mty auto
    also have "... = (( ( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> 
                      ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})) 
     +\<^sub>\<S>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real>  (((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" using int_1_def_5 by mty auto 
    also have "... = (( ( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<real>  
                     ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})) 
     +\<^sub>\<S>\<^sup>\<real>  -\<^sub>\<S>\<^sup>\<real>  (((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" using 
            int_1_def_3[of "(max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS)" "(max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}",
           simplified] 
           by mty auto 
    also have "... = ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" 
      using int_1_th_22 by mty auto
    finally have th0:  "((( (max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) )  +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}))
           /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN))-\<^sub>\<S>\<^sup>\<real> (((max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> (( 2\<^sub>\<S> |^ ?NN)))
= ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" by mty auto
    hence th1: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real>  ((?r (*) ?s) . n)\<le>\<^sup>\<real> 
         ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" 
      using rat_1_th_17[OF _ _ _ _  T1 R2] by mty auto
    have K: "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)
= ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N)" 
  using rat_1_div[of _ " 2\<^sub>\<S> |^ N"] by mty auto 
    have  "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> ?N"
    proof-
      have "2\<^sub>\<S> |^ N<>{}" using newton_th_7 by mty auto
      hence "succ {} \<subseteq> 2\<^sub>\<S> |^ N" using one2 by mty auto
      hence "(succ {})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> (2\<^sub>\<S> |^ N)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)" using rat_1_th_23 D(3) by mty auto
      hence "(succ {})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> (2\<^sub>\<S> |^ N)/\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N)" using rat_1_div by mty auto
      hence J1: "(succ{})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> succ{}" using arytm_3_th_41 D(3) by mty auto
    have A1: "?r . N = (max\<^sub>\<nat> ?NR) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)"
               "?s . N = (max\<^sub>\<nat> ?NS) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)"       
      using Rat2C[of _ N] rat_1_div DD2 by mty auto     
    have "{} \<le>\<^sup>\<real> (?r . N)" "{} \<le>\<^sup>\<real> (?s . N)" using rat_0_Q by mty auto
    hence A2: "|. (?r . N) .| = ?r. N" "|. (?s . N) .| = ?s. N"       
      using absvalue_def_1 by mty auto
    have "rM +\<^sub>\<S>\<^sup>\<real>  sM = rM +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> sM" "rM +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> sM =\<^sub>\<S> rM +\<^sub>\<S>\<^sup>\<nat> sM"
      using arytm_3_th_58[of sM rM] Prat_Preal_add[of rM sM] real_0_def_4 by mty auto
    hence "(rM +\<^sub>\<S>\<^sup>\<real>  sM)+\<^sub>\<S>\<^sup>\<real>  (succ{}) = (rM +\<^sub>\<S>\<^sup>\<nat> sM)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ{})" 
       using real_0_def_4 Prat_Preal_add[of _ "succ{}"]  by mty auto
    hence "(rM +\<^sub>\<S>\<^sup>\<real>  sM)+\<^sub>\<S>\<^sup>\<real>  (succ{}) = (rM +\<^sub>\<S>\<^sup>\<nat> sM)+\<^sub>\<S>\<^sup>\<nat> (succ{})" 
       using arytm_3_th_58 by mty auto
    hence n: "(rM +\<^sub>\<S>\<^sup>\<real>  sM)+\<^sub>\<S>\<^sup>\<real>  (succ{}) = ?N" using Add_7  by mty auto    
    have "r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rM" "s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> sM" using rM sM arytm_3_th_53 by mty auto
    hence "|. ?r . N .| \<le>\<^sup>\<real> r1" "r1 \<le>\<^sup>\<real> rM" 
          "|. ?s . N .| \<le>\<^sup>\<real> s1" "s1 \<le>\<^sup>\<real> sM" using r1 s1 rat_0_th_29 by mty auto 
    hence A3: "(max\<^sub>\<nat> ?NR)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> rM" "(max\<^sub>\<nat> ?NS)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> sM" using A2 A1
       rat_0_def_8t[of rM r1] rat_0_def_8t[of sM s1] by mty auto 
    have a3: "((max\<^sub>\<nat> ?NR)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))+\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ?NS)/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) \<le>\<^sup>\<real> rM +\<^sub>\<S>\<^sup>\<real>  sM"
      using rat_1_th_16[OF _ _ _ _ A3(1) A3(2)] by mty auto
    hence aa3: "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> rM +\<^sub>\<S>\<^sup>\<real>  sM" 
      using rat_1_th_47 D(3) by mty auto
    hence "(((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) +\<^sub>\<S>\<^sup>\<real>  
       ((succ{})/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) \<le>\<^sup>\<real> (rM +\<^sub>\<S>\<^sup>\<real>  sM) +\<^sub>\<S>\<^sup>\<real>  (succ{})" 
      using rat_1_th_16[OF _ _ _ _ _ J1] by mty auto
    hence "((((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS)) +\<^sub>\<S>\<^sup>\<real>  (succ{}))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) \<le>\<^sup>\<real> ?N" 
      using rat_1_th_47 D(3) n by mty auto
    hence "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<real>  (succ{}))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> ?N" 
      using real_0_th_15[of "succ {}" "max\<^sub>\<nat> ?NS" "max\<^sub>\<nat> ?NR",simplified] by mty auto
    hence "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ?NS)  +\<^sub>\<S>\<^sup>\<nat> (succ{})))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> ?N" 
      using int_1_def_3[of "max\<^sub>\<nat> ?NS" "succ{}",simplified] by mty auto
    hence "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NS)  +\<^sub>\<S>\<^sup>\<nat> (succ{})))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> ?N" 
      using int_1_def_3[of "max\<^sub>\<nat> ?NR"] by mty auto
    thus "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) \<le>\<^sup>\<real> ?N" using Add_7 by mty auto
   qed
    hence E: "((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?N"
      using rat_0_th_29
         K by mty auto
    hence "(((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))
    \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?N *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" using arytm_3_th_82 by mty auto 
  hence E1:"(((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))
    \<le>\<^sup>\<real> ?N *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" using rat_0_th_29 K by mty auto 
  have "?N = ?N /\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})" using arytm_3_th_40[of ?N ?N,simplified] by mty auto
  hence "?N *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) = ( ?N /\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {})  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))"
    using arytm_3_th_40[of ?N,simplified] by mty auto
  also have "... = ( ?N  /\<^sub>\<rat> (succ {})) *\<^sub>\<S>\<^sup>\<real>  ((succ {})  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" 
    using rat_1_div[of ?N "succ{}"] real_0_def_7 Prat_Preal_mult by mty auto
  also have "... = ( ?N *\<^sub>\<S>\<^sup>\<real>  (succ {})) /\<^sub>\<rat> ((succ {}) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ N))"
    using rat_1_th_14[of "succ {}" ?N "2\<^sub>\<S> |^ N" "succ{}"] D(3) by mty auto
  finally have "?N *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) = ( ?N *\<^sub>\<S>\<^sup>\<real>  (succ {})) /\<^sub>\<rat> ((succ {}) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ N))"
    using rat_1_th_14[of "succ {}" ?N "2\<^sub>\<S> |^ N" "succ{}"] D(3) by mty auto
  hence "?N *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) = 
       ( ?N *\<^sub>\<S>\<^sup>\<nat> (succ {})) /\<^sub>\<rat> ((succ {}) *\<^sub>\<S>\<^sup>\<nat> ( 2\<^sub>\<S> |^ N))"
    using int_1_def_5[of ?N "succ {}"]  int_1_def_5[of "succ{}"] by mty auto
  hence nn: "?N *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) = ?N  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)"
    using Mult_5[of ?N] Mult_5[of "2\<^sub>\<S> |^ N"] by mty auto
  have "(((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))
= (((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^sup>\<real>  ((succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))"
    using real_0_def_7 Prat_Preal_mult by mty auto
  also have "... =(((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})*\<^sub>\<S>\<^sup>\<real>  (succ {})) /\<^sub>\<rat> (( 2\<^sub>\<S> |^ N) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ N))"
    using rat_1_th_14 D(3) by mty auto 
  also have "... =(((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {})*\<^sub>\<S>\<^sup>\<nat> (succ {})) /\<^sub>\<rat> (( 2\<^sub>\<S> |^ N) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ N))"
    using int_1_def_5 by mty auto 
  also have "...   =( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)"
    using Mult_5 nk1 by mty auto
  finally have fh: "( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN) \<le>\<^sup>\<real> ?N  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)"
    using E1 nn by mty auto
  hence U: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real>  ((?r (*) ?s) . n)\<le>\<^sup>\<real> ?N  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)" 
    using rat_0_def_8t[OF _ _ _ th1]
    by mty auto
  have th2: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real>  ((?r (*) ?s) . n)<\<^sup>\<real> e" using rat_0_def_8t1[OF  _ _ _ U NQ] by mty auto
  have th3: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real>  ((?r (*) ?s) . n) = 
    ((rC r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s ) (-) ((rC r ) (*) (rC s ))) . n" using seq_m by mty auto 
 have h1:"(2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> max\<^sub>\<nat> (?NR *D ?NS)  \<subseteq>  max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)*\<^sub>D(?NR *D ?NS))" 
   using arytm_th_4 D(1) dd1 by mty auto 
 have "(max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) \<subseteq>  max\<^sub>\<nat> (?NR *D ?NS)"
   using arytm_th_7M DD1 by mty auto
  hence "(2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS)) \<subseteq> (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> max\<^sub>\<nat> (?NR *D ?NS)"
    using Mult_12 by mty auto
  hence "(2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS)) \<subseteq> max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)*\<^sub>D(?NR *D ?NS))"
    using xboole_1_th_1[OF _ _ _ _ h1] all_set by mty auto
  hence h0: "((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) 
      \<le>\<^sup>\<real>  ((?rs) .n)"
    using rat_1_th_23 D cs1 by mty auto
  have "((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = 
         ((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" 
    using int_1_def_5[of "2\<^sub>\<S> |^ k"] by mty auto
  also have "... = ( ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS)) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)  )/\<^sub>\<rat> ((2\<^sub>\<S> |^ ?NN) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ k)  )"
    using nk1 nk real_0_th_21[of "2\<^sub>\<S> |^ k"]  by mty auto
  finally have h: "( ((max\<^sub>\<nat> ?NR) *\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?NS))   )/\<^sub>\<rat> ((2\<^sub>\<S> |^ ?NN) ) 
     \<le>\<^sup>\<real> ((?rs) .n)" using h0 rat_1_th_44[of _ "2\<^sub>\<S> |^ k" "2\<^sub>\<S> |^ ?NN"] int_1_def_5 D by mty auto
  have "max\<^sub>\<nat> (( 2\<^sub>\<S> |^ ?kN) *\<^sub>D ?NR) \<subseteq> ( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NR))"
     using arytm_th_5C DD1 by mty auto
   hence "(max\<^sub>\<nat> (( 2\<^sub>\<S> |^ ?kN) *\<^sub>D ?NR))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) 
      \<le>\<^sup>\<real>  (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using rat_1_th_23 D cs1 by mty auto
  hence rQ: "?r. n \<le>\<^sup>\<real>  (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using DD2  Rat2C[of _ n] by mty auto

  have "(( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = 
         (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<real>  (succ max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using int_1_def_5[of "2\<^sub>\<S> |^ ?kN"]
    by mty auto
  also have "... =  (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<real>  (succ max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> (  (2\<^sub>\<S> |^ ?kN)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ N))"
    using nk1 by auto
  also have "... =  ( (succ max\<^sub>\<nat> (?NR)) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ ?kN) ) /\<^sub>\<rat> (   (2\<^sub>\<S> |^ N) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ ?kN) )"
    using real_0_th_21[of "2\<^sub>\<S> |^ ?kN"] by mty auto
  also have "... =  ( (succ max\<^sub>\<nat> (?NR))) /\<^sub>\<rat>  (2\<^sub>\<S> |^ N)"
    using rat_1_th_44[of "succ max\<^sub>\<nat> (?NR)" " 2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"] D by mty auto
  finally have "?r. n \<le>\<^sup>\<real> (succ max\<^sub>\<nat> (?NR)) /\<^sub>\<rat>  (2\<^sub>\<S> |^ N)" using rQ by mty auto
  hence "?r. n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ max\<^sub>\<nat> (?NR)) /\<^sub>\<rat>  (2\<^sub>\<S> |^ N)" using rat_0_th_29 by mty auto
  hence rR:"?r. n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ max\<^sub>\<nat> (?NR)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (2\<^sub>\<S> |^ N)" using rat_1_div by mty auto


    have "max\<^sub>\<nat> (( 2\<^sub>\<S> |^ ?kN) *\<^sub>D ?NS) \<subseteq> ( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NS))"
     using arytm_th_5C DD1 by mty auto
   hence "(max\<^sub>\<nat> (( 2\<^sub>\<S> |^ ?kN) *\<^sub>D ?NS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) 
      \<le>\<^sup>\<real>  (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using rat_1_th_23 D cs1 by mty auto
  hence sQ: "?s. n \<le>\<^sup>\<real>  (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using DD2  Rat2C[of _ n] by mty auto

  have "(( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = 
         (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<real>  (succ max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using int_1_def_5[of "2\<^sub>\<S> |^ ?kN"]
    by mty auto
  also have "... =  (( 2\<^sub>\<S> |^ ?kN) *\<^sub>\<S>\<^sup>\<real>  (succ max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> (  (2\<^sub>\<S> |^ ?kN)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ N))"
    using nk1 by auto
  also have "... =  ( (succ max\<^sub>\<nat> (?NS)) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ ?kN) ) /\<^sub>\<rat> (   (2\<^sub>\<S> |^ N) *\<^sub>\<S>\<^sup>\<real>  ( 2\<^sub>\<S> |^ ?kN) )"
    using real_0_th_21[of "2\<^sub>\<S> |^ ?kN"] by mty auto
  also have "... =  ( (succ max\<^sub>\<nat> (?NS))) /\<^sub>\<rat>  (2\<^sub>\<S> |^ N)"
    using rat_1_th_44[of "succ max\<^sub>\<nat> (?NS)" " 2\<^sub>\<S> |^ ?kN" "2\<^sub>\<S> |^ N"] D by mty auto
  finally have "?s. n \<le>\<^sup>\<real> (succ max\<^sub>\<nat> (?NS)) /\<^sub>\<rat>  (2\<^sub>\<S> |^ N)" using sQ by mty auto
  hence "?s. n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ max\<^sub>\<nat> (?NS)) /\<^sub>\<rat>  (2\<^sub>\<S> |^ N)" using rat_0_th_29 by mty auto
 hence sR:"?s. n \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ max\<^sub>\<nat> (?NS)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (2\<^sub>\<S> |^ N)" using rat_1_div by mty auto

  hence rsR: "(?r.n ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (?s . n) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( (succ max\<^sub>\<nat> (?NR)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (2\<^sub>\<S> |^ N))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( (succ max\<^sub>\<nat> (?NS)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (2\<^sub>\<S> |^ N))"
    using rR arytm_3_th_82B[OF _ _ _ _ rR sR,simplified] P3 by mty auto

  have "( (succ max\<^sub>\<nat> (?NR)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (2\<^sub>\<S> |^ N))*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( (succ max\<^sub>\<nat> (?NS)) /\<^bsub>\<rat>\<ge>0\<^bsup>  (2\<^sub>\<S> |^ N)) =
      ((succ max\<^sub>\<nat> (?NR))*\<^sub>\<S>\<^sup>\<nat> (succ max\<^sub>\<nat> (?NS)))  /\<^bsub>\<rat>\<ge>0\<^bsup>  ((2\<^sub>\<S> |^ N) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ N))" using arytm_3_th_49
    by mty auto
  also have  "... = ( ((max\<^sub>\<nat> (?NR))*\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS))) +\<^sub>\<S>\<^sup>\<nat>
      ((max\<^sub>\<nat> (?NR)) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS)) +\<^sub>\<S>\<^sup>\<nat> succ {})) /\<^bsub>\<rat>\<ge>0\<^bsup>  ((2\<^sub>\<S> |^ ?NN))" using nk
    Mult_17[of "max\<^sub>\<nat> (?NS)" "max\<^sub>\<nat> (?NR)"] by mty auto
  finally have  "(?r.n ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (?s . n) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>
 ( ((max\<^sub>\<nat> (?NR))*\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS))) +\<^sub>\<S>\<^sup>\<nat>
      ((max\<^sub>\<nat> (?NR)) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS)) +\<^sub>\<S>\<^sup>\<nat> succ {})) /\<^bsub>\<rat>\<ge>0\<^bsup>  ((2\<^sub>\<S> |^ ?NN))"
    using rsR by mty auto
  hence "(?r.n ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (?s . n) \<le>\<^sup>\<real>
 ( ((max\<^sub>\<nat> (?NR))*\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS))) +\<^sub>\<S>\<^sup>\<nat>
      ((max\<^sub>\<nat> (?NR)) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS)) +\<^sub>\<S>\<^sup>\<nat> succ {})) /\<^bsub>\<rat>\<ge>0\<^bsup>  ((2\<^sub>\<S> |^ ?NN))"
    using rat_0_th_29[THEN iffD1] by mty auto
  hence temp: "(?r.n ) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (?s . n) \<le>\<^sup>\<real>
 ( ((max\<^sub>\<nat> (?NR))*\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS))) +\<^sub>\<S>\<^sup>\<nat>
      ((max\<^sub>\<nat> (?NR)) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> (?NS)) +\<^sub>\<S>\<^sup>\<nat> succ {})) /\<^sub>\<rat>  ((2\<^sub>\<S> |^ ?NN))"
    using rat_1_div by mty auto


 have u0: "((?r (*) ?s) . n) -\<^sub>\<S>\<^sup>\<real> ((?rs) .n) \<le>\<^sup>\<real>   
( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS) +\<^sub>\<S>\<^sup>\<nat> succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ ?NN)" 
   using rat_1_th_17[OF _ _ _ _ temp h] P3 th0 by mty auto
  hence u:"((?r (*) ?s) . n) -\<^sub>\<S>\<^sup>\<real> ((?rs) .n) \<le>\<^sup>\<real> ( ?N  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" 
    using rat_0_def_8t[OF _ _ _ u0 fh] 
     by mty auto
   have  "(((?r (*) ?s) . n) -\<^sub>\<S>\<^sup>\<real> ((?rs) .n))<\<^sup>\<real> e" using rat_0_def_8t1[OF  _ _ _ u NQ] by mty auto
   hence "(-\<^sub>\<S>\<^sup>\<real> e) <\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (((?r (*) ?s) . n) -\<^sub>\<S>\<^sup>\<real> ((?rs) .n)))" using real_0_th_30 by mty auto
   hence "(-\<^sub>\<S>\<^sup>\<real> e) <\<^sup>\<real> (((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (*) ?s) . n ))" using 
     rat_1_th_22[of "(?rs) .n" "((?r (*) ?s) . n)"]
     by mty auto
   thus "|. ((rC r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s ) (-) ((rC r ) (*) (rC s ))) . n .| <\<^sup>\<real> e"
     using th2 th3 absvalue_th_5a[THEN iffD1] by mty auto
  qed mauto
qed mauto


text_raw {*\DefineSnippet{AddV}{*}
mtheorem AddV:
   "(rC (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) (-) ((rC r) (+) (rC s))  is vanishes\<^sub>\<rat>" 
text_raw {*}%EndSnippet*}
proof(standard,simp,intro ballI impI)
  fix e assume [ty]: 
         "e be Rat"
         and
         E: "{} <\<^sup>\<real> e"
  hence E1: "{}\<le>\<^sup>\<real> e" "e<>{}" using real_0_th_33 by mty auto
  hence [ty]: "e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using rat_0_Q by mty auto
  obtain nn where [ty]:"nn be Nat" and
     N: "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using arytm_th_10[of e] E1 by mty auto
  hence "1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ nn) <\<^sup>\<real> e" using rat_0_th_29 by mty auto
  hence NQ:"1\<^sub>\<S> /\<^sub>\<rat> ( 2\<^sub>\<S> |^ nn) <\<^sup>\<real> e" using rat_1_div by mty auto
  have "(succ nn) is Nat" by mty auto
  then obtain N where [ty]:"N be Nat" and NN:"N=succ nn" by mty auto
  let ?r="rC r" let ?s="rC s"
  let ?rs="rC (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
  let ?R="DEDEKIND_CUT r"
  let ?S="DEDEKIND_CUT s"
  have r:"r <>{}" "s<>{}" using xboole_0_lm_2 by mty auto
  hence DD:"?R <>{}" "?S<>{}" using arytm_2_lm_10 by mty auto
  show " \<exists>k : Nat. \<forall>n : Nat. k \<subseteq> n \<longrightarrow> |. ((?rs) (-) (?r (+) ?s)) . n .| <\<^sup>\<real> e"
    proof(rule bexI[of _ "succ N"],intro ballI impI)
        fix n assume [ty]: "n be Nat" and nm:" (succ N) \<subseteq> n "
        hence "N in n" using ordinal1_th_17 by mty auto
        then obtain k where [ty]:"k be Nat" and
      k: "k<>{} &  n = N +\<^sub>\<S>\<^sup>\<nat> k" using Add_8 by mty auto
    hence nk:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ N)"       
      using  newton_th_6a[of N k] Add_6[of N k] by mty auto
    hence nk1:" 2\<^sub>\<S> |^ n =  (2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ N)"       
      using int_1_def_5 by mty auto
    have D: "2\<^sub>\<S> |^ k<>{}" "2\<^sub>\<S> |^ n <>{}" "2\<^sub>\<S> |^ N <>{}" "2\<^sub>\<S> |^ nn <>{}" 
     using newton_th_7 by mty auto
    let ?NR="(2\<^sub>\<S> |^ N) *\<^sub>D ?R"
    let ?NS="(2\<^sub>\<S> |^ N) *\<^sub>D ?S"
    let ?nR="(2\<^sub>\<S> |^ n) *\<^sub>D ?R"
    let ?nS="(2\<^sub>\<S> |^ n) *\<^sub>D ?S"
    have DD1: "?NR <>{}" "?NS <>{}" "?nR<>{}" "?nS<>{}" 
      using arytm_th_1 D DD by mty auto
    have DD2: "( 2\<^sub>\<S> |^ n) *\<^sub>D ?R = (2\<^sub>\<S> |^ k)  *\<^sub>D (?NR)"
              "( 2\<^sub>\<S> |^ n) *\<^sub>D ?S = (2\<^sub>\<S> |^ k)  *\<^sub>D (?NS)"
      using arytm_def_1M[of _ "2\<^sub>\<S> |^ N" "2\<^sub>\<S> |^ k"] 
         D DD nk  by mty auto
    let ?p="predecessor (2\<^sub>\<S> |^ k)"
    have pp: "succ ?p = (2\<^sub>\<S> |^ k)" using predec D by mty auto
    have "{} in k" using k one1 one2 by mty auto
    hence "2\<^sub>\<S> |^ {} in 2\<^sub>\<S> |^ k" using newton_th_8 xboole_0_def_10[of "2\<^sub>\<S>" "2\<^sub>\<S>"] all_set by mty auto
    hence "succ {} in 2\<^sub>\<S> |^ k" using newton_th_4 by mty auto
    hence "succ {} \<subseteq> ?p"  using ordinal1_th_18[of "?p"] pp by mty auto
    hence "{} in ?p" using ordinal1_th_17 by mty auto
    hence  sp: "?p <>{}" using xb by auto
    hence M: "max\<^sub>\<nat> ((2\<^sub>\<S> |^ k) *\<^sub>D (?NR +D ?NS)) \<subseteq> 
    ((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) +\<^sub>\<S>\<^sup>\<nat> ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p)"
      using arytm_th_8[of ?p ?NS ?NR] DD1 pp by mty auto
    have "(DEDEKIND_CUT (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = DEDEKIND_CUT(GLUED((DEDEKIND_CUT r) +D (DEDEKIND_CUT s)))" using r 
      arytm_2_def_8[of r s] by mty auto
    hence DRS: "(DEDEKIND_CUT (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) =?R +D ?S"
      using arytm_2_lm_12 by mty auto
    hence "( 2\<^sub>\<S> |^ N) *\<^sub>D (DEDEKIND_CUT (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = (?NR +D  ?NS)"
      using arytm_def_1A D by mty auto
    hence "( 2\<^sub>\<S> |^ n) *\<^sub>D (DEDEKIND_CUT (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = ( 2\<^sub>\<S> |^ k) *\<^sub>D (?NR +D  ?NS)"
      using arytm_def_1M[of "DEDEKIND_CUT (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)" "2\<^sub>\<S> |^ N" "2\<^sub>\<S> |^ k"] D nk by mty auto
    hence "((?rs) .n) = ((max\<^sub>\<nat> ( ( 2\<^sub>\<S> |^ k) *\<^sub>D (?NR +D  ?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))" 
      using Rat2C[of "r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" n,simplified] by mty auto
    hence T1:"((?rs) .n) \<le>\<^sup>\<real> (((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) +\<^sub>\<S>\<^sup>\<nat> ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p))
           /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using rat_1_th_23[OF _ _ _ D(2) M ] by mty auto 
    have P1: "?r . n = (max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)  *\<^sub>D (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
         "?s . n = (max\<^sub>\<nat> (( 2\<^sub>\<S> |^ k) *\<^sub>D ?NS)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
      using Rat2C[of _ n] rat_1_div DD2 by mty auto 
     have P2: "((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) \<subseteq> (max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)  *\<^sub>D (?NR)))"
             "((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) \<subseteq> (max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)  *\<^sub>D (?NS)))"
      using arytm_th_4 DD1 D by mty auto
     have P3: "(?r (+) ?s) . n= (?r. n )+\<^sub>\<S>\<^sup>\<real>  (?s.n)" using seq_A[of ?r ?s] by mty auto
    have " (((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))  \<le>\<^sup>\<real>
        ((max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)  *\<^sub>D (?NR)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))" 
         " (((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))  \<le>\<^sup>\<real> 
        ((max\<^sub>\<nat> ((2\<^sub>\<S> |^ k)  *\<^sub>D (?NS)))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))"
      using rat_1_th_23[OF _ _ _ D(2) P2(1)] rat_1_th_23[OF _ _ _ D(2) P2(2)]
              by mty auto
     hence "(((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))  \<le>\<^sup>\<real> ?r.n"
                  "(((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))  \<le>\<^sup>\<real> ?s.n"
      using P1 by mty auto
    hence "(((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)) +\<^sub>\<S>\<^sup>\<real> 
        (((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)) \<le>\<^sup>\<real> ((?r (+) ?s) . n)"
      using rat_1_th_16 P3 by mty auto    
    hence P4:  
"(((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR)))+\<^sub>\<S>\<^sup>\<real> (((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))))  /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))
   \<le>\<^sup>\<real> ((?r (+) ?s) . n)"
      using D rat_1_th_47[of "(2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))"
           "(2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))" "2\<^sub>\<S> |^ n" ] by mty auto  
    have "(((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR)))+\<^sub>\<S>\<^sup>\<real> (((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))))) = 
         (((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR)))+\<^sub>\<S>\<^sup>\<nat>(((2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS)))))"
    using int_1_def_3[of "(2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NR))" "(2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  (max\<^sub>\<nat> (?NS))"]  by mty auto
  also have "... = (2\<^sub>\<S> |^ k)   *\<^sub>\<S>\<^sup>\<nat>  ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))" using Mult_11 by mty auto
  finally have T2: "(((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))
     \<le>\<^sup>\<real> ((?r (+) ?s) . n)" using P4 by mty auto
  have T3: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) \<le>\<^sup>\<real> 
      ((((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) +\<^sub>\<S>\<^sup>\<nat> ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))
     -\<^sub>\<S>\<^sup>\<real>  (((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))"
    using rat_1_th_17[OF _ _ _ _ T1 T2] by mty auto
  have "
((((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) +\<^sub>\<S>\<^sup>\<nat> ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p)) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))
     -\<^sub>\<S>\<^sup>\<real>  (((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))
=
((((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) +\<^sub>\<S>\<^sup>\<nat> ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p))
+\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real> ((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using rat_1_th_47m D(2) by mty auto
  also have "... =((((2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))) +\<^sub>\<S>\<^sup>\<real>  ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p))
+\<^sub>\<S>\<^sup>\<real>  (-\<^sub>\<S>\<^sup>\<real> ((2\<^sub>\<S> |^ k)  *\<^sub>\<S>\<^sup>\<nat> ( (max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using int_1_def_3[of _  "(2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p"]by mty auto
  also have "... = ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" 
    using int_1_th_22[of "(2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p" "(2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> ((max\<^sub>\<nat> ?NR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?NS))"] 
    by mty auto
  finally have T4: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) \<le>\<^sup>\<real> ( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using T3 by mty auto
  have "(2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ k) = (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (succ {} +\<^sub>\<S>\<^sup>\<nat> succ {})  " using Mult_5[of "2\<^sub>\<S> |^ k"]
     Mult_11[of "succ {}" "succ{}" "2\<^sub>\<S> |^ k"] by mty auto
  hence TD: "(2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ k) = (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> )  " using Add_5 by mty auto 
  have "?p \<subseteq> 2\<^sub>\<S> |^ k" using pp ordinal1_th_2a[of ?p] by mty auto
  hence "(2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p \<subseteq> (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> )" using Add_13[of "2\<^sub>\<S> |^ k"] TD by mty auto
  hence "( (2\<^sub>\<S> |^ k) +\<^sub>\<S>\<^sup>\<nat> ?p) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) \<le>\<^sup>\<real> ( (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> )) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using rat_1_th_23 D by mty auto
  hence   "((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) \<le>\<^sup>\<real> ( (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> )) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using rat_0_def_8t[OF _ _ _ T4] by mty auto
  hence T5:  "((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) \<le>\<^sup>\<real> ( (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> )) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using int_1_def_5[of "2\<^sub>\<S> |^ k" " 2\<^sub>\<S> "] by mty auto
  have "( (2\<^sub>\<S> |^ k) *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> )) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = 
    ( (2\<^sub>\<S> |^ k) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ k))*\<^sub>\<S>\<^sup>\<real>   ( (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" 
    using nk rat_1_th_14 D nk1 by mty auto
  also have "... = ( (2\<^sub>\<S> |^ k) /\<^bsub>\<rat>\<ge>0\<^bsup> ( 2\<^sub>\<S> |^ k))*\<^sub>\<S>\<^sup>\<real>   ( (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" using rat_1_div by mty auto
  also have "... = ( succ {})*\<^sub>\<S>\<^sup>\<real>   ( (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" using arytm_3_th_41 D by mty auto
  also have "... =  ( (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^sup>\<real>  ( succ {})" using real_0_th_21 by mty auto
  also have "... =  ( (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( succ {})" using real_0_def_7 Prat_Preal_mult by mty auto
  finally have T6: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) 
     \<le>\<^sup>\<real> ( (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N))" using arytm_3_th_53 T5 by mty auto
  have " (2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) = ( (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> (succ {})) /\<^sub>\<rat> ( 2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> (2\<^sub>\<S> |^ nn)))" 
    using newton_th_6[of nn "2\<^sub>\<S>"] NN Mult_5[of "2\<^sub>\<S>"] by mty auto 
  also have  "... = ( (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<real>  (succ {})) /\<^sub>\<rat> ( 2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<real>  (2\<^sub>\<S> |^ nn)))" 
       using int_1_def_5[of ] by mty auto
  also have  "... = ( ( (succ {}) *\<^sub>\<S>\<^sup>\<real>  2\<^sub>\<S>) /\<^sub>\<rat> ( (2\<^sub>\<S> |^ nn) *\<^sub>\<S>\<^sup>\<real>  2\<^sub>\<S>))" 
       using real_0_th_21[of "2\<^sub>\<S>"] by mty auto
  also have  "... = (  (succ {}) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ nn ))" 
       using rat_1_th_44[of "succ {}" "2\<^sub>\<S>" "2\<^sub>\<S> |^ nn"] D by mty auto
  finally have "(2\<^sub>\<S>) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ N) <\<^sup>\<real> e" using NQ by mty auto
  hence T7: "((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n)<\<^sup>\<real> e" using T6 rat_0_def_8t1[OF _ _ _ T6] by mty auto 
  have "(max\<^sub>\<nat> ?nR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nS) \<subseteq>  max\<^sub>\<nat> (?nR +D ?nS)"
    using arytm_th_7 DD1 by mty auto
  hence A1: "((max\<^sub>\<nat> ?nR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) \<le>\<^sup>\<real>  (max\<^sub>\<nat> (?nR +D ?nS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)"
    using rat_1_th_23 D by mty auto
   have "( 2\<^sub>\<S> |^ n) *\<^sub>D (DEDEKIND_CUT (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = (?nR +D  ?nS)"
      using arytm_def_1A D DRS  by mty auto
    hence A2: "((?rs) .n) = ((max\<^sub>\<nat> ( (?nR +D  ?nS))) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))" 
      using Rat2C[of "r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" n,simplified] by mty auto
  have "((max\<^sub>\<nat> ?nR) +\<^sub>\<S>\<^sup>\<nat> (max\<^sub>\<nat> ?nS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n) = 
      ((max\<^sub>\<nat> ?nR) +\<^sub>\<S>\<^sup>\<real>  (max\<^sub>\<nat> ?nS))/\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)" using int_1_def_3 by mty auto
  also have "... = ((max\<^sub>\<nat> ?nR) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n)) +\<^sub>\<S>\<^sup>\<real>  ((max\<^sub>\<nat> ?nS) /\<^sub>\<rat> ( 2\<^sub>\<S> |^ n))"
    using rat_1_th_47[OF _ _ _ D(2)] by mty auto
  also have "... = (?r. n) +\<^sub>\<S>\<^sup>\<real>  (?s. n)" using P1 DD2 by mty auto
  finally have A3: "(?r (+) ?s) . n \<le>\<^sup>\<real> ((?rs) .n)" using P3 A1 A2 by mty auto
  have A4: "(?r (+) ?s) . n \<le>\<^sup>\<real> (?r (+) ?s) . n" using P3 real_0_def_8r by mty auto
  have "((?r (+) ?s) . n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) ={}" using rat_1_th_18 by mty auto
  hence "{} \<le>\<^sup>\<real> ((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n)" 
    using rat_1_th_17[OF _ _ _ _ A3 A4] by mty auto
  hence "|. ((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n) .| =
     ((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n)" using absvalue_def_1 by mty auto
  hence "|. ((rC r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s ) (-) ((rC r ) (+) (rC s ))) . n .| =
     ((?rs) .n) -\<^sub>\<S>\<^sup>\<real> ((?r (+) ?s) . n)" using seq_m by mty auto
  thus  " |. ((rC r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s ) (-) ((rC r ) (+) (rC s ))) . n .| <\<^sup>\<real> e" using T7 by mty auto
qed mauto
qed mauto

text_raw {*\DefineSnippet{numbers}{*}
theorem numbers:
  "NAT \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" "RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> REAL\<^bsup>\<ge>0\<^bsub>" 
  "NAT \<subseteq> INT"  "RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> RAT" "REAL\<^bsup>\<ge>0\<^bsub> \<subseteq> REAL"
  "INT \<subseteq> RAT"  "RAT \<subseteq> REAL"
text_raw {*}%EndSnippet*}
proof-
  show "NAT \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" using nat_ratp by auto
  show "RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_1 by auto
  show "NAT \<subseteq> INT" 
  proof(intro impI ballI tarski_def_3I[OF all_set all_set])
    fix x assume "x in NAT"
    thus "x in INT" 
      unfolding numbers_def_4 using xboole_0_def_3 by mty auto
  qed mauto
  show "RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> RAT"
  proof(intro impI ballI tarski_def_3I[OF all_set all_set])
    fix x assume "x in RAT\<^bsup>\<ge>0\<^bsub>"
    thus "x in RAT" 
      unfolding numbers_def_3 using xboole_0_def_3 by mty auto
  qed mauto
  show "REAL\<^bsup>\<ge>0\<^bsub> \<subseteq> REAL"
  proof(intro impI ballI tarski_def_3I[OF all_set all_set])
    fix x assume "x in REAL\<^bsup>\<ge>0\<^bsub>"
    thus "x in REAL" 
      unfolding numbers_def_1 using xboole_0_def_3 by mty auto
  qed mauto
 show "INT \<subseteq> RAT" 
  proof(intro impI ballI tarski_def_3I[OF all_set all_set])
    fix x assume "x in INT"
    hence "x is integer" using int_1_def_2 by mty auto
    thus "x in RAT" using rat_0_def_3 cl_int_rat  by mty auto
  qed mauto
  show "RAT \<subseteq> REAL"
  proof(intro impI ballI tarski_def_3I[OF all_set all_set])
    fix x assume "x in RAT"
    hence [ty]:"x is Rat" using rat_0_def_3 by mty auto
    have "x is MReal" by mauto
    thus "x in REAL" using real_0_def_3 by auto 
  qed mauto
qed

end
