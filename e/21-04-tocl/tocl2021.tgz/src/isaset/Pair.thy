section \<open>Ordered pairs\<close>

text \<open>
Based heavily on code copied directly from the theory file ZF/pair.thy
of the Isabelle/ZF object logic.

Modified 2019 Alexander Krauss (QAware GmbH) and Joshua Chen (University of Innsbruck).

Original ZF/Pair.thy by Lawrence C Paulson, Cambridge University Computer Laboratory,
Copyright 1992 University of Cambridge.
\<close>

theory Pair
imports Ordinal

begin

definition Pair :: "set \<Rightarrow> set \<Rightarrow> set" ("\<langle>_ , _ \<rangle>")
  where "\<langle> a , b \<rangle> \<equiv> {{a, a}, {a, b}}"

lemma Pair_eq_iff: "\<langle>a, b\<rangle> = \<langle>c, d\<rangle> \<longleftrightarrow> a = c \<and> b = d"
  by (simp add: Pair_def doubleton_eq_iff) blast

definition DUnion :: "set \<Rightarrow> (set \<Rightarrow> set) \<Rightarrow> set"
  where "DUnion A B \<equiv> \<Union>x \<in> A. \<Union>y \<in> B x. {\<langle>x,y\<rangle>}"

syntax
  "_Disj_UNION" :: "[pttrn, set, set \<Rightarrow> set] \<Rightarrow> set" ("\<Coprod>_ \<in> _./ _" [0, 0, 100])
translations
  "\<Coprod>x \<in> A. B" \<rightleftharpoons> "CONST DUnion A (\<lambda>x. B)"

lemma DUnion_iff: "\<langle>a, b\<rangle> \<in> \<Coprod>x \<in> A. (B x) \<longleftrightarrow> a \<in> A \<and> b \<in> B a"
  by (auto simp: DUnion_def Pair_eq_iff)

end
