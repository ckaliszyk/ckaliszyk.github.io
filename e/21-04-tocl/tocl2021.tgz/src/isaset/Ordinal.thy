theory Ordinal
imports Set_Theory
begin

definition Ord :: "set type" where
  Ord_typedef: "Ord \<equiv> Type (\<lambda>x. Trans x \<and> (\<forall>y \<in> x. Trans y))"

lemma empty_ordinal [intro!]: "{} : Ord"
  unfolding Ord_typedef Trans_def by squash_types auto

lemma Ord_transitive [elim]: "\<lbrakk>y \<in> x; x : Ord\<rbrakk> \<Longrightarrow> y : Ord"
  unfolding Ord_typedef Trans_def by squash_types blast

lemma Ord_elem_subset: "\<lbrakk>x : Ord; y \<in> x\<rbrakk> \<Longrightarrow> y \<subseteq> x"
  unfolding Ord_typedef Trans_def by squash_types

end
