section \<open>Axioms of HOTG\<close>

theory Grothendieck_Axioms
imports "Soft_Types/More_HOL"

begin

text \<open>
Axiomatic basis of higher-order Tarski-Grothendieck set theory embedded in HOL.

We axiomatize a rigid type \<open>set\<close>, with the standard set-theoretic operations and axioms.
\<close>

typedecl set

axiomatization
  elem :: "set \<Rightarrow> set \<Rightarrow> bool" (infixl "\<in>" 50) and
  empty_set :: set ("{}") and
  Pow :: "set \<Rightarrow> set" and
  Union :: "set \<Rightarrow> set" ("\<Union>_" [90] 90) and
  Repl :: "set \<Rightarrow> (set \<Rightarrow> set) \<Rightarrow> set"
where
  inInduction: "(\<forall>X. (\<forall>x. x \<in> X \<longrightarrow> P x) \<longrightarrow> P X) \<longrightarrow> (\<forall>X. P X)"
and
  Empty: "\<not>(\<exists>x. x \<in> {})"
and
  Union: "\<forall>X x. x \<in> \<Union>X \<longleftrightarrow> (\<exists>Y. Y \<in> X \<and> x \<in> Y)"
and
  Replacement: "\<forall>X y. y \<in> Repl X F \<longleftrightarrow> (\<exists>x. x \<in> X \<and> y = F x)"

text \<open>
Axioms @{thm inInduction} and @{thm Replacement} are axiom schemas in first-order logic.
\<close>


text \<open>The following axioms need a definition first:\<close>

definition subset :: "set \<Rightarrow> set \<Rightarrow> bool" (infixl "\<subseteq>" 50)
  where "A \<subseteq> B \<equiv> (\<forall>x. x \<in> A \<longrightarrow> x \<in> B)"

hide_const (open) subset (* Will usually be referred to via infix *)

axiomatization where
  Extensionality: "\<forall>X Y. X \<subseteq> Y \<longrightarrow> Y \<subseteq> X \<longrightarrow> X = Y"
and
  Power: "\<forall>A x. x \<in> Pow A \<longleftrightarrow> x \<subseteq> A"


text \<open>
Finally, we axiomatize the constant \<open>Univ\<close>, which, given a set, returns a Grothendieck universe
containing the set.

This is the Tarski axiom.
\<close>

definition Trans :: "set \<Rightarrow> bool"
  where "Trans X \<equiv> (\<forall>x. x \<in> X \<longrightarrow> x \<subseteq> X)"

definition ZFclosed :: "set \<Rightarrow> bool"
  where "ZFclosed U \<equiv> (
      (\<forall>X. X \<in> U \<longrightarrow> \<Union>X \<in> U) \<and>
      (\<forall>X. X \<in> U \<longrightarrow> Pow X \<in> U) \<and>
      (\<forall>X F. X \<in> U \<longrightarrow> (\<forall>x. x \<in> X \<longrightarrow> F x \<in> U) \<longrightarrow> Repl X F \<in> U)
    )"

text \<open>Remark: @{const ZFclosed} is a second-order statement.\<close>

text_raw {*\DefineSnippet{GUniv}{*}
axiomatization
  Univ :: "set \<Rightarrow> set" where
  UnivIn: "N \<in> Univ N" and
  UnivTransSet: "Trans (Univ N)" and
  UnivZF: "ZFclosed (Univ N)" and
  UnivMin: "N \<in> U \<and> Trans U \<and> ZFclosed U \<Longrightarrow> Univ N \<subseteq> U"
text_raw {*}%EndSnippet*}



end
