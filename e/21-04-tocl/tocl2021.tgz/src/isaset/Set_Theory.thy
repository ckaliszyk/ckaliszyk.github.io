section \<open>Higher-order Tarski-Grothendieck set theory\<close>

theory Set_Theory
imports Grothendieck_Axioms

begin

subsection \<open>Preliminaries\<close>

declare [[eta_contract=false]]

abbreviation not_elem (infixl "\<notin>" 50)
  where "x \<notin> y \<equiv> \<not> x \<in> y"


subsection \<open>Foundational axioms as rules\<close>

lemma empty_rule [simp]: "x \<notin> {}" using Empty by blast

lemmas
  extensionality = Extensionality[rule_format] and
  elem_induct_rule = inInduction[rule_format] and
  Union_rule [iff] = Union[rule_format] and
  Pow_rule [iff] = Power[rule_format] and
  Replacement_rule [iff] = Replacement[rule_format]


subsection \<open>Bounded Quantifiers\<close>

definition Ball :: "set \<Rightarrow> (set \<Rightarrow> bool) \<Rightarrow> bool"
  where "Ball A P \<equiv> (\<forall>x. x \<in> A \<longrightarrow> P x)"

definition Bex :: "set \<Rightarrow> (set \<Rightarrow> bool) \<Rightarrow> bool"
  where "Bex A P \<equiv> \<exists>x. x \<in> A \<and> P x"

definition Bex1 :: "set \<Rightarrow> (set \<Rightarrow> bool) \<Rightarrow> bool"
  where "Bex1 A P \<equiv> \<exists>!x. x \<in> A \<and> P x"

syntax
  "_Ball" :: "[pttrn, set, bool] \<Rightarrow> bool"  ("(3\<forall>_ \<in> _./ _)" 10)
  "_Bex"  :: "[pttrn, set, bool] \<Rightarrow> bool"  ("(3\<exists>_ \<in> _./ _)" 10)
translations
  "\<forall>x \<in> A. P" \<rightleftharpoons> "CONST Ball A (\<lambda>x. P)"
  "\<exists>x \<in> A. P" \<rightleftharpoons> "CONST Bex A (\<lambda>x. P)"

lemma BallI [intro!]: "\<lbrakk>\<And>x. x \<in> A \<Longrightarrow> P x\<rbrakk> \<Longrightarrow> \<forall>x \<in> A. P x"
  by (simp add: Ball_def)

lemma Bspec [dest?]: "\<lbrakk>\<forall>x \<in> A. P x; x \<in> A\<rbrakk> \<Longrightarrow> P x"
  by (simp add: Ball_def)

lemma rev_BallE [elim]: "\<lbrakk>\<forall>x \<in> A. P x; x \<notin> A \<Longrightarrow> Q; P x \<Longrightarrow> Q\<rbrakk> \<Longrightarrow> Q"
  by (simp add: Ball_def, blast)

lemma BexI [intro]: "\<lbrakk>P x; x \<in> A\<rbrakk> \<Longrightarrow> \<exists>x \<in> A. P x"
  by (simp add: Bex_def, blast)

lemma BexE [elim!]: "\<lbrakk>\<exists>x \<in> A. P x; \<And>x. \<lbrakk>x \<in> A; P x\<rbrakk> \<Longrightarrow> Q\<rbrakk> \<Longrightarrow> Q"
  by (simp add: Bex_def, blast)





subsection \<open>Subsets\<close>

lemma subsetI [intro!]: "(\<And>x. x \<in> A \<Longrightarrow> x \<in> B) \<Longrightarrow> A \<subseteq> B"
  by (simp add: subset_def)

lemma subsetE [elim]: "\<lbrakk>A \<subseteq> B; c \<notin> A \<Longrightarrow> P; c \<in> B \<Longrightarrow> P\<rbrakk> \<Longrightarrow> P"
  by (simp add: subset_def, blast)

subsection \<open>Equality\<close>

lemma equality_iffI: "(\<And>x. x \<in> A \<longleftrightarrow> x \<in> B) \<Longrightarrow> A = B"
  by (rule extensionality) auto

lemma equality_iffD: "A = B \<Longrightarrow> (\<And>x. x \<in> A \<longleftrightarrow> x \<in> B)"
  by auto

method extensionality = (
    (rule extensionality)?,
    auto intro: equality_iffI dest: equality_iffD
  ) \<comment>\<open>Frequently used\<close>


subsection \<open>Replacement\<close>

syntax
  "_Replace"  :: "[set, pttrn, set] => set" ("(1{_ |/ _ \<in> _})")
  "_Replace'"  :: "[set, pttrn, set] => set" ("(1{_ ./ _ \<in> _})")
translations
  "{y | x \<in> A}" \<rightleftharpoons> "CONST Repl A (\<lambda>x. y)"
  "{y. x \<in> A}" \<rightharpoonup> "CONST Repl A (\<lambda>x. y)"

lemma Repl_cong [cong]:
  "\<lbrakk>A = B; \<And>x. x \<in> B \<Longrightarrow> f x = g x\<rbrakk> \<Longrightarrow> {f x. x \<in> A} = {g x. x \<in> B}"
  by extensionality

subsection \<open>Empty set\<close>

lemma equals_emptyI [intro]: "\<lbrakk>\<And>y. y \<in> A \<Longrightarrow> False\<rbrakk> \<Longrightarrow> A = {}"
  by extensionality

lemma equals_emptyD [dest]: "A = {} \<Longrightarrow> a \<notin> A"
  by auto

subsection \<open>Finite sets\<close>

text \<open>The unordered pair is defined using replacement. We then use it to define finite sets.\<close>

definition Upair :: "set \<Rightarrow> set \<Rightarrow> set"
  where "Upair a b = {if i = {} then a else b | i \<in> Pow (Pow {})}"

lemma Upair_elems [iff]: "x \<in> Upair a b \<longleftrightarrow> x = a \<or> x = b"
  by (auto simp: Upair_def)

definition Cons :: "set \<Rightarrow> set \<Rightarrow> set"
  where "Cons x A = \<Union>(Upair A (Upair x x))"

lemma Cons_elems [iff]: "y \<in> Cons x A \<longleftrightarrow> y = x \<or> y \<in> A"
  by (auto simp: Cons_def)

syntax
  "_Finset_Set" :: "args \<Rightarrow> set" ("{(_)}")
translations
  "{x, xs}" \<rightleftharpoons> "CONST Cons x {xs}"
  "{x}" \<rightleftharpoons> "CONST Cons x {}"

lemma singleton_eq_iff [iff]: "{a} = {b} \<longleftrightarrow> a = b"
  by extensionality

lemma doubleton_eq_iff: "{a, b} = {c, d} \<longleftrightarrow> (a = c \<and> b = d) \<or> (a = d \<and> b = c)"
  by extensionality

(* Use the following to transfer results about two-element finite sets over to Upairs,
so that there's no difference to the user. *)
lemma Upair_eq_Cons [simp]: "Upair a b = {a, b}"
  by extensionality

subsection \<open>Set comprehension\<close>

text \<open>This is also known as separation.\<close>

definition Collect :: "set \<Rightarrow> (set \<Rightarrow> bool) \<Rightarrow> set"
  where "Collect A P \<equiv> \<Union>{if P x then {x} else {} | x \<in> A}"

syntax
  "_Set_Collect" :: "pttrn \<Rightarrow> set \<Rightarrow> (set \<Rightarrow> bool) \<Rightarrow> set"  ("(1{_ \<in> _ |/ _})")
  "_Set_Collect'" :: "pttrn \<Rightarrow> set \<Rightarrow> (set \<Rightarrow> bool) \<Rightarrow> set"  ("(1{_ \<in> _ ./ _})")
translations
  "{x \<in> A | P}" \<rightleftharpoons> "CONST Collect A (\<lambda>x. P)"
  "{x \<in> A . P}" \<rightharpoonup> "CONST Collect A (\<lambda>x. P)"

lemma Collect_iff [iff]: "x \<in> {y \<in> A. P y} \<longleftrightarrow> x \<in> A \<and> P x"
  by (auto simp: Collect_def)


text \<open>Replacement in predicate form, as in ZF.\<close>

definition Replace :: "set \<Rightarrow> (set \<Rightarrow> set \<Rightarrow> bool) \<Rightarrow> set"
  where "Replace A P = {THE y. P x y | x \<in> {x \<in> A | \<exists>!y. P x y}}"

syntax
  "_GenRepl"  :: "[pttrn, pttrn, set, bool] => set"  ("(1{_ |/ _ \<in> _, _})")
  "_GenRepl'"  :: "[pttrn, pttrn, set, bool] => set"  ("(1{_ ./ _ \<in> _, _})")
translations
  "{y | x \<in> A, Q}" \<rightleftharpoons> "CONST Replace A (\<lambda>x y. Q)"
  "{y . x \<in> A, Q}" \<rightharpoonup> "CONST Replace A (\<lambda>x y. Q)"

subsection \<open>Union and intersection\<close>

definition Inter :: "set => set"  ("\<Inter>_" [90] 90)
  where "\<Inter>A \<equiv> {x \<in> \<Union>A . \<forall>y \<in> A. x \<in> y}"



syntax
  "_UNION" :: "[pttrn, set, set] => set"  ("(3\<Union>_ \<in> _./ _)" [0, 0, 10]10)
  "_INTER" :: "[pttrn, set, set] => set"  ("(3\<Inter>_ \<in> _./ _)" [0, 0, 10]10)
translations
  \<comment>\<open>@{term "\<Union>x \<in> A. (B x)"} abbreviates @{term "\<Union>({B x. x \<in> A})"}\<close>
  "\<Union>x \<in> A. B" \<rightleftharpoons> "CONST Union {B. x \<in> A}"
  "\<Inter>x \<in> A. B" \<rightleftharpoons> "CONST Inter {B. x \<in> A}"


lemma UN_iff [iff]: "b \<in> (\<Union>x \<in> A. (B x)) \<longleftrightarrow> (\<exists>x \<in> A. b \<in> B x)"
  by (simp add: Bex_def, blast)

text \<open>LCP: The order of the premises presupposes that A is rigid; b may be flexible\<close>

lemma UN_I: "a \<in> A \<Longrightarrow>  b \<in> B a \<Longrightarrow> b \<in> (\<Union>x \<in> A. B x)"
  by (simp, blast)

lemma UN_E [elim!]: "\<lbrakk>b \<in> (\<Union>x \<in> A. B x); \<And>x. \<lbrakk>x \<in> A; b \<in> B x\<rbrakk> \<Longrightarrow> R\<rbrakk> \<Longrightarrow> R"
  by blast

lemma Inter_iff [iff]: "A \<in> \<Inter>C \<longleftrightarrow> (\<forall>x \<in> C. A \<in> x) \<and> C \<noteq> {}"
  unfolding Inter_def Ball_def
  by auto

subsection \<open>Binary union and intersection\<close>

definition Un :: "[set, set] \<Rightarrow> set" (infixl "\<union>" 70)
  where "A \<union> B = \<Union>{A, B}"

definition Int :: "[set, set] \<Rightarrow> set" (infixl "\<inter>" 70)
  where "A \<inter> B \<equiv> \<Inter>{A, B}"

lemma Un_iff [simp]: "x \<in> A \<union> B \<longleftrightarrow> x \<in> A \<or> x \<in> B"
  unfolding Un_def by auto

lemma Int_iff [simp]: "x \<in> A \<inter> B \<longleftrightarrow> x \<in> A \<and> x \<in> B"
  unfolding Int_def by auto

lemma UnE [elim!]: "\<lbrakk>c \<in> A \<union> B; c \<in> A \<Longrightarrow> P; c \<in> B \<Longrightarrow> P\<rbrakk> \<Longrightarrow> P"
  by auto

lemma UnCI [intro!]: "(c \<notin> B \<Longrightarrow> c \<in> A) \<Longrightarrow> c \<in> A \<union> B"
  by auto

lemma IntI [intro!]: "\<lbrakk>c \<in> A; c \<in> B\<rbrakk> \<Longrightarrow> c \<in> A \<inter> B"
  by simp

lemma IntE [elim!]: "\<lbrakk>c \<in> A \<inter> B; \<lbrakk>c \<in> A; c \<in> B\<rbrakk> \<Longrightarrow> P\<rbrakk> \<Longrightarrow> P"
  by simp


subsection \<open>Set Difference\<close>

definition Diff :: "[set, set] \<Rightarrow> set"  (infixl "\<setminus>" 65)
  where "A \<setminus> B \<equiv> {x \<in> A | x \<notin> B}"

lemma Diff_iff [simp]: "c \<in> A \<setminus> B \<longleftrightarrow> (c \<in> A \<and> c \<notin> B)"
  by (unfold Diff_def, auto)

subsection \<open>\<in>-induction\<close>

lemma foundation: "X = {} \<or> (\<exists>Y \<in> X. \<forall>y \<in> Y. y \<notin> X)"
  using inInduction[of "\<lambda>x. x \<notin> X"] by blast

lemma elem_asymE: "\<lbrakk>a \<in> b; \<not>P \<Longrightarrow> b \<in> a\<rbrakk> \<Longrightarrow> P"
proof-
  assume AS: "a \<in> b " " \<not> P \<Longrightarrow> b \<in> a"
  obtain Y where 
     Y:"Y \<in> {a, b} \<and>  (\<forall>y \<in> Y. y \<notin> {a, b})" using  foundation[of "{a,b}"] by auto
  hence "Y=a" using AS by auto
  thus P using AS Y by auto
qed

lemma elem_double_induct:
  fixes X Y :: set
  assumes IH: "\<And>X Y. 
          (\<And>x Y. x \<in> X \<Longrightarrow> P x Y) \<Longrightarrow>
          (\<And>y. y \<in> Y \<Longrightarrow> P X y)
          \<Longrightarrow> P X Y"
  shows "P X Y"
proof (induction X arbitrary: Y rule: elem_induct_rule)
  fix X Y assume 1: "\<And>x Y. x \<in> X \<Longrightarrow> P x Y"
  show "P X Y"
  proof (induction Y rule: elem_induct_rule)
    fix Y assume "\<And>y. y \<in> Y \<Longrightarrow> P X y"
    with 1 show "P X Y" by (rule IH)
  qed
qed

end
