(*
Title:   Function.thy
Authors: Alexander Krauss and Joshua Chen
Date:    Jun 2019

Based on earlier work in Isabelle/ZF by Larry Paulson.
*)

section \<open>Functions, lambda abstraction, and dependent function spaces\<close>

theory Function
imports Pair

begin

definition Pi :: "[set, set \<Rightarrow> set] \<Rightarrow> set"
  where "Pi A B \<equiv> {f \<in> Pow (\<Coprod>x \<in> A. (B x)) | \<forall>x \<in> A. \<exists>!y. \<langle>x, y\<rangle> \<in> f}"

syntax "_PROD" :: "[pttrn, set, set] => set type" ("(3\<Prod>_ \<in> _./ _)" [0, 0, 100])
translations "\<Prod>x \<in> A. B" \<rightleftharpoons> "CONST Pi A (\<lambda>x. B)"

abbreviation "functions" :: "[set, set] \<Rightarrow> set" (infixr "\<rightarrow>" 60)
  where "A \<rightarrow> B \<equiv> \<Prod>x \<in> A. B"

definition lambda :: "set \<Rightarrow> (set \<Rightarrow> set) \<Rightarrow> set"
  where "lambda A b \<equiv> {\<langle>x, b x\<rangle> | x \<in> A}"

syntax "_lam" :: "[pttrn, set, set] => set" ("(3\<lambda>_ \<in> _./ _)" 200)
translations "\<lambda>x \<in> A. f" \<rightleftharpoons> "CONST lambda A (\<lambda>x. f)"

definition "apply" :: "set \<Rightarrow> set \<Rightarrow> set" (infixl "`" 90)
  where "f`x = (THE y. \<langle>x, y\<rangle> \<in> f)"

end
