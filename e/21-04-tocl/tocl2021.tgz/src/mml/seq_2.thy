theory seq_2
  imports real_0 absvalue
begin

abbreviation seq_1_mode_1   ("Real'_Sequence")
where "Real_Sequence \<equiv> Function-of NAT,REAL"

theorem seq_1:
  "f is Real_Sequence iff f is Function & dom f = NAT & rng f \<subseteq> REAL"
proof
  have "{} in REAL" using real_0_def_3[of "{}"] by mty auto
  hence R: "REAL<>{}" using xb by mty auto
  assume A[ty]:"f be Real_Sequence "
  hence f1:"f is Function" by mty auto
  have f2: "dom f=NAT" using funct_2_def_1[of omega REAL f] R by mty auto
  have "rng f \<subseteq> REAL" using relat_1_def_19[of REAL f,simplified] all_set by mty auto
  thus "f is Function & dom f = NAT & rng f \<subseteq> REAL" using f1 f2 by simp
next
  show " f be Function \<and> proj1 f =\<^sub>\<S> omega \<and> proj2 f \<subseteq> REAL \<Longrightarrow> f be Function-of omega, REAL"
    using funct_2_th_3[of REAL f] by mty auto
qed

mtheorem
  mlet "f be Real_Sequence", "n be object"
  "cluster f. n \<rightarrow> Mreal"
proof(standard, cases "n in NAT")
  case T:True
    have "{} in REAL" using real_0_def_3[of "{}"] by mty auto
    hence R: "REAL<>{}"  using xb ordinal1_def_12[of n] by mty auto
    hence "f. n in REAL" using funct_2_th_5[of n REAL omega,of f] T by mty auto
    thus "f. n is Mreal" using real_0_def_3 by mty auto
next
  case F:False
    have "dom f =NAT" using seq_1[of f] by mty auto
    hence "f . n = {}" "{} is Mreal" using F funct_1_def_2[of f n] F by mty auto
    thus "f. n is Mreal"by simp    
qed

mdef seq_2_def_6("convergent") where 
  "attr convergent for Real_Sequence means 
       (\<lambda>seq. ex g be MReal st for p be MReal st 
        {} <\<^sup>\<real> p ex n be Nat st for m be Nat st n \<subseteq> m holds |. (seq. m) -\<^sub>\<S>\<^sup>\<real> g .| <\<^sup>\<real> p)" ..

mdef seq_2_def_7 ("lim _" [90] 90) where
 mlet "seq be Real_Sequence"
  "assume seq is convergent func lim seq \<rightarrow> MReal means
     (\<lambda>it. for p be MReal st 
        {} <\<^sup>\<real> p ex n be Nat st for m be Nat st n \<subseteq> m holds |. (seq. m) -\<^sub>\<S>\<^sup>\<real> it .| <\<^sup>\<real> p)"
proof-
  assume "seq be convergent"
  thus "\<exists>x : MReal. \<forall>p : MReal. {} <\<^sup>\<real> p \<longrightarrow> (\<exists>n : Nat. \<forall>m : Nat. n \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> p)" 
  using seq_2_def_6 by mty auto
  fix x y assume [ty]:"seq be convergent"
           "x be MReal"
           "y be MReal" and  
           A1:"\<forall>p : MReal. {} <\<^sup>\<real> p \<longrightarrow> (\<exists>n : Nat. \<forall>m : Nat. n \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> p)" and
           A2:"\<forall>p : MReal. {} <\<^sup>\<real> p \<longrightarrow> (\<exists>n : Nat. \<forall>m : Nat. n \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> y .| <\<^sup>\<real> p)"
  show "x =y"
  proof(rule ccontr, cases " x <\<^sup>\<real> y")
    case T:True
      hence T1:"{} <\<^sup>\<real> (y -\<^sub>\<S>\<^sup>\<real> x)" using real_1_th_18[of x] 
        real_1_th_17l1[of x x x y] real_0_def_8r[of x] by mty auto
      then obtain s where [ty]:"s be MReal" and
         s: "{} <\<^sup>\<real> s & s +\<^sub>\<S>\<^sup>\<real> s = y -\<^sub>\<S>\<^sup>\<real> x" using real_1_th_23[of "y -\<^sub>\<S>\<^sup>\<real> x"] by mty auto
      obtain nx where [ty]:"nx is Nat" and
      nx:"\<forall>m : Nat. nx \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> s" using s A1[THEN bspec,of s] by mty auto
    obtain ny where [ty]:"ny is Nat" and
      ny:"\<forall>m : Nat. ny \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> y .| <\<^sup>\<real> s" using s A2[THEN bspec,of s] by mty auto
    let ?nm= "nx +\<^sub>\<S>\<^sup>\<nat> ny"
    have "?nm = ny +\<^sub>\<S>\<^sup>\<nat> nx" using Add_6 by mty auto
    hence "nx \<subseteq> ?nm" "ny \<subseteq> ?nm" using Add_10[of nx ny] Add_10[of ny nx]  by mty auto
    hence H1:"|. seq . ?nm -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> s" "|. seq . ?nm -\<^sub>\<S>\<^sup>\<real> y .| <\<^sup>\<real> s" using nx ny by mty auto
    have "y -\<^sub>\<S>\<^sup>\<real> x = ((y -\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<S>\<^sup>\<real> seq . ?nm ) -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)" using  real_1_th_19 by mty auto
    also have "... = ((y +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x)) +\<^sub>\<S>\<^sup>\<real> seq . ?nm ) -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)" using real_0_def_6 by mty auto
    also have "... = (y +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x )) -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)" 
      using real_0_th_15[of "seq . ?nm" "-\<^sub>\<S>\<^sup>\<real> x" y ] real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real> x" "seq . ?nm"] 
        real_0_def_6[of "seq . ?nm" x]  by mty auto
    also have "... = (y +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x )) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (seq . ?nm))" 
      using real_0_def_6[of _ "seq . ?nm"] by mty auto
    also have "... = (-\<^sub>\<S>\<^sup>\<real> (seq . ?nm)) +\<^sub>\<S>\<^sup>\<real> (y +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x )) " 
      using real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real>(seq . ?nm)"  ] by mty auto
    also have "... = ((-\<^sub>\<S>\<^sup>\<real> (seq . ?nm)) +\<^sub>\<S>\<^sup>\<real> y) +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ) " 
      using real_0_th_15[of _ y "-\<^sub>\<S>\<^sup>\<real>(seq . ?nm)"  ] by mty auto
    also have "... = (y -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)) +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ) " 
      using real_0_th_11[of y "-\<^sub>\<S>\<^sup>\<real>(seq . ?nm)"  ] real_0_def_6[of y "seq . ?nm" ]by mty auto
    finally have "y -\<^sub>\<S>\<^sup>\<real> x = (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ) " 
      using real_1_th_22[of y "(seq . ?nm)"] by mty auto
    hence H2:"|. y -\<^sub>\<S>\<^sup>\<real> x .| \<le>\<^sup>\<real> |. (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) .| +\<^sub>\<S>\<^sup>\<real> |. ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ).|"
      using absvalue_th_6 by mty auto
    have H3: "|. y -\<^sub>\<S>\<^sup>\<real> x .| = y -\<^sub>\<S>\<^sup>\<real> x" 
      using T1 absvalue_def_1[of "y -\<^sub>\<S>\<^sup>\<real> x"] real_0_th_33[of "y -\<^sub>\<S>\<^sup>\<real> x"]  by mty auto
    have "|. (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) .| = |.   (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y .|" 
      using  absvalue_th_7 by mty auto
    hence "|. (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) .| +\<^sub>\<S>\<^sup>\<real> |. ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ).| <\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> s"
      using H1 real_1_th_16l by mty auto
    hence "|. y -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> s" using real_0_def_8t1[OF _ _ _ H2] by mty auto 
    thus False using H3 s real_0_def_8r by mty auto
  next 
    assume xy: "x \<noteq> y"
    case False
     hence "y <\<^sup>\<real> x" using real_0_th_33 xy by mty auto
     hence T1:"{} <\<^sup>\<real> (x -\<^sub>\<S>\<^sup>\<real> y)" using real_1_th_18[of y]     
          real_1_th_17l1[of y y y x] real_0_def_8r[of y] by mty auto
      then obtain s where [ty]:"s be MReal" and
         s: "{} <\<^sup>\<real> s & s +\<^sub>\<S>\<^sup>\<real> s = x -\<^sub>\<S>\<^sup>\<real> y" using real_1_th_23[of "x -\<^sub>\<S>\<^sup>\<real> y"] by mty auto
      obtain nx where [ty]:"nx is Nat" and
      nx:"\<forall>m : Nat. nx \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> s" using s A1[THEN bspec,of s] by mty auto
    obtain ny where [ty]:"ny is Nat" and
      ny:"\<forall>m : Nat. ny \<subseteq> m \<longrightarrow> |. seq . m -\<^sub>\<S>\<^sup>\<real> y .| <\<^sup>\<real> s" using s A2[THEN bspec,of s] by mty auto
    let ?nm= "nx +\<^sub>\<S>\<^sup>\<nat> ny"
    have "?nm = ny +\<^sub>\<S>\<^sup>\<nat> nx" using Add_6 by mty auto
    hence "nx \<subseteq> ?nm" "ny \<subseteq> ?nm" using Add_10[of nx ny] Add_10[of ny nx]  by mty auto
    hence H1:"|. seq . ?nm -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> s" "|. seq . ?nm -\<^sub>\<S>\<^sup>\<real> y .| <\<^sup>\<real> s" using nx ny by mty auto
    have "y -\<^sub>\<S>\<^sup>\<real> x = ((y -\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<S>\<^sup>\<real> seq . ?nm ) -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)" using  real_1_th_19 by mty auto
    also have "... = ((y +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x)) +\<^sub>\<S>\<^sup>\<real> seq . ?nm ) -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)" using real_0_def_6 by mty auto
    also have "... = (y +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x )) -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)" 
      using real_0_th_15[of "seq . ?nm" "-\<^sub>\<S>\<^sup>\<real> x" y ] real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real> x" "seq . ?nm"] 
        real_0_def_6[of "seq . ?nm" x]  by mty auto
    also have "... = (y +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x )) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (seq . ?nm))" 
      using real_0_def_6[of _ "seq . ?nm"] by mty auto
    also have "... = (-\<^sub>\<S>\<^sup>\<real> (seq . ?nm)) +\<^sub>\<S>\<^sup>\<real> (y +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x )) " 
      using real_0_th_11[of "-\<^sub>\<S>\<^sup>\<real>(seq . ?nm)"  ] by mty auto
    also have "... = ((-\<^sub>\<S>\<^sup>\<real> (seq . ?nm)) +\<^sub>\<S>\<^sup>\<real> y) +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ) " 
      using real_0_th_15[of _ y "-\<^sub>\<S>\<^sup>\<real>(seq . ?nm)"  ] by mty auto
    also have "... = (y -\<^sub>\<S>\<^sup>\<real> (seq . ?nm)) +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ) " 
      using real_0_th_11[of y "-\<^sub>\<S>\<^sup>\<real>(seq . ?nm)"  ] real_0_def_6[of y "seq . ?nm" ]by mty auto
    finally have "y -\<^sub>\<S>\<^sup>\<real> x = (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) +\<^sub>\<S>\<^sup>\<real> ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ) " 
      using real_1_th_22[of y "(seq . ?nm)"] by mty auto
    hence H2:"|. y -\<^sub>\<S>\<^sup>\<real> x .| \<le>\<^sup>\<real> |. (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) .| +\<^sub>\<S>\<^sup>\<real> |. ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ).|"
      using absvalue_th_6 by mty auto
 have H3: "|. y -\<^sub>\<S>\<^sup>\<real> x .| = |. x -\<^sub>\<S>\<^sup>\<real> y .|" using absvalue_th_7 real_1_th_22[of x y] by mty auto
  hence H3: "|. y -\<^sub>\<S>\<^sup>\<real> x .| = x -\<^sub>\<S>\<^sup>\<real> y" 
      using T1 absvalue_def_1[of "x -\<^sub>\<S>\<^sup>\<real> y"] real_0_th_33[of "x -\<^sub>\<S>\<^sup>\<real> y" "{}"]  by mty auto
    have "|. (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) .| = |.   (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y .|" 
      using  absvalue_th_7 by mty auto
    hence "|. (-\<^sub>\<S>\<^sup>\<real> ( (seq . ?nm)-\<^sub>\<S>\<^sup>\<real> y)) .| +\<^sub>\<S>\<^sup>\<real> |. ((seq . ?nm)-\<^sub>\<S>\<^sup>\<real> x ).| <\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> s"
      using H1 real_1_th_16l by mty auto
    hence "|. y -\<^sub>\<S>\<^sup>\<real> x .| <\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> s" using real_0_def_8t1[OF _ _ _ H2] by mty auto 
    thus False using H3 s real_0_def_8r by mty auto
  qed
qed mauto

reserve s1 for Real_Sequence
reserve f for "PartFunc-of REAL,REAL"
reserve x0,x1,r,s for MReal
reserve X for set
reserve x for object

mtheorem
  mlet "f be PartFunc-of REAL,REAL", "x be object"
  "cluster f .x \<rightarrow>MReal"
proof(standard, cases "x in dom f")
  case True
  hence "f .x in rng f" "rng f \<subseteq>REAL" using relat_1_def_19[of REAL f] 
    funct_1_def_3[of f "f. x"] bexI[of _ x] by mty auto
  hence "f. x in REAL" using tarski_def_3 by mty auto
  thus "f. x is MReal" using real_0_def_3 by mty auto
next
  case False
  hence "f. x ={}" "{} is MReal" using funct_1_def_2[of f x] by mty auto 
  thus "f. x is MReal" by auto
qed

mtheorem seq_ty:
  "rng s1 c= dom f \<Longrightarrow> (f \<circ> s1) is Real_Sequence"
proof-
  have R:"rng f \<subseteq> REAL" using relat_1_def_19[of REAL f] by mty auto
  assume "rng s1 c= dom f"
  hence "dom (f \<circ> s1) = dom s1" "rng (f \<circ> s1) \<subseteq> rng f" 
    using funct_2_lm_1[of s1 f] funct_2_lm_2[of s1 f] by mty auto
  hence "rng (f \<circ> s1) \<subseteq> REAL" "dom (f \<circ> s1) = NAT" 
    using R xboole_1_th_1[of REAL "rng f"]seq_1[of s1] by mty auto
  thus ?thesis using funct_2_th_3[of REAL "f \<circ> s1"] by mty auto
qed


text_raw {*\DefineSnippet{fcont_1_def_1}{*}
mdef fcont_1_def_1("_  is'_continuous'_in _" [90,90] 90) where
  mlet "f be PartFunc-of REAL,REAL" ,"x0 be MReal"
  "pred f is_continuous_in x0 means
    for s1 st rng s1 c= dom f & s1 is
      convergent & lim s1 = x0 holds (f \<circ> s1) is convergent & f . x0 = lim (f\<circ>s1)"..
text_raw {*}%EndSnippet*}
mtheorem fcont_1_th_3:
  "f is_continuous_in x0 iff 
       (for r st {} <\<^sup>\<real> r 
( ex s st {} <\<^sup>\<real> s & (for x1 st x1
  in dom f & |. x1 -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s holds |. f .x1 -\<^sub>\<S>\<^sup>\<real> f .x0 .| <\<^sup>\<real> r)))"
proof(rule iffI3)
  show  "f is_continuous_in x0 implies
       (for r st {} <\<^sup>\<real> r 
         ( ex s st {} <\<^sup>\<real> s & (for x1 st x1 in dom f & |. x1 -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s 
            holds |. f .x1 -\<^sub>\<S>\<^sup>\<real> f .x0 .| <\<^sup>\<real> r)))"
  proof(rule impI, rule ccontr)
    assume
A1: "f is_continuous_in x0" and
    "not (for r st {} <\<^sup>\<real> r 
         ( ex s st {} <\<^sup>\<real> s & (for x1 st x1 in dom f & |. x1 -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s 
            holds |. f .x1 -\<^sub>\<S>\<^sup>\<real> f .x0 .| <\<^sup>\<real> r)))" 
    then obtain r where [ty]:"r is MReal" and
A2: "{} <\<^sup>\<real> r" and
A3: "for s holds (not {}<\<^sup>\<real> s) or (ex x1 st x1 in dom f & |.x1 -\<^sub>\<S>\<^sup>\<real> x0.|<\<^sup>\<real> s & not
    |. f .x1 -\<^sub>\<S>\<^sup>\<real> f .x0.| <\<^sup>\<real> r)" by mty auto
    let ?P="\<lambda> x y. y in dom f & ( |. y -\<^sub>\<S>\<^sup>\<real> x0.| <\<^sup>\<real> (1\<^sub>\<S> /\<^sub>\<real> (x +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>))) & 
                   (not |.f .y -\<^sub>\<S>\<^sup>\<real> f . x0 .| <\<^sup>\<real> r)"
    have A4: "for n be Nat holds (ex p be Element-of REAL st ?P(n,p))"
    proof(rule ballI)
      fix n assume [ty]:"n be Nat"
      have "succ n <>{}" by auto
      hence N:"n +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> <>{}" using Add_5[of n] by mty auto
      hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (n +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)" using arytm_3_TH4 by mty auto 
      hence "{} <\<^sup>\<real> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> (n +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)" using real_0_th_29 arytm_2_lm_14 by mty auto
      hence "{} <\<^sup>\<real> 1\<^sub>\<S> /\<^sub>\<real> (n +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)" using real_1_div_6 N by mty auto
      
      then obtain p where [ty]:"p is MReal" and
A5:   "p in dom f & |. p -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> 1\<^sub>\<S>/\<^sub>\<real>(n+\<^sub>\<S>\<^sup>\<nat>1\<^sub>\<S>) & not |.f .p -\<^sub>\<S>\<^sup>\<real> f .x0.|<\<^sup>\<real>r" 
        using A3[THEN bspec, of "1\<^sub>\<S> /\<^sub>\<real> (n +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)"] by mty auto
      have "p is Element-of REAL" using real_0_def_3[of p] Element(6) by mty auto
      thus "ex p be Element-of REAL st ?P(n,p)" using bexI[of _ p] A5 by mty auto         
    qed mauto 
    let ?F ="\<lambda> n. the Element-of { p where p be Element-of REAL: ?P(n,p)}"
    have B0:"\<forall>x:Element-of NAT. ?F(x) in { p where p be Element-of REAL: ?P(x,p)}"
    proof(rule ballI)
      fix x assume [ty]:"x is Element-of NAT" 
      obtain p where [ty]:"p be Element-of REAL" and 
        p:"?P(x,p)"  using A4[THEN bspec, of x] by mty auto
      hence "p in { p where p be Element-of REAL: ?P(x,p)}" 
         using Fraenkel_A1_in[of "Element-of REAL" p _ "\<lambda>x. x"]  
         by mty auto
       hence "{ p where p be Element-of REAL: ?P(x,p)}<>{}" using xb1 by mty auto
       thus "?F(x) in { p where p be Element-of REAL: ?P(x,p)}" 
         using all_set Element_of_rule2 by mty auto
    qed mauto
    have B1:"\<forall>x:Element-of NAT. ?F(x) be Element-of REAL"
    proof
      fix x assume [ty]:"x be Element-of NAT"
      have H: "?F(x) in { p where p be Element-of REAL: ?P(x,p)}" using B0 by mty auto
      show "?F(x) be Element-of REAL" using Fraenkel_A1_ex[OF _ _ H] by mty auto         
    qed mauto
    obtain s1 where [ty]:"s1 be Function-of NAT, REAL" and 
        B2:"\<forall>x:Element-of NAT. (s1 . x) = ?F(x)" using funct_2_sch_4[OF _ _ B1] by mty auto
    have [ty]: "s1 is Function" and S:"dom s1=NAT" using seq_1[of s1] by mty auto 
    have A6: "for n be Nat holds ?P(n,s1 .n)"
    proof
      fix n assume [ty]:"n be Nat"
      have H: "?F(n) in { p where p be Element-of REAL: ?P(n,p)}" using B0[THEN bspec,of n] by mty auto
      have "?P(n,?F(n))" using Fraenkel_A1_ex[OF _ _ H] by mty auto  
      thus "?P(n,s1 .n)" using B2 by mty auto 
    qed mauto   
   have
A7: "rng s1 c= dom f"
    proof(rule tarski_def_3I,auto)
      fix y 
      assume "y in rng s1"
      then obtain x where
      x: "x in dom s1 & y = s1. x" using funct_1_def_3[of s1 y] by mty auto
      hence [ty]:"x is Element-of NAT" using S Element(6)[of NAT x] by mty auto
      have "?P(x,s1 .x)" using A6 by mty auto
      thus "y in dom f" using x by auto
    qed mauto
    hence [ty]:"(f \<circ> s1) is Real_Sequence" using seq_ty by mty auto
    have A8:"\<And> n. n be Nat \<Longrightarrow> not |.(f \<circ> s1).n -\<^sub>\<S>\<^sup>\<real> f .x0.|<\<^sup>\<real> r"
    proof-
      fix n assume [ty]:"n be Nat"
      hence "n in NAT" using ordinal1_def_12 by mty auto
      hence A9: "NAT <>{}" using xb by auto
      have "n is Element-of NAT" by mty auto
      have "not |.f.(s1 .n)-\<^sub>\<S>\<^sup>\<real>f .x0.|<\<^sup>\<real> r" using  A6 A9 by mty auto
      thus "not |.(f \<circ> s1).n -\<^sub>\<S>\<^sup>\<real> f .x0.|<\<^sup>\<real> r" 
         using A7 A9 funct_2_th_108[of REAL s1 NAT f REAL n] by mty auto
     qed
     have ONE: "{}<\<^sup>\<real> succ {}" "{}\<le>\<^sup>\<real> succ {}" using real_0_R real_0_th_33 by mty auto  
      have A10:"for p be MReal st
        {} <\<^sup>\<real> p ex n be Nat st for m be Nat st n \<subseteq> m holds |. (s1. m) -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> p"
     proof(rule ballI, rule impI)
       fix s assume [ty]:"s be  MReal" and
A11:  "{} <\<^sup>\<real> s"
       hence H1: "{} <\<^sup>\<real> 1\<^sub>\<S>/\<^sub>\<real> s" "{} <> s" 
         using real_1_div_4 A11 ONE real_0_th_33 by mty auto
       obtain n where [ty]:"n be Element-of NAT" and
         A12: "1\<^sub>\<S>/\<^sub>\<real> s <\<^sup>\<real> n" using real_1_TH[of "1\<^sub>\<S>/\<^sub>\<real> s"] by mty auto

        have "{} c= succ (n)" using tarski_def_3I xb all_set by mty auto  
        hence "{} \<subset> succ (n)" using A7 xboole_0_def_8 by mty auto
        hence "n in succ n" "{} in succ n" 
          using ordinal1_th_2 ordinal1_th_7[of "{}" "succ (n)"] Lm1 by mty auto
       hence  "n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" using arytm_3_TH1e[of _ "succ n"] by mty auto
       hence "n <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" using arytm_2_lm_14 by mty auto
       hence H2: "n <\<^sup>\<real> succ n" "{} <\<^sup>\<real> succ n" using real_0_th_29 by mty auto
       hence "n \<le>\<^sup>\<real> succ n" using real_0_th_33 by mty auto
       hence "1\<^sub>\<S>/\<^sub>\<real> s <\<^sup>\<real> succ n" using real_0_def_8t2[of "succ n" _ n] A12 by mty auto
       hence "(succ {}) /\<^sub>\<real> (succ n) <\<^sup>\<real> 1\<^sub>\<S> /\<^sub>\<real> (1\<^sub>\<S>/\<^sub>\<real> s) " 
         using real_1_th_29s[of _ _ "1\<^sub>\<S>"] ONE H1  by mty auto
       hence A13: "(succ {}) /\<^sub>\<real> (succ n) <\<^sup>\<real> s" 
         using real_1_div_5 H1 by mty auto
       show "ex n be Nat st for m be Nat st n \<subseteq> m holds |. (s1. m) -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s"
       proof(rule bexI[of _ n],intro ballI impI)
         fix m assume [ty]:"m be Nat" and "n \<subseteq> m"
         hence "1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> n c= 1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> m" using Add_13[of "1\<^sub>\<S>" m n] by mty auto
         hence " succ(n) c= m  +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" using Add_5[of n] Add_6[of m] by mty auto
         hence "succ(n) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m  +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" using arytm_3_TH1 by mty auto
         hence "succ(n) \<le>\<^sup>\<real> m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" 
           using arytm_2_lm_14[of "m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" "m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" "succ(n)" "succ(n)" ] real_0_th_29 by mty auto
         hence "1\<^sub>\<S> /\<^sub>\<real> (m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>) \<le>\<^sup>\<real> 1\<^sub>\<S> /\<^sub>\<real> succ(n)" using real_1_th_29 H2 ONE by mty auto
         hence H3:"1\<^sub>\<S> /\<^sub>\<real> (m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>) <\<^sup>\<real> s" 
           using A13 real_0_def_8t1[of s "1\<^sub>\<S> /\<^sub>\<real> succ(n)" "1\<^sub>\<S> /\<^sub>\<real> (m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)"] by mty auto
         have "|. (s1. m) -\<^sub>\<S>\<^sup>\<real> x0 .|<\<^sup>\<real> 1\<^sub>\<S> /\<^sub>\<real> (m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)" using A6 by mty auto
         hence "|. (s1. m) -\<^sub>\<S>\<^sup>\<real> x0 .|\<le>\<^sup>\<real> 1\<^sub>\<S> /\<^sub>\<real> (m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)" using real_0_th_33 by mty auto
         thus "|. (s1. m) -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s" 
           using H3 real_0_def_8t1[of s "1\<^sub>\<S> /\<^sub>\<real> (m +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)"] H3 by mty auto    
       qed mauto
     qed mauto
     hence A15: "s1 is convergent" using seq_2_def_6I[of s1] bexI[of _ x0 MReal] by mty auto
     hence "lim s1 = x0" using seq_2_def_7_uniq[of s1 x0] A10 by mty auto
     hence "(f\<circ>s1) is convergent " " f. x0=lim(f\<circ>s1)" using  A1 A7 A15 
       fcont_1_def_1[of f x0] by mty auto
     then obtain n where [ty]:"n is Nat" and
        A16: "for m be Nat st n \<subseteq> m holds |. (f\<circ>s1).m -\<^sub>\<S>\<^sup>\<real> f. x0 .| <\<^sup>\<real> r"
       using A2 seq_2_def_7[of "f\<circ>s1" r]  by mty auto
     hence "|. (f\<circ>s1).n -\<^sub>\<S>\<^sup>\<real> f. x0 .| <\<^sup>\<real> r" using xboole_0_def_10[of n n] by mty auto
     thus False using A8  by mty auto
   qed
 next
  assume
A17: "for r st {} <\<^sup>\<real> r 
( ex s st {} <\<^sup>\<real> s & (for x1 st x1
  in dom f & |. x1 -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s holds |. f .x1 -\<^sub>\<S>\<^sup>\<real> f .x0 .| <\<^sup>\<real> r))"
  show "f is_continuous_in x0"
  proof(intro fcont_1_def_1I[of f x0] ballI impI)
    fix s1 assume [ty]:"s1 be Real_Sequence" and
A18: "rng s1 c= dom f & s1 is convergent & lim s1 = x0"
    have [ty]:"s1 be set" using all_set by mty auto
    have [ty]:"(f \<circ> s1) is Real_Sequence" using seq_ty A18 by mty auto
    have A20:"for p be MReal st
        {} <\<^sup>\<real> p ex n be Nat st for m be Nat st n \<subseteq> m holds |. ((f \<circ> s1). m) -\<^sub>\<S>\<^sup>\<real> f. x0 .| <\<^sup>\<real> p"
    proof(intro ballI impI)
      fix p assume [ty]:"p is MReal" and "{}<\<^sup>\<real> p"
      then obtain s where [ty]:"s is MReal" and 
         A21:"{} <\<^sup>\<real> s" and
       A22:"for x1 st x1 in dom f & |. x1 -\<^sub>\<S>\<^sup>\<real> x0 .| <\<^sup>\<real> s holds |. f .x1 -\<^sub>\<S>\<^sup>\<real> f .x0 .| <\<^sup>\<real> p"
        using A17[THEN bspec, of p] by mty auto
      obtain n where [ty]:"n be Nat" and
       A23: "for m being Nat  st n\<subseteq> m holds |.s1 .m -\<^sub>\<S>\<^sup>\<real> x0.|<\<^sup>\<real> s"
        using A18 A21 seq_2_def_7[of s1 s] by mty auto
      show " ex n be Nat st for m be Nat st n \<subseteq> m holds |. ((f \<circ> s1). m) -\<^sub>\<S>\<^sup>\<real> f. x0 .| <\<^sup>\<real> p"
      proof(intro bexI[of _ n] ballI impI)
        fix m assume [ty]: "m be Nat" and A: "n \<subseteq>m"
         
        have M: "m in NAT" "dom s1 =NAT" using ordinal1_def_12[of m] seq_1[of s1] by mty auto
          hence A9: "NAT <>{}" using xb by auto
        have "s1. m in rng s1" using funct_1_def_3[of s1 "s1. m",simplified] bexI[of _ m] M by mty auto
        hence "|.s1 .m -\<^sub>\<S>\<^sup>\<real> x0.|<\<^sup>\<real> s" "s1. m in dom f" using A23 A A18 tarski_def_3 by mty auto
        hence "|. f . (s1 .m) -\<^sub>\<S>\<^sup>\<real> f .x0 .| <\<^sup>\<real> p" using A22[THEN bspec, of "s1. m"] by mty auto
        thus "|. ((f \<circ> s1). m) -\<^sub>\<S>\<^sup>\<real> f . x0 .| <\<^sup>\<real> p"
             using A18 A9 funct_2_th_108[of REAL s1 NAT f REAL m,simplified]
          by mty auto
      qed mauto
    qed mauto
    hence "(f\<circ>s1) is convergent" using seq_2_def_6I[of "f\<circ>s1"] bexI[of _ "f. x0" MReal] by mty auto 
    thus "(f\<circ>s1) is convergent & f. x0 = lim (f\<circ>s1)" using  A20 seq_2_def_7_uniq by mty auto
  qed mauto
qed 

mdef fcont_1_def_2("continuous\<^sub>\<S>") where
  "attr continuous\<^sub>\<S> for PartFunc-of REAL,REAL means
    (\<lambda>f. for x0 st x0 in dom f holds f is_continuous_in x0)"..



mtheorem seq_2_lm_1:
"rng s1 c= dom(f|X) \<Longrightarrow> 
   rng s1 \<subseteq> dom f & ((f|X) \<circ> s1) = (f \<circ> s1)"
proof
  have D:"(dom f)\<inter> X \<subseteq> dom f" using tarski_def_3I xboole_0_def_4 by mty auto
  assume A:"rng s1 c= dom(f|X)"
  thus "rng s1 \<subseteq> dom f" using xboole_1_th_1[OF _ _ _ _ D]
   relat_1_th_55[of X f] by mty auto
  hence D: "dom((f|X) \<circ> s1) = dom s1" "dom(f \<circ> s1) = dom s1" using 
   funct_2_lm_1[of s1 f] funct_2_lm_1[of s1 "f|X"] A by mty auto
  have "for x be object st x in dom (f \<circ> s1) holds (f \<circ> s1) .x = ((f|X) \<circ> s1) .x"
  proof(intro ballI impI)
    fix x assume "x be object" and "x in dom (f \<circ> s1)"
    hence F:"(f \<circ> s1). x = f. (s1 .x)" "((f|X) \<circ> s1). x = (f|X). (s1 .x)" "s1 .x in dom (f|X)"
      using funct_1_th_12[of _ s1 x] D funct_1_th_11[of "(f|X)" s1 x] by mty auto
    hence "(f|X). (s1 .x) = f. (s1 .x)" using funct_1_th_47 by mty auto
    thus "(f \<circ> s1) .x = ((f|X) \<circ> s1) .x" using F by mty auto
  qed mauto
  thus "((f|X) \<circ> s1) = (f \<circ> s1)" using funct_1_th_2[of "f \<circ> s1" "(f|X) \<circ> s1"] D by mty auto
qed

mtheorem fcont_1_th_1:
  "x0 in X & f is_continuous_in x0 implies f|X is_continuous_in x0"
proof
  assume
A1: "x0 in X & f is_continuous_in x0"
  have [ty]:"f|X is PartFunc-of REAL,REAL" by mty auto
  show "f|X is_continuous_in x0"
  proof(intro fcont_1_def_1I ballI impI conjI)
    fix s1 assume [ty]:"s1 is Function-of omega, REAL" and
    A3:"rng s1 c= dom(f|X) & s1 is convergent & lim s1 = x0"
    have A5:"rng s1 \<subseteq> dom f & ((f|X) \<circ> s1) = (f \<circ> s1)" using A3 seq_2_lm_1[of X f s1] by mty auto   
    hence A6:"(s1 * f ) be convergent" "(f . x0) =\<^sub>\<S> lim (s1 * f)" using A3 A1 fcont_1_def_1E[of "f" x0,THEN bspec,of s1] 
      by mty auto    
    thus "(s1 * f | X) be convergent" using A5 by mty auto
    have "(f|X). x0 = f. x0" using A1 funct_1_th_49 by mty auto
    thus "(f|X). x0 =\<^sub>\<S> lim (s1 * f | X)" using A5 A6 by mty auto
  qed mauto
qed

mdef fcont_1_def_3 ("_  is'_continuous'_on _" [90,90] 90) where
  mlet "f be PartFunc-of REAL,REAL" ,"X be set"
  "pred f is_continuous_on X means
    for x st x in X holds f is_continuous_in x"..
end


