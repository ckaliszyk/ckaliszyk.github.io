theory real_0
  imports arytm_2
begin

reserve n,m,k for "Element-of REAL\<^bsup>\<ge>0\<^bsub>"

mdef real_0_def_1 (infix "--R" 110) where
  mlet "n be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "m be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  "func n --R m  \<rightarrow> object means
     \<lambda>it. it be Element-of REAL\<^bsup>\<ge>0\<^bsub> & (it +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m) = n if m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n 
      otherwise \<lambda>it. for k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) =m holds  it = [{},k]"
proof-
  show "(m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n implies (\<exists>x : object. x be Element-of REAL\<^bsup>\<ge>0\<^bsub> & (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m) = n))
      \<and>(\<not> m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n \<longrightarrow> (\<exists>x : object. \<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m \<longrightarrow> x = [{} , k]))"
  proof(intro conjI impI)
    assume "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
    then show "ex k be object st k be Element-of REAL\<^bsup>\<ge>0\<^bsub> & k+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m = n" 
      using arytm_2_th_9[of n m] arytm_2_def_8c by mty auto
  next 
    assume "\<not> m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
    hence "n \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m" using arytm_2_def_5c[of n m] by auto
    then obtain k where [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A1: "(n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) = m" using arytm_2_th_9[of m n] by mty auto 
    show "\<exists>x : object. \<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m \<longrightarrow> x = [{} , k]"
    proof(rule bexI[of _ "[{},k]"],intro ballI impI)
      fix K assume [ty]: "K be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
      assume "(K +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m"
      hence "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> K" using A1 arytm_2_def_8c by auto
      hence "k=K" using arytm_2_th_11[of K k n] by mty auto
      thus "[{} , k] = [{} , K]" by simp
    qed mauto
  qed
  fix x y
  show "(m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n \<and> (x be Element-of REAL\<^bsup>\<ge>0\<^bsub> & (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m) = n) \<and> (y be Element-of REAL\<^bsup>\<ge>0\<^bsub> & (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m) = n) \<longrightarrow> x = y) \<and>
        ( \<not> m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m \<longrightarrow> x = [{} , k]) \<and> 
                      (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m \<longrightarrow> y = [{} , k]) \<longrightarrow> x = y)"
  proof(intro conjI impI)
    assume A: "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n \<and> (x be Element-of REAL\<^bsup>\<ge>0\<^bsub> & (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m) = n) \<and> (y be Element-of REAL\<^bsup>\<ge>0\<^bsub> & (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m) = n)"
      hence "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x = m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_8c by auto
      then show "x=y" using arytm_2_th_11[of y x m] A by auto
    next
      assume A: "\<not> m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m \<longrightarrow> x = [{} , k]) \<and> 
                         (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n) = m \<longrightarrow> y = [{} , k])"
      hence "n \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m" using arytm_2_def_5c[of n m] by auto
      then obtain k where [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A1: "(n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) = m" using arytm_2_th_9[of m n] by auto 
      hence "k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n = m" using arytm_2_def_8c arytm_2_th_9 by auto 
      hence "x = [{} , k]" "y = [{} , k]" using A by auto
      then show "x=y" by auto 
  qed
qed mauto

mtheorem real_0_th_1:
  "(n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) = m implies m --R n = k"
proof(standard)
  assume A: "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m"
  have A2: "n \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m" using arytm_2_th_19[of n k ] A arytm_2_def_8c by mty auto
  hence [ty]: "m --R n is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and "(m --R n) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n =m" using real_0_def_1[of m n] by auto
  hence "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (m --R n) =m" using arytm_2_def_8c by auto
  then show "m--Rn = k" using arytm_2_th_11[of k "m--Rn" n] A by auto
qed

mtheorem real_0_th_2:
  "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k = {} implies n --R m = {}"
proof
  assume A1: "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k = {}"
  hence A2: "n=m" using arytm_2_def_8[of n k] by mty auto
  hence "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_2_def_5r by auto
  hence A3[ty]:"n--Rm is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and "(n --R m) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m =n" using real_0_def_1[of n m] by auto
  hence "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (n --R m) = n" using arytm_2_def_8c by auto
  hence "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (n --R m) = m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k" using A1 A2 by auto
  then show "n --R m = {}" using arytm_2_th_11[of k "n--Rm" m, OF _ A3] A1 A2 by mty auto
qed

mtheorem real_0_th_3:
  "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k<>{} implies n --R m = [{},k]"
proof
  assume A1: "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = m & k<>{}"
  hence "n <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m" using arytm_2_th_9l[of n m] by auto
  hence "\<not> m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" "k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n = m" using A1 arytm_2_def_8c by auto
  then show "n--Rm = [{},k]" using real_0_def_1[of n m] by auto
qed

mtheorem real_0_th_4:
  "n --R m is Element-of REAL\<^bsup>\<ge>0\<^bsub> iff m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
proof (standard,rule aaI)
  assume A1: "n--Rm is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "not m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
  hence "n <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m" by auto
  then obtain k where [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A2: "k<>{} & n+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k=m " using arytm_2_th_9l by auto 
  hence "n--Rm = [{},k]" using real_0_th_3 by auto
  then show False using A1 arytm_2_th_33d[of k] A2  by mty auto
next 
  assume "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
  then obtain k where [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A2:"(m+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)=n " using arytm_2_th_9[of n m] by auto 
  hence "n--Rm =k" using real_0_th_1 by auto
  then show "n--Rm is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by simp
qed

mtheorem real_0_th_5:
  "n --R k = n --R m implies k  = m"
proof(standard,cases " k \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" )
  assume A0: "n --R k = n --R m"
  case T: True
  then obtain w where [ty]: "w be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
      A1: "k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w =n" using arytm_2_th_9[of n k] by auto
  hence A2: "n--Rk = w" using real_0_th_1 by auto
  hence "n--Rm is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A0 by simp
  hence "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using real_0_th_4 by auto
  hence "(n--Rm)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m = n" "(n--Rk)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = n" using T real_0_def_1 by auto+
  hence "w +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = w+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m" using A0 A2 by auto
  then show "k=m" using arytm_2_th_11[of k m w] by mty auto
next 
  assume A0: "n --R k = n --R m"
  case T: False
  then obtain w where [ty]: "w be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
    A1: "w<>{} & n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w =k" using arytm_2_th_9l by auto
  hence A3: "n--Rk = [{},w]" using T real_0_th_3 by auto
  hence A2: "not n --R m is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 A0 arytm_2_th_33d[of w] by mty auto 
  have T1: "not m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
  proof
    assume "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n"
    then obtain w where [ty]: "w be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
      B1: "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w =n" using arytm_2_th_9[of n m] by auto
    hence "n--Rm =w" using real_0_th_1 by auto
    then show False using A2 by auto
  qed
   then obtain r where [ty]: "r be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
    A4: "r<>{} & n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r =m" using arytm_2_th_9l by auto
  hence "n --R m = [{},r]" using T1 real_0_th_3 by auto
  hence "w=r" using A3 A0 xtuple_0_th_1a by auto
  then show "k=m" using A1 A4 by simp
qed

mtheorem real_0_th_6:
  "n --R {} =n" 
proof-
  have "{} +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n=n" using arytm_2_def_8[of n] arytm_2_def_8c[of n] by mauto
  thus "n --R {} =n" using real_0_th_1 by mauto
qed

text_raw {*\DefineSnippet{REAL}{*}
mdef numbers_def_1 ("REAL") where
 "func REAL \<rightarrow> set equals 
     REAL\<^bsup>\<ge>0\<^bsub>\<union>[:{0\<^sub>\<S>},REAL\<^bsup>\<ge>0\<^bsub>:] \\ {[0\<^sub>\<S>,0\<^sub>\<S>]}" 
text_raw {*}%EndSnippet*}
  by auto

mtheorem 
  "cluster REAL \<rightarrow> non empty"
proof
  have "{} is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mauto 
  hence "{} in REAL\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "REAL\<^bsup>\<ge>0\<^bsub>" "{}"] by mauto
  then show "REAL is non empty" unfolding numbers_def_1 using xboole_0_def_3 xboole_0_def_1 by mty auto
qed

mdef real_0_def_3 ("Mreal") where
  "attr Mreal for object means (\<lambda>it . it in REAL)"..

mtheorem
  "cluster Mreal for object"
proof
  have "{} is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mauto 
  hence "{} in REAL\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "REAL\<^bsup>\<ge>0\<^bsub>"] by mauto
  hence "{} in REAL" unfolding numbers_def_1 using xboole_0_def_3 by mty auto
  thus "inhabited(Mreal \<bar> object)" using inhabited_def real_0_def_3 by auto
qed

abbreviation
  "MReal \<equiv> Mreal\<bar>object"

mtheorem cl_Preal_real:
  "cluster Element-of REAL\<^bsup>\<ge>0\<^bsub> \<rightarrow> Mreal for object"
proof(auto)
  fix it assume [ty]:"it be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  hence "it in REAL\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "REAL\<^bsup>\<ge>0\<^bsub>" it] by mauto
  hence "it in REAL" unfolding numbers_def_1 using xboole_0_def_3 all_set by auto 
  then show "it be Mreal" using real_0_def_3 by auto
qed

reserve x for object 

mtheorem real_0_th_7:
  "x is MReal iff x is Element-of REAL\<^bsup>\<ge>0\<^bsub> or (ex k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k])" 
proof(rule iffI3)
  show "x is MReal implies x is Element-of REAL\<^bsup>\<ge>0\<^bsub> or (ex k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k])"
  proof(standard,rule disjCI2)
    assume A1: "x is MReal"  "\<not> x be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    hence "x in REAL" "\<not> x in REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_3[of x] 
        Element(1) all_set by mty auto
    hence A2: "x in [:{ {} },REAL\<^bsup>\<ge>0\<^bsub>:] & not x in { [{},{}] }" unfolding numbers_def_1 using xboole_0_def_3
       xboole_0_def_5 by mty auto
    then obtain y z where
       A3: "y in {{}} & z in REAL\<^bsup>\<ge>0\<^bsub> & x=[y,z]" using zfmisc_1_def_2 by mty auto
    hence [ty]:"z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" using Element(6) all_set by auto
    have A4: "y = {}" "not x = [{},{}]" using A2 A3 tarski_def_1 by auto
    hence "not z = {}" using A3 xtuple_0_th_1[of y z] by auto
    then show "ex k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & x = [{},k]" using A3 A4 
bexI[of _ z "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by auto
  qed
  assume A1: "x be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<or> (\<exists>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. k \<noteq> {} \<and> x = [{} , k])"
  show "x is MReal"
  proof(cases "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>")
    case True
    hence "x in REAL\<^bsup>\<ge>0\<^bsub>" using Element(1)[of "REAL\<^bsup>\<ge>0\<^bsub>"] by mauto
    hence "x in REAL" unfolding  numbers_def_1 using xboole_0_def_3 by mty auto
    thus "x is MReal" using real_0_def_3 by mty auto
  next
    case False
    then obtain k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
       A2:"k\<noteq>{} \<and> x = [{},k]" using A1 by auto
    hence "x\<noteq> [{},{}]" using xtuple_0_th_1[of "{}" "{}" "{}" k] by mty auto 
    hence A3: "not x in {[{},{}]}" using tarski_def_1 by auto
    have "{} in {{}} & k in REAL\<^bsup>\<ge>0\<^bsub>" using tarski_def_1  Element(1)[of "REAL\<^bsup>\<ge>0\<^bsub>" k] by mty auto
    hence "x in [:{{}},REAL\<^bsup>\<ge>0\<^bsub>:]" using zfmisc_1_def_2 A2 by mty auto
    hence "x in [:{{}},REAL\<^bsup>\<ge>0\<^bsub>:]\\{[{},{}]}" using A3 xboole_0_def_5 by mty auto
    hence "x in REAL" unfolding numbers_def_1 using xboole_0_def_3 by mty auto  
    thus "x is MReal" using real_0_def_3 by mty auto
  qed
qed

mtheorem pair_Mreal:
  "k<>{} implies [{},k] is MReal"
proof
  assume "k<>{}"
  hence "ex n be Element-of REAL\<^bsup>\<ge>0\<^bsub> st n\<noteq>{} & [{},k] = [{},n]" using bexI[of _ k "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by mty auto
  then show "[{},k] is MReal" using real_0_th_7 by auto
qed


mtheorem
  mlet "r be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "s be Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
  "cluster r--R s \<rightarrow> MReal"
proof(standard,cases "s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r")
  case T: True
    then obtain k where TY[ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A1: "s +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = r" using arytm_2_th_9[of r s] by auto
    hence "r --R s = k" using real_0_th_1[ of r k s] T by mty auto 
    then show "r --R s be MReal"  using real_0_th_7[of k] by mty auto
  next
  case F: False
    then obtain k where TY[ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A1: "k <> {} & r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = s" using arytm_2_th_9l by auto
    hence A2: "r --R s = [{},k]" using real_0_def_1[of r s] F arytm_2_def_8c[of r k] by auto
    have "[{},k] is MReal" using real_0_th_7[of "[{},k]"] A1 bexI[of _ k "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] 
      by mty auto
    then show "r --R s be MReal"  using A2 by mty auto
qed

reserve k,k1,k2 for "Element-of REAL\<^bsup>\<ge>0\<^bsub>"  

reserve r,s,r1,r2,r3,t,w for MReal

mdef real_0_def_4 ("_ +\<^sub>\<S>\<^sup>\<real> _" [101,100] 100) where
  mlet "r be MReal","s be MReal"
  "func r +\<^sub>\<S>\<^sup>\<real> s \<rightarrow> MReal means
      \<lambda>it . (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = it  if r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & s is Element-of REAL\<^bsup>\<ge>0\<^bsub>,  
      \<lambda>it . for k st r = [{},k] holds it = s --R k if not r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & s is Element-of REAL\<^bsup>\<ge>0\<^bsub>,
      \<lambda>it . for k st s = [{},k] holds it = r --R k if r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & not s is Element-of REAL\<^bsup>\<ge>0\<^bsub> otherwise
          \<lambda>it . for k1, k2 st r = [{},k1] & s = [{},k2] holds it = [{},k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2]"
proof-
  show "(r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<longrightarrow> (\<exists>x : MReal. r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = x)) \<and>
    (\<not> r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<longrightarrow> (\<exists>x : MReal. \<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k] \<longrightarrow> x = s --R k)) \<and>
    (r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>  \<longrightarrow> (\<exists>x : MReal. \<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. s = [{} , k] \<longrightarrow> x = r --R k)) \<and>
    (\<not> (r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (\<not> r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<longrightarrow>
     (\<exists>x : MReal. \<forall>k1 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<forall>k2 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k1] \<and> s = [{} , k2] \<longrightarrow> x = [{} , k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2]))"
  proof(intro conjI impI)
    assume [ty]: "r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    have "(r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) is MReal" using real_0_th_7 by mty auto
    then show "\<exists>x : MReal. r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = x" by mty auto
  next
    assume A1:"\<not> r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    then obtain m where [ty]: "m be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A2: "m<>{} & r = [{},m]" using real_0_th_7[of r] by auto 
    have [ty]: " s be Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 by simp
    show "\<exists>x : MReal. \<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k] \<longrightarrow> x = s --R k"
    proof(rule bexI[of _ "s--Rm"],standard,standard)
      fix k assume [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and "r = [{} , k]"
      then show "s --R m = s --R k" using xtuple_0_th_1a A2 by auto
    qed mauto
  next    
    assume A1:" r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    then obtain m where [ty]: "m be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A2: "m<>{} & s = [{},m]" using real_0_th_7[of s] by auto 
    have [ty]: " r be Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 by simp
    show "\<exists>x : MReal. \<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. s = [{} , k] \<longrightarrow> x = r --R k"
    proof(rule bexI[of _ "r--Rm"],standard,standard)
      fix k assume [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and "s = [{} , k]"
      then show "r --R m = r --R k" using xtuple_0_th_1a A2 by auto
    qed mauto
  next 
    assume A1: "\<not> (r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (\<not> r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>)"
    then obtain m where [ty]: "m be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A2: "m<>{} & r = [{},m]" using real_0_th_7[of r] by auto 
    then obtain n where [ty]: "n be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A3: "n<>{} & s = [{},n]" using real_0_th_7[of s] A1 by auto   
    have "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n <>{}" using arytm_2_th_5[of n m] arytm_2_def_8c A2 A3 by mty auto
    hence "ex k be Element-of REAL\<^bsup>\<ge>0\<^bsub> st k\<noteq>{} & [{},m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n] = [{},k]" using 
bexI[of _ "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by mty auto
    hence [ty]: "[{},m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n] is MReal" using  real_0_th_7 by auto
    show "\<exists>x : MReal. \<forall>k1 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<forall>k2 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k1] \<and> s = [{} , k2] \<longrightarrow> x = [{} , (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]"
    proof(rule bexI[of _ "[{},m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n]"], intro ballI impI)
      fix k1 k2 assume [ty]:"k1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
        A4:"r = [{} , k1] \<and> s = [{} , k2]"
      hence "m=k1" "n=k2" using A2 A3 xtuple_0_th_1a by auto
      then show "[{} , m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n] = [{} , k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2]" by simp
    qed mauto
  qed
  fix x y assume [ty]: "x be MReal" "y be MReal"
  show" ((r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = x \<and> (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = y \<longrightarrow> x = y) \<and>
           ((\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k] \<longrightarrow> x = s --R k) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k] \<longrightarrow> y = s --R k) \<longrightarrow> x = y) \<and>
           ((r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. s = [{} , k] \<longrightarrow> x = r --R k) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. s = [{} , k] \<longrightarrow> y = r --R k) \<longrightarrow> x = y) \<and>
           (\<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            \<not> (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            \<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            (\<forall>k1 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<forall>k2 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k1] \<and> s = [{} , k2] \<longrightarrow> x = [{} , k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2]) \<and>
            (\<forall>k1 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<forall>k2 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k1] \<and> s = [{} , k2] \<longrightarrow> y = [{} , k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2]) \<longrightarrow>
            x = y)"
  proof(intro conjI impI)
    show "(r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = x \<and> (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = y \<Longrightarrow> x = y" by auto
  next
    assume A1: " (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k] \<longrightarrow> x = s --R k) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k] \<longrightarrow> y = s --R k)"
    then obtain m where [ty]: "m be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A2: "m<>{} & r = [{},m]" using real_0_th_7[of r] by auto 
    hence "x = s--Rm" "y = s--Rm" using A1 by auto
    then show "x = y" using A1 by auto
  next 
    assume A1: "(r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. s = [{} , k] \<longrightarrow> x = r --R k) \<and> (\<forall>k : Element-of REAL\<^bsup>\<ge>0\<^bsub>. s = [{} , k] \<longrightarrow> y = r --R k)"
      then obtain m where [ty]: "m be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A2: "m<>{} & s = [{},m]" using real_0_th_7[of s] by auto 
    hence "x = r--Rm" "y = r--Rm" using A1 by auto
    then show "x = y" using A1 by auto
  next
    assume A1: "\<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            \<not> (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            \<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            (\<forall>k1 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<forall>k2 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k1] \<and> s = [{} , k2] \<longrightarrow> x = [{} , (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]) \<and>
            (\<forall>k1 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<forall>k2 : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r = [{} , k1] \<and> s = [{} , k2] \<longrightarrow> y = [{} , (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)])"
    then obtain m1 where [ty]: "m1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A2: "m1<>{} & r = [{},m1]" using real_0_th_7[of r] by auto 
    obtain m2 where [ty]: "m2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A3: "m2<>{} & s = [{},m2]" using real_0_th_7[of s] A1 by auto 
    hence "x = [{} , (m1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m2)]" "y = [{} , (m1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m2)]"  using A2 A1 by auto
    then show "x=y" by simp
  qed
qed mauto


mtheorem
  mlet "r be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "s be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  "cluster r +\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub>"
proof
  have "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" using real_0_def_4 by auto
  then show "r +\<^sub>\<S>\<^sup>\<real> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
qed

mtheorem real_0_th_8:
  "r +\<^sub>\<S>\<^sup>\<real> {} = r & {} +\<^sub>\<S>\<^sup>\<real> r = r"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case T:True
  hence "r +\<^sub>\<S>\<^sup>\<real> {} = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {}" "{} +\<^sub>\<S>\<^sup>\<real> r = {} +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r"  using real_0_def_4 by mty auto
  then show "r +\<^sub>\<S>\<^sup>\<real> {} = r & {} +\<^sub>\<S>\<^sup>\<real> r = r" using arytm_2_def_8[of r "{}"] arytm_2_def_8c T by mty auto
next
  case F:False
  then obtain  k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
     A1:"k\<noteq>{} & r = [{},k]" using real_0_th_7[of r] by mty auto
  hence A2: "r +\<^sub>\<S>\<^sup>\<real> {} = {} --R k" "{} +\<^sub>\<S>\<^sup>\<real> r = {}--Rk" 
    using real_0_def_4[of r "{}",simplified] real_0_def_4[of "{}" r,simplified] F  by mty auto
  have "{} +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = k" using arytm_2_def_8[of "{}" k] arytm_2_def_8c by auto
  then show "r +\<^sub>\<S>\<^sup>\<real> {} = r & {} +\<^sub>\<S>\<^sup>\<real> r = r" using A2 A1 real_0_th_3[of k k "{}"] by mty auto
qed

mtheorem real_0_th_9:
  "k <> {}  implies k +\<^sub>\<S>\<^sup>\<real> [{},k] = {} & [{},k] +\<^sub>\<S>\<^sup>\<real> k = {} "
proof(rule impI)
  assume k: "k<>{}"
  hence "\<exists>ka : Element-of REAL\<^bsup>\<ge>0\<^bsub>. ka \<noteq> {} \<and> [{} , k] =\<^sub>\<S> [{} , ka]"
    using bexI[of _ k "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by mty auto
  hence [ty]: "[{}, k] is MReal" "[{}, k] is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
    using real_0_th_7[of "[{},k]"] k  arytm_2_th_33d[of k]
    by mty auto 
  have "k +\<^sub>\<S>\<^sup>\<real> [{},k] = k--Rk" "[{},k] +\<^sub>\<S>\<^sup>\<real> k = k--Rk"
    using real_0_def_4[of "[{},k]" k,simplified] using real_0_def_4[of k "[{},k]",simplified] 
    by mty auto
  then show " k +\<^sub>\<S>\<^sup>\<real> [{},k] = {} & [{},k] +\<^sub>\<S>\<^sup>\<real> k = {}" using 
 real_0_th_1[of k "{}" k] arytm_2_def_8[of k "{}"] by mty auto
qed

mtheorem real_0_th_10:
  "ex s st r +\<^sub>\<S>\<^sup>\<real> s = {} & s +\<^sub>\<S>\<^sup>\<real> r = {}"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]: True
    show "ex s st r +\<^sub>\<S>\<^sup>\<real> s = {} & s +\<^sub>\<S>\<^sup>\<real> r = {}"
    proof(cases "r={}")
      case True
      then show ?thesis using real_0_th_8[of r] bexI[of _ "{}" MReal] by mty auto
    next case F: False
      hence [ty]:"[{} , r] be Mreal" using pair_Mreal by mty auto
      hence " r +\<^sub>\<S>\<^sup>\<real> [{},r] = {} & [{},r] +\<^sub>\<S>\<^sup>\<real> r = {}" using real_0_th_9[of r,simplified] F by auto
      then show ?thesis using bexI[of _ "[{},r]" MReal,simplified] by auto
    qed
  next 
    case False
    then obtain k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A1: "k<>{} & r=[{},k]" using real_0_th_7[of r] by mty auto
    have [ty]: "k be Mreal" by mty auto
    hence [ty]:"[{} , k] be Mreal" using pair_Mreal A1 by mty auto
    hence " k +\<^sub>\<S>\<^sup>\<real> [{},k] = {} & [{},k] +\<^sub>\<S>\<^sup>\<real> k = {}" using real_0_th_9[of k,simplified] A1  by auto
    then show ?thesis using  bexI[of _ k MReal,simplified] A1 by auto
  qed

mtheorem real_0_th_11:
 "r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case T1[ty]: True
  show"r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r"
    proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case T2[ty]: True
      hence "r+\<^sub>\<S>\<^sup>\<real> s = r+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" "s+\<^sub>\<S>\<^sup>\<real> r = s+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using real_0_def_4 by mty auto
      then show "r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r" using arytm_2_def_8c by auto
    next
      case F2[ty]:False
         then obtain k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
           A1: "k<>{} & s=[{},k]" using real_0_th_7[of s] by mty auto
         hence "s+\<^sub>\<S>\<^sup>\<real> r = r --R k" "r+\<^sub>\<S>\<^sup>\<real> s = r --R k" using 
           real_0_def_4[of s r,simplified] real_0_def_4[of r s,simplified] by mty auto
         then show "r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r" using A1 real_0_def_4[of r s,simplified] by mty auto
    qed
  next
    case F1: False
      then obtain k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
        A1: "k<>{} & r=[{},k]" using real_0_th_7[of r] by mty auto
      hence [ty]:"r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d[of k] by mauto
      show"r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r"
        proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
          case T2[ty]:True
            hence "s+\<^sub>\<S>\<^sup>\<real> r = s --R k" "r+\<^sub>\<S>\<^sup>\<real> s = s --R k" using 
            real_0_def_4[of s r,simplified] real_0_def_4[of r s,simplified] A1 by mty auto
            then show "r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r" using A1 real_0_def_4[of r s,simplified] by mty auto
          next
            case F2:False
              then obtain n where [ty]: "n be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                A2: "n<>{} & s=[{},n]" using real_0_th_7[of s] by mty auto
              hence [ty]:"s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mauto    
              have "r +\<^sub>\<S>\<^sup>\<real> s = [{}, (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)]" "s +\<^sub>\<S>\<^sup>\<real> r = [{}, (n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)]" using 
               real_0_def_4[of r s, simplified] real_0_def_4[of s r, simplified] A1 A2  by mty auto
              then show "r +\<^sub>\<S>\<^sup>\<real> s = s +\<^sub>\<S>\<^sup>\<real> r" using arytm_2_def_8c by auto
    qed
qed

mtheorem real_0_th_12:
  "(k +\<^sub>\<S>\<^sup>\<real> k1) --R k2 = k +\<^sub>\<S>\<^sup>\<real> (k1 --R k2)" 
proof(cases " k2 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k +\<^sub>\<S>\<^sup>\<real> k1")
  case T1:True
    then obtain w where [ty]: "w be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A1: "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w = (k +\<^sub>\<S>\<^sup>\<real> k1)" using arytm_2_th_9[of "k +\<^sub>\<S>\<^sup>\<real> k1" k2] by mty auto
    have A2: "k+\<^sub>\<S>\<^sup>\<real> k1 = k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k1" using real_0_def_4 by auto 
    have A3: "(k +\<^sub>\<S>\<^sup>\<real> k1) --R k2 = w" using A1 real_0_th_1 by auto    
    show "(k +\<^sub>\<S>\<^sup>\<real> k1) --R k2 = k +\<^sub>\<S>\<^sup>\<real> (k1 --R k2)"
      proof(cases "k2 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k1")
        case T2:True
          then obtain n where [ty]: "n be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
             A4: "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n = k1" using arytm_2_th_9[of k1 k2] by auto
          hence "k1 --R k2 = n" using real_0_th_1 by auto
          hence A5: "k +\<^sub>\<S>\<^sup>\<real> (k1 --R k2) = k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using real_0_def_4[of k n] by auto 
          have  "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w = (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using A1 A2 A4 arytm_2_th_6 by auto
          hence "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w = k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)" using arytm_2_def_8c[of k2 k]arytm_2_th_6 by auto
          hence "w = k+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_2_th_11[of w "k+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" k2]  by mty auto
          then show ?thesis using A3 A5 by simp
        next 
          case False
            then obtain n where [ty]: "n be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
             A4: "n <>{} & k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n = k2" using arytm_2_th_9l by auto
            have [ty]: "[{},n] is MReal" using A4 pair_Mreal by auto                                  
            have "k1 --R k2 = [{},n]" using A4 real_0_th_3 by auto
            hence A5: "k +\<^sub>\<S>\<^sup>\<real> (k1 --R k2) = k --R n" 
              using real_0_def_4[of k "[{},n]",simplified] arytm_2_th_33d A4 by mty auto
            have  "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w) = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k" using A1 A2 A4 arytm_2_th_6 arytm_2_def_8c[of k k1] by auto
            hence "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w = k" using arytm_2_th_11[of k "n +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w" k1,simplified] by mty auto
            hence "k--Rn = w" using real_0_th_1 by auto
          then show ?thesis using A3 A5 by simp
        qed
    next
      case F1:False
        then obtain n where [ty]: "n be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
        A1: "n <>{} & (k +\<^sub>\<S>\<^sup>\<real> k1)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n = k2" using arytm_2_th_9l by auto
        have A2: "(k +\<^sub>\<S>\<^sup>\<real> k1) --R k2 = [{},n]" using A1 real_0_th_3 by auto
        have A3: "k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n <>{}" using arytm_2_th_5[of k n] arytm_2_def_8c[of k n] A1 by mty auto
        hence [ty]: "[{},(k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)] is MReal" "[{},(k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)] is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
           using pair_Mreal arytm_2_th_33d by mty auto
        have "k2 = (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using A1 real_0_def_4[of k k1,simplified] arytm_2_def_8c[of k k1] by mty auto
        hence "k2 = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)" using arytm_2_th_6 by mty auto
        hence "k1 --R k2 = [{},(k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)]" using A3 real_0_th_3 by mty auto
        hence "k +\<^sub>\<S>\<^sup>\<real> (k1 --R k2) = k --R (k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)" using 
              real_0_def_4[of k "[{},(k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n)]",simplified] by mty auto
        then show "(k +\<^sub>\<S>\<^sup>\<real> k1) --R k2  = k +\<^sub>\<S>\<^sup>\<real> (k1 --R k2)" using A1 A2 A3 real_0_th_3[of "k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" n] by mty auto 
      qed

mtheorem real_0_th_13:
  "not r is Element-of REAL\<^bsup>\<ge>0\<^bsub> implies (k1 +\<^sub>\<S>\<^sup>\<real> k2) +\<^sub>\<S>\<^sup>\<real> r = k1 +\<^sub>\<S>\<^sup>\<real> (k2 +\<^sub>\<S>\<^sup>\<real> r)"
proof
  assume "not r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
 then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A1: "k3<>{} & r=[{},k3]" using real_0_th_7[of r] by mty auto
  hence [ty]:"r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mauto
 have [ty]: "k1 +\<^sub>\<S>\<^sup>\<real> k2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
  have "(k1 +\<^sub>\<S>\<^sup>\<real> k2) +\<^sub>\<S>\<^sup>\<real> r = (k1 +\<^sub>\<S>\<^sup>\<real> k2) --R k3" using real_0_def_4[of "k1 +\<^sub>\<S>\<^sup>\<real> k2" r,simplified] 
    A1 by mty auto
   also have "...= k1 +\<^sub>\<S>\<^sup>\<real> (k2 --R k3)" using real_0_th_12 by mty auto
   also have "\<dots>=k1 +\<^sub>\<S>\<^sup>\<real> (k2 +\<^sub>\<S>\<^sup>\<real> r) " using real_0_def_4[of k2 r,simplified] A1 by mty auto
  finally show "(k1 +\<^sub>\<S>\<^sup>\<real> k2) +\<^sub>\<S>\<^sup>\<real> r = k1 +\<^sub>\<S>\<^sup>\<real> (k2 +\<^sub>\<S>\<^sup>\<real> r)" by auto
qed

mtheorem real_0_th_14:
  "not r1 is Element-of REAL\<^bsup>\<ge>0\<^bsub> & not r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub> implies (k +\<^sub>\<S>\<^sup>\<real> r1) +\<^sub>\<S>\<^sup>\<real> r2 = k +\<^sub>\<S>\<^sup>\<real> (r1 +\<^sub>\<S>\<^sup>\<real> r2)"
proof
  assume A0[ty]: "not r1 is Element-of REAL\<^bsup>\<ge>0\<^bsub> & not r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  then obtain k1 where [ty]: "k1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A1: "k1<>{} & r1=[{},k1]" using real_0_th_7[of r1] by mty auto
  then obtain k2 where [ty]: "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A2: "k2<>{} & r2=[{},k2]" using real_0_th_7[of r2] A0 by mty auto
  have A3: "k +\<^sub>\<S>\<^sup>\<real> r1 = k --R k1" using real_0_def_4[of k r1,simplified] A1 by mty auto
  have A4: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = [{}, k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2]" "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2<>{}"
    using real_0_def_4[of r1 r2,simplified] A1 A2 arytm_2_th_5[of k2 k1] by mty auto  
  hence [ty]:"r1 +\<^sub>\<S>\<^sup>\<real> r2 be non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mauto  
  have  A5: "k +\<^sub>\<S>\<^sup>\<real> (r1 +\<^sub>\<S>\<^sup>\<real> r2) = k --R (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)" using
      real_0_def_4[of k "r1 +\<^sub>\<S>\<^sup>\<real> r2",simplified] A4 by mty auto
  show "(k +\<^sub>\<S>\<^sup>\<real> r1) +\<^sub>\<S>\<^sup>\<real> r2 = k +\<^sub>\<S>\<^sup>\<real> (r1 +\<^sub>\<S>\<^sup>\<real> r2)"
  proof(cases "k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k")
    case True
      then obtain w1 where [ty]: "w1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
        B1: "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w1 = k" using arytm_2_th_9[of k k1] by auto
      hence C1: "k --R k1 = w1" using real_0_th_1 by auto
      show ?thesis
      proof(cases "k2 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w1")
        case True
          then obtain w2 where [ty]: "w2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
            B2: "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w2 = w1" using arytm_2_th_9[of w1 k2] by auto
          hence "w1 --R k2 = w2" using real_0_th_1 by mty auto
          hence C2: "w1 +\<^sub>\<S>\<^sup>\<real> r2 = w2" using real_0_def_4[of w1 r2,simplified] A2 by mty auto
          have "(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w2 = k" using B1 B2 arytm_2_th_6[of w2 k2] by mty auto
          hence "k --R (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) = w2" using real_0_th_1 by mty auto
          then show ?thesis using A3 A5 B1 C1 C2 by auto
        next
        case False
          then obtain w2 where [ty]: "w2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
            B2: "w2 <>{} & k2 = w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w2" using arytm_2_th_9l[of w1 k2] by mty auto
          have [ty]: "[{},w2] is MReal" using pair_Mreal B2 by mty auto
          have "w1 --R k2 = [{},w2]" using real_0_th_3 B2 by mty auto
          hence C2: "w1 +\<^sub>\<S>\<^sup>\<real> r2 = [{},w2]" using real_0_def_4[of w1 r2,simplified] A2 by mty auto
          have [ty]:"(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
          have " k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w2 = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w2)" using B1 arytm_2_th_6[of w2 w1 k1]  by auto
          hence "k --R (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) = [{},w2]" using real_0_th_3[of "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2" w2 k,simplified] B2 by mty auto
          then show ?thesis using A3 C1 C2 A5 by auto
        qed
      next
        case False
           then obtain w1 where [ty]: "w1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
            B2: "w1 <>{} & k1 = k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w1" using arytm_2_th_9l[of k k1] by mty auto
           hence [ty]: "[{} , w1] be non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mauto
          have [ty]: "[{},w1] is MReal" using pair_Mreal B2 by mty auto
          have [ty]: "(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "(w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
          have "k --R k1 = [{},w1]" using real_0_th_3 B2 by mty auto
          hence "(k +\<^sub>\<S>\<^sup>\<real> r1) +\<^sub>\<S>\<^sup>\<real> r2 = [{},w1] +\<^sub>\<S>\<^sup>\<real> [{},k2]" using A3 A2 by auto
          hence C2: "(k +\<^sub>\<S>\<^sup>\<real> r1) +\<^sub>\<S>\<^sup>\<real> r2 = [{},(w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]" 
            using A3 A2 real_0_def_4[of "[{},w1]" r2,simplified]  by mty auto
          have H1: "w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 <>{}" using arytm_2_th_5[of k2 w1] B2 by mty auto
          have "k +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2" using B2 arytm_2_th_6 by auto
          hence "k --R (k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) = [{},(w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]" using H1 real_0_th_3[of "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2" "w1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2" k,simplified] by auto 
          thus ?thesis using C2 A5 by auto 
      qed
qed

mtheorem real_0_th_15:
 "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = r1 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r3)"
proof(cases "r1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case T1[ty]: True
  show ?thesis
     proof(cases "r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
       case T2[ty]: True
           show "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = r1 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r3)"
              proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
                case T3[ty]:True
                have "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = (r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using real_0_def_4 by mty auto
                  also have "...= (r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using real_0_def_4 by mty auto
                  also have "...= r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (r2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3)" using arytm_2_th_6 by mty auto
                  also have "...= r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (r2 +\<^sub>\<S>\<^sup>\<real> r3)" using real_0_def_4 by mty auto
                  also have "...= r1 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r3)" using real_0_def_4 by mty auto
                  finally show ?thesis by auto
               next
                 case F2: False
                 thus ?thesis using real_0_th_13 by auto
                qed
     next
       case F2[ty]: False
             then obtain k2 where [ty]: "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                   A1: "k2<>{} & r2=[{},k2]" using real_0_th_7[of r2] F2 by mty auto
             have A2: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r1 --R k2" using 
                   real_0_def_4[of r1 r2,simplified] A1 arytm_2_th_33d by mty auto                 
       show ?thesis
       proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
         case [ty]:True
                have "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = (r1 --R k2) +\<^sub>\<S>\<^sup>\<real> r3" using A2 by mty auto
                 also have "...= r3 +\<^sub>\<S>\<^sup>\<real> (r1 --R k2)" using real_0_th_11 by mty auto
                  also have "...= (r3 +\<^sub>\<S>\<^sup>\<real> r1) --R k2" using real_0_th_12[of k2 r1 r3,simplified] by mty auto
                  also have "...= (r3 +\<^sub>\<S>\<^sup>\<real> r1) +\<^sub>\<S>\<^sup>\<real> r2"  
                    using A1 real_0_def_4[of "r3 +\<^sub>\<S>\<^sup>\<real> r1" r2,
                    THEN conjunct2,THEN conjunct2,THEN conjunct1,simplified] by mauto
                   also have "...= (r1 +\<^sub>\<S>\<^sup>\<real> r3) +\<^sub>\<S>\<^sup>\<real> r2"  using real_0_th_11[of r1 r3,simplified] by mty auto
                   also have "...= r1 +\<^sub>\<S>\<^sup>\<real> (r3 +\<^sub>\<S>\<^sup>\<real> r2)"  using real_0_th_13 F2 by mty auto                 
                  also have "...= r1 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r3)" using real_0_th_11 by mty auto
                  finally show ?thesis by auto
          next
            case False
              then show ?thesis using real_0_th_14[of r1 r3 r2] F2 by auto
           qed
     qed
   next
     case F1: False
     show ?thesis  
     proof(cases "r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
       case T2[ty]:True 
         show ?thesis  
         proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
           case T3[ty]:True
           have "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = r3 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r1)" using real_0_th_11 by auto
           also have "... = (r3+\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r1" using real_0_th_13[of r2 r3 r1,simplified] F1 by auto  
           finally show ?thesis using real_0_th_11 F1 by auto
         next
           case F3:False
           have  "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = (r2 +\<^sub>\<S>\<^sup>\<real> r1) +\<^sub>\<S>\<^sup>\<real> r3" using real_0_th_11 by auto
           also have "... = r2 +\<^sub>\<S>\<^sup>\<real> (r1 +\<^sub>\<S>\<^sup>\<real> r3)" using real_0_th_14[of r2 r3 r1] F1 F3 by auto
           also have "... = r2 +\<^sub>\<S>\<^sup>\<real> (r3 +\<^sub>\<S>\<^sup>\<real> r1)" using real_0_th_11[of r1 r3] F1 F3 by auto
           also have "... = (r2 +\<^sub>\<S>\<^sup>\<real> r3) +\<^sub>\<S>\<^sup>\<real> r1" using real_0_th_14[of r2 r1 r3] F1 F3 by auto
           finally show ?thesis using real_0_th_11[of r1] by auto         
         qed
       next
         case F2:False
         show ?thesis  
         proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
           case T3[ty]:True
                   have  "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = r3 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r1)" using real_0_th_11 by auto
                   also have  "... = (r3 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r1" using real_0_th_14[of r3] F1 F2 by auto
                   also have  "... = r1 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r3)" using real_0_th_11 by auto
                   finally show ?thesis by auto         
           next case F3: False
                         then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                          A3: "k3<>{} & r3=[{},k3]" using real_0_th_7[of r3] by mty auto
                         obtain k2 where [ty]: "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                          A2: "k2<>{} & r2=[{},k2]" using real_0_th_7[of r2] F2 by mty auto
                         obtain k1 where [ty]: "k1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                          A1: "k1<>{} & r1=[{},k1]" using real_0_th_7[of r1] F1 by mty auto
                         have "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 <>{}" "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3 <>{}" 
                           using A1 A2 A3 arytm_2_th_5[of k2 k1] arytm_2_th_5[of k3 k2] 
                           by mty auto
                         hence [ty]:"[{},(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)] is MReal" "[{},(k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)] is MReal"
                            "not [{},(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)] is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "not [{},(k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)] is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
                             using pair_Mreal arytm_2_th_33d by mty auto
                         have H1: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = [{},(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]" using real_0_def_4[of r1 r2,simplified] A1 A2 F1 F2 by mty auto
                         have H2: "r2 +\<^sub>\<S>\<^sup>\<real> r3 = [{},(k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)]" using real_0_def_4[of r2 r3,simplified] A3 A2 F3 F2 by mty auto                         
                         have "(r1 +\<^sub>\<S>\<^sup>\<real> r2) +\<^sub>\<S>\<^sup>\<real> r3 = [{},((k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)]"
                           using real_0_def_4[of "[{},(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]" r3,simplified] A3 F3 H1 
                           by mty auto
                         also have "\<dots>= [{},(k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (k2+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3))]" using arytm_2_th_6 by auto
                         also have "\<dots>=r1 +\<^sub>\<S>\<^sup>\<real> (r2 +\<^sub>\<S>\<^sup>\<real> r3)"
                           using real_0_def_4[of r1 "[{},(k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)]",simplified] A1 F1 H2 by mty auto
                         finally show ?thesis by auto  
    qed                                 
  qed
qed

mtheorem real_0_th_16:
  "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r1 +\<^sub>\<S>\<^sup>\<real> r3 implies r2 = r3"
proof(standard, cases "r1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  assume A0: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r1 +\<^sub>\<S>\<^sup>\<real> r3"
  case [ty]: True
    show "r2 = r3"
    proof(cases "r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
        hence A1: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2" using real_0_def_4 by auto 
        show ?thesis
        proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
          case [ty]: True
          hence "r1 +\<^sub>\<S>\<^sup>\<real> r3 = r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using real_0_def_4 by auto 
          thus ?thesis using A0 A1 arytm_2_th_11[of r3 r2 r1] by mty auto
        next
          case False
          then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
             B1: "k3<>{} & r3=[{},k3]" using real_0_th_7[of r3] by mty auto  
          hence B2: "r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2 = r1 --R k3" 
            using A0 A1 real_0_def_4[of r1 r3,simplified] arytm_2_th_33d by mty auto
          have "(r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
          hence [ty]: "r1 --R k3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using B2 by mty auto
          hence "k3 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r1" using real_0_th_4[of k3 r1,simplified] by mty auto
          hence "(r1 --R k3) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3 = r1" using real_0_def_1[of r1 k3,simplified] by mty auto 
          hence "r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (r2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3) = r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using B2 arytm_2_th_6[of k3 r2 r1] 
             arytm_2_def_8[of r1 "{}"] by mty auto
          hence "r2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3 = {}" using arytm_2_th_11[of  "{}" _ r1] by mty auto
          thus ?thesis using B1 arytm_2_th_5[of r2 k3] arytm_2_def_8c by mty auto
        qed
      next case False
        then obtain k2 where [ty]: "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
          C1: "k2<>{} & r2=[{},k2]" using real_0_th_7[of r2] by mty auto  
        have C2: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r1 --R k2" 
          using C1 real_0_def_4[of r1 r2,simplified] arytm_2_th_33d by mty auto
        show ?thesis
          proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
            case [ty]: True
              have B2: "r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3 = r1 --R k2" 
                using A0 C1 C2 real_0_def_4[of r1 r3,simplified] by mty auto
              have "(r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
              hence [ty]: "r1 --R k2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using B2 by mty auto
              hence "k2 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r1" using real_0_th_4[of k2 r1,simplified] by mty auto
              hence "(r1 --R k2) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 = r1" using real_0_def_1[of r1 k2,simplified] by mty auto 
              hence "r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (r3 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2) = r1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using 
               B2 arytm_2_th_6[of k2 r3 r1] arytm_2_def_8[of  r1 "{}"] by mty auto
              hence "r3 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 = {}" using arytm_2_th_11[of  "{}" _ r1] by mty auto
              thus ?thesis using C1 arytm_2_th_5[of r3 k2] arytm_2_def_8c by mty auto
            next case False
               then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                D1: "k3<>{} & r3=[{},k3]" using real_0_th_7[of r3] by mty auto  
               have "r1 +\<^sub>\<S>\<^sup>\<real> r3 = r1 --R k3" using D1 real_0_def_4[of r1 r3,simplified] 
                   arytm_2_th_33d by mty auto 
               hence "k2=k3"  using A0 C2 real_0_th_5[of k3 k2 r1] by mty auto
               then show "r2 = r3" using C1 D1 by simp
        qed
    qed
  next
    assume A0: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r1 +\<^sub>\<S>\<^sup>\<real> r3"
    case F0[ty]: False
      then obtain k1 where [ty]: "k1 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
          F1: "k1<>{} & r1=[{},k1]" using real_0_th_7[of r1] by mty auto       
    show "r2 = r3"
    proof(cases "r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
        hence A1: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = r2 --R k1" using real_0_def_4[of r1 r2,simplified] F0 F1 by auto
        show ?thesis
        proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
          case [ty]: True
          hence A2: "r1 +\<^sub>\<S>\<^sup>\<real> r3 = r3 --R k1" using real_0_def_4[of r1 r3,simplified] F0 F1  by auto 
          hence A3: "r2 --Rk1 = r3--Rk1" using A0 A1 by auto 
          show "r2 = r3"
          proof(cases "k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2")
            case T1: True
              hence [ty]: "r2--Rk1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "r3--Rk1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A3 real_0_th_4[of k1 r2,simplified] by mty auto
              hence T2: "k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using real_0_th_4[of k1 r3,simplified] by auto
              hence T3: "(r2--Rk1) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k1 = r2" "(r3--Rk1) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k1 = r3" using real_0_def_1 T1 by auto
              have "(r3--Rk1) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k1 = r2" using A3 T3(1) by simp 
              then show ?thesis using T3(2) by simp 
            next
              case F2:False
                hence [ty]: "not r2--Rk1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "not r3--Rk1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A3 real_0_th_4[of k1 r2,simplified] by mty auto    
                hence F3:"not k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using real_0_th_4[of k1 r3,simplified] by auto
                obtain j2 where [ty]:"j2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                  F4: "j2 <>{} & r2+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> j2 = k1" using arytm_2_th_9l[of r2 k1] F2 by mauto
                then obtain j3 where [ty]: "j3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
                  F5: "j3 <>{} & r3+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> j3 = k1" using arytm_2_th_9l F3 by auto
                have "r2--Rk1 = [{},j2]" "r3--Rk1 = [{},j3]" using real_0_th_3 F4 F5 by auto
                hence "[{},j2] = [{},j3]" using A3 by auto
                hence "j2 =j3" using xtuple_0_th_1a by auto
                hence "j2+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2 = j2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using F4 F5 arytm_2_def_8c by auto
                then show "r2 = r3" using F4 F5 arytm_2_th_11[of r3 r2 j2] by mty auto 
          qed
        next case F3: False
          then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
          C1: "k3<>{} & r3=[{},k3]" using real_0_th_7[of r3] by mty auto  
          have C2: "r1 +\<^sub>\<S>\<^sup>\<real> r3 = [{}, (k1+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)]" "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3<>{}"
            using real_0_def_4[of r1 r3,simplified] F1 C1 arytm_2_th_33d arytm_2_th_5[of k3 k1] 
                        by mty auto 
          hence "not r1+\<^sub>\<S>\<^sup>\<real> r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_33d by mty auto
          hence "not r2 --R k1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 A0 by mty auto 
          hence " not k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r2" using real_0_th_4 A1 A0 by mty auto
          then obtain k2 where [ty]: "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
            C3: "k2 <>{} & r2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 =k1" using arytm_2_th_9l by auto
          hence "r2 --R k1 = [{},k2]" using real_0_th_3[of k1 k2 r2] by mty auto
          hence "k2 = (k1+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)" using C2 A0 A1 xtuple_0_th_1a by auto
          hence "k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {} = k2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (r2+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)" 
            using C3 arytm_2_def_8c[of k2 r2,simplified]arytm_2_th_6[of k3 r2 k2,simplified] 
           arytm_2_def_8[of k2 "{}"] by mty auto
          hence "{} = (r2+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)" using arytm_2_th_11[of "r2 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3" "{}" k2] by mty auto   
          thus ?thesis using arytm_2_th_5[of r2 k3] C1 arytm_2_def_8c[of r2 k3]by auto
        qed
      next
        case F2[ty]:False
          then obtain k2 where [ty]: "k2 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
          C1: "k2<>{} & r2=[{},k2]" using real_0_th_7[of r2] by mty auto
           have C2: "r1 +\<^sub>\<S>\<^sup>\<real> r2 = [{}, (k1+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)]" using real_0_def_4[of r1 r2,simplified] 
         F1 C1 by mty auto         
         show ?thesis
         proof(cases "r3 is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
           case [ty]: True
             hence A1: "r1 +\<^sub>\<S>\<^sup>\<real> r3 = r3 --R k1" using real_0_def_4[of r1 r3,simplified] F0 F1 by auto    
             have "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 <>{}" using C1 arytm_2_th_5[of k1 k2] arytm_2_def_8c[of k1 k2] 
               by mauto
             hence "not r1+\<^sub>\<S>\<^sup>\<real> r2 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using C2 arytm_2_th_33d by mty auto
             hence "not r3 --R k1 is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 A0 by mty auto 
             hence " not k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r3" using real_0_th_4 A1 A0 by mty auto
             then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
             C3: "k3 <>{} & r3 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3 =k1" using arytm_2_th_9l by auto
             hence "r3 --R k1 = [{},k3]" using real_0_th_3[of k1 k3 r3] by mty auto
             hence "k3 = (k1+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)" using C2 A0 A1 xtuple_0_th_1a by auto
             hence "k3 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {} = k3 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (r3+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)" using C3 arytm_2_def_8c[of k3 r3,simplified]arytm_2_th_6[of k2 r3 k3,simplified] 
               arytm_2_def_8[of k3 "{}",simplified] by mty auto
             hence "{} = (r3+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2)" using arytm_2_th_11[of "r3 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2" "{}" k3] by mty auto   
             thus ?thesis using arytm_2_th_5[of r3 k2] C1 arytm_2_def_8c[of r3 k2] C1 by auto
         next
           case F3[ty]:False
             then obtain k3 where [ty]: "k3 be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
             D1: "k3<>{} & r3=[{},k3]" using real_0_th_7[of r3] by mty auto  
             have D2: "r1 +\<^sub>\<S>\<^sup>\<real> r3 = [{}, (k1+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3)]" using real_0_def_4[of r1 r3,simplified] F1 D1 by mty auto  
             hence "k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k3" using A0 C2 xtuple_0_th_1a by auto
             hence "k2 = k3" using arytm_2_th_11[of k3 k2 k1] by auto
             thus ?thesis using D1 C1 by auto
        qed
     qed
   qed    

mdef real_0_def_5 ( "-\<^sub>\<S>\<^sup>\<real> _" 110) where
  mlet "r be MReal"
  "func -\<^sub>\<S>\<^sup>\<real> r  \<rightarrow> MReal means
     \<lambda>it . it +\<^sub>\<S>\<^sup>\<real> r = {}"
proof-
  show "ex x be MReal st  x +\<^sub>\<S>\<^sup>\<real> r = {}"
  proof(cases "r ={}")
    case True
    thus ?thesis using bexI[of _ "{}" MReal] real_0_th_8[of "{}"] by mty auto
  next case F: False
    show ?thesis 
    proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
        hence [ty]: "[{},r] is MReal" using pair_Mreal F by auto
        thus ?thesis using bexI[of _ "[{},r]" MReal] real_0_th_9[of r] F by mty auto
      next case False
        then obtain k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>"  and 
          A1:"k\<noteq>{} & r = [{},k]" using real_0_th_7[of r] by mty auto
       thus ?thesis using bexI[of _ "k" MReal] real_0_th_9[of k] F by mty auto
    qed
  qed
  fix r1 r2 assume [ty]: "r1 is MReal" "r2 is MReal" and
  A1:"r1 +\<^sub>\<S>\<^sup>\<real> r = {}" "r2 +\<^sub>\<S>\<^sup>\<real> r = {}"
  have "r1 = r1 +\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> r2)" using  A1 real_0_th_8 real_0_th_11 by auto
  hence "r1 =  (r1 +\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> r2" using real_0_th_15 by auto
  then show "r1 = r2" using real_0_th_8[of r2] A1(1) by auto 
qed mauto

mtheorem real_0_th_17:
  "k<>{} implies (-\<^sub>\<S>\<^sup>\<real> k) = [{},k] & (-\<^sub>\<S>\<^sup>\<real> [{},k]) = k"
proof(intro impI conjI)
  assume K: "k<>{}"
  hence [ty]: "[{},k] is MReal" using pair_Mreal by auto
  have A1: "[{},k] +\<^sub>\<S>\<^sup>\<real> k = {}" "k +\<^sub>\<S>\<^sup>\<real> [{},k] = {}" using K real_0_th_9 by auto
  then show "(-\<^sub>\<S>\<^sup>\<real> k) = [{},k]" "(-\<^sub>\<S>\<^sup>\<real> [{},k]) = k "using real_0_def_5_uniq[of k "[{},k]"] 
    real_0_def_5_uniq[of "[{},k]" k] by mty auto  
qed

mtheorem real_0_th_18:
 "-\<^sub>\<S>\<^sup>\<real> {} = {}"
proof-
  have "{} +\<^sub>\<S>\<^sup>\<real> {} = {}" using real_0_th_8 by mty auto
  then show "-\<^sub>\<S>\<^sup>\<real> {} = {}" using real_0_def_5_uniq[of "{}" "{}"] by mty auto  
qed

mtheorem real_0_th_19:
  "-\<^sub>\<S>\<^sup>\<real> k is Element-of REAL\<^bsup>\<ge>0\<^bsub> implies k={} \<and> -\<^sub>\<S>\<^sup>\<real> k={}"
proof
  assume A: "-\<^sub>\<S>\<^sup>\<real> k is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  have  "k={}"
  proof(rule ccontr)
    assume K: "k<>{}"
    hence "(-\<^sub>\<S>\<^sup>\<real> k) = [{},k]" using real_0_th_17 by mauto
    thus False using arytm_2_th_33d K A by mauto
  qed
  thus "k={} \<and> -\<^sub>\<S>\<^sup>\<real> k={}" using real_0_th_18 by mauto
qed

mtheorem real_0_th_20a:
 "-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = r"
proof(cases "not r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case True
    then obtain k where [ty]:"k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
       A1: "k<>{} & r = [{},k]" using real_0_th_7[of r] by mty auto 
    then show "-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = r" using real_0_th_17[of k] by auto
  next
    case [ty]: False
    show "-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = r"
    proof(cases "r={}")
      case True 
      thus ?thesis using real_0_th_18 by auto
    next
      case False 
         then show "-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) = r" using real_0_th_17[of r] by auto 
    qed
  qed


mtheorem real_0_th_20:
  "-\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> s) = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)"
proof-
  have "((-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)) +\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> s) = 
           (((-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)) +\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> r "  
    using real_0_th_15[of r s "(-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)"]real_0_th_11[of r s] by mauto
  also have "... = ((-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> s)) +\<^sub>\<S>\<^sup>\<real> r" using 
    real_0_th_15[of s  "-\<^sub>\<S>\<^sup>\<real> s"] by mauto
  also have "... = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> r" using real_0_def_5[of s] real_0_th_8[of "-\<^sub>\<S>\<^sup>\<real> r"] by mauto
  also have "... = {}" using real_0_def_5[of r] by mauto 
  finally show ?thesis using real_0_def_5_uniq[of "r +\<^sub>\<S>\<^sup>\<real> s" "(-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)"] by mauto
qed

mtheorem
  mlet "r be non Element-of REAL\<^bsup>\<ge>0\<^bsub>\<bar>MReal"
  "cluster  -\<^sub>\<S>\<^sup>\<real> r \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub>"
proof
  obtain k where [ty]: "k be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A1: "k<>{} & r = [{},k]" using real_0_th_7[of r] by mty auto
  hence "(-\<^sub>\<S>\<^sup>\<real> [{},k]) = k" using real_0_th_17 by auto
  then show "-\<^sub>\<S>\<^sup>\<real> r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 by mty auto 
qed

mdef real_0_def_7 ("_ *\<^sub>\<S>\<^sup>\<real> _" [100,101] 100) where
  mlet "r be MReal","s be MReal"
  "func r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> MReal means
      \<lambda>it . (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = it  if r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & s is  Element-of REAL\<^bsup>\<ge>0\<^bsub>,  
      \<lambda>it . -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = it  if not r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & s is  Element-of REAL\<^bsup>\<ge>0\<^bsub>,
      \<lambda>it . -\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) = it if r is Element-of REAL\<^bsup>\<ge>0\<^bsub> & not s is  Element-of REAL\<^bsup>\<ge>0\<^bsub> otherwise
      \<lambda>it . (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s) =it "
proof-
  show "(r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<longrightarrow> (\<exists>x : MReal. (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = x)) \<and>
    (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<longrightarrow> (\<exists>x : MReal. -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = x)) \<and>
    (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<longrightarrow> (\<exists>x : MReal. -\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) = x)) \<and>
    (\<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) 
\<and> \<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<longrightarrow> (\<exists>x : MReal. (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s) = x))"
  proof(intro impI conjI)  
    assume [ty]: "r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    show "\<exists>x : MReal. r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = x" using bexI[of _ "r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" MReal] by mty auto
  next
    assume [ty]: "\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    show "\<exists>x : MReal. -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = x" using bexI[of _ "-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)" MReal ] by mty auto
  next
    assume [ty]: " r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    show "\<exists>x : MReal. -\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) = x" using bexI[of _ "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s))" MReal ] by mty auto
  next 
    assume "\<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>)"
    hence [ty]: "\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by auto
     show "\<exists>x : MReal. (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s) = x" using bexI[of _ "(-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" MReal] by mty auto
   qed
   fix x y assume [ty]: "x be MReal" "y be MReal"
   show "((r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = x \<and> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = y \<longrightarrow> x = y) \<and>
               ((\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = x \<and> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)) = y \<longrightarrow> x = y) \<and>
           ((r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> (-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s))) = x \<and> (-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s))) = y \<longrightarrow> x = y) \<and>
           (\<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and>
            \<not> (\<not> r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (r be Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> \<not> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>) \<and> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) = x \<and> 
((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) = y \<longrightarrow>
            x = y)" by blast
 qed mauto  

mtheorem real_0_th_21:
 "r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case T1[ty]: True
  show"r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r"
    proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case T2[ty]: True
      hence "r*\<^sub>\<S>\<^sup>\<real> s = r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" "s*\<^sub>\<S>\<^sup>\<real> r = s*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using real_0_def_7 by mty auto
      then show "r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r" using arytm_2_def_9_c by auto
    next
      case F2[ty]:False
          hence "s*\<^sub>\<S>\<^sup>\<real> r = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> s)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r)" "r*\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s))" using 
           real_0_def_7[of s r,simplified] real_0_def_7[of r s,simplified] by mty auto
         then show "r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r" using arytm_2_def_9_c by mty auto
    qed
  next
    case F1[ty]: False
        show"r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r"
        proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
          case T2[ty]:True
            hence "s*\<^sub>\<S>\<^sup>\<real> r = -\<^sub>\<S>\<^sup>\<real> (s*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r))" "r*\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)" using 
            real_0_def_7[of s r,simplified] real_0_def_7[of r s,simplified] by mty auto
            then show "r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r" using arytm_2_def_9_c by mty auto
          next
            case F2[ty]:False
               have "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" "s *\<^sub>\<S>\<^sup>\<real> r =  (-\<^sub>\<S>\<^sup>\<real> s)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r)" using 
               real_0_def_7[of r s, simplified] real_0_def_7[of s r, simplified]   by mty auto
              then show "r *\<^sub>\<S>\<^sup>\<real> s = s *\<^sub>\<S>\<^sup>\<real> r" using arytm_2_def_9_c[of "-\<^sub>\<S>\<^sup>\<real> s" "-\<^sub>\<S>\<^sup>\<real> r"] by mauto
    qed
  qed

mtheorem real_0_th_22:
  "r *\<^sub>\<S>\<^sup>\<real> {} = {} \<and> {} *\<^sub>\<S>\<^sup>\<real> r = {}"
proof(cases "r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]:True
  hence "r *\<^sub>\<S>\<^sup>\<real> {} = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {})" 
        "{} *\<^sub>\<S>\<^sup>\<real> r = -\<^sub>\<S>\<^sup>\<real> ({}*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r))" using real_0_def_7[of r "{}"] 
    real_0_def_7[of "{}" r] by mauto
  hence "r *\<^sub>\<S>\<^sup>\<real> {} = -\<^sub>\<S>\<^sup>\<real> {}" "{} *\<^sub>\<S>\<^sup>\<real> r = -\<^sub>\<S>\<^sup>\<real> {}"
    using arytm_2_th_4[of "-\<^sub>\<S>\<^sup>\<real> r"]  
      arytm_2_def_9_c[of "-\<^sub>\<S>\<^sup>\<real> r" "{}"] by mty auto
  thus "r *\<^sub>\<S>\<^sup>\<real> {} = {} \<and> {} *\<^sub>\<S>\<^sup>\<real> r = {}" using real_0_th_18 by mauto
next
  case [ty]: False
    hence "r *\<^sub>\<S>\<^sup>\<real> {} = r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {} " 
        "{} *\<^sub>\<S>\<^sup>\<real> r = {}*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using real_0_def_7[of r "{}"] 
       real_0_def_7[of "{}" r] by mauto
    thus "r *\<^sub>\<S>\<^sup>\<real> {} = {} \<and> {} *\<^sub>\<S>\<^sup>\<real> r = {}" 
       using arytm_2_th_4[of r] arytm_2_def_9_c[of r] by mauto
  qed   

mtheorem 
 mlet "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>", "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
 "cluster r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
proof
  have "r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" using real_0_def_7 by mauto
  thus "r *\<^sub>\<S>\<^sup>\<real> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
qed

mtheorem 
  mlet "r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>\<bar>MReal", "s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>\<bar>MReal"
  "cluster r *\<^sub>\<S>\<^sup>\<real> s \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
proof
  have "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" using real_0_def_7 by mauto
  thus "r *\<^sub>\<S>\<^sup>\<real> s be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
qed

mtheorem real_0_th_23:
  "r <>{} \<Longrightarrow>
     r is Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow>
     s is non Element-of REAL\<^bsup>\<ge>0\<^bsub> \<Longrightarrow>
    r *\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s *\<^sub>\<S>\<^sup>\<real> r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>"
proof-
  assume R: "r <>{}" and
     T[ty]: "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  have RS: "r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s) <>{}"
  proof
    assume "r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s) ={}"
    hence "-\<^sub>\<S>\<^sup>\<real> s = {}" using arytm_2_lm_40[of _ r] R by mty auto
    hence "s = {}" "{} is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_th_20a[of s] real_0_th_18 by mauto
    thus False using T by mauto
  qed
  hence "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) = [{},r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)]" using real_0_th_17 by mauto 
  hence "-\<^sub>\<S>\<^sup>\<real> (r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using RS arytm_2_th_33d by mauto 
  hence "r *\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_7 by mauto
  thus "r *\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub> \<and> s *\<^sub>\<S>\<^sup>\<real> r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
    using real_0_th_21[of r s] by mauto
  
qed

mtheorem real_0_th_24:
  "n \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m implies (m --R n) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = (m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)--R (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)"
proof
  assume T: "n \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m"
  hence "(m --R n) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n = m" and 
     [ty]: "m --R n is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_1[of m n] by mauto
  hence T1: "((m --R n)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)  +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) = m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k" using arytm_2_th_13s[of k n "m --R n"] by mauto
  have N1: "n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k" using T arytm_2_th_82[of k m n] by mauto
  hence "((m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)--R (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) = (m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)" and
    [ty]:"(m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)--R (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
    using real_0_def_1[of "m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k" "n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k"] by mauto
  hence "(n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ((m --R n)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) = (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ((m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)--R (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k))"
    using T1 arytm_2_def_8c by mty auto  
  thus "(m --R n)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k = (m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)--R (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)" using 
    arytm_2_th_11[of "(m *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)--R (n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k)"  "(m --R n)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k" "n *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k"]  by mty auto
qed


mdef real_0_def_8 ("_ \<le>\<^sup>\<real> _ " [41,40]40) where
  mlet "r be MReal", "s be MReal"
  "pred r \<le>\<^sup>\<real> s means
      ex z be Element-of REAL\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^sup>\<real> z"..

abbreviation lessQ ("_ <\<^sup>\<real> _" [51,50] 50) where
  "s <\<^sup>\<real> r \<equiv> \<not> r \<le>\<^sup>\<real> s"
                              
mtheorem real_0_th_29:
  "k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2 iff k1 \<le>\<^sup>\<real> k2"
proof
  assume "k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2"
  then obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    "k2 = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_2_th_9 by mauto
  hence "k2 = k1 +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_4 by mauto
  thus "k1 \<le>\<^sup>\<real> k2" using real_0_def_8I[of k1 k2] bexI[of _ z] by mauto
next
  assume "k1 \<le>\<^sup>\<real> k2"
  then obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    "k2 = k1 +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8 by mauto
  hence "k2 = k1 +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using real_0_def_4 by mauto
  thus "k1 \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> k2" using arytm_2_th_19[of k1 z k2] arytm_2_def_8c[of k1 z] by mauto
qed

mtheorem real_0_th_30:
  "r \<le>\<^sup>\<real> s iff (-\<^sub>\<S>\<^sup>\<real> s) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)"
proof
  assume "r \<le>\<^sup>\<real> s"
  then obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    "s = r +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8 by mauto
  hence "-\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> z)" using real_0_th_20[of z r] by mauto
  hence "(-\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> z = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> z) +\<^sub>\<S>\<^sup>\<real> z)" using real_0_th_15[of z] by mauto
  also have "... =  (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> {}" using real_0_def_5[of z] by mauto
  also have "... =  (-\<^sub>\<S>\<^sup>\<real> r)" using real_0_th_8[of "-\<^sub>\<S>\<^sup>\<real> r"]  by mauto
  finally show "(-\<^sub>\<S>\<^sup>\<real> s) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)" 
    using real_0_def_8I[of "-\<^sub>\<S>\<^sup>\<real> s" "-\<^sub>\<S>\<^sup>\<real> r"] bexI[of _ z]by mauto
next 
  assume "(-\<^sub>\<S>\<^sup>\<real> s) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)" 
  then obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    "(-\<^sub>\<S>\<^sup>\<real> r) = (-\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8[of "-\<^sub>\<S>\<^sup>\<real> s"] by mauto
  hence "r = s +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> z)" 
     using real_0_th_20[of z "-\<^sub>\<S>\<^sup>\<real> s"] real_0_th_20a[of r] real_0_th_20a[of s] by mauto
  hence "r +\<^sub>\<S>\<^sup>\<real> z = (s) +\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> z) +\<^sub>\<S>\<^sup>\<real> z)" using real_0_th_15[of z] by mauto
  also have "... =  s +\<^sub>\<S>\<^sup>\<real> {}" using real_0_def_5[of z] by mauto
  also have "... =  s" using real_0_th_8[of "s"] by mauto
  finally  show "r \<le>\<^sup>\<real> s" using real_0_def_8I[of r s] bexI[of _ z] by mauto
qed

mtheorem real_0_def_8c:
  "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]: True
  show "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r"
    proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
      have  "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s or s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_2_def_5c[of r s] by mauto
      thus "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r" using real_0_th_29 by mauto
    next 
      case [ty]:False
      have "s +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s) ={}" using real_0_def_5 real_0_th_11[of s "-\<^sub>\<S>\<^sup>\<real> s"] by mauto
      hence "r = (s +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)) +\<^sub>\<S>\<^sup>\<real> r" using real_0_th_8 by mauto
      also have "... = s +\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> r)" using real_0_th_15[ of r "-\<^sub>\<S>\<^sup>\<real> s" s] by mauto
      finally show "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r" using real_0_def_8I[of s r] bexI[of _ "(-\<^sub>\<S>\<^sup>\<real> s) +\<^sub>\<S>\<^sup>\<real> r"] 
        by mauto
    qed
  next
   case [ty]:False
   show "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r"
      proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
         have "r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r) ={}" using real_0_def_5 real_0_th_11[of r "-\<^sub>\<S>\<^sup>\<real> r"] by mauto
        hence "s = (r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)) +\<^sub>\<S>\<^sup>\<real> s" using real_0_th_8 by mauto
        also have "... = r +\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> s)" 
          using real_0_th_15[ of s "-\<^sub>\<S>\<^sup>\<real> r" r] by mauto
        finally show "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r" 
          using real_0_def_8I[of r s] bexI[of _ "(-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> s"] 
          by mauto
      next 
        case [ty]:False
        have  "(-\<^sub>\<S>\<^sup>\<real> r) \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s) or (-\<^sub>\<S>\<^sup>\<real> s) \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r)" 
          using arytm_2_def_5c[of "-\<^sub>\<S>\<^sup>\<real> r" "-\<^sub>\<S>\<^sup>\<real> s"] by mauto
        hence  "(-\<^sub>\<S>\<^sup>\<real> r) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s) or (-\<^sub>\<S>\<^sup>\<real> s) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)" 
          using  real_0_th_29[of "-\<^sub>\<S>\<^sup>\<real> s" "-\<^sub>\<S>\<^sup>\<real> r"] real_0_th_29[of "-\<^sub>\<S>\<^sup>\<real> r" "-\<^sub>\<S>\<^sup>\<real> s"] 
          by mauto
      thus "r \<le>\<^sup>\<real> s or s \<le>\<^sup>\<real> r" using real_0_th_30 by mauto
    qed      
 qed

mtheorem real_0_def_8r:
  "r \<le>\<^sup>\<real> r"
proof
  have "r +\<^sub>\<S>\<^sup>\<real> {} =r" using real_0_th_8 by mauto 
  thus "\<exists>z : Element-of REAL\<^bsup>\<ge>0\<^bsub>. r =\<^sub>\<S> r +\<^sub>\<S>\<^sup>\<real> z" using bexI[of _ "{}"] by mauto
qed mauto

mtheorem real_0_def_8s:
  "r \<le>\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> r implies s=r"
proof
  assume  AS: "r \<le>\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> r"
  then obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A1: "r =s +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8E[of s r] by mauto
  then obtain w where [ty]: "w be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A2: "s =r +\<^sub>\<S>\<^sup>\<real> w" using real_0_def_8E[of r s] AS by mauto
  hence "r +\<^sub>\<S>\<^sup>\<real> {} = r +\<^sub>\<S>\<^sup>\<real> (w+\<^sub>\<S>\<^sup>\<real> z)" using A1 real_0_th_15[of z w r] real_0_th_8[of r]by mauto
  hence "{} = w+\<^sub>\<S>\<^sup>\<real> z" using real_0_th_16[of "w +\<^sub>\<S>\<^sup>\<real> z" "{}" r] by mauto
  hence "{} = w +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using  real_0_def_4[of w z] by mauto
  hence "w={}" using arytm_2_th_5 by mauto
  thus "s=r" using A2 real_0_th_8 by mauto
qed

mtheorem real_0_def_8t:
  "r \<le>\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t implies r \<le>\<^sup>\<real> t"
proof
  assume AS: "r \<le>\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t"
  then obtain rs where [ty]:"rs  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     rs: "s = r +\<^sub>\<S>\<^sup>\<real> rs" using real_0_def_8 by mty auto
  obtain ST where [ty]:"ST  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     st: "t = s +\<^sub>\<S>\<^sup>\<real> ST" using AS real_0_def_8 by mty auto
  have "t = r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real> ST)" using rs st real_0_th_15 by mty auto
  thus "r \<le>\<^sup>\<real> t" using bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> ST"] real_0_def_8[of r t] by mty auto
qed

mtheorem real_0_th_33:
  "s <\<^sup>\<real> r iff s \<le>\<^sup>\<real> r & r <>s"
proof
  assume AS: "s <\<^sup>\<real> r"
  thus "s \<le>\<^sup>\<real> r & r <>s" using real_0_def_8c[of r s] real_0_def_8r AS by mauto
next
  assume AS: "s \<le>\<^sup>\<real> r & r <>s"
  thus "s <\<^sup>\<real> r"  using real_0_def_8s[of r s] by mauto 
qed


mtheorem real_0_R:
  "{} \<le>\<^sup>\<real> r iff r is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
proof
  assume "{} \<le>\<^sup>\<real> r"
  then obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    "r = {} +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8E[of "{}" r] by mauto
  hence "r=z" using real_0_th_8[of z,simplified] by mauto
  thus "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mauto
next
  assume [ty]:"r is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  have "r={} +\<^sub>\<S>\<^sup>\<real> r" using real_0_th_8 by mauto
  thus "{} \<le>\<^sup>\<real> r" using real_0_def_8I[of "{}" r] bexI[of _ r] by mauto
qed


mtheorem real_0_th_25:
  "-\<^sub>\<S>\<^sup>\<real> (m--R n)  = n --R m"
proof(cases " n = m")
  case T: True
  hence "m +\<^sub>\<S>\<^sup>\<real> {} =n"  using real_0_th_8[of m] by mty auto
  hence "m +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {} =n"  using real_0_def_4 by mty auto
  hence "n --R m ={}"  using real_0_th_1[of n "{}" m] by mauto
  thus "-\<^sub>\<S>\<^sup>\<real> (m--R n)  = n --R m" using real_0_th_18 T by auto
next
  case F: False
  show "-\<^sub>\<S>\<^sup>\<real> (m--R n)  = n --R m"
  proof(cases "n \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m")
    case T:True
    hence  [ty]:"m--Rn is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
       A1: "(m--R n)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n=m" "n <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m"
        using T F real_0_def_1 arytm_2_th_68 by mty auto
      hence "n--R m = [{},m--R n]" "m--R n <>{} "
        using real_0_def_1[of n m] F arytm_2_def_8[of n] arytm_2_def_8c[of "m--R n" n]
        T by mty auto
      thus "-\<^sub>\<S>\<^sup>\<real> (m--R n)  = n --R m" using A1 real_0_th_17 by mauto
    next 
      case T:False
      hence "m \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_2_th_68 by mauto
      hence A1: "(n--R m)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m=n" and [ty]:"n--Rm is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
        using T F real_0_def_1 arytm_2_th_68 by mauto
      hence "m--R n = [{},n--R m]" "n--R m <>{} " 
        using T real_0_def_1[of m n] F arytm_2_def_8[of m] arytm_2_def_8c[of "n--R m" m]
        by mty auto
      thus "-\<^sub>\<S>\<^sup>\<real> (m--R n)  = n --R m" using A1 real_0_th_17 by mauto
  qed
qed

mtheorem real_0_th_26:
  "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
proof(cases "r={} or s={} or t={}")
  case T:True
    hence H: "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t ={}" "r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) ={}"
     using real_0_th_22[of r] real_0_th_22[of s] 
       real_0_th_22[of "r *\<^sub>\<S>\<^sup>\<real> s"] real_0_th_22[of "s *\<^sub>\<S>\<^sup>\<real> t"] real_0_th_22[of t] by mauto
   thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" by simp
 next
   case F:False
   show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
   proof (cases "r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
     case [ty]:True
       show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
         proof (cases "s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
           case [ty]:True
             show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
               proof (cases "t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
                 case [ty]:True
                 have "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" using real_0_def_7 by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> (((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ((-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))" 
                    using arytm_2_th_12[of "-\<^sub>\<S>\<^sup>\<real> t" "-\<^sub>\<S>\<^sup>\<real> s"] by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (s *\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_def_7  by mauto
                  thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                    by mauto
                next case [ty]: False
                  hence [ty]:"s *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F real_0_th_23 by mauto
                     have "r *\<^sub>\<S>\<^sup>\<real> s = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" using real_0_def_7 by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t" 
                    using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ((-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
                    using  arytm_2_th_12[of t "-\<^sub>\<S>\<^sup>\<real> s"] by mauto
                 hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ( -\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)))" 
                    using real_0_th_20a [of "(-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t"] by mauto
                 hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ( -\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_def_7 [of s  t] by mauto
                     thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                       by mauto
               qed
           next 
             case [ty]:False
                   hence [ty]:"r *\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
                     using F real_0_th_23 by mauto
                   have RS: "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  s)" using real_0_def_7 by mauto                
               show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
               proof (cases "t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
                 case [ty]:True
                 hence [ty]:"s *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>"using F real_0_th_23 by mauto                  
                   have "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)" 
                    using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mty auto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  s))) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)" 
                    using RS by auto
                 hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_th_20a[of"(-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  s"] arytm_2_th_12[of "-\<^sub>\<S>\<^sup>\<real> t" s] by mauto
                 hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))))" 
                    using real_0_th_20a[of"s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)"]  by mauto
                 hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  (-\<^sub>\<S>\<^sup>\<real>(s *\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_def_7[of s t ] by mauto                                
                  thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                    by mauto
                next case [ty]: False
                    have "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
                      using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mauto
                    hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>(((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
                      using RS real_0_th_20a[of "(-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  s"] by mauto
                    hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ( s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))" 
                      using arytm_2_th_12[of t s] by mauto
                    hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (s *\<^sub>\<S>\<^sup>\<real> t))" 
                      using real_0_def_7[of s t] by mauto
                    thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                       by mauto                
                   qed
         qed
       next 
         case [ty]:False                  
           show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
         proof (cases "s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
           case [ty]:True
             hence [ty]:"r *\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F real_0_th_23 by mauto          
             have RS: "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real>( r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s))" using real_0_def_7 by mauto
             show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
               proof (cases "t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
                 case [ty]:True
                  have "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)" 
                    using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ((-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_th_20a[of "r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)"] RS  arytm_2_th_12[of "-\<^sub>\<S>\<^sup>\<real> t" "-\<^sub>\<S>\<^sup>\<real> s" r]
                       by mauto
                  thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                    real_0_def_7[of s t] by mauto
                next
                  case [ty]:False
                    hence [ty]:"s *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F real_0_th_23 by mauto                     
                    have "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
                      using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mauto
                    hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>( r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))))"
                      using real_0_th_20a[of "r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)"] 
                       real_0_th_20a[of "(-\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t"] RS  arytm_2_th_12[of t "-\<^sub>\<S>\<^sup>\<real> s" r] by mauto
                    hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>( r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real>(s *\<^sub>\<S>\<^sup>\<real> t)))"
                      using real_0_def_7[of s t] by mauto
                    thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                      by mauto
                  qed
          next
            case [ty]:False
               hence RS:"r *\<^sub>\<S>\<^sup>\<real> s = r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" using real_0_def_7 by mauto
               show "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
               proof (cases "t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
                 case [ty]:True
                  hence [ty]:"s *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F real_0_th_23 by mauto                     
                  have "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> ((r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
                    using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))" 
                    using real_0_th_20a[of "s*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)"] RS  arytm_2_th_12[of "-\<^sub>\<S>\<^sup>\<real> t"  s r]
                       by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>(s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))))" 
                    using real_0_th_20a[of "s*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)"] 
                       by mauto
                  thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                    real_0_def_7[of s t] by mauto
                next
                  case [ty]:False
                    have "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = ((r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
                    using real_0_def_7[of "r *\<^sub>\<S>\<^sup>\<real> s" t] RS by mauto
                  hence "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (s *\<^sub>\<S>\<^sup>\<real>  t)" 
                    using  arytm_2_th_12[of t s r] real_0_def_7[of s t] by mauto
                      thus "(r *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = r *\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_def_7[of r "s *\<^sub>\<S>\<^sup>\<real> t"] 
                    real_0_def_7[of s t] by mauto
                qed
           qed 
       qed
qed

mtheorem real_0_th_28:
  "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
proof(cases "t ={}")
  case True
  hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = {}" 
       "r *\<^sub>\<S>\<^sup>\<real> t ={}" "s *\<^sub>\<S>\<^sup>\<real> t ={}" using real_0_th_22[of "r +\<^sub>\<S>\<^sup>\<real> s"]  real_0_th_22[of r]  real_0_th_22[of s]by mauto
  thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_th_8[of "{}"] by mauto
next
  case F:False
  show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
proof(cases "t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]:True     
  then obtain T where [ty]: "T be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
      T1:"T\<noteq>{} & t = [{},T]" using real_0_th_7 by mauto
  hence T2: "-\<^sub>\<S>\<^sup>\<real> t = T" using real_0_th_17 by mauto
  show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
  proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True   
      show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
      proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
        case [ty]:True
           have RS: "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" using real_0_def_4 by mauto
           hence [ty]:"r +\<^sub>\<S>\<^sup>\<real> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mauto
           have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
             using RS real_0_def_7[of "r +\<^sub>\<S>\<^sup>\<real> s" t] by mauto
           also have "... = -\<^sub>\<S>\<^sup>\<real>((r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))" 
             using arytm_2_th_13s[of "-\<^sub>\<S>\<^sup>\<real> t" s r] by mauto
           also have "... = -\<^sub>\<S>\<^sup>\<real>((r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))+\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))" 
             using real_0_def_4[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)"] by mauto
           also have "... = (-\<^sub>\<S>\<^sup>\<real>(r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))+\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))"
             using real_0_th_20[of "s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)" "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)"] by mauto
          also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)))"
             using real_0_def_7[of r t] by mauto
          also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real>(s *\<^sub>\<S>\<^sup>\<real> t)"
            using real_0_def_7[of s t] by mauto
          finally show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" by mauto
        next
          case [ty]:False
          then   obtain S where [ty]:"S be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
             S: "S\<noteq>{} & s = [{},S]" using real_0_th_7 by mauto
          hence RS: "r +\<^sub>\<S>\<^sup>\<real> s = r --R S" using real_0_def_4[of r s,simplified] S by mauto
          have S2: "-\<^sub>\<S>\<^sup>\<real> s = S" using S real_0_th_17 by mauto
          have S1: "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using arytm_2_th_68 real_0_R S real_0_th_29[of S "{}"] by mty auto
          have P1:"r *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> ( r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T)" using real_0_def_7[of r t] T2 by mauto
          have P2: "s *\<^sub>\<S>\<^sup>\<real> t =  S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T" using real_0_def_7[of s t] S2 T2 by mauto                 
         show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
          proof(cases "S \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r")
            case T: True
            hence [ty]: "r --R S is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_1 by mauto
            have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>( (r --R S) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T)" 
              using RS real_0_def_7[of "r --R S" t] T2 by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>( (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T))" 
              using real_0_th_24[of T r S] T by mauto
            hence A: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T)" 
              using real_0_th_25 by mauto
            have "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using S1 T arytm_2_th_69[of r "{}" S] by mauto
            hence R: "r<>{}" using arytm_2_th_68 by mty auto
            hence [ty]: "r *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>"
                       using real_0_th_23[of t r] F by mauto
            have "r*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>T<>{}" using R T1 arytm_2_lm_40[of T r] by mauto
            hence rT1: "-\<^sub>\<S>\<^sup>\<real> ( r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) = [{},r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T]" using real_0_th_17[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T"] by mauto          
            have "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T)" 
              using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] rT1 P1 P2 by mauto
            thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using A by auto
          next
            case F: False
            hence F1: "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using arytm_2_th_68 by mauto 
             have  [ty]: "r --R S is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F real_0_th_4 by mauto
             have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> (r --R S)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T" 
              using RS real_0_def_7[of "r --R S" t] T2 by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (S --R r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T" 
              using real_0_th_25[of S r] by mauto
            hence R: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T)" 
              using real_0_th_24[of T S r] F1 by mauto
            show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
            proof(cases "r *\<^sub>\<S>\<^sup>\<real> t is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
              case [ty]:True
              hence "r *\<^sub>\<S>\<^sup>\<real> t = {}" "-\<^sub>\<S>\<^sup>\<real> {} =\<^sub>\<S> {}" using real_0_th_19 P1 real_0_th_18 by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T" "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T={}"
                  using real_0_th_20a[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T"] P2 real_0_th_8[of "s *\<^sub>\<S>\<^sup>\<real> t"] P1 by mauto
              thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using R real_0_th_6 by mauto
            next
              case [ty]:False
              then obtain RT where [ty]: "RT be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              T1:"RT\<noteq>{} & r *\<^sub>\<S>\<^sup>\<real> t = [{},RT]" using real_0_th_7[of "r *\<^sub>\<S>\<^sup>\<real> t"] by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R RT" "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> t) = RT"
                using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] P2 real_0_th_17 
                by mauto
              thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using R P1 real_0_th_20a[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T"]
                  by mauto
            qed
          qed
        qed
       next
      case [ty]: False
        show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
      proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
        case [ty]:True
          then   obtain R where [ty]:"R be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
             R: "R\<noteq>{} & r = [{},R]" using real_0_th_7 by mauto
          hence RS: "r +\<^sub>\<S>\<^sup>\<real> s = s --R R" using real_0_def_4[of r s,simplified] R by mauto
          have S2: "-\<^sub>\<S>\<^sup>\<real> r = R" using R real_0_th_17 by mauto
          have S1: "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> R" using arytm_2_th_68 real_0_R R real_0_th_29[of R "{}"] by mty auto
          have P1:"s *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real> ( s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T)" using real_0_def_7[of s t] T2 by mauto
          have P2: "r *\<^sub>\<S>\<^sup>\<real> t =  R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T" using real_0_def_7[of r t] S2 T2 by mauto          
         show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
          proof(cases "R \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s")
            case T: True
            hence [ty]: "s --R R is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_1 by mauto
            have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>( (s --R R) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T)" 
              using RS real_0_def_7[of "s --R R" t] T2 by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>( (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T))" 
              using real_0_th_24[of T s R] T by mauto
            hence A: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T)" 
              using real_0_th_25 by mauto
            have "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" using S1 T arytm_2_th_69[of s "{}" R] by mauto
            hence S: "s<>{}" using arytm_2_th_68 by mty auto
            hence [ty]: "s *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>"
                       using real_0_th_23[of t s] F by mauto
            have "s*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>T<>{}" using S T1 arytm_2_lm_40[of T s] by mauto
            hence sT1: "-\<^sub>\<S>\<^sup>\<real> ( s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) = [{},s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T]" using real_0_th_17[of "s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T"] by mauto          
            have "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T)" 
              using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] sT1 P1 P2 by mauto
            thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using A by auto
          next
            case F: False
            hence F1: "s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> R" using arytm_2_th_68 by mauto 
             have  [ty]: "s --R R is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F real_0_th_4 by mauto
             have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (-\<^sub>\<S>\<^sup>\<real> (s --R R)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T" 
              using RS real_0_def_7[of "s --R R" t] T2 by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (R --R s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T" 
              using real_0_th_25[of R s] by mauto
            hence R: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  T)" 
              using real_0_th_24[of T R s] F1 by mauto
            show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
            proof(cases "s *\<^sub>\<S>\<^sup>\<real> t is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
              case [ty]:True
              hence "s *\<^sub>\<S>\<^sup>\<real> t = {}" "-\<^sub>\<S>\<^sup>\<real> {} =\<^sub>\<S> {}" using real_0_th_19 P1 real_0_th_18 by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T" "s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T={}"
                  using real_0_th_20a[of "s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T"] P2 real_0_th_8[of "r *\<^sub>\<S>\<^sup>\<real> t"] P1 by mauto
              thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using R real_0_th_6 by mauto
            next
              case [ty]:False
              then obtain ST where [ty]: "ST be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              T1:"ST\<noteq>{} & s *\<^sub>\<S>\<^sup>\<real> t = [{},ST]" using real_0_th_7[of "s *\<^sub>\<S>\<^sup>\<real> t"] by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T) --R ST" "-\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = ST"
                using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] P2 P1 real_0_th_17 
                by mauto
              thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using R P1 real_0_th_20a[of "s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> T"]
                by mauto
            qed
          qed
        next 
          case [ty]:False
            obtain R where [ty]:"R be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              R: "R\<noteq>{} & r = [{},R]" using real_0_th_7 by mauto
            have R1: "-\<^sub>\<S>\<^sup>\<real> r = R" using R real_0_th_17 by mauto
            obtain S where [ty]:"S be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              S: "S\<noteq>{} & s = [{},S]" using real_0_th_7 by mauto
            have S1: "-\<^sub>\<S>\<^sup>\<real> s = S" using S real_0_th_17 by mauto
            have rs: "R+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S<>{}"
              using  R arytm_2_th_5[of S R,simplified] by mauto
            have RS: "r +\<^sub>\<S>\<^sup>\<real> s = [{}, R +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S]"
              using real_0_def_4[of r s,simplified] R S by mauto
            hence [ty]:"r +\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
              using arytm_2_th_33d rs by mauto
            have "-\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> s) = R +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using rs RS real_0_th_17 by mauto           
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (R +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)" 
             using real_0_def_7[of "r +\<^sub>\<S>\<^sup>\<real> s" t] by mauto
           also have "... = (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
             using arytm_2_th_13s[of "-\<^sub>\<S>\<^sup>\<real> t" S R] by mauto
           also have "... = (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))+\<^sub>\<S>\<^sup>\<real> (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
             using real_0_def_4[of "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)" "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t)"] by mauto
           also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real> (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> t))" 
             using  real_0_def_7[of r t] R1 by mauto
           also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real>  t)" 
             using  real_0_def_7[of s t] S1 by mauto           
           finally show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" by mauto
         qed
       qed
     next
       case [ty]:False 
  show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
  proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
    case [ty]:True
      show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
      proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
        case [ty]:True
           have RS: "r +\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" using real_0_def_4[of r s,simplified] by mauto
           hence [ty]:"r +\<^sub>\<S>\<^sup>\<real> s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mauto
           have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t" 
             using RS real_0_def_7[of "r +\<^sub>\<S>\<^sup>\<real> s" t] by mauto
           also have "... = (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" 
             using arytm_2_th_13s[of t s r] by mauto
           also have "... = (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)+\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" 
             using real_0_def_4[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t"] by mauto
             also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
             using real_0_def_7[of r t] by mauto
          also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real>(s *\<^sub>\<S>\<^sup>\<real> t)"
            using real_0_def_7[of s t] by mauto
          finally show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" by mauto
        next
          case [ty]:False
          then   obtain S where [ty]:"S be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
             S: "S\<noteq>{} & s = [{},S]" using real_0_th_7 by mauto
          hence RS: "r +\<^sub>\<S>\<^sup>\<real> s = r --R S" using real_0_def_4[of r s,simplified] S by mauto
          have S2: "-\<^sub>\<S>\<^sup>\<real> s = S" using S real_0_th_17 by mauto
          have S1: "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using arytm_2_th_68 real_0_R S real_0_th_29[of S "{}"] by mty auto
          have P1:"r *\<^sub>\<S>\<^sup>\<real> t =( r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" using real_0_def_7[of r t] by mauto
          have P2: "s *\<^sub>\<S>\<^sup>\<real> t =  -\<^sub>\<S>\<^sup>\<real>(S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" using real_0_def_7[of s t] S2 by mauto                 
          show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
          proof(cases "S \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r")
            case T: True
            hence [ty]: "r --R S is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_1 by mauto
            have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r --R S) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t" 
              using RS real_0_def_7[of "r --R S" t] by mauto
            hence A: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using real_0_th_24[of t r S] T by mauto
            show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
            proof(cases "s *\<^sub>\<S>\<^sup>\<real> t is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
              case [ty]:True
              hence "s *\<^sub>\<S>\<^sup>\<real> t = {}" "-\<^sub>\<S>\<^sup>\<real> {} =\<^sub>\<S> {}" using real_0_th_19 P1 P2 real_0_th_18 by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t" "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t={}"
                  using real_0_th_8[of "r *\<^sub>\<S>\<^sup>\<real> t"] real_0_th_20a[of "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"] P1 P2 by mauto
             thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_th_6 A by mauto
            next
              case [ty]:False
              then obtain ST where [ty]: "ST be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              T1:"ST\<noteq>{} & s *\<^sub>\<S>\<^sup>\<real> t = [{},ST]" using real_0_th_7[of "s *\<^sub>\<S>\<^sup>\<real> t"] by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R ST" "-\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = ST"
                using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] P2 P1 real_0_th_17 
                by mauto
              thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" 
                using P2 P1 A real_0_th_20a[of "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"]
                  by mauto
              qed
         next 
           case F1: False
              hence F2: "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using arytm_2_th_68 by mauto 
             have  [ty]: "r --R S is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F1 real_0_th_4 by mauto
             have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> (r --R S)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using RS real_0_def_7[of "r --R S" t] by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  -\<^sub>\<S>\<^sup>\<real>((S --R r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using real_0_th_25[of S r] by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))" 
              using real_0_th_24[of t S r] F2 by mauto
            hence A: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using real_0_th_25 by mauto
            have "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using S1 F arytm_3_th_70[of S "{}" r] by mauto
            hence R: "S <>{}" using arytm_2_th_68 by mauto
            hence "s <>{}" using S2 real_0_th_20a[of S] real_0_th_18 by mauto
            hence [ty]: "s *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_th_23[of s t,simplified] F by mauto
            have "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t<>{}" using R arytm_2_lm_40[of t S ] F by mauto
            hence rT1: "-\<^sub>\<S>\<^sup>\<real> ( S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) = [{},S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t]" using real_0_th_17[of "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mauto          
            have "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" 
              using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] rT1 P1 P2 by mauto
            thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using A by auto
          qed
        qed   
    next 
      case [ty]:False 
       then   obtain R where [ty]:"R be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
             R: "R\<noteq>{} & r = [{},R]" using real_0_th_7 by mauto
          have R2: "-\<^sub>\<S>\<^sup>\<real> r = R" using R real_0_th_17 by mauto
          have R1: "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> R" using arytm_2_th_68 real_0_R R real_0_th_29[of R "{}"] by mty auto       
        show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
          proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
            case [ty]:True
          hence RS: "r +\<^sub>\<S>\<^sup>\<real> s = s --R R" using real_0_def_4[of r s,simplified] R by mauto
          have P1:"r *\<^sub>\<S>\<^sup>\<real> t =-\<^sub>\<S>\<^sup>\<real>( R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" using R2 real_0_def_7[of r t] by mauto
          have P2: "s *\<^sub>\<S>\<^sup>\<real> t =  s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t" using real_0_def_7[of s t] by mauto                 
          show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
          proof(cases "R \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s")
            case T: True
            hence [ty]: "s --R R is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_def_1 by mauto
            have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (s --R R) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t" 
              using RS real_0_def_7[of "s --R R" t] by mauto
            hence A: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using real_0_th_24[of t s R] T by mauto
            show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)"
            proof(cases "r *\<^sub>\<S>\<^sup>\<real> t is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
              case [ty]:True
              hence "r *\<^sub>\<S>\<^sup>\<real> t = {}" "-\<^sub>\<S>\<^sup>\<real> {} =\<^sub>\<S> {}" using real_0_th_19 P1 P2 real_0_th_18 by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t" "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t={}"
                  using real_0_th_8[of "s *\<^sub>\<S>\<^sup>\<real> t"] real_0_th_20a[of "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"] P1 P2 by mauto
             thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using real_0_th_6 A by mauto
            next
              case [ty]:False
              then obtain RT where [ty]: "RT be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              T1:"RT\<noteq>{} & r *\<^sub>\<S>\<^sup>\<real> t = [{},RT]" using real_0_th_7[of "r *\<^sub>\<S>\<^sup>\<real> t"] by mauto
              hence "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R RT" "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> t) = RT"
                using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] P2 P1 real_0_th_17 
                by mauto
              thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" 
                using P2 P1 A real_0_th_20a[of "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"]
                  by mauto
              qed
         next 
           case F1: False
              hence F2: "s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> R" using arytm_2_th_68 by mauto 
             have  [ty]: "s --R R is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using F1 real_0_th_4 by mauto
             have "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> (s --R R)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using RS real_0_def_7[of "s --R R" t] by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  -\<^sub>\<S>\<^sup>\<real>((R --R s) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using real_0_th_25[of R s] by mauto
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))" 
              using real_0_th_24[of t R s] F2 by mauto
            hence A: "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t =  (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
              using real_0_th_25 by mauto
            have "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> R" using R1 F arytm_3_th_70[of R "{}" s] by mauto
            hence R: "R <>{}" using arytm_2_th_68 by mauto
            hence "r <>{}" using R2 real_0_th_20a[of S] real_0_th_18 by mauto
            hence [ty]: "r *\<^sub>\<S>\<^sup>\<real> t is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_th_23[of r t,simplified] F by mauto
            have "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t<>{}" using R arytm_2_lm_40[of t R ] F by mauto
            hence rT1: "-\<^sub>\<S>\<^sup>\<real> ( R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) = [{},R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t]" using real_0_th_17[of "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mauto          
            have "(r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t) = (s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t) --R (R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)" 
              using real_0_def_4[of "r *\<^sub>\<S>\<^sup>\<real> t" "s *\<^sub>\<S>\<^sup>\<real> t",simplified] rT1 P1 P2 by mauto
            thus "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" using A by auto
          qed
        next
          case [ty]:False
             obtain R where [ty]:"R be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              R: "R\<noteq>{} & r = [{},R]" using real_0_th_7 by mauto
            have R1: "-\<^sub>\<S>\<^sup>\<real> r = R" using R real_0_th_17 by mauto
            obtain S where [ty]:"S be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
              S: "S\<noteq>{} & s = [{},S]" using real_0_th_7 by mauto
            have S1: "-\<^sub>\<S>\<^sup>\<real> s = S" using S real_0_th_17 by mauto
            have rs: "R+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S<>{}"
              using  R arytm_2_th_5[of S R,simplified] 
               by mauto
            have RS: "r +\<^sub>\<S>\<^sup>\<real> s = [{}, R +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S]"
              using real_0_def_4[of r s,simplified] R S by mauto
            hence [ty]:"r +\<^sub>\<S>\<^sup>\<real> s is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
              using arytm_2_th_33d rs by mauto
            have "-\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> s) = R +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S" using rs RS real_0_th_17 by mauto           
            hence "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = -\<^sub>\<S>\<^sup>\<real>((R +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> S) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t)" 
             using real_0_def_7[of "r +\<^sub>\<S>\<^sup>\<real> s" t] by mauto
           also have "... = -\<^sub>\<S>\<^sup>\<real>((R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))" 
             using arytm_2_th_13s[of t S R] by mauto
           also have "... = -\<^sub>\<S>\<^sup>\<real>((R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)+\<^sub>\<S>\<^sup>\<real> (S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))" 
             using real_0_def_4[of "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mauto
           also have "... = (-\<^sub>\<S>\<^sup>\<real>(R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t)) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))"           
           using real_0_th_20[of "S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t" "R *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mauto
           also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real>(S *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  t))" 
             using  real_0_def_7[of r t] R1 by mauto
           also have "... = (r *\<^sub>\<S>\<^sup>\<real>  t)+\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real>  t)" 
             using  real_0_def_7[of s t] S1 by mauto           
           finally show "(r +\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> t = (r *\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> t)" by mauto
         qed
       qed
     qed
   qed

mtheorem real_0_th_28s:
  "t *\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> s) = (t *\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (t *\<^sub>\<S>\<^sup>\<real> s)"
  using real_0_th_28[of t s r,simplified] 
real_0_th_21[of t r,simplified] real_0_th_21[of t s,simplified] 
  real_0_th_21[of t "r +\<^sub>\<S>\<^sup>\<real> s",simplified] by simp

mtheorem real_0_th_40:
  "r *\<^sub>\<S>\<^sup>\<real> {} = {} \<and> {} *\<^sub>\<S>\<^sup>\<real> r = {}"
proof(cases "r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]:True
  hence "r *\<^sub>\<S>\<^sup>\<real> {} = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r)*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {})" 
        "{} *\<^sub>\<S>\<^sup>\<real> r = -\<^sub>\<S>\<^sup>\<real> ({}*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r))" using real_0_def_7[of r "{}",simplified]
    real_0_def_7[of "{}" r,simplified] by mty auto
  hence "r *\<^sub>\<S>\<^sup>\<real> {} = -\<^sub>\<S>\<^sup>\<real> {}" "{} *\<^sub>\<S>\<^sup>\<real> r = -\<^sub>\<S>\<^sup>\<real> {}"
    using arytm_2_th_4[of "-\<^sub>\<S>\<^sup>\<real> r" "{}"] arytm_2_def_9_c[of "-\<^sub>\<S>\<^sup>\<real> r" "{}"] by mauto
  thus "r *\<^sub>\<S>\<^sup>\<real> {} = {} \<and> {} *\<^sub>\<S>\<^sup>\<real> r = {}" using real_0_th_18 by mauto
next
  case [ty]: False
    hence "r *\<^sub>\<S>\<^sup>\<real> {} = r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {} " 
        "{} *\<^sub>\<S>\<^sup>\<real> r = {} *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using real_0_def_7[of r "{}"] 
       real_0_def_7[of "{}" r] by mauto
    thus "r *\<^sub>\<S>\<^sup>\<real> {} = {} \<and> {} *\<^sub>\<S>\<^sup>\<real> r = {}" 
       using arytm_2_def_9_c real_0_th_18 arytm_2_th_4 by mty auto
  qed   

mtheorem real_0_th_41: 
  "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s"
proof(cases "r={}\<or>s={}")
  case True
  hence "r *\<^sub>\<S>\<^sup>\<real> s = {}" "-\<^sub>\<S>\<^sup>\<real> r={} or s={}" using real_0_th_40 real_0_th_18 
real_0_th_21[of "{}"] by mty auto
    hence "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) = {}" "((-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s)={}" using real_0_th_40 real_0_th_18 by auto
    thus "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s" by auto
  next
    case F: False
    show "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s"
    proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
      case [ty]: True
        hence [ty]: "-\<^sub>\<S>\<^sup>\<real> r is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_th_19[of r] F by mauto 
        show "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s"
        proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
          case [ty]: True      
            have  "(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s=-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)" "r *\<^sub>\<S>\<^sup>\<real> s = r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s"
              using real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> r" s,simplified] real_0_def_7[of r s,simplified] by mauto
            thus "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s" using real_0_th_20a by auto
          next
            case [ty]: False
              have  "(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s= r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)" "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s))"
                using real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> r" s,simplified] real_0_def_7[of r s,simplified] 
               real_0_th_20a[of r]by mauto
            thus "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s" using real_0_th_20a[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)"]  by mauto
          qed
        next
          case [ty]:False
            hence [ty]: "-\<^sub>\<S>\<^sup>\<real> r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mauto 
            show "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s"
            proof(cases "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
              case [ty]: True      
                have  "(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s =(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s" "r *\<^sub>\<S>\<^sup>\<real> s = -\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
                using real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> r" s,simplified] real_0_def_7[of r s,simplified] by mauto
              thus "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s" using real_0_th_20a[of "(-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s"]  by mauto
            next 
              case [ty]:False 
                have  "(-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s =-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)) " "r *\<^sub>\<S>\<^sup>\<real> s =  (-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)"
                using real_0_def_7[of "-\<^sub>\<S>\<^sup>\<real> r" s,simplified] real_0_def_7[of r s,simplified] by mauto
              thus "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s" using real_0_th_20a[of "(-\<^sub>\<S>\<^sup>\<real>r) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> s)"] 
                by mauto
            qed
     qed   
   qed

mtheorem real_0_th_42:
  "-\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  (-\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s \<and> 
   -\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) =  r *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)"
  using real_0_th_41[of r s] real_0_th_41[of s r] 
        real_0_th_21[of r s] real_0_th_21[of r "-\<^sub>\<S>\<^sup>\<real> s"] by mauto

mdef real_0_def_6 ( "_ -\<^sub>\<S>\<^sup>\<real> _" 110) where
  mlet "r be MReal","s be MReal"
  "func r -\<^sub>\<S>\<^sup>\<real> s  \<rightarrow> MReal equals
     r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)"
proof -
  show "(r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)) be MReal" by mty auto
qed

mtheorem real_1_th_15:
  "r+\<^sub>\<S>\<^sup>\<real> s = r \<longrightarrow> s={}"
proof
  assume "r+\<^sub>\<S>\<^sup>\<real> s = r"
  hence  "r+\<^sub>\<S>\<^sup>\<real> s = r +\<^sub>\<S>\<^sup>\<real> {}" using real_0_th_8[of r] by mauto
  thus "s ={}" using real_0_th_16[of "{}" s r] by mauto
qed

mtheorem real_1_th_16:
  "r \<le>\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
proof
  assume AS: "r \<le>\<^sup>\<real> s  \<and> t \<le>\<^sup>\<real> w"
 then obtain rs where [ty]:"rs  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     rs: "s = r +\<^sub>\<S>\<^sup>\<real> rs" using real_0_def_8 by mty auto
  obtain tw where [ty]:"tw  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     tw: "w = t +\<^sub>\<S>\<^sup>\<real> tw" using AS real_0_def_8 by mty auto
  have "s+\<^sub>\<S>\<^sup>\<real> w = ((r +\<^sub>\<S>\<^sup>\<real> rs) +\<^sub>\<S>\<^sup>\<real>  t) +\<^sub>\<S>\<^sup>\<real> tw" using rs tw real_0_th_15[of tw t] by mty auto
  also have "...= (r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real>  t)) +\<^sub>\<S>\<^sup>\<real> tw" using  real_0_th_15[of t rs] by mty auto
  also have "... = (r +\<^sub>\<S>\<^sup>\<real> (t +\<^sub>\<S>\<^sup>\<real>  rs)) +\<^sub>\<S>\<^sup>\<real> tw" using  real_0_th_11 by mty auto
  also have "... = ((r +\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real>  rs) +\<^sub>\<S>\<^sup>\<real> tw" using  real_0_th_15 by mty auto
  also have "... = (r +\<^sub>\<S>\<^sup>\<real> t) +\<^sub>\<S>\<^sup>\<real>  (rs +\<^sub>\<S>\<^sup>\<real> tw)" using  real_0_th_15[of tw rs] by mty auto
  finally show "r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_0_def_8I[of "r+\<^sub>\<S>\<^sup>\<real> t" "s+\<^sub>\<S>\<^sup>\<real> w"]
   bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> tw" "Element-of REAL\<^bsup>\<ge>0\<^bsub>",simplified] by mty auto
qed

mtheorem real_0_def_8l:
  " r <\<^sup>\<real> w \<longleftrightarrow> (ex z be Element-of REAL\<^bsup>\<ge>0\<^bsub> st z<>{} & w = r +\<^sub>\<S>\<^sup>\<real> z)"
proof
  assume "r <\<^sup>\<real> w"
  hence r: "r <> w & r \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  then obtain z where [ty]:"z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
   z:  "w = r +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8 by mty auto
  hence "z <>{}" using r real_0_th_8 by mty auto
  thus "ex z be Element-of REAL\<^bsup>\<ge>0\<^bsub> st z<>{} & w = r +\<^sub>\<S>\<^sup>\<real> z" 
    using z bexI[of _ z "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by mty auto
next
  assume  "ex z be Element-of REAL\<^bsup>\<ge>0\<^bsub> st z<>{} & w = r +\<^sub>\<S>\<^sup>\<real> z" 
  then obtain z where [ty]:"z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
   z:  "z <>{} & w = r +\<^sub>\<S>\<^sup>\<real> z" by mty auto
  hence "r \<le>\<^sup>\<real> w" "w<>r" using bexI[of _ z] real_0_def_8 real_1_th_15[of z r] by mty auto
  thus "r <\<^sup>\<real> w" using real_0_th_33 by mty auto
qed

mtheorem real_0_def_8t1:
  "r \<le>\<^sup>\<real> s \<and> s <\<^sup>\<real> t implies r <\<^sup>\<real> t"
proof
  assume AS: "r \<le>\<^sup>\<real> s \<and> s <\<^sup>\<real> t"
  then obtain rs where [ty]:"rs  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     rs: "s = r +\<^sub>\<S>\<^sup>\<real> rs" using real_0_def_8 by mty auto
  obtain ST where [ty]:"ST  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     st: "ST<>{} & t = s +\<^sub>\<S>\<^sup>\<real> ST" using AS real_0_def_8l by mty auto
  have "rs +\<^sub>\<S>\<^sup>\<real> ST = ST +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> rs" using real_0_def_4 real_0_th_11 by mty auto
  hence "t = r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real> ST)" "rs +\<^sub>\<S>\<^sup>\<real> ST <>{}"
       using rs st real_0_th_15 st arytm_2_th_5[of rs ST] by mty auto
  thus "r <\<^sup>\<real> t" using bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> ST"] real_0_def_8l[of r t] by mty auto
qed

mtheorem real_0_def_8t2:
  "r <\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t implies r <\<^sup>\<real> t"
proof
  assume AS: "r <\<^sup>\<real> s \<and> s \<le>\<^sup>\<real> t"
  then obtain rs where [ty]:"rs  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     rs: "rs<>{} & s = r +\<^sub>\<S>\<^sup>\<real> rs" using real_0_def_8l by mty auto
  obtain ST where [ty]:"ST  be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
     st: " t = s +\<^sub>\<S>\<^sup>\<real> ST" using AS real_0_def_8 by mty auto
  have "rs +\<^sub>\<S>\<^sup>\<real> ST = rs +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> ST" using real_0_def_4 real_0_th_11 by mty auto
  hence "t = r +\<^sub>\<S>\<^sup>\<real> (rs +\<^sub>\<S>\<^sup>\<real> ST)" "rs +\<^sub>\<S>\<^sup>\<real> ST <>{}"
       using rs st real_0_th_15 st arytm_2_th_5[of ST] by mty auto
  thus "r <\<^sup>\<real> t" using bexI[of _ "rs +\<^sub>\<S>\<^sup>\<real> ST"] real_0_def_8l[of r t] by mty auto
qed

mtheorem real_1_th_17:
   "r \<le>\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real>  s -\<^sub>\<S>\<^sup>\<real> t"
proof
  assume AS:"r \<le>\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w"
  hence "(-\<^sub>\<S>\<^sup>\<real> w) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> t)" using real_0_th_30 by mty auto
  hence "r+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w) \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> t)" using real_1_th_16 AS by mty auto
  thus "r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real>  s -\<^sub>\<S>\<^sup>\<real> t" using real_0_def_6 by mty auto
qed 



mtheorem real_1_th_18:
  "w -\<^sub>\<S>\<^sup>\<real> w ={}"
proof-
  have "w -\<^sub>\<S>\<^sup>\<real> w = w +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w)" using real_0_def_6 by mty auto
  also have "... =  (-\<^sub>\<S>\<^sup>\<real> w) +\<^sub>\<S>\<^sup>\<real> w" using real_0_th_11 by mty auto
  finally show ?thesis using real_0_def_5 by mty auto 
qed

mtheorem real_1_th_19:
  "(r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w = r" 
proof-
  have "(r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w = (r +\<^sub>\<S>\<^sup>\<real> w) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w)" using real_0_def_6 by mty auto
  also have "... = r +\<^sub>\<S>\<^sup>\<real> (w +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w))" using real_0_th_15 by mty auto
  also have "... = r +\<^sub>\<S>\<^sup>\<real> (w -\<^sub>\<S>\<^sup>\<real> w)" using real_0_def_6 by mty auto
  also have "... = r +\<^sub>\<S>\<^sup>\<real> {}" using real_1_th_18 by mty auto
  finally show ?thesis using real_0_th_8 by mty auto 
qed


mtheorem real_1_th_16l:
  "r <\<^sup>\<real> s \<and> t <\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
proof
  have r: "r \<le>\<^sup>\<real> r" "w \<le>\<^sup>\<real> w" using real_0_def_8r by mty auto
  assume AS: "r <\<^sup>\<real> s  \<and> t <\<^sup>\<real> w"
  hence as: "r \<le>\<^sup>\<real> s" "t \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  hence "r +\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> w" using r real_1_th_16 by mty auto
  hence H1: "(r +\<^sub>\<S>\<^sup>\<real> t) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using r real_1_th_17 by mty auto
  have h1:"r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_1_th_16 as by mty auto  
 have  "r+\<^sub>\<S>\<^sup>\<real> t <>  s+\<^sub>\<S>\<^sup>\<real> w"
  proof
    assume "r+\<^sub>\<S>\<^sup>\<real> t =  s+\<^sub>\<S>\<^sup>\<real> w"
    hence "(s +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using H1 by mty auto
    hence "s \<le>\<^sup>\<real> r" using real_1_th_19 by mty auto
    thus False using AS by mty auto
  qed
  thus "r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_0_th_33[of "r+\<^sub>\<S>\<^sup>\<real> t" "s+\<^sub>\<S>\<^sup>\<real> w"] h1 by mty auto
qed

mtheorem real_1_th_16l2:
  "r <\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
proof
  have r: "r \<le>\<^sup>\<real> r" "w \<le>\<^sup>\<real> w" using real_0_def_8r by mty auto
  assume AS: "r <\<^sup>\<real> s  \<and> t \<le>\<^sup>\<real> w"
  hence as: "r \<le>\<^sup>\<real> s" "t \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  hence "r +\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real> r +\<^sub>\<S>\<^sup>\<real> w" using r real_1_th_16 by mty auto
  hence H1: "(r +\<^sub>\<S>\<^sup>\<real> t) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using r real_1_th_17 by mty auto
  have h1:"r+\<^sub>\<S>\<^sup>\<real> t \<le>\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_1_th_16 as by mty auto  
 have  "r+\<^sub>\<S>\<^sup>\<real> t <>  s+\<^sub>\<S>\<^sup>\<real> w"
  proof
    assume "r+\<^sub>\<S>\<^sup>\<real> t =  s+\<^sub>\<S>\<^sup>\<real> w"
    hence "(s +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w " using H1 by mty auto
    hence "s \<le>\<^sup>\<real> r" using real_1_th_19 by mty auto
    thus False using AS by mty auto
  qed
  thus "r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w" using real_0_th_33[of "r+\<^sub>\<S>\<^sup>\<real> t" "s+\<^sub>\<S>\<^sup>\<real> w"] h1 by mty auto
qed

mtheorem real_1_th_16l1:
  "r \<le>\<^sup>\<real> s \<and> t <\<^sup>\<real> w \<longrightarrow> r+\<^sub>\<S>\<^sup>\<real> t <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> w"
  using real_0_th_11 real_1_th_16l2 by mty auto


mtheorem real_1_th_17l1:
   "r <\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w \<longrightarrow> r -\<^sub>\<S>\<^sup>\<real> w <\<^sup>\<real>  s -\<^sub>\<S>\<^sup>\<real> t"
proof
  assume AS:"r <\<^sup>\<real> s \<and> t \<le>\<^sup>\<real> w"
  hence "(-\<^sub>\<S>\<^sup>\<real> w) \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> t)" using real_0_th_30 by mty auto
  hence "r+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> w) <\<^sup>\<real>  s+\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> t)" using real_1_th_16l2 AS by mty auto
  thus "r -\<^sub>\<S>\<^sup>\<real> w <\<^sup>\<real>  s -\<^sub>\<S>\<^sup>\<real> t" using real_0_def_6 by mty auto
qed 

mtheorem real_1_th_20:
  "r +\<^sub>\<S>\<^sup>\<real> s \<le>\<^sup>\<real> w \<longrightarrow> r \<le>\<^sup>\<real> w -\<^sub>\<S>\<^sup>\<real> s"
proof
  have r: "s \<le>\<^sup>\<real> s" using real_0_def_8r by mty auto
  assume "r +\<^sub>\<S>\<^sup>\<real> s \<le>\<^sup>\<real> w"
  hence "(r +\<^sub>\<S>\<^sup>\<real> s) -\<^sub>\<S>\<^sup>\<real> s \<le>\<^sup>\<real> w -\<^sub>\<S>\<^sup>\<real> s"  using r real_1_th_17 by mty auto 
  thus "r \<le>\<^sup>\<real> w -\<^sub>\<S>\<^sup>\<real> s" using real_1_th_19 by mty auto
qed

mtheorem real_1_th_21:
  "r \<le>\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> w \<longrightarrow> r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s"
proof
  have r: "w \<le>\<^sup>\<real> w" using real_0_def_8r by mty auto
  assume "r \<le>\<^sup>\<real> s +\<^sub>\<S>\<^sup>\<real> w"
  hence "r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (s +\<^sub>\<S>\<^sup>\<real> w) -\<^sub>\<S>\<^sup>\<real> w"  using r real_1_th_17 by mty auto 
  thus "r -\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s" using real_1_th_19 by mty auto
qed

mtheorem real_1_th_22:
 "-\<^sub>\<S>\<^sup>\<real> (r -\<^sub>\<S>\<^sup>\<real> s) = s -\<^sub>\<S>\<^sup>\<real> r"
proof-
  have "-\<^sub>\<S>\<^sup>\<real> (r -\<^sub>\<S>\<^sup>\<real> s) =( -\<^sub>\<S>\<^sup>\<real> (r +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s)))" using real_0_def_6 by mty auto
  also have "... = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> s))" using real_0_th_20 by mty auto
  also have "... = (-\<^sub>\<S>\<^sup>\<real> r) +\<^sub>\<S>\<^sup>\<real> s" using real_0_th_20a by mty auto
  also have "... = s +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> r)" using real_0_th_11 by mty auto
  finally show ?thesis using real_0_def_6 by mty auto
qed

mtheorem real_1_th_23:
  "{} <\<^sup>\<real> r implies (ex s st {} <\<^sup>\<real> s & s +\<^sub>\<S>\<^sup>\<real> s = r)" 
proof(standard,rule bexI[of _ "r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)"],rule conjI)
  assume AS:"{} <\<^sup>\<real> r"
  hence A1: "{}\<le>\<^sup>\<real> r" "r <>{}" using real_0_th_33 by mty auto
  hence [ty]:" r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  show "(r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)) is MReal" by mty auto 

  have "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> /\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>" using arytm_3_TH4 by mty auto
  hence A2:"1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S> <>{}" using  arytm_3_th_68 by mty auto

  have A3:"{} \<le>\<^sup>\<real> r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using real_0_R by mty auto
  have "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) <> {}" using A1 A2 arytm_2_lm_40[of "1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>" r]  by mty auto
  hence "r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) <> {}" using real_0_def_7  by mty auto
  thus "{} <\<^sup>\<real> r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)" using A3 real_0_th_33 by mty auto

  have "(r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)) +\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)) = 
      r *\<^sub>\<S>\<^sup>\<real> ((1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using real_0_th_28s by mty auto
  also have "... = r *\<^sub>\<S>\<^sup>\<real> ((1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using real_0_def_4[of "1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>" "1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>"] 
    by mty auto
  also have "... = r *\<^sub>\<S>\<^sup>\<real> ((1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>))" using Prat_Preal_add by mty auto
  also have "... = r *\<^sub>\<S>\<^sup>\<real> ((1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>)/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) " using arytm_3_th_47 by mty auto
  also have "... = r *\<^sub>\<S>\<^sup>\<real> ((2\<^sub>\<S>)/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) " using Add_5[of "1\<^sub>\<S>"] by mty auto
  also have "... = r *\<^sub>\<S>\<^sup>\<real> (succ {}) " using arytm_3_th_41 by mty auto
  also have "... = r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {}) " using real_0_def_7 by mty auto
  finally show "(r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>)) +\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> (1\<^sub>\<S>/\<^bsub>\<rat>\<ge>0\<^bsup> 2\<^sub>\<S>) ) =r" 
    using arytm_2_th_15 arytm_2_def_9_c by mty auto
qed mauto

mtheorem real_1_th_24:
  "(succ {}) *\<^sub>\<S>\<^sup>\<real> r = r"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]: True
    have "(succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r = r" using arytm_2_th_15 by mty auto
    thus "(succ {}) *\<^sub>\<S>\<^sup>\<real> r = r" using real_0_def_7 by mty auto
  next
    case [ty]:False
    have "(succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r) = (-\<^sub>\<S>\<^sup>\<real> r)" using arytm_2_th_15 by mty auto
    hence "-\<^sub>\<S>\<^sup>\<real>( (succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r)) = r" using real_0_th_20a[of r] by mty auto
    hence "-\<^sub>\<S>\<^sup>\<real>( (succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> r)) = r" using real_0_th_20a[of r] by mty auto
    thus " (succ {}) *\<^sub>\<S>\<^sup>\<real> r = r" using real_0_def_7[of _ r] by mty auto
qed

theorem div_ex:
  assumes [ty]: "x be MReal" "y be MReal" and Y: "y<>{}"
shows "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x"
  proof(cases "x is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
    case [ty]: True
       show "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x"
       proof(cases "y is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
         case [ty]:True  
         obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
           z: "y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = 1\<^sub>\<S>" using Y arytm_2_th_14[of y] by mty auto
         hence "z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = 1\<^sub>\<S>" using arytm_2_def_9_c by mty auto
         hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) = x" using arytm_2_th_15[of x] arytm_2_def_9_c[of x] by mty auto
         hence "(x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = x" using arytm_2_th_12[of y z x]  by mty auto
         hence "(x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^sup>\<real> y = x" using real_0_def_7[of "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" y]  by mty auto
         thus "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x" using bexI[of _ "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" MReal] by mty auto
       next
         case [ty]: False   
           have Y1:  "-\<^sub>\<S>\<^sup>\<real> y <>{}" using real_0_th_18 real_0_th_20a[of y] Y by mty auto
           obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
           z: "(-\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = 1\<^sub>\<S>" using Y1 arytm_2_th_14[of "-\<^sub>\<S>\<^sup>\<real> y"] by mty auto 
           hence "z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y) = 1\<^sub>\<S>" using arytm_2_def_9_c by mty auto
           hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y)) = x" using arytm_2_th_15[of x] arytm_2_def_9_c[of x] by mty auto
           hence "(x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y) = x" using arytm_2_th_12[of "-\<^sub>\<S>\<^sup>\<real> y" z x]  by mty auto
           hence "-\<^sub>\<S>\<^sup>\<real>(-\<^sub>\<S>\<^sup>\<real>((x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y))) = x" using real_0_th_20a  by mty auto     
           hence "-\<^sub>\<S>\<^sup>\<real>( (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^sup>\<real> y) = x" using real_0_def_7[of "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" y]  by mty auto
           hence "(-\<^sub>\<S>\<^sup>\<real>(x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)) *\<^sub>\<S>\<^sup>\<real> y = x" using real_0_th_42[of y "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"]  by mty auto
          thus "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x" using bexI[of _ "-\<^sub>\<S>\<^sup>\<real>(x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" MReal] by mty auto
        qed
      next 
        case [ty]: False
       show "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x"
       proof(cases "y is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
         case [ty]:True  
             obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
           z: "y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = 1\<^sub>\<S>" using Y arytm_2_th_14[of y] by mty auto
         hence "z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = 1\<^sub>\<S>" using arytm_2_def_9_c by mty auto
         hence "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) = (-\<^sub>\<S>\<^sup>\<real> x)" using arytm_2_th_15[of "-\<^sub>\<S>\<^sup>\<real> x"] arytm_2_def_9_c[of "-\<^sub>\<S>\<^sup>\<real> x"] by mty auto
         hence "((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = (-\<^sub>\<S>\<^sup>\<real> x)" using arytm_2_th_12[of y z "-\<^sub>\<S>\<^sup>\<real> x"]  by mty auto
         hence "((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^sup>\<real> y = (-\<^sub>\<S>\<^sup>\<real> x)" using real_0_def_7[of "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" y]  by mty auto
         hence "-\<^sub>\<S>\<^sup>\<real>(((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^sup>\<real> y) = x" using real_0_th_20a  by mty auto
         hence "(-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  z)) *\<^sub>\<S>\<^sup>\<real> y = x" using real_0_th_42  by mty auto
         thus "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x" using bexI[of _ "-\<^sub>\<S>\<^sup>\<real>((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  z)" MReal] by mty auto
       next 
         case [ty]:False
          have Y1:  "-\<^sub>\<S>\<^sup>\<real> y <>{}" using real_0_th_18 real_0_th_20a[of y] Y by mty auto
           
         obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
             z: "(-\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = 1\<^sub>\<S>" using Y1 arytm_2_th_14[of "-\<^sub>\<S>\<^sup>\<real> y"] by mty auto 
          hence "z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y) = 1\<^sub>\<S>" using arytm_2_def_9_c by mty auto
          hence "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y)) = (-\<^sub>\<S>\<^sup>\<real> x)" 
             using arytm_2_th_15[of "-\<^sub>\<S>\<^sup>\<real> x"] arytm_2_def_9_c[of "-\<^sub>\<S>\<^sup>\<real> x"] by mty auto
           hence "((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y) = (-\<^sub>\<S>\<^sup>\<real> x)" using arytm_2_th_12[of "-\<^sub>\<S>\<^sup>\<real> y" z "-\<^sub>\<S>\<^sup>\<real> x"]  by mty auto
           hence "-\<^sub>\<S>\<^sup>\<real>(((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (-\<^sub>\<S>\<^sup>\<real> y)) = x" using real_0_th_20a[of x]  by mty auto     
           hence " ((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^sup>\<real> y = x" using real_0_def_7[of "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" y]  by mty auto
         thus "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x" using bexI[of _ "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" MReal] by mty auto
       qed
  qed

mdef real_div ("_ '/\<^sub>\<real> _" [81,80]80) where
  mlet "x be MReal","y be MReal"
  "assume y<>{} func x /\<^sub>\<real> y \<rightarrow> MReal means
      \<lambda>it. it *\<^sub>\<S>\<^sup>\<real> y = x"
proof-
  assume Y: "y<>{}"
  show "\<exists>xa : MReal. xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x" using Y div_ex by mty auto
next
  fix xa ya assume Y:"y \<noteq> {}"
    and [ty]:" xa be MReal" "ya be MReal" and 
  A1: "xa *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x" " ya *\<^sub>\<S>\<^sup>\<real> y =\<^sub>\<S> x"
  obtain Y where [ty]: "Y be MReal" and
    Y: "Y *\<^sub>\<S>\<^sup>\<real> y = 1\<^sub>\<S>" using div_ex[of "1\<^sub>\<S>" y] Y by mty auto
  hence "xa = xa *\<^sub>\<S>\<^sup>\<real> (y *\<^sub>\<S>\<^sup>\<real> Y)" using real_1_th_24[of xa] real_0_th_21[of xa] real_0_th_21[of Y y] by mty auto
  also have "... = (ya *\<^sub>\<S>\<^sup>\<real> y) *\<^sub>\<S>\<^sup>\<real> Y" using A1 real_0_th_26[of Y y xa] by mty auto    
  also have "... = ya *\<^sub>\<S>\<^sup>\<real> (y *\<^sub>\<S>\<^sup>\<real> Y)" using real_0_th_26[of Y y ya] by mty auto    
  finally show "xa = ya" using Y real_1_th_24[of ya] real_0_th_21[of ya] real_0_th_21[of Y y] by mty auto    
qed mauto

mtheorem real_1_th_25:
  "r *\<^sub>\<S>\<^sup>\<real> w = s *\<^sub>\<S>\<^sup>\<real> w \<Longrightarrow> w<>{} \<Longrightarrow> r=s"
proof-
  let ?Y="1\<^sub>\<S> /\<^sub>\<real> w"
  assume A1:"r *\<^sub>\<S>\<^sup>\<real> w = s *\<^sub>\<S>\<^sup>\<real> w" and Y:"w<>{}"
  hence U:"?Y *\<^sub>\<S>\<^sup>\<real> w = 1\<^sub>\<S>" using real_div[of "1\<^sub>\<S>" w] Y by mty auto
  hence "r = r *\<^sub>\<S>\<^sup>\<real> (w *\<^sub>\<S>\<^sup>\<real> ?Y)" using real_1_th_24[of r] real_0_th_21[of r] real_0_th_21[of ?Y w] by mty auto
  also have "... = (s *\<^sub>\<S>\<^sup>\<real> w) *\<^sub>\<S>\<^sup>\<real> ?Y" using A1 real_0_th_26[of ?Y w r] by mty auto    
  also have "... = s *\<^sub>\<S>\<^sup>\<real> (w *\<^sub>\<S>\<^sup>\<real> ?Y)" using real_0_th_26[of ?Y w s] by mty auto    
  finally show "r = s" using Y U real_1_th_24[of s] real_0_th_21[of s] real_0_th_21[of ?Y w] by mty auto    
qed

mtheorem real_1_div_1:
  "r <>{} \<Longrightarrow> (w *\<^sub>\<S>\<^sup>\<real> r) /\<^sub>\<real> r = w"
proof-
  assume A1: "r<>{}"
  hence "((w *\<^sub>\<S>\<^sup>\<real> r) /\<^sub>\<real> r) *\<^sub>\<S>\<^sup>\<real> r = w *\<^sub>\<S>\<^sup>\<real> r" using real_div by mty auto
  thus "(w *\<^sub>\<S>\<^sup>\<real> r) /\<^sub>\<real> r = w" using real_1_th_25[of w r "(w *\<^sub>\<S>\<^sup>\<real> r) /\<^sub>\<real> r"] A1 by mty auto
qed

mtheorem real_1_div_2:
  "r <>{} \<Longrightarrow> s<>{} \<Longrightarrow> (w  /\<^sub>\<real> r) /\<^sub>\<real> s = (w /\<^sub>\<real> s) /\<^sub>\<real> r"
proof-
  assume RS: "r<>{}" "s<>{}"
  have "(((w  /\<^sub>\<real> r) /\<^sub>\<real> s) *\<^sub>\<S>\<^sup>\<real> s) *\<^sub>\<S>\<^sup>\<real> r = w " using RS real_div by mty auto
  hence "((w  /\<^sub>\<real> r) /\<^sub>\<real> s) *\<^sub>\<S>\<^sup>\<real> (r *\<^sub>\<S>\<^sup>\<real> s) = w " 
    using real_0_th_26[of r s] real_0_th_21[of r s] by mty auto
  hence "(((w  /\<^sub>\<real> r) /\<^sub>\<real> s) *\<^sub>\<S>\<^sup>\<real> r) *\<^sub>\<S>\<^sup>\<real> s = w " 
    using real_0_th_26[of s r] by mty auto
  hence "((w  /\<^sub>\<real> r) /\<^sub>\<real> s) *\<^sub>\<S>\<^sup>\<real> r = w /\<^sub>\<real> s" 
    using real_div_uniq[of _ s] RS by mty auto
  thus "(w  /\<^sub>\<real> r) /\<^sub>\<real> s  = (w /\<^sub>\<real> s)/\<^sub>\<real> r" 
    using real_div_uniq[of _ r] RS by mty auto
qed

mtheorem real_1_div_3:
  "r<>{} \<Longrightarrow> s /\<^sub>\<real> r ={} \<longleftrightarrow> s={}"
proof
  assume "r \<noteq> {}""s /\<^sub>\<real> r =\<^sub>\<S> {}"
  hence "{} *\<^sub>\<S>\<^sup>\<real> r = s" using real_div[of s r] by mty auto
  thus "s={}" using real_0_th_40 by mty auto
next
  have R: "{} *\<^sub>\<S>\<^sup>\<real> r={}" using  real_0_th_22 by mty auto
  assume "r<>{}" "s={}"
  thus "s /\<^sub>\<real> r ={}" using real_div_uniq[of "{}" r "{}"] R by mty auto
qed
  
mtheorem real_1_div_4:
  "{} <\<^sup>\<real> r \<Longrightarrow> {}<\<^sup>\<real> s \<Longrightarrow> {} <\<^sup>\<real> r /\<^sub>\<real> s"
proof-
  assume A1: "{} <\<^sup>\<real> r" "{}<\<^sup>\<real> s"
  hence A2:"{} <>s" "{}\<le>\<^sup>\<real> s" "r<>{}" "{}\<le>\<^sup>\<real> r" using real_0_th_33 by mty auto
  hence [ty]: "s is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using A1 real_0_R by mty auto
  obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
           z: "s *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = 1\<^sub>\<S>" using A2 arytm_2_th_14[of s] by mty auto
  hence A3: "z<>{}" using arytm_2_def_9_c arytm_2_th_4 by mty auto 
  have [ty]: "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
  hence "{} \<le>\<^sup>\<real> r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z <>{}" using real_0_R arytm_2_lm_40[of z r] A2 A3 by mty auto
  hence A4: "{} <\<^sup>\<real> r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using  real_0_th_33 by mty auto
  hence "z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = 1\<^sub>\<S>" using arytm_2_def_9_c z by mty auto
  hence "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s) = r" using arytm_2_th_15[of r] arytm_2_def_9_c[of r] by mty auto
  hence "(r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s = r" using arytm_2_th_12[of s z r]  by mty auto
  hence "(r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^sup>\<real> s = r" using real_0_def_7[of "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" s]  by mty auto
  hence "r *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = r /\<^sub>\<real> s" using real_div_uniq A2 by mty auto
  thus "{} <\<^sup>\<real> r /\<^sub>\<real> s" using A4 by mty auto
qed

mtheorem real_1_div_5:
  "r <>{} \<Longrightarrow> s <>{}  \<Longrightarrow> r /\<^sub>\<real> (r /\<^sub>\<real> s) = s"
proof-
  assume RS:"r<>{}" "s<>{}"
  hence A1: "(r /\<^sub>\<real> s)<>{}" using real_1_div_3 by mty auto
  have "(r /\<^sub>\<real> s) *\<^sub>\<S>\<^sup>\<real> s = r" using RS real_div by auto
  hence "s *\<^sub>\<S>\<^sup>\<real> (r /\<^sub>\<real> s) = r" using real_0_th_21 by mty auto
  thus "r /\<^sub>\<real> (r /\<^sub>\<real> s) = s" using real_div_uniq[of r "r /\<^sub>\<real> s" s] A1 by mty auto
qed

theorem real_1_div_6:
  assumes [ty]:"n is Nat" "m is Nat" and AS:"m<>{}"
  shows " n /\<^bsub>\<rat>\<ge>0\<^bsup> m = n/\<^sub>\<real> m"
proof-
  have "(n /\<^bsub>\<rat>\<ge>0\<^bsup> m) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> m = n" using AS arytm_3_TH2 by mty auto
  hence "(n /\<^bsub>\<rat>\<ge>0\<^bsup> m) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> m = n" using Prat_Preal_mult by mty auto
  hence "(n /\<^bsub>\<rat>\<ge>0\<^bsup> m) *\<^sub>\<S>\<^sup>\<real> m = n" using real_0_def_7 by mty auto
  thus " n /\<^bsub>\<rat>\<ge>0\<^bsup> m = n/\<^sub>\<real> m" using AS real_div_uniq by mty auto
qed
  

  
mtheorem real_1_th_26:
   "{} \<le>\<^sup>\<real> w \<Longrightarrow> r \<le>\<^sup>\<real> s \<Longrightarrow> r *\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s *\<^sub>\<S>\<^sup>\<real> w"
proof-
  assume AS:"{} \<le>\<^sup>\<real> w" "r \<le>\<^sup>\<real> s"
  hence [ty]:"w is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  obtain z where [ty]: "z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A1: "s =r +\<^sub>\<S>\<^sup>\<real> z" using real_0_def_8E[of r s] AS by mauto
  hence "s *\<^sub>\<S>\<^sup>\<real> w =(r *\<^sub>\<S>\<^sup>\<real> w) +\<^sub>\<S>\<^sup>\<real> (z*\<^sub>\<S>\<^sup>\<real> w)" using real_0_th_28 by mty auto
  hence "s *\<^sub>\<S>\<^sup>\<real> w =(r *\<^sub>\<S>\<^sup>\<real> w) +\<^sub>\<S>\<^sup>\<real> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w)" using real_0_def_7[of z w] by mty auto
  thus "r *\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s *\<^sub>\<S>\<^sup>\<real> w" using real_0_def_8I[of "r *\<^sub>\<S>\<^sup>\<real> w" "s *\<^sub>\<S>\<^sup>\<real> w"]  
    bexI[of _"z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w" "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by mty auto 
qed

mtheorem real_1_th_27:
   "{} <\<^sup>\<real> w \<Longrightarrow> r <\<^sup>\<real> s \<Longrightarrow> r *\<^sub>\<S>\<^sup>\<real> w <\<^sup>\<real> s *\<^sub>\<S>\<^sup>\<real> w"
proof
  assume AS: " {} <\<^sup>\<real> w"  "r <\<^sup>\<real> s"  "s *\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> r *\<^sub>\<S>\<^sup>\<real> w"
  hence A1: "{} \<le>\<^sup>\<real>  w" "w <>{}" "r \<le>\<^sup>\<real> s" "r<>s" using real_0_th_33 by mty auto
  hence "r *\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s *\<^sub>\<S>\<^sup>\<real> w" using real_1_th_26 by mty auto
  hence "r *\<^sub>\<S>\<^sup>\<real> w = s *\<^sub>\<S>\<^sup>\<real> w" using AS real_0_def_8s by mty auto
  thus False using A1 real_1_th_25[of s w r] by mty auto
qed

mtheorem real_1_th_28:
  "{} <\<^sup>\<real> w \<Longrightarrow> r \<le>\<^sup>\<real> s \<Longrightarrow> r /\<^sub>\<real> w \<le>\<^sup>\<real> s /\<^sub>\<real> w"
proof-
  assume A1: "{} <\<^sup>\<real> w" "r \<le>\<^sup>\<real> s"
  hence "{} <>w" using real_0_th_33 by mty auto
  hence "(r /\<^sub>\<real> w) *\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> (s /\<^sub>\<real> w) *\<^sub>\<S>\<^sup>\<real> w" using A1 real_div[of _w] by mty auto
  thus "r /\<^sub>\<real> w \<le>\<^sup>\<real> s /\<^sub>\<real> w" using A1 real_1_th_27[of "s /\<^sub>\<real> w" "r /\<^sub>\<real> w" w] by mty auto 
qed

mtheorem real_1_th_28s:
  "{} <\<^sup>\<real> w \<Longrightarrow> r <\<^sup>\<real> s \<Longrightarrow> r /\<^sub>\<real> w <\<^sup>\<real> s /\<^sub>\<real> w"
proof-
  assume A1: "{} <\<^sup>\<real> w" "r <\<^sup>\<real> s"
  hence A2:"{} <>w" "{} \<le>\<^sup>\<real> w" using real_0_th_33 by mty auto
  hence "(r /\<^sub>\<real> w) *\<^sub>\<S>\<^sup>\<real> w <\<^sup>\<real> (s /\<^sub>\<real> w) *\<^sub>\<S>\<^sup>\<real> w" using A1 real_div[of _w] by mty auto
  thus "r /\<^sub>\<real> w <\<^sup>\<real> s /\<^sub>\<real> w" using A1 real_1_th_26[of "r /\<^sub>\<real> w" "s /\<^sub>\<real> w" w] A2 by mty auto 
qed

mtheorem real_1_th_29:
  "{} \<le>\<^sup>\<real> w \<Longrightarrow> {} <\<^sup>\<real> r \<and> r \<le>\<^sup>\<real> s \<Longrightarrow> w /\<^sub>\<real> s \<le>\<^sup>\<real> w /\<^sub>\<real> r"
proof-
  assume A1: "{} \<le>\<^sup>\<real> w" "{} <\<^sup>\<real> r \<and> r \<le>\<^sup>\<real> s"
  hence A2: "r <>{}" "{} <\<^sup>\<real> s" using real_0_th_33 real_0_def_8t2[of s "{}" r] by mty auto
  hence A3: "s<>{}" using real_0_th_33 by mty auto
    have  "r *\<^sub>\<S>\<^sup>\<real> w \<le>\<^sup>\<real> s *\<^sub>\<S>\<^sup>\<real> w" using A1 real_1_th_26 by mty auto
  hence "(r *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r \<le>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r" using A1 real_1_th_28 by mty auto
  hence " w \<le>\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r" using real_1_div_1[of w r] real_0_th_21[of r w] A2 by mty auto
  hence " w/\<^sub>\<real> s \<le>\<^sup>\<real> ((s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r)/\<^sub>\<real> s" using real_1_th_28[of _ w s] A2 by mty auto
  hence " w/\<^sub>\<real> s \<le>\<^sup>\<real> ((s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> s)/\<^sub>\<real> r" using real_1_div_2 A2 A3 by mty auto
  thus " w/\<^sub>\<real> s \<le>\<^sup>\<real> w/\<^sub>\<real> r" using real_1_div_1[of w s] A2 A3 real_0_th_21[of s w] by mty auto
qed

mtheorem real_1_th_29s:
  "{} <\<^sup>\<real> w \<Longrightarrow> {} <\<^sup>\<real> r \<and> r <\<^sup>\<real> s \<Longrightarrow> w /\<^sub>\<real> s <\<^sup>\<real> w /\<^sub>\<real> r"
proof-
  assume A1: "{} <\<^sup>\<real> w" "{} <\<^sup>\<real> r \<and> r <\<^sup>\<real> s"
  hence A2: "r <>{}" "{} <\<^sup>\<real> s" using real_0_th_33 real_0_def_8t2[of s "{}" r] by mty auto
  hence A3: "s<>{}" using real_0_th_33 by mty auto
    have  "r *\<^sub>\<S>\<^sup>\<real> w <\<^sup>\<real> s *\<^sub>\<S>\<^sup>\<real> w" using A1 real_1_th_27 by mty auto
  hence "(r *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r <\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r" using A1 real_1_th_28s by mty auto
  hence " w <\<^sup>\<real> (s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r" using real_1_div_1[of w r] real_0_th_21[of r w] A2 by mty auto
  hence " w/\<^sub>\<real> s <\<^sup>\<real> ((s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> r)/\<^sub>\<real> s" using real_1_th_28s[of w _ s] A1 A2 A3 by mty auto
  hence " w/\<^sub>\<real> s <\<^sup>\<real> ((s *\<^sub>\<S>\<^sup>\<real> w)/\<^sub>\<real> s)/\<^sub>\<real> r" using real_1_div_2 A2 A3 by mty auto
  thus " w/\<^sub>\<real> s <\<^sup>\<real> w/\<^sub>\<real> r" using real_1_div_1[of w s] A2 A3 real_0_th_21[of s w] by mty auto
qed

mtheorem real_1_TH:
  "ex n be Element-of NAT st r <\<^sup>\<real> n"
proof(cases "r is Element-of REAL\<^bsup>\<ge>0\<^bsub>")
  case [ty]:False
  hence "r <\<^sup>\<real> {}" using real_0_R by mty auto
  thus "ex n be Element-of NAT st r <\<^sup>\<real> n" using bexI[of _ "{}"] by mty auto
next
  case [ty]:True
  then obtain n where [ty]:"n be Element-of NAT" and 
    n: "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_2_TH3[of r] by mty auto
  have "n in succ n" using ordinal1_th_2 by mty auto
  hence  "n <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" using arytm_3_TH1e[of n "succ n"] by mty auto
  hence "n <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" using arytm_2_lm_14 by mty auto
  hence "r <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> succ n" using arytm_2_th_69[of "succ n" r n] n by mty auto
  thus "ex n be Element-of NAT st r <\<^sup>\<real> n" using bexI[of _ "succ n"] real_0_th_29 by mty auto
qed

mdef xxreal_1_def_1 ("[. _ , _ .]" [90,90] 90) where 
  mlet "x be MReal", "y be MReal" 
  "func [. x , y .] \<rightarrow> Subset-of REAL equals
       {a where a be Element-of REAL: x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y}"
proof-
  have "{a where a be Element-of REAL: x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y} \<subseteq> REAL"
  proof(rule tarski_def_3I[OF all_set all_set], intro ballI impI)
    fix xa assume "xa be object" and 
      A:"xa in {a where a be Element-of REAL: x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y}"
    have "xa is Element-of REAL" using Fraenkel_A1_ex[OF _ _ A] by mty auto
    thus "xa in REAL" using Element(7) by mty auto 
  qed mauto
  thus "Fraenkel1(\<lambda>a. a, Element-of REAL, \<lambda>a. x \<le>\<^sup>\<real> a  \<and> a \<le>\<^sup>\<real> y ) be Subset-of REAL" 
    using Subset_of_rule by mty auto
qed

reserve a,x,y for MReal

mtheorem xxreal_1_th_1:
  "a in [.x,y.] iff x \<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y"
proof
  assume "a in [.x,y.]"
  hence H:"a in {a where a be Element-of REAL: x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y}" 
    using xxreal_1_def_1 by mty auto
  thus "x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y" using Fraenkel_A1_ex[OF _ _ H] by mty auto
next
  have [ty]:"a is Element-of REAL" using real_0_def_3[of a] Element(6) by mty auto
  assume "x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y"
  hence "a in {a where a be Element-of REAL: x\<le>\<^sup>\<real> a & a \<le>\<^sup>\<real> y}"
    using Fraenkel_A1_in[of "Element-of REAL" a _ "\<lambda>a. a"] by mty auto 
  thus "a in [.x,y.]" using xxreal_1_def_1 by mty auto
qed
     
end


