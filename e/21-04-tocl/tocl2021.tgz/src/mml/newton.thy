theory newton
  imports finseq_1
    
begin
mdef newton_def_1 ("_ |^ _"[100,100] 100 ) where
  mlet "n be Nat", "k be Nat"
  "func n |^ k \<rightarrow> Nat means
     \<lambda>it. ex f be Function-of NAT,NAT st it = f. k & f. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ k holds f.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (f. i)) "
proof-
   let ?P = "\<lambda> x.  n *\<^sub>\<S>\<^sup>\<nat> x" 
   have P1: "for x be Nat holds ?P(x) is Nat"
   proof(intro ballI)
     fix x assume [ty]: "x be Nat"
     show "?P(x) is Nat" by mty auto
   qed mauto
   obtain f where [ty]:"f be  Function-of NAT,NAT" and
      A1:"f.{} = succ {} & (for j be Nat st j in succ k holds f. (succ j) = ?P(f. j))"
     using NAT_sch[OF P1, of "succ {}" "succ k"] by mty auto 
   show "ex it be Nat st ex f be Function-of NAT,NAT st it = f. k & f. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ k holds f.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (f. i))"
   proof(rule bexI[of _ "f. k"], rule bexI[of _ f],intro conjI)
      show" f . {} =\<^sub>\<S> succ {}" using A1 by auto
      show" \<forall>i : Nat. i in succ k \<longrightarrow> f . (succ i) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> f . i" using A1 by auto
      have "k in NAT" "dom f = NAT" "NAT<>{}"
          using ordinal1_def_12[of k] funct_2_th_52[of NAT f] xb ordinal1_def_11 by mty auto
      hence "f. k in omega" using funct_2_th_5[of k NAT NAT f,simplified] by mty auto 
      thus " f . k be Nat" using ordinal1_def_12 by mty auto      
   qed mauto
   fix x y assume [ty]:" x be Nat" 
           "y be Nat" and AS:
           "\<exists>f :
            Function-of omega, omega. x =\<^sub>\<S> f . k \<and>
                                      f . {} =\<^sub>\<S> succ {} \<and>
                                      (\<forall>i : Nat. i in succ k \<longrightarrow> f . (succ i) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> f . i)"
           "\<exists>f :
            Function-of omega, omega. y =\<^sub>\<S> f . k \<and>
                                      f . {} =\<^sub>\<S> succ {} \<and>
                                      (\<forall>i : Nat. i in succ k \<longrightarrow> f . (succ i) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> f . i)"
   obtain f where [ty]:"f be Function-of omega, omega" and
        X: "x =\<^sub>\<S> f . k \<and> f . {} =\<^sub>\<S> succ {} \<and>
           (\<forall>i : Nat. i in succ k \<longrightarrow> f . (succ i) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> f . i)" 
       using AS by auto
   obtain g where [ty]:"g be Function-of omega, omega" and
        Y: "y =\<^sub>\<S> g . k \<and> g . {} =\<^sub>\<S> succ {} \<and>
           (\<forall>i : Nat. i in succ k \<longrightarrow> g . (succ i) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> g . i)" 
       using AS by auto     
    let ?Q = "\<lambda>it. it  in succ k \<longrightarrow>f. it = g. it"
     have Q1: "?Q({})" using X Y by auto
    have Q2: "\<forall>n : Nat. ?Q(n) \<longrightarrow> ?Q(succ n)"
    proof(intro ballI impI)
      fix a assume [ty]:"a be Nat" and AS:"?Q(a)" "succ a in succ k"
      hence "a in succ k" using ordinal1_th_8[of a _ "succ a"] ordinal1_th_2a[of a] by mty auto
      hence "f. a = g. a" "f . (succ a) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> f . a" 
            "g . (succ a) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> g . a" using AS X Y by mty auto
      thus "f . (succ a) =\<^sub>\<S> g . (succ a)" by auto
    qed mauto
    have "?Q(k)" using ordinal_2_sch_19[of k ?Q, OF _ Q1 Q2] by auto
    thus "           x =\<^sub>\<S> y" using X Y ordinal1_th_2 by mty auto
  qed mauto

mtheorem newton_th_4:
  "n |^ 0\<^sub>\<S> = 1\<^sub>\<S>"
proof-
  obtain f where "f be Function-of NAT,NAT" and 
    N: "n |^ 0\<^sub>\<S> = f. {} & f. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ {} holds f.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (f. i))" 
      using newton_def_1[of n "{}"] by mty auto
  thus  "n |^ 0\<^sub>\<S> = 1\<^sub>\<S>" by auto
qed

mtheorem newton_th_5:
  "n |^ 1\<^sub>\<S> = n"
proof-
  obtain f where "f be Function-of NAT,NAT" and 
    N: "n |^ 1\<^sub>\<S> = f. 1\<^sub>\<S> & f. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ 1\<^sub>\<S> holds f.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (f. i))" 
    using newton_def_1[of n "1\<^sub>\<S>"] by mty auto
  have "1\<^sub>\<S> in succ 1\<^sub>\<S>" using ordinal1_th_2 by auto
  hence "0\<^sub>\<S> in  succ 1\<^sub>\<S>" using ordinal1_th_2a[of "{}"] ordinal1_th_8[of "{}" _ "succ {}"] by mty auto
  hence "f.(succ {}) = n *\<^sub>\<S>\<^sup>\<nat> (f. {})" using N by auto
  thus  "n |^  1\<^sub>\<S> = n" using Mult_5 N by auto
qed

mtheorem newton_th_6:
  "n |^ (succ k) = n *\<^sub>\<S>\<^sup>\<nat> (n |^ k)  "
proof-
  obtain f where "f be Function-of NAT,NAT" and 
    N: "n |^ (succ k) = f. (succ k) & f. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ (succ k) holds f.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (f. i))" 
    using newton_def_1[of n "succ k"] by mty auto
  obtain g where "g be Function-of NAT,NAT" and 
    Q: "n |^ (k) = g. (k) & g. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ k holds g.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (g. i))" 
    using newton_def_1[of n k] by mty auto
  let ?Q = "\<lambda>it. it  in succ k \<longrightarrow>f. it = g. it"
     have Q1: "?Q({})" using N Q  by auto
    have Q2: "\<forall>n : Nat. ?Q(n) \<longrightarrow> ?Q(succ n)"
    proof(intro ballI impI)
      fix a assume [ty]:"a be Nat" and AS:"?Q(a)" "succ a in succ k"
      hence "a in succ k" "a in succ succ k" 
        using ordinal1_th_8[of a _ "succ a"] ordinal1_th_2a[of a] ordinal1_th_4 by mty auto
      hence "f. a = g. a"  "f . (succ a) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> f . a" 
            "g . (succ a) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> g . a" using AS N Q by mty auto
      thus "f . (succ a) =\<^sub>\<S> g . (succ a)" by auto
    qed mauto
    have "?Q(k)" using ordinal_2_sch_19[of k ?Q, OF _ Q1 Q2] by auto
    hence FG: "f. k =\<^sub>\<S> g. k" using ordinal1_th_2 by mty auto
    have "k in succ succ k" using ordinal1_th_4 by mty auto
    hence "f.(succ k) = n *\<^sub>\<S>\<^sup>\<nat> (f. k)" using N by mty auto
    thus ?thesis using N Q FG by mty auto 
  qed

mtheorem newton_th_6a:
  "n |^ (l +\<^sub>\<S>\<^sup>\<nat> k) = (n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n |^ k)  "
proof-
  let ?P="\<lambda>it. n |^ (l +\<^sub>\<S>\<^sup>\<nat> it) = (n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n |^ it)" 
  have "n |^ {} = succ {}" using  newton_th_4 by mty auto
  hence  " (n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n |^ {}) = (n |^ l)" "l  +\<^sub>\<S>\<^sup>\<nat> {}=l"
      using Mult_5 Add_3 by mty auto
    hence P0:"?P({})" by mty auto
  have Pn: "\<forall>k : Nat. ?P(k) \<longrightarrow> ?P(succ k)"
  proof(intro ballI impI)
    fix k assume [ty]:"k be Nat" and P:"?P(k)" 
    have "n |^ (l +\<^sub>\<S>\<^sup>\<nat> (succ k)) = n |^ (succ (l +\<^sub>\<S>\<^sup>\<nat>  k))" using Add_1 by mty auto
    also have "... =  n *\<^sub>\<S>\<^sup>\<nat>  (n |^ (l +\<^sub>\<S>\<^sup>\<nat>  k))" using newton_th_6 by mty auto
    also have "... =    ((n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n |^ k)) *\<^sub>\<S>\<^sup>\<nat> n" using P Mult_6[of n] by mty auto
    also have "... =    (n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n *\<^sub>\<S>\<^sup>\<nat> (n |^ k) )" 
      using P Mult_13[of n "n |^ k"] Mult_6[of n "n |^ k"] by mty auto
    finally show "n |^ (l +\<^sub>\<S>\<^sup>\<nat> (succ k)) =  (n |^ l) *\<^sub>\<S>\<^sup>\<nat> (n |^ (succ k) )" 
       using  newton_th_6 by mty auto
  qed mauto
   have "?P(k)" using ordinal_2_sch_19[of k ?P, OF _ P0 Pn] by auto
  thus ?thesis by mty auto
qed


mtheorem newton_th_7:
  "n <> {} \<longrightarrow> n |^ k <> {}"
proof
  assume AS1:"n<>{}"
  obtain g where [ty]:"g be Function-of NAT,NAT" and 
    Q: "n |^ (k) = g. (k) & g. 0\<^sub>\<S> = 1\<^sub>\<S> & 
     (for i be Nat st i in succ k holds g.(succ i) = n *\<^sub>\<S>\<^sup>\<nat> (g. i))" 
    using newton_def_1[of n k] by mty auto

 let ?Q = "\<lambda>it. it  in succ k \<longrightarrow>g. it <>{} "
   have Q1: "?Q({})" using Q by auto
    have Q2: "\<forall>n : Nat. ?Q(n) \<longrightarrow> ?Q(succ n)"
    proof(intro ballI impI)
      fix a assume [ty]:"a be Nat" and AS:"?Q(a)" "succ a in succ k"
      have "a in NAT" "dom g = NAT" "NAT<>{}"
          using ordinal1_def_12[of a] funct_2_th_52[of NAT g] xb ordinal1_def_11 by mty auto
      hence "g. a in omega" using funct_2_th_5[of a NAT NAT g,simplified] by mty auto 
      hence [ty]:"g. a is Nat" using ordinal1_def_12 by mty auto 
      have "a in succ k" 
        using ordinal1_th_8[of a _ "succ a"] ordinal1_th_2a[of a] ordinal1_th_4 AS by mty auto
      hence "g . (succ a) =\<^sub>\<S> n *\<^sub>\<S>\<^sup>\<nat> g . a" "g . a <>{}" using AS Q by mty auto
      thus "g . (succ a) <>{}" using Mult_9[of "g . a" n] AS1 by mty  auto
    qed mauto
   have "?Q(k)" using ordinal_2_sch_19[of k ?Q, OF _ Q1 Q2] by auto
   thus "n |^ k <> {}" using Q ordinal1_th_2 by mty auto
qed

mtheorem newton_th_8:
 "2\<^sub>\<S> \<subseteq> n \<and> i in j \<longrightarrow> n |^ i in n |^ j"
proof
  assume A1: "2\<^sub>\<S> \<subseteq> n \<and> i in j"
  then obtain k where [ty]:"k is Nat" and
   K:  "k<>{} & j =i+\<^sub>\<S>\<^sup>\<nat> k" using Add_8 by mty auto
   let ?Q = "\<lambda>it. it <>{} \<longrightarrow> n |^ i in n|^ (i +\<^sub>\<S>\<^sup>\<nat> it)"
   have Q1: "?Q({})" by auto
    have Q2: "\<forall>n : Nat. ?Q(n) \<longrightarrow> ?Q(succ n)"
    proof(intro ballI impI)
      fix a assume [ty]:"a be Nat" and AS:"?Q(a)" "succ a <>{}"
        have Z: " succ {} in 2\<^sub>\<S>" "{} in succ {}" using  ordinal1_th_2 by mty auto
        hence S: "succ {} in n" using A1 tarski_def_3E all_set by mty auto 
        hence "{} in n" using ordinal1_th_8t[of "{}" n "succ {}"] Z by mty auto
        hence N: "n <>{}" using prefix_in_irreflexive by mty auto 
    
      show "n |^ i in n|^ (i +\<^sub>\<S>\<^sup>\<nat> (succ a))"
      proof(cases "a={}")
        case True
        hence I: "i +\<^sub>\<S>\<^sup>\<nat> succ a = succ i" using Add_5[of i] by mty auto
          have  "n |^ i <> {}" using newton_th_7 N by mty auto
        hence " (n |^ i) *\<^sub>\<S>\<^sup>\<nat> succ {}  in (n |^ i) *\<^sub>\<S>\<^sup>\<nat> n" using Mult_14 S by mty auto
        hence " (n |^ i)  in n *\<^sub>\<S>\<^sup>\<nat> (n |^ i)"  using Mult_5 Mult_6 by mty auto
        thus " (n |^ i)  in (n|^ (i +\<^sub>\<S>\<^sup>\<nat> (succ a)))"  using I newton_th_6 by mty auto
      next 
        case False
        hence D: " n |^ i in n|^ (i +\<^sub>\<S>\<^sup>\<nat> a)" using AS by auto
     
       have  "n |^ (i +\<^sub>\<S>\<^sup>\<nat> a) <> {}" using newton_th_7 N by mty auto
        hence " (n |^ (i +\<^sub>\<S>\<^sup>\<nat> a)) *\<^sub>\<S>\<^sup>\<nat> succ {}  in (n |^ (i +\<^sub>\<S>\<^sup>\<nat> a)) *\<^sub>\<S>\<^sup>\<nat> n" using Mult_14 S by mty auto
        hence " (n |^ (i +\<^sub>\<S>\<^sup>\<nat> a))  in n *\<^sub>\<S>\<^sup>\<nat> (n |^ (i +\<^sub>\<S>\<^sup>\<nat> a))"  using Mult_5 Mult_6 by mty auto
        hence " (n |^ (i +\<^sub>\<S>\<^sup>\<nat> a))  in (n|^ (succ (i +\<^sub>\<S>\<^sup>\<nat> a)))"  using  newton_th_6 by mty auto
        hence " (n |^ (i +\<^sub>\<S>\<^sup>\<nat> a))  in (n|^  (i +\<^sub>\<S>\<^sup>\<nat> succ (a)))"  using  Add_2[of i a] 
         Add_6 by mty auto
        thus "n |^ i in (n|^  (i +\<^sub>\<S>\<^sup>\<nat> succ (a)))" using ordinal1_th_8t[OF _ _ _ _ _ _ D] by mty auto
      qed                
    qed mauto
   have "?Q(k)" using ordinal_2_sch_19[of k ?Q, OF _ Q1 Q2] by auto
   thus "n |^ i in n |^ j" using K by mty auto
 qed

mtheorem newton_th_9:
 "2\<^sub>\<S> \<subseteq> n \<and> i \<subseteq> j \<longrightarrow> n |^ i \<subseteq> n |^ j"
proof
  assume AS: "2\<^sub>\<S> \<subseteq> n \<and> i \<subseteq> j"
  hence "i = j or i in j" using ordinal1_th_7 xboole_0_def_8[of i j] all_set by mty auto
  hence "n |^ i = n |^ j or n |^ i in n |^ j" using AS newton_th_8 by mty auto
  hence "n |^ i = n |^ j or n |^ i \<subset> n |^ j" using ordinal1_th_7a by mty auto
  thus "n |^ i \<subseteq> n |^ j" using xboole_0_def_8[of "n |^ i " "n |^ j",simplified] 
    xboole_0_def_10 by mty auto
qed

end
