theory arytm_2
  imports arytm_3
begin

reserve r,s,t,x9,y9,z9,p,q for "Element-of RAT\<^bsup>\<ge>0\<^bsub>"

text_raw {*\DefineSnippet{arytm_2_def_1}{*}
mdef arytm_2_def_1("DEDEKIND'_CUTS") where
  "func DEDEKIND_CUTS \<rightarrow> Subset-Family-of RAT\<^bsup>\<ge>0\<^bsub> equals
  { A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    \<forall>r: Element-of RAT\<^bsup>\<ge>0\<^bsub>. r in A \<longrightarrow>
         (\<forall>s: Element-of RAT\<^bsup>\<ge>0\<^bsub>. s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<longrightarrow> s in A) \<and> (\<exists>s: Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in A \<and> r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)} \\ {RAT\<^bsup>\<ge>0\<^bsub>}"
text_raw {*}%EndSnippet*}
proof(rule Subset_of_rule) 
  show "{ A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s )}
  \\ { RAT\<^bsup>\<ge>0\<^bsub>} \<subseteq> bool RAT\<^bsup>\<ge>0\<^bsub>"
  proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
    fix x 
    assume "x in ({ A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s )}
      \\ { RAT\<^bsup>\<ge>0\<^bsub>} )"
    hence F: "x in { A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s )}"
      using xboole_0_def_5 by mauto
    obtain A where [ty]:"A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>"
    and "x=A & (for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s ))"
      using Fraenkel_A1_ex[OF _ _ F] by mauto
    hence "x \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" using Subset_in_rule by mauto
    thus "x in bool RAT\<^bsup>\<ge>0\<^bsub>" using zfmisc_1_def_1[of "RAT\<^bsup>\<ge>0\<^bsub>" x] all_set by mauto
  qed mauto
qed


lemma arytm_2_def_1_ty1[ty]: "DEDEKIND_CUTS is set" using all_set by mauto

mtheorem
  "cluster DEDEKIND_CUTS \<rightarrow> non empty"
proof
  let  ?X = "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub> : s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{} }"
  have A1: "?X c= RAT\<^bsup>\<ge>0\<^bsub>"
    proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
      fix e 
      assume F: "e in ?X"
      obtain s where "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        " s = e & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using Fraenkel_A1_ex[OF _ _ F] by mauto
      thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" s] by mauto
    qed mauto
    hence [ty]:"?X is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by mauto
    have S: "succ {} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" ] by mauto
    have "not succ {} in ?X"
    proof
      assume F: "succ {} in ?X"
      obtain s where "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        " s = succ {} & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using Fraenkel_A1_ex[OF _ _ F] by mauto     
      thus False using arytm_3_th_68 by mauto
    qed
    hence "?X <> RAT\<^bsup>\<ge>0\<^bsub>" using S by mauto
    hence A2: "not ?X in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by mauto 
    have "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{}" using arytm_3_th_64 by mauto
    hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using arytm_3_th_68 by mauto
    hence "{} in ?X" using Fraenkel_A1_in by mauto
    have H: " for r st r in ?X holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?X) & (ex s st s in ?X & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
    proof(rule ballI,intro impI conjI)
      fix r  
      assume F: "r in ?X"
      then obtain S where [ty]:"S is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      A3: "S = r & S <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using Fraenkel_A1_ex[OF _ _ F] by mauto
      show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?X"
      proof(intro ballI impI)
        fix s assume [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
        assume "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
        hence "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using  A3 arytm_3_th_69[of "succ{}" s S] by mauto
        thus "s in ?X" using Fraenkel_A1_in by mauto
      qed mauto
      obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4:   "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" and
A5:   "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using  A3 arytm_3_th_93[of S "succ{}"] by mauto
      have "s in ?X" using A5  Fraenkel_A1_in by mauto
      thus "ex s st s in ?X & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A4 bexI[of _ s] by mauto
    qed mauto
    hence "?X in { A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s )}"
      using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" ?X ] H by mauto
    hence "?X in DEDEKIND_CUTS" unfolding arytm_2_def_1 using A2 xboole_0_def_5[of _ _ ?X] by mauto
    thus " DEDEKIND_CUTS is non empty" using xboole_0_def_1[of  DEDEKIND_CUTS] all_set bexI[of _ ?X] by mauto
  qed

text_raw {*\DefineSnippet{arytm_2_def_2}{*}
mdef arytm_2_def_2 ("REAL\<^bsup>\<ge>0\<^bsub>") where
  "func REAL\<^bsup>\<ge>0\<^bsub> \<rightarrow> set equals (RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS) \\ 
   {{s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t} where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: t \<noteq> 0\<^sub>\<S>}" 
  text_raw {*}%EndSnippet*}
using all_set by mauto
reserve x,y,z for "Element-of REAL\<^bsup>\<ge>0\<^bsub>"

abbreviation 
"IR \<equiv> { A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds
s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)}"

abbreviation 
  "RA \<equiv> {{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t} where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>:
        t <> {}}"

mtheorem arytm_2_lm_1: "not (ex x,y be object st [x,y] in IR)"
proof
  assume "ex x,y be object st [x,y] in IR"
  then obtain x y where
   A1:  "[x,y] in IR" by mauto
  obtain A where [ty]: "A is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "[x,y] = A" and
A3: "for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)" 
    using Fraenkel_A1_ex[OF _ _ A1] by mauto
  have H: "{x} in A" "{x}<>{}" 
    using A2 tarski_def_2[of "{x,y}" "{x}"] tarski_def_5[of x y] 
    tarski_def_1 xb1  by mauto
  hence "{x} in RAT\<^bsup>\<ge>0\<^bsub>"
     using Subset_in_rule[of A "RAT\<^bsup>\<ge>0\<^bsub>"] tarski_def_3  by mauto
  hence E: "\<exists>t : Element-of RAT\<^bsup>\<ge>0\<^bsub>. t in A \<and> t \<noteq> {}" using H Element(6) bexI[of _ "{x}"]
    by mauto
  have F: "\<And>r s. r be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> s be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> r in A \<Longrightarrow> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r  \<Longrightarrow> s in A"
    using A2 A3 tarski_def_2[of "{x , y}" "{x}"] tarski_def_5[of x y] by mauto
   have "ex r1, r2,r3 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r1 in A \<and>
     r2 in A \<and> r3 in A \<and> r1 \<noteq> r2 \<and> r2 \<noteq> r3 \<and> r3 \<noteq> r1" using arytm_3_th_75[of A,OF _ E F] by mauto
  then obtain r1 r2 r3 where "r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "r1 in A" and
A5: "r2 in A" and
A6: "r3 in A & r1 <> r2 & r2 <> r3 & r3 <> r1" by auto
  have
A7: "r1 = { x,y } or r1 = { x }" "r2 = { x,y } or r2 = { x }" "r3 = { x,y } or r3 = { x }"
    using A2 A4 A5 A6  tarski_def_2[of "{x,y}" "{x}"] tarski_def_5[of x y]
    by mauto
  thus False using A6 by mauto
qed

mtheorem arytm_2_lm_2: "RAT\<^bsup>\<ge>0\<^bsub> misses RA"
proof(rule ccontr)
  assume "\<not> RAT\<^bsup>\<ge>0\<^bsub> misses RA"
  hence "RAT\<^bsup>\<ge>0\<^bsub> meets RA" using xboole_0_antonym_meets all_set by mauto
  then obtain e where
A1: "e in RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "e in RA" using xboole_0_th_3 by mauto
  have [ty]:"e is set" using all_set by mauto
  obtain t where [ty]:"t  is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "e = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t }" and
A4: "t <> {}" using Fraenkel_A1_ex[OF _ _ A2] by mauto
  have "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_64 by mauto
  hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A4 arytm_3_th_68 by mauto
  hence
A5: "{} in e" using A3 Fraenkel_A1_in by mauto
hence a5:"e<>{}" using xb1 by mauto 
  have "e c= RAT\<^bsup>\<ge>0\<^bsub>"
  proof(standard,rule all_set,rule all_set,intro ballI impI)
    fix u 
    assume "u in e"
    hence F: "u in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t }" using A3 by simp
    obtain  s where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
      and " s = u & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A3 Fraenkel_A1_ex[OF _ _ F] by mauto
    thus "u in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
  qed mauto
  hence  [ty]:"e is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using A5 Subset_of_rule[of e "RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
  obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6: "s in e" and
A7: "for r st r in e holds r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A1 arytm_3_th_91 a5 by mauto
  have F: "s in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t }" using A3 A6 by simp
  obtain R where "R is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    " R = s & R <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A3 A6 Fraenkel_A1_ex[OF _ _ F] by mauto
  then obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A8: "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" and
A9: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_93[of s t] by mauto
  have "r in e" 
    using A3 A9 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r] by mauto
  thus False using A7 A8 by mauto
qed

text_raw {*\DefineSnippet{arytm_2_th_1}{*}
mtheorem arytm_2_th_1:
  "RAT\<^bsup>\<ge>0\<^bsub> c= REAL\<^bsup>\<ge>0\<^bsub>"
text_raw {*}%EndSnippet*}
proof(standard,rule all_set,rule all_set,intro ballI impI,rule ccontr)
  fix x 
  assume AS: "x in RAT\<^bsup>\<ge>0\<^bsub>" "not x in REAL\<^bsup>\<ge>0\<^bsub>"
  hence "not x in (RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS) or x in RA" 
    using xboole_0_def_5[of "RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS" RA] all_set arytm_2_def_2 by mauto
  hence "x in RA" using AS xboole_0_def_3[of "RAT\<^bsup>\<ge>0\<^bsub>" DEDEKIND_CUTS] all_set by mauto
  hence "RAT\<^bsup>\<ge>0\<^bsub> meets RA" using xboole_0_th_3[of RA "RAT\<^bsup>\<ge>0\<^bsub>"] bexI[of _ x] AS all_set by mauto
  thus False using xboole_0_antonym_meets arytm_2_lm_2 by mauto
qed mauto

mtheorem cRR:
  "cluster Element-of RAT\<^bsup>\<ge>0\<^bsub> \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub> for object"
proof(standard,auto)
  fix x assume "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  hence "x in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  hence "x in REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_1 tarski_def_3 by mty auto
  thus "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>" using Element(6) by mty auto 
qed

mtheorem arytm_2_lm_3:
  "REAL\<^bsup>\<ge>0\<^bsub> c= RAT\<^bsup>\<ge>0\<^bsub> \<union> IR"
proof(standard,rule all_set,rule all_set,intro ballI impI)
  fix x 
  assume AS: "x in REAL\<^bsup>\<ge>0\<^bsub>"
  hence "x in RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS " 
    using xboole_0_def_5[of "RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS" RA] all_set arytm_2_def_2 by mauto
  hence "x in RAT\<^bsup>\<ge>0\<^bsub> or x in DEDEKIND_CUTS" using xboole_0_def_3[of "RAT\<^bsup>\<ge>0\<^bsub>" DEDEKIND_CUTS] all_set by mauto
  hence "x in RAT\<^bsup>\<ge>0\<^bsub> or x in IR" using arytm_2_def_1 all_set xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] by mauto
  thus "x in RAT\<^bsup>\<ge>0\<^bsub> \<union> IR" using xboole_0_def_3[of "RAT\<^bsup>\<ge>0\<^bsub>" IR] all_set by mauto
qed mauto

mtheorem arytm_2_lm_4:
  "DEDEKIND_CUTS \\ RA c= REAL\<^bsup>\<ge>0\<^bsub>"
proof(rule tarski_def_3I[OF all_set all_set],auto)
  fix x assume "x in DEDEKIND_CUTS \\ RA"
  hence "x in RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS" "not x in  RA" using xboole_0_def_3  xboole_0_def_5 by auto
  hence "x in (RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS) \\ RA" using xboole_0_def_5 all_set by auto
  thus "x in REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_def_2 by auto 
 qed

mtheorem
  "cluster REAL\<^bsup>\<ge>0\<^bsub> \<rightarrow> non empty"
proof
  have "{} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mauto
  hence "{} in REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_1 tarski_def_3 by mauto
  thus "REAL\<^bsup>\<ge>0\<^bsub> be non empty" using xboole_0_def_1 by mauto
qed

text_raw {*\DefineSnippet{arytm_2_def_3}{*}
mdef arytm_2_def_3 ("DEDEKIND'_CUT _") where
  mlet "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  "func DEDEKIND_CUT x \<rightarrow> 
      Element-of DEDEKIND_CUTS means
    \<lambda>it. \<exists>r:Element-of RAT\<^bsup>\<ge>0\<^bsub>. x =\<^sub>\<S> r \<and>
      it = {s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r} 
    if x in RAT\<^bsup>\<ge>0\<^bsub> 
    otherwise \<lambda>it. it =\<^sub>\<S> x"
text_raw {*}%EndSnippet*}
proof(auto)
      assume X: "x in RAT\<^bsup>\<ge>0\<^bsub>"
      hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mauto 
      let ?IT = "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x }"
      have A1:"?IT c= RAT\<^bsup>\<ge>0\<^bsub>"
      proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
        fix e
        assume E: "e in ?IT"
        obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         " s = e & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using Fraenkel_A1_ex[OF _ _ E] by mauto
        thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" s] by mauto
      qed mauto
      have "not x in ?IT" 
      proof
        assume E:"x in ?IT"
        obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         " s = x & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using Fraenkel_A1_ex[OF _ _ E] by mauto
        thus False using arytm_3_def_13r by mauto
      qed
      hence
A2:   "?IT <> RAT\<^bsup>\<ge>0\<^bsub>" using X by mauto 
      hence a2:"not ?IT in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by mauto
      have [ty]:"?IT is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using A1 Subset_of_rule by mauto
      have "for t st t in ?IT holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t holds s in ?IT) & (ex s st s in ?IT &
      t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
      proof(rule ballI, intro impI conjI)
        fix t assume [ty]:"t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        F: "t in ?IT"
        hence A3: "t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using  Fraenkel_A1_ex[OF _ _ F,simplified] by mauto
        then obtain s0 where [ty]:"s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" and
A5: "s0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_93[of t x] by mauto
        show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t holds s in ?IT"
        proof(intro ballI impI)
          fix s assume [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
          "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
          hence "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using A3 arytm_3_th_69[of x s t] by mauto
          thus "s in ?IT" using Fraenkel_A1_in by mauto
        qed mauto
        have "s0 in ?IT" using A5 Fraenkel_A1_in by mauto
        thus "ex s st s in ?IT & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A4 A5 bexI[of _ s0] by mauto
      qed mauto
      hence "?IT in IR" using Fraenkel_A1_in by mauto
      hence "?IT in DEDEKIND_CUTS" using a2 arytm_2_def_1 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
             all_set by mauto
      thus [ty]:"?IT is Element-of DEDEKIND_CUTS" using Element(6)[of DEDEKIND_CUTS ?IT] all_set by mauto
    next
      assume "x in RAT\<^bsup>\<ge>0\<^bsub>"
      thus "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mauto
    next
      have A6: "x in REAL\<^bsup>\<ge>0\<^bsub>" using Element(7) by mauto
      assume "not x in RAT\<^bsup>\<ge>0\<^bsub>"
      hence "x in DEDEKIND_CUTS" 
        using A6 xboole_0_def_3[of "RAT\<^bsup>\<ge>0\<^bsub>"  DEDEKIND_CUTS] 
        xboole_0_def_5[of _ RA] arytm_2_def_2 by mauto 
      thus "x be Element-of DEDEKIND_CUTS" using Element(6) by mauto
qed


mtheorem arytm_2_th_2:
  "not (ex y being object st [{},y] in REAL\<^bsup>\<ge>0\<^bsub>)"
proof
  assume "ex y being object st [{},y] in REAL\<^bsup>\<ge>0\<^bsub>"
  then obtain  y where
A1: "[{},y] in REAL\<^bsup>\<ge>0\<^bsub>" by auto
  hence "[{},y] in RAT\<^bsup>\<ge>0\<^bsub> \<union> IR" using arytm_2_lm_3 tarski_def_3 all_set by mty auto
  hence H: "[{},y] in RAT\<^bsup>\<ge>0\<^bsub> or [{},y] in IR" using xboole_0_def_3 all_set 
       by mty auto
  show False
  proof(cases "[{},y] in RAT\<^bsup>\<ge>0\<^bsub>")
    case True
    thus False using arytm_3_th_61 by auto
  next 
    case False
    hence "[{},y] in IR" using H by mty auto
    thus False using arytm_2_lm_1 by mty auto
  qed
qed

mtheorem arytm_2_lm_6: 
  "(for r holds (r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  s ) iff r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t) implies s = t"
proof
  assume
A1: "for r holds r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s iff r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  have "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_13r by auto
  hence 
A2: "t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using  A1 by auto
  have "t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13r by auto
  hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"  using  A1 by auto
  thus "s = t" using  A2 arytm_3_th_66 by auto
qed

text_raw {*\DefineSnippet{arytm_2_def_4}{*}
mdef arytm_2_def_4 ("GLUED _") where
  mlet "x be Element-of DEDEKIND_CUTS"
  "func GLUED x \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub> means
    \<lambda>it. \<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. it = r \<and> 
     (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)
    if \<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. 
      s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r 
    otherwise \<lambda> it. it = x"
text_raw {*}%EndSnippet*}
proof-
  show "((\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<longrightarrow>
     (\<exists>xa :
       Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r))) \<and>
    (\<not> (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<longrightarrow>
     (\<exists>xa : Element-of REAL\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> x))"
  proof
    show "(\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<longrightarrow>
     (\<exists>xa :
       Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r))"
    proof 
      assume "\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
      then obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        A5: "\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" by auto 
      have "r in RAT\<^bsup>\<ge>0\<^bsub>" using Element_of1 by auto
      hence "r in REAL\<^bsup>\<ge>0\<^bsub>" using arytm_2_th_1 all_set tarski_def_3 by mty auto
      hence  [ty]:"r is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using Element_of_rule3 by auto
      show "\<exists>xa : Element-of REAL\<^bsup>\<ge>0\<^bsub>. \<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)"
      proof(rule bexI[of _ r],rule bexI[of _ r])
        show "r =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)" using A5 by auto
      qed mauto
    qed
    show "\<not> (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<longrightarrow>
     (\<exists>xa : Element-of REAL\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> x)"
    proof
      assume A6: "\<not> (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)"
      have A: "x in DEDEKIND_CUTS" using Element_of1 by auto
      have "\<not> x in RA"
      proof
        assume A: "x in RA"
        obtain  t where [ty]:"t be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A7:       "x = { s  where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t}" and
          "t <> {}" using Fraenkel_A1_ex[OF _ _ A] by auto
        have "for s holds s in x iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
          proof(rule ballI,rule iffI3)
            fix s assume [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
            show "s in x implies s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
            proof
              assume "s in x"
              hence A:"s in { s1  where s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t}" using A7 by auto
              thus "s<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using Fraenkel_A1_ex[OF _ _ A,simplified] by auto
            qed 
            assume "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
            thus "s in x" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s ] A7 by auto
          qed mauto
          hence "\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" 
            using bexI[of _ t] by mty auto
          thus False using A6 by auto
        qed      
        hence  "x in DEDEKIND_CUTS \\ RA" using A xboole_0_def_5 by mty auto
        hence "x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using  arytm_2_lm_4 Element(6)[of "REAL\<^bsup>\<ge>0\<^bsub>"] tarski_def_3
          all_set  by mty auto
        thus "\<exists>xa : Element-of REAL\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> x" using bexI[of _ x] by mauto
    qed
  qed

  fix xa y assume [ty]: "xa be Element-of REAL\<^bsup>\<ge>0\<^bsub>" "y be Element-of REAL\<^bsup>\<ge>0\<^bsub>"

  show "((\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<and>
        (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)) \<and>
        (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. y =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)) \<longrightarrow>
        xa =\<^sub>\<S> y) \<and>
       (\<not> (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<and> xa =\<^sub>\<S> x \<and> y =\<^sub>\<S> x \<longrightarrow>
        xa =\<^sub>\<S> y)"
  proof(intro conjI impI)
    assume  AS: "(\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) \<and>
             (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. xa =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r))\<and>
             (\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. y =\<^sub>\<S> r \<and> (\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r))"
    obtain r1 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     R1: "xa =\<^sub>\<S> r1" "\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" using AS by auto
    obtain r2 where [ty]:"r2 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     R2: "y =\<^sub>\<S> r2" "\<forall>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s in x \<longleftrightarrow> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2" using AS by auto
    have "for s holds s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2" using R1(2) R2(2) by auto
    thus "xa=y" using arytm_2_lm_6[of r2 r1] R1(1) R2(1) by mty auto
   qed mauto
 qed mauto 
  

mtheorem arytm_2_lm_7: 
  "for B being Element-of DEDEKIND_CUTS st r in B (ex s st s in B & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
proof(intro ballI impI)
  fix B assume [ty]:"B be Element-of DEDEKIND_CUTS"
  hence AS1:"B in DEDEKIND_CUTS" using Element(7) by auto
  assume AS: "r in B"
  hence B: "B in IR" using arytm_2_def_1 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}" B] all_set AS1 by mty auto
  have "ex A being Subset-of RAT\<^bsup>\<ge>0\<^bsub> st B = A & (for t st t in A holds (for s st s
  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t holds s in A) & (ex s st s in A & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s))" using  Fraenkel_A1_ex[OF _ _ B] by mty auto
  then show "ex s st s in B & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using AS by auto
qed mauto

mtheorem arytm_2_lm_7f: 
  "for B being Element-of DEDEKIND_CUTS st r in B & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in B"
proof(intro ballI impI)
  fix B assume [ty]:"B be Element-of DEDEKIND_CUTS"
  hence"B in DEDEKIND_CUTS" using Element(7) by auto
  hence B: "B in IR" using arytm_2_def_1 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}" B] all_set by mty auto
  assume AS: "r in B \<and> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  obtain A where [ty]:"A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A: " B = A "" (for t st t in A holds (for s st s
  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t holds s in A) & (ex s st s in A & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s))" using  Fraenkel_A1_ex[OF _ _ B] by mty auto
  hence H:"for t st t in A holds (for s st s
  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t holds s in A)" by auto
  have "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A" using H[THEN bspec,of r,simplified] A(1) AS by mty auto
  then show "s in B" using AS A by mty auto
qed mauto

mtheorem arytm_2_lm_8:
 "{} in DEDEKIND_CUTS"
proof-
  have "{} c= RAT\<^bsup>\<ge>0\<^bsub>" using  all_set tarski_def_3 xb by mty auto
  hence [ty]: "{} is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by auto
  have "for r holds (r in {} implies 
    (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in {}) & (ex s st s in {} & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s))" using xb by auto
  hence H: "{} in IR"
    using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" "{}"] by mty auto
  have "{}<>RAT\<^bsup>\<ge>0\<^bsub>" using arytm_3_th_74 xb by  auto
  hence "not {} in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by auto
  thus  "{} in DEDEKIND_CUTS" using H xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}" "{}"] 
     arytm_2_def_1 all_set by mty auto
qed

mtheorem cDR:
  "cluster Element-of DEDEKIND_CUTS \<rightarrow> Subset-of RAT\<^bsup>\<ge>0\<^bsub> for object"
proof(standard,auto)
  have H: "DEDEKIND_CUTS c= bool (RAT\<^bsup>\<ge>0\<^bsub>)" using Subset_in_rule by auto
  fix x assume "x be Element-of DEDEKIND_CUTS"
  hence "x in DEDEKIND_CUTS" using Element(7) by mty auto
  hence "x c= RAT\<^bsup>\<ge>0\<^bsub>" using H tarski_def_3 zfmisc_1_def_1[of "RAT\<^bsup>\<ge>0\<^bsub>" x] all_set by mty auto 
  thus "x is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule H tarski_def_3 by mty auto
qed mauto

mtheorem arytm_2_lm_9:
 "DEDEKIND_CUTS \<inter> RAT\<^bsup>\<ge>0\<^bsub> = {{}}"
proof(standard,auto)
  fix e 
  assume A1:"e in DEDEKIND_CUTS \<inter> RAT\<^bsup>\<ge>0\<^bsub>"
  have "e={}"                                                    
  proof(rule ccontr)
    assume A2: "e <> {}"
     have H: "DEDEKIND_CUTS c= bool (RAT\<^bsup>\<ge>0\<^bsub>)" using Subset_in_rule by auto
     have H1: "e in DEDEKIND_CUTS" "e in RAT\<^bsup>\<ge>0\<^bsub>" using A1 xboole_0_def_4 by auto
     hence [ty]: "e is Element-of DEDEKIND_CUTS" using Element(6) by auto
    obtain s where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3:   "s in e & (for r st r in e holds r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)" using arytm_3_th_91[of e] H1(2) A2 by mty auto
    thus False using arytm_2_lm_7[of s e] H1 all_set by mty auto
  qed
  thus "e in {{}}" using tarski_def_1 by auto
next
  fix e
  assume "e in {{}}"
  hence "e={}" using tarski_def_1 by auto
  hence "e in RAT\<^bsup>\<ge>0\<^bsub>" "e in DEDEKIND_CUTS" using arytm_2_lm_8 Element(7) by mty auto
  thus "e in DEDEKIND_CUTS \<inter> RAT\<^bsup>\<ge>0\<^bsub>" using xboole_0_def_4 by auto
qed

mtheorem arytm_2_lm_10:
  "DEDEKIND_CUT x = {} iff x = {}"
proof
  assume AS: "DEDEKIND_CUT x = {}"
  show "x={}"
  proof(cases "x in RAT\<^bsup>\<ge>0\<^bsub>")
    case A4: True
    show "x={}"
    proof(rule ccontr)
      assume A5: "x<>{}"
      obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6:   "x = r" and
A7:   "DEDEKIND_CUT x = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r }" using A4 arytm_2_def_3[of x] 
         by mty auto
      have "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_64 by auto
      hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A6 A5 arytm_3_th_68 by mty auto
      hence "{} in DEDEKIND_CUT x" using A7 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}"] by mty auto
      thus False using AS xb by auto
    qed
  next
    case False
      thus "x={}" using AS arytm_2_def_3 by mty auto
  qed
next
  assume AS:"x={}"
  hence "x in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  then obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
  A6:   "x = r" and
  A7:   "DEDEKIND_CUT x = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r }" using arytm_2_def_3[of x] 
   by mty auto
  show "DEDEKIND_CUT x={}"
  proof(rule ccontr)
    assume "DEDEKIND_CUT x \<noteq> {}"
    hence "DEDEKIND_CUT x is non empty"
       using xboole_0_lm_1[of "DEDEKIND_CUT x"] xboole_0_def_1 by mauto
    then obtain y where
       A:"y in DEDEKIND_CUT x" using xboole_0_def_1 by mty auto
    obtain s where [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      B:"y=s & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A A7  Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
    thus False using AS A6 B using arytm_3_th_64 by mty auto
  qed
qed


mtheorem arytm_2_lm_11:
  "for A being Element-of DEDEKIND_CUTS holds GLUED A = {} iff A = {}"
proof(rule ballI, rule iffI3)
  fix  A assume [ty]:"A be Element-of DEDEKIND_CUTS"
  show "GLUED A = {} implies A = {}"
  proof(rule impI,cases "ex r st for s holds s in A iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r",rule ccontr)
    case A2:True
    assume A1: "GLUED A =\<^sub>\<S> {}" "A<>{}"
    hence "A is non empty"
       using xboole_0_lm_1[of A] xboole_0_def_1 by mauto
     then obtain r where        
A3:   "r in A" using xboole_0_def_1 by auto
      have "A c= RAT\<^bsup>\<ge>0\<^bsub>" using Subset_in_rule by mty auto
      hence "r in RAT\<^bsup>\<ge>0\<^bsub>" using A3 tarski_def_3 by mty auto
     hence [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6)[of "RAT\<^bsup>\<ge>0\<^bsub>" r] by mty auto
     obtain r1 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     A4:    " GLUED A = r1 & (for s holds s in A iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1)" 
       using A2 arytm_2_def_4[of A,THEN conjunct1] by auto
     hence "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using  A1 A3 by mty auto      
     thus False using arytm_3_th_64 by mty auto
  next
    case F:False 
    assume "GLUED A =\<^sub>\<S> {}"
    thus "A = {}" using arytm_2_def_4[of A] F by auto
  qed
  assume A4: "A = {}"
  hence "for s holds s in A iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using arytm_3_th_64 xb by mty auto
  then obtain r where [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A5: "GLUED A = r" and
A6: "for s holds s in A iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using bexI[of _ "{}"] arytm_2_def_4[of A] by mty auto
  show "GLUED A = {}"
  proof(rule ccontr)
    assume A7: "GLUED A <> {}"
    have "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using  arytm_3_th_64 by mty auto
    hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using  A5 A7 arytm_3_th_68 by mty auto
    thus False using A4 A6 xb by mty auto
  qed
qed mauto

mtheorem arytm_2_lm_12:
  "for A being Element-of DEDEKIND_CUTS holds DEDEKIND_CUT GLUED A = A"
proof
  fix A assume [ty]:"A be Element-of DEDEKIND_CUTS"
  show "DEDEKIND_CUT GLUED A = A"
  proof(cases "ex r st for s holds s in A iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r")
    case True
     then obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "GLUED A = r" and
A2: "for s holds s in A iff s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_2_def_4[of A] by mty auto
     have "r in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mauto
     then obtain s where
A3: "r = s" and
A4: "DEDEKIND_CUT GLUED A = { t where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s }" 
       using A1 arytm_2_def_3[of r] by mty auto
     show "DEDEKIND_CUT GLUED A = A"
     proof(intro xboole_0_def_10I tarski_def_3I,auto)
       fix e
      assume "e in DEDEKIND_CUT GLUED A"
      then obtain t where [ty]:"t be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        "t = e & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A4 Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
      thus "e in A" using A2 A3 by mty auto
    next 
        fix e
        assume E: "e in A"
        have "A c= RAT\<^bsup>\<ge>0\<^bsub>" using Subset_in_rule by mty auto
        hence "e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using E Element(6) tarski_def_3 by mty auto
        show "\<And>x. x in A \<Longrightarrow> x in DEDEKIND_CUT GLUED A"
        proof-
          fix e assume A: "e in A "
          hence [ty]:"e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto            
          have "e <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A A2 by mty auto
          thus "e in DEDEKIND_CUT GLUED A" 
             using A3 A4 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" e "\<lambda>t. t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "\<lambda>t. t"] 
             by mty auto
        qed
     qed mauto
   next case A8:False 
     show "DEDEKIND_CUT GLUED A = A"
     proof(cases "A={}")
       case A6: True
         hence "GLUED A = {}" using arytm_2_lm_11[of A,simplified] by auto
         thus "DEDEKIND_CUT GLUED A = A" using A6 arytm_2_lm_10[of A,simplified] by mty auto
     next
        case A7: False 
        have A9: "GLUED A = A" using A8 arytm_2_def_4 by mauto
        have [ty]: "GLUED A be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
        have "not GLUED A in RAT\<^bsup>\<ge>0\<^bsub>"
        proof
            assume "GLUED A in RAT\<^bsup>\<ge>0\<^bsub>"
            hence  "GLUED A in DEDEKIND_CUTS \<inter> RAT\<^bsup>\<ge>0\<^bsub>" 
              using A9 xboole_0_def_4 Element(7)[of "DEDEKIND_CUTS" A]by mty auto
            hence  "GLUED A = {}" using arytm_2_lm_9 tarski_def_1[of "{}" "GLUED A"] by mty auto
            thus False using A7 arytm_2_lm_11 by auto
        qed
        thus "DEDEKIND_CUT GLUED A = A" using A9 arytm_2_def_3[of "GLUED A",simplified] by mty auto
      qed
    qed
  qed mauto

mtheorem arytm_2_lm_13:
  "for x,y be set st x in IR & y in IR holds x c= y or y c= x"
proof(intro ballI impI )
  fix x y assume [ty]:"x be set" "y be set"
  have "sethood_prop(Subset-of RAT\<^bsup>\<ge>0\<^bsub>)" by mty auto
  assume X: "x in IR\<and> y in IR"
  then obtain A9 where [ty]: "A9 be Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A9:"x = A9" "for r holds r in A9 implies 
         ((for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A9) & (ex s st s in A9 & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s))" 
    using Fraenkel_A1_ex[OF _ _ X[THEN conjunct1]] by mty auto
  then obtain B9 where [ty]:"B9 be Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
    B9:"y = B9" "for r holds r in B9 implies 
         ((for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in B9) & (ex s st s in B9 & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s))" 
     using Fraenkel_A1_ex[OF _ _ X[THEN conjunct2]] by mty auto

   show "x c= y or y c= x" 
 proof(auto)

   assume "\<not> y \<subseteq> x" 
  then obtain s where 
A3: "s in y" and
A4: "not s in x" using tarski_def_3[of y x,OF all_set all_set]  by auto
  have "s in RAT\<^bsup>\<ge>0\<^bsub>" using Subset_in_rule[of B9 "RAT\<^bsup>\<ge>0\<^bsub>"] A3 B9 tarski_def_3 all_set by mty auto
  hence [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using B9 A3 Element(6) all_set by auto
  show "x \<subseteq> y"
  proof(standard,auto)
    fix e
    assume
A5: "e in x"
    have "e in RAT\<^bsup>\<ge>0\<^bsub>" using Subset_in_rule[of A9 "RAT\<^bsup>\<ge>0\<^bsub>"] A5 A9 tarski_def_3 all_set by mty auto
    hence [ty]: "e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using B9 A3 Element(6) all_set by auto

    have  "not s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using  A9(1) A9(2)[THEN bspec,of e]  A3 A4 A5 by mty auto
    hence "e \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_13c[of e s] by mty auto
    thus "e in y"  using B9(1) B9(2)[THEN bspec,of s]  A3 by mty auto
  qed
qed 
qed mauto

mdef arytm_2_def_5 ("_ \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> _ " [41,40]40) where
  mlet "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "y be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  "pred x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y means
  ex x9,y9 st x = x9 & y = y9 & x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 
    if x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub>, 
  x in y 
    if x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub>, 
  not y in x 
    if not x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> 
    otherwise 
  x c= y"
  by(standard,auto)

reserve x,y for "Element-of REAL\<^bsup>\<ge>0\<^bsub>"

lemma arytm_2_def_5i:
  assumes [ty]:"x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" "y is Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  shows  "x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y\<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
         "x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub> & x in y \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
         "(not x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & not y in x) \<Longrightarrow> (x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y)"
         "(not x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub> &  x c= y) \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
proof-
  show "x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof-
    assume A:"x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"
    hence [ty]: "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mty auto
    have "ex y1 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st y=y1 & x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y1" using bexI[of _ y] A by mty auto
    hence "ex x1,y1 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st x=x1 & y=y1 & x1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y1" using bexI[of _ y] A by mty auto
    thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_5I[of x y] A by mty auto 
    qed 
  show "x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub> & x in y \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_5[of x y] by mty auto
  show "not x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & not y in x \<Longrightarrow> (x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y)" using arytm_2_def_5[of x y] by mty auto
  show  "(not x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub> &  x c= y) \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_5[of x y] by mty auto
qed

mtheorem arytm_2_def_5r:
 "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof(standard,auto)
  assume "x in RAT\<^bsup>\<ge>0\<^bsub>" thus [ty]:"x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mty auto
  show "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x" using arytm_3_def_13r[of x] by mty auto
next
  assume "\<not> x \<subseteq> x"
  thus "x in RAT\<^bsup>\<ge>0\<^bsub>" "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using xboole_0_def_10[of x] all_set by mty auto
qed

mtheorem arytm_2_def_5c:
  "y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x \<or> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" 
proof(auto)
  assume " \<not> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  hence A1: "not ((x in RAT\<^bsup>\<ge>0\<^bsub> \<and> y in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow>
 (\<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<exists>y9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. x =\<^sub>\<S> x9 \<and> y =\<^sub>\<S> y9 \<and> x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 )) \<and>
(x in RAT\<^bsup>\<ge>0\<^bsub> \<and> \<not> y in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> x in y) \<and>
(\<not> x in RAT\<^bsup>\<ge>0\<^bsub> \<and> y in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> \<not> y in x) \<and>
((x in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> \<not> y in RAT\<^bsup>\<ge>0\<^bsub>) \<and> (x in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> y in RAT\<^bsup>\<ge>0\<^bsub>) \<and> (x in RAT\<^bsup>\<ge>0\<^bsub> \<or> \<not> y in RAT\<^bsup>\<ge>0\<^bsub>) \<longrightarrow> x \<subseteq> y))"
    using arytm_2_def_5[of x y] by auto
  show "y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
  proof(standard,simp,simp,cases "y in RAT\<^bsup>\<ge>0\<^bsub>",simp)
    case T:True 
      have C1: "x in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> y be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<and> x be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<and> y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
      proof(auto)
        assume X: "x in RAT\<^bsup>\<ge>0\<^bsub>"
        thus [ty]:"y be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using T Element(6) by mty auto 
        hence "not x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A1 T X by auto
        thus "y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13c[of x y] by mty auto
       qed
       thus "x in RAT\<^bsup>\<ge>0\<^bsub> \<and> y be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<and> x be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<and> y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x  \<or>
    \<not> x in RAT\<^bsup>\<ge>0\<^bsub> \<and> y in x \<or> \<not> x in RAT\<^bsup>\<ge>0\<^bsub> \<and> x in RAT\<^bsup>\<ge>0\<^bsub> \<and> y \<subseteq> x" using A1 T by auto
  next
    case False
    then show "(y in RAT\<^bsup>\<ge>0\<^bsub> \<and> x in RAT\<^bsup>\<ge>0\<^bsub>) \<and>
    (\<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<exists>y9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. y =\<^sub>\<S> x9 \<and> x =\<^sub>\<S> y9 \<and> x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 ) \<or>
    (y in RAT\<^bsup>\<ge>0\<^bsub> \<and> \<not> x in RAT\<^bsup>\<ge>0\<^bsub>) \<and> y in x \<or>
    (\<not> y in RAT\<^bsup>\<ge>0\<^bsub> \<and> x in RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<not> x in y \<or>
    \<not> (y in RAT\<^bsup>\<ge>0\<^bsub> \<and> x in RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (y in RAT\<^bsup>\<ge>0\<^bsub> \<and> \<not> x in RAT\<^bsup>\<ge>0\<^bsub>) \<and> \<not> (\<not> y in RAT\<^bsup>\<ge>0\<^bsub> \<and> x in RAT\<^bsup>\<ge>0\<^bsub>) \<and> y \<subseteq> x"
    proof(simp)
      assume A: "not y in RAT\<^bsup>\<ge>0\<^bsub>"
      have C1: "x in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> \<not> x in y" using A1 A by auto
      have  "not x in RAT\<^bsup>\<ge>0\<^bsub> \<longrightarrow> y c= x"
      proof
        assume A2: "not x in RAT\<^bsup>\<ge>0\<^bsub>"       
        hence G: "not x \<subseteq> y" using A1 A by mty auto
          have "y in REAL\<^bsup>\<ge>0\<^bsub>" "x in REAL\<^bsup>\<ge>0\<^bsub>" "REAL\<^bsup>\<ge>0\<^bsub> \<subseteq> RAT\<^bsup>\<ge>0\<^bsub> \<union> IR" using Element(7) arytm_2_lm_3 by mty auto
          hence "x in RAT\<^bsup>\<ge>0\<^bsub> \<union> IR" "y in RAT\<^bsup>\<ge>0\<^bsub> \<union> IR" using tarski_def_3  all_set  by mty auto
          hence "x in IR" "y in IR" using A A2 xboole_0_def_3[of "RAT\<^bsup>\<ge>0\<^bsub>" IR] all_set  by mty auto
          thus "y \<subseteq> x" using arytm_2_lm_13[of x y] G by auto
        qed
      thus "x in RAT\<^bsup>\<ge>0\<^bsub> \<and> \<not> x in y \<or> \<not> x in RAT\<^bsup>\<ge>0\<^bsub> \<and> y \<subseteq> x" using C1 by auto
    qed
  qed
qed
                                
abbreviation lessr ("_ <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> _" [51,50] 50) where
  "y <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x \<equiv> \<not> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"

mtheorem arytm_2_lm_14:
  "x = x9 & y = y9 implies (x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y iff x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9)"
proof(rule impI, rule iffI2)
  assume
A1: "x = x9 & y = y9"
  have X:"x9 in RAT\<^bsup>\<ge>0\<^bsub>" "y9 in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  show "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y  \<longrightarrow> x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9"
  proof
    assume "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
    then obtain x91 y91 where
      "x = x91 & y = y91 & x91 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y91" using  A1 arytm_2_def_5[of x y] X by auto 
    thus "x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9" using A1 by auto
  qed
  show "x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9  \<longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A1 X arytm_2_def_5 by auto
qed

mtheorem arytm_2_lm_15:
  "for B being set st B in DEDEKIND_CUTS & B <> {} ex r st r in B & r <> {}"
proof(intro ballI impI)
  fix B assume [ty]:"B be set" and
A1: "B in DEDEKIND_CUTS \<and> B <> {}"
  hence B:"B in IR" unfolding arytm_2_def_1 using xboole_0_def_5 all_set by mty auto
  obtain A where AA[ty]:"A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "B = A" and
A4: "for r holds r in A implies (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
    using Fraenkel_A1_ex[OF _ _ B] by mty auto    
  have [ty]: "A is non empty\<bar>set" using A1 A3 xboole_0_lm_1[of A] all_set by mty auto
  then obtain r0 where
A5: "r0 in A" using xboole_0_def_1[of A] by auto
  have [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES  A5 by auto
  obtain r1 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6: "r1 in A" and
A7: "r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" using A4[THEN bspec, of r0] A5 by mty auto
  have "r1 <> {} or r0 <> {}" using A7 arytm_3_th_68 by mty auto
  hence A8:"\<exists>t : Element-of RAT\<^bsup>\<ge>0\<^bsub>. t in A \<and> t \<noteq> {}" using A5 A6 bexI[of _ r1] bexI[of _ r0] by mty auto

  have H:"\<And>r s. r be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> s be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> r in A \<Longrightarrow> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r  \<Longrightarrow> s in A"
   proof-
     fix r s assume [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
   and "r in A" "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
     thus "s in A" using  A4[THEN bspec, of r] by auto
   qed mauto
   have " ex r1,r2,r3 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r1 in A & r2
  in A & r3 in A & r1 <> r2 & r2 <> r3 & r3 <> r1"  
     using  arytm_3_th_75[OF AA A8] H  by blast
  then obtain r1 r2 r3 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  "r2 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A9: "r1 in A & r2 in A" and
  "r3 in A" and
A10: "r1 <> r2" and
  "r2 <> r3 &
  r3 <> r1"  by auto
  have "r1 <> {} or r2 <> {}" using A10 by auto
  thus "\<exists>r : Element-of RAT\<^bsup>\<ge>0\<^bsub>. r in B \<and> r \<noteq> {}" using A3 A9 bexI by auto
qed mauto

mtheorem arytm_2_lm_16:
 "for B being set holds B in DEDEKIND_CUTS & r in B & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r implies s in B"
proof(intro ballI impI)
  fix B assume [ty]:"B be set" and
A1: "B in DEDEKIND_CUTS \<and> r in B \<and> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  have B: "B in IR" using arytm_2_def_1 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}"] all_set using A1 by mty auto
  obtain A where [ty]: "A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A2: "B = A " "for t st t in A holds (for s st s
  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t holds s in A) & (ex s st s in A & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)" using Fraenkel_A1_ex[OF _ _ B] by mty auto
  show "s in B" using A2(2)[THEN bspec, of r] A2(1) A1 by mty auto
qed mauto


mtheorem arytm_2_lm_17:
  "for B being set st B in DEDEKIND_CUTS & B <> {} holds {} in B"
proof(intro ballI impI)
  fix B assume [ty]:"B be set" and
A1: "B in DEDEKIND_CUTS & B <> {}"
  hence [ty]: "B is Element-of DEDEKIND_CUTS" using Element(6) by mty auto
  have [ty]:"B is non empty" using A1 xboole_0_lm_1 by mty auto
  obtain r where
    R:"r in B" using xboole_0_def_1[of B] all_set by mty auto
  hence [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[of r B "RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
  thus "{} in B" using A1 R arytm_2_lm_16[of "{}" r B,simplified] 
   arytm_3_th_64[of r,simplified] by mty auto
qed mauto

mtheorem arytm_2_lm_18:
  "for B being set st B in DEDEKIND_CUTS \\ RA & not r in B & B <> {} 
     (ex s st not s in B & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)"
proof(intro ballI impI)
  fix B assume "B is set" and
A1: "B in DEDEKIND_CUTS \\ RA & not r in B & B <> {}"
  have A4: "B in DEDEKIND_CUTS" using A1 xboole_0_def_5 by mty auto
  hence [ty]: "B is Element-of DEDEKIND_CUTS" using Element(6) by mty auto
  show "ex s st not s in B & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  proof(rule ccontr)
    assume A5: "\<not> (\<exists>s : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<not> s in B \<and> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r)"
    have A6: "B = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r}"
    proof(rule xboole_0_def_10I)
      show " B c= { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r}"
      proof(standard, auto)
        fix e assume A7:"e in B"
        hence [ty]:"e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
        have "not r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> e" using A1 A4 A7 arytm_2_lm_16[of _ e B] by mty auto
        hence "e <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" by mty auto
        thus "e in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r}" 
          using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" e "\<lambda>s. s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "\<lambda>s. s",simplified] by simp
      qed mauto
      show "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r} c= B"
      proof(standard, auto)
        fix e assume E:"e in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r}"
        have "e is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "e <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using Fraenkel_A1_ex[OF _ _ E] 
           by mty auto       
         thus "e in B" using A5 by auto
      qed mauto
    qed mauto

    have "r <> {}" using A1 A4 arytm_2_lm_17 by mty auto
    hence "B in RA" using A6 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r] by mty auto
    thus False  using A1 xboole_0_def_5 by mty auto
  qed
qed mauto

mtheorem arytm_2_lm_19:
  "DEDEKIND_CUT x in RA implies x in RAT\<^bsup>\<ge>0\<^bsub>"
proof(rule impI, rule ccontr)
  assume
A1: "DEDEKIND_CUT x in RA"
  have X:"x in REAL\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  assume "not x in RAT\<^bsup>\<ge>0\<^bsub>"
  hence "DEDEKIND_CUT x = x" using arytm_2_def_3 by mty auto
  thus False using A1 xboole_0_def_5[of "RAT\<^bsup>\<ge>0\<^bsub> \<union> DEDEKIND_CUTS" RA x] 
   arytm_2_def_2 X all_set by mty auto
qed


mtheorem arytm_2_lm_20:
 " DEDEKIND_CUT x c= DEDEKIND_CUT y implies x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
proof
  assume
A1: "DEDEKIND_CUT x c= DEDEKIND_CUT y"

  have [ty]:"{} is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
    hence E:"{} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
    have [ty]:"{} is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto

  have T1: "x={} & not y in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof-
    assume A2: "x={} & not y in RAT\<^bsup>\<ge>0\<^bsub>"
    hence "DEDEKIND_CUT y = y & y <> {}" using  A2 arytm_2_def_3[of y] E by mty auto 
    hence "x in y" using A2 arytm_2_lm_17[of "DEDEKIND_CUT y"] 
          Element(7)[of "DEDEKIND_CUTS" "DEDEKIND_CUT y",simplified] by mty auto
    thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A2 arytm_2_def_5i(2)[of "{}" y,simplified] E by mty auto
  qed
  have T2: "y={} \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof-
    assume A4: "y={}"
    hence "DEDEKIND_CUT y = {}" using arytm_2_lm_10 by auto
    hence "DEDEKIND_CUT x = {}" using xboole_1_empty[OF _ _ A1] by auto
    hence "x={}" using arytm_2_lm_10 by auto
    thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A4 arytm_2_lm_14[of "{}" "{}"] arytm_3_def_13r[of "{}"] by mty auto
  qed
  have T3:" x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof-
    assume A5:" x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub>"
    obtain ry where [ty]:"ry is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A7: "y = ry" and
A8: "DEDEKIND_CUT y = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ry }" 
      using arytm_2_def_3[of y,simplified] A5 by mty auto
   obtain rx where [ty]:"rx is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A9: "x = rx" and
A10: "DEDEKIND_CUT x = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rx }" 
     using arytm_2_def_3[of x,simplified] A5 by mty auto
     show "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
     proof(rule ccontr)
        assume "y <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
        hence "ry <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rx" using A9 A7 arytm_2_lm_14[of ry] by mty auto
        hence "ry in DEDEKIND_CUT x" using A10 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" ry] by mty auto
        hence "ry in DEDEKIND_CUT y" using A1 tarski_def_3 by auto
        hence "ex s st s = ry & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ry" using Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" ry] A8 by mty auto
        thus False using arytm_3_def_13r[of "ry"]  by auto
     qed
  qed
  have T4:"x in RAT\<^bsup>\<ge>0\<^bsub> &  not y in RAT\<^bsup>\<ge>0\<^bsub> & x <> {} \<Longrightarrow>  x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof-
    assume A11:"x in RAT\<^bsup>\<ge>0\<^bsub> &  not y in RAT\<^bsup>\<ge>0\<^bsub> & x <> {}"
    hence A14: "DEDEKIND_CUT y = y" using arytm_2_def_3 by auto
    obtain rx where [ty]: "rx be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A15: "x = rx" and
A16: "DEDEKIND_CUT x = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rx }" 
      using A11 arytm_2_def_3[of x] by auto 
    hence "DEDEKIND_CUT x in RA" using A11 A15 A16 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" rx]
      by mty  auto
    hence "DEDEKIND_CUT x <> y" using  A11 A14 arytm_2_lm_19[of y] by mty auto
    hence "not DEDEKIND_CUT y c= DEDEKIND_CUT x" 
      using A1 A14 xboole_0_def_10[of "DEDEKIND_CUT y" "DEDEKIND_CUT x"] by mty auto
    then obtain r0 where "r0 is object" and
A17: "r0 in y" and
A18: "not r0 in DEDEKIND_CUT x" using A14 tarski_def_3 by mty auto
    have [ty]: "r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using A17 A14 ES[of r0 "DEDEKIND_CUT y" "RAT\<^bsup>\<ge>0\<^bsub>",
      simplified] by mty auto
    have "rx \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using A16 A18 
      Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r0 "\<lambda>s. s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rx" "\<lambda>s. s"] 
      by mty auto
    hence "x in y" using A15 A14 A17 arytm_2_lm_16[of x r0 "DEDEKIND_CUT y"] 
        Element(7)[of "DEDEKIND_CUTS" "DEDEKIND_CUT y",simplified] by mty auto
    thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A11 arytm_2_def_5i[of x y] by mty auto 
  qed
  have T5:"not x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & y <> {} \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof-
    assume A21: "not x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> & y <> {}"
    obtain ry where [ty]:"ry be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
A22: "y = ry" and
A23: "DEDEKIND_CUT y = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ry }" 
      using A21 arytm_2_def_3[of  y] by auto
    have  
A24: "DEDEKIND_CUT y in RA" using A21 A22 A23  Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" y] by mty auto
    have A25: "DEDEKIND_CUT x = x" using A21 arytm_2_def_3 by mty auto 
    hence "not x in RA" using A21 arytm_2_lm_19 by mty auto
    hence "not DEDEKIND_CUT y c= DEDEKIND_CUT x" 
       using A1 A24 A25 xboole_0_def_10[of "DEDEKIND_CUT y" "DEDEKIND_CUT x"] all_set by mty auto
     then obtain r0 where
A26: "r0 in DEDEKIND_CUT y" and
A27: "not r0 in DEDEKIND_CUT x" using A25 tarski_def_3 by auto
     have [ty]: "r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES A26 by mty auto
     have A28:"DEDEKIND_CUT x in DEDEKIND_CUTS" 
       using Element(7)[of "DEDEKIND_CUTS"] all_set by mty auto
     obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
       D: " s = r0 & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ry" using A23 A26 Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto  
     hence S: "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ry" using arytm_3_def_13c[of s ry] by mty auto
     hence "not y in x" using A27
       arytm_2_lm_16[of s ry  "DEDEKIND_CUT x", simplified, OF A28 _ S ] 
       A28 S A25 D A22 by mty auto
     thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A21 arytm_2_def_5i[of x y] by mty auto
   qed
   have " ( not x in RAT\<^bsup>\<ge>0\<^bsub>)& not y in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
   proof-
     assume A28: " not x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub>"
     hence " x = DEDEKIND_CUT x & y = DEDEKIND_CUT y" using arytm_2_def_3 by mty auto
     thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using  A1 A28 arytm_2_def_5i[of x y] by mty auto
   qed
   thus "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using T1 T2 T3 T4 T5 by mty auto
qed

mtheorem arytm_2_lm_21: 
  "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y & y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x implies x = y"
proof
  assume A1: "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y & y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
  have T1:"x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x=y"
  proof-
    assume "x in RAT\<^bsup>\<ge>0\<^bsub> & y in RAT\<^bsup>\<ge>0\<^bsub>"
    hence [ty]: "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
      using Element(6) by mty auto 
    have "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y & y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using A1 arytm_2_lm_14 by auto
    thus "x=y" using arytm_3_th_66 by mty auto
  qed
  have T2:"x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x=y"
  proof-
    assume A3: "x in RAT\<^bsup>\<ge>0\<^bsub> & not y in RAT\<^bsup>\<ge>0\<^bsub>"
    have H:"x in y" using A1 A3 arytm_2_def_5 by mty auto
    have "not x in y" using A1 A3 arytm_2_def_5[of y x,
      THEN iffD1,THEN conjunct2,THEN conjunct2,simplified] by mty auto 
    thus "x=y" using H by simp   
  qed
 have T3:"y in RAT\<^bsup>\<ge>0\<^bsub> & not x in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x=y"
  proof-  
    assume A3: "y in RAT\<^bsup>\<ge>0\<^bsub> & not x in RAT\<^bsup>\<ge>0\<^bsub>"
    have H:"y in x" using A1 A3 arytm_2_def_5 by mty auto
    have "not y in x" using A1 A3 arytm_2_def_5[of x y,
      THEN iffD1,THEN conjunct2,THEN conjunct2,simplified] by mty auto 
    thus "x=y" using H by simp   
  qed
 have "not y in RAT\<^bsup>\<ge>0\<^bsub> & not x in RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> x=y"
  proof-  
    assume A3: "not y in RAT\<^bsup>\<ge>0\<^bsub> & not x in RAT\<^bsup>\<ge>0\<^bsub>"
    have H:"x \<subseteq> y" "y \<subseteq> x" using A1 A3 arytm_2_def_5 by mty auto
    thus "x=y" using xboole_0_def_10 by auto  
  qed
  thus "x=y" using T1 T2 T3 by auto
qed

mtheorem arytm_2_lm_22: 
  "DEDEKIND_CUT x = DEDEKIND_CUT y implies x = y"
proof
  assume "DEDEKIND_CUT x = DEDEKIND_CUT y"
  hence "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y & y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_2_lm_20 xboole_0_def_10 by auto
  thus "x=y" using arytm_2_lm_21 by auto
qed

mtheorem arytm_2_lm_23: 
  "GLUED DEDEKIND_CUT x = x"
proof-
  have "DEDEKIND_CUT GLUED DEDEKIND_CUT x = DEDEKIND_CUT x" using arytm_2_lm_12 by auto
  thus "GLUED DEDEKIND_CUT x = x" using arytm_2_lm_22 by auto
qed

mdef arytm_2_def_6 (infix "+D" 110) where
  mlet "A be Element-of DEDEKIND_CUTS", "B be Element-of DEDEKIND_CUTS" 
  "func A +D B \<rightarrow> Element-of DEDEKIND_CUTS equals
   { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
proof-
  let ?C="{ r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
  have "?C in DEDEKIND_CUTS"
  proof-
    have "?C c= RAT\<^bsup>\<ge>0\<^bsub>"
      proof(standard,simp,simp,intro ballI impI)
        fix e assume E: "e in ?C"
        obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             e: " e = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex[OF _ _ _ _ E] by auto
        have "s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
        thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using e by auto
      qed mauto
      hence [ty]: "?C is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by auto
      have AB: "A in DEDEKIND_CUTS" "B in DEDEKIND_CUTS" 
         using Element(7)[of "DEDEKIND_CUTS"] by mty auto
      hence "not A in {RAT\<^bsup>\<ge>0\<^bsub>}" unfolding arytm_2_def_1 using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
        all_set by mty auto
      hence "A<>RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 by auto 
      hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> A" using xboole_0_def_10 Subset_in_rule by mty auto
      then obtain a0 where
A1:   "a0 in RAT\<^bsup>\<ge>0\<^bsub>" "not a0 in A" using tarski_def_3 by auto 
      hence [ty]:"a0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by auto
      have "for r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r in ?C 
          holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?C) & (ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
      proof(rule  ballI,rule impI,rule conjI)
        fix r assume [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and r: "r in ?C"
        obtain s0 t0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2:     "r = s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" and
A3:     "s0 in A" and
A4:     "t0 in B" using Fraenkel_A2_ex[OF _ _ _ _ r] by mty auto
        show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?C"
        proof(auto)
          fix s 
          assume [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
          then obtain s1 t1 where [ty]:"s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A5:       "s = s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" and
A6:       "s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 & t1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A2 arytm_3_th_87[of t0 s0 s] by mty auto
          have "s1 in A & t1 in B" using A3 A4 A6 arytm_2_lm_16[of s1 s0 A] 
            arytm_2_lm_16[of t1 t0 B] AB by mty auto
          thus "s in ?C" using A5 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s1 t1]
            by mty auto
        qed
        obtain s1 where [ty]: "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A7:     "s1 in A" and
A8:     "s0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" using A3 arytm_2_lm_7[of s0 A] AB by mty auto
        show "ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
        proof(rule bexI[of _ "s1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"],rule conjI)
          show "s1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 in ?C" using A4 A7 Fraenkel_A2_in[of _ _ s1 t0]  by mty auto
          show "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A2 A8 arytm_3_th_76 by mty auto
        qed mauto
      qed mauto
      hence
A9:   "?C in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" ?C] by mty auto
      
      have "not B in {RAT\<^bsup>\<ge>0\<^bsub>}" using AB unfolding arytm_2_def_1 using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
        all_set AB by mty auto
      hence "B <>RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 by auto 
      hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> B" using xboole_0_def_10 Subset_in_rule by mty auto
      then obtain b0 where
A10:   "b0 in RAT\<^bsup>\<ge>0\<^bsub>" "not b0 in B" using tarski_def_3 by auto 
      hence [ty]:"b0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by auto
     
      have "not a0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b0 in ?C"
      proof
        assume A:"a0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b0 in ?C"
        obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        A11: "a0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b0 = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex[OF _ _ _ _ A] by auto
        have "a0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s or b0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A11 arytm_3_th_81 by mty auto
        thus False using A1 A11 A10 arytm_2_lm_16[of a0 s A] arytm_2_lm_16[of b0 t B] AB by mty auto
      qed
      hence "?C <> RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" "a0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b0"] by mty auto
      hence "not ?C in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by auto
      thus "?C in DEDEKIND_CUTS" unfolding arytm_2_def_1 using A9 xboole_0_def_5 all_set by mty auto
  qed
  thus "?C be Element-of DEDEKIND_CUTS" using Element(6) by auto
qed mauto

theorem arytm_2_def_6_c:
  "A be Element-of DEDEKIND_CUTS \<Longrightarrow>
    B be Element-of DEDEKIND_CUTS \<Longrightarrow>  A +D B =  B +D A"
proof(rule xboole_0_def_10I[OF all_set all_set])
  assume [ty]:"A be Element-of DEDEKIND_CUTS" "B be Element-of DEDEKIND_CUTS"
  show"A +D B \<subseteq> B +D A"
  proof(rule tarski_def_3I,auto)
    fix x assume X:"x in A +D B"
    hence X:"x in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
      using arytm_2_def_6[of A B,simplified] by auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      x: " x = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex [OF _ _ _ _ X] by mty auto
    hence "x= t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_11c by auto 
    hence "x in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in B & s in A}
       " using Fraenkel_A2_in[of _ _ t s] x by mty auto 
    thus "x in B +D A" using arytm_2_def_6[of B A,simplified] by auto
  qed mauto


  show"B +D A \<subseteq> A +D B"
  proof(rule tarski_def_3I,auto)
    fix x assume X:"x in B +D A"
    hence X:"x in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in B & s in A}"
      using arytm_2_def_6[of B A,simplified] by auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      x: " x = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in B & t in A" using Fraenkel_A2_ex [OF _ _ _ _ X] by mty auto
    hence "x= t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_11c by auto 
    hence "x in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}
       " using Fraenkel_A2_in[of _ _ t s] x by mty auto 
    thus "x in A +D B" using arytm_2_def_6[of A B,simplified] by auto
  qed mauto
qed


mtheorem arytm_2_lm_24: 
  "for B be Element-of DEDEKIND_CUTS holds ex r st not r in B"
proof
fix A  assume [ty]:"A be Element-of DEDEKIND_CUTS"
  have A: "A in DEDEKIND_CUTS"
     using Element(7)[of "DEDEKIND_CUTS"] by mty auto
  hence "not A in {RAT\<^bsup>\<ge>0\<^bsub>}" unfolding arytm_2_def_1 using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
    all_set by mty auto
  hence "A<>RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 by auto 
  hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> A" using xboole_0_def_10 Subset_in_rule by mty auto
  then obtain a0 where
A1:   "a0 in RAT\<^bsup>\<ge>0\<^bsub>" "not a0 in A" using tarski_def_3 by mty auto 
  hence [ty]:"a0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mty auto
  thus "ex r st not r in A" using bexI[of _ a0] A1 by mty auto     
qed mauto


mdef arytm_2_def_7 (infix "*D" 110) where
  mlet "A be Element-of DEDEKIND_CUTS", "B be Element-of DEDEKIND_CUTS" 
  "func A *D B \<rightarrow> Element-of DEDEKIND_CUTS equals
   { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
proof(standard,auto,cases "A={}")
  case T: True
  have "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}={}"
  proof(rule ccontr)                                                            
    assume "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}<>{}"
    then obtain x where
     X: "x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}" 
      using  xboole_0_th_7 all_set by mty auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             x: " x = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex[OF _ _ _ _ X] by auto
    thus False using x T xb by auto
  qed
  thus "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B} 
      in DEDEKIND_CUTS" using T Element(7)[of "DEDEKIND_CUTS" A,simplified] by mty auto
next
  case A3: False
  let ?C="{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
  show "?C in DEDEKIND_CUTS"
  proof-
    have "?C c= RAT\<^bsup>\<ge>0\<^bsub>"
      proof(standard,simp,simp,intro ballI impI)
        fix e assume E: "e in ?C"
        obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             e: " e = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex[OF _ _ _ _ E] by auto
        have "s*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
        thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using e by auto
      qed mauto
      hence [ty]: "?C is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by auto
      have AB: "A in DEDEKIND_CUTS" "B in DEDEKIND_CUTS" 
         using Element(7)[of "DEDEKIND_CUTS"] by mty auto
      hence "not A in {RAT\<^bsup>\<ge>0\<^bsub>}" unfolding arytm_2_def_1 using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
        all_set by mty auto
      hence "A<>RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 by auto 
      hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> A" using xboole_0_def_10 Subset_in_rule by mty auto
      then obtain a0 where
A1:   "a0 in RAT\<^bsup>\<ge>0\<^bsub>" "not a0 in A" using tarski_def_3 by auto 
      hence [ty]:"a0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by auto
      have "for r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r in ?C 
          holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?C) & (ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
      proof(rule  ballI,rule impI,rule conjI)
        fix r assume [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and r: "r in ?C"
        obtain r0 s0 where [ty]:"r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2:     "r = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" and
A3:     "r0 in A" and
A4:     "s0 in B" using Fraenkel_A2_ex[OF _ _ _ _ r] by mty auto
        show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?C"
        proof(auto)
          fix s 
          assume [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
          then obtain t1 where [ty]: "t1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A5:       "s = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" and
A6:       " t1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A2 arytm_3_th_79[of s0 r0 s] by mty auto
          have "t1 in B" using A4 A6  
            arytm_2_lm_16[of t1 s0 B] AB by mty auto
          thus "s in ?C" using A3 A5 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r0 t1]
            by mty auto
        qed

       obtain t0 where [ty]: "t0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A9:     "t0 in B" and
A10:     "s0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A4 arytm_2_lm_7[of s0 B] AB by mty auto
        show "ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
        proof(cases "r0={}")
         case A11:True
         obtain r1 where [ty]:"r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A12:      "r1 in A" and
A13:      "r1 <> {}" using A3 arytm_2_lm_15[of A] AB xb[of r0] by auto
         show "ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
         proof(rule bexI[of _ "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"],rule conjI)         
           show "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 in ?C" 
              using A9 A12 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r1 t0,simplified] 
              by mty auto
          have "t0 <> {}" using A10 arytm_3_th_64 by mty auto
          hence
A14:      "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 <> {}" using A13 arytm_3_th_78[of t0 r1] by mty auto
          hence 
A15:      "r = {}" using A2 A11 arytm_3_th_48[of s0]  arytm_3_def_12c  by mty auto
          hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using arytm_3_th_64[of "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"] by mty auto
          thus "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A15 A14 arytm_3_th_68 by mty auto
        qed mauto
      next
        case A16:False
          have "s0 <> t0" using A10  arytm_3_def_13r by auto
          hence
A17:      "r <> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A2 A16 arytm_3_th_56[of _ _ r0] by mty auto
        show "ex s st s in ?C & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
         proof(rule bexI[of _ "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"],rule conjI)         
           show "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 in ?C" using A3 A9 Fraenkel_A2_in by auto
           have "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using arytm_3_def_13c[of s0 t0] A2 A10 
             arytm_3_def_12c[of t0 r0]arytm_3_def_12c[of s0 r0]
             arytm_3_th_82[of r0 t0 s0] by mty auto
           thus "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A17 arytm_3_th_68 by mty auto
         qed mauto
       qed
     qed mauto
      hence A18:"?C in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" ?C,simplified] by mty auto  
      obtain r0 where [ty]:"r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A19:  "not r0 in A" using arytm_2_lm_24[of A] by mty auto
      obtain s0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A20:  "not s0 in B" using arytm_2_lm_24[of B] by mty auto
      have "not r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in ?C"
      proof
        assume A:"r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in ?C"
        obtain r s where [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             A21: " r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r in A & s in B" using Fraenkel_A2_ex[OF _ _ _ _ A] by auto
        have "r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r or s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using  A21 arytm_3_th_83 by mty auto
        thus False using A19 A20 A21 arytm_2_lm_16[of r0 r A]  arytm_2_lm_16[of s0 s B] AB 
          by mty auto
      qed
      hence "?C <> RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0"] by mty auto
      hence "not ?C in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by auto
      thus "?C in DEDEKIND_CUTS" unfolding arytm_2_def_1 using A18 xboole_0_def_5 all_set by mty auto
    qed
qed


theorem arytm_2_def_7_c:
  "A be Element-of DEDEKIND_CUTS \<Longrightarrow>
    B be Element-of DEDEKIND_CUTS \<Longrightarrow>  A *D B =  B *D A"
proof(rule xboole_0_def_10I[OF all_set all_set])
  assume [ty]:"A be Element-of DEDEKIND_CUTS" "B be Element-of DEDEKIND_CUTS"
  show"A *D B \<subseteq> B *D A"
  proof(rule tarski_def_3I,auto)
    fix x assume X:"x in A *D B"
    hence X:"x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
      using arytm_2_def_7[of A B,simplified] by auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      x: " x = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in A & t in B" using Fraenkel_A2_ex [OF _ _ _ _ X] by mty auto
    hence "x= t*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_12c by auto 
    hence "x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in B & s in A}
       " using Fraenkel_A2_in[of _ _ t s] x by mty auto 
    thus "x in B *D A" using arytm_2_def_7[of B A,simplified] by auto
  qed mauto

  show"B *D A \<subseteq> A *D B"
  proof(rule tarski_def_3I,auto)
    fix x assume X:"x in B *D A"
    hence X:"x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in B & s in A}"
      using arytm_2_def_7[of B A,simplified] by auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      x: " x = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in B & t in A" using Fraenkel_A2_ex [OF _ _ _ _ X] by mty auto
    hence "x= t*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_12c by auto 
    hence "x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}
       " using Fraenkel_A2_in[of _ _ t s] x by mty auto 
    thus "x in A *D B" using arytm_2_def_7[of A B,simplified] by auto
  qed mauto
qed



mdef arytm_2_def_8 (infix "+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>" 110) where
  mlet "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "y be Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
  "func x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub> equals
     x if (y={}), y if (x={}) otherwise GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y))"
  by (standard, auto)

mtheorem  arytm_2_def_8c:
  "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof(cases "x={} or y={}")
  case True
  thus "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_2_def_8[of x y,simplified]  arytm_2_def_8[of y x,simplified ]
    by mty auto
next
  case F:False
  hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y))" using arytm_2_def_8[of x y,simplified]
    by auto
  hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED((DEDEKIND_CUT y) +D (DEDEKIND_CUT x))" 
    using arytm_2_def_6_c[of "DEDEKIND_CUT y" "DEDEKIND_CUT x"] by mty auto
   thus "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using  F arytm_2_def_8[of y x,simplified ]
    by mty auto
qed

mdef arytm_2_def_9 (infix "*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>" 110) where
  mlet "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>", "y be Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
  "func x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub> equals
     GLUED((DEDEKIND_CUT x) *D (DEDEKIND_CUT y))"
proof-
  show "GLUED((DEDEKIND_CUT x) *D (DEDEKIND_CUT y)) is Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
qed

mtheorem  arytm_2_def_9_c:
  "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof-
  have "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED((DEDEKIND_CUT x) *D (DEDEKIND_CUT y))" using arytm_2_def_9[of x y,simplified]
    by auto
  hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED((DEDEKIND_CUT y) *D (DEDEKIND_CUT x))" 
    using arytm_2_def_7_c[of "DEDEKIND_CUT y" "DEDEKIND_CUT x"] by mty auto
   thus "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using  arytm_2_def_9[of y x,simplified ]
    by mty auto
qed

mtheorem arytm_2_th_4:
  "x = {} implies x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = {}"
proof
  let  ?A = "DEDEKIND_CUT x"
  let ?B = "DEDEKIND_CUT y"
  assume
A1: "x = {}"
  thm arytm_2_lm_11
  have [ty]:"(?A *D ?B) be Element-of DEDEKIND_CUTS" by mty auto
  have " ?A *D ?B ={}"
  proof(rule ccontr)
    assume "?A *D ?B <>{}"
    then obtain ab where
     ab: "ab in ?A *D ?B" using  xboole_0_th_7 all_set by mty auto
    hence X:"ab in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in ?A & s in ?B}"
      using arytm_2_def_7[of ?A ?B,simplified] by mty auto
    obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      x: " ab = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in ?A & t in ?B" using Fraenkel_A2_ex [OF _ _ _ _ X] by mty auto
    thus False using arytm_2_lm_10[of x] A1 xb[of s] by mty auto
  qed
  hence "GLUED( ?A *D ?B) ={}" using arytm_2_lm_11[of "?A *D ?B",simplified] by mty auto
  thus "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = {}" using arytm_2_def_9[of x y] by mty auto
qed

mtheorem arytm_2_th_5:
  "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = {} implies x = {}"
proof
  assume
A1: "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = {}"
  show "x = {}"
  proof(cases "y={}")
    case True
    thus "x={}" using A1 arytm_2_def_8[of x y] by mty auto
  next
    case A2: False
    hence "DEDEKIND_CUT y <> {}" using arytm_2_lm_10 by auto
    then obtain s0 where
A3: "s0 in DEDEKIND_CUT y" using xboole_0_th_7 all_set by mty auto
    hence [ty]:"s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[of s0 "DEDEKIND_CUT y" "RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
    show "x = {}"
    proof(rule ccontr)
    assume
   A4: "x <> {}"
   hence "DEDEKIND_CUT x <> {}" using arytm_2_lm_10 by auto
    then obtain r0 where
A5: "r0 in DEDEKIND_CUT x" using xboole_0_th_7 all_set by mty auto
    hence [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[of r0 "DEDEKIND_CUT x" "RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
    have A6: "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>,s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
      r in DEDEKIND_CUT x & s in DEDEKIND_CUT y }" using  A5 A3 Fraenkel_A2_in[of _ _ r0 s0] by mty auto
    hence "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in (DEDEKIND_CUT x) +D (DEDEKIND_CUT y)"
      using arytm_2_def_6 by mty auto
    hence "GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y)) <> {}"
      using arytm_2_lm_11 xb by mty auto
    thus False using arytm_2_def_8 A1 A2 A4 by mty auto
    qed
  qed
qed


mtheorem arytm_2_th_25: 
  "for A,B,C being Element-of DEDEKIND_CUTS holds A +D (B +D C) c= (A +D B) +D C"
proof(intro ballI,rule tarski_def_3I,auto)
  fix A B C assume [ty]: "A be Element-of DEDEKIND_CUTS" "B be Element-of DEDEKIND_CUTS"
     "C be Element-of DEDEKIND_CUTS"
  show "A +D (B +D C) be set" "(A +D B) +D C be set" by mty auto
  fix e
  assume "e in A +D (B +D C)"
  hence E: "e in Fraenkel2(\<lambda>r s. r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s, Element-of RAT\<^bsup>\<ge>0\<^bsub>, Element-of RAT\<^bsup>\<ge>0\<^bsub>, 
    \<lambda>r s. r in A \<and> s in B +D C)" using arytm_2_def_6[of A "B +D C"] by mty auto
  obtain r0 s0 where [ty]: "r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "e = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 & r0 in A" and
A2: "s0 in B +D C" using Fraenkel_A2_ex[OF _ _ _ _ E] by mty auto
  hence S:"s0 in Fraenkel2(\<lambda>r s. r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s, Element-of RAT\<^bsup>\<ge>0\<^bsub>, Element-of RAT\<^bsup>\<ge>0\<^bsub>, 
    \<lambda>r s. r in B \<and> s in  C)" using arytm_2_def_6[of B C] by mty auto
  obtain r1 s1 where [ty]: "r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "s0 = r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 & r1 in B" and
A4: "s1 in C" using Fraenkel_A2_ex[OF _ _ _ _ S] by mty auto
  have "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 in A +D B" using A1 A3 
     Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r0 r1] arytm_2_def_6[of A B]
    by mty auto
  hence "(r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 in (A +D B) +D C" using A4 
     Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" s1] 
     arytm_2_def_6[of "A +D B" C] by mty auto
  hence "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1) in (A +D B) +D C" using arytm_3_th_51 by mty auto
  thus "e in (A +D B) +D C" using A1 A3 by auto
qed

mtheorem arytm_2_lm_26:
  "for A,B,C being Element-of DEDEKIND_CUTS holds A +D (B +D C) = (A +D B) +D C"
proof(intro ballI,auto,rule xboole_0_def_10I[OF all_set all_set])
  fix A B C assume [ty]: "A be Element-of DEDEKIND_CUTS" "B be Element-of DEDEKIND_CUTS"
     "C be Element-of DEDEKIND_CUTS"
  show "A +D (B +D C) c= (A +D B) +D C" using arytm_2_th_25[of A B C] by mty auto
  show "(A +D B) +D C c= A +D (B +D C)"
  proof(rule tarski_def_3I,auto)
    fix e
    assume "e in (A +D B) +D C"
    hence E: "e in Fraenkel2(\<lambda>r s. r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s, Element-of RAT\<^bsup>\<ge>0\<^bsub>, Element-of RAT\<^bsup>\<ge>0\<^bsub>, 
      \<lambda>r s. r in A +D B \<and> s in  C)" using arytm_2_def_6[of "A +D B" C] by mty auto
    obtain r0 s0 where [ty]: "r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
  A1: "e = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 & r0 in A +D B" and
  A2: "s0 in C" using Fraenkel_A2_ex[OF _ _ _ _ E] by mty auto
    hence S:"r0 in Fraenkel2(\<lambda>r s. r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s, Element-of RAT\<^bsup>\<ge>0\<^bsub>, Element-of RAT\<^bsup>\<ge>0\<^bsub>, 
      \<lambda>r s. r in A \<and> s in  B)" using arytm_2_def_6[of A B] by mty auto
    obtain r1 s1 where [ty]: "r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
  A3: "r0 = r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 & r1 in A" and
  A4: "s1 in B" using Fraenkel_A2_ex[OF _ _ _ _ S] by mty auto
    have "s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in B +D C" using A2 A4 
       Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s1 s0] arytm_2_def_6[of B C]
      by mty auto
    hence "r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) in A +D (B +D C)" using A3 
       Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r1 "s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0"] 
       arytm_2_def_6[of A "B +D C"] by mty auto
    hence "(r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in A +D (B +D C)" using arytm_3_th_51 by mty auto
    thus "e in A +D (B +D C)" using A1 A2 A3 A4 by auto
  qed mauto
qed

mtheorem arytm_2_lm_27:
  "for A,B being Element-of DEDEKIND_CUTS st A +D B = {} holds A={} or B={}"
proof(intro ballI impI,rule ccontr)
   fix A B assume [ty]: "A be Element-of DEDEKIND_CUTS" "B be Element-of DEDEKIND_CUTS"
   and A1:"A +D B =\<^sub>\<S> {}" "\<not> (A =\<^sub>\<S> {} \<or> B =\<^sub>\<S> {})"
   obtain r0 where
A2: "r0 in A" using xboole_0_th_7 A1 all_set by mty auto
   have [ty]: "r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using A2 ES by mty auto
   obtain s0 where
A3: "s0 in B" using xboole_0_th_7 A1 all_set by mty auto
   have [ty]: "s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using A3 ES by mty auto
  have "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in A +D B" using A2 A3 
     Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r0 s0,simplified] 
     arytm_2_def_6[of A B,simplified]
    by mty auto
  thus False using A1 xb by auto
qed mauto


mtheorem arytm_2_th_6:
  "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
proof(cases "x={} or y={} or z={}")
  case T: True
  show "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
  proof(cases "x={}")
    case A1:True
      hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_2_def_8[of "{}"] by mty auto
      thus "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using A1 arytm_2_def_8[of "{}"] by mty auto
    next
      case A1:False 
      show "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
        proof(cases "y={}")
          case A2:True
            hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_2_def_8[of "{}"] by mty auto
            thus "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using A2 arytm_2_def_8[of _ "{}"] by mty auto
          next
            case False
            hence A2: "z={}" using A1 T by auto 
            hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_8[of _ "{}"] by mty auto
            thus "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using A2 arytm_2_def_8[of _ "{}"] by mty auto
        qed
   qed
 next
   case F: False
   have A8: "GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y)) <>{}"
   proof
     assume "GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y)) ={}"
     hence "(DEDEKIND_CUT x) +D (DEDEKIND_CUT y) = {}" using arytm_2_lm_11 by mty auto
     hence "(DEDEKIND_CUT x) ={} or  (DEDEKIND_CUT y) = {}" using arytm_2_lm_27 by mty auto
     thus False using F arytm_2_lm_10[of x] arytm_2_lm_10[of y] by mty auto
   qed
 have A7: "GLUED((DEDEKIND_CUT y) +D (DEDEKIND_CUT z)) <>{}"
   proof
     assume "GLUED((DEDEKIND_CUT y) +D (DEDEKIND_CUT z)) ={}"
     hence "(DEDEKIND_CUT y) +D (DEDEKIND_CUT z) = {}" using arytm_2_lm_11 by mty auto
     hence "(DEDEKIND_CUT y) ={} or  (DEDEKIND_CUT z) = {}" using arytm_2_lm_27 by mty auto
     thus False using F arytm_2_lm_10[of z] arytm_2_lm_10[of y] by mty auto
   qed

   have "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> GLUED((DEDEKIND_CUT y) +D (DEDEKIND_CUT z))"
     using  F arytm_2_def_8 by mty auto
   also have "\<dots> = GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT GLUED((DEDEKIND_CUT y) +D
    (DEDEKIND_CUT z))))" using F A7 arytm_2_def_8 by mty auto
   also have "\<dots>= GLUED((DEDEKIND_CUT x) +D ((DEDEKIND_CUT y) +D (DEDEKIND_CUT z)))" 
       using arytm_2_lm_12 by mty auto
     also have "\<dots>= GLUED(((DEDEKIND_CUT x) +D (DEDEKIND_CUT y)) +D (DEDEKIND_CUT z))"
       using arytm_2_lm_26 by mty auto
    also have "\<dots>= GLUED((DEDEKIND_CUT (GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y)))) +D (DEDEKIND_CUT z))"
       using arytm_2_lm_12 by mty auto
    also have "\<dots>=  (GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT y))) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
      using F A8 arytm_2_def_8 by mty auto
    also have "\<dots>=  (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
      using F arytm_2_def_8 by mty auto
    finally show "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" by mty auto
  qed


theorem arytm_2_lm_34: 
  "for A,B being Element-of DEDEKIND_CUTS st A +D B = A & A <> {} holds B = {}"
proof(intro ballI impI,rule ccontr)
  fix A B assume [ty]:"A is Element-of DEDEKIND_CUTS" "B is Element-of DEDEKIND_CUTS"and
A1: "A +D B = A & A <> {}" and
A3: "B <> {}"
  have a:"A in DEDEKIND_CUTS" and b:"B in DEDEKIND_CUTS" using Element(7)[of "DEDEKIND_CUTS"] 
       by mty auto
  obtain A0 where [ty]:"A0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     A4: "A0 in A & A0<>{}" using a A1 arytm_2_lm_15[of A] by mty auto
  obtain y9 where [ty]: "y9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     A5: "y9 in B" and A6: "y9<>{}" using b A3 arytm_2_lm_15[of B] by mty auto
  let ?P= "\<lambda>x. x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 in A"
  have "{} *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 = {}" using arytm_3_th_48[of y9] arytm_3_def_12c by mty auto
  hence 
A7: "?P({})" using A4 arytm_2_lm_16[of "{}" A0 A] a arytm_3_th_64[of A0] by mty auto
  have "A in { A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s )}
  \\ { RAT\<^bsup>\<ge>0\<^bsub>}" using a arytm_2_def_1  by mty auto
  hence "not A in {RAT\<^bsup>\<ge>0\<^bsub>}" using
    xboole_0_def_5[OF all_set all_set,of  A _ "{RAT\<^bsup>\<ge>0\<^bsub>}",THEN iffD1] by mty auto
  hence "A <> RAT\<^bsup>\<ge>0\<^bsub>" "A \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" 
    using tarski_def_1 Subset_in_rule by mty auto
  hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> A" using xboole_0_def_10 by mty auto
  then obtain r where 
   "r in RAT\<^bsup>\<ge>0\<^bsub>" and A8:"not r in A" using tarski_def_3 by mty auto
  hence [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by mty auto
  obtain n where [ty]: "n be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A9: "n in omega" and
A10: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9" using A6 arytm_3_th_95[of r y9] by mty auto
  have [ty]: "n is Nat" using A9 ordinal1_def_12 by mty auto 
  have A11: "not ?P(n)" using A8 A10 arytm_2_lm_16[of r "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9" A] a by mty auto
  obtain n0 where [ty]: "n0 is Nat" and
A12: "(?P(n0))& not ?P(n0 +\<^sub>\<S>\<^sup>\<nat> succ {})" using arytm_3_sch_1[of n ?P] A11 A7 by mty auto
    have 
  "(n0 +\<^sub>\<S>\<^sup>\<nat> succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 = (n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9)" using arytm_3_th_57s[of y9 "succ{}" n0] 
    arytm_3_th_58[of "succ {}" n0] by mty auto
    hence "(n0 +\<^sub>\<S>\<^sup>\<nat> succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 = (n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9" using arytm_3_def_12c arytm_3_th_53 
      by mty auto
    hence "(n0 +\<^sub>\<S>\<^sup>\<nat> succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 in
   { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}" using 
      Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9" y9] A5 A12 by mty auto
    hence "(n0 +\<^sub>\<S>\<^sup>\<nat> succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 in A +D B" using arytm_2_def_6 by mty auto
    thus False using A1 A12 by mauto
qed mauto

mtheorem arytm_2_lm_35:
  "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = x implies y = {}"
proof(rule impI, rule ccontr)
  assume
A1: "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = x" and
A2: "y <> {}"
  have A3: "x <> {}" using A1 A2 arytm_2_th_5[of x y] arytm_2_def_8c[of x y,simplified] by mty auto
  hence A4: "DEDEKIND_CUT x <> {}" using arytm_2_lm_10 by mty auto
  hence "DEDEKIND_CUT x = DEDEKIND_CUT GLUED((DEDEKIND_CUT x) +D DEDEKIND_CUT y)" 
    using  A1 A2 A3 arytm_2_def_8 by mty auto
  also have "...= (DEDEKIND_CUT x) +D DEDEKIND_CUT y" using arytm_2_lm_12 by mty auto
  finally have  "(DEDEKIND_CUT y) = {}" using
      A4 arytm_2_lm_34[THEN bspec,of "DEDEKIND_CUT x"] by mty auto
  thus False using A2 arytm_2_lm_10 by mty auto
qed

mtheorem arytm_2_lm_36: 
  "for A,B being Element-of DEDEKIND_CUTS st A <> {} & A c= B & A <> B ex C
being Element-of DEDEKIND_CUTS st A +D C = B"
proof(intro ballI impI)
  fix  A B 
  assume [ty]:"A be Element-of DEDEKIND_CUTS" "B be Element-of DEDEKIND_CUTS"
and A1: "A <> {} & A c= B & A <> B"
  have "not B c= A" using A1 xboole_0_def_10 by mty auto
  then obtain s1 where
A3: "s1 in B & not s1 in A" using tarski_def_3 by mty auto
  have [ty]:"s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using A3 ES[of s1 B] by mty  auto
  obtain DIF where
    dif: "DIF = { t where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s}"
    by mty auto
   have A4: "DIF c= RAT\<^bsup>\<ge>0\<^bsub>"
   proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
    fix e 
    assume "e in DIF"
    hence e: "e in { t where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s}"
      using dif by mty auto
    obtain  t where [ty]: "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
   "t = e & (ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s)"
      using Fraenkel_A1_ex[OF _ _ e] by mty auto
    thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of _ t] by mty auto
  qed mauto
  have "s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = s1" using arytm_3_th_84[of s1 "{}"] arytm_3_def_11c[of s1 "{}"] by mty auto
  hence "ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = s" using A3 bexI[of _ s1]by mty auto
  hence
A5: "{} in DIF" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}" _ "\<lambda>x. x"] dif  by mty auto
  hence [ty]: "DIF is non empty" "DIF is Subset-of RAT\<^bsup>\<ge>0\<^bsub>"
     using xb1 xboole_0_lm_1 all_set Subset_of_rule A4 by mty auto
  have "for t be Element-of RAT\<^bsup>\<ge>0\<^bsub> st
  t in DIF holds (for s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st (s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t) holds s in DIF) 
      & (ex s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st s in DIF & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
  proof(rule ballI, intro impI conjI)
    fix t assume [ty]:"t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "t in DIF"
    hence t:"t in { t where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s}" 
      using dif by mty auto
    obtain x9 where [ty]: "x9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
   "x9 = t & (ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 = s)"
      using Fraenkel_A1_ex[OF _ _ t] by mty auto
    then obtain r0 s0 where [ty]: "r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6: "not r0 in A" and
A7: "s0 in B" and
A8: "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s0" by mty auto
    show "for s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st (s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t) holds s in DIF"
    proof(intro ballI impI)
      fix s assume [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
      then obtain p where [ty]:"p be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A9:   "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> p = t" using arytm_3_def_13 by mty auto
      have 
 A10:  "t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A8 arytm_3_def_13I[of t s0] bexI[of _ r0 "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] 
         arytm_3_def_11c[of r0 t] by mty auto
      have "p \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A9 arytm_3_def_13I[of p t] bexI[of _ s "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] 
         arytm_3_def_11c[of s p] by mty auto
      hence "p \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A10 arytm_3_th_67[of s0 t p] by mty auto
      then obtain q where [ty]:"q be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A11:   "p +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q = s0" using arytm_3_def_13 by mty auto
      have "(r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> p = q +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> p" 
        using A8 A9 A11 arytm_3_th_51[of p s r0] arytm_3_def_11c[of p q] by mty auto 
      hence
A12:  "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = q" using arytm_3_th_62[of _ p] by mty auto
      have "B in DEDEKIND_CUTS" using Element(7) by mty auto
      hence "q in B" using  A7 A11 arytm_2_lm_16[of q s0 B] arytm_3_th_77[of p  q ] 
           arytm_3_def_11c[of p q] by mty auto
      hence "ex r1,s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
           not r1 in A & s1 in B & r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = s1" using A6 A12 bexI[of _ r0] 
        by mty auto
      thus "s in DIF" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s _ "\<lambda>x. x"] dif by mty auto 
    qed mauto
    obtain s1 where [ty]:"s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A13: "s1 in B" and
A14: "s0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" using A7 arytm_2_lm_7[of s0 B]  by mty auto
    obtain q where [ty]:"q be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A15: "s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q = s1 & q <>{}" using A14 arytm_3_def_13l[of s0 s1] by mty auto
    
    show "ex s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st (s in DIF & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)" 
    proof(rule bexI[of _ "t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"],rule conjI)
    have A16: "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) = s1" using A8 A15 arytm_3_th_51 by mty auto
    thus "t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q in DIF" using A6 A13 bexI[of _ r0]
       Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" _ "\<lambda>x. x"] dif by mty auto
    have "s0 <>s1" using A14 arytm_3_th_68 by mty auto
    hence "t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q & t <> t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" 
      using A8 A14 A16 arytm_3_def_13I[of t "t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"] bexI[of _ q] by mty auto
    thus "t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" using arytm_3_th_68 by mty auto
    qed mauto
  qed mauto
  hence
A17: "DIF in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" DIF] 
   bexI[of _ DIF "Subset-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
  
  have "B in DEDEKIND_CUTS" using Element(7) by mty auto
  hence "B in { A where A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>: 
    for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s )}
  \\ { RAT\<^bsup>\<ge>0\<^bsub>}" using arytm_2_def_1  by mty auto
  hence "not B in {RAT\<^bsup>\<ge>0\<^bsub>}" using
    xboole_0_def_5[OF all_set all_set,of  B _ "{RAT\<^bsup>\<ge>0\<^bsub>}",THEN iffD1] by mty auto
  hence "B <> RAT\<^bsup>\<ge>0\<^bsub>" "B \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" 
    using tarski_def_1 Subset_in_rule by mty auto
  hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> B" using xboole_0_def_10 by mty auto
  then obtain s2 where
A18: "s2 in RAT\<^bsup>\<ge>0\<^bsub>" "not s2 in B" using tarski_def_3 by mty auto
  hence [ty]:"s2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by mty auto
  have a: "A in DEDEKIND_CUTS" and 
     b: "B in DEDEKIND_CUTS" using arytm_2_lm_16 Element(7)[of "DEDEKIND_CUTS"] 
      by mty auto
  have "not s2 in DIF"
  proof
    assume "s2 in DIF"
   hence e: "s2 in { t where t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s}"
      using dif by mty auto
    obtain  t where [ty]: "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
   "t = s2 & (ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s)"    
      using Fraenkel_A1_ex[OF _ _ e] by mty auto
    then obtain r s where [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
     and rs:"not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2 = s" by mty auto
    have b: "B in DEDEKIND_CUTS" using arytm_2_lm_16 Element(7)[of "DEDEKIND_CUTS" B] 
      by mty auto
    have "s2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using rs  arytm_3_th_77 arytm_3_def_11c by mty auto
    hence "s2 in B"  using rs arytm_2_lm_16[of s2 s B] b by mty auto
    thus False using A18  by mty auto
  qed
  hence "DIF <> RAT\<^bsup>\<ge>0\<^bsub>" using A18 by mty auto
  hence "not DIF in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by mty auto
  hence "DIF in DEDEKIND_CUTS" using A17 arytm_2_def_1 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
    all_set by mauto
  hence [ty]: " DIF is Element-of DEDEKIND_CUTS" using Element by mty auto
  show "ex C being Element-of DEDEKIND_CUTS st A +D C = B"
  proof(rule bexI[of _ DIF])
    let ?C = "{ r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & t in DIF}"
    have BB:"B = ?C"
  proof(rule xboole_0_def_10I[OF all_set all_set])
    show "B c= ?C"
    proof(standard, auto)
      fix y assume A19:  "y in B"
      hence [ty]: "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
      show "y in ?C"
      proof(cases "y in A")     
        case A20: True

        have "y = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using arytm_3_th_84[of  y "{}"] arytm_3_def_11c[of y "{}"]  by mty auto
        thus "y in ?C" using A5 A20 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" y "{}"_ 
          "\<lambda>r t. r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] bexI[of _ y "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] bexI[of _ "{}" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
      next
        case
A21:    False
        then obtain s0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A22:    "s0 in B" and
A23:    "y <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A19 arytm_2_lm_7[of y B] by mty auto
        
        let ?Z = "{ r where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>: (ex x9 st not x9 in A & x9 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r = s0) }"
        have
A24:    "not s0 in A" using a A21 A23 arytm_2_lm_16[of _ s0 A] arytm_3_th_68[of y s0] by mty auto
        have 
A25:    "s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = s0" using arytm_3_th_84[of s0 "{}"] arytm_3_def_11c[of s0 "{}"]  by mty auto
        have H: "for r2 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st r2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 ex s,t st s in A & t in ?Z
        & r2 = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
        proof(intro ballI impI)
          fix r2 assume [ty]:"r2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and     
A26:      "r2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0"
          hence
A27:      "r2 <> s0" using arytm_3_th_68 by mty auto
          show "ex s,t st s in A & t in ?Z & r2 = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
          proof(cases "r2 in A")
            case A28: True
                show "ex s,t st s in A & t in ?Z & r2 = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
                proof(rule bexI[of _ r2],rule bexI[of _ "{}"], intro conjI)             
                  show "r2 in A" using A28 by mty auto
                  show "{} in ?Z" using A24 A25 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}" _ "\<lambda>r. r"]
                       bexI[of _s0]by mty auto
                  show "r2 = r2 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using arytm_3_th_84[of r2 "{}"] 
                     arytm_3_def_11c[of r2 "{}"] by mty auto
                qed mauto
            next
            case A29:False
            obtain q where [ty]:"q be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A30:        "r2 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q = s0" "q<>{}" using A26 arytm_3_def_13l by mty auto
                    
            let ?P ="\<lambda>x . x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q in A"
            have "{} *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q = {}" using arytm_3_th_48 arytm_3_def_12c by mty auto
            hence
A31:        "?P({})" using A1 arytm_2_lm_17[of A] a by mty auto
            have "q <> {}" using A30 by mty auto
            then obtain n where [ty]: "n be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A32:        "n in omega" and
A33:        "s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" using arytm_3_th_95[of s0 q] by mty auto
            have [ty]:"n is Nat" using A32 ordinal1_def_12 by mty auto
            have
A34:        "not ?P(n)" using A24 A33 arytm_2_lm_16[of s0 "n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" A] a by mty auto       
            obtain  n0 where [ty]: "n0 be Nat" and          
A35:        "?P(n0)" and
A36:        "not ?P(n0 +\<^sub>\<S>\<^sup>\<nat> (succ{}))" using arytm_3_sch_1[of n ?P,OF _ A31 A34] by mty auto              
            have "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2" using  A29 A35 arytm_2_lm_16[of r2 "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" A] 
              a arytm_3_def_13c[of "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q " " r2"] by mty auto
            hence "(n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using  A30 arytm_3_th_76 by mty auto
            then obtain t where [ty]:"t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A37:        "((n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s0" using arytm_3_def_13 by mty auto
              show "ex s,t st s in A & t in ?Z & r2 = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
                proof(rule bexI[of _ "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"],rule bexI[of _ "t"], intro conjI)                                
                  show "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q in A" using A35 by mty auto
                  have "(n0 +\<^sub>\<S>\<^sup>\<nat> (succ{})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q = (n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q)"
                    using arytm_3_th_57s[of q "succ{}" n0] arytm_3_th_58[of "succ{}" n0] by mty auto
                  also have "... = (n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"
                    using arytm_3_th_53[of q] arytm_3_def_12c[of q "succ{}"] by mty auto
                  finally show "t in ?Z" using A36 A37 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t _ "\<lambda>r. r"]
                    bexI[of _ "(n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
                  have "((n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q = r2 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"
                    using A30(1) A37 arytm_3_th_51[of t q "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"] 
                      arytm_3_def_11c[of q t] arytm_3_th_51[of q t "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q"]  by mty auto
                  thus "r2 =\<^sub>\<S> (n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> q) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using  arytm_3_th_62[of _ q] by mty auto
                qed mauto
              qed mauto
            qed mauto
        obtain s t where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A38:    "s in A" and
A39:    "t in ?Z" and
A40:    "y = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A23 H[THEN bspec,of y] by mty auto
        obtain x9 where [ty]: "x9 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
           "not x9 in A & x9 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s0"
          using A39 Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t] by mty auto
        hence "ex r,s be Element-of RAT\<^bsup>\<ge>0\<^bsub> st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s" 
          using bexI[of _ x9] bexI[of _ s0] A22 by mty auto
        hence "t in DIF" using dif Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t _ "\<lambda>x. x"] 
          by mty auto
        thus "y in ?C" using A38 A40 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]
          by mty auto   
      qed mauto  
    qed mauto 
    show "?C c= B"
      proof(standard, auto)
        fix e assume e: "e in ?C"
    then obtain s3 t3 where [ty]: "s3 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t3 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A41: "e = s3 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t3" and
A42: "s3 in A" and
A43: "t3 in DIF" using Fraenkel_A2_ex[OF _ _ _ _ e] by mty auto
    have  "ex r,s st not r in A & s in B & r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t3 = s" 
      using A43  Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t3] dif by mty auto
    then obtain r4 s4 where [ty]:"r4 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s4 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A44: "not r4 in A" and
A45: "s4 in B" and
A46: "r4 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t3 = s4" using A43  Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t3] dif by mty auto
    have "s3 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r4" using A42 A44 arytm_2_lm_16[of r4 s3 A] a arytm_3_def_13c[of s3 r4] by mty auto 
    hence "s3 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t3 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s4" using A46 arytm_3_th_76 by mty auto
    thus "e in B" using A41 A45 arytm_2_lm_16[of e s4 B] b by mty auto
  qed mauto
qed mauto
  thus "A +D DIF =\<^sub>\<S> B" using arytm_2_def_6[of A DIF]by mty auto
 qed mauto
qed mauto 

mtheorem arytm_2_lm_37: 
"x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y implies DEDEKIND_CUT x c= DEDEKIND_CUT y"
proof(rule impI,rule ccontr)
  assume
A1: "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  have H: "DEDEKIND_CUT x in DEDEKIND_CUTS"
          "DEDEKIND_CUT y in DEDEKIND_CUTS" using Element(7)[of "DEDEKIND_CUTS"] by mty auto
  assume
A2: "\<not> DEDEKIND_CUT x c= DEDEKIND_CUT y"
  have "DEDEKIND_CUT x in IR & DEDEKIND_CUT y in IR" 
    using xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}"] arytm_2_def_1 all_set H by mty auto 
  hence "DEDEKIND_CUT y c= DEDEKIND_CUT x" 
    using A2 arytm_2_lm_13[of "DEDEKIND_CUT x" "DEDEKIND_CUT y"] by mty auto
  hence "y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_2_lm_20[of x y] by mty auto
  thus False using A1 A2 arytm_2_lm_21[of x y] 
    xboole_0_def_10[of "DEDEKIND_CUT x " "DEDEKIND_CUT y",simplified]  by mty auto
qed

mtheorem arytm_2_th_9:
  "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y implies (ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y)"
proof                             
  assume
A1: "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  show "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y"
  proof(cases "x={}")
    case True
    thus "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y" using bexI[of _ y] arytm_2_def_8[of "{}" y] by mty auto
  next
    case A4: False
    show "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y"
    proof(cases "x=y")
      case True
      thus "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y" using bexI[of _ "{}"] arytm_2_def_8[of x "{}"] by mty auto
    next
      case A5: False 
        have A6: "DEDEKIND_CUT x <> {}" using A4 arytm_2_lm_10 by mty auto
        have "DEDEKIND_CUT x <> DEDEKIND_CUT y" using A5 arytm_2_lm_22 by mty auto
        then obtain C where [ty]: "C be Element-of DEDEKIND_CUTS" and
          A7: "(DEDEKIND_CUT x) +D C = DEDEKIND_CUT y" using A1 A6 
          arytm_2_lm_36[of "DEDEKIND_CUT x" "DEDEKIND_CUT y"] arytm_2_lm_37[of y x] by mty auto
        show "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y"
        proof(rule bexI[of _ "GLUED C"])
          have "C<>{}"
          proof
            assume
A8:         "C = {}"
            have "(DEDEKIND_CUT x) +D C ={}"
              proof(rule ccontr)
                assume "(DEDEKIND_CUT x) +D C<>{}"
                then obtain e where
                  "e in (DEDEKIND_CUT x) +D C" using 
                   xboole_0_lm_1[of "(DEDEKIND_CUT x) +D C"] xboole_0_def_1 by mty auto
                hence e: "e in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>,s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
                   r in DEDEKIND_CUT x & s in C}" using arytm_2_def_6[of "DEDEKIND_CUT x" C] by mty auto
                then obtain r s where 
                  "e = r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r in DEDEKIND_CUT x & s in C" using Fraenkel_A2_ex[OF _ _ _ _ e] by mty auto
                thus False using A8 xb by mty auto
              qed
              hence "DEDEKIND_CUT y = {}" using A7 by mty auto
              hence "DEDEKIND_CUT x \<subseteq> {}" using A1 A6 arytm_2_lm_37[of y x] by mty auto
              thus False using xboole_1_th_3 A6 by mty auto
          qed
          hence "GLUED C <> {}" using arytm_2_lm_11 by mty auto
          hence "(x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (GLUED C)) = GLUED((DEDEKIND_CUT x) +D (DEDEKIND_CUT GLUED C))"  
            using A4 arytm_2_def_8 by mty auto
          hence "(x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (GLUED C)) = GLUED (DEDEKIND_CUT y)" using A7 arytm_2_lm_12 by mty auto
          thus "(x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (GLUED C)) = y" using arytm_2_lm_23 by mty auto
        qed mauto
      qed
    qed
  qed


mtheorem arytm_2_th_10:
  "ex z st (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y or y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = x)"
proof-
  have "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y or y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_2_def_5c[of x y] by mty auto
  thus ?thesis using arytm_2_th_9[of x y]  arytm_2_th_9[of y x] by mty auto
qed

mtheorem arytm_2_th_11:
  "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z implies y = z"
proof
  assume
A1: "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
  obtain q where [ty]:"q be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
A2: "z +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> q = y or y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> q = z" using arytm_2_th_10[of y z] by mty auto 
  show "y = z"
  proof(cases "z +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> q = y")
    case  A3: True
    hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> q" using A1 arytm_2_th_6[of q z x,simplified] by mty auto
    hence "q = {}" using arytm_2_lm_35[of q "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"] by mty auto
    thus "y=z" using A3 arytm_2_def_8[of z q] by mty auto
  next
    case A4: False
     hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> q"
    using A1 A2  arytm_2_th_6[of q y x] by mty auto
    hence "q = {}" using arytm_2_lm_35[of q "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"] by mty auto
    thus "y=z" using A4 A2 arytm_2_def_8[of y q] by mty auto
  qed
qed


mtheorem arytm_2_th_9l:
   "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y iff (ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z <>{})"
proof
  assume AS: "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  hence "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_5c[of x y] by auto
  then obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
    A1: "y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_2_th_9[of y x] by mty auto
  have "z <>{}" using arytm_2_def_5r[of x] arytm_2_def_8[of x] A1 AS by mauto
  thus "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z \<noteq>{}" using A1 bexI[of _ z "Element-of REAL\<^bsup>\<ge>0\<^bsub>"] by mauto
next
  assume "ex z st x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z \<noteq>{}"
  then obtain z where [ty]:"z is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
    A2:"x+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z <>{}" by mauto
  show "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof
    assume "y \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>x"
    then obtain w where [ty]:"w is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
      A3: "x = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> w" using arytm_2_th_9[of x y] by mauto
    hence "y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (w +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using A2 arytm_2_th_6[of z w y] 
        arytm_2_def_8[of y "{}"] by mty auto
    hence "w+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = {}" using arytm_2_th_11[of "{}" _ y] by mty auto
    hence "z={}" using arytm_2_th_5[of w z] arytm_2_def_8c[of w z] by mauto 
    thus False using A2 by simp
  qed
qed

mtheorem arytm_2_th_19:
  "x = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z implies z \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" 
proof(rule impI, rule ccontr)
  assume
A1: "x = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
  assume
A2: "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
  then obtain y0 where [ty]:"y0 be  Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
A3: "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y0 = z" "y0<>{}" using  arytm_2_th_9l by mty auto
  have "x = (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y0" using A1 A3 arytm_2_th_6[of y0 x y] arytm_2_def_8c[of y x] by mty auto
  hence "x = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y0)" using arytm_2_th_6 by mty auto
  hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> {} = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y0)" using arytm_2_def_8[of x "{}"] by mty auto
  hence "y0 = {}" using arytm_2_th_5[of y y0] arytm_2_th_11[of "y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y0" "{}" x] 
    arytm_2_def_8c[of y y0] by mty auto
  thus False using A3 arytm_2_def_8 by mty auto
qed

mtheorem arytm_2_th_66:
  "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r implies r = s" using arytm_2_lm_21 by mty auto

mtheorem arytm_2_th_68:
  "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y iff x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y & x <> y"
proof
  assume AS: "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  then obtain z where [ty]:"z be Element-of REAL\<^bsup>\<ge>0\<^bsub>" and  
     z:"x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z <>{}" using arytm_2_th_9l by mty auto
  thus "x\<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y & x<>y" using AS arytm_2_th_19 arytm_2_def_8c arytm_2_def_5r[of x] by mty auto
next
  assume "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y & x <> y"
  thus "x <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_lm_21 by mty auto
qed

theorem arytm_2_th_33d:
  "x<>{} \<Longrightarrow> [{},x] is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" 
proof(auto)
  assume x: "x <> {}" and [ty]: "[{} , x] be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  hence "[{},x] in REAL\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  hence "[{},x] in RAT\<^bsup>\<ge>0\<^bsub> \<union> IR" using arytm_2_lm_3 tarski_def_3E all_set by mty auto 
  hence "[{},x] in RAT\<^bsup>\<ge>0\<^bsub> or [{},x] in IR" using xboole_0_def_3 all_set by mty auto
  hence "[{},x] in IR" using arytm_3_th_33d[of x] x Element(6) by mty auto 
  thus False using arytm_2_lm_1 by mty auto
qed


mtheorem arytm_2_lm_40: 
  "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = {} implies x = {} or y = {}"
proof
  assume "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = {}"
  hence "{} = GLUED((DEDEKIND_CUT x)*D (DEDEKIND_CUT y))" using arytm_2_def_9 by mty auto
  hence A1: "{}=(DEDEKIND_CUT x)*D (DEDEKIND_CUT y)" 
    using arytm_2_lm_11[of "(DEDEKIND_CUT x)*D (DEDEKIND_CUT y)"] by mty auto
  have "DEDEKIND_CUT x = {} or DEDEKIND_CUT y = {}"
  proof(rule ccontr)
    assume A:"\<not> (DEDEKIND_CUT x =\<^sub>\<S> {} \<or> DEDEKIND_CUT y =\<^sub>\<S> {})"
     hence "DEDEKIND_CUT x is non empty"
       using xboole_0_lm_1[of "DEDEKIND_CUT x"] xboole_0_def_1 by mty auto
    then obtain r0 where
       A2:"r0 in DEDEKIND_CUT x" using xboole_0_def_1 by mty auto

    have "DEDEKIND_CUT y is non empty"
       using xboole_0_lm_1[of "DEDEKIND_CUT y"] A xboole_0_def_1 by mty auto
    then obtain s0 where
       A3:"s0 in DEDEKIND_CUT y" using xboole_0_def_1 by mty auto
    have [ty]: "r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
      using A2 A3 ES by mty auto
    
    have "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>,s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
       r in DEDEKIND_CUT x & s in DEDEKIND_CUT y}" 
      using  A2 A3 Fraenkel_A2_in arytm_2_def_9[of r0 s0] by mty auto
    hence "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in (DEDEKIND_CUT x)*D (DEDEKIND_CUT y)"
      using arytm_2_def_7 by mty auto
    thus False using  A1 xb by mty auto
  qed
  thus "x = {} or y = {}" using arytm_2_lm_10 by mty auto
qed

mtheorem arytm_2_lm_39: 
  "for A,B,C being Element-of DEDEKIND_CUTS holds A *D (B *D C) = (A *D B) *D C"
proof(intro ballI,rule xboole_0_def_10I)
  fix A B C assume [ty]: "A is Element-of DEDEKIND_CUTS" "B is Element-of DEDEKIND_CUTS"
                         "C is Element-of DEDEKIND_CUTS"
  show "A *D (B *D C) is set" by mty auto
  show "(A *D B) *D C is set" by mty auto
  show " A *D (B *D C) c= (A *D B) *D C"
  proof(standard,auto)
    fix e 
    assume "e in A *D (B *D C)"
    hence e0: "e in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B *D C}"
      using arytm_2_def_7[of A "B *D C"] by mty auto
  obtain r0 s0 where [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "e = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 & r0 in A" and
A2: "s0 in B *D C" using Fraenkel_A2_ex[OF _ _ _ _ e0] by mty auto
  hence e1: "s0 in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in B & s in C}"
      using arytm_2_def_7[of B "C"] by mty auto
    obtain r1 s1 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "s0 = r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 & r1 in B" and
A4: "s1 in C" using Fraenkel_A2_ex[OF _ _ _ _ e1] by mty auto

    have "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 in A *D B" 
      using Fraenkel_A2_in arytm_2_def_7[of A B] A1 A3 by mty auto
    hence "(r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 in (A *D B) *D C" 
      using Fraenkel_A2_in arytm_2_def_7[of "A *D B" C] A4 by mty auto
    thus "e in (A *D B) *D C" using arytm_3_th_52[of s1 r1 r0] A1 A3 by mty auto
  qed mauto 
  show "(A *D B) *D C c=  A *D (B *D C)"  
  proof(standard,auto)
    fix e 
    assume "e in (A *D B) *D C"
    hence e0: "e in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A *D B & s in C}"
      using arytm_2_def_7[of "A *D B" C] by mty auto
  obtain r0 s0 where [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "e = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 & r0 in A *D B" and
A2: "s0 in C" using Fraenkel_A2_ex[OF _ _ _ _ e0] by mty auto
  hence e1: "r0 in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
      using arytm_2_def_7[of A B] by mty auto
    obtain r1 s1 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "r0 = r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 & r1 in A" and
A4: "s1 in B" using Fraenkel_A2_ex[OF _ _ _ _ e1] by mty auto

    have "s1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 in B *D C" 
      using Fraenkel_A2_in arytm_2_def_7[of B C] A1 A2 A3 A4 by mty auto
    hence "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (s1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) in A *D (B *D C)" 
      using Fraenkel_A2_in arytm_2_def_7[of A "B *D C"] A3 by mty auto
    thus "e in A *D (B *D C)" using arytm_3_th_52[of s0 s1 r1] A1 A3 by mty auto
  qed mauto 
qed mauto



mtheorem arytm_2_th_12:
  "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
proof-
  have  "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = GLUED((DEDEKIND_CUT x) *D (DEDEKIND_CUT (y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)))"
    using arytm_2_def_9[of x] by mty auto
  also have "... = GLUED((DEDEKIND_CUT x) *D 
      (DEDEKIND_CUT (GLUED((DEDEKIND_CUT y) *D (DEDEKIND_CUT z)))))"
    using arytm_2_def_9[of y z] by mty auto
  also have  "... = GLUED((DEDEKIND_CUT x) *D ((DEDEKIND_CUT y) *D (DEDEKIND_CUT
  z)))" using arytm_2_lm_12[of "(DEDEKIND_CUT y) *D (DEDEKIND_CUT z)"] by mty auto
  also have  "... = GLUED(((DEDEKIND_CUT x) *D (DEDEKIND_CUT y)) *D (DEDEKIND_CUT
  z))" using arytm_2_lm_39 by mty auto
   also have  "... = GLUED((DEDEKIND_CUT (GLUED((DEDEKIND_CUT x) *D (DEDEKIND_CUT y)))) *D (DEDEKIND_CUT
  z))" using  arytm_2_lm_12 by mty auto
   also have  "... = GLUED((DEDEKIND_CUT (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y)) *D (DEDEKIND_CUT z))" 
     using  arytm_2_def_9[of x y] by mty auto
   finally show ?thesis using  arytm_2_def_9[of _ z] by mty auto
 qed




mtheorem arytm_2_lm_41: 
  "for A,B,C being Element-of DEDEKIND_CUTS holds A *D (B +D C) = (A *D B) +D (A *D C)"
proof(intro ballI,rule xboole_0_def_10I)
  fix A B C assume [ty]: "A is Element-of DEDEKIND_CUTS" "B is Element-of DEDEKIND_CUTS"
                         "C is Element-of DEDEKIND_CUTS"
  show "A *D (B +D C) is set" by mty auto
  show "(A *D B) +D (A *D C) is set" by mty auto
  show " A *D (B +D C) c= (A *D B) +D (A *D C)"
  proof(standard,auto)
    fix e 
    assume "e in A *D (B +D C)"
    hence e0: "e in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B +D C}"
      using arytm_2_def_7[of A "B +D C"] by mty auto
  obtain r0 v0 where [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "v0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "e = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> v0 "and
A2: " r0 in A" and
A3: "v0 in B +D C" using Fraenkel_A2_ex[OF _ _ _ _ e0] by mty auto

    hence e1: "v0 in  { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in B & s in  C}"
      using arytm_2_def_6[of B C] by mty auto
  obtain r1 v1 where [ty]:"r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "v1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "v0 = r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> v1 "and
A5: " r1 in B" and
A6: "v1 in C" using Fraenkel_A2_ex[OF _ _ _ _ e1] by mty auto
  
 
    have "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 in A *D B" "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> v1 in A *D C" 
      using Fraenkel_A2_in arytm_2_def_7[of A B] arytm_2_def_7[of A C] A2 A5 A6 by mty auto
    hence "(r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> v1) in (A *D B) +D (A *D C)"
       using Fraenkel_A2_in arytm_2_def_6[of "A *D B" "A *D C"] by mty auto
     thus "e in (A *D B) +D (A *D C)" using  A1 A4 arytm_3_th_57 by mty auto
   qed mauto

  show " (A *D B) +D (A *D C) c= A *D (B +D C)"
  proof(standard,auto)
    fix e 
    assume "e in (A *D B) +D (A *D C)"
    hence e0: "e in  { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A *D B& s in A *D C}"
      using arytm_2_def_6[of "A*D B" "A *D C"] by mty auto
  obtain s1 t1 where [ty]:"s1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A7: "e = s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1 "and
A8: " s1 in A*D B" and
A9: "t1 in A *D C" using Fraenkel_A2_ex[OF _ _ _ _ e0] by mty auto
   hence e0: "s1 in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
      using arytm_2_def_7[of A B] by mty auto
    obtain r0 s0 where [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A10: "s1 = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" and
A11: "r0 in A" and
A12: "s0 in B" using Fraenkel_A2_ex[OF _ _ _ _ e0] by mty auto

    have e0: "t1 in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in C}"
      using arytm_2_def_7[of A C] A9 by mty auto
    obtain r09 t0 where [ty]:"r09 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A13: "t1 = r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" and
A14: "r09 in A" and
A15: "t0 in C" using Fraenkel_A2_ex[OF _ _ _ _ e0] by mty auto

    show "e in A *D (B +D C)"
    proof(cases "r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r09")
      case True
        hence "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using arytm_3_th_82 by mty auto
        then obtain s09 where [ty]:"s09 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A16: "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 = r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s09" and
A17: "s09 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using arytm_3_th_79[of  s0 r09 "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0"] by mty auto
        have "s09 in B" using A12 A17 arytm_2_lm_16[of s09 s0 B] Element(7) by mty auto
        hence
A18: "s09 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 in B +D C" using A15 Fraenkel_A2_in arytm_2_def_6[of B C] by mty auto

        have "e = r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (s09 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0)" using A7 A10 A13 A16 arytm_3_th_57 by mty auto
        thus "e in A *D (B +D C)" using A14 A18 Fraenkel_A2_in arytm_2_def_7[of A "B +D C"]
          by mty auto  
      next
        case False
    hence "r09 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using arytm_3_th_68 by mty auto
    hence "r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using arytm_3_th_82 by mty auto
    then obtain t09 where [ty]:"t09 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A19: "r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t09" and
A20: "t09 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using arytm_3_th_79[of t0 r0 "r09 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"] Element(7) by mty auto
    have "t09 in C" using A15 A20 arytm_2_lm_16[of t09 t0 C,simplified] Element(7) by mty auto
    hence
A21: "s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t09 in B +D C" using A12 Fraenkel_A2_in arytm_2_def_6[of B C] by mty auto
      have "e = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t09)" using A7 A10 A13 A19 arytm_3_th_57 by mty auto
    thus "e in A *D (B +D C)" using A11 A21 Fraenkel_A2_in arytm_2_def_7[of A "B +D C"] by mty auto
  qed
qed mauto
qed mauto

mtheorem arytm_2_th_13:
  "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)"
proof(cases "x={}")
case A1: True
  hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = x" using arytm_2_th_4[of "y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" x] by mty auto
  also have "... = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using A1 arytm_2_def_8[of x x] by mty auto
  also have "... =  x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using A1 arytm_2_th_4[of _ x] by mty auto
  finally show "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)"  using A1 arytm_2_th_4[of _ x] by mty auto
next
  case A4:False
  show "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)"
   proof(cases "y={}")
     case A2:True
       hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_2_def_8[of y z] by mty auto
         also have "... = y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using  A2 arytm_2_def_8[of y] by mty auto
       finally show "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using A2 arytm_2_th_4[of] arytm_2_def_9_c[of x y] by mty auto
     next
       case A5: False
       show "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)"
          proof(cases "z={}")
          case A3:True
            hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_2_def_8[of y z] by mty auto
            also have "... = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using  A3 arytm_2_def_8[of _ z] by mty auto
            finally show "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" 
              using A3 arytm_2_th_4[of] arytm_2_def_9_c[of x z] by mty auto
          next
            case A51:False
            have A6: "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y <> {} & x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z <> {}" using A4 A5 A51 arytm_2_lm_40[of y x] 
               arytm_2_lm_40[of z x] by mty auto
            have "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = GLUED((DEDEKIND_CUT x) *D DEDEKIND_CUT (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z))" using 
                arytm_2_def_9[of x "y+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"] by mty auto
            also have "... = GLUED((DEDEKIND_CUT x) *D DEDEKIND_CUT GLUED(
                  (DEDEKIND_CUT y) +D (DEDEKIND_CUT z)))" using A5 arytm_2_def_8[of y z] A5 A51
         by mty auto
       also have "... = GLUED((DEDEKIND_CUT x) *D ((DEDEKIND_CUT y) +D (DEDEKIND_CUT z)))"
         using arytm_2_lm_12 by mty auto
    also have "... = GLUED(((DEDEKIND_CUT x) *D (DEDEKIND_CUT y)) +D ((DEDEKIND_CUT x) *D
     (DEDEKIND_CUT z)))" using arytm_2_lm_41[of "DEDEKIND_CUT x" "DEDEKIND_CUT y" "DEDEKIND_CUT z"] 
      by mty auto

    also have "... = GLUED(((DEDEKIND_CUT x) *D (DEDEKIND_CUT y)) +D DEDEKIND_CUT (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z))" 
      using arytm_2_lm_12  arytm_2_def_9[of x z] by mty auto
    also have "... = GLUED((DEDEKIND_CUT (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y)) +D DEDEKIND_CUT (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z))" 
      using arytm_2_lm_12  arytm_2_def_9[of x y] by mty auto
    finally show "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using A6 arytm_2_def_8 by mty auto
  qed
qed
qed

mtheorem arytm_2_th_13s:
  " (y +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x = (y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x)"
  using arytm_2_def_9_c[of x y] arytm_2_def_9_c[of x z] 
   arytm_2_def_9_c[of x "y+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" ] arytm_2_th_13[of z y x] by mty auto


mtheorem arytm_2_lm_42: 
  "for B being set st B in IR & B <> {} ex r st r in B & r <> {}"
proof(rule ballI, rule impI)
  fix B assume [ty]:"B is set" and
A1: "B in IR & B <> {}"
  obtain A where AA[ty]:"A is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "B = A" and
A4: "for r st r in A holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) & (ex s st s in A & r
  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)" using Fraenkel_A1_ex[OF _ _  A1[THEN conjunct1]] by mty auto
    have "A is non empty"
       using A3 xboole_0_lm_1[of B] xboole_0_def_1 A1 by mauto
    then obtain r0 where
       A5:"r0 in A" using xboole_0_def_1[of A,OF all_set] by mty auto
    have [ty]:"r0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES[OF A5] by mty auto
   
    obtain r1 where [ty]: "r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6: "r1 in A" and
A7: "r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" using A5 A4[THEN bspec,of r0] by mty auto
    have 
 "r1 <> {} or r0 <> {}" using A7 arytm_3_def_13r by mty auto
    hence A8: "\<exists>t : Element-of RAT\<^bsup>\<ge>0\<^bsub>. t in A \<and> t \<noteq> {}" 
      using bexI[of _ _ "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] A5 A6 by mty auto

    have H:"\<And>r s. r be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> s be Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> r in A \<Longrightarrow> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r  \<Longrightarrow> s in A" 
    proof-
      fix r s assume [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
     and "r in A "" s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" thus"s in A" using A4[THEN bspec,of r] by mty auto
    qed 
    hence " \<exists>r1 :Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<exists>r2 :Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<exists>r3 :Element-of RAT\<^bsup>\<ge>0\<^bsub>. r1 in A \<and>
    r2 in A \<and> r3 in A \<and> r1 \<noteq> r2 \<and> r2 \<noteq> r3 \<and> r3 \<noteq> r1" 
      using  arytm_3_th_75[OF AA A8] H by blast
    then obtain r1 r2 r3 where [ty]: "r1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r2 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r3 is Element-of RAT\<^bsup>\<ge>0\<^bsub>"and
A9: "r1 in A & r2 in A" and
  "r3 in A" and
A10: "r1 <> r2" and
  "r2 <> r3" and
  "r3 <> r1" by auto
    have "r1 <> {} or r2 <> {}" using A10 arytm_3_def_13r by mty auto
    thus "ex r st r in B & r <> {}" using A9 A3 bexI[of _ _ "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]  by mty auto
qed mauto

mtheorem arytm_2_lm_43:
" for rone be Element-of REAL\<^bsup>\<ge>0\<^bsub> st rone = succ {}
   for A being Element-of DEDEKIND_CUTS st A <> {} ex B being Element-of
DEDEKIND_CUTS st A *D B = DEDEKIND_CUT rone"
proof(intro ballI impI)
  fix rone A assume [ty]:"rone be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
and A0: "rone=succ {}"
and[ty]:"A be Element-of DEDEKIND_CUTS" and
A1: "A <> {}"
  show "ex B being Element-of
DEDEKIND_CUTS st A *D B = DEDEKIND_CUT rone"
  proof(cases "A in RA")
    case T:True
    then obtain r0 where [ty]:"r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "A = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0}" and
A3: "r0 <> {}" using Fraenkel_A1_ex[OF _ _ T] by mty auto
      
    obtain s0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 = succ {}" using  A3 arytm_3_th_54[of r0] by mty auto
    let ?B = "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0}"
    have "?B c= RAT\<^bsup>\<ge>0\<^bsub>"
    proof(standard,auto)
      fix e assume A:"e in ?B"
      have "ex s st s = e & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using Fraenkel_A1_ex[OF _ _ A] by mty auto
      thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
    qed mauto
    hence [ty]:"?B is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by mty auto
    have "for r st r in ?B holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?B) & (ex s st s in ?B & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
    proof(rule ballI, intro impI conjI)
      fix r assume [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and r: "r in ?B"
      have
A5:   "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using Fraenkel_A1_ex[OF _ _ r] by mty auto
      then obtain t where [ty]:"t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6:   "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" and
A7:   "t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s0" using arytm_3_th_93[of r s0] by mty auto
      show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in ?B"
      proof(standard,standard)
        fix s assume [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
        hence "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A5 arytm_3_th_69[of s0 s r] by mty auto
        thus "s in ?B" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s] by mty auto
      qed mauto
      show "ex s st s in ?B & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
      proof(rule bexI[of _ t],rule conjI)
        show "t in ?B" using A7 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t] by mty auto
        show "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A6 by auto
      qed mauto
    qed mauto
    hence
A8: "?B in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" ?B] by mty auto
    have "not (ex s st s = s0 & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0)" using arytm_3_def_13r by mty auto 
    hence "not s0 in ?B" using Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s0] by mty auto
    hence "?B <> RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
    hence "not ?B in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by mty auto
    hence "?B in DEDEKIND_CUTS" unfolding arytm_2_def_1 using A8 xboole_0_def_5[of IR "{RAT\<^bsup>\<ge>0\<^bsub>}" ?B]
      all_set by mty auto
    hence [ty]:"?B is Element-of DEDEKIND_CUTS" using Element(6) by mty auto
    have 
A9: "A *D ?B = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 }"
    proof (rule xboole_0_def_10I[OF all_set all_set])
      show  "A *D ?B c= { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 }"
      proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
        fix e assume "e in A *D ?B"
        hence H:"e in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in ?B}"
          using arytm_2_def_7 by mty auto
        obtain r1 s1 where [ty]: "r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>"  "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A10:    "e = r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" and
A11:    "r1 in A" and
A12:    "s1 in ?B" using Fraenkel_A2_ex[OF _ _ _ _ H] by mty auto
        have H: "r1 in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0}" using A11 A2 by mty auto
        have "r1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0"
          using Fraenkel_A1_ex[OF _ _ H] by mty auto
        hence "r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using arytm_3_th_68 by mty auto
        hence
A13:    "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" using arytm_3_th_82 by mty auto
        have 
A14:    "s1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0"  using Fraenkel_A1_ex[OF _ _ A12] by mty auto
        hence a14: "s1 <> s0" "s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using arytm_3_th_68 by mty auto
        hence 
A15:    "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 <> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A3 arytm_3_th_56[of _ _ r0] by mty auto         
        have "s1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using a14 arytm_3_th_82[of r0 s0 s1] by mty auto
        hence "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A15 arytm_3_th_68 arytm_3_def_12c by mty auto
        hence "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" 
          using A13 arytm_3_th_69[of "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1"] by mty auto
        thus "e in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 }"
          using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r1*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1"] A10  by mty auto
      qed mauto
      show  " { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 } \<subseteq> A *D ?B"
      proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
        fix e assume H:"e in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 }"
        obtain s1 where [ty]:"s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A16:      "e = s1" and
A17:      "s1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using Fraenkel_A1_ex[OF _ _ H] by mty auto
        hence a17:"s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using arytm_3_th_68 by mty auto
        obtain t0 where [ty]:"t0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A18:  "s1 = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" and
A19:  "t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 "using a17 arytm_3_th_79[of s0 r0 s1] by mty auto
      have "t0 <> s0" using A17 A18 arytm_3_def_13r by mty auto
      hence "t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using A19 arytm_3_th_68 by mty auto
      hence "t0 in ?B" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" t0] by mty auto
      then obtain t1 where [ty]:"t1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
A20:  "t1 in ?B" and
A21:  "t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" using arytm_2_lm_7[of t0 ?B] by mty auto
      hence a21: "t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" "t0 <>t1" using arytm_3_th_68 by mty auto
      hence "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using A21 arytm_3_th_82[of r0 t1 t0] arytm_3_def_12c by mty auto
      then obtain r1 where [ty]:"r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A22:  "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 = t1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" and
A23:  "r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using arytm_3_th_79[of r0 t1 "r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"] by mty auto
      have "t1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 <> r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" using a21 A3 A22 arytm_3_th_56[of t1 t0 r0] by mty auto
      hence "r1 <> r0" using arytm_3_def_12c[of t1 r1] by mty auto
      hence "r1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" using A23 arytm_3_th_68 by mty auto
      hence "r1 in A" using A2 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r1] by mty auto
      hence "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1 in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in ?B}"
        using  A20 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r1 t1
          "\<lambda>r s. r in A \<and> s in ?B" "\<lambda>r s. r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] by mty auto
      thus "e in A *D ?B" 
        using A16 A18 A22 arytm_3_def_12c[of r1 t1] arytm_2_def_7[of A ?B] by mty auto
      qed mauto
    qed    
    have "rone in RAT\<^bsup>\<ge>0\<^bsub>" using A0 Element(7) by mty auto
    hence "
    DEDEKIND_CUT rone = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rone }" 
      using arytm_2_def_3[of rone] A0 by mty auto
    thus "ex B being Element-of
    DEDEKIND_CUTS st A *D B = DEDEKIND_CUT rone" using A4 A9 A0 bexI[of _ ?B] by mty auto
  next
    case A24: False
    let ?B = "{ y9 where y9 be Element-of RAT\<^bsup>\<ge>0\<^bsub>: ex x9 st (not x9 in A & x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{}) }"
    have A25: "?B \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>"
     proof(rule tarski_def_3I[OF all_set all_set], intro ballI impI)
      fix e assume A:"e in ?B"
      have "ex y9 st ( e = y9 & (ex x9 st (not x9 in A & x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{})))" 
        using Fraenkel_A1_ex[OF _ _ A] by mty auto
      thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
    qed mauto
    then obtain B where  [ty]:"B is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" and
       B: "B=?B" using Subset_of_rule by mty auto
    have "A in DEDEKIND_CUTS" using Element(7) by mty auto
    hence aa: "not A in {RAT\<^bsup>\<ge>0\<^bsub>}" "A in IR" unfolding arytm_2_def_1 
      using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] all_set by mty auto
    hence A26: "A <> RAT\<^bsup>\<ge>0\<^bsub>" "A \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 Subset_in_rule by mty auto
    hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> A" using xboole_0_def_10 by mty auto
    then obtain x0 where 
A27: "not x0 in A" "x0 in RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_3 by mty auto
    hence [ty]:"x0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mty auto 
    have "x0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = {}" using arytm_3_th_48 by mty auto
    hence "x0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using arytm_3_th_64[of "succ {}"] by mty auto 
    hence "ex x9 st (not x9 in A & x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{})" using A27 bexI[of _ x0] by mty auto
    hence A28: "{} in ?B" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}"
        "\<lambda>y9. \<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<not> x9 in A \<and> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" ] by mty auto  
    have  [ty]:"A is non empty" using A1 xboole_0_lm_1[of A] by mty auto
    then obtain X9 where
        x9: "X9 in A" using xboole_0_def_1[of A] by mty auto
    hence [ty]:"X9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
    hence
A30: "{} in A" using arytm_3_th_64[of X9] arytm_2_lm_7f[of _ X9 A] x9 by mty auto
    have 
    "for r st r in B holds (for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in B) & (ex s st s in B & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
      proof(rule ballI,intro impI conjI)
        fix r assume [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and  
      r: "r in B"
        hence r: "r in ?B" using B by simp
      obtain x9 where [ty]:"x9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A31:  "not x9 in A" and
A32:  "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using B Fraenkel_A1_ex[OF _ _ r] by mty auto

      show "for s st s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in B"
      proof(intro ballI impI)
        fix s assume [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
        "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
        hence "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_82[of x9 r s] arytm_3_def_12c[of x9] by mty auto
        hence "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using A32 arytm_3_th_67[of "succ {}" "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"]  by mty auto
        hence "\<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<not> x9 in A \<and> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using A31 bexI[of _ x9] 
           by mty auto
         thus "s in B" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s
           "\<lambda>y9. \<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<not> x9 in A \<and> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" ] B by mty auto      
       qed mauto
       have "A in DEDEKIND_CUTS" using Element(7) by mty auto
       hence " A in DEDEKIND_CUTS \\ RA" using  A24 xboole_0_def_5 by mty auto
      then obtain x99 where [ty]:"x99 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A33:  "not x99 in A" and
A34:  "x99 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9" using A1 A31 arytm_2_lm_18[of x9 A] by mty auto
      obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
A35:  "succ {} = x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using  A30 A33 arytm_3_th_55[of "succ{}" x99] by mty auto
      show "ex s st s in B & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
      proof(rule bexI[of _ s],rule conjI)
        have "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using arytm_3_def_13r A35 by mty auto
        thus "s in B" using B A33 bexI[of _ x99] Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s
        "\<lambda>y9. \<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. \<not> x9 in A \<and> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}"] by mty auto
        have
A36:    "s <> {}" using A35 arytm_3_th_48 by mty auto
        have "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A34 arytm_3_th_82 arytm_3_th_68[of x99 x9] by mty auto
        hence "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using 
          A32 A35 arytm_3_th_67[of "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"] by mty auto
        hence
A37:    "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A30 A33 arytm_3_th_80[of s r x99] arytm_3_def_12c[of x99] by mty auto
        have  a:"x99 <> x9 & x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A34 arytm_3_th_82[of s x9 x99] 
           arytm_3_th_68 by mty auto
        have "r <> s" 
        proof
          assume "r=s"
          hence "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s =\<^sub>\<S> x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using 
              a A32 A35 arytm_3_th_56 arytm_3_th_66[of "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] by mty auto
          thus False using a A32 A35 A36 arytm_3_th_56[of x9 x99 s] arytm_3_def_12c by mty auto
         qed
         thus "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using A37 arytm_3_th_68 by mty auto
      qed mauto
    qed mauto
    hence
A38: "B in IR" using Fraenkel_A1_in[of "Subset-of RAT\<^bsup>\<ge>0\<^bsub>" B] by mty auto
    obtain x9 where [ty]:"x9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A39: "x9 in A" and
A40: "x9 <> {}" using A1 arytm_2_lm_42[OF _ aa(2)] by mty auto
    obtain y9 where [ty]:"y9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A41: "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 = succ {}" using  A40 arytm_3_th_55[of "succ {}" x9]  by mty auto
    have "not y9 in B"
    proof
      assume "y9 in B"
      hence y:"y9 in ?B" using B by auto
      then obtain x99 where [ty]:"x99 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A42:    "not x99 in A & x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{}"
        using Fraenkel_A1_ex[OF _ _ y] by mty auto
      have
      y:"y9 <> {}" using A41 arytm_3_th_48 by mty auto
      have  "x99 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y9 " using A41 A42 by mty auto
      hence "x99  \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 " using  arytm_3_th_80[of x9 x99 y9] y by mty auto
      thus False using aa(2) A39 arytm_2_lm_7f[of x99 x9 A] A42 by mty auto
    qed
    hence "B <> RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
    hence "not B in {RAT\<^bsup>\<ge>0\<^bsub>}" using tarski_def_1 by mty auto
    hence "B in DEDEKIND_CUTS" unfolding arytm_2_def_1 using A38 xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}" B] all_set 
        by mty auto
    hence [ty]:"B is Element-of DEDEKIND_CUTS" using Element(6) by mty auto
    show "ex B being Element-of
    DEDEKIND_CUTS st A *D B = DEDEKIND_CUT rone"
    proof(rule bexI[of _ B]) 
      have  F: "for r holds r in A *D B iff r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{}"
       proof(rule ballI,rule iffI3)
         fix r assume [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
         show "r in A *D B \<longrightarrow> r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}"
         proof
           assume "r in A *D B"
           hence H:"r in { s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>, t be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
             s in A & t in B}" using arytm_2_def_7 by mty auto            
           obtain s t where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A43:         "r = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" and
A44:         "s in A" and
A45:         "t in B" using Fraenkel_A2_ex[OF _ _ _ _ H] by mty auto
           hence a45:"t in ?B" using B by auto
           obtain x9 where [ty]:"x9 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A46:         "not x9 in A" and
A47:         "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using  Fraenkel_A1_ex[OF _ _ a45] by mty auto
           have "not x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using  A44 A46 arytm_2_lm_7f[of x9 s A] by mty auto       
           hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9" using  A44 A46 arytm_3_th_68 by mty auto
           hence
A48:         "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_82 by mty auto
           have A49:"r <> succ {}"
           proof
             assume A50:"r = succ {}"
             hence t: "t <> {}" using A43 arytm_3_th_48 by mty auto
             have "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" 
               using A43 A44 A46 A47 A48 A50  by mty auto
             hence "t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9" using A48 arytm_3_th_66[of "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"]
               arytm_3_def_12c[of t x9] arytm_3_def_12c[of t s] by mty auto
             thus False using t A43 A44 A46 A47 arytm_3_th_56[of s x9 t] 
               by mty auto
           qed
           have "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{}" using A43 A47 A48 arytm_3_th_67[of "succ {}" "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mty auto  
           thus "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using A49 arytm_3_th_68 by mty auto
         qed
      assume
A51:  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}"
      hence
A52:  "r <> succ {}" " r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ{}" using arytm_3_th_68 by mty auto
      show "r in A *D B"
      proof(cases "r={}")
        case True
        hence "r = {}*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>{}" using arytm_3_th_48 by mty auto
        hence "r in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
          using A28 A30 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}" "{}"] 
          B by mty auto
        thus "r in A *D B" using arytm_2_def_7 by mty auto
      next
        case False
        then obtain r9 where [ty]:"r9 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A53:      "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9 = succ {}" using arytm_3_th_55[of "succ {}" r] by mty auto
        let ?rA = "{ r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s in A }"
        have  "?rA c= RAT\<^bsup>\<ge>0\<^bsub>"
        proof(rule tarski_def_3I[OF all_set all_set],intro ballI impI)
          fix e
          assume H:"e in ?rA"
          obtain  s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
            "e = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s in A" using Fraenkel_A1_ex[OF _ _ H] by mty auto 
          hence "e is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  by mty auto
          thus "e in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7)[of "RAT\<^bsup>\<ge>0\<^bsub>" e] by mty auto
        qed mauto
        hence [ty]:"?rA is Subset-of RAT\<^bsup>\<ge>0\<^bsub>" using Subset_of_rule by mty auto
        obtain dr where [ty]:"dr is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A54:    "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr = succ {}" using A52 arytm_3_def_13 by mty auto
        obtain xx where 
        xx: "xx in RAT\<^bsup>\<ge>0\<^bsub>" and
A55:      "not xx in A" using A26 xboole_0_def_10I[of A "RAT\<^bsup>\<ge>0\<^bsub>"] tarski_def_3 by mty auto
        have [ty]:"xx is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using xx Element(6) by mty auto
        let ?rr = "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr"
        have "dr <> {}" using A52 A54 arytm_3_th_50 by mty auto
        then obtain n0 where [ty]:"n0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A56:    "n0 in omega" and
A57:     "xx \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?rr" using A40 arytm_3_th_78[of dr x9] arytm_3_th_95[of xx ?rr] by mty auto
        hence [ty]:"n0 is Nat" using ordinal1_def_12 by mty auto
        let ?P="\<lambda>x .  x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?rr in A"
        have
A58:    "?P({})" using A30 arytm_3_th_48[of ?rr] arytm_3_def_12c[of "{}" ?rr]  by mty auto
        have
A59:    "not ?P(n0)" using A55 A57 arytm_2_lm_7f[of xx "n0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr)" A,simplified] by mty auto
        obtain n1 where [ty]:"n1 is Nat" and
A60:    "?P(n1)" and
A61:    "not ?P(n1 +\<^sub>\<S>\<^sup>\<nat> succ {})" using arytm_3_sch_1[of n0 ?P,OF _ A58 A59] by mty auto
        let ?S0 = "n1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?rr"
        have
A62:    "not ?S0 in ?rA"
        proof
          assume H:"?S0 in ?rA"
          obtain s0 where [ty]:"s0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A63:      "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 = ?S0" and
A64:      "s0 in A" using Fraenkel_A1_ex[OF _ _ H] by mty auto
          have "(n1 +\<^sub>\<S>\<^sup>\<nat> succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?rr = ?S0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?rr)" 
            using arytm_3_th_57s[of ?rr "succ{}" n1,simplified] arytm_3_th_58[of "succ {}" n1] 
            by mty auto
          hence 
A65:        "(n1 +\<^sub>\<S>\<^sup>\<nat> succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?rr = (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9)" using A63 arytm_3_th_53[of ?rr]
               arytm_3_def_12c A63 by mty auto
          show False
          proof(cases "s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9")
            case A66:True
              have "s0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A66 arytm_3_th_82[of r] arytm_3_def_13r by mty auto
              hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9" using arytm_3_def_12c by mty auto
              hence
A68:            "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9)" 
                using arytm_3_th_76[of "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9" "dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9"] by mty auto
              have"(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) = (r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9" 
                using arytm_3_th_57s[of x9 dr r] by mty auto
              hence "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) = x9" using A54 arytm_3_th_53 arytm_3_def_12c by mty auto 
              thus False using A68 A61 A39 A65 arytm_2_lm_7f[of "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9)" x9 A] by mty auto
            next 
              case False 
              hence A66: " x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using arytm_3_def_13c[of x9 s0] by mty auto
              have  "x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr" 
              using A66 arytm_3_th_82[of r] arytm_3_th_82[of dr] by mty auto
              hence "dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" 
                 using arytm_3_def_12c by mty auto
              hence " (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0)" 
                 using arytm_3_th_76[of ] by mty auto
              hence
A68:           "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0)" 
                using arytm_3_def_11c by mty auto
              have
                "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) = (r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0" using arytm_3_th_57s[of s0 dr r] by mty auto
              hence "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) = s0" using A54 arytm_3_th_53 arytm_3_def_12c by mty auto
              hence "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) in A" 
                using A68 A64  arytm_2_lm_7f[of "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0)" s0  A] by mty auto
              thus False using A61 A65 A68 arytm_2_lm_7f[of "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x9)" "(r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (dr *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s0)"  A] 
                by mty auto
          qed
        qed  
        have A69:"not ?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9 in A"
        proof
          assume
A70:      "?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9 in A"
          have "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9) = (succ {})*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?S0" using A53 arytm_3_th_52[of ?S0 r9 r] arytm_3_def_12c[of ?S0 r9] 
             by mty auto
           hence H:"r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9) = ?S0" using arytm_3_th_53[of "?S0"] arytm_3_def_12c[of ?S0] 
             by mty auto
           have "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9) in ?rA" using A70 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9"] 
             by mty auto
           thus False using H A62 by auto 
        qed
        have "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = {}" using arytm_3_th_48 by mty auto
        hence "{} in ?rA" 
          using A30 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}" "\<lambda>s. s in A" "\<lambda>s. r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] by mty auto
        hence "?S0 <>{}" using A62 by auto
        then obtain s9 where [ty]:"s9 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A71:      "?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9 = succ{}" using A62 arytm_3_th_55[of "succ {}" "?S0"]  by mty auto
        have "?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9) = (?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_52[of  r s9 ?S0] 
           arytm_3_def_12c[of r s9] by mty auto
        hence A72: "?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9) = r" using A71 arytm_3_th_53[of r] arytm_3_def_12c by mty auto
        have "(?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9) = ((?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9 )*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9" 
             using arytm_3_th_52[of s9 r] by mty auto
        also have "... = (?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9" 
             using A53 arytm_3_th_52[of r r9 ?S0] arytm_3_def_12c[of r r9] by mty auto
        also have "... = succ {}" using A71 arytm_3_th_53  by mty auto
        finally have  "(?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using arytm_3_def_13r by mty auto
        hence "\<exists>x9 : Element-of RAT\<^bsup>\<ge>0\<^bsub>. (\<not> x9 in A \<and> x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9) \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {}))" 
          using A69 bexI[of _ "?S0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r9"] by mty auto 
        hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9 in B" 
          using A69 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9" _ "\<lambda>y9. y9"] B by mty auto
        
         hence "r in  { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
           using A60 A72 Fraenkel_A2_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "n1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x9 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dr)" 
           "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s9" "\<lambda>r s. r in A \<and> s in B" "\<lambda>r s. r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"] by mty auto
        thus "r in A *D B" using arytm_2_def_7 by mty auto      
      qed
    qed mauto
     have "rone in RAT\<^bsup>\<ge>0\<^bsub>" using A0 Element(7) by mty auto
     hence DC:"DEDEKIND_CUT rone = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rone }" 
      using arytm_2_def_3[of rone] A0 by mty auto
    thm arytm_2_lm_12
    show "A *D B =\<^sub>\<S> DEDEKIND_CUT rone"
    proof(standard,auto)
      fix x assume x: "x in A *D B"
        hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
        have "x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rone" using F x A0 by mty auto
        thus "x in DEDEKIND_CUT rone" using DC
          Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x " \<lambda>s. s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rone"] by mty auto
      next
        fix x assume "x in DEDEKIND_CUT rone" 
        hence x:"x in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rone }" using DC by auto
        obtain s where [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
          x:"x=s & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> rone" using Fraenkel_A1_ex[OF _ _ x] by mty auto
        thus "x in A *D B" using A0 F by mty auto
    qed mauto
  qed mauto
qed
qed mauto

mtheorem arytm_2_th_14:
  "x <> {} implies (ex y st x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = 1\<^sub>\<S>)"
proof
  assume "x <> {}"
  hence "DEDEKIND_CUT x <> {}" using arytm_2_lm_10 by mty auto
  hence "ex B being Element-of DEDEKIND_CUTS st 
    (DEDEKIND_CUT x) *D B = DEDEKIND_CUT (succ {})"
  using arytm_2_lm_43 by mty auto
  then obtain B where [ty]:"B is Element-of DEDEKIND_CUTS" and
    B: "(DEDEKIND_CUT x) *D B = DEDEKIND_CUT (succ {})" by auto
  show "ex y st x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = 1\<^sub>\<S>"
  proof(rule bexI[of _ "GLUED B"])
    have "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> GLUED B = GLUED DEDEKIND_CUT (succ {})" 
      using arytm_2_def_9[of x "GLUED B"]  using B arytm_2_lm_12 by mty auto
    thus "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> GLUED B = succ {}" using arytm_2_lm_23 by mty auto
  qed mauto
qed

mtheorem arytm_2_lm_44: 
  "for A,B being Element-of DEDEKIND_CUTS st A = { r  where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {} } 
holds A *D B = B"
proof(intro ballI,rule impI,rule xboole_0_def_10I[OF all_set all_set])
  fix A B assume [ty]:"A is Element-of DEDEKIND_CUTS" "B is Element-of DEDEKIND_CUTS" and
      A1: "A = { r  where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {} }"
  show "A *D B c= B"
  proof(rule tarski_def_3I[OF all_set all_set], auto)
    fix x 
    assume "x in A *D B"
    hence x: "x in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
      using arytm_2_def_7 by mty auto
    obtain r s where [ty]:" r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "x = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" and
A3: "r in A" and
A4: "s in B" using Fraenkel_A2_ex[OF _ _ _ _ x] by mty auto
    have x:"r in { r1  where r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {} }" using A1 A3 by auto
    have "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using Fraenkel_A1_ex[OF _ _ x] by mty auto
    hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using arytm_3_th_68 by mty auto
    hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_th_82 by mty auto
    hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_th_53[of s] arytm_3_def_12c by mty auto
    thus "x  in B" using  A2 A4 arytm_2_lm_7f[of "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" s B] by mty auto
  qed
  show "B c= A *D B"
  proof(rule tarski_def_3I[OF all_set all_set], auto) 
    fix s  assume A5: "s in B"
      hence [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto 
      obtain s1 where [ty]:"s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A6: "s1 in B" and
A7: "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" using A5 arytm_2_lm_7[of s B] by mty auto
    have "s1 <> {}" using A7 arytm_3_th_64 by mty auto
    then obtain s2 where [ty]:"s2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
A8: "s1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2 = s" using arytm_3_th_55[of s s1] by mty auto
    have A9: "s2 <> succ {}"
    proof
      assume "s2 = succ {}"
      hence "s = s1" using A8 arytm_3_th_53 by mty auto
      then show False using A7 arytm_3_th_68 by mty auto
    qed
    have "(succ {}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = s2 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1" using A8 arytm_3_th_53[of s] arytm_3_def_12c  by mty auto
    hence "s2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using A7 arytm_3_th_83[of s2 s1 "succ {}" s] by mty auto
    hence "s2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> succ {}" using A9 arytm_3_th_68 by mty auto
    hence "s2 in A" using A1 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" s2] by mty auto
    hence "s2 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: r in A & s in B}"
      using A6 Fraenkel_A2_in by mty auto
    hence "s2 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 in A *D B" using arytm_2_def_7 by mty auto
    thus "s in A *D B" using A8 arytm_3_def_12c by mty auto
  qed
qed mauto

mtheorem arytm_2_th_15:
  "(succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y"
proof-
  have T: "DEDEKIND_CUT succ {} be Element-of DEDEKIND_CUTS"
    "DEDEKIND_CUT y be Element-of DEDEKIND_CUTS" by mty auto
  have "succ {} in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  hence H: "DEDEKIND_CUT succ {} = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  succ {} }"
    using arytm_2_def_3 by mty auto
  have "(succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED ((DEDEKIND_CUT (succ {})) *D (DEDEKIND_CUT y))" 
    using arytm_2_def_9[of "succ {}" y] by mty auto
  hence  "(succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED ((DEDEKIND_CUT y)) "
    using arytm_2_lm_44[OF T H] H by mty auto
  thus  "(succ {}) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = y" using arytm_2_lm_23 by mty auto 
qed

mtheorem arytm_2_th_82:
  "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y implies x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"
proof                                      
  assume "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  then obtain xx where [ty]: "xx is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and
A1: "y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> xx" using arytm_2_th_9[of y x] by mauto
  hence "y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = (x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (z*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> xx)" using arytm_2_th_13[of xx x z] arytm_2_def_9_c[of z y]
    arytm_2_def_9_c[of z x]  by mauto
  hence "y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z = (z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> xx) +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using  arytm_2_def_8c[of "z*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> xx" "x*\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z"]  by mauto
  thus "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_2_th_19[of " x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> z " "z *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> xx"]  by mty auto
qed


reserve r,s,t for "Element-of REAL\<^bsup>\<ge>0\<^bsub>"

mtheorem arytm_2_th_67:
  "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t implies r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"
proof
  assume AS: "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  then obtain x where [ty]:"x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
    A1: "s = r +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_2_th_9[of  s r] by mty auto
  obtain y where [ty]:"y is Element-of REAL\<^bsup>\<ge>0\<^bsub>" and 
    A2: "t = s +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using AS arytm_2_th_9[of t s] by mty auto
  hence "t = r+\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> (x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y)" using A1 arytm_2_th_6[of y x r] by mty  auto
  thus "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_2_th_19[of r "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"] arytm_2_def_8c by mty auto
qed

mtheorem arytm_2_th_69:
  "r <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t or r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> s & s <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t implies r <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  using arytm_2_th_67 arytm_2_def_5c ty by blast


theorem arytm_3_th_90B:
  assumes [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  shows  "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <> {} & r <>{} implies 
    (ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
       s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
proof
  assume R: " s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<and> t \<noteq> {} \<and> r \<noteq> {}"
  then obtain r0 t0 where [ty]:"r0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     rt: "s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 \<and> r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<and> t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<and> t0 \<noteq> t" using arytm_3_th_90[of s t r] by mty auto
  hence t0: "t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_68 by mty auto
  then obtain t1 where [ty]:"t1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    t1: "t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" "t1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_93[of t0 t] by mty auto
  then obtain dt where [ty]:"dt is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    dt: "t1 =\<^sub>\<H> t0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dt" "dt <>{}" using arytm_3_def_13l by mty auto 
  show "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st
       s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
    proof(cases "r0 <>r")
       case True
       hence "r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using rt arytm_3_th_68 by mty auto
       thus "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st
         s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using t0 rt bexI[of _ r0] bexI[of _ t0] by mty auto
     next
       case F2: False
        show "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st
         s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"     
       proof(cases "dt \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0")
         case True
           then obtain h where [ty]:"h be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             h: "r0 = dt +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> h" using arytm_3_def_13 by mty auto   
           hence H: "h <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using F2 dt arytm_3_def_13l dt bexI[of _ dt] arytm_3_def_11c[of dt h] 
             by mty auto

           have "s =  (h +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> dt" using rt h arytm_3_th_51[of t0 h dt] 
             arytm_3_def_11c[of dt] by mty auto
           hence "s = h +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" using  arytm_3_th_51[of dt t0 h] dt by mty auto
           thus "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st
              s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using t1 H bexI[of _ h] bexI[of _ t1] by mty auto
         next
           have H1: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using F2 arytm_3_th_64[of r] arytm_3_th_68[of "{}" r] R by mty auto
           case False
           then obtain h where [ty]:"h be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
             h: "dt = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> h"  using arytm_3_def_13l by mty auto
           hence "t1  = (t0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> h" using dt arytm_3_th_51[of h r0 t0] by mty auto     
           hence "t0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" using arytm_3_def_13 bexI[of _ h] by mty auto 
           hence H2: "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using t1 arytm_3_th_69[of t "t0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r0" t1] 
              arytm_3_def_11c[of r0 t0] by mty auto           
           have "s = {} +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0)" using rt arytm_3_th_50[of "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"]
              arytm_3_def_11c[of "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"] by  mty auto
           thus "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st
              s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using H1 H2 bexI[of _ "{}"] bexI[of _ "r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"] 
             by mty auto
         qed
       qed
qed
text_raw {*\DefineSnippet{Prat_Preal_add}{*}
theorem Prat_Preal_add:
  assumes [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  shows "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
text_raw {*}%EndSnippet*}
proof(cases "x={} or y={}")
  case True
  hence "(x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = y & x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y =y) or (x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x & x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y =x)" 
    using arytm_3_th_50[of x] arytm_3_th_50[of y] 
     arytm_3_def_11c[of x y] arytm_2_def_8[of x y] by mty auto
  thus "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" by auto
next
  case F: False
  have [ty]: "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
  have XY:"x in RAT\<^bsup>\<ge>0\<^bsub>" "y in RAT\<^bsup>\<ge>0\<^bsub>" "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto 
  hence D:"DEDEKIND_CUT x = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x }" 
        "DEDEKIND_CUT y = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }" 
      using arytm_2_def_3[of x,simplified] arytm_2_def_3[of y,simplified] by mty auto
    have I1: "(DEDEKIND_CUT x) +D (DEDEKIND_CUT y) \<subseteq> { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }"
    proof(rule tarski_def_3I,auto)
      fix z assume "z in (DEDEKIND_CUT x) +D (DEDEKIND_CUT y)"
      hence Z: "z in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
        r in DEDEKIND_CUT x & s in DEDEKIND_CUT y}"
        using arytm_2_def_6[of "DEDEKIND_CUT x" "DEDEKIND_CUT y",simplified] by mty auto
      obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         st: " z = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in DEDEKIND_CUT x & t in DEDEKIND_CUT y" 
        using Fraenkel_A2_ex [OF _ _ _ _ Z] by mty auto
      have "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" "t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using st D Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
      hence "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_76 by mty auto
      hence "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_3_th_68 arytm_3_def_11c[of x] 
        by mty auto
      hence "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_3_th_69[of "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"  "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mty auto
      hence "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t in { w where w be Element-of RAT\<^bsup>\<ge>0\<^bsub>: w <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }" 
        using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "\<lambda>s. s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" "\<lambda>w. w"]
        by mty auto
      thus "z in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }" using st by auto
    qed mauto
  have "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y } \<subseteq> (DEDEKIND_CUT x) +D (DEDEKIND_CUT y)"
  proof(rule tarski_def_3I,auto)
    fix z assume Z: "z in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }"
    obtain s where [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     s: "z=s & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using Fraenkel_A1_ex[OF _ _ Z] by mty auto
    then obtain x0 y0 where TY[ty]:"x0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "y0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     xy: "s = x0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y0 \<and> x0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x  \<and> y0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y " using s arytm_3_th_90B[of s x y] F by mty auto
    hence "x0 in DEDEKIND_CUT x" "y0 in DEDEKIND_CUT y" 
      using D Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x0 ] 
      Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" y0 ] by mty auto
    hence "x0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y0 in { r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
        r in DEDEKIND_CUT x & s in DEDEKIND_CUT y}"
        using Fraenkel_A2_in by mty auto
    thus  "z in (DEDEKIND_CUT x) +D (DEDEKIND_CUT y)" using s xy arytm_2_def_6 by mty auto
  qed mauto
  hence "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y } = (DEDEKIND_CUT x) +D (DEDEKIND_CUT y)" 
    using xboole_0_def_10 I1 by mty auto
  hence "DEDEKIND_CUT( x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) = (DEDEKIND_CUT x) +D (DEDEKIND_CUT y)" 
    using arytm_2_def_3[of "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y",simplified] XY by mty auto
  hence "x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED(DEDEKIND_CUT( x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y))" using arytm_2_def_8 F by mty auto
  thus "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using  arytm_2_lm_23 by mty auto
qed

theorem arytm_3_th_79B:
  assumes [ty]:"s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  shows  "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <> {} & r <>{} implies 
    (ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
       s = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
proof
  assume AS: "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <> {} & r <>{}"
  hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_68 by mty auto
  then obtain t0 where [ty]:"t0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    t0: "s = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_79[of t r s] by mty auto
  hence "t0 <>t" using AS arytm_3_def_13r by mty auto  
  hence "t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_68 t0 by mty auto
  then obtain t1 where [ty]:"t1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
     t1: "t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" "t1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_93[of t0 t] by mty auto
  hence "t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" "s = t0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using  arytm_3_th_68[of t0 t1] t0 arytm_3_def_12c by mty auto
  hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_82 by mty auto
  then obtain t2 where [ty]:"t2 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    t2: "s = t1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t2 & t2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"  
    using  arytm_3_th_79[of r t1 s] by mty auto
  have "t2 <>r"
  proof
    assume "t2=r"
    hence "t0=t1" using arytm_3_th_56[of t1 t0 r] AS t0 t2 arytm_3_def_12c[of t2 t1] by mty auto
    thus False using t1 arytm_3_def_13r by mty auto
  qed
  hence "t2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using t2  arytm_3_th_68 by mty auto
  thus "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
       s = r0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using t1 t2 arytm_3_def_12c[of t2 t1] 
      bexI[of _ t1] bexI[of _ t2] by mty auto
qed
text_raw {*\DefineSnippet{Prat_Preal_mult}{*}
theorem Prat_Preal_mult:
  assumes [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>"  "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  shows "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y"
text_raw {*}%EndSnippet*}
proof(cases "x={} or y={}")
  case True
  hence "(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x & x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y =x) or (x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = y & x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y =y)" 
    using arytm_3_th_48[of x] arytm_3_th_48[of y]  arytm_2_def_9_c
     arytm_3_def_12c[of x y] arytm_2_th_4[of x y] arytm_2_th_4[of y x] by mty auto
  thus "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" by auto
next
  case F: False
  have [ty]: "x be Element-of REAL\<^bsup>\<ge>0\<^bsub>" by mty auto
  have XY:"x in RAT\<^bsup>\<ge>0\<^bsub>" "y in RAT\<^bsup>\<ge>0\<^bsub>" "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto 
  hence D:"DEDEKIND_CUT x = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x }" 
        "DEDEKIND_CUT y = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }" 
      using arytm_2_def_3[of x,simplified] arytm_2_def_3[of y,simplified] by mty auto
    have I1: "(DEDEKIND_CUT x) *D (DEDEKIND_CUT y) \<subseteq> { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }"
    proof(rule tarski_def_3I,auto)
      fix z assume "z in (DEDEKIND_CUT x) *D (DEDEKIND_CUT y)"
      hence Z: "z in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
        r in DEDEKIND_CUT x & s in DEDEKIND_CUT y}"
        using arytm_2_def_7[of "DEDEKIND_CUT x" "DEDEKIND_CUT y",simplified] by mty auto
      obtain s t where [ty]: "s is Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
         st: " z = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s in DEDEKIND_CUT x & t in DEDEKIND_CUT y" 
        using Fraenkel_A2_ex [OF _ _ _ _ Z] by mty auto
      have L: "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" "t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using st D Fraenkel_A1_ex[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
      have "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"
      proof(cases "s = {} or t={}")
        case T: True
          hence ST: "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = {}" using arytm_3_th_48 arytm_3_def_12c[of s t] by mty auto 
          have " x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y <>{}" using F arytm_3_th_78[of y x] by mty auto
          hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" 
            using arytm_3_th_68[of "{}" "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"] arytm_3_th_64[of "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"] by mty auto 
          thus "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t  <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using ST by auto 
      next
        case False
          hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"
            using arytm_3_th_80[of s x t] arytm_3_th_80[of t y x] L F 
              arytm_3_def_12c[of x] by mty auto
          thus "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_3_th_70[of "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mty auto
      qed
      hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t in { w where w be Element-of RAT\<^bsup>\<ge>0\<^bsub>: w <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }" 
        using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "\<lambda>s. s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" "\<lambda>w. w"]
        by mty auto
      thus "z in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }" using st by auto
    qed mauto
  have "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y } \<subseteq> (DEDEKIND_CUT x) *D (DEDEKIND_CUT y)"
  proof(rule tarski_def_3I,auto)
    fix z assume Z: "z in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y }"
    obtain s where [ty]:"s be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     s: "z=s & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using Fraenkel_A1_ex[OF _ _ Z] by mty auto
    then obtain x0 y0 where TY[ty]:"x0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "y0 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     xy: "s = x0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y0 \<and> x0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x  \<and> y0 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y " using s arytm_3_th_79B[of s x y] F by mty auto
    hence "x0 in DEDEKIND_CUT x" "y0 in DEDEKIND_CUT y" 
      using D Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" x0 ] 
      Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" y0 ] by mty auto
    hence "x0 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y0 in { r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s where r be Element-of RAT\<^bsup>\<ge>0\<^bsub>, s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: 
        r in DEDEKIND_CUT x & s in DEDEKIND_CUT y}"
        using Fraenkel_A2_in by mty auto
    thus  "z in (DEDEKIND_CUT x) *D (DEDEKIND_CUT y)" using s xy arytm_2_def_7 by mty auto
  qed mauto
  hence "{ s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y } = (DEDEKIND_CUT x) *D (DEDEKIND_CUT y)" 
    using xboole_0_def_10 I1 by mty auto
  hence "DEDEKIND_CUT( x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) = (DEDEKIND_CUT x) *D (DEDEKIND_CUT y)" 
    using arytm_2_def_3[of "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y",simplified] XY by mty auto
  hence "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = GLUED(DEDEKIND_CUT( x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y))" using arytm_2_def_9 F by mty auto
  thus "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y" using  arytm_2_lm_23 by mty auto
qed


mtheorem arytm_2_TH1:
  "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x \<longrightarrow> (ex r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & r <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x)"
proof
  assume "{} <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
  hence "x <>{}" using  arytm_2_def_5r by mty auto
  hence "DEDEKIND_CUT(x)<>{}" "DEDEKIND_CUT(x) in DEDEKIND_CUTS"
     using arytm_2_lm_10 Element(7) by mty auto
   then obtain r where [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      r:   "r in DEDEKIND_CUT(x)" "r <>{}" using arytm_2_lm_15[of "DEDEKIND_CUT(x)"] by mty auto
   show "ex r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & r <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x"
   proof(rule bexI[of _ r], rule conjI)
     show "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r " using r arytm_3_th_65[of r] by mty auto
    have R:"r in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto
  
     have rx: "r <>x"
     proof
       assume "r=x"
       hence W: "r in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r }" 
         using arytm_2_def_3[of r] R r by mty auto
       have  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using Fraenkel_A1_ex[OF _ _ W] by mty auto
       thus False using arytm_3_def_13r[of r] by mty auto
     qed
   have "DEDEKIND_CUT(r) \<subseteq> DEDEKIND_CUT(x)"
   proof(rule tarski_def_3I, auto)
     fix y assume  "y in DEDEKIND_CUT(r)"
     hence x: "y in { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r }" using arytm_2_def_3[of r] R by mty auto
     have [ty]: "y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and "y <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"using Fraenkel_A1_ex[OF _ _ x]by mty auto    
     hence "y\<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_68 by mty auto
     thus "y in DEDEKIND_CUT(x)" using arytm_2_lm_7f[of y r "DEDEKIND_CUT(x)" ] r by mty auto  
   qed mauto
   hence "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_2_lm_20 by mty auto  
   thus "r <\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> x" using rx arytm_2_th_68 by mty auto
 qed mauto
qed

mtheorem arytm_2_TH2:
  "ex r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r"
proof-
  let ?A= "DEDEKIND_CUT(x)"
 have "?A in DEDEKIND_CUTS"  
         using Element(7)[of "DEDEKIND_CUTS"] by mty auto
      hence "not ?A in {RAT\<^bsup>\<ge>0\<^bsub>}" unfolding arytm_2_def_1 using xboole_0_def_5[of _ "{RAT\<^bsup>\<ge>0\<^bsub>}"] 
        all_set by mty auto
      hence "?A<>RAT\<^bsup>\<ge>0\<^bsub>" using tarski_def_1 by auto 
      hence "not RAT\<^bsup>\<ge>0\<^bsub> \<subseteq> ?A" using xboole_0_def_10 Subset_in_rule by mty auto
      then obtain b where
A1:   "b in RAT\<^bsup>\<ge>0\<^bsub>" "not b in ?A" using tarski_def_3 by mty auto 
      hence [ty]:"b be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element by auto
      have D: "DEDEKIND_CUT(b) = { s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b }"
        using arytm_2_def_3[of b] A1 by mty auto
      
      have "?A \<subseteq> DEDEKIND_CUT(b)"
      proof(rule tarski_def_3I[OF all_set all_set],rule ballI, rule impI, rule ccontr)
        fix xa assume C1:"xa in ?A" "\<not>  xa in DEDEKIND_CUT(b)"
        hence [ty]:"xa is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using ES by mty auto
        have "b \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> xa" using D C1(2) Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" xa "\<lambda>s. s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b" "\<lambda>s. s"] 
          by mty auto
        thus False using arytm_2_lm_7f[of b xa ?A] C1 A1(2)by mty auto
      qed mauto
    hence "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> b" using arytm_2_lm_20 by mty auto 
    thus "ex r be Element-of RAT\<^bsup>\<ge>0\<^bsub> st x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using bexI[of _ b] by mty auto
qed

mtheorem arytm_2_TH3:
  "ex r be Element-of NAT st x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r"
proof-
  obtain r where [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   r: "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_2_TH2[of x] by mty auto
  obtain n where [ty]: "n be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
  A1: "n in omega" and
  A2: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ{})" using arytm_3_th_95[of r "succ{}"] by mty auto
  hence "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_3_th_53 by mty auto
  hence "r \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" using arytm_2_lm_14 by mty auto
  hence "x \<le>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> n" "n is Element-of NAT"
    using arytm_2_th_67[of n r x] r A1 Element(6) by mty auto
  thus ?thesis using bexI[of _ n] by mty auto
qed

end