theory arytm_3
  imports nat_1
          "../mizar/mizar_fraenkel_2"
(*    "~~/src/HOL/Number_Theory/Primes" *)
    
begin
  
mdef arytm_3_def_2 ("_ , _ are-coprime" [0,0]90) where
  mlet "a be Nat", "b be Nat"
  "pred a,b are-coprime means 
     \<forall> c:Nat, d1:Nat,d2 be Nat. a =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d1 \<and> b =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d2 \<longrightarrow> c =\<^sub>\<S> 1\<^sub>\<S>"..


mtheorem arytm_3_def_2s:
  "n,k are-coprime \<longrightarrow> k,n are-coprime"
proof(intro impI arytm_3_def_2I ballI)
  assume A1: "n,k are-coprime"
  fix c d1 d2 assume [ty]: "c be Nat" "d1 be Nat" "d2 be Nat"
  and "k =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d1 \<and> n =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d2 "
  thus "c =\<^sub>\<S> 1\<^sub>\<S>" using arytm_3_def_2E[OF _ _ A1,
     THEN bspec,THEN bspec,THEN bspec,of c d2 d1] by mauto
qed mauto

mtheorem arytm_3_th_1:  "\<not> 0\<^sub>\<S>,0\<^sub>\<S> are-coprime"
proof
  assume A1: "0\<^sub>\<S>,0\<^sub>\<S> are-coprime"
  have "0\<^sub>\<S> =\<^sub>\<S> 0\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> 0\<^sub>\<S>" using Mult_1 by auto 
  hence "{} =\<^sub>\<S> 1\<^sub>\<S>" using arytm_3_def_2E[of "0\<^sub>\<S>"  "0\<^sub>\<S>",
    THEN bspec,THEN bspec]  A1 by mauto 
  thus "False" using one2 xboole_0_def_10 by auto
qed

mtheorem arytm_3_th_2:  "1\<^sub>\<S>,n are-coprime"
proof(standard,simp,simp,intro ballI impI)
  fix c d1 d2 assume [ty]: "c is Nat" "d1 is Nat" "d2 is Nat"
  "1\<^sub>\<S> =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d1 \<and> n =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d2"
  thus "c =\<^sub>\<S> 1\<^sub>\<S>" using  Mult_8[of d1 c] by mauto
qed mauto

mtheorem arytm_3_th_3: "0\<^sub>\<S>,n are-coprime \<longrightarrow> n =\<^sub>\<S> 1\<^sub>\<S>"
proof
  assume A1: "0\<^sub>\<S>,n are-coprime"
  have "0\<^sub>\<S> = n *\<^sub>\<S>\<^sup>\<nat> 0\<^sub>\<S>" "n = n *\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" using Mult_2 Mult_5 by mauto
  thus "n =\<^sub>\<S> 1\<^sub>\<S>" using arytm_3_def_2E[of "0\<^sub>\<S>"  n,
    THEN bspec,THEN bspec,THEN bspec, of n "0\<^sub>\<S>" "1\<^sub>\<S>"]  A1 by mauto
qed

mtheorem arytm_3_th_9:  "n divides m \<and> m divides n \<longrightarrow> n = m"
proof
  assume AS: "n divides m \<and> m divides n"
  show "n=m"
  proof(cases "n={}\<or>m={}")
    case True
    hence "n={}" "m={}" using div_4 AS by mauto
    thus "n=m" by simp
  next
    case False
    hence "n \<subseteq> m" "m \<subseteq> n" using AS div_2 by auto
    thus "n=m" using xboole_0_def_10  by simp
  qed
qed


mtheorem arytm_3_th_10:
   "n divides {} & 1\<^sub>\<S> divides n" using div_1 div_3 by auto


mtheorem arytm_3_th_11:
  " n divides k & {} in k implies n c= k & n <> {}"
proof
  assume AS: " n divides k & {} in k"
  hence "k<>{}" using xb by auto
  thus "n c= k & n <> {}" using AS div_2 by mauto
qed

mdef arytm_3_def_4 ("_ lcm _" [60,61]60) where
 mlet "k be Nat", "n be Nat"   
 "func k lcm n \<rightarrow> Nat means
    \<lambda>it. k divides it \<and> n divides it \<and>
         (\<forall>m: Nat. k divides m \<and> n divides m \<longrightarrow> it divides m)"
proof-
  let ?P = "\<lambda>it. (k divides it \<and> n divides it)"
  let ?R = "\<lambda>it. ?P(it) \<and> k c= it"
  show  "\<exists>it :
     Nat.(k divides it \<and> n divides it \<and>
         (\<forall>m: Nat. k divides m \<and> n divides m \<longrightarrow> it divides m))"
  proof(cases "k={} or n={}")
    case T: True     
     show "\<exists>x : Nat. k divides x \<and>
          n divides x \<and> (\<forall>m : Nat. ?P(m) \<longrightarrow> x divides m)" 
     proof(rule bexI[of _ "{}" Nat],intro conjI ballI impI)
       show "k divides {}" "n divides {}" using arytm_3_th_10 by mauto
       fix i assume [ty]:"i be Nat" and "?P(i)"
       hence "i={}" using T div_4 by auto
       thus "{} divides i" using arytm_3_th_10  by mauto
     qed mauto
   next
     case F:False
     hence A3: "{} in k" "{} in n" using xb ordinal1_th_10 by mauto
     hence A4:" succ {} \<subseteq> n" using one1 by mauto
     have "?P(k*\<^sub>\<S>\<^sup>\<nat>n)\<and> k c=  k*\<^sub>\<S>\<^sup>\<nat>n"
         using div_9 Mult_7 F by auto
     hence I: "\<exists>i : Nat. ?R(i)" using bexI[of _ " k*\<^sub>\<S>\<^sup>\<nat>n" Nat] by mauto
     obtain l where
        [ty]:"l is Nat" and
        A7: "?R(l) \<and> (\<forall>i:Nat. ?R(i) \<longrightarrow> l \<subseteq> i)" 
           using MinInd[OF I]  by mauto  
    show "\<exists>x : Nat. k divides x \<and>
          n divides x \<and> (\<forall>m : Nat. ?P(m) \<longrightarrow> x divides m)" 
     proof(rule bexI[of _ l Nat],intro conjI ballI impI)
       show A10:"k divides l" "n divides l" using A7 by auto
       fix m assume [ty]:"m is Nat" and A13: "?P(m)"
       have "{} in l" using A3 A7 tarski_def_3E[of k l] by mauto
       hence L:"l<>{}" using xb by auto
       obtain mDl mMl where
         [ty]: " mDl is Nat " "mMl is Nat" and
          A15: "m = mDl *\<^sub>\<S>\<^sup>\<nat> l +\<^sub>\<S>\<^sup>\<nat> mMl \<and> mMl in l"
         using L div_8[of m l] by mauto
       obtain lDk where
         [ty]:"lDk is Nat" and
         B:"l = k *\<^sub>\<S>\<^sup>\<nat> lDk" using A10 div[of k l] by mauto
       hence "l *\<^sub>\<S>\<^sup>\<nat> mDl = (k *\<^sub>\<S>\<^sup>\<nat> lDk) *\<^sub>\<S>\<^sup>\<nat> mDl" by auto 
       hence "l *\<^sub>\<S>\<^sup>\<nat> mDl = k *\<^sub>\<S>\<^sup>\<nat> (lDk *\<^sub>\<S>\<^sup>\<nat> mDl)" using Mult_13 by auto
       hence " k divides mDl *\<^sub>\<S>\<^sup>\<nat> l" using divI[of k "l *\<^sub>\<S>\<^sup>\<nat> mDl"]
          bexI[of _ "lDk *\<^sub>\<S>\<^sup>\<nat> mDl" Nat] Mult_6[of l mDl]  by mauto
       hence A16: " k divides mMl" using A15 L A13 
         div_7[of mMl "mDl *\<^sub>\<S>\<^sup>\<nat> l" k] by mauto
       obtain lDn where
         [ty]:"lDn is Nat" and
         C:"l = n *\<^sub>\<S>\<^sup>\<nat> lDn" using A10 div[of n l] by mauto
       hence "l *\<^sub>\<S>\<^sup>\<nat> mDl = (n *\<^sub>\<S>\<^sup>\<nat> lDn) *\<^sub>\<S>\<^sup>\<nat> mDl" by auto 
       hence "l *\<^sub>\<S>\<^sup>\<nat> mDl = n *\<^sub>\<S>\<^sup>\<nat> (lDn *\<^sub>\<S>\<^sup>\<nat> mDl)" using Mult_13 by auto
       hence " n divides mDl *\<^sub>\<S>\<^sup>\<nat> l" 
         using divI[of n "l *\<^sub>\<S>\<^sup>\<nat> mDl"] Mult_6[of l mDl] 
         bexI[of _ "lDn *\<^sub>\<S>\<^sup>\<nat> mDl" Nat] by mauto
       hence A17:"n divides mMl" using A15 L A13 
         div_7[of mMl "mDl *\<^sub>\<S>\<^sup>\<nat> l" n] by mauto
       have "mMl={}"  
       proof(rule ccontr)
         assume "mMl<>{}"
         hence "{} in mMl" using xb ordinal1_th_10 by mauto
         hence "k c= mMl" using A16 arytm_3_th_11 by auto
         hence "l c= mMl" "mMl \<subset> l" 
            using A7 A16 A17 ordinal1_th_7a[of mMl l] A15 by mauto
          thus "False" using xboole_0_def_10 xboole_0_def_8 by mauto
       qed
       hence "m = l *\<^sub>\<S>\<^sup>\<nat> mDl" using A15 Add_3 Mult_6[of l mDl] by mauto   
       thus "l divides m" using divI[of l m] bexI[of _ mDl Nat] by mauto
     qed mauto   
   qed
   fix x y assume  [ty]: "x be Nat" "y be Nat"
     and A1:"k divides x \<and>
           n divides x \<and> (\<forall>m : Nat. k divides m \<and> n divides m \<longrightarrow> x divides m)"
     and A2:"k divides y \<and>
           n divides y \<and> (\<forall>m : Nat. k divides m \<and> n divides m \<longrightarrow> y divides m)"
   have "x divides y" "y divides x" using A1 A2 by auto
   thus "x=y" using div_10 by auto
 qed mauto

mtheorem arytm_3_def_4_commutativity:
  "k lcm n = n lcm k"
proof-
  have K: "k divides (k lcm n)" "n divides (k lcm n)" using arytm_3_def_4 by mauto 
  have "\<forall>m : Nat. n divides m \<and> k divides m \<longrightarrow> k lcm n divides m" 
    using  arytm_3_def_4[of k n] by auto
  thus "k lcm n = n lcm k" using arytm_3_def_4_uniq[of n k "k lcm n"] K by auto
qed

mtheorem arytm_3_th_12:
  "m lcm n divides m *\<^sub>\<S>\<^sup>\<nat> n"
proof-
  have "n divides m *\<^sub>\<S>\<^sup>\<nat> n \<and> m divides m *\<^sub>\<S>\<^sup>\<nat> n" using div_9 by simp
  thus ?thesis using arytm_3_def_4[of m n] by mauto  
qed

mtheorem arytm_3_th_13:
  "n<>{} \<and> m *\<^sub>\<S>\<^sup>\<nat> n  = d *\<^sub>\<S>\<^sup>\<nat> (m lcm n) \<longrightarrow> d divides m"
proof
  let ?L="m lcm n"
  assume AS:"n<>{} \<and> m *\<^sub>\<S>\<^sup>\<nat> n  = d *\<^sub>\<S>\<^sup>\<nat> ?L" 
  have "n divides ?L" using arytm_3_def_4 by auto
  then obtain nL where
   [ty]:"nL is Nat" and "?L = n *\<^sub>\<S>\<^sup>\<nat> nL" using divE by mauto
  hence "n *\<^sub>\<S>\<^sup>\<nat> m  = (d *\<^sub>\<S>\<^sup>\<nat> nL) *\<^sub>\<S>\<^sup>\<nat> n" 
    using AS Mult_6[of n nL] Mult_6[of n m] 
      Mult_13[of n nL d]  by mauto
  hence "n *\<^sub>\<S>\<^sup>\<nat> m  = n *\<^sub>\<S>\<^sup>\<nat> (d *\<^sub>\<S>\<^sup>\<nat> nL)" 
    using  Mult_6[of n] by mauto 
  hence "m = d *\<^sub>\<S>\<^sup>\<nat> nL" 
    using AS Mult_15[of m "d *\<^sub>\<S>\<^sup>\<nat> nL" n] by mauto
  thus "d divides m" using divI[of d m] bexI[of _ nL Nat]
    by mauto
qed


mdef arytm_3_def_5 ("_ hcf _" [60,61]60) where
 mlet "n be Nat", "k be Nat"   
 "func n hcf k \<rightarrow> Nat means
    \<lambda>it. it divides n \<and> it divides k \<and>
         (\<forall>m: Nat. m divides n \<and> m divides k \<longrightarrow> m divides it)"
proof-
  let ?P = "\<lambda>it. (it divides n \<and> it divides k)"
  show "\<exists>x :
     Nat. x divides n \<and>
          x divides k \<and> (\<forall>m : Nat. ?P(m) \<longrightarrow> m divides x)"
  proof(cases "n={} or k={}")
    case T: True
     show "\<exists>x : Nat. x divides n \<and>
          x divides k \<and> (\<forall>m : Nat. ?P(m) \<longrightarrow> m divides x)" 
     proof(rule bexI[of _ "n +\<^sub>\<S>\<^sup>\<nat> k" Nat],intro conjI ballI impI)
       show "n +\<^sub>\<S>\<^sup>\<nat> k divides n" 
       proof(cases "n={}")
          case True  
          thus "n +\<^sub>\<S>\<^sup>\<nat> k divides n" using arytm_3_th_10 by mauto
        next
          case False
          hence "n +\<^sub>\<S>\<^sup>\<nat> k = n" using T Add_3 by mauto
          thus "n +\<^sub>\<S>\<^sup>\<nat> k divides n" using div_5 by mauto
        qed
       show "n +\<^sub>\<S>\<^sup>\<nat> k divides k" 
       proof(cases "n={}")
         case True  
           hence "n +\<^sub>\<S>\<^sup>\<nat> k = k" using Add_4 by mauto
           thus "n +\<^sub>\<S>\<^sup>\<nat> k divides k" using div_5 by mauto
        next
          case False
          hence "k={}" using T by simp
          thus "n +\<^sub>\<S>\<^sup>\<nat> k divides k" using arytm_3_th_10 by mauto
        qed
       fix m assume [ty]:"m be Nat" and "?P(m)"
       thus "m divides (n +\<^sub>\<S>\<^sup>\<nat> k)" using div_6[of k] by mauto
     qed mauto
   next
     case F:False
     have "k lcm n divides k *\<^sub>\<S>\<^sup>\<nat> n" using arytm_3_th_12
       by mauto
     then obtain l where
        [ty]: "l be Nat" and 
        L: "k *\<^sub>\<S>\<^sup>\<nat> n = (k lcm n) *\<^sub>\<S>\<^sup>\<nat> l" using divE by mauto
     show "\<exists>x : Nat. x divides n \<and>
          x divides k \<and> (\<forall>m : Nat. ?P(m) \<longrightarrow> m divides x)" 
     proof(rule bexI[of _ "l" Nat],intro conjI ballI impI)
       have H:"k lcm n = n lcm k" 
        "(k lcm n) *\<^sub>\<S>\<^sup>\<nat> l = l *\<^sub>\<S>\<^sup>\<nat> (k lcm n)" "k *\<^sub>\<S>\<^sup>\<nat> n = n *\<^sub>\<S>\<^sup>\<nat> k" 
         using Mult_6[of l] Mult_6[of k n]
         arytm_3_def_4_commutativity[of k n]  by mauto
       thus "l divides k" "l divides n"
         using F L arytm_3_th_13[of l k n] 
                   arytm_3_th_13[of l n k] by auto
       fix m assume [ty]: "m be Nat" and 
         A3: "m divides n \<and> m divides k"
       then obtain ndm where
         [ty]: "ndm is Nat" and 
         A5: "n = m *\<^sub>\<S>\<^sup>\<nat> ndm"  using divE[of m n] by mauto
      obtain kdm where
         [ty]: "kdm is Nat" and 
         A9: "k = m *\<^sub>\<S>\<^sup>\<nat> kdm"  using divE[of m k] A3 by mauto
       have A6: "kdm<>{}" "ndm<>{}" "m<>{}" 
        using Mult_2 Mult_1 F A5 A9 by auto
       have "n *\<^sub>\<S>\<^sup>\<nat> kdm = m *\<^sub>\<S>\<^sup>\<nat> (ndm *\<^sub>\<S>\<^sup>\<nat> kdm)" 
         using A5 Mult_13 by auto
       hence A7: "n divides m *\<^sub>\<S>\<^sup>\<nat> (ndm *\<^sub>\<S>\<^sup>\<nat> kdm)" 
         using Mult_6[of ndm  kdm] divI bexI[of _ kdm Nat] by mauto
       let ?mm = "m *\<^sub>\<S>\<^sup>\<nat> (ndm *\<^sub>\<S>\<^sup>\<nat> kdm)"
       have A10: "ndm *\<^sub>\<S>\<^sup>\<nat> kdm<>{}" using Mult_9[of kdm ndm] A6 by mauto
       hence B10:"?mm <>{}" using Mult_9[of _ m] A6 by mauto
      
       have "k *\<^sub>\<S>\<^sup>\<nat> ndm = m *\<^sub>\<S>\<^sup>\<nat> (kdm *\<^sub>\<S>\<^sup>\<nat> ndm)"
         using A9 Mult_13 by auto
       hence "k divides m *\<^sub>\<S>\<^sup>\<nat> (ndm *\<^sub>\<S>\<^sup>\<nat> kdm)" 
         using divI bexI[of _ ndm Nat] Mult_6[of ndm  kdm] by mauto
       hence "k lcm n divides ?mm" 
         using arytm_3_def_4[of k n] A7 by mauto
       then obtain mmd where
       [ty]: "mmd is Nat" and 
         A11: "?mm = (k lcm n) *\<^sub>\<S>\<^sup>\<nat> mmd " using 
             divE[of "k lcm n" ?mm] by mauto
       hence KN: "k lcm n<>{}" using B10 Mult_1 by mauto
       have C: "?mm *\<^sub>\<S>\<^sup>\<nat> m = (k lcm n) *\<^sub>\<S>\<^sup>\<nat> (mmd *\<^sub>\<S>\<^sup>\<nat> m)" using A11
         Mult_13[of m mmd] by mauto
       have "?mm *\<^sub>\<S>\<^sup>\<nat> m = n *\<^sub>\<S>\<^sup>\<nat> (kdm *\<^sub>\<S>\<^sup>\<nat> m)" 
         using A5 Mult_13[of kdm ndm m] Mult_13[of m kdm n] 
         by mauto
       hence "?mm *\<^sub>\<S>\<^sup>\<nat> m = n *\<^sub>\<S>\<^sup>\<nat> k" using A9 Mult_6[of kdm m] by auto
       hence "(k lcm n) *\<^sub>\<S>\<^sup>\<nat> l = (k lcm n) *\<^sub>\<S>\<^sup>\<nat> (mmd *\<^sub>\<S>\<^sup>\<nat> m)" 
         using C L H by auto
       hence "l = mmd *\<^sub>\<S>\<^sup>\<nat> m" using 
          Mult_15[of "mmd *\<^sub>\<S>\<^sup>\<nat> m" l ] KN by mauto         
       thus "m divides l" using divI bexI[of _ mmd Nat]
        Mult_6[of mmd m]  by mauto
     qed mauto
qed
   fix x y assume [ty]: "x be Nat" "y be Nat" and
          A1:" x divides n \<and> x divides k \<and>
           (\<forall>m : Nat. m divides n \<and> m divides k \<longrightarrow>
                  m divides x)" and
          A2:"y divides n \<and> y divides k \<and>
           (\<forall>m :Nat. m divides n \<and> m divides k \<longrightarrow>
                  m divides y)"
  have "x divides y \<and> y divides x" using A1 A2 by auto
  thus "x =\<^sub>\<S> y" using div_10 by auto
qed mauto

mtheorem arytm_3_def_5c:
  "k hcf n = n hcf k"
proof-
  have K: "(k hcf n) divides k" "(k hcf n) divides n" using arytm_3_def_5 by mauto 
  have "\<forall>m : Nat. m divides k \<and> m divides n \<longrightarrow> m divides (k hcf n)" 
    using  arytm_3_def_5[of k n] by auto
  thus "k hcf n = n hcf k" using arytm_3_def_5_uniq[of n k "k hcf n"] K by auto
qed

mtheorem arytm_3_th_14:
  "n hcf {} = n \<and> n lcm {} = {}"
proof
  show "n hcf {} = n" using div_1[of n] div_5[of n] 
    arytm_3_def_5_uniq[of n "{}" n] by mauto
  show "n lcm {} = {}" using div_1[of n] div_5[of "{}"] 
    arytm_3_def_4_uniq[of n "{}" "{}"] by mauto
qed

mtheorem arytm_3_th_15:
  "n hcf k = {} \<longrightarrow> n ={}"
proof
  assume AS: "n hcf k={}"
  have "n hcf k divides n" using arytm_3_def_5 by auto
  thus "n={}" using div_4 AS by auto
qed


mtheorem arytm_3_th_16:
  "n hcf n = n \<and> n lcm n = n"
proof
  have "for k st k divides n & k divides n holds k divides n" by auto
  thus "n hcf n = n" using div_5[of n] arytm_3_def_5_uniq[of n n n] by auto
  have "for k st n divides k & n divides k holds n divides k" by auto
  thus "n lcm n = n" using div_5[of n] arytm_3_def_4_uniq[of n n n] by auto
qed

reserve a,b,c,d for Nat

mtheorem arytm_3_th_17:
  "(a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c) = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> c"
proof(cases "c ={}")
  case T: True
    hence "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> c = {}" " a *\<^sub>\<S>\<^sup>\<nat> c = {}" "b *\<^sub>\<S>\<^sup>\<nat> c = {}"
      using Mult_2 by mauto
    thus "(a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c) = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> c" using arytm_3_th_16 by mauto
next 
  case F: False
  show "(a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c) = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> c"
  proof(cases "a={}")
    case T1:True
    hence  "a hcf b = b & a*\<^sub>\<S>\<^sup>\<nat>c = {}" using arytm_3_th_14 
       arytm_3_def_5c[of a b] Mult_1 by mauto
    thus "(a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c) = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> c" using T1 Mult_1 arytm_3_th_14 
      arytm_3_def_5c[of "a *\<^sub>\<S>\<^sup>\<nat> c" "b *\<^sub>\<S>\<^sup>\<nat> c"] by mauto
  next
    case F1:False
    let ?d = "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> c" 
    let ?E= "(a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c)"
    have "a hcf b divides b" using arytm_3_def_5[of a b] by mauto
    then obtain bDahb where [ty]:"bDahb is Nat" and
      "b = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> bDahb" using divE[of "a hcf b" b] by mauto
    hence "b *\<^sub>\<S>\<^sup>\<nat> c = c *\<^sub>\<S>\<^sup>\<nat> (a hcf b) *\<^sub>\<S>\<^sup>\<nat> bDahb" using Mult_6[of c b] by mauto
    hence "b *\<^sub>\<S>\<^sup>\<nat> c = ?d *\<^sub>\<S>\<^sup>\<nat> bDahb" using Mult_13[of bDahb "a hcf b" c] Mult_6[of c "a hcf b"] by mauto
    hence A4: "?d divides b *\<^sub>\<S>\<^sup>\<nat> c" using divI[of ?d] bexI[of _ bDahb Nat] by mauto
    have "a hcf b divides a" using arytm_3_def_5[of a b] by mauto
    then obtain aDahb where [ty]:"aDahb is Nat" and
      "a = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> aDahb" using divE[of "a hcf b" a] by mauto
    hence "a *\<^sub>\<S>\<^sup>\<nat> c = c *\<^sub>\<S>\<^sup>\<nat> (a hcf b) *\<^sub>\<S>\<^sup>\<nat> aDahb" using Mult_6[of c a] by mauto
    hence "a *\<^sub>\<S>\<^sup>\<nat> c = ?d *\<^sub>\<S>\<^sup>\<nat> aDahb" using Mult_13[of aDahb "a hcf b" c] Mult_6[of c "a hcf b"] by mauto
    hence "?d divides a *\<^sub>\<S>\<^sup>\<nat> c" using divI[of ?d] bexI[of _ aDahb Nat] by mauto
    hence "?d divides?E" using A4 arytm_3_def_5 by auto
    then obtain e where
     [ty]: "e is Nat" and E: "?E = ?d *\<^sub>\<S>\<^sup>\<nat> e" using divE[of ?d ?E] by mauto
    hence A5: "?E =    (a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e" using Mult_13[of e c] by mauto  
    hence "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e divides (b *\<^sub>\<S>\<^sup>\<nat> c)" using arytm_3_def_5[of "a *\<^sub>\<S>\<^sup>\<nat> c" "b *\<^sub>\<S>\<^sup>\<nat> c"]  by mauto
    then obtain D1 where
      [ty]: "D1 is Nat" and "b *\<^sub>\<S>\<^sup>\<nat> c = ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D1" 
      using divE[of "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e" "b *\<^sub>\<S>\<^sup>\<nat> c"] by mauto
   hence "c *\<^sub>\<S>\<^sup>\<nat> b = (((a hcf b) *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D1" using Mult_6[of c b] Mult_13[of e c "a hcf b"] by mauto
    hence "c *\<^sub>\<S>\<^sup>\<nat> b = (c *\<^sub>\<S>\<^sup>\<nat> (a hcf b)) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D1)" using Mult_6[of c "a hcf b"] Mult_13[of D1 e "c *\<^sub>\<S>\<^sup>\<nat> (a hcf b)"] 
      by mauto
    hence "c *\<^sub>\<S>\<^sup>\<nat> b = c *\<^sub>\<S>\<^sup>\<nat> ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D1))" using Mult_13[of _ "a hcf b" c] 
      by mauto
    hence "b = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D1)" using Mult_15[of b "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D1)" c] F by mauto 
    hence "b = ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D1" using Mult_13[of D1 e] by mauto 
    hence A6: "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> e divides b" using divI[of _ b] bexI[of _ D1 Nat] by mauto
   hence "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e divides (a *\<^sub>\<S>\<^sup>\<nat> c)" using arytm_3_def_5[of "a *\<^sub>\<S>\<^sup>\<nat> c" "b *\<^sub>\<S>\<^sup>\<nat> c"] A5  by mauto
    then obtain D2 where
      [ty]: "D2 is Nat" and "a *\<^sub>\<S>\<^sup>\<nat> c = ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D2" 
      using divE[of "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> e" "a *\<^sub>\<S>\<^sup>\<nat> c"] by mauto
   hence "c *\<^sub>\<S>\<^sup>\<nat> a = (((a hcf b) *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D2" using Mult_6[of c a] Mult_13[of e c "a hcf b"] by mauto
    hence "c *\<^sub>\<S>\<^sup>\<nat> a = (c *\<^sub>\<S>\<^sup>\<nat> (a hcf b)) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D2)" using Mult_6[of c "a hcf b"] Mult_13[of D2 e "c *\<^sub>\<S>\<^sup>\<nat> (a hcf b)"] 
      by mauto
    hence "c *\<^sub>\<S>\<^sup>\<nat> a = c *\<^sub>\<S>\<^sup>\<nat> ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D2))" using Mult_13[of _ "a hcf b" c] 
      by mauto
    hence "a = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D2)" using Mult_15[of a "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D2)" c] F by mauto 
    hence "a = ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D2" using Mult_13[of D2 e] by mauto 
    hence  "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> e divides a" using divI[of _ a] bexI[of _ D2 Nat] by mauto
 hence  "(a hcf b) *\<^sub>\<S>\<^sup>\<nat> e divides (a hcf b)" using A6 arytm_3_def_5[of a b] by mauto
  then obtain  D3 where
       [ty]:"D3 be Nat" and "a hcf b = ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> e) *\<^sub>\<S>\<^sup>\<nat> D3" using divE[of _ "a hcf b" ] by mauto
  hence "a hcf b = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> (e *\<^sub>\<S>\<^sup>\<nat> D3)" "a hcf b<>{}" using Mult_13[of D3 e] 
      arytm_3_th_15[of b a] F1 by mauto
  hence "e*\<^sub>\<S>\<^sup>\<nat> D3 = succ {}" using Mult_10[of "e*\<^sub>\<S>\<^sup>\<nat> D3" "a hcf b"] by mauto
  hence "e=succ {}" using Mult_8[of D3 e] by mauto
   thus "(a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c) = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> c" using E Mult_5 by mauto 
 qed
qed

mtheorem arytm_3_th_19:
 " (a<>{} \<or> b <>{}) \<and> a = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> n \<and> b = (a hcf b) *\<^sub>\<S>\<^sup>\<nat> k \<longrightarrow>
    (n,k are-coprime)"
proof
  let ?ab = "a hcf b"
  assume AS: "(a<>{} \<or> b <>{}) \<and> a = ?ab *\<^sub>\<S>\<^sup>\<nat> n \<and> b = ?ab *\<^sub>\<S>\<^sup>\<nat> k"
  show "n,k are-coprime"
  proof(cases "a = {}")
    case A: True
    hence B: "b<>{}" using AS by auto    
    hence "?ab = b"  using A arytm_3_th_14[of b] arytm_3_def_5c[of a b] 
      by mauto
    hence "k=succ {}" using AS Mult_10[of k b] B by mauto
    thus "n,k are-coprime" using arytm_3_th_2[of n] arytm_3_def_2s[of n k] by mauto
  next
    case F:False
      show "n,k are-coprime"
      proof(cases "b = {}")
        case A: True
        hence B: "a<>{}" using AS by auto    
        hence "?ab = a"  using A arytm_3_th_14[of a] arytm_3_def_5c[of a b] 
          by mauto
        hence "n=succ {}" using AS Mult_10[of n a] B by mauto
        thus "n,k are-coprime" using arytm_3_th_2[of k] by mauto
      next
        case FF:False  
        show "n,k are-coprime"
        proof(standard,simp,simp,intro ballI impI)
          fix c d1 d2 assume [ty]:"c be Nat" "d1 be Nat" "d2 be Nat"
            and A6: "n =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d1 \<and> k =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d2"
          hence "b = (?ab *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> d2" using AS Mult_13[of d2 c ?ab] by mauto
          hence A9: "?ab *\<^sub>\<S>\<^sup>\<nat> c divides b" using divI[of _ b] bexI[of _ d2 Nat] by mauto
          have "a = (?ab *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> d1" using A6 AS Mult_13[of d1 c ?ab] by mauto
          hence "?ab *\<^sub>\<S>\<^sup>\<nat> c divides a" using divI[of _ a] bexI[of _ d1 Nat] by mauto
          hence "?ab *\<^sub>\<S>\<^sup>\<nat> c divides ?ab" using A9 arytm_3_def_5[of a b] by mauto
          then obtain  D3 where
            [ty]:"D3 be Nat" and "?ab = (?ab *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> D3" using divE[of _ "a hcf b" ] by mauto
          hence "?ab = ?ab *\<^sub>\<S>\<^sup>\<nat> (c *\<^sub>\<S>\<^sup>\<nat> D3)" "?ab<>{}" using Mult_13[of D3 c] 
              arytm_3_th_15[of b a] F FF  by mauto
          hence "c*\<^sub>\<S>\<^sup>\<nat> D3 = succ {}" using Mult_10[of "c*\<^sub>\<S>\<^sup>\<nat> D3" "a hcf b"] by mauto
          thus "c =succ {}" using Mult_8[of D3 c] by mauto
        qed mauto
      qed
    qed
  qed

mtheorem arytm_3_th_20:
  "(a,b are-coprime) iff a hcf b = succ{}"
proof(rule iffI3)
  let ?ab="a hcf b"
  show "(a,b are-coprime) implies ?ab = succ{}"
  proof
    assume AS: "a,b are-coprime"
    obtain ad where [ty]:"ad is Nat" and
      A: "a = ?ab *\<^sub>\<S>\<^sup>\<nat> ad" using divE[of ?ab a] arytm_3_def_5[of a b]
      by mauto
    obtain bd where [ty]:"bd is Nat" and
     B: "b = ?ab *\<^sub>\<S>\<^sup>\<nat> bd" using divE[of ?ab b] arytm_3_def_5[of a b]
      by mauto
    show "?ab = succ {}" using arytm_3_def_2E[THEN bspec,
      THEN bspec,THEN bspec,of a b ?ab ad bd] AS A B by mauto
  qed
  assume AS: "?ab = succ{}"
  show "a,b are-coprime"
  proof(standard,simp,simp,intro ballI impI)
    fix c d1 d2
    assume [ty]:"c be Nat" "d1 be Nat" "d2 be Nat" and
        "a =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d1 \<and> b =\<^sub>\<S> c *\<^sub>\<S>\<^sup>\<nat> d2"
    hence "c divides a" "c divides b" 
      using divI[of c] bexI[of _ d1 Nat] bexI[of _ d2 Nat]
      by mauto
    hence "c divides ?ab" using arytm_3_def_5[of a b] 
      by mauto
    then obtain e where [ty]: "e is Nat" and
     "?ab = c *\<^sub>\<S>\<^sup>\<nat> e" using divE[of c ?ab]  by mauto
    thus "c = succ {}" using Mult_8[of e c] AS by mauto 
  qed mauto
qed

mdef arytm_3_def_6 : RED where
 mlet "k be Nat", "n be Nat"   
 "func RED(k , n)  \<rightarrow> Nat means
    \<lambda>it. k = it  *\<^sub>\<S>\<^sup>\<nat> (k hcf n) if k <> {}
   otherwise \<lambda> it. it ={}"
proof-
  have " k hcf n divides k" using arytm_3_def_5 by auto
  then obtain x where
     [ty]: "x is Nat" and "k =\<^sub>\<S>  (k hcf n)  *\<^sub>\<S>\<^sup>\<nat> x " using divE by mauto
  hence "\<exists>x : Nat. k =\<^sub>\<S> x *\<^sub>\<S>\<^sup>\<nat> (k hcf n)" "\<exists>x : Nat. x =\<^sub>\<S> {}" 
    using bexI[of _ x Nat ] Mult_6[of "k hcf n" x]
    by mauto
  thus "(k \<noteq> {} \<longrightarrow> (\<exists>x : Nat. k =\<^sub>\<S> x *\<^sub>\<S>\<^sup>\<nat> (k hcf n))) \<and>
    (\<not> k \<noteq> {} \<longrightarrow> (\<exists>x : Nat. x =\<^sub>\<S> {}))" by auto
  fix x y assume [ty]: "x be Nat" "y be Nat"
           
  show "(k \<noteq> {} \<and> k =\<^sub>\<S> x *\<^sub>\<S>\<^sup>\<nat> (k hcf n) \<and> k =\<^sub>\<S> y *\<^sub>\<S>\<^sup>\<nat> (k hcf n) \<longrightarrow> x =\<^sub>\<S> y) \<and>
           (\<not> k \<noteq> {} \<and> x =\<^sub>\<S> {} \<and> y =\<^sub>\<S> {} \<longrightarrow> x =\<^sub>\<S> y)"
  proof(auto)
    assume AS: "k \<noteq> {}" "k =\<^sub>\<S> x *\<^sub>\<S>\<^sup>\<nat> (k hcf n)" "k =\<^sub>\<S> y *\<^sub>\<S>\<^sup>\<nat> (k hcf n)"
    hence "k hcf n<>{}" " (k hcf n)  *\<^sub>\<S>\<^sup>\<nat> x =  (k hcf n) *\<^sub>\<S>\<^sup>\<nat> y"
       using Mult_2[of x] Mult_6[of "k hcf n"] by mauto
     thus "x =\<^sub>\<S> y" using Mult_15[of x y ] by mauto
  qed
qed mauto

mtheorem arytm_3_th_21:
  "RED(a,b) *\<^sub>\<S>\<^sup>\<nat> (a hcf b) = a"
proof(cases "a={}")
  case T: True
    hence "RED(a ,b) = {}" using arytm_3_def_6[of a b] by mauto
    thus "RED(a,b) *\<^sub>\<S>\<^sup>\<nat> (a hcf b) = a" using
     Mult_1 T by mauto
  next
    case F:False
      thus  "RED(a,b) *\<^sub>\<S>\<^sup>\<nat> (a hcf b) = a" using arytm_3_def_6[of a b] by mauto
qed

mtheorem arytm_3_th_22:
  "a <> {} or b <> {} implies RED(a,b), RED(b,a) are-coprime"
proof
  assume AS:"a <> {} or b <> {}"
  let ?ab = "a hcf b"
  have "?ab = b hcf a" using arytm_3_def_5c[of a b] by mauto
  hence "?ab *\<^sub>\<S>\<^sup>\<nat> RED(a,b) = a" "?ab *\<^sub>\<S>\<^sup>\<nat> RED(b,a) = b" using 
    arytm_3_th_21[of b a] arytm_3_th_21[of a b] Mult_6[of ?ab]
    by mauto
  thus "RED(a,b), RED(b,a) are-coprime" 
    using AS arytm_3_th_19[of "RED(b,a)" "RED(a,b)" b a,
     simplified] by mauto
qed

  

mtheorem arytm_3_th_23:
  "a,b are-coprime implies RED(a,b) = a"
proof
  assume "a,b are-coprime"
  hence "a hcf b = succ {}" using arytm_3_th_20 by auto
  thus "RED(a,b) = a" using arytm_3_th_21[of b a] Mult_5 by mauto
qed

mtheorem arytm_3_th_24:
  "RED(a,1\<^sub>\<S>) = a \<and> RED(1\<^sub>\<S>,a) = 1\<^sub>\<S>"
proof-
  have "a,1\<^sub>\<S> are-coprime" "1\<^sub>\<S>,a are-coprime" using arytm_3_def_2s arytm_3_th_2[of a] by mauto
  thus ?thesis using arytm_3_th_23 by auto
qed

mtheorem arytm_3_th_25:
  "a <> {} implies RED(a,b) <> {}"
proof
  have A1:" RED(a, b) *\<^sub>\<S>\<^sup>\<nat> (a hcf b) =\<^sub>\<S> a" using 
     arytm_3_th_21[of b a] by mauto
  assume "a<>{}"
  thus "RED(a,b) <> {}" using Mult_1 A1 by mauto 
qed

mtheorem arytm_3_th_26:
  "RED({},a) = {} & (a <> {} implies RED(a,{}) = succ {})"
proof(auto)
  show "RED({},a) = {}" using arytm_3_def_6 by mauto
  assume
A1: "a <> {}"
  hence "RED(a,{})*\<^sub>\<S>\<^sup>\<nat> a = a" 
    using arytm_3_th_21[of "{}" a] arytm_3_th_14[of a] by mauto 
  thus " RED(a,{}) = succ {}" using A1 Mult_10[of "RED(a,{})" a]
       Mult_6[of "RED(a,{})" a]
    by mauto
qed

mtheorem arytm_3_th_27:
  "a <> {} implies RED(a,a) = succ {}"
proof
  assume
A1: "a <> {}"
 hence "RED(a,a)*\<^sub>\<S>\<^sup>\<nat> a = a" 
    using arytm_3_th_21[of a a] arytm_3_th_16[of a] by mauto
   thus " RED(a,a) = succ {}" using A1 Mult_10[of "RED(a,a)" a]
       Mult_6[of "RED(a,a)" a]
    by mauto
qed

mtheorem arytm_3_th_28:
  "c <> {} implies RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) = RED(a, b)"
proof
  assume
A1: "c <> {}"
  show "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) = RED(a, b)"
  proof(cases "a={}")
    case T: True
    hence "a *\<^sub>\<S>\<^sup>\<nat> c ={}" using Mult_1 by auto
    hence "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) ={}" "RED(a, b) = {}" 
        using arytm_3_th_26 T by auto
   thus "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) = RED(a, b)" by simp
 next 
   case F: False
   hence FF: "a hcf  b <> {}" using arytm_3_th_15[of b a] 
      by mauto
    have  "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> ((a *\<^sub>\<S>\<^sup>\<nat> c) hcf (b *\<^sub>\<S>\<^sup>\<nat> c)) = a *\<^sub>\<S>\<^sup>\<nat> c"
     using arytm_3_th_21[of "b *\<^sub>\<S>\<^sup>\<nat> c" "a *\<^sub>\<S>\<^sup>\<nat> c"]  by mauto
   hence  "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> ((a hcf b) *\<^sub>\<S>\<^sup>\<nat> c) = a *\<^sub>\<S>\<^sup>\<nat> c"
     using arytm_3_th_17[of b c a]  by mauto
   hence  "(RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> (a hcf b)) *\<^sub>\<S>\<^sup>\<nat> c = a *\<^sub>\<S>\<^sup>\<nat> c"
     using Mult_13[of c "a hcf b"] by mauto
    hence "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> (a hcf b) = a" 
     using Mult_15s[of a "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) *\<^sub>\<S>\<^sup>\<nat> (a hcf b)" c] 
     A1 by mauto
   thus "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c) = RED(a, b)" using
       Mult_15s[of "RED(a *\<^sub>\<S>\<^sup>\<nat> c, b *\<^sub>\<S>\<^sup>\<nat> c)" "RED(a, b)"] 
   FF arytm_3_th_21[of b a] by mauto
 qed
qed

definition RATplus :: "Set" where
   " RATplus \<equiv> 
  {[a,b] where a be Element-of NAT, b be Element-of NAT:
  a,b are-coprime & b <> {}}"

mtheorem RATi:
  "for x be object holds
  x in  RATplus \<longleftrightarrow> 
     (\<exists> a:Nat, b:Nat. x=[a,b] \<and> a,b are-coprime & b <> {})"
proof(standard,standard)
  fix x
  assume "x in RATplus"
  hence "\<exists> a:Element-of NAT, b:Element-of NAT. x=[a,b] \<and> 
    a,b are-coprime & b <> {}" unfolding RATplus_def 
  using  Fraenkel_A2_ex[of "Element-of NAT" "Element-of NAT" x]
  by mauto
  then obtain a b where [ty]: "a is Element-of NAT"
                 " b is Element-of NAT"
     and  A1: "x=[a,b] \<and> 
    a,b are-coprime & b <> {}" by auto
  thus "\<exists> a:Nat, b:Nat. x=[a,b] \<and> 
    a,b are-coprime & b <> {}" using A1 bexI[of _ a Nat] bexI[of _ b Nat]
    by mauto
next fix x
  assume "\<exists> a:Nat, b:Nat. x=[a,b] \<and> 
    a,b are-coprime & b <> {}"
  then obtain a b where
     [ty]:"a is Nat" "b is Nat" and A2:" x=[a,b] \<and> 
      a,b are-coprime & b <> {}" by mauto 
  thus "x in RATplus" unfolding RATplus_def using Fraenkel_A2_in
   [of "Element-of NAT" "Element-of NAT" a b] by mauto
qed mauto


text_raw {*\DefineSnippet{arytm_3_def_7}{*}
mdef arytm_3_def_7 ("RAT\<^bsup>\<ge>0\<^bsub>") where
  "func RAT\<^bsup>\<ge>0\<^bsub> \<rightarrow>  set equals
  ({[i,j] where i be Element-of NAT, j be Element-of NAT: 
         i,j are-coprime & j \<noteq> 0\<^sub>\<S>} \\ the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT) \<union> NAT"
  text_raw {*}%EndSnippet*}
  by mauto

mtheorem
  "cluster RAT\<^bsup>\<ge>0\<^bsub> \<rightarrow> non empty"
proof
  have "{} in NAT" using ordinal1_def_12[of "{}"] by mauto
  hence "{} in RAT\<^bsup>\<ge>0\<^bsub>" using xboole_0_def_3[of _ NAT] arytm_3_def_7 by mauto 
  thus "RAT\<^bsup>\<ge>0\<^bsub> be non empty" using tarski_def_1 xboole_0_def_1 by mauto
qed

reserve x,y,z for "Element-of RAT\<^bsup>\<ge>0\<^bsub>"


mtheorem arytm_3_th_29:
  "x in NAT or (ex i be Nat, j be Nat st x = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>)"
proof(rule disjCI2)
  have R: "x in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mauto
  assume "\<not> x in omega"
  hence
A1: "x in RATplus \\ (the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT)" unfolding
      RATplus_def using R xboole_0_def_3[of _ NAT] arytm_3_def_7 by mauto
  hence
A2: "\<not> x in the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT " using xboole_0_def_5[of RATplus] all_set 
    by mauto
  have "x in RATplus" using xboole_0_def_5[of RATplus] A1 all_set by mauto
  then obtain a b where
    [ty]: "a is Nat" "b is Nat" and
    A3: " x=[a,b] \<and> a,b are-coprime & b <> {}" using RATi by mauto
  have "b <> 1\<^sub>\<S>"
  proof
    assume "b = 1\<^sub>\<S>"
    hence "[a,b] in the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT" using
      Set_of_All_in[of "Element-of NAT" a] by mauto
    thus False using A3 A2 by auto 
  qed
  thus "ex i be Nat, j be Nat st x = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>"
    using A3 bexI[of _ a Nat] bexI[of _ b Nat] by mauto
qed

text_raw {*\DefineSnippet{arytm_3_th_29I}{*}
theorem nat_ratp:
  "NAT \<subseteq> RAT\<^bsup>\<ge>0\<^bsub>" 
text_raw {*}%EndSnippet*}
proof(intro tarski_def_3I ballI impI)
  fix x assume "x in NAT"
  thus "x in RAT\<^bsup>\<ge>0\<^bsub>" using xboole_0_def_3[of _ NAT] arytm_3_def_7 by mauto 
qed mauto


theorem arytm_3_th_32:
  "\<not> [i,j] in NAT"
proof
  assume "[i,j] in NAT"
  hence "[i,j] is natural" "[i,j] is non natural" 
    using ordinal1_def_12 cl_non_nat by mauto
  thus False by mauto
qed

mtheorem arytm_3_th_33:
  "[n,k] in RAT\<^bsup>\<ge>0\<^bsub> iff (n,k are-coprime & k <> {} & k <> 1\<^sub>\<S>)"
proof
  assume "[n,k] in RAT\<^bsup>\<ge>0\<^bsub>"
  hence "[n,k] is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by auto
  hence "ex i be Nat, j be Nat st 
     [n,k] = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>" 
    using arytm_3_th_32[of n k] arytm_3_th_29 by mauto
  then obtain i j where "i be Nat" "j be Nat" and 
     A2: "[n,k] = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>"     
    by mauto
  thus "n,k are-coprime & k <> {} & k <> 1\<^sub>\<S>" 
    using xtuple_0_th_1a by mauto
next 
  assume AS: "n,k are-coprime & k <> {} & k <> 1\<^sub>\<S>"
  hence "ex i be Nat, j be Nat st 
     [n,k] = [i,j] & i,j are-coprime & j <> {}"
    using bexI[of _ k Nat] bexI[of _ n Nat] by mauto
  hence NK: "[n,k] in RATplus" using RATi by mauto
  have "\<not> [n,k] in the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT"
  proof
    assume "[n,k] in the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT"
    then obtain n1 where "n1 be Element-of NAT" and 
         A2: "[n,k] = [n1,1\<^sub>\<S>]" using 
         Set_of_All_ex[of "Element-of NAT"] by mauto
    thus False using AS xtuple_0_th_1a by mauto
  qed
  hence "[n,k] in (RATplus \\ the set-of-all [k,1\<^sub>\<S>] where k be Element-of NAT)"
    using NK xboole_0_def_5[of RATplus] all_set by mauto
  thus "[n,k] in RAT\<^bsup>\<ge>0\<^bsub>" using arytm_3_def_7 xboole_0_def_3 RATplus_def by mauto 
qed  

mtheorem arytm_3_th_33c:
mlet "n be object"
  "cluster [n,{}] \<rightarrow> non Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
proof(standard,auto)
 assume [ty]:"[n , {}] be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  then obtain i j where [ty]:"i be Nat" "j be Nat" and 
     A1: "[n,{}] = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>" 
    using arytm_3_th_32[of n "{}"] arytm_3_th_29 by mauto 
  thus False using xtuple_0_th_1[ of i j n] by mauto
qed

theorem arytm_3_th_33d:
  "n<>{} \<Longrightarrow> [{},n] is non Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
proof(auto)                            
 assume "n <> {}" and [ty]: "[{} , n] be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  then obtain i j where [ty]:"i be Nat" "j be Nat" and 
     A1: "[{},n] = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>" 
    using arytm_3_th_32[of "{}" n] arytm_3_th_29 by mauto 
  hence "i={} \<and> n=j" using xtuple_0_th_1[ of i j "{}" n] by mauto
  thus False using A1 arytm_3_th_3 by mauto
qed

mdef arytm_3_def_8 : numerator where
 mlet "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
 "func  numerator(x) \<rightarrow> Nat means
     \<lambda>it. it = x if x in omega otherwise \<lambda>it. ex a st x = [it,a]"
proof-
  show "(x in omega \<longrightarrow> (\<exists>xa : Nat. xa =\<^sub>\<S> x)) \<and>
    (\<not> x in omega \<longrightarrow> (\<exists>xa : Nat. \<exists>a : Nat. x =\<^sub>\<S> [xa , a]))"
  proof(intro  conjI impI,simp)
    assume "x in omega" thus "x be natural" using ordinal1_def_12 by auto
  next
    assume "\<not>x in omega"
    hence "ex i be Nat, j be Nat st x = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>" 
      using arytm_3_th_29 by mauto
    thus "ex i be Nat, j be Nat st x = [i,j]" by mauto
  qed
  fix xa y assume  [ty]: "xa be Nat" "y be Nat"
  show"(x in omega \<and> xa =\<^sub>\<S> x \<and> y =\<^sub>\<S> x \<longrightarrow> xa =\<^sub>\<S> y) \<and>
       (\<not> x in omega \<and> (\<exists>a : Nat. x =\<^sub>\<S> [xa , a]) \<and> (\<exists>a : Nat. x =\<^sub>\<S> [y , a]) \<longrightarrow> xa =\<^sub>\<S> y)" using 
         xtuple_0_th_1a by mauto
qed mauto

mtheorem arytm_3_def_8o:
  "[a,b] is Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> numerator([a,b]) = a"
proof-
  assume [ty]:"[a,b] is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  have "\<not> [a,b] in NAT" using  arytm_3_th_32 by mauto
  then obtain c where "c is Nat" and
    " [a,b] = [numerator([a,b]),c]" using arytm_3_def_8 by mauto
  thus "numerator([a,b]) = a" using xtuple_0_th_1a by auto
qed


mdef arytm_3_def_9 : denominator where
 mlet "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
 "func  denominator(x) \<rightarrow> Nat means
     \<lambda>it. it = 1\<^sub>\<S> if x in omega otherwise \<lambda>it. ex a st x = [a,it]"
proof-
  show "(x in omega \<longrightarrow> (\<exists>x : Nat. x =\<^sub>\<S> succ {})) \<and>
    (\<not> x in omega \<longrightarrow> (\<exists>xa : Nat. \<exists>a : Nat. x =\<^sub>\<S> [a , xa]))"
  proof(intro  conjI impI,simp)
    assume "\<not>x in omega"
    hence "ex i be Nat, j be Nat st x = [i,j] & i,j are-coprime & j <> {} & j <> 1\<^sub>\<S>" 
      using arytm_3_th_29 by mauto
    thus "ex i be Nat, j be Nat st x = [j,i]" by mauto
  qed
  fix xa y assume "xa be Nat" "y be Nat"
  show "(x in omega \<and> xa =\<^sub>\<S> succ {} \<and> y =\<^sub>\<S> succ {} \<longrightarrow> xa =\<^sub>\<S> y) \<and>
       (\<not> x in omega \<and> (\<exists>a : Nat. x =\<^sub>\<S> [a , xa]) \<and> (\<exists>a : Nat. x =\<^sub>\<S> [a , y]) \<longrightarrow> xa =\<^sub>\<S> y)"
    using xtuple_0_th_1a by mauto
qed mauto

mtheorem arytm_3_def_9o:
  "[a,b] is Element-of RAT\<^bsup>\<ge>0\<^bsub> \<Longrightarrow> denominator([a,b]) = b"
proof-
  assume [ty]:"[a,b] is Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  have "\<not> [a,b] in NAT" using  arytm_3_th_32 by mauto
  then obtain c where "c is Nat" and
    " [a,b] = [c,denominator([a,b])]" using arytm_3_def_9 by mauto
  thus "denominator([a,b]) = b" using xtuple_0_th_1a by auto
qed

mtheorem arytm_3_th_34:
  "numerator(x), denominator(x) are-coprime"
proof(cases "x in NAT")
  case True
    hence "denominator(x)= 1\<^sub>\<S>" "numerator(x) = x" "x is Nat" 
      using arytm_3_def_9 arytm_3_def_8 ordinal1_def_12 by mauto
    thus "numerator(x), denominator(x) are-coprime" using arytm_3_th_2[of x]
     arytm_3_def_2s by mauto
  next
    case F: False
    then obtain i j where "i be Nat"  "j be Nat" and
       A1: " x = [i,j]" " i,j are-coprime " "j <> {} & j <> 1\<^sub>\<S>"
      using arytm_3_th_29 by mauto
    obtain a where "a be Nat" and 
      A2: "x = [numerator(x),a]" using arytm_3_def_8[of x] F by mauto
    obtain b where "b be Nat" and 
      A3: "x = [b,denominator(x)]" using arytm_3_def_9[of x] F by mauto
    have "i=numerator(x)" "j=denominator(x)" using A1 A2 A3 xtuple_0_th_1a by mauto
    thus "numerator(x), denominator(x) are-coprime" using A1(2) by auto
qed

mtheorem arytm_3_th_35:
  "denominator(x) <> {}"
proof(cases "x in NAT")
  case True
  thus "denominator(x)<>{}" using arytm_3_def_9[of x] by mauto
next
  case F: False
  then obtain i j where "i be Nat"  "j be Nat" and
       A1: " x = [i,j]" " i,j are-coprime " "j <> {} & j <> 1\<^sub>\<S>"
      using arytm_3_th_29 by mauto
    obtain b where "b be Nat" and 
      A2: "x = [b,denominator(x)]" using arytm_3_def_9[of x] F by mauto
    have "j=denominator(x)" using A1 A2 xtuple_0_th_1a by mauto
     thus "denominator(x)<>{}" using A1 by auto
   qed

mtheorem arytm_3_th_36:
  "\<not> x in NAT implies x = [numerator(x), denominator(x)] & denominator(x) <>  1\<^sub>\<S>"
proof
  assume F: "\<not> x in NAT"
      then obtain i j where "i be Nat"  "j be Nat" and
       A1: " x = [i,j]" " i,j are-coprime " "j <> {} & j <> 1\<^sub>\<S>"
      using arytm_3_th_29 by mauto
    obtain a where "a be Nat" and 
      A2: "x = [numerator(x),a]" using arytm_3_def_8[of x] F by mauto
    obtain b where "b be Nat" and 
      A3: "x = [b,denominator(x)]" using arytm_3_def_9[of x] F by mauto
    have "i=numerator(x)" "j=denominator(x)" using A1 A2 A3 xtuple_0_th_1a by mauto
    thus "x = [numerator(x), denominator(x)] & denominator(x) <>  1\<^sub>\<S>" using A1(1,3) by blast
qed
  
mtheorem arytm_3_th_37:
  "x <> {} iff numerator(x) <> {}"
proof
  assume AS: "x <>{}"
  show "numerator(x) <> {}"
  proof(cases "x in NAT")
    case True
      hence "numerator(x) = x" using arytm_3_def_8[of x] by mauto
      thus "numerator(x) <> {}" using AS by auto
  next
    case F:False
       then obtain i j where [ty]:"i be Nat"  "j be Nat" and
       A1: " x = [i,j]" " i,j are-coprime " "j <> {} & j <> 1\<^sub>\<S>"
      using arytm_3_th_29 by mauto
    obtain a where "a be Nat" and 
      A2: "x = [numerator(x),a]" using arytm_3_def_8[of x] F by mauto
    have "i=numerator(x)" using A1 A2 xtuple_0_th_1a by mauto
    thus "numerator(x)<>{}" using A1 arytm_3_th_3[of j] by mauto
  qed
next 
  have E: "{} in NAT" using ordinal1_def_11 by mauto
  assume  "numerator(x) <> {}"
  thus "x <> {}" using E arytm_3_def_8 by mauto
qed  

mtheorem arytm_3_th_38:
  "x in NAT iff denominator(x) = 1\<^sub>\<S>"
using arytm_3_def_9[of x] arytm_3_th_36[of x] by mauto

mdef arytm_3_def_10 (infix "'/\<^bsub>\<rat>\<ge>0\<^bsup>" 60) where 
  mlet "i be Nat", "j be Nat" 
  "func (i /\<^bsub>\<rat>\<ge>0\<^bsup> j) \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub> equals
   {} if j = {},                                  
    RED(i,j) if RED(j,i) = 1\<^sub>\<S>
   otherwise ( [RED(i,j), RED(j,i)])"
proof(intro impI conjI)
  assume "j={}"
  have "{} in NAT" using ordinal1_def_11 by auto
  hence "{} in RAT\<^bsup>\<ge>0\<^bsub>" using arytm_3_def_7 xboole_0_def_3[of _ NAT] all_set by mauto
  thus "{} be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mauto
next
  assume "RED(j, i) =\<^sub>\<S> succ {}" 
  hence "RED(i,j) in NAT" using ordinal1_def_12[of "RED(i,j)"] by mauto
  hence "RED(i,j) in RAT\<^bsup>\<ge>0\<^bsub>" using arytm_3_def_7 xboole_0_def_3[of _ NAT] all_set by mauto
  thus "RED(i,j) be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by mauto
next
  assume AS: "j \<noteq> {} \<and> RED(j, i) \<noteq> succ {}"
  hence A1:"i<>{}" "RED(j, i)<>{}" using arytm_3_th_26  arytm_3_th_25 by mauto
  hence "RED(i, j), RED(j, i) are-coprime" using arytm_3_th_22 AS by mauto
  hence "[RED(i, j), RED(j, i)] in RAT\<^bsup>\<ge>0\<^bsub>" using A1 AS arytm_3_th_33[of "RED(j, i)" "RED(i, j)"] 
     by mauto
   thus "[RED(i, j) , RED(j, i)] be Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by auto
next
  show "\<forall>x : Element-of RAT\<^bsup>\<ge>0\<^bsub>. j =\<^sub>\<S> {} \<and> RED(j, i) =\<^sub>\<S> succ {} \<longrightarrow> x =\<^sub>\<S> {} \<longleftrightarrow> x =\<^sub>\<S> RED(i, j)"
  proof(intro ballI impI)
    fix x assume [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
      J: "j =\<^sub>\<S> {} \<and> RED(j, i) =\<^sub>\<S> succ {}"
    hence "j = j hcf i" using arytm_3_th_21[of i j] Mult_5[of "j hcf i"] by mauto
    hence "i={}" using J arytm_3_th_15[of  j i] arytm_3_def_5c[of i j]
      by mauto
    hence " RED(i, j) ={}" using arytm_3_def_6 by mauto
    thus "x =\<^sub>\<S> {} \<longleftrightarrow> x =\<^sub>\<S> RED(i, j)" by auto
  qed mauto
qed

mtheorem arytm_3_th_39:
  "numerator(x) /\<^bsub>\<rat>\<ge>0\<^bsup> denominator(x) = x"
proof-
  let ?n = "numerator(x)"
  let ?d = "denominator(x)"
  have A1: "?d<>{}" using arytm_3_th_35 by mauto
  have A2: "RED(?n,?d) = ?n" using arytm_3_th_23 arytm_3_th_34 by mauto
  have "?n,?d are-coprime" using arytm_3_th_34 by mauto
  hence A3: "RED(?d,?n) = ?d" using arytm_3_th_23 arytm_3_def_2s by mauto
  show "?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d = x"
  proof(cases "?d = succ {}")
    case T: True
    hence "x in NAT" using arytm_3_th_36 by mauto
    hence "?n = x" using arytm_3_def_8[of x] by mauto
    thus "?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d = x" using T A2 A3 arytm_3_def_10[of ?n ?d] by mauto
  next
    case F:False
    hence "\<not> x in NAT" using arytm_3_def_9 by auto
    hence "x = [?n, ?d]" using arytm_3_th_36 by mauto
    thus "?n /\<^bsub>\<rat>\<ge>0\<^bsup> ?d = x" using F A1 A2 A3 arytm_3_def_10[of ?n ?d] by mauto
  qed
qed


mtheorem arytm_3_th_40:
  "{} /\<^bsub>\<rat>\<ge>0\<^bsup> b = {} \<and> a /\<^bsub>\<rat>\<ge>0\<^bsup> 1\<^sub>\<S> = a"
proof
  show "{} /\<^bsub>\<rat>\<ge>0\<^bsup> b = {}"
  proof(cases "b={}")
    case True
    thus "{} /\<^bsub>\<rat>\<ge>0\<^bsup> b = {}" using arytm_3_def_10 by mauto
  next 
    case False
    hence "RED(b,{}) = 1\<^sub>\<S>" "RED({},b) = {}" using arytm_3_th_26 by mauto
    thus "{} /\<^bsub>\<rat>\<ge>0\<^bsup> b = {}" using arytm_3_def_10 by mauto   
  qed
  have "RED(1\<^sub>\<S>,a) = 1\<^sub>\<S> & RED(a,1\<^sub>\<S>) = a" using arytm_3_th_24 by mauto
  thus "a /\<^bsub>\<rat>\<ge>0\<^bsup> 1\<^sub>\<S> = a" using arytm_3_def_10 by mauto
qed

mtheorem arytm_3_th_41:
  "a <> {} \<longrightarrow>  a /\<^bsub>\<rat>\<ge>0\<^bsup> a = 1\<^sub>\<S>"
proof
  assume "a <> {}"
  hence "RED(a,a) = 1\<^sub>\<S>" using arytm_3_th_27 by mauto
  thus "a /\<^bsub>\<rat>\<ge>0\<^bsup> a = 1\<^sub>\<S>" using arytm_3_def_10 by mauto
qed

mtheorem arytm_3_th_42:
  "b <> {} implies numerator(a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(a,b) & denominator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(b,a)"
proof
  assume
A1: "b <> {}"
  show "numerator(a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(a,b) & denominator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(b,a)"
  proof(cases "RED(b,a) = succ {}")
    case A2: True
      hence  "a /\<^bsub>\<rat>\<ge>0\<^bsup> b = RED(a,b)" "RED(a,b) in NAT" 
        using arytm_3_def_10[of a b] ordinal1_def_12[of "RED(a,b)"] ty by mauto
      thus "numerator(a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(a,b) & denominator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(b,a)" 
        using arytm_3_def_8[of "RED(a,b)",THEN conjunct1] 
        arytm_3_def_9[of "RED(a,b)"] A2 ty by mty auto
    next
      case A3: False
       have A4: "\<not> [RED(a,b), RED(b,a)] in omega" using arytm_3_th_32 by auto
       have A5: "a /\<^bsub>\<rat>\<ge>0\<^bsup> b = [RED(a,b), RED(b,a)]" using  A1 A3 arytm_3_def_10 by auto
       thus "numerator(a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(a,b) & denominator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = RED(b,a)" 
         using A4 arytm_3_def_8o[of "RED(b,a)" "RED(a,b)"] 
         arytm_3_def_9o[of "RED(b,a)" "RED(a,b)"] ty by mauto
   qed
 qed

mtheorem arytm_3_th_43:
  "a,b are-coprime & b <> {} implies numerator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = a &
  denominator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = b"
proof
  assume AS: "a,b are-coprime & b <> {}"
  hence "RED(a,b) = a & RED(b,a) = b" using arytm_3_th_23[of b a] arytm_3_th_23[of a b] 
    arytm_3_def_2s[of b a] by mauto
  thus "numerator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = a &
  denominator (a /\<^bsub>\<rat>\<ge>0\<^bsup> b) = b" using arytm_3_th_42 AS by mauto
qed

mtheorem arytm_3_th_44:
  "c <> {} implies (a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c) = a/\<^bsub>\<rat>\<ge>0\<^bsup> b"
proof
  assume
A1: "c <> {}"
  show "(a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c) = a/\<^bsub>\<rat>\<ge>0\<^bsup> b"
  proof(cases "b={}")
    case True
      hence "a /\<^bsub>\<rat>\<ge>0\<^bsup> b = {} & b*\<^sub>\<S>\<^sup>\<nat>c = {}" using arytm_3_def_10[of a b] Mult_1[of c] by auto
      thus  "(a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c) = a/\<^bsub>\<rat>\<ge>0\<^bsup> b" using arytm_3_def_10[of "a*\<^sub>\<S>\<^sup>\<nat>c" "b*\<^sub>\<S>\<^sup>\<nat>c"] by mauto
  next
    case A2:False   
      hence A3: "b*\<^sub>\<S>\<^sup>\<nat>c <> {}" using A1 Mult_9[of c b] by mauto
      hence "denominator((a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c)) = RED(b*\<^sub>\<S>\<^sup>\<nat>c,a*\<^sub>\<S>\<^sup>\<nat>c)" using arytm_3_th_42 by mauto
      hence "denominator((a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c)) = RED(b,a)" using A1 arytm_3_th_28[of a b c] by mauto
      hence A4: "denominator((a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c))= denominator (a/\<^bsub>\<rat>\<ge>0\<^bsup>b)" using A2 arytm_3_th_42 by mauto
      have "numerator ((a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c)) = RED(a*\<^sub>\<S>\<^sup>\<nat>c,b*\<^sub>\<S>\<^sup>\<nat>c)" using  A3 arytm_3_th_42 by mauto
      hence "numerator ((a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c))= RED(a,b)" using A1 arytm_3_th_28[of b a c] by mauto 
      hence "numerator ((a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c))= numerator (a/\<^bsub>\<rat>\<ge>0\<^bsup>b)" using A2 arytm_3_th_42 by mauto
      hence "(a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c) = numerator(a/\<^bsub>\<rat>\<ge>0\<^bsup>b) /\<^bsub>\<rat>\<ge>0\<^bsup> denominator(a/\<^bsub>\<rat>\<ge>0\<^bsup>b)" 
          using A4 arytm_3_th_39 by mauto
      thus  "(a*\<^sub>\<S>\<^sup>\<nat>c)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>c) = a/\<^bsub>\<rat>\<ge>0\<^bsup> b" using arytm_3_th_39 by mauto
  qed
qed

mtheorem arytm_3_th_44s:
  "c <> {} implies (c*\<^sub>\<S>\<^sup>\<nat>a)/\<^bsub>\<rat>\<ge>0\<^bsup>(c*\<^sub>\<S>\<^sup>\<nat>b) = a/\<^bsub>\<rat>\<ge>0\<^bsup> b"
using Mult_6[of a c] Mult_6[of b c] arytm_3_th_44[of b a c] by auto

mtheorem arytm_3_th_45:
  "j <> {} & l <> {} implies (i/\<^bsub>\<rat>\<ge>0\<^bsup>j = k/\<^bsub>\<rat>\<ge>0\<^bsup>l iff i*\<^sub>\<S>\<^sup>\<nat>l = j*\<^sub>\<S>\<^sup>\<nat>k)"
proof(standard,rule iffI2)
  assume A1: "j <> {} \<and> l <> {}"
  let ?x = "i/\<^bsub>\<rat>\<ge>0\<^bsup>j" let ?y = "k/\<^bsub>\<rat>\<ge>0\<^bsup>l"
  let ?ny = "numerator(?y)" let ?dy = "denominator(?y)"
  let ?nx = "numerator(?x)" let ?dx = "denominator(?x)"
  have A3: "?ny = RED(k,l)" using A1 arytm_3_th_42 by mauto
  have A4: "?dx = RED(j,i)" using  A1 arytm_3_th_42 by mauto
  have A5: "?dy = RED(l,k)" using A1 arytm_3_th_42 by mauto
  have A6: "?nx = RED(i,j)" using A1 arytm_3_th_42 by mauto
  show "i /\<^bsub>\<rat>\<ge>0\<^bsup> j =\<^sub>\<S> k /\<^bsub>\<rat>\<ge>0\<^bsup> l \<longrightarrow> i *\<^sub>\<S>\<^sup>\<nat> l =\<^sub>\<S> j *\<^sub>\<S>\<^sup>\<nat> k"
  proof
    assume "i/\<^bsub>\<rat>\<ge>0\<^bsup>j = k/\<^bsub>\<rat>\<ge>0\<^bsup>l"
    hence "i = ?ny*\<^sub>\<S>\<^sup>\<nat>(i hcf j) & l = ?dx*\<^sub>\<S>\<^sup>\<nat>(l hcf k)" 
      using A5 A6 arytm_3_th_21[of k l] arytm_3_th_21[of j i] by mauto
    hence "i*\<^sub>\<S>\<^sup>\<nat>l = ((?ny*\<^sub>\<S>\<^sup>\<nat>(i hcf j))*\<^sub>\<S>\<^sup>\<nat> ?dx) *\<^sub>\<S>\<^sup>\<nat>(l hcf k)"
      using Mult_13[of "l hcf k" ?dx]  by mauto
    hence "i*\<^sub>\<S>\<^sup>\<nat>l= (?ny*\<^sub>\<S>\<^sup>\<nat>((i hcf j)*\<^sub>\<S>\<^sup>\<nat>?dx))*\<^sub>\<S>\<^sup>\<nat>(l hcf k)" 
      using Mult_13[of ?dx "i hcf j" ?ny] by mauto
    hence "i*\<^sub>\<S>\<^sup>\<nat>l = (?ny*\<^sub>\<S>\<^sup>\<nat>j)*\<^sub>\<S>\<^sup>\<nat>(l hcf k)" 
      using A4 arytm_3_th_21[of i j] Mult_6[of ?dx "i hcf j"]
         arytm_3_def_5c[of i j] by mauto
    hence "i*\<^sub>\<S>\<^sup>\<nat>l= j*\<^sub>\<S>\<^sup>\<nat>(?ny*\<^sub>\<S>\<^sup>\<nat>(l hcf k))" using 
     Mult_13[of _ ?ny j] Mult_6[of j ?ny] by mauto
    thus "i*\<^sub>\<S>\<^sup>\<nat>l = j*\<^sub>\<S>\<^sup>\<nat>k" using A3 arytm_3_th_21[of l k] 
      arytm_3_def_5c[of l k] by mauto
  qed
  show "i *\<^sub>\<S>\<^sup>\<nat> l =\<^sub>\<S> j *\<^sub>\<S>\<^sup>\<nat> k \<longrightarrow> i /\<^bsub>\<rat>\<ge>0\<^bsup> j =\<^sub>\<S> k /\<^bsub>\<rat>\<ge>0\<^bsup> l"
  proof
    assume A7: "i*\<^sub>\<S>\<^sup>\<nat>l = j*\<^sub>\<S>\<^sup>\<nat>k"
    hence "?dx = RED(j*\<^sub>\<S>\<^sup>\<nat>l,j*\<^sub>\<S>\<^sup>\<nat>k)" 
      using A1 A4 arytm_3_th_28[of i j l] by mauto 
    hence A8: "?dx = ?dy" using A1 A5 arytm_3_th_28[of k l j] 
        Mult_6[of l j] Mult_6[of j k] by mauto
    have "?nx = RED(j*\<^sub>\<S>\<^sup>\<nat>k,j*\<^sub>\<S>\<^sup>\<nat>l)" using 
    A1 A6 A7 arytm_3_th_28[of j i l] by mauto 
    hence "?nx = ?ny" using  A1 A3 arytm_3_th_28[of l k j]
    Mult_6[of l j] Mult_6[of k j] by mauto
    hence "?x = ?ny/\<^bsub>\<rat>\<ge>0\<^bsup>?dy" using A8 arytm_3_th_39 by mauto
    thus "?x = ?y" using arytm_3_th_39 by mauto
  qed
qed

mdef arytm_3_def_11 (infix "+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>" 110) where
  mlet "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>", "y be Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
  "func x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub> equals
  ( numerator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y)+\<^sub>\<S>\<^sup>\<nat> numerator(y)*\<^sub>\<S>\<^sup>\<nat>denominator(x)) 
    /\<^bsub>\<rat>\<ge>0\<^bsup> (denominator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y))"
proof-
  show "(( numerator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y)+\<^sub>\<S>\<^sup>\<nat> numerator(y)*\<^sub>\<S>\<^sup>\<nat>denominator(x)) 
    /\<^bsub>\<rat>\<ge>0\<^bsup> (denominator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y))) be Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto
qed

mtheorem arytm_3_def_11c:
  "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof-
have "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = ( numerator(y) *\<^sub>\<S>\<^sup>\<nat> denominator(x)+\<^sub>\<S>\<^sup>\<nat> numerator(x)*\<^sub>\<S>\<^sup>\<nat>denominator(y)) 
    /\<^bsub>\<rat>\<ge>0\<^bsup> (denominator(y) *\<^sub>\<S>\<^sup>\<nat> denominator(x))" using 
     Add_6[of "numerator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y)" "numerator(y)*\<^sub>\<S>\<^sup>\<nat>denominator(x)"]  arytm_3_def_11 
     Mult_6[of "denominator(x)" "denominator(y)"]
  by mauto
  thus ?thesis using arytm_3_def_11 by mauto
qed

mdef arytm_3_def_12 (infix "*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>" 110) where
  mlet "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>", "y be Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
  "func x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub> equals
  (numerator(x) *\<^sub>\<S>\<^sup>\<nat> numerator(y)) /\<^bsub>\<rat>\<ge>0\<^bsup> (denominator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y))"
proof-
  show "(numerator(x) *\<^sub>\<S>\<^sup>\<nat> numerator(y) /\<^bsub>\<rat>\<ge>0\<^bsup> denominator(x) *\<^sub>\<S>\<^sup>\<nat> denominator(y)) be
    Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mauto
qed

mtheorem arytm_3_def_12c:
  "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = y *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof-
  have "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = (numerator(y) *\<^sub>\<S>\<^sup>\<nat> numerator(x)) /\<^bsub>\<rat>\<ge>0\<^bsup> 
   (denominator(y) *\<^sub>\<S>\<^sup>\<nat> denominator(x))" using arytm_3_def_12 
  Mult_6[of "denominator(x)" "denominator(y)"] 
  Mult_6[of "numerator(x)" "numerator(y)"] by mauto
  thus ?thesis using arytm_3_def_12 by mauto
qed

mtheorem arytm_3_th_46:
  "j <> {} & l <> {} implies (i /\<^bsub>\<rat>\<ge>0\<^bsup> j) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (k /\<^bsub>\<rat>\<ge>0\<^bsup> l) = (i*\<^sub>\<S>\<^sup>\<nat>l +\<^sub>\<S>\<^sup>\<nat> j*\<^sub>\<S>\<^sup>\<nat>k)/\<^bsub>\<rat>\<ge>0\<^bsup> (j*\<^sub>\<S>\<^sup>\<nat>l)"
proof
  assume A1: "j <> {} \<and> l <> {}"
  let ?ij = "RED(i,j)" let ?ji="RED(j,i)" let ?kl="RED(k,l)" let ?lk="RED(l,k)"
  have KL: "k hcf l = l hcf k" "k hcf l<>{}" using A1 arytm_3_def_5c[of k l ] arytm_3_th_15[of k l] by mauto
  have A3: "denominator(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = ?lk & denominator(i/\<^bsub>\<rat>\<ge>0\<^bsup>j) = ?ji" 
    using A1 arytm_3_th_42[ of k] arytm_3_th_42[ of i] by mauto
  have N: "numerator(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = ?kl \<and> numerator(i/\<^bsub>\<rat>\<ge>0\<^bsup>j) = ?ij" 
    using A1 arytm_3_th_42[ of k] arytm_3_th_42[ of i] by mauto
  have IJ:"i hcf j<>{}" using arytm_3_def_5c[of i j] A1 arytm_3_th_15[of i j] by auto
  have "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?ij*\<^sub>\<S>\<^sup>\<nat> ?lk+\<^sub>\<S>\<^sup>\<nat>?ji*\<^sub>\<S>\<^sup>\<nat>?kl) /\<^bsub>\<rat>\<ge>0\<^bsup> (?ji*\<^sub>\<S>\<^sup>\<nat>?lk)"
    using N A3 arytm_3_def_11[of "i/\<^bsub>\<rat>\<ge>0\<^bsup>j" "k/\<^bsub>\<rat>\<ge>0\<^bsup>l",simplified] Mult_6[of ?kl ?ji] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?ij*\<^sub>\<S>\<^sup>\<nat> ?lk+\<^sub>\<S>\<^sup>\<nat>?ji*\<^sub>\<S>\<^sup>\<nat>?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j) /\<^bsub>\<rat>\<ge>0\<^bsup> ((?ji*\<^sub>\<S>\<^sup>\<nat>?lk)*\<^sub>\<S>\<^sup>\<nat>(i hcf j))"
    using arytm_3_th_44[of "?ji*\<^sub>\<S>\<^sup>\<nat>?lk" _  "i hcf j"] IJ by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?ij*\<^sub>\<S>\<^sup>\<nat> ?lk+\<^sub>\<S>\<^sup>\<nat>?ji*\<^sub>\<S>\<^sup>\<nat>?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk*\<^sub>\<S>\<^sup>\<nat>(?ji*\<^sub>\<S>\<^sup>\<nat>(i hcf j)))"
    using Mult_13[of _  ?ji ?lk] Mult_6[of ?ji ?lk] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?ij*\<^sub>\<S>\<^sup>\<nat> ?lk+\<^sub>\<S>\<^sup>\<nat>?ji*\<^sub>\<S>\<^sup>\<nat>?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk*\<^sub>\<S>\<^sup>\<nat>j)"
    using arytm_3_th_21[of i j] arytm_3_def_5c[of i j] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = ((?ij*\<^sub>\<S>\<^sup>\<nat> ?lk)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)+\<^sub>\<S>\<^sup>\<nat>(?ji*\<^sub>\<S>\<^sup>\<nat>?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk*\<^sub>\<S>\<^sup>\<nat>j)"
    using Mult_11s[of "?ji*\<^sub>\<S>\<^sup>\<nat>?kl" "i hcf j" "?ij*\<^sub>\<S>\<^sup>\<nat> ?lk"] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?lk*\<^sub>\<S>\<^sup>\<nat> (?ij*\<^sub>\<S>\<^sup>\<nat>(i hcf j))+\<^sub>\<S>\<^sup>\<nat>(?ji*\<^sub>\<S>\<^sup>\<nat>?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk*\<^sub>\<S>\<^sup>\<nat>j)"
    using Mult_6[of ?ij ?lk] Mult_13[of _ ?ij ?lk] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?lk*\<^sub>\<S>\<^sup>\<nat> i +\<^sub>\<S>\<^sup>\<nat>(?ji*\<^sub>\<S>\<^sup>\<nat>?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk*\<^sub>\<S>\<^sup>\<nat>j)"
    using arytm_3_th_21[of j i] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?lk*\<^sub>\<S>\<^sup>\<nat> i +\<^sub>\<S>\<^sup>\<nat>?kl*\<^sub>\<S>\<^sup>\<nat> j) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk*\<^sub>\<S>\<^sup>\<nat>j)" using Mult_6[of ?ji ?kl] 
    arytm_3_def_5c[of i j] arytm_3_th_21[of i j] Mult_13[of _ ?ji ?kl] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?lk*\<^sub>\<S>\<^sup>\<nat> i +\<^sub>\<S>\<^sup>\<nat>?kl*\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(k hcf l) /\<^bsub>\<rat>\<ge>0\<^bsup> (j*\<^sub>\<S>\<^sup>\<nat>?lk)*\<^sub>\<S>\<^sup>\<nat>(k hcf l)" using
     KL arytm_3_th_44[of "?lk*\<^sub>\<S>\<^sup>\<nat>j" "?lk*\<^sub>\<S>\<^sup>\<nat> i +\<^sub>\<S>\<^sup>\<nat>?kl*\<^sub>\<S>\<^sup>\<nat> j" "k hcf l"] Mult_6[of ?lk j] by mauto 
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?lk*\<^sub>\<S>\<^sup>\<nat> i +\<^sub>\<S>\<^sup>\<nat>?kl*\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(k hcf l) /\<^bsub>\<rat>\<ge>0\<^bsup> (j*\<^sub>\<S>\<^sup>\<nat>l)" using
     KL arytm_3_th_21[of k l] Mult_13[of _ ?lk j] by mauto 
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = ((?lk*\<^sub>\<S>\<^sup>\<nat> i)*\<^sub>\<S>\<^sup>\<nat>(k hcf l) +\<^sub>\<S>\<^sup>\<nat>(?kl*\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(k hcf l)) /\<^bsub>\<rat>\<ge>0\<^bsup> (j*\<^sub>\<S>\<^sup>\<nat>l)" using
    Mult_11s[ of "?kl*\<^sub>\<S>\<^sup>\<nat> j" "k hcf l" "?lk*\<^sub>\<S>\<^sup>\<nat> i"] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (i*\<^sub>\<S>\<^sup>\<nat>l +\<^sub>\<S>\<^sup>\<nat>(?kl*\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(k hcf l)) /\<^bsub>\<rat>\<ge>0\<^bsup> (j*\<^sub>\<S>\<^sup>\<nat>l)" using
    Mult_6[of ?lk i] Mult_13[of _ ?lk i] arytm_3_th_21[of k l] KL by mauto
  thus "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (i*\<^sub>\<S>\<^sup>\<nat>l +\<^sub>\<S>\<^sup>\<nat>j*\<^sub>\<S>\<^sup>\<nat> k) /\<^bsub>\<rat>\<ge>0\<^bsup> (j*\<^sub>\<S>\<^sup>\<nat>l)" using
    Mult_6[of ?kl j] Mult_13[of _ ?kl j] arytm_3_th_21[of l k] KL by mauto
qed

mtheorem arytm_3_th_47:
  "k <> {} implies (i/\<^bsub>\<rat>\<ge>0\<^bsup>k)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(j/\<^bsub>\<rat>\<ge>0\<^bsup>k) = (i +\<^sub>\<S>\<^sup>\<nat> j)/\<^bsub>\<rat>\<ge>0\<^bsup>k"
proof
  assume A1: "k <> {}"
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>k)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (j/\<^bsub>\<rat>\<ge>0\<^bsup>k) = (i *\<^sub>\<S>\<^sup>\<nat> k +\<^sub>\<S>\<^sup>\<nat> j *\<^sub>\<S>\<^sup>\<nat> k)/\<^bsub>\<rat>\<ge>0\<^bsup>(k *\<^sub>\<S>\<^sup>\<nat> k)" using arytm_3_th_46[of j i k k] Mult_6[of j k]
    by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>k)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (j/\<^bsub>\<rat>\<ge>0\<^bsup>k) = ((i +\<^sub>\<S>\<^sup>\<nat> j) *\<^sub>\<S>\<^sup>\<nat> k)/\<^bsub>\<rat>\<ge>0\<^bsup>(k *\<^sub>\<S>\<^sup>\<nat> k)" using Mult_11s[of j k i] by mauto
  thus "(i/\<^bsub>\<rat>\<ge>0\<^bsup>k)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (j/\<^bsub>\<rat>\<ge>0\<^bsup>k) = (i +\<^sub>\<S>\<^sup>\<nat> j) /\<^bsub>\<rat>\<ge>0\<^bsup> k" using arytm_3_th_44[of k "i +\<^sub>\<S>\<^sup>\<nat> j" k] A1 by mauto
qed

mtheorem
  "cluster natural \<rightarrow> Element-of RAT\<^bsup>\<ge>0\<^bsub> for object"
proof(standard,intro ballI impI)
  fix it assume "it is natural"
  hence "it in NAT" using ordinal1_def_12 all_set by auto
  hence "it in RAT\<^bsup>\<ge>0\<^bsub>" using arytm_3_def_7 xboole_0_def_3 by mauto  
  thus "it is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by auto
qed mauto

mtheorem arytm_3_th_48:
  "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = {}"
proof-
  have "numerator({}) = {} & numerator(x)*\<^sub>\<S>\<^sup>\<nat>{} = {}" using 
    arytm_3_def_8 Mult_2[of "numerator(x)"] ordinal1_def_11 by mauto
  thus "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = {}" using arytm_3_th_40 arytm_3_def_12[of x "{}"] by mauto
qed

mtheorem arytm_3_th_49:
  "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (i*\<^sub>\<S>\<^sup>\<nat>k)/\<^bsub>\<rat>\<ge>0\<^bsup>(j*\<^sub>\<S>\<^sup>\<nat>l)"
proof(cases "j <> {} & l <> {}")
  case A1: True
    let ?ij = "RED(i,j)" let ?ji="RED(j,i)" let ?kl="RED(k,l)" let ?lk="RED(l,k)"
    have KL: "k hcf l = l hcf k" "k hcf l<>{}" using A1 arytm_3_def_5c[of k l ] 
       arytm_3_th_15[of k l] by mauto
    have IJ: "i hcf j = j hcf i" "i hcf j<>{}" using A1 arytm_3_def_5c[of i j ] 
       arytm_3_th_15[of i j] by mauto
  have A2: "denominator(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = ?lk & denominator(i/\<^bsub>\<rat>\<ge>0\<^bsup>j) = ?ji" 
    using A1 arytm_3_th_42[ of k] arytm_3_th_42[ of i] by mauto
  have N: "numerator(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = ?kl \<and> numerator(i/\<^bsub>\<rat>\<ge>0\<^bsup>j) = ?ij" 
    using A1 arytm_3_th_42[ of k] arytm_3_th_42[ of i] by mauto
  hence "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (?ij *\<^sub>\<S>\<^sup>\<nat> ?kl) /\<^bsub>\<rat>\<ge>0\<^bsup> (?ji *\<^sub>\<S>\<^sup>\<nat> ?lk) " using A2 arytm_3_def_12[of "i/\<^bsub>\<rat>\<ge>0\<^bsup>j" "k/\<^bsub>\<rat>\<ge>0\<^bsup>l"] 
      by mauto
  also have "... =(?ij *\<^sub>\<S>\<^sup>\<nat> ?kl)*\<^sub>\<S>\<^sup>\<nat>(i hcf j) /\<^bsub>\<rat>\<ge>0\<^bsup> (?ji *\<^sub>\<S>\<^sup>\<nat> ?lk)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)"
    using A1 A2 IJ arytm_3_th_44[of "?ji *\<^sub>\<S>\<^sup>\<nat> ?lk" _ "i hcf j"] by mauto
  also have "... =?kl *\<^sub>\<S>\<^sup>\<nat> (?ij*\<^sub>\<S>\<^sup>\<nat>(i hcf j)) /\<^bsub>\<rat>\<ge>0\<^bsup> (?ji *\<^sub>\<S>\<^sup>\<nat> ?lk)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)"
    using Mult_6[of ?ij ?kl] Mult_13[of _ ?ij ?kl] by mauto
  also have "... =?kl *\<^sub>\<S>\<^sup>\<nat> i /\<^bsub>\<rat>\<ge>0\<^bsup> (?ji *\<^sub>\<S>\<^sup>\<nat> ?lk)*\<^sub>\<S>\<^sup>\<nat>(i hcf j)"
    using arytm_3_th_21[of j i] by mty auto
  also have "... =?kl *\<^sub>\<S>\<^sup>\<nat> i /\<^bsub>\<rat>\<ge>0\<^bsup> ?lk *\<^sub>\<S>\<^sup>\<nat> (?ji*\<^sub>\<S>\<^sup>\<nat>(i hcf j))"
    using Mult_6[of ?ji ?lk] Mult_13[of _ ?ji ?lk] by mty auto
  also have "... =?kl *\<^sub>\<S>\<^sup>\<nat> i /\<^bsub>\<rat>\<ge>0\<^bsup> ?lk *\<^sub>\<S>\<^sup>\<nat> j"
    using arytm_3_th_21[of  i j] IJ by mty auto
  also have "... =(?kl *\<^sub>\<S>\<^sup>\<nat> i)*\<^sub>\<S>\<^sup>\<nat>(l hcf k) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk *\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(l hcf k)"
    using arytm_3_th_44[of "?lk *\<^sub>\<S>\<^sup>\<nat> j" _ "l hcf k"] KL by mty auto
  also have "... =i *\<^sub>\<S>\<^sup>\<nat> (?kl*\<^sub>\<S>\<^sup>\<nat>(l hcf k)) /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk *\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(l hcf k)"
    using Mult_6[of i ?kl] Mult_13[of _  ?kl i] by mty auto
  also have "... =i *\<^sub>\<S>\<^sup>\<nat> k /\<^bsub>\<rat>\<ge>0\<^bsup> (?lk *\<^sub>\<S>\<^sup>\<nat> j)*\<^sub>\<S>\<^sup>\<nat>(l hcf k)"
    using arytm_3_th_21[of  l k] KL by mty auto
  also have "... =i *\<^sub>\<S>\<^sup>\<nat> k /\<^bsub>\<rat>\<ge>0\<^bsup> (j *\<^sub>\<S>\<^sup>\<nat> (?lk*\<^sub>\<S>\<^sup>\<nat>(l hcf k)))"
    using Mult_6[of j ?lk] Mult_13[of _  ?lk j] by mty auto
  also have "... =i *\<^sub>\<S>\<^sup>\<nat> k /\<^bsub>\<rat>\<ge>0\<^bsup> (j *\<^sub>\<S>\<^sup>\<nat> l)"
    using arytm_3_th_21[of   k l] KL by mauto
  finally show "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (i*\<^sub>\<S>\<^sup>\<nat>k)/\<^bsub>\<rat>\<ge>0\<^bsup>(j*\<^sub>\<S>\<^sup>\<nat>l)" by auto
next
  case A3:False 
    hence "i/\<^bsub>\<rat>\<ge>0\<^bsup>j = {} or k/\<^bsub>\<rat>\<ge>0\<^bsup>l = {}" using arytm_3_def_10 by mauto
    hence A4: "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = {}" using arytm_3_th_48 arytm_3_def_12c[of "i/\<^bsub>\<rat>\<ge>0\<^bsup>j" "k/\<^bsub>\<rat>\<ge>0\<^bsup>l"] by mauto
    have "j*\<^sub>\<S>\<^sup>\<nat>l = {}" using  A3 Mult_1 Mult_2 by mauto
    thus "(i/\<^bsub>\<rat>\<ge>0\<^bsup>j)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(k/\<^bsub>\<rat>\<ge>0\<^bsup>l) = (i*\<^sub>\<S>\<^sup>\<nat>k)/\<^bsub>\<rat>\<ge>0\<^bsup>(j*\<^sub>\<S>\<^sup>\<nat>l)" using A4 arytm_3_def_10[of _ "j*\<^sub>\<S>\<^sup>\<nat>l"] by mauto
qed

mtheorem arytm_3_th_50:
  "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = x"
proof-
  have A1: "numerator(x)*\<^sub>\<S>\<^sup>\<nat>1\<^sub>\<S> = numerator(x) & {}*\<^sub>\<S>\<^sup>\<nat>denominator(x) = {}"
    using Mult_1 Mult_5 by mty auto
  have A2: "denominator(x)*\<^sub>\<S>\<^sup>\<nat>1\<^sub>\<S> = denominator(x) & numerator(x)+\<^sub>\<S>\<^sup>\<nat>{} = numerator(x)"
     using Add_3 Mult_5 by mty auto
  have "denominator({}) = 1\<^sub>\<S> & numerator({}) = {}"
        using arytm_3_def_8 arytm_3_def_9 ordinal1_def_11 by mauto
  thus "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = x" using A1 A2 arytm_3_th_39[of x] arytm_3_def_11[of x "{}"] by mty auto
qed

mtheorem arytm_3_th_51:
  "(x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z = x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(y+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z)"
proof-
  let ?nx = "numerator(x)" let ?ny = "numerator(y)" let ?nz = "numerator(z)"
  let  ?dx = "denominator(x)" let ?dy = "denominator(y)" let  ?dz = "denominator(z)"
  have A1: "?dy <> {}" using arytm_3_th_35 by mty auto
  have A2: "?dz <> {}" using arytm_3_th_35 by mty auto
  hence
A3: "?dy*\<^sub>\<S>\<^sup>\<nat>?dz <> {}" using A1 Mult_9[of ?dz ?dy] by mty auto
  have
A4: "?dx <> {}" using arytm_3_th_35 by mty auto
  hence
A5: "?dx*\<^sub>\<S>\<^sup>\<nat>?dy <> {}" using A1 Mult_9[of ?dy ?dx] by mty auto
  hence "(x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z = ((?nx*\<^sub>\<S>\<^sup>\<nat>?dy+\<^sub>\<S>\<^sup>\<nat>?ny*\<^sub>\<S>\<^sup>\<nat>?dx)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy))+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (?nz/\<^bsub>\<rat>\<ge>0\<^bsup>?dz)" 
    using  arytm_3_th_39[of z]
        arytm_3_def_11[of x y]  by mty auto
  also have "... = ((?nx*\<^sub>\<S>\<^sup>\<nat>?dy+\<^sub>\<S>\<^sup>\<nat>?ny*\<^sub>\<S>\<^sup>\<nat>?dx)*\<^sub>\<S>\<^sup>\<nat>?dz +\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?nz)/\<^bsub>\<rat>\<ge>0\<^bsup> ((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz)" 
          using A2 A5 arytm_3_th_46[of ?nz "?nx*\<^sub>\<S>\<^sup>\<nat>?dy+\<^sub>\<S>\<^sup>\<nat>?ny*\<^sub>\<S>\<^sup>\<nat>?dx" ?dz "?dx*\<^sub>\<S>\<^sup>\<nat>?dy"] by mty auto
   also have "...= ((?nx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?ny)*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?nz)/\<^bsub>\<rat>\<ge>0\<^bsup>((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz)"
     using Mult_6[of ?dx ?ny] Mult_11s[of _ ?dz _] by mty auto
   also have "...= (?nx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>?dx*\<^sub>\<S>\<^sup>\<nat>(?ny*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz)"
     using Mult_13[of ?dz ?dy ?nx] Mult_13[of ?dz ?ny ?dx] Mult_13[of ?nz ?dy ?dx] by mauto
   also have "...= (?nx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>(?ny*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz)))/\<^bsub>\<rat>\<ge>0\<^bsup>((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz)"
     using Add_7[of "?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz)"] by mty auto
   also have "...= (?nx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>?dx*\<^sub>\<S>\<^sup>\<nat>((?ny*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz)))/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?dz))"
     using Mult_11[of "(?dy*\<^sub>\<S>\<^sup>\<nat>?nz)" _ ?dx] Mult_13[of ?dz ?dy ?dx]  by mty auto
   also have "...= (?nx /\<^bsub>\<rat>\<ge>0\<^bsup> ?dx) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (((?ny*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup> (?dy*\<^sub>\<S>\<^sup>\<nat>?dz))"
     using arytm_3_th_46[of "(?ny*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz)" ?nx "?dy*\<^sub>\<S>\<^sup>\<nat>?dz" ?dx] A3 A4 by mty auto 
   also have "...= (?nx /\<^bsub>\<rat>\<ge>0\<^bsup> ?dx) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using arytm_3_def_11[of y z] Mult_6[of ?dy ?nz]by mty auto
   also have "... = x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(y+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z)" using arytm_3_th_39[of x] by mty auto
   finally show ?thesis by auto
qed


mtheorem arytm_3_th_52:
  "(x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z = x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (y *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z)"
proof-
  let ?nx = "numerator(x)" let ?ny = "numerator(y)" let ?nz = "numerator(z)"
  let  ?dx = "denominator(x)" let ?dy = "denominator(y)" let  ?dz = "denominator(z)"
  have A1: "x = ?nx/\<^bsub>\<rat>\<ge>0\<^bsup>?dx" using arytm_3_th_39 by mauto
  have "z = ?nz/\<^bsub>\<rat>\<ge>0\<^bsup>?dz" using  arytm_3_th_39 by mauto
  hence "(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y)*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z = ((?nx*\<^sub>\<S>\<^sup>\<nat>?ny)*\<^sub>\<S>\<^sup>\<nat>?nz)/\<^bsub>\<rat>\<ge>0\<^bsup>((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz)" using arytm_3_def_12[of x y] 
      arytm_3_th_49[of ?dz ?nz "?dx*\<^sub>\<S>\<^sup>\<nat>?dy"] by mty auto
  also have "... =  (?nx*\<^sub>\<S>\<^sup>\<nat>(?ny*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?dz))" using Mult_13[of ?dz ?dy ?dx]
    Mult_13[of ?nz ?ny ?nx] by mauto
  also have "... =  (?nx/\<^bsub>\<rat>\<ge>0\<^bsup> ?dx) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((?ny*\<^sub>\<S>\<^sup>\<nat>?nz)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dy*\<^sub>\<S>\<^sup>\<nat>?dz))" using arytm_3_th_49 by mty auto
  also have "... =  (?nx/\<^bsub>\<rat>\<ge>0\<^bsup> ?dx) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( y *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z)" using arytm_3_def_12[of y z] 
    by mauto
  finally show ?thesis using A1 by mauto
qed

mtheorem arytm_3_th_53:
  "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> = x"
proof-
  have A1: "numerator(x)*\<^sub>\<S>\<^sup>\<nat>1\<^sub>\<S> = numerator(x) & denominator(x)*\<^sub>\<S>\<^sup>\<nat>1\<^sub>\<S> 
  = denominator(x)" using Mult_5 by mauto 
  have "1\<^sub>\<S> in NAT" using ordinal1_def_12[of "1\<^sub>\<S>"] by mty auto
  hence  "numerator(1\<^sub>\<S>) = 1\<^sub>\<S> & denominator(1\<^sub>\<S>) = 1\<^sub>\<S>"
    using arytm_3_def_8[of "1\<^sub>\<S>"] arytm_3_def_9[of "1\<^sub>\<S>"] by mty auto
  thus ?thesis using A1 arytm_3_th_39 arytm_3_def_12[of x "1\<^sub>\<S>"] by mauto
qed

mtheorem arytm_3_th_53s:
  "1\<^sub>\<S> *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x = x" using arytm_3_def_12c[of "1\<^sub>\<S>" x] arytm_3_th_53 by mauto

mtheorem arytm_3_th_54:
  "x <> {} implies (ex y st x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = 1\<^sub>\<S>)"
proof
  let ?nx = "numerator(x)" let ?dx = "denominator(x)"
  have A1: "?dx <> {}" using arytm_3_th_35 by mauto
  assume "x <> {}"
  hence
A2: "?nx <> {}" using arytm_3_th_37 by mauto
  hence
A3: "?nx *\<^sub>\<S>\<^sup>\<nat> ?dx <>{}" using Mult_9[of ?dx ?nx] A1 by mty auto 
  let ?y = "?dx /\<^bsub>\<rat>\<ge>0\<^bsup> ?nx"
  show "ex y st x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = 1\<^sub>\<S>"
  proof(rule bexI[of _ ?y "Element-of RAT\<^bsup>\<ge>0\<^bsub>"])
     have "?nx, ?dx are-coprime" using arytm_3_th_34 by mauto
     hence "denominator(?y) = ?nx & 
            numerator(?y) = ?dx" using A2 arytm_3_th_43[of ?nx ?dx]
            arytm_3_def_2s[of ?dx ?nx] by mauto
     hence "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y = ?nx *\<^sub>\<S>\<^sup>\<nat> ?dx /\<^bsub>\<rat>\<ge>0\<^bsup> ?nx *\<^sub>\<S>\<^sup>\<nat> ?dx" 
       using arytm_3_def_12[of x] Mult_6[of ?nx ?dx] by mauto     
     thus "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y = 1\<^sub>\<S>" using A3 arytm_3_th_41   by mty auto
  qed mauto
qed

mtheorem arytm_3_th_55:
  "x <> {} implies (ex z st y = x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z)"
proof
  assume "x <> {}"
  then obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z = 1\<^sub>\<S>" using arytm_3_th_54 by mauto
  show "ex z st y = x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z"
  proof(rule bexI[of _ "z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"])
    have "y = y*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>"  using arytm_3_th_53[of y] by mauto
    hence "y =  (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using  A1 arytm_3_th_52[of z x y] 
       arytm_3_def_12c[of x y] by mauto
    thus "y =  x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y)" using arytm_3_th_52[of z y x] 
      arytm_3_def_12c[of y z] by auto
  qed mauto
qed

mtheorem arytm_3_th_56:
  "x <> {} & x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y = x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z implies y = z"
proof
  assume AS: "x <> {} & x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y = x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z"
  then obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>r = 1\<^sub>\<S>" using arytm_3_th_54 by mauto
  have "r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y) = 1\<^sub>\<S>*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using  
    A1 arytm_3_th_52[of y x r] arytm_3_def_12c[of r x] by mty auto
  hence A2: "r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y) = y" using 
     arytm_3_def_12c[of "1\<^sub>\<S>" y] arytm_3_th_53 by mty auto
  have "r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z) = z" using A1 arytm_3_th_53[of z] arytm_3_def_12c[of r x]
      arytm_3_def_12c[of "1\<^sub>\<S>" z] arytm_3_th_52[of z x r] by mty auto 
  hence "r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y) = z" using AS by auto
  thus "y=z" using A2 by auto
qed

mtheorem arytm_3_th_57:
  "x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z) = (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z)"
proof-
  let ?nx = "numerator(x)" let ?ny = "numerator(y)" let ?nz = "numerator(z)"
  let  ?dx = "denominator(x)" let ?dy = "denominator(y)" let  ?dz = "denominator(z)"
  have A1: "?dx <> {}" using arytm_3_th_35 by mty auto
  have "?dz <> {}" using arytm_3_th_35 by mty auto
  hence
A2: "?dx*\<^sub>\<S>\<^sup>\<nat>?dz <> {}" using A1 Mult_9[of ?dz ?dx] by mty auto
  have "?dy <> {}" using arytm_3_th_35 by mauto
  hence
A3: "?dx*\<^sub>\<S>\<^sup>\<nat>?dy <> {}" using  A1 Mult_9[of ?dy ?dx] by mauto
  have "x = ?nx /\<^bsub>\<rat>\<ge>0\<^bsup> ?dx" using arytm_3_th_39 by auto
  hence "x*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(y+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z) = (?nx*\<^sub>\<S>\<^sup>\<nat>(?ny*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>?dy*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>?dz)"
    using arytm_3_th_49[of "?dy*\<^sub>\<S>\<^sup>\<nat>?dz" "?ny*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>?dy*\<^sub>\<S>\<^sup>\<nat>?nz" ?dx ?nx]
           arytm_3_def_11[of y z] Mult_6[of ?dy ?nz] Mult_13[of ?dz ?dy ?dx]
    by mty auto
  also have "... = (?nx*\<^sub>\<S>\<^sup>\<nat>(?ny*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>?nx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>((?dy*\<^sub>\<S>\<^sup>\<nat>?dx)*\<^sub>\<S>\<^sup>\<nat>?dz)"
    using Mult_11[of _ "?ny*\<^sub>\<S>\<^sup>\<nat>?dz" ?nx] Mult_13[of ?dz ?dy ?dx] 
    Mult_6[of ?dy ?dx]by mty auto
  also have "... = ((?nx*\<^sub>\<S>\<^sup>\<nat>?ny)*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>?dy*\<^sub>\<S>\<^sup>\<nat>(?nx*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>(?dy*\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dz))"
    using Mult_13[of ?nz ?dy ?nx] Mult_6[of ?nx ?dy] Mult_13[of ?nz ?nx ?dy]
       Mult_13[of ?dz ?ny ?nx] Mult_13[of ?dz ?dx ?dy]
      by mty auto
  also have "... = (?dx*\<^sub>\<S>\<^sup>\<nat>((?nx*\<^sub>\<S>\<^sup>\<nat>?ny)*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>(?nx*\<^sub>\<S>\<^sup>\<nat>?nz))))/\<^bsub>\<rat>\<ge>0\<^bsup>
    (?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dz)))" using arytm_3_th_35[of x] arytm_3_th_44s[of "?dy*\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dz)"  _ ?dx] by mty auto
  also have 
    "...= ((?dx*\<^sub>\<S>\<^sup>\<nat>(?nx*\<^sub>\<S>\<^sup>\<nat>?ny))*\<^sub>\<S>\<^sup>\<nat>?dz+\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat> ?dy)*\<^sub>\<S>\<^sup>\<nat>(?nx*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>
    (?dx*\<^sub>\<S>\<^sup>\<nat>(?dy*\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dz)))" using Mult_11[of _ _ ?dx] 
        Mult_13[of "?nx*\<^sub>\<S>\<^sup>\<nat>?nz" ?dy ?dx] Mult_13[of ?dz "?nx*\<^sub>\<S>\<^sup>\<nat>?ny" ?dx]by mty auto
  also have 
    "...= ((?nx*\<^sub>\<S>\<^sup>\<nat>?ny)*\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dz)+\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat> ?dy)*\<^sub>\<S>\<^sup>\<nat>(?nx*\<^sub>\<S>\<^sup>\<nat>?nz))/\<^bsub>\<rat>\<ge>0\<^bsup>
    ((?dx*\<^sub>\<S>\<^sup>\<nat>?dy)*\<^sub>\<S>\<^sup>\<nat>(?dx*\<^sub>\<S>\<^sup>\<nat>?dz))" using Mult_6[of ?dx "?nx*\<^sub>\<S>\<^sup>\<nat>?ny"] 
          Mult_13[of ?dz ?dx "?nx*\<^sub>\<S>\<^sup>\<nat>?ny"] Mult_13[of "?dx*\<^sub>\<S>\<^sup>\<nat>?dz" ?dy ?dx] by mty auto
  also have "... = ((?nx*\<^sub>\<S>\<^sup>\<nat>?ny)/\<^bsub>\<rat>\<ge>0\<^bsup> (?dx*\<^sub>\<S>\<^sup>\<nat>?dy)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((?nx*\<^sub>\<S>\<^sup>\<nat>?nz) /\<^bsub>\<rat>\<ge>0\<^bsup> (?dx*\<^sub>\<S>\<^sup>\<nat>?dz))" 
    using arytm_3_th_46[of "?nx*\<^sub>\<S>\<^sup>\<nat>?nz" "?nx*\<^sub>\<S>\<^sup>\<nat>?ny" "?dx*\<^sub>\<S>\<^sup>\<nat>?dz"] A2 A3 by mty auto
  also have "... = (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z)" 
    using arytm_3_def_12[of x y] arytm_3_def_12[of x z] by mty auto
  finally show ?thesis by auto
qed

mtheorem arytm_3_th_57s:
  " (y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x = (y *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)" using arytm_3_def_12c[of x y] 
     arytm_3_def_12c[of x z] using arytm_3_def_12c[of x "y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z"] arytm_3_th_57 by mty auto

mtheorem arytm_3_th_58:
  " i+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j = i+\<^sub>\<S>\<^sup>\<nat>j"
proof-
  let ?ni = "numerator(i)" let ?nj = "numerator(j)"
  have A1: "j in NAT" using ordinal1_def_12[of j] by mauto
  hence A2: "denominator(j) = 1\<^sub>\<S>" "?nj=j" using arytm_3_def_9[of j] arytm_3_def_8[of j]
    by mauto
  have A3: "i in omega" using ordinal1_def_12[of i] by mauto
  hence A4: "denominator(i) = 1\<^sub>\<S>" "?ni=i" 
    using arytm_3_def_9[of i] arytm_3_def_8[of i] by mauto
  hence "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j = (?ni *\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> ?nj)/\<^bsub>\<rat>\<ge>0\<^bsup> 1\<^sub>\<S>" 
      using A2 arytm_3_def_11[of i j] Mult_6[of ?nj] Mult_5 by mauto 
  hence "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j = (?ni +\<^sub>\<S>\<^sup>\<nat> ?nj)/\<^bsub>\<rat>\<ge>0\<^bsup> 1\<^sub>\<S>" 
      using Mult_5[of ?ni] Mult_5[of ?nj] by mauto 
  thus "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j = i +\<^sub>\<S>\<^sup>\<nat> j" using A2 A4  arytm_3_th_40 by mauto 
qed

mtheorem arytm_3_th_59:
  " i*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>j = i*\<^sub>\<S>\<^sup>\<nat>j"
proof-
  let ?ni = "numerator(i)" let ?nj = "numerator(j)"
  have A1: "j in NAT" using ordinal1_def_12[of j] by mauto
  hence A2: "denominator(j) = 1\<^sub>\<S>" "?nj=j" using arytm_3_def_9[of j] arytm_3_def_8[of j]
    by mauto
  have A3: "i in omega" using ordinal1_def_12[of i] by mauto
  hence A4: "denominator(i) = 1\<^sub>\<S>" "?ni=i" 
    using arytm_3_def_9[of i] arytm_3_def_8[of i] by mauto
  hence "i *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j = (?ni*\<^sub>\<S>\<^sup>\<nat>?nj)/\<^bsub>\<rat>\<ge>0\<^bsup> 1\<^sub>\<S>" using A2 arytm_3_def_12[of i j] Mult_5 by mauto
  thus "i *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> j = i *\<^sub>\<S>\<^sup>\<nat> j" using A2 A4 arytm_3_th_40 by mauto
qed

mtheorem arytm_3_th_60:
  "ex y st x = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"
proof-
  let ?O = "1\<^sub>\<S> +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>"
  have " 1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> = succ( 1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> {})" using Add_1 by mauto
  hence O: "1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> = 2\<^sub>\<S>" "1\<^sub>\<S> in 2\<^sub>\<S>" using Add_3 ordinal1_th_2 by mauto
  have "?O = 1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S>" using arytm_3_th_58 by mauto
  hence "?O <> {}" using O by auto
  then obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "?O*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z = 1\<^sub>\<S>" using arytm_3_th_54[of ?O] by mty auto
  have "x = 1\<^sub>\<S> *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_53 arytm_3_def_12c by mty auto
  also have "...= ?O*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)" using A1 arytm_3_th_52[of x z ?O] by mty auto
  also have "...= (1\<^sub>\<S> *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (1\<^sub>\<S> *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x))" using arytm_3_th_57s by mty auto
  also have "...= (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)" using arytm_3_th_53s by mty auto
  finally show ?thesis using bexI[of _ "z *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto 
qed

mdef arytm_3_def_13 ("_ \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> _ " [41,40]40) where
  mlet "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>", "y be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
  "pred x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y means
      ex z being Element-of RAT\<^bsup>\<ge>0\<^bsub> st y = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z"..

mtheorem arytm_3_def_13c:
  "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y \<or> y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
  proof-
    let ?nx = "numerator(x)" let ?ny = "numerator(y)"
    let ?dx = "denominator(x)" let ?dy = "denominator(y)"
    have A1: "?dx <> {} & ?dy <> {}" using  arytm_3_th_35 by mauto
    hence a1:"?dx*\<^sub>\<S>\<^sup>\<nat>?dy<>{}" using Mult_9[of ?dy ?dx] by mty auto 
    have A2: "?nx/\<^bsub>\<rat>\<ge>0\<^bsup>?dx = x & ?ny/\<^bsub>\<rat>\<ge>0\<^bsup>?dy = y" using  arytm_3_th_39 by mty auto
    have AA: 
    "(?nx*\<^sub>\<S>\<^sup>\<nat>?dy)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy) = ?nx/\<^bsub>\<rat>\<ge>0\<^bsup>?dx & (?ny*\<^sub>\<S>\<^sup>\<nat>?dx)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy) = ?ny/\<^bsub>\<rat>\<ge>0\<^bsup>?dy"
      using A1 arytm_3_th_44[of ?dx ?nx ?dy] arytm_3_th_44[of ?dy ?ny ?dx] Mult_6[of ?dx ?dy]
         by mty auto
    show "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y \<or> y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
    proof(cases "?nx*\<^sub>\<S>\<^sup>\<nat>?dy c= ?ny*\<^sub>\<S>\<^sup>\<nat>?dx")
      case True
      then obtain k where [ty]:"k be Nat" and
         A3: "?ny*\<^sub>\<S>\<^sup>\<nat>?dx = ?nx*\<^sub>\<S>\<^sup>\<nat>?dy+\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by mty auto
      hence "(?nx*\<^sub>\<S>\<^sup>\<nat>?dy+\<^sub>\<S>\<^sup>\<nat> k)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy) = y" using A2 AA by mauto
      hence "((?nx*\<^sub>\<S>\<^sup>\<nat>?dy)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (k/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy))= y" 
        using arytm_3_th_47[of k "?nx*\<^sub>\<S>\<^sup>\<nat>?dy" "?dx*\<^sub>\<S>\<^sup>\<nat>?dy"] a1  by mty auto
      hence "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (k/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy))= y" 
        using arytm_3_th_44[of ?dx ?nx] A1 A2  by mty auto
      thus ?thesis using arytm_3_def_13 bexI[of _ "k/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy)" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]    
        by mty auto
    next
      case False
      hence "?ny*\<^sub>\<S>\<^sup>\<nat>?dx c= ?nx*\<^sub>\<S>\<^sup>\<nat>?dy" using ordinal1_def_5c by mty auto
   then obtain k where [ty]:"k be Nat" and
         A3: "?nx*\<^sub>\<S>\<^sup>\<nat>?dy = ?ny*\<^sub>\<S>\<^sup>\<nat>?dx+\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by mty auto
      hence "(?ny*\<^sub>\<S>\<^sup>\<nat>?dx+\<^sub>\<S>\<^sup>\<nat> k)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy) = x" using A2 AA by mauto
      hence "((?dx*\<^sub>\<S>\<^sup>\<nat>?ny)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (k/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy))= x" 
        using Mult_6[of ?dx ?ny]arytm_3_th_47[of k "?ny*\<^sub>\<S>\<^sup>\<nat>?dx" "?dx*\<^sub>\<S>\<^sup>\<nat>?dy"] a1  by mty auto
      hence "y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>  (k/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy))= x" 
        using arytm_3_th_44s[of ?dy ?ny] A1 A2  by mty auto
      thus ?thesis using arytm_3_def_13 bexI[of _ "k/\<^bsub>\<rat>\<ge>0\<^bsup>(?dx*\<^sub>\<S>\<^sup>\<nat>?dy)" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]    
        by mty auto
    qed
  qed

mtheorem arytm_3_def_13r:
  "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" 
proof
  show  "ex y st x = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using  arytm_3_th_50[of x] bexI[of _ "{}" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] 
    by mty auto
qed mauto
                           
abbreviation lessR ("_ <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> _" [51,50] 50) where
  "y <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x \<equiv> \<not> x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"     

reserve r,s,t for "Element-of RAT\<^bsup>\<ge>0\<^bsub>"

theorem arytm_3_th_61:
   "y be object \<Longrightarrow> \<not>[{},y] in RAT\<^bsup>\<ge>0\<^bsub>"
proof(standard)
  assume [ty]:"y be object" and A1: "[{},y] in RAT\<^bsup>\<ge>0\<^bsub>"
  then obtain i j where  [ty]:"i be Nat" "j be Nat" and 
       A2: "[{} , y] =\<^sub>\<S> [i , j] \<and> i , j are-coprime \<and> j \<noteq> {} \<and> j \<noteq> succ {}"
    using arytm_3_th_29[of "[{},y]"] arytm_3_th_32 Element(6) by mty auto
  hence "i={}" using xtuple_0_th_1a by mauto 
  thus False using arytm_3_th_3[of j] A2 by mty auto
qed

mtheorem arytm_3_th_62:
  "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies s = r"
proof
  assume
A1: "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  obtain r1 r2 where 
     R: "r1 =  numerator(r)" "r2 = denominator(r)" by auto
  obtain t1 t2 where
     T: "t1 =  numerator(t)" "t2 = denominator(t)" by auto
  obtain s1 s2 where
     S: "s1 =  numerator(s)" "s2 = denominator(s)" by auto
  have [ty]: "s1 is Nat" "s2 is Nat" "t1 is Nat" "t2 is Nat" 
       "r1 is Nat" "r2 is Nat" using S T R by mauto
  have A2: "t2 <> {}" using T arytm_3_th_35 by mty auto
  have A3: "s2 <> {}" using S arytm_3_th_35 by mty auto
  hence
A4: "s2*\<^sub>\<S>\<^sup>\<nat>t2 <> {}" using A2 Mult_9[of t2 s2] S T by mty auto
  have
A5: "r2 <> {}" using R arytm_3_th_35 by mauto
  hence "r2*\<^sub>\<S>\<^sup>\<nat>t2 <> {}" using  A2 Mult_9[of t2 r2] T R by mty auto
  thm arytm_3_th_45
  hence "(s1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>t1*\<^sub>\<S>\<^sup>\<nat>s2)*\<^sub>\<S>\<^sup>\<nat>(r2*\<^sub>\<S>\<^sup>\<nat>t2) = (s2*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>(r1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>t1*\<^sub>\<S>\<^sup>\<nat>r2)"
    using A1 A4 arytm_3_th_45[of "r1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>t1*\<^sub>\<S>\<^sup>\<nat>r2" "s1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>t1*\<^sub>\<S>\<^sup>\<nat>s2" "r2*\<^sub>\<S>\<^sup>\<nat>t2" "s2*\<^sub>\<S>\<^sup>\<nat>t2"] 
    arytm_3_def_11[of s t]  arytm_3_def_11[of r t] S T R by mauto
  hence "(s1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>s2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>(r2*\<^sub>\<S>\<^sup>\<nat>t2) = ((r1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>r2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>s2)*\<^sub>\<S>\<^sup>\<nat>t2"
    using Mult_6[of "s2*\<^sub>\<S>\<^sup>\<nat>t2" "r1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>t1*\<^sub>\<S>\<^sup>\<nat>r2"] Mult_13[of t2 s2] 
          Mult_6[of t1 s2] Mult_6[of t1 r2] ty by mty auto                             
  hence "((s1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>s2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>r2)*\<^sub>\<S>\<^sup>\<nat>t2 = ((r1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>r2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>s2)*\<^sub>\<S>\<^sup>\<nat>t2" 
    using Mult_13[of t2 r2] by mauto     
  hence "(s1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>s2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>r2 = (r1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>r2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>s2" 
     using A2 Mult_15s[of _ _ t2] by mty auto
  hence  "(s1*\<^sub>\<S>\<^sup>\<nat>t2+\<^sub>\<S>\<^sup>\<nat>s2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>r2 = (r1*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>s2+\<^sub>\<S>\<^sup>\<nat>(r2*\<^sub>\<S>\<^sup>\<nat>t1)*\<^sub>\<S>\<^sup>\<nat>s2" using Mult_11s by mty auto
  hence  "(s1*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>r2+\<^sub>\<S>\<^sup>\<nat>r2 *\<^sub>\<S>\<^sup>\<nat> (s2*\<^sub>\<S>\<^sup>\<nat>t1) = (r1*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>s2+\<^sub>\<S>\<^sup>\<nat>r2*\<^sub>\<S>\<^sup>\<nat>(s2*\<^sub>\<S>\<^sup>\<nat>t1)" using 
          Mult_11s[of "s2*\<^sub>\<S>\<^sup>\<nat>t1" r2 "s1*\<^sub>\<S>\<^sup>\<nat>t2"] Mult_13[of s2 t1 r2] Mult_6[of t1 s2]
         Mult_6[of "s2*\<^sub>\<S>\<^sup>\<nat>t1" r2]  by mty auto
  hence "(s1*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>r2 = (r1*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>s2" using Add_11s[of "(r1*\<^sub>\<S>\<^sup>\<nat>t2)*\<^sub>\<S>\<^sup>\<nat>s2" "r2*\<^sub>\<S>\<^sup>\<nat>(s2*\<^sub>\<S>\<^sup>\<nat>t1)"] 
    by mty auto
  hence "(t2*\<^sub>\<S>\<^sup>\<nat>s1)*\<^sub>\<S>\<^sup>\<nat>r2 = (t2*\<^sub>\<S>\<^sup>\<nat>r1)*\<^sub>\<S>\<^sup>\<nat>s2" using Mult_6[of s1 t2] Mult_6[of r1 t2] 
    by mty auto
  hence "t2*\<^sub>\<S>\<^sup>\<nat>(s1*\<^sub>\<S>\<^sup>\<nat>r2) = t2*\<^sub>\<S>\<^sup>\<nat>(r1*\<^sub>\<S>\<^sup>\<nat>s2)" using Mult_13 by mty auto 
  hence "s1*\<^sub>\<S>\<^sup>\<nat>r2 = r1*\<^sub>\<S>\<^sup>\<nat>s2" using A2 Mult_15[of _ _ t2] by mty auto
  hence "s1/\<^bsub>\<rat>\<ge>0\<^bsup>s2 = r1/\<^bsub>\<rat>\<ge>0\<^bsup>r2" using A3 A5 arytm_3_th_45[of r1 s1 r2 s2] Mult_6[of r1 s2]by mty auto
  thus "s=r" using S R  arytm_3_th_39 by mty auto
qed

mtheorem arytm_3_th_62s:
  "t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r implies s = r" using arytm_3_th_62[of r t s] arytm_3_def_11c[of t s] 
  arytm_3_def_11c[of r t] by auto 

mtheorem  arytm_3_th_63:
  "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = {} implies r = {}"
proof
  obtain r1 r2 where 
     R: "r1 =  numerator(r)" "r2 = denominator(r)" by auto
  obtain s1 s2 where           
     S: "s1 =  numerator(s)" "s2 = denominator(s)" by auto
  have [ty]: "s1 is Nat" "s2 is Nat"  
       "r1 is Nat" "r2 is Nat" using S R by mauto
  assume
A1: "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s = {}"
  have "denominator({}) = succ {} & numerator({}) = {}" using arytm_3_def_8 arytm_3_def_9
     ordinal1_def_11 by mty auto
  hence
A2: "(r1*\<^sub>\<S>\<^sup>\<nat>s2+\<^sub>\<S>\<^sup>\<nat>s1*\<^sub>\<S>\<^sup>\<nat>r2)/\<^bsub>\<rat>\<ge>0\<^bsup>(r2*\<^sub>\<S>\<^sup>\<nat>s2) = {}/\<^bsub>\<rat>\<ge>0\<^bsup> succ{}" using A1 arytm_3_th_39[of "{}"]
    arytm_3_def_11 R S by mty auto
    have
A3: "s2 <> {}" using arytm_3_th_35 S by mauto
    have "r2 <> {}" using arytm_3_th_35 R by mauto
  hence "r2*\<^sub>\<S>\<^sup>\<nat>s2 <> {}"  using A3 Mult_9[of s2] by mauto
  hence "(r1*\<^sub>\<S>\<^sup>\<nat>s2+\<^sub>\<S>\<^sup>\<nat>s1*\<^sub>\<S>\<^sup>\<nat>r2)*\<^sub>\<S>\<^sup>\<nat>succ {} = (r2*\<^sub>\<S>\<^sup>\<nat>s2)*\<^sub>\<S>\<^sup>\<nat>{}"
     using A2 arytm_3_th_45 by mty auto 
  hence "r1*\<^sub>\<S>\<^sup>\<nat>s2+\<^sub>\<S>\<^sup>\<nat>s1*\<^sub>\<S>\<^sup>\<nat>r2 = {}" using Mult_2 Mult_5 by mauto
  hence "r1*\<^sub>\<S>\<^sup>\<nat>s2 = {}" using Add_14[of _ "r1*\<^sub>\<S>\<^sup>\<nat>s2"] by mauto
  hence "r1 = {}" using A3 Mult_9[of s2 r1] by mauto
  thus "r={}" using  arytm_3_th_37[of r] R by mauto
qed

mtheorem arytm_3_def_13l:
  "x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y  iff (ex z st x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z \<noteq>{})"
proof
  assume AS: "x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  hence "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_3_def_13c[of x y] by auto
  then obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
    A1: "y = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_def_13 by mauto
  have "z <>{}" using arytm_3_th_50[of x] arytm_3_def_13r[of x] A1 AS by mauto
  thus "ex z st x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z \<noteq>{}" using A1 bexI[of _ z "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
next
  assume "ex z st x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z \<noteq>{}"
  then obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A2:"x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z = y & z <>{}" by mauto
  show "x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"
  proof
    assume "y \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x"
    then obtain w where [ty]:"w is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      A3: "x = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> w" using arytm_3_def_13[of y x] by mauto
    hence "y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (w +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z) = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using A2 arytm_3_th_51[of z w y] arytm_3_th_50[of y] by simp
    hence "w+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z = {}" using arytm_3_th_62s[of "{}" "w+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z" y] by mauto
    hence "z={}" using arytm_3_th_63 arytm_3_def_11c[of w z] by mauto 
    thus False using A2 by simp
  qed
qed


mtheorem arytm_3_th_64:
  "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
proof(standard)
  show "\<exists>z : Element-of RAT\<^bsup>\<ge>0\<^bsub>. s =\<^sub>\<S> {} +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_th_50[of s]
   arytm_3_def_11c[of "{}"]  bexI[of _ s "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] 
    by mauto
qed mauto

mtheorem arytm_3_th_65:
  "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} implies s = {}"
proof
  assume "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}"
  hence "ex z st {} = s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z " using arytm_3_def_13[of s "{}"] by mauto
  thus "s={}" using arytm_3_th_63 by mty auto
qed

mtheorem arytm_3_th_66:
  "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r implies r = s"
proof
  assume AS: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  then obtain x where [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
    A1: "s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13[of r s] by mty auto
  obtain y where [ty]:"y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
    A2: "r = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using AS arytm_3_def_13 by mty auto
  have "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = r" using arytm_3_th_50 arytm_3_def_11c by mty auto 
  also have "... =  (r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using A1 A2  by auto 
  also have "... = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y)" using arytm_3_th_51[of y x r] by auto
  finally have "{} =x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using arytm_3_th_62s[of "{}" "x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y"] by mauto
  hence "x={}" using arytm_3_th_63[of y x] by mauto 
  thus "r=s" using A1 arytm_3_th_50[of r] by mauto
qed

mtheorem arytm_3_th_67:
  "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
proof
  assume AS: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  then obtain x where [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
    A1: "s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13[of r s] by mty auto
  obtain y where [ty]:"y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and 
    A2: "t = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" using AS arytm_3_def_13 by mty auto
  hence "t = r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y)" using A1 arytm_3_th_51[of y x r] by mty  auto
  thus "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13[of r t] bexI[of _ "x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" ] by mty auto
qed

mtheorem arytm_3_th_68:
  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s iff r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r <> s" 
using  arytm_3_th_66 arytm_3_def_13c[of r s] by auto

mtheorem arytm_3_th_68i:
  "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s \<and> t<>{} implies r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
proof
  assume "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s \<and> t<>{}"
  thus "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_13l bexI[of _ t] by mauto
qed


mtheorem arytm_3_th_69:
  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t or r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  using arytm_3_th_67 arytm_3_def_13c ty by blast

mtheorem arytm_3_th_70:
  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" 
   using arytm_3_th_67 arytm_3_def_13c ty by blast

mtheorem arytm_3_th_71:
  "x in NAT & x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y in NAT implies y in NAT"
proof
  assume AS:"x in NAT & x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y in NAT"
  hence [ty]: "x is Nat & x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y is Nat" using ordinal1_def_12 by mauto
  show "y in NAT"
  proof(cases "x c= x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y")
    case True
    then obtain k where [ty]:"k is Nat" and
      A1: "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^sup>\<nat> k" using Add_9[of "x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y" x] by mty auto
    hence "x +\<^sub>\<S>\<^sup>\<nat> k = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" using arytm_3_th_58[of k x] by mty auto
    hence "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" using A1 by simp
    hence "y=k" using arytm_3_th_62s[of k y x] by mty auto
    thus "y in NAT" using ordinal1_def_12[of k] by mty auto
  next
    case False
      hence "x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y c= x" using ordinal1_def_5c by mauto
      then obtain k where [ty]:"k is Nat" and
      A1: "x= x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y +\<^sub>\<S>\<^sup>\<nat> k" using Add_9[of x "x+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y"] by mty auto
      have "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y +\<^sub>\<S>\<^sup>\<nat> k = (x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" using arytm_3_th_58 by mauto
      hence "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k)" using  arytm_3_th_51[of k y x] arytm_3_th_50[of x] A1 
        by mauto
      hence "{} = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" using arytm_3_th_62s[of "y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> k" "{}" x] by mty auto
      hence "y={}" using arytm_3_th_63[of k y] by mty auto
      thus "y in NAT" using ordinal1_def_11 by mty auto
  qed
qed

mtheorem arytm_3_th_72:
   "i <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x & x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> \<longrightarrow> not x in NAT"
proof(standard, rule ccontr)
  assume
A1: "i <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x \<and>x <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> i+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>1\<^sub>\<S>" and
A3: "\<not>\<not>x in NAT"
  obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z \<and> z<>{}" using A1 arytm_3_def_13l[of x "i+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>1\<^sub>\<S>"] by mauto
  have "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> = i+\<^sub>\<S>\<^sup>\<nat>1\<^sub>\<S>" using arytm_3_th_58 by mauto
  hence "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> in NAT" using ordinal1_def_12[of "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>"] by mauto
  hence "z in NAT" using A3 A4 arytm_3_th_71[of "z" x]  by auto
  hence [ty]: "z is Nat" using ordinal1_def_12 by mauto
  obtain y where [ty]:"y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A5: "x = i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> y & y <>{}" using A1 arytm_3_def_13l[of i x] by mauto
  have "i in NAT" using ordinal1_def_12[of i] by auto
  hence "y in NAT" using  A3 A5 arytm_3_th_71[of y i] by mauto
  hence [ty]:"y is Nat" using ordinal1_def_12 by auto
  have "i +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S> = i+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>(y+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z)" using  A5 A4 arytm_3_th_51[of z y i] by auto
  hence "1\<^sub>\<S> = y +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_th_62s[of "y+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z" "1\<^sub>\<S>" i] by mauto
  hence "y +\<^sub>\<S>\<^sup>\<nat> z c= y" "y c= y +\<^sub>\<S>\<^sup>\<nat> z" 
     using one2[of y] A5 arytm_3_th_58[of z y] Add_10 by auto 
  hence "y +\<^sub>\<S>\<^sup>\<nat> z = y+\<^sub>\<S>\<^sup>\<nat> {}" using xboole_0_def_10I all_set Add_3[of y,simplified] by mty auto
  thus False using Add_11[of "{}" z y] A4 by mauto
qed

mtheorem arytm_3_th_73:
  "t <> {} implies (ex r st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & not r in NAT)"
proof
  assume A1: "t <> {}"
  have A2:  "1\<^sub>\<S> +\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> = succ 1\<^sub>\<S>" using Add_3[of "1\<^sub>\<S>" ] Add_1 by mauto
  show "ex r st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & not r in NAT"
  proof(cases "1\<^sub>\<S> \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t")
    case  A3: True
    obtain r where [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "1\<^sub>\<S> = r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>r" using  arytm_3_th_60[of "1\<^sub>\<S>"] by mauto
    have B: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using  A4 arytm_3_def_13[of r "1\<^sub>\<S>"] bexI[of _ r] by mty auto
    have "r <> 1\<^sub>\<S>" using A2 A4 arytm_3_th_58 by mty auto
    hence "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using B arytm_3_th_66 by mty auto
    hence T: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using  A3 arytm_3_th_69[of t r "succ {}"] by mty auto
    have  A5: "1\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> 1\<^sub>\<S> = 1\<^sub>\<S>" using Mult_5 by mauto
  have "\<not> r in NAT"
  proof
    assume E: "r in NAT"
    hence A6: "denominator(r) = 1\<^sub>\<S>" using arytm_3_def_9 by mauto
    hence "numerator(r)*\<^sub>\<S>\<^sup>\<nat>denominator(r) = numerator(r)" using Mult_5 by mauto
    hence "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r = (numerator(r)+\<^sub>\<S>\<^sup>\<nat>numerator(r))/\<^bsub>\<rat>\<ge>0\<^bsup> (1\<^sub>\<S>)"
      using A6 arytm_3_def_11[of r r] A5 by mauto
    hence
A7: "1\<^sub>\<S> = numerator(r)+\<^sub>\<S>\<^sup>\<nat>numerator(r)" using A4 A5 arytm_3_th_40[of "numerator(r)+\<^sub>\<S>\<^sup>\<nat>numerator(r)" "{}"] by  mty auto
    hence A: "numerator(r) c= 1\<^sub>\<S>" using Add_10 by mauto
    have [ty]:"r is Nat" using ordinal1_def_12 E  by mauto
    hence "r<>{}" using A4 arytm_3_th_50[of r] by auto
    hence "numerator(r) <> {}" using arytm_3_th_37 by mauto
    hence "1\<^sub>\<S> c= numerator(r)" using one2 by mauto
    hence "1\<^sub>\<S> = numerator(r)" using A xboole_0_def_10I all_set  by auto
    hence "1\<^sub>\<S> = succ 1\<^sub>\<S>" using A7 A2 by auto
    thus False by auto 
  qed
  thus "ex r st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & not r in NAT" using T bexI[of _ r ] by auto
next
  case A8: False
    obtain r where [ty]: "r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
    A9: "t = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_60 by mauto
    have A10: "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_64 by mauto
    have R: "r <> {}" using  A1 A9 arytm_3_th_50 by mauto
    hence
A11: "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A10 arytm_3_th_66 by mauto

  have A12: "1\<^sub>\<S> = {} +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using arytm_3_th_50[of "succ {}"] arytm_3_def_11c[of "{}"] by mauto
  have A13: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A9 arytm_3_def_13[of r t] bexI[of _ r "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mauto 
  have "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r = t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {}" using A9 arytm_3_th_50[of t] by mauto
  hence "r <>t" using A9 arytm_3_th_62s[of "{}" t t] R by mty auto
  hence S: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using  A13 arytm_3_th_66 by mauto
  have  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> 1\<^sub>\<S>" using  A8 A13 arytm_3_th_69[of "succ {}" r t] by mty auto
  hence "not r in NAT" using A11 A12 arytm_3_th_72[of "{}" r] by auto
  thus "ex r st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & not r in NAT" using S bexI[of _ r ] by auto
qed
qed

mtheorem arytm_3_th_74:
  "{s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t} in RAT\<^bsup>\<ge>0\<^bsub> iff t = {}"
proof
  let ?H="{s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t}"
  assume A1a:"?H in RAT\<^bsup>\<ge>0\<^bsub>"
  hence [ty]:"?H is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by auto
  show "t={}"
  proof(rule ccontr)
    assume A1b:"t<>{}"
    then obtain r where [ty]:"r is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<and> not r in NAT" using arytm_3_th_73 by mauto
    have "{} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_64 by auto
    hence "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A1b arytm_3_th_66 by auto
    hence A4: "{} in ?H" using Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" "{}"] by auto
    have "r in ?H" using A2 Fraenkel_A1_in[of "Element-of RAT\<^bsup>\<ge>0\<^bsub>" r]
      by mty auto
    hence "\<not> ?H in NAT" using A2 all_set ordinal1_th_6[of ?H r NAT] by mauto 
    then obtain i j where "i is Nat" "j is Nat" and 
      "?H = [i,j] & i,j are-coprime & j <> {} & j <> succ{}" using  
       A1a A2 arytm_3_th_29[of ?H] by mauto
    hence "{} = {i} or {} = {i,j}" using A4 tarski_def_5 tarski_def_2 by auto
    thus False using tarski_def_1[of i i] tarski_def_2[of i j i] xb by auto
  qed
next
  let ?H="{s where s be Element-of RAT\<^bsup>\<ge>0\<^bsub>: s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t}"
  assume A5: "t = {}"
  have "?H = {}"
proof(rule ccontr)
  assume "?H<>{}"
   hence "?H is non empty" using xboole_0_lm_1[of ?H] xboole_0_def_1 by mauto
   then obtain x where
    A6:"x be object ""  x in ?H" using xboole_0_def_1 by mauto
   obtain y where [ty]: "y be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
      and " x =\<^sub>\<S> y \<and> y <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using Fraenkel_A1_ex[OF _ _ A6(2)] by auto
   thus False using A5 arytm_3_th_64[of y] by auto
 qed 
  hence "?H is Element-of RAT\<^bsup>\<ge>0\<^bsub>" by mty auto
  thus "?H in RAT\<^bsup>\<ge>0\<^bsub>" using Element(7) by mty auto 
qed



mtheorem arytm_3_th_75:
  "for A be Subset-of RAT\<^bsup>\<ge>0\<^bsub> st 
     (ex t st t in A & t <> {}) & 
      (for r,s st r in A & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A) 
   holds
   ex r1,r2,r3 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r1 in A & r2
  in A & r3 in A & r1 <> r2 & r2 <> r3 & r3 <> r1"
proof(standard,standard)
  fix A assume [ty]:"A be Subset-of RAT\<^bsup>\<ge>0\<^bsub>"
  and AS:" (ex t st t in A & t <> {}) & 
      (for r,s st r in A & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r holds s in A)"  
  obtain t where [ty]:"t be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "t in A" and
A2: "t <> {}" using AS by auto
  obtain x where [ty]:"x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "t = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_60 by mauto
  have "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13I[of x t] bexI[of _ x] A4 by mauto
  hence T1: "{} in A" "x in A" "t in A" using A1 AS[THEN conjunct2,THEN bspec,of t ] A1 arytm_3_th_64[of t] by mauto
  have T2: "{} <> x" using A2 A4 arytm_3_th_50 by mauto
  have "x <> t"
  proof
    assume "x = t"
    hence "t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>{} = t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t" using A4 arytm_3_th_50 by mauto
    thus False using A2 arytm_3_th_62s[of t "{}"t] by mauto
  qed
  thus "ex r1,r2,r3 be Element-of RAT\<^bsup>\<ge>0\<^bsub> st r1 in A & r2
  in A & r3 in A & r1 <> r2 & r2 <> r3 & r3 <> r1" using T1 T2 A2 bexI[of _ x "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]
      bexI[of _ "{}" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] bexI[of _t "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
qed mauto

mtheorem arytm_3_th_76:
  "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t iff s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
proof(rule iffI3)
  show "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  proof
    assume "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
    then obtain z where [ty]:"z is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t = (s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z" using arytm_3_def_13 by auto

    have "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t = (s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using  A1 arytm_3_th_51[of z t s] arytm_3_def_11c[of t z]
         arytm_3_th_51[of t z s] by auto
    hence "r = s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_th_62[of "s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" t] by mty auto
    thus "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_def_13I[of s r] bexI[of _ z] by mauto
  qed
next
  assume "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  then obtain z where [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "r = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_def_13E[of s r] by mauto
  hence "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t = (s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t)+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>z" using arytm_3_th_51[of z t s] arytm_3_def_11c[of t z]
         arytm_3_th_51[of t z s] by auto
  thus "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using  arytm_3_def_13I[of "s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] bexI[of _ z] by mauto
qed

mtheorem arytm_3_th_77:
  "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13I[of s "s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t"] bexI[of _ t] by mauto 

mtheorem arytm_3_th_78:
  "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = {} implies r = {} or s = {}"
proof
  let ?nr = "numerator(r)" let ?dr = "denominator(r)"
  let ?ns = "numerator(s)" let ?ds = "denominator(s)"
  assume
A1: " r*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = {}"
  have "?dr <> {} & ?ds <> {}" using arytm_3_th_35 by auto
  hence
A2: "?dr*\<^sub>\<S>\<^sup>\<nat>?ds <> {}" using Mult_9[of ?ds ?dr] by mauto
  have "denominator({}) = succ {} & numerator({}) = {}" using
     arytm_3_def_8[of "{}"] arytm_3_def_9[of "{}"] 
     ordinal1_def_11 by mauto
  hence "(?nr*\<^sub>\<S>\<^sup>\<nat>?ns)/\<^bsub>\<rat>\<ge>0\<^bsup>(?dr*\<^sub>\<S>\<^sup>\<nat>?ds) = {}/\<^bsub>\<rat>\<ge>0\<^bsup>succ {}"
    using A1  arytm_3_th_39 arytm_3_def_12[of r s] by mauto
  hence "(?nr*\<^sub>\<S>\<^sup>\<nat>?ns)*\<^sub>\<S>\<^sup>\<nat>succ {} = (?dr*\<^sub>\<S>\<^sup>\<nat>?ds)*\<^sub>\<S>\<^sup>\<nat>{}"
    using A2 arytm_3_th_45[of "{}" "?nr*\<^sub>\<S>\<^sup>\<nat>?ns" "succ {}" 
    "?dr*\<^sub>\<S>\<^sup>\<nat>?ds"] by mauto
  hence "(?nr*\<^sub>\<S>\<^sup>\<nat>?ns)*\<^sub>\<S>\<^sup>\<nat>succ {}  = {}" using  Mult_2 by mauto
  hence "?nr*\<^sub>\<S>\<^sup>\<nat>?ns = {}" using Mult_9 by mauto
  hence "?nr = {} or ?ns = {}" using Mult_9 by mauto
  thus "r={} or s={}" using arytm_3_th_37 by auto
qed

mtheorem arytm_3_th_79:
  "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies (ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> 
      st r = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
proof
  assume "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  then obtain x where [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x" using arytm_3_def_13E[of r] by mauto
  show "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> 
      st r = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  proof(cases "s={}")
  case A2: True   
    hence "s*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t = {}" using arytm_3_th_48[of t] 
       arytm_3_def_12c[of s t] by mauto
    thus "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> 
      st r = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using 
       A1 arytm_3_th_63[of x r] bexI[of _ t "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]
        arytm_3_def_13r[of t] by auto
  next
    case A3:False
    then obtain t1 where [ty]:"t1 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A4: "x = s*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t1" using arytm_3_th_55[of x s] by mauto
    obtain t0 where [ty]:"t0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A5: "r = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using A3 arytm_3_th_55[of r s] by mauto
    have "r = s*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t0" using A5 by mauto
    have "s*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (t0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1)" using 
     A1 A5 A4 arytm_3_th_57[of t1 t0 s] by mauto
    hence "t = t0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" using  A3 arytm_3_th_56[of _ t s] 
      by mauto
    hence "t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13I[of t0 t] bexI[of _ t1] 
      by mauto
    thus "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> 
      st r = s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using 
       A5 bexI[of _ t0 "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mauto
    qed
qed

mtheorem arytm_3_th_80:
  "t <> {} & s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
proof
  assume A1: "t <> {} & s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  then obtain x where [ty]:"x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      A2: " s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x & x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using 
    arytm_3_th_79[of r t  "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t"] arytm_3_def_12c[of r t]
    by mty auto
  hence "s=x" using  arytm_3_th_56[of x s t] 
    arytm_3_def_12c[of s t] A1 by mty auto
  thus "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using A2 by mauto
qed

mtheorem arytm_3_th_81:
  "for r1,r2,s1,s2 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st r1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>r2 = s1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s2 holds r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1
  or r2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2"
proof(intro ballI impI,rule ccontr)
  fix r1 r2 s1 s2 assume [ty]: "r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
    "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "r1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2 =\<^sub>\<S> s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2" "\<not> (r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1  \<or> r2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2 )"
  hence "s1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s2"
     using arytm_3_th_76[of s1 _ r1] by mauto
   hence "r2+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>r1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>r1" using arytm_3_def_11c[of r1 s2] 
   arytm_3_def_11c[of r1 r2]  A1 by mauto
   hence "r2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2" using arytm_3_th_76[of r2 _ s2] by mauto
   thus False  using A1 arytm_3_th_68[of r2 s2] by mauto
 qed mauto

mtheorem arytm_3_th_82:
  "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r implies s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
proof
  assume "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
  then obtain x where [ty]: "x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "r = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13E[of s r] by mauto
  hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = (s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (t*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x)" using arytm_3_th_57[of x s t] arytm_3_def_12c[of t r]
    arytm_3_def_12c[of t s] by mauto
  thus "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13I[of "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] bexI[of _ "t*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>x"] by mauto
qed

mtheorem arytm_3_th_82B:
  "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x implies s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof
  assume "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
  hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_82  by mty auto
  hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_12c[of r t]
     arytm_3_def_12c[of x r] by mty auto
  thus "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_67[of "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mty auto
qed

mtheorem arytm_3_th_82e:
  "t<>{} \<and> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r implies s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
proof(rule impI, rule ccontr)
  assume A1: "t<>{} \<and> s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "\<not> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_82[of t r s] 
      arytm_3_th_68[of s r] by mauto 
  hence "t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r = t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_th_66 arytm_3_def_12c[of r t] 
       arytm_3_def_12c[of s t]by mauto
  hence "r  = s " using arytm_3_th_56[of s r] A1 by mauto
  thus False using A1 arytm_3_th_68 by mauto
qed

mtheorem arytm_3_th_82Be:
  "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x & {}<> r implies s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x"
proof
  assume "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x & {} <>r "
  hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "t *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_82 arytm_3_th_82e  by mty auto
  hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_12c[of r t]
     arytm_3_def_12c[of x r] by mty auto
  thus "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_69[of "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] by mty auto
qed


mtheorem arytm_3_th_82f:
  "t<>{} \<and>  s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies s = r"
proof
  assume T: "t<>{} \<and>  s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13r by auto
  hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_th_82e[of s r t]  arytm_3_th_82e[of r s t] T by mty auto
  thus "s=r" using arytm_3_th_66 by mty auto
qed

mtheorem arytm_3_th_80e:
  "t <> {} & s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r"
proof
  assume T:  "t <> {} & s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  hence "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t <> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_68 by mty auto
  hence "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "s <> r"  using arytm_3_th_80[of r s t] T by mty auto
  thus "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_68 by mty auto 
qed



mtheorem arytm_3_th_83:
  "for r1,r2,s1,s2 be Element-of RAT\<^bsup>\<ge>0\<^bsub> holds 
    r1*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>r2 = s1*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s2 implies r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 or r2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2"
proof(intro ballI impI,rule ccontr)
  fix r1 r2 s1 s2 assume [ty]: "r1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "r2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
   "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "s2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A1: "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2 = s1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2" and "\<not> (r1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s1 or r2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2)"
  hence A3: "s1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" and A4: "s2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2" by auto
  have S2: "s2 <>{}"
  proof
    assume "s2={}"
    hence "r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r2 = {}" using A1 arytm_3_th_48 by mauto
    hence "r1={} or r2={}" using arytm_3_th_78 by mauto
    thus "False" using A3 A4 arytm_3_th_64 by mauto
  qed  
  have B1: "s1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2" using
    A3 S2 arytm_3_th_82e[of s1 r1] by mauto
  hence "r2 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2 *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r1" using
  A1 arytm_3_def_12c[of r1] by mauto
  hence "r2 <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2" using arytm_3_th_82[of r1 r2 s2] by auto 
  thus False using A4 arytm_3_th_68 by mauto
qed mauto

mtheorem arytm_3_th_84:
  "r = {} iff r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s = s"
proof-
  have "{}+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>s = s" using arytm_3_th_50 arytm_3_def_11c[of s] by mauto
  thus ?thesis using arytm_3_th_62[of "{}" s] by mauto
qed

mtheorem arytm_3_th_85:
  "for s1,t1,s2,t2 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
   s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1 = s2 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t2 & s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2
  holds t2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1"
proof(intro ballI impI)
  fix s1 t1 s2 t2 assume [ty]: "s1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t1 be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
 "s2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>" "t2 be Element-of RAT\<^bsup>\<ge>0\<^bsub>"
and
A1: "s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1 = s2 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t2\<and>s1 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s2"
  then obtain x where [ty]: "x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "s2 = s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13E[of s1 s2] by mauto
  
  have "s1+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>t1 = s1 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t2)" using A1 A2 arytm_3_th_51[of t2 x s1] by mauto
  hence "t1 = x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t2"  using arytm_3_th_62s[of _ t1 s1] by mauto
  thus "t2 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t1" using arytm_3_def_13[of t2 t1] bexI[of _ x] arytm_3_def_11c[of x t2] 
    by mauto 
qed mauto

mtheorem arytm_3_th_86:
  "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies (ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
proof
  assume AS: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  then obtain x where [ty]:"x be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
     A1: "s = r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13E[of r s] by mauto
  hence "x +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using AS arytm_3_def_11c[of x r] arytm_3_def_11c[of t r] by mauto 
  hence "x \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using AS A1 arytm_3_th_76[of t r x ] by mauto
  thus "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using bexI[of _ x] A1 by mauto
qed

mtheorem arytm_3_th_87:
  "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies (ex s0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st r = s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
proof
  assume
A1: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  show "ex s0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st r = s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  proof(cases "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r") 
    case T: True 
    then obtain t0 where [ty]:"t0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
      A2: "r = s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A1 arytm_3_th_86[of t r s] by mauto
    have "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_13r by auto
    thus "ex s0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st r = s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
      using A2 bexI[of _ t0 ] bexI[of _ s ] by mauto 
  next
    case F: False
    hence A2: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_th_68 by mauto

    have "r = r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>{} & {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using 
     arytm_3_th_50 arytm_3_th_64 by mauto
    thus "ex s0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
      r = s0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & s0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
      using A2 bexI[of _ "{}" ] bexI[of _ r ] by mauto 
  qed
qed

mtheorem arytm_3_th_88: 
  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t implies 
     (ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
         t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0)"
proof
  assume AS: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"
  hence A1: "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" 
      using arytm_3_th_68 arytm_3_def_13r by mauto
  show "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
         t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0"
  proof(cases "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t")
    case True
       thus "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
         t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using 
         AS bexI[of _ s] A1 by mauto
     next case False 
       hence "t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_th_68 by mauto 
       thus "ex t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
         t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0" using 
         AS bexI[of _ t] A1 by mauto
     qed
qed

mtheorem arytm_3_th_89:
  "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s & s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & s <> t implies r <> t" using 
    arytm_3_th_66 by mauto

mtheorem arytm_3_th_90:
  "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <> {} implies 
  (ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
     s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t0 <> t)"
proof
  assume A1:  "s <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <> {}"
  show "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
     s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t0 <> t"
  proof(cases "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s")
    case True
    then obtain t0 where [ty]:"t0 is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using A1 
          arytm_3_th_86[of t s r]
       arytm_3_th_68[of s r]  arytm_3_th_68[of s "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t"] 
      by mauto
    have "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" "t0<>t"
      using A1 A3 arytm_3_def_13r[of r] arytm_3_th_68 by mauto
    thus "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
      s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t0 <> t"
      using A1 A3  bexI[of _ t0 "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]
        bexI[of _ r "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by auto             
  next
    case False
     hence A4: "s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_th_68 by mauto
     have "s = s+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>{} & {} \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" "{}<> t"
         using A1 arytm_3_th_50
      arytm_3_th_64 by mauto
     thus "ex r0,t0 being Element-of RAT\<^bsup>\<ge>0\<^bsub> st 
      s = r0 +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t0 & r0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r & t0 \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t0 <> t"
      using A1 A4  bexI[of _ "{}" "Element-of RAT\<^bsup>\<ge>0\<^bsub>"]
        bexI[of _ s "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mauto    
  qed
qed

mtheorem arytm_3_th_91:
  "for A be Subset-of RAT\<^bsup>\<ge>0\<^bsub> st 
    A<>{} & A in RAT\<^bsup>\<ge>0\<^bsub> (ex s st s in A & (for
  r st r in A holds r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s))"
proof(intro ballI impI)
  fix A assume [ty]: "A is Subset-of RAT\<^bsup>\<ge>0\<^bsub>"
 and AS: "A<>{} & A in RAT\<^bsup>\<ge>0\<^bsub>"
  hence [ty]: "A is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) by auto
  have N: "A in NAT"
  proof(rule ccontr)
    assume "not A in NAT"
    then obtain i j where [ty]: "i is Nat" "j is Nat"
      and 
      A2:"A =\<^sub>\<S> [i , j]" and A3:" i , j are-coprime" and 
     " j \<noteq> {} " and A4:" j \<noteq> succ {}"
      using arytm_3_th_29[of A] AS by mauto
    have A5: "not {i} in NAT"
    proof
      assume I: "{i} in NAT"
      hence [ty]:"{i} is Nat" and "i in {i}" using ordinal1_def_12 tarski_def_1[of i] by mauto
      hence "succ {} c= {i}" using one2[of "{i}"] xb by mauto
      hence "{} in {i}" using one1 by mauto
      hence "{} = i" using tarski_def_1 by auto
      thus False using A3 A4 arytm_3_th_3 by mauto
    qed
    have "{i} in A" "A c= RAT\<^bsup>\<ge>0\<^bsub>" using A2 tarski_def_2 tarski_def_5[of i j] Subset_in_rule 
       by mauto
    hence [ty]:"{i} is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) tarski_def_3 by mauto
    obtain i1 j1 where [ty]: "i1 is Nat" "j1 is Nat"
      and 
      A6:"{i} =\<^sub>\<S> [i1 , j1]" and A7:" i1 , j1 are-coprime" and 
     " j1 \<noteq> {} " and A8:" j1 \<noteq> succ {}"
      using arytm_3_th_29[of "{i}"] A5 by mauto
  
    have "{i1,j1} in {i}" using A6 tarski_def_2 tarski_def_5[of i1 j1] by mauto
    hence
A9: "i = {i1,j1}" using tarski_def_1 by mauto
    have "{i1} in {i}" using A6 A2 tarski_def_2 tarski_def_5[of i1 j1] by mauto
    hence "i = {i1}" using tarski_def_1 by mauto
    hence "j1 in {i1}" using A9 tarski_def_2[of i1 j1] by mauto
    hence "j1 = i1" "i1 hcf j1 = succ {}" using tarski_def_1 arytm_3_th_20 A7 by mauto
    thus False using A8 arytm_3_th_16[of j1] by mauto
  qed
  hence [ty]:"A is Element-of NAT" using all_set Element(6)[of NAT A] by mauto
  hence [ty]:"A is Nat" by mauto
  let ?C = "predecessor A" 
  have A12: "succ ?C = A" using AS NAT_1_5 by mauto
  hence B12: "?C in A"  "A c= RAT\<^bsup>\<ge>0\<^bsub>" using Subset_in_rule  using ordinal1_th_2 all_set by mauto
    hence [ty]:"?C is Element-of RAT\<^bsup>\<ge>0\<^bsub>" using Element(6) tarski_def_3 by mauto
  show "ex s st s in A & (for
  r st r in A holds r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
  proof(rule bexI[of _ ?C "Element-of RAT\<^bsup>\<ge>0\<^bsub>"],auto)  
    show "?C in A" using B12 by mauto
    fix r assume [ty]:"r be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A13: "r in A"
    hence "r in NAT" using N ordinal1_th_6[of A r  omega] by mauto
    hence [ty]:"r is Nat" using ordinal1_def_12  by mauto
    have "r c= ?C" using A13 A12 ordinal1_th_18[of "?C" r] by mauto
    then obtain x where [ty]: "x be Nat" and 
       X:"?C = r +\<^sub>\<S>\<^sup>\<nat> x" using Add_9[of ?C r] by mauto
    have "x in NAT" using ordinal1_def_12[of x] by mauto
    hence [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" 
     using arytm_3_def_7 xboole_0_def_3[of _ NAT] all_set by mauto 
   have "?C = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_th_58[of x] X by mauto
   thus "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?C" using arytm_3_def_13I[of r ?C] bexI[of _ x] by mauto
 qed
qed mauto

mtheorem arytm_3_th_92:
  "ex t st r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = s or s +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t = r"
proof-
  have "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s or s \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r" using arytm_3_def_13c by mauto
  thus ?thesis using arytm_3_def_13E by mauto
qed

mtheorem arytm_3_th_93:
  "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s implies (ex t st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s)"
proof
  assume
A1: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
  then obtain x where [ty]:"x is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A2: "s = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> x" using arytm_3_def_13c[of r s] arytm_3_def_13[of r s] by mauto
  obtain y where [ty]:"y is Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
A3: "x = y+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y" using arytm_3_th_60 by mauto
  let ?t = "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y"
  have A4: "s = ?t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y" using A2 A3 arytm_3_th_51[of y y r] by mauto
  hence A5: "?t \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using arytm_3_def_13I bexI[of _ y] by mauto
  have "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?t" using arytm_3_def_13I bexI[of _ y] by mauto
  hence T1: "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?t" using A1 A4 arytm_3_th_66 by mauto
  have "s<>?t"
  proof
    assume "s=?t"
    hence "?t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>y = ?t+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub>{}" using A4 arytm_3_th_50 by mauto
    hence "y={}" using arytm_3_th_62s[of "{}" y] by mauto
    hence "x={}" using A3  arytm_3_th_50  by mauto
    hence "r=s" using A2  arytm_3_th_50 by mauto
    thus False using A1 arytm_3_def_13r by mauto
  qed
  hence "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?t & ?t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using T1 A5 arytm_3_th_66 by mauto
  thus "ex t st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t & t <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" using bexI[of _ ?t] by mauto
qed

mtheorem arytm_3_th_94:
  "ex s st r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
proof-
  let ?s = "r+\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})"
  have "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> {} = r" using arytm_3_th_50 by mauto
  hence
A1: "r <> ?s" using arytm_3_th_62s[of "{}" _ r] by mauto
  have "r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s" using arytm_3_def_13I[of r ?s] bexI[of _ "succ {}"] by mauto
  hence "r <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s" using A1 arytm_3_th_66 by mauto
  thus ?thesis using bexI[of _ ?s] by mauto
qed 

mtheorem arytm_3_th_95:
  "t <> {} implies (ex s st s in omega & r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t)"
proof
have A1: "denominator(r) <> {}" using arytm_3_th_35 by mauto  
  let ?s = "denominator(t)*\<^sub>\<S>\<^sup>\<nat> numerator(r)"
  have [ty]:"?s is Nat" by mauto
  assume "t <> {}"
  hence "numerator(t) <> {}" using arytm_3_th_37 by mauto
  hence "{} <> numerator(t)*\<^sub>\<S>\<^sup>\<nat>denominator(r)" 
    using A1 Mult_9[of "denominator(r)" "numerator(t)"] by mauto 
  hence "succ {} c= numerator(t)*\<^sub>\<S>\<^sup>\<nat>denominator(r)" using one2 by mauto
  then obtain NtDr1 where [ty]:"NtDr1 be Nat" and
    "numerator(t)*\<^sub>\<S>\<^sup>\<nat>denominator(r) = succ {} +\<^sub>\<S>\<^sup>\<nat> NtDr1" using Add_9[of _ "succ {}"] by mauto
  hence "?s*\<^sub>\<S>\<^sup>\<nat>(numerator(t)*\<^sub>\<S>\<^sup>\<nat>denominator(r)) = 
      denominator(t)*\<^sub>\<S>\<^sup>\<nat> (numerator(r)*\<^sub>\<S>\<^sup>\<nat>(succ {} +\<^sub>\<S>\<^sup>\<nat>(NtDr1)))" 
     using Mult_13[of _ "numerator(r)" "denominator(t)"] by mauto
   also have "... = denominator(t)*\<^sub>\<S>\<^sup>\<nat> (numerator(r)*\<^sub>\<S>\<^sup>\<nat>(succ {}) +\<^sub>\<S>\<^sup>\<nat>
(numerator(r)*\<^sub>\<S>\<^sup>\<nat> NtDr1))" using Mult_11[of NtDr1 "succ{}"] by mauto
   finally have A2:"(?s *\<^sub>\<S>\<^sup>\<nat> numerator(t))*\<^sub>\<S>\<^sup>\<nat>denominator(r) = 
      denominator(t) *\<^sub>\<S>\<^sup>\<nat> (numerator(r) *\<^sub>\<S>\<^sup>\<nat> succ {} +\<^sub>\<S>\<^sup>\<nat> 
       numerator(r) *\<^sub>\<S>\<^sup>\<nat> NtDr1)" using Mult_13[of _ "numerator(t)" ?s]
     by mauto
   have T1: "?s in omega" using ordinal1_def_12[of ?s] by mauto

   let ?y= "(numerator (r)*\<^sub>\<S>\<^sup>\<nat>NtDr1)/\<^bsub>\<rat>\<ge>0\<^bsup> (denominator(r))"


   have "  denominator(t) <> {}" using arytm_3_th_35 by mauto
   hence "(?s*\<^sub>\<S>\<^sup>\<nat>numerator(t))/\<^bsub>\<rat>\<ge>0\<^bsup> denominator(t) = 
     (numerator(r)*\<^sub>\<S>\<^sup>\<nat>(succ{})+\<^sub>\<S>\<^sup>\<nat> numerator(r)*\<^sub>\<S>\<^sup>\<nat>(NtDr1))/\<^bsub>\<rat>\<ge>0\<^bsup>denominator(r)"
     using A1 A2 arytm_3_th_45[of "(numerator(r)*\<^sub>\<S>\<^sup>\<nat> succ {}) +\<^sub>\<S>\<^sup>\<nat> 
         (numerator(r)*\<^sub>\<S>\<^sup>\<nat> NtDr1)" "?s*\<^sub>\<S>\<^sup>\<nat>numerator(t)" "denominator(r)" 
    "denominator(t)" ] by mauto
   also have "... = ((numerator(r)*\<^sub>\<S>\<^sup>\<nat>(succ{}))/\<^bsub>\<rat>\<ge>0\<^bsup>denominator(r)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y"
     using arytm_3_th_47[of "(numerator(r)*\<^sub>\<S>\<^sup>\<nat> NtDr1)" 
             "(numerator(r)*\<^sub>\<S>\<^sup>\<nat>(succ{}))" "denominator(r)" ] 
           arytm_3_th_35[of r] by mauto
   also have "... = (numerator(r)/\<^bsub>\<rat>\<ge>0\<^bsup>denominator(r)) +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y"
     using Mult_5 by mauto
   also have "... = r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y"
     using arytm_3_th_39 by mauto
   finally have "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y =  (?s*\<^sub>\<S>\<^sup>\<nat>numerator(t))/\<^bsub>\<rat>\<ge>0\<^bsup> ((succ{}) *\<^sub>\<S>\<^sup>\<nat> denominator(t))" 
     using Mult_5[of "denominator(t)"] by mty auto
   also have "... = (?s/\<^bsub>\<rat>\<ge>0\<^bsup> (succ{})) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( numerator(t) /\<^bsub>\<rat>\<ge>0\<^bsup> denominator(t))"
     using arytm_3_th_49[of "denominator(t)" "numerator(t)"] by mauto
   also have "... = ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ( numerator(t) /\<^bsub>\<rat>\<ge>0\<^bsup> denominator(t))"
     using arytm_3_th_40 by mauto
   also have "... = ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_th_39[of t] by auto 
   finally have "r +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?y = ?s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" by auto
   hence " r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ?s*\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using arytm_3_def_13I[of r] bexI[of _ "?y"] by mauto
   thus "ex s st s in omega & r \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> t" using T1 bexI[of _ "?s"] by mauto
 qed

theorem arytm_3_sch_1:
  assumes [ty]:"n2 is Nat" and
             A1: "P({})" and
             A2: "not P(n2)"                    
  shows "ex s be Nat st P(s) & not P(s +\<^sub>\<S>\<^sup>\<nat> succ {})"
proof-
  let ?Q="\<lambda>x. not P(x)"
  have B1:  "\<exists>n : Nat. ?Q(n)" using A2 bexI[of ?Q n2 Nat] by mty auto
  obtain k where [ty]:"k be Nat" and 
    A6: " ?Q(k) \<and> (\<forall>n:Nat. ?Q(n) \<longrightarrow> k \<subseteq> n)" using MinInd[OF B1] by mty auto
  have "k<>{}" using A1 A6 by mty auto 
  then obtain y where [ty]:"y be Nat" and
   y:    "succ y=k" using NAT_1_1[of k] by mty auto
  show "ex s be Nat st P(s) & not P(s +\<^sub>\<S>\<^sup>\<nat> succ {})"
  proof(rule bexI[of _ y],rule conjI)
    show "P(y)"
    proof(rule ccontr)
      assume "\<not> P(y)"
      hence "succ y \<subseteq> y" using y A6 by mty auto
      thus False using ordinal1_th_1 ordinal1_th_2 by mty auto
    qed
    have "y +\<^sub>\<S>\<^sup>\<nat> succ {} = k" using Add_5 y by mty auto
    thus "\<not> P(y +\<^sub>\<S>\<^sup>\<nat> succ {})" using A6 by mty auto
  qed mauto
qed mauto

reserve a,b,c,d for Nat

mtheorem arytm_3_TH1:
  "a \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b iff a c= b"
proof
  assume "a \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b"
  then obtain z where [ty]:"z be Element-of RAT\<^bsup>\<ge>0\<^bsub>" and
   z: "b = a +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> z" using arytm_3_def_13 by mty auto
  have "a in NAT" "b in NAT" using ordinal1_def_12[of a]  ordinal1_def_12[of b] by mty auto
  hence "z in NAT" using z arytm_3_th_71[of z a] by mty auto
  hence [ty]:"z is Nat" using ordinal1_def_12[of z] by mty auto
  hence "b = a +\<^sub>\<S>\<^sup>\<nat> z" using z arytm_3_th_58 by mty auto
  thus "a c= b" using bexI[of _ z Nat] Add_9[of b a] by mty auto
next
  assume "a c= b"
  then obtain c where [ty]: "c is Nat" and
     c: "b = a +\<^sub>\<S>\<^sup>\<nat> c" using  Add_9[of b a] by mty auto 
  hence "b = a +\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c" using arytm_3_th_58 by auto
  thus " a \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b" using arytm_3_def_13 bexI[of _ c "Element-of RAT\<^bsup>\<ge>0\<^bsub>"] by mty auto
qed

mtheorem arytm_3_TH1e:
  "a <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b iff a in b"
proof
  assume "a <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b"
  hence A: "a \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b & a <> b" using arytm_3_th_68 by auto 
  hence "a \<subseteq>b " using arytm_3_TH1 by auto 
  hence "not b in a" using ordinal1_th_1 by mty auto
  thus "a in b" using A ordinal1_th_10  by mty auto
next
  assume A: "a in b"
  hence "a \<subset> b" using ordinal1_th_7a by mty auto
  hence R: "a \<subseteq> b & a <>b" using xboole_0_def_8 by mty auto
  hence "a \<le>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b" using arytm_3_TH1 by mty auto
  thus "a <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b" using R arytm_3_th_68[of a b] by mty auto
qed

mtheorem arytm_3_TH2:
  "b<>{} \<longrightarrow> (a  /\<^bsub>\<rat>\<ge>0\<^bsup> b) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b = a"
proof
  assume A: "b<>{}"
  have N: "b = b/\<^bsub>\<rat>\<ge>0\<^bsup> (succ {})" using arytm_3_th_40 by mauto
  have "succ {} <>{}" by auto
  have "(a  /\<^bsub>\<rat>\<ge>0\<^bsup> b) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b = (a  /\<^bsub>\<rat>\<ge>0\<^bsup> b) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (b /\<^bsub>\<rat>\<ge>0\<^bsup> succ {})" using N  by mty auto
  also have "... = (a*\<^sub>\<S>\<^sup>\<nat>b)/\<^bsub>\<rat>\<ge>0\<^bsup>(b*\<^sub>\<S>\<^sup>\<nat>succ {})" using arytm_3_th_49 by mty auto
  also have "... = (a*\<^sub>\<S>\<^sup>\<nat>b)/\<^bsub>\<rat>\<ge>0\<^bsup>((succ {})*\<^sub>\<S>\<^sup>\<nat> b)" using Mult_6 by mty auto
  also have "... = (a  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (b /\<^bsub>\<rat>\<ge>0\<^bsup> b)" using arytm_3_th_49 by mty auto
  also have "... = (a  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{}) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (succ {})" using arytm_3_th_41[of b] A by mty auto
  also have "... = (a  /\<^bsub>\<rat>\<ge>0\<^bsup> succ{})" using arytm_3_th_53 by mty auto
  also have "... = a " using arytm_3_th_40[of a a] all_set by mty auto
  finally show "(a  /\<^bsub>\<rat>\<ge>0\<^bsup> b) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b = a" by auto
qed

mtheorem arytm_3_TH3:
  "b <>{} \<and> a *\<^sub>\<S>\<^sup>\<nat> b in c *\<^sub>\<S>\<^sup>\<nat> d \<longrightarrow> a /\<^bsub>\<rat>\<ge>0\<^bsup> d <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c /\<^bsub>\<rat>\<ge>0\<^bsup> b"
proof
  assume B:"b <>{} & a *\<^sub>\<S>\<^sup>\<nat> b in c *\<^sub>\<S>\<^sup>\<nat> d"
  hence "c *\<^sub>\<S>\<^sup>\<nat> d <>{}" using xb by auto
  hence D:"d <>{}" using Mult_2 by mty auto

  have "a *\<^sub>\<S>\<^sup>\<nat> b <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c *\<^sub>\<S>\<^sup>\<nat> d" using arytm_3_TH1e B by mty auto
  hence "a *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> d" using arytm_3_th_59 by mty auto
  hence "b *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> ((a /\<^bsub>\<rat>\<ge>0\<^bsup> d) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> d) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> d" 
    using arytm_3_def_12c[of a b]  arytm_3_TH2[of a d] D by mty auto
   hence "(b *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (a /\<^bsub>\<rat>\<ge>0\<^bsup> d)) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> d <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> d" 
    using arytm_3_th_52 by mty auto
  hence "b *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (a /\<^bsub>\<rat>\<ge>0\<^bsup> d) <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (c /\<^bsub>\<rat>\<ge>0\<^bsup> b) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b" 
     using arytm_3_th_80e[of "b *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (a /\<^bsub>\<rat>\<ge>0\<^bsup> d)" c d] D arytm_3_TH2[of c b] B by mty auto
  hence " (a /\<^bsub>\<rat>\<ge>0\<^bsup> d) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> (c /\<^bsub>\<rat>\<ge>0\<^bsup> b) *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b" 
    using arytm_3_def_12c[of _ b] by mty auto
  thus "a /\<^bsub>\<rat>\<ge>0\<^bsup> d <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> c /\<^bsub>\<rat>\<ge>0\<^bsup> b" using B arytm_3_th_80e[of "a /\<^bsub>\<rat>\<ge>0\<^bsup> d" "c /\<^bsub>\<rat>\<ge>0\<^bsup> b" b] by mty auto
qed

mtheorem arytm_3_TH4:
  "a<>{} \<and> b<>{} \<longrightarrow> {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> a/\<^bsub>\<rat>\<ge>0\<^bsup> b"
proof(rule impI, rule ccontr)
  assume as: "a<>{} \<and> b<>{}" "\<not> {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> a /\<^bsub>\<rat>\<ge>0\<^bsup> b"
  hence "a /\<^bsub>\<rat>\<ge>0\<^bsup> b ={}" using arytm_3_th_65 by mty auto
  hence "{} *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> b = a" using as arytm_3_TH2[of a b] by mty auto
  thus False using arytm_3_th_48 as arytm_3_def_12c[of b] by mty auto
qed

mtheorem arytm_3_TH5:
  "{} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<and> {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s \<longrightarrow> {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
proof(rule impI, rule ccontr)
  assume as: "{}<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r \<and> {}<\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s" "\<not> {} <\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s"
  hence "r *\<^sub>\<S>\<^bsup>\<rat>\<^sup>\<ge>\<^sup>0\<^bsub> s ={}" using arytm_3_th_65 by mty auto
  thus False using arytm_3_th_78[of s r] as by mty auto
qed


end