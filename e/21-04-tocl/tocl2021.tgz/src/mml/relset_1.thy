theory relset_1
imports relat_1 subset_1
begin

reserve x,y,z for object
reserve X,Y for set

section "relset_1"

text_raw {*\DefineSnippet{relset1def1prefix}{*}
abbreviation relset_1_def_1 ("(Relation-of _,_)" 105)
where "Relation-of X,Y \<equiv> Subset-of [:X,Y:]"
text_raw {*}%EndSnippet*}

mtheorem relset_1_lm_1:
  "for R being Relation-of X,Y holds R \<subseteq> [:X,Y:]"
proof (rule ballI)
  fix R
  assume A1[ty]: "R be Relation-of X,Y"
  have [ty]:"R be set" by mauto
  have "R in (bool [:X,Y:])" using subset_1_def_1 A1 by mauto
  thus B1: "R \<subseteq> [:X,Y:]" using zfmisc_1_def_1[of "[:X,Y:]" R] by auto
qed mauto

text_raw {*\DefineSnippet{relset_1_cl_1}{*}
mtheorem relset_1_cl_1:
  mlet "X be set","Y be set"
   "cluster \<rightarrow> Relation_like for Subset-of [:X,Y:]"
text_raw {*}%EndSnippet*}
proof(standard,intro ballI)
  fix IT
  assume [ty]: "IT be Subset-of [:X,Y:]"
  show "IT is Relation_like"
    proof (intro relat_1_def_1I,simp,intro ballI impI)
    (*  show "for x st x in IT ex y,z st x=[y,z]"
        proof (intro ballI impI)*)
          fix x
          have A2: "IT be Element-of (bool [:X,Y:])" by auto
          hence "IT in (bool [:X,Y:])" using subset_1_def_1 by mauto
          hence B1: "IT \<subseteq> [:X,Y:]" using zfmisc_1_def_1 subset_1_def_1[of _ IT ] by auto
          assume "x in IT"
          hence "x in [:X,Y:]" using B1 tarski_def_3E[of IT]  by auto
          thus "ex y,z st x=[y,z]" using B1 zfmisc_1_def_2 by auto
       qed mauto
qed mauto
  
mtheorem relset_1_cl_2:
   mlet "X be set","Y be set"
   "cluster \<rightarrow> (X-defined) \<bar> (Y-valued) for (Relation-of X,Y)"
proof(standard,standard)
  fix IT
  assume A2[ty]: "IT be Relation-of X,Y"
  have B1: "IT \<subseteq> [:X,Y:]" using relset_1_lm_1 A2 by mauto
  show "IT is (X-defined) \<bar> (Y-valued)"
    proof
       show "IT is (X-defined)"
          proof (intro relat_1_def_18I,simp,simp)
            show "dom IT \<subseteq> X"
              proof(standard,auto)
                fix x
                assume "x in dom IT"
                then obtain y where
                  "y be object" and A3: "[x,y] in IT" using xtuple_0_def_12 by auto
                hence "[x,y] in [:X,Y:]" using A3 B1 tarski_def_3 by auto
                thus "x in X" using A2 zfmisc_1_th_87 by simp
              qed mauto
          qed mauto
       show "IT is (Y-valued)"
          proof (intro relat_1_def_19I,simp,simp)
            show "rng IT \<subseteq> Y"
              proof(standard,auto)
                fix x
                assume "x in rng IT"
                then obtain y where
                  "y be object"  "[y,x] in IT" using xtuple_0_def_13 by auto
                hence "[y,x] in [:X,Y:]" using A2 B1 tarski_def_3 by auto
                thus "x in Y" using A2 zfmisc_1_th_87 by simp
              qed mauto
          qed mauto
     qed
   qed mauto

mtheorem relset_1_th_4:
  "for R being Relation st dom R \<subseteq> X \<and> rng R \<subseteq> Y holds R be Relation-of X,Y"
proof(rule ballI,rule impI)
  fix R
  assume A1[ty]: "R be Relation"
  assume "dom R \<subseteq> X \<and> rng R \<subseteq> Y"
  hence "R c= [:dom R,rng R:] \<and> [:dom R,rng R:] c= [:X,Y:]" using relat_1_th_7[of R]
       zfmisc_1_th_96[of Y "rng R" X "dom R"] A1 by mauto
  hence "R c= [:X,Y:]" using tarski_def_3 by mauto
  thus "R be Relation-of X,Y" using zfmisc_1_def_1 Element(6) by mauto
qed simp

mtheorem
  mlet "A be set", "B be set", "X be set",
       "R be Relation-of A,B" 
  "cluster R|X \<rightarrow> Relation-of A,B"
proof
  have "dom (R|X) = dom R \<inter> X" using relat_1_th_55[of X R] by mty auto
  hence "dom (R|X) c= dom R" "dom R c= A" using relat_1_def_18[of A R] 
    using xboole_0_def_4 tarski_def_3I by mty auto
  hence D: "dom (R|X) c= A" using xboole_1_th_1[of A "dom R" "dom (R|X)"] all_set by mty auto
  have "rng(R|X) c= B"
  proof(intro tarski_def_3I ballI impI)
    fix x assume "x in rng(R|X)"
    then obtain y where
      y:"[y,x] in (R|X)" using xtuple_0_def_13 by mty auto
    hence "[y,x] in R" using relat_1_def_11[of R X] by mty auto
    hence "x in rng R" "rng R c= B" using  relat_1_def_19[of B R]  xtuple_0_def_13 by mty auto
    thus "x in B" using tarski_def_3E all_set by mty auto
  qed mauto
  thus "R | X be Relation-of A,B" using relset_1_th_4 D by mty auto
qed
end
