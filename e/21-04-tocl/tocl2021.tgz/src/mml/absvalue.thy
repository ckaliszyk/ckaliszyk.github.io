theory absvalue
  imports real_0
    
begin


reserve x,y for MReal

mdef absvalue_def_1 ("|. _ .|" 110) where
  mlet "x be MReal"
  "func |. x .|  \<rightarrow> Element-of REAL\<^bsup>\<ge>0\<^bsub> equals
  x if ({} \<le>\<^sup>\<real> x) otherwise -\<^sub>\<S>\<^sup>\<real> x"
proof
  show " {} \<le>\<^sup>\<real> x  \<longrightarrow> x be Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R[of x,simplified] by mty auto
  show "x <\<^sup>\<real> {} \<longrightarrow> (-\<^sub>\<S>\<^sup>\<real> x) be Element-of REAL\<^bsup>\<ge>0\<^bsub>"
  proof
    assume "x <\<^sup>\<real> {}" 
    hence "{} <\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x)" using real_0_th_30[of x "{}"] real_0_th_18 by mty auto
    hence "{} \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x)" using real_0_th_33 by mty auto
    thus "(-\<^sub>\<S>\<^sup>\<real> x) is  Element-of REAL\<^bsup>\<ge>0\<^bsub>" using  real_0_R[of "-\<^sub>\<S>\<^sup>\<real> x",simplified] by mty auto
  qed
qed mauto

mtheorem absvalue_th_1:
  "|.x.| = x or |.x.| = (-\<^sub>\<S>\<^sup>\<real> x)" using  absvalue_def_1[of x] by mty auto

mtheorem absvalue_th_2:
  "x = {} iff |.x.| = {}"
proof
  show "x =\<^sub>\<S> {} \<Longrightarrow> |. x .| =\<^sub>\<S> {}" using absvalue_def_1[of x] real_0_def_8r[of "{}"] by mty auto
  show "|. x .| =\<^sub>\<S> {} \<Longrightarrow> x =\<^sub>\<S> {}"
  proof(rule ccontr)
    assume A: "|. x .| =\<^sub>\<S> {}" "x <> {}"
    hence "{} = (-\<^sub>\<S>\<^sup>\<real> x)" using A absvalue_def_1[of x] by mty auto 
    thus False using A real_0_th_18  real_0_th_20a[of x] by mty auto
  qed
qed

mtheorem absvalue_th_3:
  "|.x.| = (-\<^sub>\<S>\<^sup>\<real> x) & x <> {} implies x <\<^sup>\<real> {}"
proof(rule impI, rule ccontr)
  assume A: "|. x .| =\<^sub>\<S> (-\<^sub>\<S>\<^sup>\<real> x) \<and> x \<noteq> {}""\<not> x <\<^sup>\<real> {}"
  hence Q: " {} \<le>\<^sup>\<real> x" using real_0_def_8c by auto
  hence [ty]: "x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  have "(-\<^sub>\<S>\<^sup>\<real> x) =\<^sub>\<S> x" using Q A absvalue_def_1[of x] by mty auto
  thus "False" using A real_0_th_19 by mty auto
qed

mtheorem absvalue_th_4:
  " (-\<^sub>\<S>\<^sup>\<real> |.x.|) \<le>\<^sup>\<real> x & x \<le>\<^sup>\<real> |.x.|"
proof(cases "x <\<^sup>\<real> {}")
  case T: True
  hence "|.x.| = (-\<^sub>\<S>\<^sup>\<real> x)"  using absvalue_def_1[of x] by mty auto
  hence x:"(-\<^sub>\<S>\<^sup>\<real> |.x.| ) = x" using real_0_th_20a real_0_th_18 by mty auto
  have "{} \<le>\<^sup>\<real> |.x.|" "x \<le>\<^sup>\<real> {}" using real_0_R[of "|.x.|"] real_0_th_33[of x "{}"] T by mty auto
  hence "x \<le>\<^sup>\<real> |.x.|" using T real_0_def_8t[of "|.x.|" "{}" x] by mty auto
  thus  " (-\<^sub>\<S>\<^sup>\<real> |.x.|) \<le>\<^sup>\<real> x & x \<le>\<^sup>\<real> |.x.|" using x real_0_def_8r[of x] by mty auto
next
  case F:False
    hence x: "|.x.| = x"  using absvalue_def_1[of x] by mty auto
    hence "-\<^sub>\<S>\<^sup>\<real> |.x.| \<le>\<^sup>\<real> {}" using F real_0_th_30 real_0_th_18 by mty auto 
    hence "-\<^sub>\<S>\<^sup>\<real> |.x.| \<le>\<^sup>\<real> x" using real_0_def_8t[of x "{}" ] F by mty auto
   thus  " (-\<^sub>\<S>\<^sup>\<real> |.x.|) \<le>\<^sup>\<real> x & x \<le>\<^sup>\<real> |.x.|" using x real_0_def_8r[of x] by mty auto
qed
       
       
mtheorem absvalue_th_5:
  "(-\<^sub>\<S>\<^sup>\<real> y) \<le>\<^sup>\<real> x & x \<le>\<^sup>\<real> y iff |.x.| \<le>\<^sup>\<real> y"
proof
  assume AS: "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> x  \<and> x \<le>\<^sup>\<real> y"
  hence "-\<^sub>\<S>\<^sup>\<real> x \<le>\<^sup>\<real> y" using  real_0_th_20a[of y]  real_0_th_30[of x "-\<^sub>\<S>\<^sup>\<real> y"] by mty auto
  thus "|.x.| \<le>\<^sup>\<real> y" using AS absvalue_def_1[of x] by mty auto
next
  assume AS: "|.x.| \<le>\<^sup>\<real> y"
  show "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> x  \<and> x \<le>\<^sup>\<real> y"  
  proof(cases "x={}")
    case T: True
      hence "|. x.|={}" using absvalue_th_2 by mty auto
      thus "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> x  \<and> x \<le>\<^sup>\<real> y"   using AS real_0_th_30[of y "{}"] real_0_th_18 T by mty auto
    next
      case F:False
      show "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> x  \<and> x \<le>\<^sup>\<real> y" 
      proof(cases "{} \<le>\<^sup>\<real> x")
        case T: True
        hence x:"|. x .| = x" using absvalue_def_1[of x] by mty auto
        hence "{} \<le>\<^sup>\<real> y" using T AS real_0_def_8t[of y x "{}"] by mty auto
        hence "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> {}" using real_0_th_18 real_0_th_30 by mty auto
        thus "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> x  \<and> x \<le>\<^sup>\<real> y" using T x AS  real_0_def_8t[of x "{}"] by mty auto
      next
        case F1: False
        hence x:"|. x .| = (-\<^sub>\<S>\<^sup>\<real> x)" using absvalue_def_1[of x] by mty auto
        hence y: "(-\<^sub>\<S>\<^sup>\<real> y) \<le>\<^sup>\<real> x" using real_0_th_20a[of x] AS real_0_th_30 by mty auto
        have "{} \<le>\<^sup>\<real>|. x .|" using AS real_0_R by mty auto
        hence "{} \<le>\<^sup>\<real> y" "x \<le>\<^sup>\<real> {}" 
           using F1 real_0_th_33 AS real_0_def_8t[of y "|. x .|" "{}"] by mty auto
         thus "-\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> x  \<and> x \<le>\<^sup>\<real> y" using y real_0_def_8t[of y "{}" x] by mty auto
      qed         
  qed
qed

mtheorem absvalue_th_5a:
  "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x & x <\<^sup>\<real> y iff |.x.| <\<^sup>\<real> y"
proof
  assume AS: "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x  \<and> x <\<^sup>\<real> y"
  hence "(-\<^sub>\<S>\<^sup>\<real> x) <\<^sup>\<real> y" using  real_0_th_20a[of y]  real_0_th_30[of "-\<^sub>\<S>\<^sup>\<real> y" x] by mty auto
  thus "|.x.| <\<^sup>\<real> y" using AS absvalue_def_1[of x] by mty auto
next
  assume AS: "|.x.| <\<^sup>\<real> y"
  show "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x  \<and> x <\<^sup>\<real> y"  
  proof(cases "x={}")
    case T: True
      hence "|. x.|={}" using absvalue_th_2 by mty auto
      thus "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x  \<and> x <\<^sup>\<real> y"   using AS real_0_th_30[of "{}" y] real_0_th_18 T by mty auto
    next
      case F:False
      show "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x  \<and> x <\<^sup>\<real> y" 
      proof(cases "{} \<le>\<^sup>\<real> x")
        case T: True
        hence x:"|. x .| = x" using absvalue_def_1[of x] by mty auto
        hence "{} <\<^sup>\<real> y" using T AS real_0_def_8t1[of y x "{}"] by mty auto
        hence "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> {}" using real_0_th_18 real_0_th_30 by mty auto
        thus "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x  \<and> x <\<^sup>\<real> y" using T x AS real_0_def_8t2[of x _ "{}"] by mty auto
      next
        case F1: False
        hence x:"|. x .| = (-\<^sub>\<S>\<^sup>\<real> x)" using absvalue_def_1[of x] by mty auto
        hence y: "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x" using real_0_th_20a[of x] AS real_0_th_30 by mty auto
        have "{} \<le>\<^sup>\<real> |. x .|" using AS real_0_R by mty auto
        hence "{} \<le>\<^sup>\<real> y" "x <\<^sup>\<real> {}" using F1 real_0_th_33 AS real_0_def_8t[of y "|. x .|" "{}"] by mty auto
        thus "(-\<^sub>\<S>\<^sup>\<real> y) <\<^sup>\<real> x  \<and> x <\<^sup>\<real> y" using y real_0_def_8t2[of y x "{}" ] by mty auto
      qed         
  qed
qed


mtheorem absvalue_th_6:
  "|. x +\<^sub>\<S>\<^sup>\<real> y .| \<le>\<^sup>\<real> |.x.| +\<^sub>\<S>\<^sup>\<real> |.y.|"
proof-
  have "x \<le>\<^sup>\<real> |.x.|" "y \<le>\<^sup>\<real> |.y.|" using absvalue_th_4 by mty auto
  hence H: "x +\<^sub>\<S>\<^sup>\<real> y \<le>\<^sup>\<real> |.x.| +\<^sub>\<S>\<^sup>\<real> |.y.|" using real_1_th_16 by mty auto 
  have "(-\<^sub>\<S>\<^sup>\<real> |.x.| ) \<le>\<^sup>\<real> x " "(-\<^sub>\<S>\<^sup>\<real> |.y.| )\<le>\<^sup>\<real> y" using absvalue_th_4 by mty auto
  hence "(-\<^sub>\<S>\<^sup>\<real> |.x.| ) +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> |.y.| )\<le>\<^sup>\<real> x +\<^sub>\<S>\<^sup>\<real> y" using real_1_th_16 by mty auto
  hence "(-\<^sub>\<S>\<^sup>\<real> ( |.x.|  +\<^sub>\<S>\<^sup>\<real>  |.y.| ))\<le>\<^sup>\<real> x +\<^sub>\<S>\<^sup>\<real> y" using real_0_th_20 by mty auto
  thus ?thesis using H absvalue_th_5[of "x +\<^sub>\<S>\<^sup>\<real> y" "|.x.|  +\<^sub>\<S>\<^sup>\<real>  |.y.|"] by mty auto
qed

mtheorem absvalue_th_7:
  "|.x.| = |. ( -\<^sub>\<S>\<^sup>\<real> x) .|"
proof(cases "x={}")
  case True
  thus  "|.x.| = |. ( -\<^sub>\<S>\<^sup>\<real> x) .|" using real_0_th_18 by mty auto
next 
  case F:False
  hence F1: "(-\<^sub>\<S>\<^sup>\<real> x) <>{}" using real_0_th_20a[of x] real_0_th_18 by mty auto
  show"|.x.| = |. ( -\<^sub>\<S>\<^sup>\<real> x) .|"
  proof(cases "{} \<le>\<^sup>\<real> x")
    case T:True
    hence "(-\<^sub>\<S>\<^sup>\<real> x) \<le>\<^sup>\<real> {}" using real_0_th_18 real_0_th_30[of x "{}"] by mty auto
    hence "(-\<^sub>\<S>\<^sup>\<real> x) <\<^sup>\<real> {}" using real_0_th_33 F1 by mty auto
    hence "|. ( -\<^sub>\<S>\<^sup>\<real> x) .| = x" using real_0_th_20a[of x] absvalue_def_1 by mty auto
    thus  "|.x.| = |. ( -\<^sub>\<S>\<^sup>\<real> x) .|" using T absvalue_def_1 by mty auto
  next
    case F2: False
    hence "x \<le>\<^sup>\<real> {}" using real_0_th_33 by mty auto
    hence "{} \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x)" using real_0_th_18 real_0_th_30[of "{}" x] by mty auto
    thus  "|.x.| = |. ( -\<^sub>\<S>\<^sup>\<real> x) .|" using F2 absvalue_def_1 by mty auto
  qed
qed


mtheorem absvalue_th_8:
  "|. |. x .| -\<^sub>\<S>\<^sup>\<real> |. y .| .| \<le>\<^sup>\<real> |. x  -\<^sub>\<S>\<^sup>\<real> y .|"
proof-
  have "(x +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)) -\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y) = x" using real_1_th_19 by mty auto
  hence "(x +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)) +\<^sub>\<S>\<^sup>\<real> y = x" using real_0_def_6 real_0_th_20a[of y] by mty auto
  hence "(x -\<^sub>\<S>\<^sup>\<real> y) +\<^sub>\<S>\<^sup>\<real> y = x" using real_0_def_6 by mty auto
  hence "|. x .| \<le>\<^sup>\<real> |.(x -\<^sub>\<S>\<^sup>\<real> y).| +\<^sub>\<S>\<^sup>\<real> |.y.|" using absvalue_th_6[of y "x -\<^sub>\<S>\<^sup>\<real> y"] by mty auto 
  hence H1: "|. x .| -\<^sub>\<S>\<^sup>\<real> |.y.| \<le>\<^sup>\<real> |.(x -\<^sub>\<S>\<^sup>\<real> y).|" using real_1_th_21 by mty auto 
  have "(y +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x))-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x) = y" using real_1_th_19 by mty auto
  hence "(y +\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x)) +\<^sub>\<S>\<^sup>\<real> x = y" using real_0_def_6 real_0_th_20a[of x] by mty auto
  hence "(y -\<^sub>\<S>\<^sup>\<real> x) +\<^sub>\<S>\<^sup>\<real> x = y" using real_0_def_6 by mty auto
  hence "|. y .| \<le>\<^sup>\<real> |.(y -\<^sub>\<S>\<^sup>\<real> x).| +\<^sub>\<S>\<^sup>\<real> |.x.|" using absvalue_th_6[of x "y -\<^sub>\<S>\<^sup>\<real> x"] by mty auto 
  hence "|. y .| -\<^sub>\<S>\<^sup>\<real> |.x.| \<le>\<^sup>\<real> |.(y -\<^sub>\<S>\<^sup>\<real> x).|" using real_1_th_21 by mty auto 
  hence "-\<^sub>\<S>\<^sup>\<real> |.(y -\<^sub>\<S>\<^sup>\<real> x).| \<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (( |. y.| -\<^sub>\<S>\<^sup>\<real> |.x.|))) " using real_0_th_30 by mty auto 
  hence "-\<^sub>\<S>\<^sup>\<real> |.(y -\<^sub>\<S>\<^sup>\<real> x).| \<le>\<^sup>\<real> ( |. x.| -\<^sub>\<S>\<^sup>\<real> |.y.|) " using real_1_th_22 by mty auto
  hence "-\<^sub>\<S>\<^sup>\<real> |.(x -\<^sub>\<S>\<^sup>\<real> y).| \<le>\<^sup>\<real> ( |. x.| -\<^sub>\<S>\<^sup>\<real> |.y.|)" using absvalue_th_7[of "x -\<^sub>\<S>\<^sup>\<real> y"] 
   real_1_th_22[of y x] by mty auto
  thus ?thesis using H1 absvalue_th_5[of "|. x .| -\<^sub>\<S>\<^sup>\<real> |. y .|" "|.(x -\<^sub>\<S>\<^sup>\<real> y).|"] by mty auto
qed

mtheorem absvalue_th_9:
  "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|"
proof(cases "{} \<le>\<^sup>\<real> x")
  case T: True
  hence [ty]:"x is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  show "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|"
  proof(cases "{} \<le>\<^sup>\<real> y")
    case T2:True
    hence [ty]: "y is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
    have "x *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub> y = x *\<^sub>\<S>\<^sup>\<real> y" using real_0_def_7 by mty auto
    hence "{}\<le>\<^sup>\<real> x *\<^sub>\<S>\<^sup>\<real> y" using real_0_R by mty auto
    hence "|. x *\<^sub>\<S>\<^sup>\<real> y .| = x *\<^sub>\<S>\<^sup>\<real> y" using absvalue_def_1 by mty auto
    thus "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|" using T T2 absvalue_def_1 by mty auto
  next
    case F: False
    hence [ty]:"y is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
    have "x *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y) = x *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using real_0_def_7 by mty auto
    hence "{}\<le>\<^sup>\<real> x *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using real_0_R by mty auto
    hence H: "|. x *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y) .| = x *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using absvalue_def_1 by mty auto
    
    have "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. -\<^sub>\<S>\<^sup>\<real> (x *\<^sub>\<S>\<^sup>\<real> y) .| " using absvalue_th_7 by mty auto
    also have "... = x *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y) " using H real_0_th_42[of y x] by mty auto
    finally show "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|" using T F absvalue_def_1 by mty auto 
  qed
next case F: False
    hence [ty]:"x is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
  show "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|"
  proof(cases "{} \<le>\<^sup>\<real> y")
    case T2:True
    hence [ty]:"y is Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
    have "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  y = (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> y" using real_0_def_7 by mty auto
    hence "{}\<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> y" using real_0_R by mty auto
    hence H: "|. (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> y.| = (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> y" using absvalue_def_1 by mty auto
    
    have "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. -\<^sub>\<S>\<^sup>\<real> (x *\<^sub>\<S>\<^sup>\<real> y) .| " using absvalue_th_7 by mty auto
    also have "... = (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> y " using H real_0_th_42[of y x] by mty auto
    finally show "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|" using T2 F absvalue_def_1 by mty auto 
  next
    case F2: False
    hence [ty]:"y is non Element-of REAL\<^bsup>\<ge>0\<^bsub>" using real_0_R by mty auto
    have "(-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^bsup>\<real>\<^sup>\<ge>\<^sup>0\<^bsub>  (-\<^sub>\<S>\<^sup>\<real> y) = (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using real_0_def_7 by mty auto
    hence "{}\<le>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using real_0_R by mty auto
    hence H: "|. (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y).| = (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using absvalue_def_1 by mty auto
    have "x *\<^sub>\<S>\<^sup>\<real> y = (-\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> (x *\<^sub>\<S>\<^sup>\<real> y)))" using real_0_th_20a[of "x *\<^sub>\<S>\<^sup>\<real> y"] by mty auto
    also have "... = (-\<^sub>\<S>\<^sup>\<real> ((-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> y))" using real_0_th_42[of y x] by mty auto
    also have "... =  (-\<^sub>\<S>\<^sup>\<real> x) *\<^sub>\<S>\<^sup>\<real> (-\<^sub>\<S>\<^sup>\<real> y)" using real_0_th_42[of y "-\<^sub>\<S>\<^sup>\<real> x"] by mty auto
    finally show "|. x *\<^sub>\<S>\<^sup>\<real> y .| = |. x .| *\<^sub>\<S>\<^sup>\<real> |. y .|" using F2 F H absvalue_def_1 by mty auto 
  qed
qed


end


