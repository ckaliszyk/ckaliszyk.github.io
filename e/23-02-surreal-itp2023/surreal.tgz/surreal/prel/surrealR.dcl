<?xml version="1.0"?>
<Registrations>
<Signature>
<ArticleID name="HIDDEN"/>
<ArticleID name="TARSKI"/>
<ArticleID name="XBOOLE_0"/>
<ArticleID name="ZFMISC_1"/>
<ArticleID name="SUBSET_1"/>
<ArticleID name="RELAT_1"/>
<ArticleID name="FUNCT_1"/>
<ArticleID name="PARTFUN1"/>
<ArticleID name="XTUPLE_0"/>
<ArticleID name="MCART_1"/>
<ArticleID name="FUNCT_2"/>
<ArticleID name="ORDINAL1"/>
<ArticleID name="FINSET_1"/>
<ArticleID name="CARD_1"/>
<ArticleID name="FINSEQ_1"/>
<ArticleID name="FINSUB_1"/>
<ArticleID name="RELAT_2"/>
<ArticleID name="STRUCT_0"/>
<ArticleID name="CLASSES1"/>
<ArticleID name="GRAPH_1"/>
<ArticleID name="CAT_1"/>
<ArticleID name="XFAMILY"/>
<ArticleID name="COH_SP"/>
<ArticleID name="COHSP_1"/>
<ArticleID name="SURREALO"/>
<ArticleID name="SURREALR"/>
</Signature>
<RCluster aid="SURREALR" nr="1">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
<Adjective nr="25"/>
<Adjective nr="100"/>
<Adjective nr="111"/>
</Cluster>
</RCluster>
<FCluster aid="SURREALR" nr="1">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
<Adjective nr="111"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="111"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="2">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
<Adjective nr="100"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="28">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="100"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="3">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
<Adjective nr="111"/>
</Cluster>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="34">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="4">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
<Adjective nr="25"/>
<Adjective nr="100"/>
<Adjective nr="111"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="3">
<Func kind="K" nr="54">
<LocusVar nr="1"/>
</Func>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="9"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="5">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="228">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="106"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="6">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="229">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="107"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="7">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="23"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="230">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="8">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="232">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="106"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="9">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="233">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="107"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="10">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="240">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="106"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALR" nr="11">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="106"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="241">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
<LocusVar nr="3"/>
<LocusVar nr="4"/>
</Func>
<Cluster>
<Adjective nr="107"/>
</Cluster>
</FCluster>
</Registrations>
