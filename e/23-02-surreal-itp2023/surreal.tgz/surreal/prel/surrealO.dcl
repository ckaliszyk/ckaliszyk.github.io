<?xml version="1.0"?>
<Registrations>
<Signature>
<ArticleID name="HIDDEN"/>
<ArticleID name="TARSKI"/>
<ArticleID name="XBOOLE_0"/>
<ArticleID name="ZFMISC_1"/>
<ArticleID name="SUBSET_1"/>
<ArticleID name="RELAT_1"/>
<ArticleID name="XTUPLE_0"/>
<ArticleID name="FUNCT_1"/>
<ArticleID name="ORDINAL1"/>
<ArticleID name="SURREALO"/>
</Signature>
<RCluster aid="SURREALO" nr="1">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="28"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALO" nr="2">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="29"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALO" nr="3">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="29"/>
</Cluster>
</RCluster>
<RCluster aid="SURREALO" nr="4">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="29"/>
</Cluster>
</Typ>
</ArgTypes>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="9"/>
<Adjective nr="28"/>
<Adjective nr="30">
<LocusVar nr="1"/>
</Adjective>
</Cluster>
</RCluster>
<RCluster aid="SURREALO" nr="5">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="9"/>
<Adjective nr="28"/>
<Adjective nr="31"/>
</Cluster>
</RCluster>
<FCluster aid="SURREALO" nr="1">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="59">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="4"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="2">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="4"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="61">
<LocusVar nr="2"/>
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="3">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="65">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="4"/>
<Adjective nr="27"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="4">
<ArgTypes/>
<Func kind="K" nr="4">
<Func kind="K" nr="5"/>
<Func kind="K" nr="5"/>
</Func>
<Cluster>
<Adjective nr="28"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="5">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="1">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="6">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="34">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</FCluster>
<FCluster aid="SURREALO" nr="7">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="35">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</FCluster>
<FCluster aid="SURREALO" nr="8">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="29"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="29"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="6">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="9">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="29"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="29"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="8">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="10">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="29"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="29"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="7">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="11">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="71">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="29"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="12">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="48">
<Func kind="K" nr="73">
<LocusVar nr="1"/>
</Func>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="29"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="13">
<ArgTypes/>
<Func kind="K" nr="67"/>
<Cluster>
<Adjective nr="28"/>
<Adjective nr="31"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="14">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
<Adjective nr="31"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="6">
<Func kind="K" nr="57">
<LocusVar nr="1"/>
</Func>
<Func kind="K" nr="58">
<LocusVar nr="1"/>
</Func>
</Func>
<Cluster>
<Adjective nr="32"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="15">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
<Adjective nr="31"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="1">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="32"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="16">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="32"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="32"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="6">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="32"/>
</Cluster>
</FCluster>
<FCluster aid="SURREALO" nr="17">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="28"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="74">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="28"/>
<Adjective nr="31"/>
</Cluster>
</FCluster>
<CCluster aid="SURREALO" nr="1">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="19"/>
</Cluster>
</Typ>
</ArgTypes>
<Cluster/>
<Typ kind="M" nr="3">
<Cluster/>
<Func kind="K" nr="66">
<LocusVar nr="1"/>
</Func>
</Typ>
<Cluster>
<Adjective nr="28"/>
</Cluster>
</CCluster>
<CCluster aid="SURREALO" nr="2">
<ArgTypes/>
<Cluster>
<Adjective nr="28"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="9"/>
<Adjective nr="28"/>
</Cluster>
</CCluster>
<CCluster aid="SURREALO" nr="3">
<ArgTypes/>
<Cluster>
<Adjective nr="28"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</CCluster>
<CCluster aid="SURREALO" nr="4">
<ArgTypes/>
<Cluster>
<Adjective nr="1"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="32"/>
</Cluster>
</CCluster>
</Registrations>
