(* $Id: equeue.ml,v 1.1 2003/01/22 08:11:57 uuu Exp $
 *
 * Event queues
 * written by Gerd Stolpmann
 *)

type 'a t =
  { mutable queue : 'a list;
    mutable new_queue : 'a list;
    mutable error_queue : 'a list;
    mutable handlers : 'a hdl list;
    mutable new_handlers : 'a hdl list;
    mutable source : 'a t -> unit }
and 'a hdl = 'a t -> 'a -> unit


exception Reject          (* Event handler rejects an event *)
exception Terminate       (* Event handler removes itself from the list *)
exception Out_of_handlers (* There is an event  but no event handler *)

let create source =
  {queue = []; new_queue = []; error_queue = []; handlers = [];
   new_handlers = []; source = source}


let add_handler esys h = esys.new_handlers <- esys.new_handlers @ [h]


let add_event esys e = esys.new_queue <- esys.new_queue @ [e]




let run esys =
  if esys.queue = [] then
    begin
      if esys.new_queue = [] && esys.error_queue = [] then esys.source esys;
      esys.queue <- esys.new_queue @ esys.error_queue;
      esys.new_queue <- [];
      esys.error_queue <- []
    end;
  while esys.queue <> [] do
    let (e :: q') = esys.queue in
    let accept = ref false in
    esys.handlers <- esys.handlers @ esys.new_handlers;
    esys.new_handlers <- [];
    begin try
      esys.handlers <-
        List.filter
          (fun h ->
             if not !accept then
               try h esys e; accept := true; true with
                 Reject -> true
               | Terminate -> accept := true; false
             else true)
          esys.handlers;
      esys.queue <- q'
    with
      any ->
        esys.queue <- q';
        esys.error_queue <- esys.error_queue @ [e];
        raise any
    end;
    if esys.queue = [] then
      begin
        if esys.new_queue = [] && esys.error_queue = [] then
          begin
            esys.source esys;
            if esys.new_queue <> [] && esys.handlers = [] &&
               esys.new_handlers = []
            then
              raise Out_of_handlers
          end;
        esys.queue <- esys.new_queue @ esys.error_queue;
        esys.new_queue <- [];
        esys.error_queue <- []
      end
  done

(*======================================================================
 * $Log: equeue.ml,v $
 * Revision 1.1  2003/01/22 08:11:57  uuu
 *
 * Equeue dodane.
 *
 * Revision 1.8  2001/09/02 12:39:59  gerd
 * 	Out_of_handlers: it is sufficient if new_handlers is non-
 * empty!
 *
 * Revision 1.7  2001/07/20 19:24:02  gerd
 * 	Out_of_handlers (again): If the event source is called, and
 * after that there are events but no handlers, this is clearly a
 * programming error, and the new Out_of_handlers condition.
 *
 * Revision 1.6  2001/07/20 19:12:27  gerd
 * 	Out_of_handlers: this exception has been removed. New behaviour:
 * If there are no handlers, all current events are dropped, and the
 * event source is called once. The source has the chance to add new handlers
 * and new events. If the source adds events but no handlers, the events
 * are dropped again, and the source is called again (perhaps this is
 * the real Out_of_handlers condition? don't know...). If the source does
 * not add events, the event system stops (even if there are new handlers).
 * If there are both events and handlers, the event system continues.
 *
 * Revision 1.5  2000/01/30 21:08:43  gerd
 * 	Another fix.
 *
 * Revision 1.4  2000/01/30 18:12:47  gerd
 * 	Separated new events and error events.
 *
 * Revision 1.3  2000/01/30 18:07:51  gerd
 * 	Bugfix: events added within handlers are no longer discarded.
 *
 * Revision 1.2  1999/04/07 16:42:42  gerd
 * 	Improved exception handling: If processing an event causes an
 * exception (other than Reject or Terminate), the event is added to a
 * second queue of deferred events; and the exception is propagated up.
 * You can now program an exception handler that can react by adding further
 * events to the primary queue, and it is guaranteed that these new events
 * are processed before the event that caused the error is reached again.
 * The idea is that applications such as Unixqueue can put Term events into
 * the queue that terminate the handlers that produced the errors, and that
 * (a) other handlers have the chance to get the error event, or (b) the event
 * is simply lost because there are not any handlers that can process it.
 *
 * Revision 1.1  1999/04/03 23:53:20  gerd
 * 	Renamed from 'Event' to 'Equeue'. Added some comments.
 *
 *)
