(* $Id: unixqueue_mt.mli,v 1.1 2003/01/22 08:11:57 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

(* This module initializes Unixqueue for multi-threaded programs.
 * Make sure that this module is linked as object file (.cmo or .cmx)
 * into the final executable, because this module would be garbage-
 * collected if it were in an archive file (.cma or .cmxa).
 *)

(* ======================================================================
 * History:
 * 
 * $Log: unixqueue_mt.mli,v $
 * Revision 1.1  2003/01/22 08:11:57  uuu
 *
 * Equeue dodane.
 *
 * Revision 1.1  2001/07/20 19:33:55  gerd
 * 	Initial revision.
 *
 * 
 *)
