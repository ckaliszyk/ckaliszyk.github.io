(* $Id: unixqueue_mt.ml,v 1.1 2003/01/22 08:11:57 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)


let create_lock_unlock_pair () =
  let mutex = Mutex.create () in
  let lock () = Mutex.lock mutex in
  let unlock () = Mutex.unlock mutex in lock, unlock

let _ = Unixqueue.init_mt create_lock_unlock_pair

(* ======================================================================
 * History:
 * 
 * $Log: unixqueue_mt.ml,v $
 * Revision 1.1  2003/01/22 08:11:57  uuu
 *
 * Equeue dodane.
 *
 * Revision 1.1  2001/07/20 19:33:55  gerd
 * 	Initial revision.
 *
 * 
 *)
