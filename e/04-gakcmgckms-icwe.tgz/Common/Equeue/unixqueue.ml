# 1 "unixqueue.mlp"
(* 
 * $Id: unixqueue.ml,v 1.1 2003/01/22 08:11:57 uuu Exp $
 *)

(**********************************************************************)
(***                                                                ***)
(***                Extensions to the UNIX library                  ***)
(***                                                                ***)
(**********************************************************************)

open Unix
open Sys

(* The following types are only used by the TCL extension: *)
type tcl_file_handler

# 18 "unixqueue.mlp"
# 19 "unixqueue.mlp"
# 21 "unixqueue.mlp"
# 22 "unixqueue.mlp"
# 24 "unixqueue.mlp"
# 25 "unixqueue.mlp"
# 26 "unixqueue.mlp"
type tcl_timer_handler
# 28 "unixqueue.mlp"

type tcl_file_handler_rec =
  { mutable tcl_fh : tcl_file_handler;
    mutable tcl_fd : Unix.file_descr;
    mutable tcl_mask : int }

(* Helpers for multi-threading: *)

let create_lock_unlock_pair = ref (fun () -> (fun () -> ()), (fun () -> ()))

let mt_mode = ref false

let init_mt create = create_lock_unlock_pair := create; mt_mode := true

(* Idea: 
 *   let lock, unlock = !create_lock_unlock_pair()
 * which creates a mutex, and two functions:
 *   lock()
 *   unlock()
 *
 * In multi-threading mode, the variable create_lock_unlock_pair is
 * initialized right at startup with a reasonable mutex creator.
 * In non-mt mode, the default value of this variable contains
 * a dummy creator that does not lock anything.
 *)



(**********************************************************************)
(*                          System events                             *)
(**********************************************************************)

(* [group] and [wait_id] are now objects. The structural equality
 * ( = ) compares object IDs if applied to objects, so that this
 * is exactly what we need. It is no longer necessary to manage
 * the IDs ourselves, because the language already manages object IDs.
 *
 * This has also the advantage that groups can now have additional
 * properties.
 *)

class group_object =
  object
    val mutable terminating = false
    method is_terminating = terminating
    method terminate () = terminating <- true
  end

type group = group_object

class wait_object = object end

type wait_id = wait_object

type operation =
    Wait_in of file_descr
  | Wait_out of file_descr
  | Wait_oob of file_descr
  | Wait of wait_id

type event =
    Input_arrived of (group * file_descr)
  | Output_readiness of (group * file_descr)
  | Out_of_band of (group * file_descr)
  | Timeout of (group * operation)
  | Signal
  | Extra of exn

exception Term of group
  (* Extra (Term g) is now the group termination event for g *)

exception Keep_alive
  (* Sometimes used to keep the event system alive *)

type resource = operation * float   (* In/Out/descriptor, timeout value *)

type event_system =
  { mutable sys : event Equeue.t option;
    mutable res : (group * resource * float) list;
    mutable new_res : (group * resource * float) list;
    mutable num_res : int;
    mutable close : (file_descr * (group * (file_descr -> unit))) list;
    mutable abort : (group * (group -> exn -> unit)) list;
    mutable aborting : bool;
    mutable lock : unit -> unit;
    mutable unlock : unit -> unit;
    mutable blocking : bool;
    mutable ctrl_pipe_rd : file_descr;
    mutable ctrl_pipe_wr : file_descr;
    mutable ctrl_pipe_group : group;
    mutable tcl_last_timer : tcl_timer_handler ref option;
    mutable tcl_last_file_handlers :
      (Unix.file_descr, tcl_file_handler_rec) Hashtbl.t;
    mutable tcl_file_io_time : float;
    mutable tcl_file_io_freq : float;
    mutable tcl_attached : bool;
    mutable tcl_runner : event_system -> unit;
    mutable tcl_is_running : bool } 

(* The control pipe:
 * 
 * The control pipe is only used in multi-threaded programs: if thread
 * A adds an event/resource to the event system while thread B runs the
 * system (and blocks). In this case, A must wake up B such that B can
 * react on the changed conditions of the system.
 *
 * The control pipe has a read end and a write end. The read end is added
 * to the watched resources such that when bytes arrive thread B wakes
 * up. Thread A signals changed conditions by writing a single byte into
 * the write end of the control pipe.
 *)



exception Abort of (group * exn)


let setup s es =
  let tref = gettimeofday () in
  let res' =
    List.map (fun (g, r, t0) -> g, r, (if t0 < 0.0 then tref else t0)) es.res
  in
  es.res <- res';
  if res' <> [] then
    let (infiles, outfiles, oobfiles, time) =
      List.fold_left
        (fun (inf, outf, oobf, t) (g, r, t0) ->
           let t' =
             match r with
               _, xt ->
                 if xt < 0.0 then t
                 else
                   let tdelta = max 0.0 (xt -. (tref -. t0)) in
                   if t < 0.0 then tdelta else min t tdelta
           in
           match r with
             Wait_in d, _ -> (d, g) :: inf, outf, oobf, t'
           | Wait_out d, _ -> inf, (d, g) :: outf, oobf, t'
           | Wait_oob d, _ -> inf, outf, (d, g) :: oobf, t'
           | Wait _, _ -> inf, outf, oobf, t')
        ([], [], [], -1.0) es.res
    in
    infiles, outfiles, oobfiles, time
  else [], [], [], -1.0


let queue_events
  s es (infiles, outfiles, oobfiles, time) (infiles', outfiles', oobfiles') =
  let dummy_buf = String.create 1 in
  let deferred_exn = ref None in
  let read_ctrl_pipe () =
    try
      while true do ignore (read es.ctrl_pipe_rd dummy_buf 0 1) done;
      assert false
    with
      Unix_error (EAGAIN, _, _) -> ()
    | Unix_error (EINTR, _, _) as err -> deferred_exn := Some err
  in
  let add constructor group_map descr_list =
    List.iter
      (fun d ->
         let g = List.assoc d group_map in
         if g = es.ctrl_pipe_group then read_ctrl_pipe ()
         else Equeue.add_event s (constructor g d))
      descr_list
  in
  add (fun g d -> Input_arrived (g, d)) infiles infiles';
  add (fun g d -> Output_readiness (g, d)) outfiles outfiles';
  add (fun g d -> Out_of_band (g, d)) oobfiles oobfiles';
  let tref' =
    if infiles' = [] && outfiles' = [] && oobfiles' = [] then
      let res_minimum =
        List.fold_left
          (fun current_minimum (_, (_, xt), t0) ->
             if xt >= 0.0 then min current_minimum (t0 +. xt)
             else current_minimum)
          1E50 es.res
      in
      max res_minimum (gettimeofday ())
    else gettimeofday ()
  in
  let res'' =
    List.map
      (fun (g, r, t0) ->
         let (op, xt) = r in
         if match op with
              Wait_in d ->
                List.mem d infiles' &
                (try List.assoc d infiles = g with
                   Not_found -> false)
            | Wait_out d ->
                List.mem d outfiles' &
                (try List.assoc d outfiles = g with
                   Not_found -> false)
            | Wait_oob d ->
                List.mem d oobfiles' &
                (try List.assoc d oobfiles = g with
                   Not_found -> false)
            | Wait _ -> false
         then
           g, r, tref'
         else if xt >= 0.0 then
           if tref' >= t0 +. xt then
             begin Equeue.add_event s (Timeout (g, op)); g, r, tref' end
           else g, r, t0
         else g, r, t0)
      es.res
  in
  es.res <- res'';
  match !deferred_exn with
    None -> ()
  | Some exn -> raise exn


let create_unix_event_system () =
  let (es_lock, es_unlock) = !create_lock_unlock_pair () in
  let (ctrl_rd, ctrl_wr) =
    if !mt_mode then let (rd, wr) = pipe () in set_nonblock rd; rd, wr
    else stdin, stdin
  in
  let ctrl_g = new group_object in
  let es =
    {sys = None; res = []; new_res = []; num_res = 0; close = []; abort = [];
     aborting = false; lock = es_lock; unlock = es_unlock; blocking = false;
     ctrl_pipe_rd = ctrl_rd; ctrl_pipe_wr = ctrl_wr; ctrl_pipe_group = ctrl_g;
     tcl_last_timer = None; tcl_last_file_handlers = Hashtbl.create 1;
     tcl_file_io_time = 0.0; tcl_file_io_freq = 0.1; tcl_attached = false;
     tcl_runner = (fun _ -> ()); tcl_is_running = false}
  in
  if !mt_mode then es.res <- [ctrl_g, (Wait_in ctrl_rd, -1.0), -1.0];
  let source s =
    es.lock ();
    try
      if not es.tcl_attached then
        begin
          if es.new_res <> [] then
            begin
              es.res <- es.res @ es.new_res;
              es.num_res <- es.num_res + List.length es.new_res;
              es.new_res <- []
            end;
          let (infiles, outfiles, oobfiles, time as watch_tuple) =
            setup s es
          in
          if es.num_res > 0 then
            try
              es.blocking <- true;
              es.unlock ();
              let (infiles', outfiles', oobfiles' as actual_tuple) =
                Unix.select (List.map fst infiles) (List.map fst outfiles)
                  (List.map fst oobfiles) time
              in
              es.lock ();
              es.blocking <- false;
              queue_events s es watch_tuple actual_tuple
            with
              Unix.Unix_error (Unix.EINTR, _, _) ->
                es.lock (); es.blocking <- false; Equeue.add_event s Signal
        end;
      es.unlock ()
    with
      any -> es.unlock (); raise any
  in
  es.sys <- Some (Equeue.create source); es


let protect ues f arg =
  ues.lock ();
  try let r = f arg in ues.unlock (); r with
    any -> ues.unlock (); raise any


let new_group ues = new group_object


let new_wait_id ues = new wait_object


let exists_resource_nolock ues op =
  List.exists (fun (_, (op', _), _) -> op' = op) ues.res ||
  List.exists (fun (_, (op', _), _) -> op' = op) ues.new_res


let exists_resource ues op =
  protect ues (fun () -> exists_resource_nolock ues op) ()


let rec wake_up keep_alive ues =
  if !mt_mode && ues.blocking then
    let s =
      match ues.sys with
        Some s -> s
      | None -> assert false
    in
    try
      if keep_alive then Equeue.add_event s (Extra Keep_alive);
      let buf = String.make 1 'X' in ignore (write ues.ctrl_pipe_wr buf 0 1)
    with
      Unix_error (EINTR, _, _) ->
        Equeue.add_event s Signal; wake_up keep_alive ues


let add_resource ues g (op, t) =
  if g#is_terminating then
    invalid_arg "Unixqueue.add_resource: the group is terminated";
  protect ues
    (fun () ->
       if exists_resource_nolock ues op then ()
       else
         begin
           ues.new_res <- ues.new_res @ [g, (op, t), -1.0]; wake_up true ues
         end)
    ()


let exists_descriptor_nolock ues d =
  let test (_, (op, _), _) =
    match op with
      Wait_in d' -> d = d'
    | Wait_out d' -> d = d'
    | Wait_oob d' -> d = d'
    | Wait _ -> false
  in
  List.exists test ues.res || List.exists test ues.new_res


let exists_descriptor ues = protect ues (exists_descriptor_nolock ues)


let add_close_action ues g (d, a) =
  if g#is_terminating then
    invalid_arg "Unixqueue.add_close_action: the group is terminated";
  protect ues
    (fun () ->
       if exists_descriptor_nolock ues d then
         ues.close <- (d, (g, a)) :: ues.close
       else failwith "add_close_action")
    ()


let add_abort_action ues g a =
  if g#is_terminating then
    invalid_arg "Unixqueue.add_abort_action: the group is terminated";
  protect ues (fun () -> ues.abort <- (g, a) :: ues.abort) ()


let remove_resource_nolock ues g op =
  if g#is_terminating then
    invalid_arg "Unixqueue.remove_resource: the group is terminated";
  let n = ref 0 in
  ues.res <-
    List.filter
      (fun (g', (op', _), _) ->
         let p = g' <> g or op' <> op in if not p then incr n; p)
      ues.res;
  ues.num_res <- ues.num_res - !n;
  ues.new_res <-
    List.filter (fun (g', (op', _), _) -> g' <> g or op' <> op) ues.new_res;
  let sd =
    match op with
      Wait_in d' -> Some d'
    | Wait_out d' -> Some d'
    | Wait_oob d' -> Some d'
    | Wait _ -> None
  in
  match sd with
    Some d ->
      if not ues.aborting then
        let action =
          try Some (snd (List.assoc d ues.close)) with
            Not_found -> None
        in
        begin match action with
          Some a ->
            if not (exists_descriptor_nolock ues d) then
              begin
                a d;
                ues.close <- List.filter (fun (d', _) -> d <> d') ues.close
              end
        | None -> ()
        end
  | None -> ()


let remove_resource ues g = protect ues (remove_resource_nolock ues g)


let add_event_nolock ues e =
  match ues.sys with
    None -> failwith "add_event"
  | Some s -> Equeue.add_event s e; wake_up false ues


let add_event ues = protect ues (add_event_nolock ues)


let add_handler_nolock ues g h =
  if g#is_terminating then
    invalid_arg "Unixqueue.add_handler: the group is terminated";
  let h' an_ues an_es an_e =
    match an_e with
      Extra (Term g') ->
        if g = g' then
          begin add_event_nolock ues an_e; raise Equeue.Terminate end
        else raise Equeue.Reject
    | Extra Keep_alive -> raise Equeue.Reject
    | Input_arrived (g', _) ->
        if g#is_terminating then raise Equeue.Reject;
        if g = g' then h an_ues an_es an_e else raise Equeue.Reject
    | Output_readiness (g', _) ->
        if g#is_terminating then raise Equeue.Reject;
        if g = g' then h an_ues an_es an_e else raise Equeue.Reject
    | Out_of_band (g', _) ->
        if g#is_terminating then raise Equeue.Reject;
        if g = g' then h an_ues an_es an_e else raise Equeue.Reject
    | Timeout (g', _) ->
        if g#is_terminating then raise Equeue.Reject;
        if g = g' then h an_ues an_es an_e else raise Equeue.Reject
    | Signal ->
        if g#is_terminating then raise Equeue.Reject; h an_ues an_es an_e
    | Extra x ->
        if g#is_terminating then raise Equeue.Reject; h an_ues an_es an_e
  in
  match ues.sys with
    None -> failwith "add_handler"
  | Some s -> Equeue.add_handler s (h' ues)


let add_handler ues g = protect ues (add_handler_nolock ues g)


let clear_nolock ues g =
  g#terminate ();
  let n = ref 0 in
  ues.res <-
    List.filter (fun (g', _, _) -> let p = g' <> g in if not p then incr n; p)
      ues.res;
  ues.num_res <- ues.num_res - !n;
  ues.new_res <- List.filter (fun (g', _, _) -> g' <> g) ues.new_res;
  add_event_nolock ues (Extra (Term g));
  ues.close <- List.filter (fun (_, (g', _)) -> g <> g') ues.close;
  ues.abort <- List.filter (fun (g', _) -> g <> g') ues.abort;
  wake_up false ues;
  ()
  

let clear ues = protect ues (clear_nolock ues)


let abort_nolock ues g ex =
  let action =
    try Some (List.assoc g ues.abort) with
      Not_found -> None
  in
  match action with
    Some a ->
      ues.aborting <- true;
      let mistake = ref None in
      begin try a g ex with
        any -> mistake := Some any
      end;
      clear ues g;
      ues.aborting <- false;
      begin match !mistake with
        None -> ()
      | Some m -> raise m
      end
  | None -> ()


let abort ues g = protect ues (abort_nolock ues) g


let run ues =
  let get_sys =
    protect ues
      (fun () ->
         match ues.sys with
           None -> failwith "run"
         | Some s -> s)
  in
  let continue = ref true in
  while !continue do
    continue := false;
    try Equeue.run (get_sys ()) with
      Abort (g, an_exception) ->
        begin match an_exception with
          Equeue.Reject | Equeue.Terminate ->
            failwith "Caught 'Abort' exception with Reject or Terminate exception as argument; this is a programming error"
        | Abort (_, _) ->
            failwith "Caught 'Abort' exception with an 'Abort' exception as argument; this is a programming error"
        | _ -> ()
        end;
        abort ues g an_exception;
        continue := true
  done


let once ues g duration f =
  let id = new_wait_id ues in
  let op = Wait id in
  let handler ues ev e =
    if e = Timeout (g, op) then
      begin remove_resource ues g op; f (); raise Equeue.Terminate end
    else raise Equeue.Reject
  in
  if duration >= 0.0 then
    begin add_resource ues g (op, duration); add_handler ues g handler end;
  ()


let attach_to_tcl_queue es runner = failwith "Unixqueue.attach_to_tcl_queue"

(* The default "implementation". It may be overridden later. *)

(* ---------------------------------------------------------------------- *)

(**********************************************************************)
(*                       Cooperation with Tcl/Tk                      *)
(**********************************************************************)

(* Note:
 * In labltk, there are also bindings for CreateFileHandler. However,
 * these are insufficient: It is not possible to watch the same file
 * for both read and write conditions. I'll keep my own bindings until
 * this is fixed.
 *
 * CreateTimerHandler: The bindings in labltk are ok.
 *)

# 832 "unixqueue.mlp"
# 833 "unixqueue.mlp"
# 871 "unixqueue.mlp"
# 872 "unixqueue.mlp"
# 890 "unixqueue.mlp"
# 908 "unixqueue.mlp"
# 1010 "unixqueue.mlp"
# 1014 "unixqueue.mlp"
# 1033 "unixqueue.mlp"
# 1094 "unixqueue.mlp"
# 1100 "unixqueue.mlp"
# 1192 "unixqueue.mlp"

(*======================================================================
 *
 * $Log: unixqueue.ml,v $
 * Revision 1.1  2003/01/22 08:11:57  uuu
 *
 * Equeue dodane.
 *
 * Revision 1.17  2001/12/15 14:24:36  gerd
 * 	Fix (tcl extension): Only attached queues are set up for
 * "select".
 *
 * Revision 1.16  2001/09/16 00:02:02  gerd
 * 	For multi-threaded applications: The new control pipe is used to
 * wake blocking threads up.
 * 	Follow-up: New resources are now added to the component new_res
 * because this might happen while the other thread blocks. new_res is added
 * to res just before the next cycle.
 * 	Follow-up: The Extra Keep_alive event is used to keep the system
 * running if res = [] and new_res <> [].
 *
 * Revision 1.15  2001/09/05 14:44:59  gerd
 * 	Minor change for TCL extension...
 *
 * Revision 1.14  2001/07/22 20:14:48  gerd
 * 	Removed prerr_endline
 *
 * Revision 1.13  2001/07/22 20:11:48  gerd
 * 	Integrated the TCL extension into the main file by using
 * IFDEF/ENDIF directives.
 * 	There is now support for two TCL extensions:
 * 	- TCL: Uses only labltk timers as primary callbacks. The file
 * event handlers of labltk are not powerful enough to be useful (it is
 * not possible to wait until a file descriptor is able to read _or_
 * write), so they are emulated. It is tried to add as many timer
 * callback as necessary to trace the file events without too much
 * latency. (This code is new.)
 * 	- TCL && TCL_NATIVE: Uses TCL's file event handlers directly
 * (old code).
 * 	There seems to be a problem with TCL: sometimes the wrong
 * timer callback is invoked. I've tried to work around this, but the
 * workaround may be wrong, too (I don't know the reason).
 *
 * Revision 1.12  2001/07/20 19:32:29  gerd
 * 	(See also changes unixqueue.mli rev 1.5)
 * 	By initializing (init_mt) the module it can be enforced that
 * the functions are serialized in a multi-threaded environment.
 * 	groups and wait_ids are now objects.
 * 	Improved the implementation of "clear".
 *
 * Revision 1.11  2000/02/14 19:54:53  gerd
 * 	Bugfix: After 'add_resource' (TCL extension), the TCL handlers
 * were not always updated as necessary. Same problem with 'once'.
 *
 * Revision 1.10  2000/02/14 00:39:05  gerd
 * 	Updated.
 *
 * Revision 1.9  2000/02/13 16:50:13  gerd
 * 	Intermediate version.
 *
 * Revision 1.8  2000/01/31 21:18:24  gerd
 * 	Added restricted thread-safety.
 *
 * Revision 1.7  2000/01/30 21:08:18  gerd
 * 	Fixed the 'clear' function.
 *
 * Revision 1.6  2000/01/30 02:49:12  gerd
 * 	Bugfix: It was possible that events were lost because of
 * rounding errors in floating-point computations.9
 *
 * Revision 1.5  1999/04/12 01:38:49  gerd
 * 	Minor changes/additions.
 *
 * Revision 1.4  1999/04/11 20:37:52  gerd
 * 	Event values now contain the group of the resource created
 * them. The problematic situation was:
 * - event E has been created by resource A for descriptor D
 * - resource A is closed
 * - resource B is opened, and has the same descriptor D
 * - as E has not yet been processed, the event handlers for B think
 *   that E must be handled by them
 * Now it is stored with E by which resource it was created.
 *
 * Revision 1.3  1999/04/11 15:19:30  gerd
 * 	Fixed a bug in 'abort'.
 *
 * Revision 1.2  1999/04/07 16:43:48  gerd
 * 	Improved exception handling: certain 'Abort' events are considered
 * illegal.
 *
 * Revision 1.1  1999/04/03 23:55:09  gerd
 * 	Renamed from 'Sysevent' to 'Unixqueue'.
 * 	Change: introduced 'wait_id' to distinguish between several anonymous
 * timeout events.
 * 	Addition: function 'once'
 *
 *
 *======================================================================
 * OLD LOGS:
 *
 * Revision 1.2  1998/10/04 20:25:28  gerd
 * If the list of resources is empty, no further select() happens.
 * Otherwise would wait forever...
 *
 * Revision 1.1  1998/10/04 16:40:58  gerd
 * First version of sysevent (formerly known as unixext). Simple tests
 * passed.
 *
 * 
 *)
