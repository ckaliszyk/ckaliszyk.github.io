DIR:=Common/Equeue
TARGET:=equeue.$(LIB_SUF)
FILES:=equeue unixqueue_mt unixqueue
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -a -o $@ $^
