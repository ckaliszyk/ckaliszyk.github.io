(* ----------------------------------------------------------------------
 *
 *)


type cclass =
    CData
  | CIgnore
  | CSeparator
  | CIgnoreOrSeparator


let split_string ignoreset ignoreleft ignoreright separators =
  let character_classification =
    let a = Array.create 256 CData in
    let sepchars =
      List.flatten
        (List.map (fun sep -> if sep <> "" then [sep.[0]] else []) separators)
    in
    let ignorechars =
      let l = ref [] in
      for k = 0 to String.length ignoreset - 1 do
        l := ignoreset.[k] :: !l
      done;
      !l
    in
    List.iter (fun c -> a.(Char.code c) <- CSeparator) sepchars;
    List.iter
      (fun c ->
         let code = Char.code c in
         if a.(code) = CSeparator then a.(code) <- CIgnoreOrSeparator
         else a.(code) <- CIgnore)
      ignorechars;
    a
  in
  fun s ->
    let l = String.length s in
    let rec split_over_word i_wordbeg i_wordend i_current =
      if i_current < l then
        let code = Char.code s.[i_current] in
        let cl = character_classification.(code) in
        match cl with
          CData -> fast_skip_word i_wordbeg (i_current + 1)
        | CIgnore -> split_over_word i_wordbeg i_wordend (i_current + 1)
        | _ ->
            let rec find_sep sepl =
              match sepl with
                [] ->
                  if cl = CSeparator then
                    fast_skip_word i_wordbeg (i_current + 1)
                  else split_over_word i_wordbeg i_wordend (i_current + 1)
              | sep :: sepl' ->
                  let lsep = String.length sep in
                  if i_current + lsep <= l & String.sub s i_current lsep = sep
                  then
                    String.sub s i_wordbeg (i_wordend - i_wordbeg) ::
                      split_after_word (i_current + lsep) (i_current + lsep)
                  else find_sep sepl'
            in
            find_sep separators
      else if ignoreright then
        [String.sub s i_wordbeg (i_wordend - i_wordbeg)]
      else [String.sub s i_wordbeg (i_current - i_wordbeg)]
    and split_after_word i_wordbeg i_current =
      if i_current < l then
        let code = Char.code s.[i_current] in
        let cl = character_classification.(code) in
        match cl with
          CData -> fast_skip_word i_current (i_current + 1)
        | CIgnore | CIgnoreOrSeparator ->
            split_after_word i_wordbeg (i_current + 1)
        | CSeparator ->
            let rec find_sep sepl =
              match sepl with
                [] -> fast_skip_word i_wordbeg (i_current + 1)
              | sep :: sepl' ->
                  let lsep = String.length sep in
                  if i_current + lsep < l & String.sub s i_current lsep = sep
                  then
                    "" ::
                      split_after_word (i_current + lsep) (i_current + lsep)
                  else find_sep sepl'
            in
            find_sep separators
      else if i_wordbeg = 0 then []
      else [""]
    and fast_skip_word i_wordbeg i_current =
      if i_current < l - 1 then
        let code1 = Char.code s.[i_current] in
        let cl1 = character_classification.(code1) in
        match cl1 with
          CData ->
            let code2 = Char.code s.[i_current + 1] in
            let cl2 = character_classification.(code2) in
            begin match cl2 with
              CData -> fast_skip_word i_wordbeg (i_current + 2)
            | CIgnore ->
                split_over_word i_wordbeg (i_current + 1) (i_current + 2)
            | _ -> split_over_word i_wordbeg (i_current + 1) (i_current + 1)
            end
        | CIgnore -> split_over_word i_wordbeg i_current (i_current + 1)
        | _ -> split_over_word i_wordbeg i_current i_current
      else split_over_word i_wordbeg i_current i_current
    in
    if ignoreleft then split_after_word 0 0 else split_over_word 0 0 0




(* ======================================================================
 * History:
 *
 * Revision 1.2  1999/07/06 21:32:09  gerd
 * 	Tried to optimize the function; but currently without success.
 * There should be deeper analysis -- on the other hand, splitting seems
 * to be relative fast compared with the Str splitting function.
 * Perhaps the improvements have an effect on machines with bigger caches.
 *
 * Revision 1.1  1999/06/27 23:03:38  gerd
 * 	Initial revision.
 *
 * 
 *)
