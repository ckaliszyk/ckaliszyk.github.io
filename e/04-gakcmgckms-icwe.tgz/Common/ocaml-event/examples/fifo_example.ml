(*
 * Small example program
 *)

let fifo_read event fd event_type =
  print_newline ();

  let buflen = 255 in
  let buf = String.create buflen in 
  match Unix.read fd buf 0 buflen with
    0 -> 
      print_string "Connection closed";
      print_newline ()
  | n -> 
      print_string "Read: ";
      print_string (String.sub buf 0 n);
      print_newline ();
      
      (* Reschedule this event *)
      Event.add event None

let _ =
  let fifo = "event.fifo" in

  Unix.unlink fifo; 
  Unix.mkfifo fifo 0o600;

  let socket = Unix.openfile fifo [ Unix.O_RDWR; Unix.O_NONBLOCK ] 0 in
  let evfifo = Event.create () in

  print_string "Write data to: ";
  print_string fifo;
  print_newline ();
  
  Event.set evfifo socket [Event.READ] false (fifo_read evfifo);
  Event.add evfifo None;

  Event.dispatch ()
    
