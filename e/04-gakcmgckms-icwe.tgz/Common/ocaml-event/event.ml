(***********************************************************************)
(* The OcamlEvent library                                              *)
(*                                                                     *)
(* Copyright 2002, 2003 Maas-Maarten Zeeman. All rights reserved. See  *) 
(* LICENCE for details.                                                *)
(***********************************************************************)

(* $Id: event.ml,v 1.6 2003/09/16 21:54:15 maas Exp $ *)
type event

type event_type =
    TIMEOUT 
  | READ 
  | WRITE
  | SIGNAL 

let int_of_event_type = function
    TIMEOUT -> 0x01
  | READ -> 0x02
  | WRITE -> 0x04
  | SIGNAL -> 0x08

type event_callback = Unix.file_descr -> event_type -> unit

(* Use an internal hashtable to store the callbacks with the event *)  
let table = Hashtbl.create 0

let event_cb event_id fd etype =
  (Hashtbl.find table event_id) fd etype 
  
(* Create an event *)
external create : unit -> event = "oc_create_event"

(* Return the id of an event *)
external event_id : event -> int = "oc_event_id"

(* Set an event (not exported) *)
external cset : event -> Unix.file_descr -> int -> unit = "oc_event_set"

(* Event set *)
let set event fd etype persist (cb : event_callback) =
  let rec int_of_event_type_list flag = function
      h::t -> int_of_event_type_list (flag lor (int_of_event_type h)) t
    | [] -> flag
  in
  let flag = 
    let f = int_of_event_type_list 0 etype in
    if persist then
      f lor 0x10
    else
      f
  in
  Hashtbl.replace table (event_id event) cb;
  cset event fd flag

(* Add an event *)
external add : event -> float option -> unit = "oc_event_add"

(* Del an event  *)
external cdel : event -> unit = "oc_event_del"
let del event =
  Hashtbl.remove table (event_id event);
  cdel event

(* *)
(* Not fully implemented yet *)
external pending : event -> 
  event_type list -> float option -> float option = "oc_event_pending"

(* Process events *)

external dispatch : unit -> unit = "oc_event_dispatch"

type loop_flag = ONCE | NONBLOCK
external loop : loop_flag -> unit = "oc_event_loop"


(* Initialize the event library *)
external init : unit -> unit = "oc_event_init"
let _ = 
  Callback.register "event_cb" event_cb;
  init ()



