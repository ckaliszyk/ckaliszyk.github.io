(***********************************************************************)
(* The OcamlEvent library                                              *)
(*                                                                     *)
(* Copyright 2002, 2003 Maas-Maarten Zeeman. All rights reserved. See  *) 
(* LICENCE for details.                                                *)
(***********************************************************************)

(* $Id: unittest.ml,v 1.5 2003/10/03 20:18:30 maas Exp $ *)

open OUnit

(* Tests the creation of new events *)
let create_event _ =
  let e1 = Event.create () in
  let e2 = Event.create () in 
  "Event should be different" @? (e1 <> e2)

(* Tests if pending can be called with and without the optional float *)
let call_pending x _ =
  let e1 = Event.create() in
  ignore(Event.pending e1 [] x)

(* This is not really a test *)
let call_set _ =
  let e1 = Event.create () in
  print_string "Running call_set";
  Event.set e1 Unix.stderr [Event.WRITE] false 
    (fun fd e -> print_string "yo stderr");
  Event.set e1 Unix.stdout [Event.WRITE] false 
    (fun fd e -> print_string "...yo stdout");
  Event.set e1 Unix.stdin [Event.READ] false 
    (fun fd e -> print_string "event ...stdin");
  Event.add e1 (Some 0.1);
  Event.loop(Event.ONCE)
 
(* Construct the test suite *)
let suite = "event" >::: 
  ["create_event" >:: create_event;
   "call_pending None" >:: call_pending None;
   "call_pending (Some 0.12345555)" >:: call_pending (Some 0.123455555);
   "call_set" >:: call_set;
 ] 

(* Run the tests in the test suite *)
let _ = 
  run_test_tt_main suite
