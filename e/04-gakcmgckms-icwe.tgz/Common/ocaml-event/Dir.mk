DIR:=Common/ocaml-event
TARGET:=event.$(LIB_SUF)
FILES:=event
CFILES:=event_stubs

# Ugly hack
LIBEVENTLIB=libevent.a
LIBEVENTDIR=Common/libevent

${LIBEVENTDIR}/${LIBEVENTLIB}:
	@cd ${LIBEVENTDIR} && ./configure && make

out/${DIR}/${LIBEVENTLIB}: ${LIBEVENTDIR}/${LIBEVENTLIB}
	@cp ${LIBEVENTDIR}/${LIBEVENTLIB} out/Common/ocaml-event

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES}) out/${DIR}/${LIBEVENTLIB}
	${OCAML_COMP} -a -o $@ $^
