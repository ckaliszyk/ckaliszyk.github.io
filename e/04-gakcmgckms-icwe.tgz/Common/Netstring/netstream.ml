(* $Id: netstream.ml,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)


open Netchannels


class type in_obj_stream =
  object
    inherit Netchannels.in_obj_channel
    method block_size : int
    method window : Netbuffer.t
    method want : int -> unit
    method want_another_block : unit -> unit
    method window_length : int
    method window_at_eof : bool
    method skip : int -> unit
  end


class virtual input_methods init_s_netbuf =
  object (self)
    val mutable s_pos = 0
    val mutable s_at_eof = false
    val s_netbuf = init_s_netbuf
    val mutable s_closed = false
    method virtual want : int -> unit
    method virtual want_another_block : unit -> unit
    method virtual window_length : int
    method virtual input : string -> int -> int -> int
    method really_input buf pos len =
      if s_closed then raise Netchannels.Closed_channel;
      let rec read p =
        let l = self#input buf (pos + p) (len - p) in
        let p' = p + l in
        if p' = len then () else if l = 0 then raise End_of_file else read p'
      in
      self#want len; read 0
    method input_char () =
      let s = String.create 1 in self#really_input s 0 1; s.[0]
    method input_byte () =
      let s = String.create 1 in self#really_input s 0 1; int_of_char s.[0]
    method input_line () =
      let rec find_eol () =
        try Netbuffer.index_from s_netbuf 0 '\n' with
          Not_found ->
            if not s_at_eof then
              begin self#want_another_block (); find_eol () end
            else self#window_length
      in
      if s_closed then raise Netchannels.Closed_channel;
      let n = find_eol () in
      if n >= self#window_length then
        begin
          if n = 0 then raise End_of_file;
          let s = String.create n in self#really_input s 0 n; s
        end
      else
        let s = String.create n in
        self#really_input s 0 n; ignore (self#input_char ()); s
    method pos_in = if s_closed then raise Netchannels.Closed_channel; s_pos
  end


class input_stream ?len ?(block_size = 4096) in_ch =
  (object (self)
     val s_channel = (in_ch : in_obj_channel)
     val s_maxlength = len
     val s_blocksize = block_size
     val mutable s_underrun = false
     inherit input_methods (Netbuffer.create block_size)
     initializer
       try self#want_minimum () with
         Buffer_underrun -> s_underrun <- true
     method private debug msg =
       prerr_endline
         (msg ^ ": s_pos=" ^ string_of_int s_pos ^ " s_at_eof=" ^
            string_of_bool s_at_eof ^ " buflen=" ^
            string_of_int (Netbuffer.length s_netbuf) ^ " s_closed=" ^
            string_of_bool s_closed)
     method block_size = s_blocksize
     method window =
       if s_closed then raise Netchannels.Closed_channel; s_netbuf
     method window_length =
       if s_closed then raise Netchannels.Closed_channel;
       Netbuffer.length s_netbuf
     method window_at_eof =
       if s_closed then raise Netchannels.Closed_channel; s_at_eof
     method want_another_block () =
       if s_closed then raise Netchannels.Closed_channel;
       if not s_at_eof then
         let m =
           match s_maxlength with
             None -> s_blocksize
           | Some l -> min (l - s_pos - Netbuffer.length s_netbuf) s_blocksize
         in
         assert (m >= 0);
         let rec read_block k =
           if k < m then
             let n =
               Netbuffer.add_inplace ~len:(m - k) s_netbuf s_channel#input
             in
             if n > 0 then read_block (k + n) else k
           else k
         in
         let n = read_block 0 in s_at_eof <- m = 0 || n < m
     method want n =
       if s_closed then raise Netchannels.Closed_channel;
       while not s_at_eof && Netbuffer.length s_netbuf < n do
         self#want_another_block ()
       done
     method private want_minimum () = self#want s_blocksize
     method skip len =
       if s_closed then raise Netchannels.Closed_channel;
       let rec read len =
         if len > 0 then
           let k = min (Netbuffer.length s_netbuf) len in
           Netbuffer.delete s_netbuf 0 k;
           s_pos <- s_pos + k;
           self#want_minimum ();
           if k > 0 then read (len - k)
       in
       read len
     method input buf pos len =
       if s_closed then raise Netchannels.Closed_channel;
       if s_underrun then begin self#want_minimum (); s_underrun <- false end;
       let len' = min len (Netbuffer.length s_netbuf) in
       Netbuffer.blit s_netbuf 0 buf pos len';
       Netbuffer.delete s_netbuf 0 len';
       s_pos <- s_pos + len';
       begin try self#want_minimum () with
         Buffer_underrun -> s_underrun <- true
       end;
       len'
     method close_in () =
       if s_closed then raise Netchannels.Closed_channel;
       s_channel#close_in ();
       s_closed <- true
     method _rep_in = `Other
   end :
   in_obj_stream)


(*
let find_prefix s1 pos len s2 =
  (* Checks where a non-empty prefix of [s2] occurs at the end of the substring
   * of [s1] beginning at [pos] with length [len]. The function returns 
   * the position [p] of the prefix in [s1]. 
   * The function raises Not_found if it does not find a prefix.
   * POSTCONDITION:
   * - s1[p..p+n-1] = s2[0..n-1] for some biggest n, n <= String.length s2
   *   "The string s1 contains the prefix of s2 at position p, and the
   *   prefix has the maximum length n."
   * - n < String.length s2 ==> p+n = String.length s1
   *   "If the prefix is a proper prefix, it occurs at the end of s1"
   *)
  assert(String.length s2 > 0);
  let l1 = min (String.length s1) (pos+len) in
  let l2 = String.length s2 in
  let s2c0 = s2.[0] in
  let rec check_rec p k =
    k >= l2 || p+k >= l1 || (s1.[p+k] = s2.[k] && check_rec p (k+1)) in
  let rec search_rec p =
    if p >= l1 then raise Not_found;
    let p' = String.index_from s1 p s2c0 in  (* or Not_found *)
    if p' >= l1 then raise Not_found;
    if check_rec p' 0 then
      p'
    else
      search_rec (p'+1)
  in
  search_rec pos
;;
*)


class sub_stream ?len ?delimiter in_stream =
  (object (self)
     val s = (in_stream : in_obj_stream)
     val mutable s_winlen = 0
     val mutable s_del = None
     val s_len = len
     val mutable s_underrun = false
     inherit input_methods (in_stream#window)
     initializer
       begin match delimiter with
         Some "" -> invalid_arg "new Netstream.sub_stream"
       | Some d -> s_del <- Some (d, Netaux.KMP.make_pattern d)
       | None -> s_del <- None
       end;
       begin match s_len with
         Some l -> if l < 0 then invalid_arg "new Netstream.sub_stream"
       | None -> ()
       end;
       try self#want_minimum () with
         Buffer_underrun -> s_underrun <- true
     method block_size = s#block_size
     method window =
       if s_closed then raise Netchannels.Closed_channel; s_netbuf
     method window_length =
       if s_closed then raise Netchannels.Closed_channel; s_winlen
     method window_at_eof =
       if s_closed then raise Netchannels.Closed_channel; s_at_eof
     method private compute_winlen () =
       let ambigous = ref false in
       let w = s#window in
       let wlen = s#window_length in
       let weof = s#window_at_eof in
       begin match s_del with
         None -> s_winlen <- wlen; s_at_eof <- weof
       | Some (d, pat) ->
           let p =
             Netaux.KMP.find_pattern pat ~len:wlen (Netbuffer.unsafe_buffer w)
           in
           if p >= wlen then begin s_winlen <- wlen; s_at_eof <- weof end
           else if p + String.length d > wlen then
             begin
               ambigous := not weof; s_winlen <- wlen; s_at_eof <- weof
             end
           else begin s_winlen <- p; s_at_eof <- true end
       end;
       begin match s_len with
         None -> ()
       | Some l ->
           if l - s_pos < s_winlen then
             begin
               ambigous := false; s_winlen <- l - s_pos; s_at_eof <- true
             end
       end;
       !ambigous
     method want_another_block () =
       if s_closed then raise Netchannels.Closed_channel;
       s#want_another_block ();
       while self#compute_winlen () do s#want_another_block () done
     method want n =
       if s_closed then raise Netchannels.Closed_channel;
       while not s_at_eof && s_winlen < n do self#want_another_block () done
     method private want_minimum () =
       if self#compute_winlen () then self#want_another_block ();
       self#want s#block_size
     method skip len =
       if s_closed then raise Netchannels.Closed_channel;
       let rec read len =
         if len > 0 then
           let k = min s_winlen len in
           s#skip k;
           s_pos <- s_pos + k;
           self#want_minimum ();
           if k > 0 then read (len - k)
       in
       read len
     method input buf pos len =
       if s_closed then raise Netchannels.Closed_channel;
       if s_underrun then begin self#want_minimum (); s_underrun <- false end;
       let len' = min len s_winlen in
       Netbuffer.blit s_netbuf 0 buf pos len';
       s#skip len';
       s_pos <- s_pos + len';
       begin try self#want_minimum () with
         Buffer_underrun -> s_underrun <- true
       end;
       len'
     method close_in () =
       if s_closed then raise Netchannels.Closed_channel;
       s#close_in ();
       s_closed <- true
     method _rep_in = `Other
   end :
   in_obj_stream)


let print_in_obj_stream fmt s =
  Format.fprintf fmt "<NETSTREAM pos_in:%d window_length:%d eof=%b>" s#pos_in
    s#window_length s#window_at_eof

type t = int * in_obj_stream    (* block_size, stream *)

module Deprecated =
  struct
    let create_from_channel ch len block_size =
      let obj_ch = new input_channel ch in
      block_size, new input_stream ?len ~block_size:(2 * block_size) obj_ch
    let create_from_string s =
      let obj_ch = new input_string s in
      let l = String.length s in l, new input_stream ~block_size:l obj_ch
    let block_size (bs, sm) = bs
    let current_length (bs, sm) = sm#pos_in + sm#window_length
    let at_eos (bs, sm) = sm#window_at_eof
    let window_position (bs, sm) = sm#pos_in
    let window_length (bs, sm) = sm#window_length
    let window (bs, sm) = sm#window
    let move (bs, sm) n = sm#skip n
    let want (bs, sm) n = sm#want n
    let want_another_block (bs, sm) = sm#want_another_block ()
    let print_stream (bs, sm) = print_in_obj_stream Format.std_formatter sm
  end


(* ======================================================================
 * History:
 * 
 * $Log: netstream.ml,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.7  2002/11/01 21:28:24  stolpmann
 * 	Fix: ~len is now processed correctly
 *
 * Revision 2.6  2002/10/25 21:29:56  stolpmann
 * 	Fixed: Buffer_underrun exceptions are taken into account.
 *
 * Revision 2.5  2002/03/08 14:02:31  stolpmann
 * 	Fix: The class input_stream now interprets ~len as the length
 * relative to the beginning of the stream, and no longer relative to
 * the beginning of the underlying channel.
 *
 * Revision 2.4  2002/01/14 23:47:45  stolpmann
 * 	Uses now Netaux.KMP to search substrings.
 *
 * Revision 2.3  2002/01/05 19:38:30  stolpmann
 * 	New: class [sub_stream].
 * 	The method [delete] has been renamed into [skip].
 *
 * Revision 2.2  2001/12/28 21:09:24  stolpmann
 * 	New OO interface. The type in_obj_stream extends in_obj_channel,
 * and adds the look-ahead window. The class input_stream is a layer on top
 * of an arbitrary in_obj_channel.
 * 	The implementation of the OO interface looks much more elegant
 * than the old implementation.
 * 	The old interface is still available in the sub module
 * "Deprecated".
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.2  2000/06/24 20:20:33  gerd
 * 	Added the toploop printer.
 *
 * Revision 1.1  2000/04/15 13:07:48  gerd
 * 	Initial revision.
 *
 * 
 *)
