(* $Id: netaux.ml,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

module KMP =
  struct
    type pattern =
      { len : int; p : string; fail : int array; rex : Pcre.regexp }
    let rec delta pat state c =
      if pat.p.[state] = c then state + 1
      else if state = 0 then 0
      else delta pat pat.fail.(state - 1) c
    let make_pattern p =
      let l = String.length p in
      if l = 0 then invalid_arg "Netaux.KMP.make_pattern";
      let rex = Pcre.regexp (Pcre.quote (String.make 1 p.[0])) in
      let pat = {len = l; p = p; fail = Array.make l 0; rex = rex} in
      for n = 0 to l - 2 do
        pat.fail.(n + 1) <- delta pat pat.fail.(n) p.[n]
      done;
      pat
    let run rex len p fail s endpos state pos =
      let rec run_loop state pos =
        if state = len || pos = endpos then state, pos
        else if p.[state] = s.[pos] then run_loop (state + 1) (pos + 1)
        else if state = 0 then run_pcre (pos + 1)
        else let state' = fail.(state - 1) in run_delta p.[state'] state' pos
      and run_delta c state pos =
        if c = s.[pos] then run_loop (state + 1) (pos + 1)
        else if state = 0 then run_loop 0 (pos + 1)
        else let state' = fail.(state - 1) in run_delta p.[state'] state' pos
      and run_pcre pos =
        let pos' =
          try let a = Pcre.pcre_exec ~rex ~pos s in a.(0) with
            Not_found -> endpos
        in
        if pos' < endpos then run_loop 0 pos' else run_loop 0 endpos
      in
      run_loop state pos
    let find_pattern pat ?(pos = 0) ?len s =
      let endpos =
        match len with
          None -> String.length s
        | Some l -> pos + l
      in
      if pos < 0 || endpos > String.length s || pos > endpos then
        invalid_arg "Netaux.KMP.find_pattern";
      let (state, pos) = run pat.rex pat.len pat.p pat.fail s endpos 0 pos in
      pos - state
  end

(* ======================================================================
 * History:
 * 
 * $Log: netaux.ml,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 1.1  2002/01/14 23:47:15  stolpmann
 * 	Initial revision
 *
 * 
 *)
