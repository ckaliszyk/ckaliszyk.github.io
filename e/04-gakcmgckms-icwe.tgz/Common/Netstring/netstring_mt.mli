(* $Id: netstring_mt.mli,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

(* This module initializes the multi-threading mode of 
 * Netstring. You must link it with every application that
 * uses multi-threading.
 * PITFALL: Link this module _directly_ with the executable,
 * _don't_ put this module into a cma archive! This would not work!
 *)


(* ======================================================================
 * History:
 * 
 * $Log: netstring_mt.mli,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.1  2000/06/25 21:15:27  gerd
 * 	Initial revision
 *
 * 
 *)
