(* $Id: netstring_mt.ml,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

(* Initialize multi-threading mode: *)

(* let str_mutex = Mutex.create();; *)
let cgi_mutex = Mutex.create ()
let mappings_mutex = Mutex.create ()

(*
Netstring_str.init_mt
  (fun () -> Mutex.lock str_mutex)
  (fun () -> Mutex.unlock str_mutex);
*)
let _ =
  Cgi.init_mt (fun () -> Mutex.lock cgi_mutex)
    (fun () -> Mutex.unlock cgi_mutex);
  Netmappings.init_mt (fun () -> Mutex.lock mappings_mutex)
    (fun () -> Mutex.unlock mappings_mutex)

(* ======================================================================
 * History:
 * 
 * $Log: netstring_mt.ml,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.2  2001/11/07 00:32:39  stolpmann
 * 	Removed the initialization of Netstring_str.
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.2  2000/08/29 00:45:42  gerd
 * 	Initializing Netmappings, too
 *
 * Revision 1.1  2000/06/25 21:15:27  gerd
 * 	Initial revision
 *
 * 
 *)
