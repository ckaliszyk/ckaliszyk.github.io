type token =
    Lcomment
  | Rcomment
  | Mcomment
  | Ldoctype
  | Rdoctype
  | Mdoctype
  | Lpi
  | Rpi
  | Mpi
  | Lelement of string
  | Lelementend of string
  | Relement
  | Cdata of string
  | Space of int
  | Name of string
  | Is
  | Literal of string
  | Other
  | Eof
val lexeme_skip : Lexing.lexbuf -> int -> string
val lexeme_cut : Lexing.lexbuf -> int -> int -> string
val lexeme_length : Lexing.lexbuf -> int
val __ocaml_lex_tables : Lexing.lex_tables
val scan_document : Lexing.lexbuf -> token
val __ocaml_lex_scan_document_rec : Lexing.lexbuf -> int -> token
val scan_special : Lexing.lexbuf -> token
val __ocaml_lex_scan_special_rec : Lexing.lexbuf -> int -> token
val scan_comment : Lexing.lexbuf -> token
val __ocaml_lex_scan_comment_rec : Lexing.lexbuf -> int -> token
val scan_doctype : Lexing.lexbuf -> token
val __ocaml_lex_scan_doctype_rec : Lexing.lexbuf -> int -> token
val scan_pi : Lexing.lexbuf -> token
val __ocaml_lex_scan_pi_rec : Lexing.lexbuf -> int -> token
val scan_element : Lexing.lexbuf -> token
val __ocaml_lex_scan_element_rec : Lexing.lexbuf -> int -> token
val scan_no_space : Lexing.lexbuf -> token
val __ocaml_lex_scan_no_space_rec : Lexing.lexbuf -> int -> token
val scan_skip_element : Lexing.lexbuf -> token
val __ocaml_lex_scan_skip_element_rec : Lexing.lexbuf -> int -> token
