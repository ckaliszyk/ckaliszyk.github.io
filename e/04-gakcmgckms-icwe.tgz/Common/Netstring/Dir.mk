DIR:=Common/Netstring
TARGET:=netstring.$(LIB_SUF)
FILES:=netstring_pcre netstring_str netbuffer\
	netaux netchannels netdate \
	netmappings netconversion \
	netencoding netstream \
	mimestring cgi \
	nethtml_scanner nethtml\
	neturl \
	netaddress \
	netmime netsendmail
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -a -o $@ $^
