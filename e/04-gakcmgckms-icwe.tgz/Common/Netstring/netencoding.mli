(* $Id: netencoding.mli,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

(**********************************************************************)
(* Several encodings important for the net                            *)
(**********************************************************************)


(**********************************************************************)
(* Base 64 encoding                                                   *)
(**********************************************************************)

(* See RFC 2045 for a description of Base 64 encoding. *)

(* THREAD-SAFETY: 
 * All Base64 functions are reentrant and thus thread-safe.
 *)

module Base64 :
  sig
    val encode :
      ?pos: int -> ?len: int -> ?linelength: int -> ?crlf: bool -> string ->
        string
    val url_encode :
      ?pos: int -> ?len: int -> ?linelength: int -> ?crlf: bool -> string ->
        string
    val decode :
      ?pos: int -> ?len: int -> ?url_variant: bool -> ?accept_spaces: bool ->
        string -> string
    class encoding_pipe :
      ?linelength: int -> ?crlf: bool -> unit -> Netchannels.pipe
    class decoding_pipe :
      ?url_variant: bool -> ?accept_spaces: bool -> unit -> Netchannels.pipe
    module Deprecated :
      sig
        val encode_substring :
          string -> pos:int -> len:int -> linelength:int -> crlf:bool ->
            string
        val decode_ignore_spaces : string -> string
        val decode_substring :
          string -> pos:int -> len:int -> url_variant:bool ->
            accept_spaces:bool -> string
      end
  end

(**********************************************************************)
(* Quoted printable encoding                                          *)
(**********************************************************************)

(* See RFC 2045.
 * This implementation assumes that the encoded string has a text MIME
 * type. Because of this, the characters CR and LF are never protected 
 * by hex tokens; they are copied literally to the output string.
 *)

(* THREAD-SAFETY: 
 * All QuotedPrintable functions are reentrant and thus thread-safe.
 *)

module QuotedPrintable :
  sig
    val encode : ?pos: int -> ?len: int -> string -> string
    val decode : ?pos: int -> ?len: int -> string -> string
    class encoding_pipe : unit -> Netchannels.pipe
    class decoding_pipe : unit -> Netchannels.pipe
    module Deprecated :
      sig
        val encode_substring : string -> pos:int -> len:int -> string
        val decode_substring : string -> pos:int -> len:int -> string
      end
  end

(**********************************************************************)
(* Q encoding                                                         *)
(**********************************************************************)

(* See RFC 2047. 
 * The functions behave similar to those of QuotedPrintable. 
 *)

(* THREAD-SAFETY: 
 * All Q functions are reentrant and thus thread-safe.
 *)

module Q :
  sig
    val encode : ?pos: int -> ?len: int -> string -> string
    val decode : ?pos: int -> ?len: int -> string -> string
    module Deprecated :
      sig
        val encode_substring : string -> pos:int -> len:int -> string
        val decode_substring : string -> pos:int -> len:int -> string
      end
  end

(**********************************************************************)
(* B encoding                                                         *)
(**********************************************************************)

(* The B encoding of RFC 2047 is the same as Base64. *)


(**********************************************************************)
(* URL-encoding                                                       *)
(**********************************************************************)

(* Encoding/Decoding within URLs:
 *
 * The following two functions perform the '%'-substitution for
 * characters that may otherwise be interpreted as metacharacters.
 *
 * According to: RFC 1738, RFC 1630
 *
 * Option ~plus: This option has been added because there are some
 * implementations that do not map ' ' to '+', for example Javascript's
 * escape function. The default is "true" because this is the RFC-
 * compliant definition.
 *)

(* THREAD-SAFETY:
 * The Url functions are thread-safe.
 *)

module Url :
  sig
    val decode : ?plus: bool -> string -> string
    val encode : ?plus: bool -> string -> string
    val mk_url_encoded_parameters : (string * string) list -> string
    val dest_url_encoded_parameters : string -> (string * string) list
  end


(**********************************************************************)
(* HTMLization                                                        *)
(**********************************************************************)

(* Encodes characters that need protection by converting them to
 * entity references. E.g. "<" is converted to "&lt;".
 * As the entities may be named, there is a dependency on the character
 * set. 
 *)

(* THREAD-SAFETY:
 * The Html functions are thread-safe.
 *)

module Html :
  sig
    val encode_from_latin1 : string -> string
    val decode_to_latin1 : string -> string
    val unsafe_chars_html4 : string
    val encode :
      in_enc:Netconversion.encoding -> ?out_enc: Netconversion.encoding ->
        ?prefer_name: bool -> ?unsafe_chars: string -> unit -> string ->
        string
    type entity_set = [ `Html | `Xml | `Empty ]
    val decode :
      in_enc:Netconversion.encoding -> out_enc:Netconversion.encoding ->
        ?lookup: (string -> string) -> ?subst: (int -> string) ->
        ?entity_base: entity_set -> unit -> string -> string
  end


(* ======================================================================
 * History:
 * 
 * $Log: netencoding.mli,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.6  2002/07/03 01:16:38  stolpmann
 * 	New: Html.encode and Html.decode
 *
 * Revision 2.5  2002/02/02 23:54:06  stolpmann
 * 	Improvements for mbox mailboxes.
 *
 * Revision 2.4  2002/01/14 01:04:58  stolpmann
 * 	Netencoding.Url.mk/dest_url_encoded_parameters: These functions
 * now reside here and not in Cgi.
 *
 * Revision 2.3  2002/01/04 22:46:08  stolpmann
 * 	New: QuotedPrintable.encoding_pipe, and decoding_pipe.
 * 	The deprecated functions of [QuotedPrintable] and [Q] have been
 * moved into modules [Deprecated].
 *
 * Revision 2.2  2002/01/04 21:59:35  stolpmann
 * 	New: Base64.encoding_pipe, and Base64.decoding_pipe.
 * 	The deprecated Base64 functions have been moved into a
 * module [Deprecated].
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.5  2001/08/30 19:45:43  gerd
 * 	Module Url: added the option ~plus
 *
 * Revision 1.4  2000/06/25 22:34:43  gerd
 * 	Added labels to arguments.
 *
 * Revision 1.3  2000/06/25 21:15:48  gerd
 * 	Checked thread-safety.
 *
 * Revision 1.2  2000/03/03 01:08:29  gerd
 * 	Added Netencoding.Html functions.
 *
 * Revision 1.1  2000/03/02 01:14:48  gerd
 * 	Initial revision.
 *
 * 
 *)
