(* $Id: netaux.mli,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

(* Auxiliary stuff *)


module KMP :
  sig
    type pattern
    val make_pattern : string -> pattern
    val find_pattern : pattern -> ?pos: int -> ?len: int -> string -> int
  end

(* ======================================================================
 * History:
 * 
 * $Log: netaux.mli,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 1.1  2002/01/14 23:47:15  stolpmann
 * 	Initial revision
 *
 * 
 *)
