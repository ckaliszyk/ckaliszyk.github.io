(* $Id: netstring_top.ml,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)


let exec s =
  let l = Lexing.from_string s in
  let ph = !(Toploop.parse_toplevel_phrase) l in
  assert (Toploop.execute_phrase false Format.err_formatter ph)

(* Install the printers: *)

let _ = exec "#install_printer Mimestring.print_s_param;;"
let _ = exec "#install_printer Neturl.print_url;;"
let _ = exec "#install_printer Netbuffer.print_buffer;;"
let _ = exec "#install_printer Netstream.print_in_obj_stream;;"
let _ = exec "#install_printer Netstream.Deprecated.print_stream;;"
let _ = exec "#install_printer Cgi.print_argument;;"

(* ======================================================================
 * History:
 * 
 * $Log: netstring_top.ml,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.2  2002/01/12 18:35:46  stolpmann
 * 	Updated the toploop printers.
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.2  2000/06/25 22:34:43  gerd
 * 	Added labels to arguments.
 *
 * Revision 1.1  2000/06/24 20:20:58  gerd
 * 	Initial revision.
 *
 * 
 *)
