(* $Id: netstring_top.mli,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

(* You may load this module into the toploop in order to install
 * the printers for the various opaque data types of Netstring.
 *)

(* ======================================================================
 * History:
 * 
 * $Log: netstring_top.mli,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.1  2000/06/25 22:53:45  gerd
 * 	Initial revision.
 *
 * 
 *)
