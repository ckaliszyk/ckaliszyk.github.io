(* $Id: netmappings.ml,v 1.1 2003/01/15 12:36:21 uuu Exp $
 * ----------------------------------------------------------------------
 *
 *)

type from_uni_list =
    U_nil
  | U_single of (int * int)
  | U_double of (int * int * int * int)
  | U_list of (int * int) list

let to_unicode = Hashtbl.create 50

let from_unicode = Hashtbl.create 50

let f_lock = ref (fun () -> ())
let f_unlock = ref (fun () -> ())

let lock () = !f_lock ()
let unlock () = !f_unlock ()

let init_mt new_f_lock new_f_unlock =
  f_lock := new_f_lock; f_unlock := new_f_unlock

(* ======================================================================
 * History:
 * 
 * $Log: netmappings.ml,v $
 * Revision 1.1  2003/01/15 12:36:21  uuu
 *
 * CeK mega update
 * Mati
 * Radzio
 * eLeL
 * i wog�le.
 * PO Lab u Krzeszczakowskiego,
 * Zmniejszyli�my znak be�ciak...
 * jest lepszak...
 *
 * Revision 2.2  2002/06/23 19:47:29  stolpmann
 * 	Improved representation of character mappings.
 *
 * Revision 2.1  2001/09/14 14:22:34  stolpmann
 * 	Initial revision (sourceforge)
 *
 *
 * ======================================================================
 * Revision 1.1  2000/08/28 23:17:54  gerd
 * 	Initial revision.
 *
 * 
 *)
