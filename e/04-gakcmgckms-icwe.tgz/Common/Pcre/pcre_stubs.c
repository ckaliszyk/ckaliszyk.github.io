/* pcre_intf.c

   Copyright (C) 1999-2002  Markus Mottl
   email: markus@oefai.at
   WWW:   http://www.oefai.at/~markus

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* $Id: pcre_stubs.c,v 1.1 2003/01/15 12:36:21 uuu Exp $ */

#if defined(_WIN32) && defined(_DLL)
#  define PCREextern __declspec(dllexport) 
#else
#  define PCREextern
#endif

#include <caml/mlvalues.h>
#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/fail.h>
#include <caml/callback.h>

#include "pcre.h"

typedef const unsigned char * chartables;  /* Type of chartable sets */

/* Cache for exceptions */
static value *pcre_exc_Not_found     = NULL;  /* Exception [Not_found] */
static value *pcre_exc_BadPattern    = NULL;  /* Exception [BadPattern] */
static value *pcre_exc_InternalError = NULL;  /* Exception [InternalError] */

/* Cache for polymorphic variants */
static value var_Start_only;   /* Variant [`Start_only] */
static value var_ANCHORED;     /* Variant [`ANCHORED] */
static value var_Char;         /* Variant [`Char char] */
static value var_Not_studied;  /* Variant [`Not_studied] */
static value var_Studied;      /* Variant [`Studied] */
static value var_Optimal;      /* Variant [`Optimal] */

/* Fetchs the named OCaml-values + caches them and
   calculates + caches the variant hash values */
void pcre_init_caml_names()
{
  pcre_exc_Not_found     = caml_named_value("Pcre.Not_found");
  pcre_exc_BadPattern    = caml_named_value("Pcre.BadPattern");
  pcre_exc_InternalError = caml_named_value("Pcre.InternalError");

  var_Start_only         = hash_variant("Start_only");
  var_ANCHORED           = hash_variant("ANCHORED");
  var_Char               = hash_variant("Char");
  var_Not_studied        = hash_variant("Not_studied");
  var_Studied            = hash_variant("Studied");
  var_Optimal            = hash_variant("Optimal");
}

/* Finalizing deallocation function for chartable sets */
static void pcre_dealloc_tables(value val)
{ (pcre_free)((void *) Field(val, 1)); }

/* Finalizing deallocation function for compiled regular expressions */
static void pcre_dealloc_pattern(value val)
{
  void *extra = (void *) Field(val,2);
  (pcre_free)((void *) Field(val, 1));
  if (extra != NULL) (pcre_free)(extra);
}

/* Raises exceptions which take two arguments */
static void raise_with_two_args(value tag, value arg1, value arg2)
{
  value exc;

  /* Protects tag, arg1 and arg2 from being reclaimed by the garbage
     collector when the exception value is allocated */
  Begin_roots3(tag, arg1, arg2);
    exc = alloc_small(3, 0);
    Field(exc, 0) = tag;
    Field(exc, 1) = arg1;
    Field(exc, 2) = arg2;
  End_roots();

  mlraise(exc);
}

/* Makes OCaml-string from PCRE-version */
value pcre_version_wrapper() { return copy_string((char *) pcre_version()); }

/* Makes compiled regular expression from compilation options, an optional
   value of chartables and the pattern string */
value pcre_compile_wrapper(value options, value table_val, value regexp)
{
  value result;  /* Final result -> value of type [regexp] */
  const char *error = NULL;  /* pointer to possible error message */
  int error_offset = 0;  /* offset in the pattern at which error occurred */

  /* If table_val = [None] then pointer to tables is NULL, otherwise
     set it to the appropriate value */
  chartables tables =
    (table_val == Val_int(0)) ? NULL
                              : (chartables) Field(Field(table_val, 0), 1);

  /* Compiles the pattern */
  pcre *pattern = pcre_compile(String_val(regexp),
                               Int_val(options),
                               &error, &error_offset, tables);

  /* Raises appropriate exception [BadPattern] if the pattern could not
     be compiled */
  if (pattern == NULL) raise_with_two_args(*pcre_exc_BadPattern,
                                           copy_string((char *) error),
                                           Val_int(error_offset));

  /* Finalized value: GC will do a full cycle every 500 regexp allocations
     (one regexp consumes in average probably less than 100 bytes ->
     maximum of 50000 bytes unreclaimed regexps) */
  result = alloc_final(4, pcre_dealloc_pattern, 100, 50000);

  /* Field[1]: compiled regular expression (Field[0] is finalizing
     function! See above!) */
  Field(result, 1) = (value) pattern;

  /* Field[2]: extra information about pattern when it has been studied
     successfully */
  Field(result, 2) = (value) NULL;

  /* Field[3]: If 0 -> pattern has not yet been studied
                  1 -> pattern has already been studied */
  Field(result, 3) = 0;

  return result;
}

/* Studies a pattern */
value pcre_study_wrapper(value pat)
{
  /* If it has not yet been studied */
  if (! (int) Field(pat, 3)) {
    const char *error = NULL;
    pcre_extra *extra = pcre_study((pcre *) Field(pat, 1), 0, &error);
    if (error != NULL) invalid_argument((char *) error);
    Field(pat, 2) = (value) extra;
    ++Field(pat, 3);
  }

  return pat;
}

/* Performs the call to the pcre_fullinfo function. */
static value pcre_fullinfo_wrapper(value pat, int what, void *where)
{
  return pcre_fullinfo((pcre *) Field(pat, 1), (pcre_extra *) Field(pat, 2),
                       what, where);
}

/* Generic wrapper for getting integer results from pcre_fullinfo. */
static value pcre_info_int_wrapper(value pat, int what)
{
  int options;
  const int ret = pcre_fullinfo_wrapper(pat, what, &options);
  if (ret != 0) raise_with_string(*pcre_exc_InternalError, "pcre_int_wrapper");
  return Val_int(options);
}

/* Some wrappers for info-functions... */

value pcre_options_wrapper(value pat)
{ return pcre_info_int_wrapper(pat, PCRE_INFO_OPTIONS); }

value pcre_size_wrapper(value pat)
{ return pcre_info_int_wrapper(pat, PCRE_INFO_SIZE); }

value pcre_capturecount_wrapper(value pat)
{ return pcre_info_int_wrapper(pat, PCRE_INFO_CAPTURECOUNT); }

value pcre_backrefmax_wrapper(value pat)
{ return pcre_info_int_wrapper(pat, PCRE_INFO_BACKREFMAX); }

value pcre_firstchar_wrapper(value pat)
{
  int firstchar;
  value v_firstchar;

  const int ret = pcre_fullinfo_wrapper(pat, PCRE_INFO_FIRSTCHAR, &firstchar);

  if (ret != 0) raise_with_string(*pcre_exc_InternalError,
                                  "pcre_firstchar_wrapper");

  switch (firstchar) {
    case -1 : v_firstchar = var_Start_only; break;  /* [`Start_only] */
    case -2 : v_firstchar = var_ANCHORED; break;    /* [`ANCHORED] */
    default :
      if (firstchar < 0 )  /* Should not happen */
        raise_with_string(*pcre_exc_InternalError, "pcre_firstchar_wrapper");

      /* Allocates the non-constant constructor [`Char of char] and fills
         in the appropriate value. */
      v_firstchar = alloc_small(2, 0);
      Field(v_firstchar, 0) = var_Char;
      Field(v_firstchar, 1) = Val_int(firstchar);
  }

  return v_firstchar;
}

value pcre_firsttable_wrapper(value pat)
{
  const unsigned char *ftable;
  value result, res_str;
  char *ptr;

  int i, ret =
    pcre_fullinfo_wrapper(pat, PCRE_INFO_FIRSTTABLE, (void *) &ftable);

  if (ret != 0) raise_with_string(*pcre_exc_InternalError,
                                  "pcre_firsttable_wrapper");

  if (ftable == NULL) return Val_int(0);  /* [None] */

  Begin_roots2(pat, res_str);
    /* Allocates [Some string] from firsttable */
    res_str = alloc_string(32);
    result = alloc_small(1, 1);
    Field(result, 0) = res_str;
    ptr = String_val(res_str);
    for (i = 0; i <= 31; ++i) { *ptr = *ftable; ++ptr; ++ftable; }
  End_roots();

  return result;
}

value pcre_lastliteral_wrapper(value pat)
{
  int lastliteral;
  value result;
  const int ret = pcre_fullinfo_wrapper(pat, PCRE_INFO_LASTLITERAL,
                                        &lastliteral);

  if (ret != 0) raise_with_string(*pcre_exc_InternalError,
                                  "pcre_lastliteral_wrapper");

  if (lastliteral == -1) return Val_int(0);  /* [None] */
  if (lastliteral < 0) raise_with_string(*pcre_exc_InternalError,
                                         "pcre_lastliteral_wrapper");

  /* Allocates [Some char]. */
  result = alloc_small(1, 1);
  Field(result, 0) = Val_int(lastliteral);

  return result;
}

value pcre_study_stat_wrapper(value pat)
{
  /* Generates the appropriate constant constructor [`Optimal] or
     [`Studied] if pattern has already been studied */
  if (Field(pat, 3))
    return ((pcre_extra *) Field(pat, 2) == NULL)
             ? var_Optimal : var_Studied;

  return var_Not_studied;  /* otherwise [`Not_studied] */
}

/* Executes a pattern match with runtime options, a regular expression, a
   string offset, a string length, a subject string, a number of subgroup
   offsets and an offset vector */
value pcre_exec_wrapper(value v_opt, value v_pat, value v_offset,
                        value v_subject, value v_subgroups2, value v_ovec)
{
  const int offset = Int_val(v_offset), len = string_length(v_subject);
  if (offset > len || offset < 0)
    invalid_argument("Pcre.pcre_exec_wrapper: illegal offset");
  {
    const pcre *code = (pcre *) Field(v_pat, 1);  /* Compiled pattern */
    const pcre_extra *extra = (pcre_extra *) Field(v_pat, 2);  /* Extra info */
    const char *subject = String_val(v_subject);  /* Subject string */

    int subgroups2 = Int_val(v_subgroups2);
    const int subgroups1 = subgroups2 >> 1;
    const int subgroups2_1 = subgroups2 - 1;

    int *ovector = (int *) &Field(v_ovec, 0);
    const int *ovec_source = ovector + subgroups2_1;
    long int *ovec_dest = (long int *) ovector + subgroups2_1;

    /* Performs the match */
    const int ret = pcre_exec(code, extra, subject, len, offset, Int_val(v_opt),
                              ovector, subgroups1 + subgroups2);

    if (ret < 0) {
      if (ret == -1) raise_constant(*pcre_exc_Not_found);  /* [Not_found] */

      /* Should not happen */
      raise_with_string(*pcre_exc_InternalError, "pcre_exec_wrapper");
    }

    /* Converts offsets from C-integers to OCaml-Integers.
       This is a bit tricky, because there are 32- and 64-bit platforms
       around and OCaml chooses the larger possibility for representing
       integers when available (also in arrays) - not so the PCRE. */
    while (subgroups2--) {
      *ovec_dest = Val_int(*ovec_source);
      --ovec_source; --ovec_dest;
    }

    return Val_unit;
  }
}

/* Byte-code hook for pcre_exec_wrapper.
   Needed, because there are more than 5 arguments */
value pcre_exec_wrapper_bc(value *argv, int argn)
{
  return pcre_exec_wrapper(argv[0], argv[1], argv[2], argv[3],
                           argv[4], argv[5]);
}

/* Generates a new set of chartables for the current locale (see man
   page of PCRE */
value pcre_maketables_wrapper()
{
  /* GC will do a full cycle every 100 table set allocations
     (one table set consumes 864 bytes -> maximum of 86400 bytes
     unreclaimed table sets) */
  const value result = alloc_final(2, pcre_dealloc_tables, 864, 86400);
  Field(result, 1) = (value) pcre_maketables();
  return result;
}

/* Wraps around the isspace-function */
value pcre_isspace_wrapper(value v_c)
{
  return Val_bool(isspace(Int_val(v_c)));
}
