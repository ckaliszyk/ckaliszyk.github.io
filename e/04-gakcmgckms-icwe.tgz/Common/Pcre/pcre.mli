(*
   PCRE-OCAML - Perl Compatibility Regular Expressions for OCaml

   Copyright (C) 1999-2002  Markus Mottl
   email: markus@oefai.at
   WWW:   http://www.oefai.at/~markus

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*)

(* $Id: pcre.mli,v 1.1 2003/01/15 12:36:21 uuu Exp $ *)

(** Perl Compatibility Regular Expressions *)


(** {6 Exceptions} *)

(** [BadPattern (msg, pos)] gets raised when the regular expression is
    malformed. The reason is in [msg], the position of the error in the
    pattern in [pos]. *)
exception BadPattern of string * int

(** [InternalError msg] gets raised when the C-library exhibits undefined
    behaviour. The reason is in [msg]. *)
exception InternalError of string


(** {6 Compilation and runtime flags and their conversion functions} *)

type icflag
and irflag
and cflag =
  [ `CASELESS
  | `MULTILINE
  | `DOTALL
  | `EXTENDED
  | `ANCHORED
  | `DOLLAR_ENDONLY
  | `EXTRA
  | `UNGREEDY
  | `UTF8 ]

val cflags : cflag list -> icflag
  (** [cflags cflag_list] converts a list of compilation flags to
      their internal representation. *)

val cflag_list : icflag -> cflag list
  (** [cflag_list cflags] converts internal representation of
      compilation flags to a list. *)

(** Runtime flags *)
type rflag = [ `ANCHORED | `NOTBOL | `NOTEOL | `NOTEMPTY ]

val rflags : rflag list -> irflag
  (** [rflags rflag_list] converts a list of runtime flags to
      their internal representation. *)

val rflag_list : irflag -> rflag list
  (** [rflag_list rflags] converts internal representation of
      runtime flags to a list. *)


(** {6 Information on patterns} *)

(** Information on matching of "first chars" in patterns *)
type firstchar_info = [ `Char of char | `Start_only | `ANCHORED ]

(** Information on the study status of patterns *)
type study_stat = [ `Not_studied | `Studied | `Optimal ]

type regexp (** Compiled regular expressions *)

(** [options regexp] @return compilation flags of [regexp]. *)
external options : regexp -> icflag = "pcre_options_wrapper"

(** [size regexp] @return memory size of [regexp]. *)
external size : regexp -> int = "pcre_size_wrapper"

(** [capturecount regexp] @return number of capturing subpatterns in
    [regexp]. *)
external capturecount : regexp -> int = "pcre_capturecount_wrapper"

(** [backrefmax regexp] @return number of highest backreference in [regexp]. *)
external backrefmax : regexp -> int = "pcre_backrefmax_wrapper"

(** [firstchar regexp] @return firstchar info on [regexp]. *)
external firstchar : regexp -> firstchar_info = "pcre_firstchar_wrapper"

(** [firsttable regexp] @return some 256-bit (32-byte) fixed set table in
    form of a string for [regexp] if available, [None] otherwise. *)
external firsttable : regexp -> string option = "pcre_firsttable_wrapper"

(** [lastliteral regexp] @return some last matching character of [regexp]
    if available, [None] otherwise. *)
external lastliteral : regexp -> char option = "pcre_lastliteral_wrapper"

(** [study_stat regexp] @return study status of [regexp]. *)
external study_stat :
  regexp -> study_stat = "pcre_study_stat_wrapper" "noalloc"


(** {6 Compilation of patterns} *)

type chtables (** Alternative set of char tables for pattern matching *)

external maketables : unit -> chtables = "pcre_maketables_wrapper"
  (** Generates new set of char tables for the current locale. *)

val regexp :
  ?study: bool -> ?iflags: icflag -> ?flags: cflag list ->
    ?chtables: chtables -> string -> regexp
  (** [regexp ?study ?iflags ?flags ?chtables pattern] compiles [pattern]
      with [flags] when given, with [iflags] otherwise, and with char
      tables [chtables]. If [study] is true, then the resulting regular
      expression will be studied.

      @param study default = true
      @param iflags default = no extra flags
      @param flags default = ignored
      @param chtables default = builtin char tables

      @return the regular expression.

      For detailed documentation on how you can specify PERL-style
      regular expressions (= patterns), please consult PERL-manuals.
      @see <http://www.perl.com> www.perl.com *)

val quote : string -> string
  (** [quote str] @return the quoted string of [str]. *)


(** {6 Matching of patterns and subpattern extraction} *)

type substrings (** Information on substrings after pattern matching *)

val num_of_subs : substrings -> int
  (** [num_of_subs substrings] @return number of strings in [substrings]
      (whole match inclusive). *)

val get_substring : substrings -> int -> string
  (** [get_substring substrings n] @return the [n]th substring
      (0 is whole match) of [substrings] or the empty string if the
      corresponding subpattern did not capture a substring.

      @raise Invalid_argument if [n] is not in the range of the number
      of substrings. *)

val get_substring_ofs : substrings -> int -> int * int
  (** [get_substring_ofs substrings n] @return the offset tuple of the
      [n]th substring of [substrings] (0 is whole match).

      @raise Invalid_argument if [n] is not in the range of the number
             of substrings.
      @raise Not_found if the corresponding subpattern did not capture
             a substring. *)

val get_substrings : ?full_match: bool -> substrings -> string array
  (** [get_substrings ?full_match substrings] @return the array of
      substrings in [substrings]. It includes the full match at index 0
      when [full_match] is [true], the captured substrings only when it
      is [false]. If a subpattern did not capture a substring, the empty
      string is returned in the corresponding position instead.

      @param full_match default = true *)

val pcre_exec :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> string -> int array
  (** [pcre_exec ?iflags ?flags ?rex ?pat ?pos subj] @return an array of
      offsets that describe the position of matched subpatterns in
      the string [subj] starting at position [pos] with pattern [pat]
      when given, regular expression [rex] otherwise. The array also
      contains additional workspace needed by the match engine. Uses
      [flags] when given, the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0

      @raise Not_found if pattern does not match. *)

val exec :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> string -> substrings
  (** [exec ?iflags ?flags ?rex ?pat ?pos subj] @return substring
      information on string [subj] starting at position [pos] with pattern
      [pat] when given, regular expression [rex] otherwise.  Uses [flags]
      when given, the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0

      @raise Not_found if pattern does not match. *)

val exec_all :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> string -> substrings array
  (** [exec_all ?iflags ?flags ?rex ?pat ?pos subj] @return an array
      of substring information of all matching substrings in string
      [subj] starting at position [pos] with pattern [pat] when given,
      regular expression [rex] otherwise.  Uses [flags] when given,
      the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0

      @raise Not_found if pattern does not match. *)

val next_match :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> substrings -> substrings
  (** [next_match ?iflags ?flags ?rex ?pat ?pos substrs] @return substring
      information on the match that follows on the last match denoted by
      [substrs], jumping over [pos] characters (also backwards!), using
      pattern [pat] when given, regular expression [rex] otherwise. Uses
      [flags] when given, the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0

      @raise Not_found if pattern does not match.
      @raise Invalid_arg if [pos] let matching start outside of
             the subject string. *)

val extract :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?full_match: bool -> string -> string array
  (** [extract ?iflags ?flags ?rex ?pat ?pos ?full_match subj] @return
      the array of substrings that match [subj] starting at position
      [pos], using pattern [pat] when given, regular expression [rex]
      otherwise. Uses [flags] when given, the precompiled [iflags]
      otherwise. It includes the full match at index 0 when [full_match]
      is [true], the captured substrings only when it is [false].

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param full_match default = true

      @raise Not_found if pattern does not match. *)

val extract_all :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?full_match: bool -> string -> string array array
  (** [extract_all ?iflags ?flags ?rex ?pat ?pos ?full_match subj] @return
      an array of arrays of all matching substrings that match [subj]
      starting at position [pos], using pattern [pat] when given,
      regular expression [rex] otherwise. Uses [flags] when given,
      the precompiled [iflags] otherwise. It includes the full match
      at index 0 of the extracted string arrays when [full_match] is
      [true], the captured substrings only when it is [false].

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param full_match default = true

      @raise Not_found if pattern does not match. *)

val pmatch :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> string -> bool
  (** [pmatch ?iflags ?flags ?rex ?pat ?pos subj] @return [true] if [subj]
      is matched by pattern [pat] when given, regular expression [rex]
      otherwise, starting at position [pos]. Uses [flags] when given,
      the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param full_match default = true *)


(** {6 String substitution} *)

(** Information on substitution patterns *)
type substitution

val subst : string -> substitution
  (** [subst str] converts the string [str] representing a
      substitution pattern to the internal representation

      The contents of the substitution string [str] can be normal text
      mixed with any of the following (mostly as in PERL):

      - {e $\[0-9\]+}  - a "$" immediately followed by an arbitrary number.
                       "$0" stands for the name of the executable, any other
                       number for the n-th backreference.
      - {e $&}       - the whole matched pattern
      - {e $`}       - the text before the match
      - {e $'}       - the text after the match
      - {e $+}       - the last group that matched
      - {e $$}       - a single "$"
      - {e $!}       - delimiter which does not appear in the substitution.
                       Can be used to part "$[0-9]+" from an immediately
                       following other number. *)

val replace :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?itempl: substitution -> ?templ: string -> string -> string
  (** [replace ?iflags ?flags ?rex ?pat ?pos ?itempl ?templ subj] replaces
      all substrings of [subj] matching pattern [pat] when given, regular
      expression [rex] otherwise, starting at position [pos] with the
      substitution string [templ] when given, [itempl] otherwise. Uses
      [flags] when given, the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param itempl default = empty string
      @param templ default = ignored

      @raise Failure if there are backreferences to nonexistent subpatterns. *)

val qreplace :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?templ: string -> string -> string
  (** [qreplace ?iflags ?flags ?rex ?pat ?pos ?templ subj] replaces all
      substrings of [subj] matching pattern [pat] when given, regular
      expression [rex] otherwise, starting at position [pos] with the
      string [templ]. Uses [flags] when given, the precompiled [iflags]
      otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param templ default = ignored *)

val substitute_substrings :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> subst:(substrings -> string) -> string -> string
  (** [substitute_substrings ?iflags ?flags ?rex ?pat ?pos ~subst subj]
      replaces all substrings of [subj] matching pattern [pat] when given,
      regular expression [rex] otherwise, starting at position [pos]
      with the result of function [subst] applied to the substrings
      of the match. Uses [flags] when given, the precompiled [iflags]
      otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param templ default = ignored *)

val substitute :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> subst:(string -> string) -> string -> string
  (** [substitute ?iflags ?flags ?rex ?pat ?pos ~subst subj] replaces
      all substrings of [subj] matching pattern [pat] when given,
      regular expression [rex] otherwise, starting at position [pos]
      with the result of function [subst] applied to the match. Uses
      [flags] when given, the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param templ default = ignored *)

val replace_first :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?itempl: substitution -> ?templ: string -> string -> string
  (** [replace_first ?iflags ?flags ?rex ?pat ?pos ?itempl ?templ subj]
      replaces the first substring of [subj] matching pattern [pat] when
      given, regular expression [rex] otherwise, starting at position
      [pos] with the substitution string [templ] when given, [itempl]
      otherwise. Uses [flags] when given, the precompiled [iflags]
      otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param itempl default = empty string
      @param templ default = ignored

      @raise Failure if there are backreferences to nonexistent subpatterns. *)

val qreplace_first :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?templ: string -> string -> string
  (** [qreplace_first ?iflags ?flags ?rex ?pat ?pos ?templ subj] replaces
      the first substring of [subj] matching pattern [pat] when given,
      regular expression [rex] otherwise, starting at position [pos]
      with the string [templ]. Uses [flags] when given, the precompiled
      [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param templ default = ignored *)

val substitute_substrings_first :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> subst:(substrings -> string) -> string -> string
  (** [substitute_substrings_first ?iflags ?flags ?rex ?pat ?pos ~subst subj]
      replaces the first substring of [subj] matching pattern [pat] when
      given, regular expression [rex] otherwise, starting at position
      [pos] with the result of function [subst] applied to the substrings
      of the match. Uses [flags] when given, the precompiled [iflags]
      otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0 *)

val substitute_first :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> subst:(string -> string) -> string -> string
  (** [substitute_first ?iflags ?flags ?rex ?pat ?pos ~subst subj]
      replaces the first substring of [subj] matching pattern [pat] when
      given, regular expression [rex] otherwise, starting at position
      [pos] with the result of function [subst] applied to the match. Uses
      [flags] when given, the precompiled [iflags] otherwise.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0 *)


(** {6 Splitting} *)

val split :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?max: int -> string -> string list
  (** [split ?iflags ?flags ?rex ?pat ?pos ?max subj] splits [subj]
      into a list of at most [max] strings, using as delimiter pattern
      [pat] when given, regular expression [rex] otherwise, starting at
      position [pos].  Uses [flags] when given, the precompiled [iflags]
      otherwise. If [max] is zero, trailing empty fields are stripped. If
      it is negative, it is treated as arbitrarily large. If neither [pat]
      nor [rex] are specified, leading whitespace will be stripped! Should
      behave exactly as in PERL.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param max default = 0 *)

val asplit :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?max: int -> string -> string array
  (** [asplit ?iflags ?flags ?rex ?pat ?pos ?max subj] same as
      {!Pcre.split} but @return an array instead of a list. *)

(** Result of a {!Pcre.full_split} *)
type split_result =
    Text of string
  | Delim of string
  | Group of int * string
  | NoGroup               (** Unmatched subgroup *)

val full_split :
  ?iflags: irflag -> ?flags: rflag list -> ?rex: regexp -> ?pat: string ->
    ?pos: int -> ?max: int -> string -> split_result list
  (** [full_split ?iflags ?flags ?rex ?pat ?pos ?max subj] splits [subj]
      into a list of at most [max] elements of type "split_result", using
      as delimiter pattern [pat] when given, regular expression [rex]
      otherwise, starting at position [pos].  Uses [flags] when given,
      the precompiled [iflags] otherwise. If [max] is zero, trailing
      empty fields are stripped. If it is negative, it is treated as
      arbitrarily large. Should behave exactly as in PERL.

      @param iflags default = no extra flags
      @param flags default = ignored
      @param rex default = matches whitespace
      @param pat default = ignored
      @param pos default = 0
      @param max default = 0 *)


(** {6 Version information} *)

val version : string  (** Version of the PCRE-C-library *)


(** {6 Additional convenience functions} *)

val foreach_line : ?ic: in_channel -> (string -> unit) -> unit
  (** [foreach_line ?ic f] applies [f] to each line in inchannel [ic] until
      the end-of-file is reached.

      @param ic default = stdin *)


val foreach_file : string list -> (string -> in_channel -> unit) -> unit
  (** [foreach_file filenames f] opens each file in the list [filenames]
      for input and applies [f] to each filename and the corresponding
      channel. Channels are closed after each operation (even when
      exceptions occur - they get reraised afterwards!). *)


(** {6 {b UNSAFE STUFF - USE WITH CAUTION!}} *)

external unsafe_pcre_exec :
  irflag -> regexp -> int -> string -> int -> int array ->
    unit = "pcre_exec_wrapper_bc" "pcre_exec_wrapper"
  (** [unsafe_pcre_exec flags rex pos subject subgroup_offsets offset_vector].
      You should read the C-source to know what happens.
      If you do not understand it - {b don't use this function!} *)

val make_ovector : regexp -> int * int array
  (** [make_ovector regexp] calculates the tuple (subgroups2, ovector)
      which is the number of subgroup offsets and the offset array. *)
