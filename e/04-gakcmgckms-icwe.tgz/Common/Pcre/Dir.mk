DIR:=Common/Pcre
TARGET:=pcre.$(LIB_SUF)
FILES:=pcre
CFILES:=pcre_stubs

EXTERN:=get maketables pcre study pcreposix
EXTERN:=$(patsubst %,${DIR}/lib/%.o,${EXTERN})

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -a -o $@ $^ ${EXTERN}
