(* $Id: http_client.ml,v 1.1.1.1 2004/07/12 17:35:09 gozdal Exp $
 * ----------------------------------------------------------------------
 *
 *)

(* Reference documents:
 * RFC 2068, 2616:      HTTP 1.1
 * RFC 2069, 2617:      Digest Authentication
 *)


(* TODO:
 * - Minor problem: if there is no user/password given for a realm, the client
 *   initiates a second request although this request is senseless.
 *)

open Unix

let listrm = List.remove_assoc
  (* This is Ocaml-2.02. In 2.01, use List.remove *)

exception Header_is_incomplete
exception Body_is_incomplete
exception Body_maybe_complete

exception Bad_message of string

exception Http_error of (int * string)
exception Http_protocol of exn
exception No_reply

(* Internally used exceptions: *)

exception No_exception    (* serves as a guard *)
exception Abort_on_protocol_error
exception Broken_pipe


type auth_method =
    Auth_basic of string
  | Auth_digest of (string * string * string * string)  (* realm, nonce,
							 * opaque, stale *)

type token =
    Word of string
  | Special of char


type secret = unit

type 'message_class how_to_reconnect =
    Send_again
  | Request_fails
  | Inquire of ('message_class -> bool)

type 'message_class how_to_redirect =
    Redirect
  | Do_not_redirect
  | Redirect_inquire of ('message_class -> bool)


let better_unix_error f arg =
  try f arg with
    Unix_error (e, syscall, param) ->
      let error = error_message e in
      if param = "" then failwith error else failwith (param ^ ": " ^ error)


let rec syscall f =
  try f () with
    Unix.Unix_error (Unix.EINTR, _, _) -> syscall f


let string_of_token_list l =
  String.concat ", "
    (List.map
       (function
          Word w -> w
        | Special c -> "'" ^ String.make 1 c ^ "'")
       l)

(* Parsing suitable for most header lines. See RFC 2068. *)

let parse_header_value v =
  let is_control c = let code = Char.code c in code < 32 || code = 127 in
  let is_special c =
    c = '(' || c = ')' || c = '<' || c = '>' or c = '@' || c = ',' ||
    c = ';' || c = ':' or c = '\\' || c = '\"' || c = '/' || c = '[' or
    c = ']' || c = '?' || c = '{' || c = '}' or c = '\t' || c = ' ' || c = '='
  in
  let l = String.length v in
  let rec parse_quoted k word =
    if k < l then
      let c = v.[k] in
      if c = '\"' then k, word
      else if c = '\\' then
        if k < l - 1 then
          parse_quoted (k + 2) (word ^ String.make 1 v.[k + 1])
        else failwith "http_client: cannot parse header line"
      else parse_quoted (k + 1) (word ^ String.make 1 c)
    else failwith "http_client: cannot parse header line"
  in
  let rec parse k word =
    if k < l then
      let c = v.[k] in
      if c <> '\"' && (is_control c || is_special c) then
        if c = ' ' || c = '\t' then
          (if word <> "" then [Word word] else []) @ parse (k + 1) ""
        else
          (if word <> "" then [Word word] else []) @ [Special c] @
            parse (k + 1) ""
      else if c = '\"' then
        let (k', word') = parse_quoted (k + 1) "" in
        (if word <> "" then [Word word] else []) @ [Word word'] @
          parse (k' + 1) ""
      else parse (k + 1) (word ^ String.make 1 c)
    else []
  in
  let p = parse 0 "" in p


let hex_digits =
  [| '0'; '1'; '2'; '3'; '4'; '5'; '6'; '7'; '8'; '9'; 'a'; 'b'; 'c'; 'd';
     'e'; 'f' |]

let encode_hex s =
  let l = String.length s in
  let t = String.make (2 * l) ' ' in
  for n = 0 to l - 1 do
    let x = Char.code s.[n] in
    t.[2 * n] <- hex_digits.(x lsr 4); t.[2 * n + 1] <- hex_digits.(x land 15)
  done;
  t


type synchronization =
    Sync_with_handshake_before_request_body of float
  | Sync
  | Pipeline of int


type http_options =
  { synchronization : synchronization;
    maximum_connection_failures : int;
    maximum_message_errors : int;
    inhibit_persistency : bool;
    connection_timeout : float;
    number_of_parallel_connections : int;
    verbose_status : bool;
    verbose_request_header : bool;
    verbose_response_header : bool;
    verbose_request_contents : bool;
    verbose_response_contents : bool;
    verbose_connection : bool }

(**********************************************************************)
(***                          BUFFERS                               ***)
(**********************************************************************)

(* Similar to Buffer, but may be accessed in a more efficient way. *)

module B = Netbuffer

type buffer_type = B.t


(**********************************************************************)
(***                  THE MESSAGE CONTAINER                         ***)
(**********************************************************************)

(* The class 'message' represents the logical view on messages. A message
 * consists of
 * - a set of header attributes and a message body intended
 *   to be sent to the server (the request)
 * - a set of header attributes and a message body returned from the
 *   server (the reply)
 * 
 * The class has methods helping to transform the request into a 
 * sequence of octets (bytes) and to interpret a stream of octets as 
 * reply.
 *
 * The class is virtual because an auxiliary method needed to form the
 * request depends on the type of the HTTP request ("HTTP method"). This
 * method, 'prepare', is defined in the subclasses 'get', 'post', 'put' etc.
 *)


class virtual message =
  object (self)
    val mutable host = ""
    val mutable port = 80
    val mutable path = ""
    val mutable request = ""
    val mutable request_uri = ""
    val mutable request_method = ""
    val mutable header = []
    val mutable no_proxy = false
    val mutable using_proxy = false
    val mutable body = ""
    val mutable received = B.create 1
    val mutable received_header = []
    val mutable received_entity = 0
    val mutable received_contents = ""
    val mutable status_code = 0
    val mutable status_text = ""
    val mutable status_version = ""
    val mutable served = false
    val mutable reconnect_mode = (Request_fails : message how_to_reconnect)
    val mutable redirect_mode = (Do_not_redirect : message how_to_redirect)
    val mutable error_counter = 0
    val mutable error_exception = No_exception
    method virtual prepare : bool -> unit
    method using_proxy = using_proxy
    method is_served = served
    method set_served (_ : secret) = served <- true
    method set_unserved (_ : secret) =
      served <- false; error_counter <- 0; error_exception <- No_exception
    method get_host () = host
    method get_port () = port
    method get_uri () =
      let http_prefix =
        "http://" ^ host ^
          (if port = 80 then "" else ":" ^ string_of_int port)
      in
      match request_uri with
        "*" -> http_prefix
      | "" -> assert false
      | path when path.[0] = '/' -> http_prefix ^ path
      | full_uri -> full_uri
    method get_req_body () = body
    method get_request (_ : secret) = request
    method get_req_header () = header
    method assoc_req_header name = List.assoc name header
    method assoc_multi_req_header name =
      List.map snd (List.filter (fun (n, _) -> n = name) header)
    method set_req_header name0 value =
      let name = String.lowercase name0 in
      let rec set l =
        match l with
          [] -> [name, value]
        | (n, v) :: l' ->
            if name = n then (name, value) :: l' else (n, v) :: set l'
      in
      header <- set header
    method get_req_uri () = request_uri
    method get_req_method () = request_method
    method get_resp_header () =
      if error_exception = No_exception then received_header
      else raise (Http_protocol error_exception)
    method assoc_resp_header name =
      if error_exception = No_exception then List.assoc name received_header
      else raise (Http_protocol error_exception)
    method assoc_multi_resp_header name =
      if error_exception = No_exception then
        List.map snd (List.filter (fun (n, _) -> n = name) received_header)
      else raise (Http_protocol error_exception)
    method get_resp_body () =
      if error_exception = No_exception then
        let (_, code, _) = self#dest_status () in
        if code >= 200 && code < 300 then received_contents
        else raise (Http_error (code, received_contents))
      else raise (Http_protocol error_exception)
    method dump_header prefix h =
      List.iter (fun (n, v) -> prerr_endline (prefix ^ n ^ ": " ^ v)) h
    method no_proxy () = no_proxy <- true
    method is_proxy_allowed () = not no_proxy
    method get_reconnect_mode = reconnect_mode
    method set_reconnect_mode m = reconnect_mode <- m
    method get_redirect_mode = redirect_mode
    method set_redirect_mode m = redirect_mode <- m
    method get_error_counter () = error_counter
    method set_error_counter () n = error_counter <- n
    method set_error_exception () x = error_exception <- x
    method set_response response p_init_header =
      received <- response;
      error_exception <- No_exception;
      if p_init_header then
        begin
          status_code <- 0; received_header <- []; received_entity <- 0
        end
    method init_query (_ : secret) query =
      try
        let (h, pt, ph) = Http_client_aux.match_query query in
        host <- h;
        port <- pt;
        if String.length ph >= 1 then
          if ph.[0] <> '/' then failwith "http_client: bad URL";
        path <- ph
      with
        Not_found -> failwith "http_client: bad URL"
    method private set_request use_proxy use_asterisk req =
      self#set_req_header "host" (host ^ ":" ^ string_of_int port);
      request_method <- req;
      reconnect_mode <-
        begin match req with
          "GET" | "HEAD" -> Send_again
        | _ -> Request_fails
        end;
      redirect_mode <-
        begin match req with
          "GET" | "HEAD" -> Redirect
        | _ -> Do_not_redirect
        end;
      if use_proxy then
        let query = "http://" ^ host ^ ":" ^ string_of_int port ^ path in
        request_uri <- query
      else
        request_uri <-
          if path = "" then if use_asterisk then "*" else "/" else path;
      request <- req ^ " " ^ request_uri ^ " HTTP/1.1";
      using_proxy <- use_proxy
    method dest_status () =
      if error_exception = No_exception then
        if status_code <> 0 then status_version, status_code, status_text
        else
          let nl = B.index_from received 0 '\n' in
          let status_line = B.sub received 0 nl in
          let (version, code, text) =
            try Http_client_aux.match_status status_line with
              Not_found ->
                raise (Bad_message ("Bad status line: " ^ status_line))
          in
          status_version <- version;
          status_code <- code;
          status_text <- text;
          status_version, status_code, status_text
      else raise (Http_protocol error_exception)
    method decode_header (_ : secret) =
      try
        if received_header = [] then
          let first_nl = B.index_from received 0 '\n' in
          ignore (self#dest_status ());
          let (header, length) =
            self#decode_header_at () received (first_nl + 1)
          in
          received_header <- header; received_entity <- first_nl + length + 1
      with
        Not_found -> raise Header_is_incomplete
    method decode_header_at (_ : secret) message position =
      let length = ref 0 in
      let decode_line line =
        try Http_client_aux.match_header_line line with
          Not_found -> raise (Bad_message "Bad header line")
      in
      let rec get_header pos prefix =
        let nl =
          try B.index_from message pos '\n' with
            Not_found -> raise Header_is_incomplete
        in
        let line =
          if nl > pos && (B.unsafe_buffer message).[nl - 1] = '\r' then
            B.sub message pos (nl - pos - 1)
          else B.sub message pos (nl - pos)
        in
        if line = "" then
          begin
            length := nl + 1 - position;
            if prefix <> "" then [decode_line prefix] else []
          end
        else if List.mem line.[0] [' '; '\t'] then
          let line_length = String.length line in
          let rec substring_non_space i =
            if i < line_length then
              match line.[i] with
                ' ' | '\t' -> substring_non_space (i + 1)
              | _ -> String.sub line i (line_length - i)
            else ""
          in
          let transformed_line = " " ^ substring_non_space 0 in
          get_header (nl + 1) (prefix ^ transformed_line)
        else
          let h = if prefix <> "" then [decode_line prefix] else [] in
          h @ get_header (nl + 1) line
      in
      assert (position <= B.length message);
      let lines = get_header position "" in
      List.flatten
        (List.map (fun (n, v) -> if n = "" then [] else [n, v]) lines),
      !length
    method
      decode_body
      (_ : secret)
      verbose_response_header
      verbose_response_contents
      =
      let received_length = B.length received in
      let rec chunks pos =
        assert (pos <= received_length);
        let nl =
          try B.index_from received pos '\n' with
            Not_found ->
              raise (Bad_message "Cannot decode chunk; LF not found")
        in
        let length_line = B.sub received pos (nl - pos) in
        let length =
          try
            let hexnum = Http_client_aux.match_hex length_line in
            int_of_string ("0x" ^ hexnum)
          with
            _ -> raise (Bad_message "Cannot decode chunk; bad hex number")
        in
        if length = 0 then
          let (footer, _) =
            try self#decode_header_at () received (nl + 1) with
              Header_is_incomplete -> raise (Bad_message "Incomplete footer")
          in
          if verbose_response_header then
            self#dump_header "HTTP Footer " footer;
          received_header <- received_header @ footer;
          []
        else
          let k = nl + 1 + length in
          let pos' =
            try
              if k < received_length then
                match (B.unsafe_buffer received).[k] with
                  '\r' ->
                    if k + 1 < received_length then
                      begin
                        if (B.unsafe_buffer received).[k + 1] <> '\n' then
                          raise Not_found;
                        k + 2
                      end
                    else raise Not_found
                | '\n' -> k + 1
                | _ -> raise Not_found
              else raise Not_found
            with
              Not_found ->
                raise (Bad_message "Cannot decode chunk; missing CRLF")
          in
          B.sub received (nl + 1) length :: chunks pos'
      in
      let transfer_encoding =
        String.lowercase
          (try List.assoc "transfer-encoding" received_header with
             Not_found -> "")
      in
      begin match transfer_encoding with
        "chunked" ->
          assert (received_entity <= B.length received);
          received_contents <- String.concat "" (chunks received_entity)
      | "" ->
          let no_body_expected =
            request_method = "HEAD" || status_code = 204 || status_code = 304
          in
          let length =
            if no_body_expected then 0
            else
              try
                int_of_string (List.assoc "content-length" received_header)
              with
                Not_found -> B.length received - received_entity
              | _ -> raise (Bad_message "Bad Content-Length header field")
          in
          if length > B.length received - received_entity then
            raise (Bad_message "Message does not match Content-Length");
          received_contents <- B.sub received received_entity length;
          received <- B.create 1
      | _ ->
          raise
            (Bad_message
               ("Unknown transfer encoding '" ^ transfer_encoding ^ "'"))
      end;
      if verbose_response_contents then
        prerr_endline ("HTTP Response:\n" ^ received_contents)
    method received_body_is_complete (_ : secret) =
      let body_length =
        self#body_is_complete () received_header received received_entity
      in
      received_entity, body_length
    method body_is_complete (_ : secret) header message body_pos =
      let message_length = B.length message in
      assert (body_pos <= message_length);
      let rec chunks pos =
        assert (pos <= message_length);
        let nl =
          try B.index_from message pos '\n' with
            Not_found -> raise Body_is_incomplete
        in
        let length_line = B.sub message pos (nl - pos) in
        let length =
          try
            let hexnum = Http_client_aux.match_hex length_line in
            int_of_string ("0x" ^ hexnum)
          with
            _ -> raise (Bad_message "Cannot decode chunk; bad hex number")
        in
        if length = 0 then
          let (footer, footer_length) =
            try self#decode_header_at () message (nl + 1) with
              Header_is_incomplete -> raise Body_is_incomplete
          in
          nl + 1 + footer_length - body_pos
        else
          let k = nl + 1 + length in
          let pos' =
            if k < message_length then
              match (B.unsafe_buffer message).[k] with
                '\r' ->
                  if k + 1 < message_length then
                    begin
                      if (B.unsafe_buffer message).[k + 1] <> '\n' then
                        raise
                          (Bad_message "Cannot decode chunk; missing CRLF");
                      k + 2
                    end
                  else raise Body_is_incomplete
              | '\n' -> k + 1
              | _ -> raise (Bad_message "Cannot decode chunk; missing CRLF")
            else raise Body_is_incomplete
          in
          chunks pos'
      in
      let transfer_encoding =
        String.lowercase
          (try List.assoc "transfer-encoding" header with
             Not_found -> "")
      in
      let beginning = body_pos in
      match transfer_encoding with
        "chunked" -> chunks beginning
      | "" ->
          let length =
            if request_method = "HEAD" then 0
            else
              try int_of_string (List.assoc "content-length" header) with
                Not_found -> raise Body_maybe_complete
              | _ -> raise (Bad_message "Bad Content-Length header field")
          in
          if length > B.length message - beginning then
            raise Body_is_incomplete;
          length
      | _ ->
          raise
            (Bad_message
               ("Unknown transfer encoding '" ^ transfer_encoding ^ "'"))
  end


(******** SUBCLASSES IMPLEMENTING HTTP METHODS ************************)

class get the_query =
  object (self)
    inherit message
    val query = the_query
    initializer self#init_query () query
    method prepare use_proxy = self#set_request use_proxy false "GET"
  end


class trace the_query max_hops =
  object (self)
    inherit message
    val query = the_query
    val hops = max_hops
    initializer self#init_query () query
    method prepare use_proxy =
      self#set_request use_proxy false "TRACE";
      self#set_req_header "max-forwards" (string_of_int hops)
  end


class options the_query =
  object (self)
    inherit message
    val query = the_query
    initializer self#init_query () query
    method prepare use_proxy = self#set_request use_proxy true "OPTIONS"
  end


class head the_query =
  object (self)
    inherit message
    val query = the_query
    initializer self#init_query () query
    method prepare use_proxy = self#set_request use_proxy false "HEAD"
  end


class post the_query the_params =
  object (self)
    inherit message
    val query = the_query
    val params = the_params
    initializer self#init_query () query
    method prepare use_proxy =
      self#set_request use_proxy false "POST";
      self#set_req_header "content-type" "application/x-www-form-urlencoded";
      let s = List.map (fun (n, v) -> n ^ "=" ^ Cgi.encode v) params in
      body <- String.concat "&" s
  end


class post_raw the_query the_contents =
  object (self)
    inherit message
    val query = the_query
    val cont = the_contents
    initializer self#init_query () query
    method prepare use_proxy =
      self#set_request use_proxy false "POST"; body <- cont
  end


class put the_query the_contents =
  object (self)
    inherit message
    val query = the_query
    val cont = the_contents
    initializer self#init_query () query
    method prepare use_proxy =
      self#set_request use_proxy false "PUT"; body <- cont
  end


class delete the_query =
  object (self)
    inherit message
    val query = the_query
    initializer self#init_query () query
    method prepare use_proxy = self#set_request use_proxy false "DELETE"
  end


(**********************************************************************)
(***                  AUTHENTICATION METHODS                        ***)
(**********************************************************************)

(* Authentication methods specify the behaviour of the client in the 
 * case the server requires authorization.
 *)


class basic_auth_method =
  object (self)
    val mutable userdb = []
    val mutable current_realm = ""
    val mutable current_host = ""
    val mutable current_port = -1
    method name = "basic"
    method set_realm realm user password =
      userdb <- (realm, (user, password)) :: listrm realm userdb
    method get_credentials () = List.assoc current_realm userdb
    method www_authenticate (req : message) param_toks =
      let p_alist = self#scan_params param_toks in
      let get n =
        try List.assoc n p_alist with
          Not_found -> ""
      in
      current_realm <- get "realm";
      current_host <- req#get_host ();
      current_port <- req#get_port ()
    method set_authorization (req : message) name_authorization =
      if req#get_host () <> current_host or req#get_port () <> current_port
      then
        raise Not_found;
      let (user, password) = self#get_credentials () in
      let basic_cookie = Netencoding.Base64.encode (user ^ ":" ^ password) in
      let cred = "Basic " ^ basic_cookie in
      req#set_req_header name_authorization cred
    method update (req : message) (param_toks : token list) = ()
    method private scan_params p =
      let rec scan p =
        match p with
          [] -> []
        | Word name :: Special '=' :: Word value :: p' ->
            begin match p' with
              Special ',' :: p'' -> (name, value) :: scan p''
            | [] -> [name, value]
            | _ -> failwith "error scanning header parameters"
            end
        | _ -> failwith "error scanning header parameters"
      in
      scan p
  end


class digest_auth_method =
  object (self)
    inherit basic_auth_method
    val mutable current_nonce = ""
    val mutable current_opaque = ""
    method name = "digest"
    method www_authenticate req param_toks =
      let p_alist = self#scan_params param_toks in
      let get n =
        try List.assoc n p_alist with
          Not_found -> ""
      in
      let algorithm = get "algorithm" in
      if algorithm = "MD5" || algorithm = "" then
        begin
          current_realm <- get "realm";
          current_nonce <- get "nonce";
          current_opaque <- get "opaque";
          current_host <- req#get_host ();
          current_port <- req#get_port ()
        end
    method set_authorization req name_authorization =
      if req#get_host () <> current_host or req#get_port () <> current_port
      then
        raise Not_found;
      let h s = encode_hex (Digest.substring s 0 (String.length s)) in
      let (user, password) = self#get_credentials () in
      let uri = req#get_req_uri () in
      let a1 = user ^ ":" ^ current_realm ^ ":" ^ password in
      let a2 = req#get_req_method () ^ ":" ^ uri in
      let response = h (h a1 ^ ":" ^ current_nonce ^ ":" ^ h a2) in
      let digest_response =
        "Digest username=\"" ^ user ^ "\", realm=\"" ^ current_realm ^
          "\", nonce=\"" ^ current_nonce ^ "\", uri=\"" ^ uri ^
          "\", response=\"" ^ response ^ "\", opaque=\"" ^ current_opaque ^
          "\""
      in
      req#set_req_header name_authorization digest_response
    method update req param_toks =
      let p_alist = self#scan_params param_toks in
      let get n =
        try List.assoc n p_alist with
          Not_found -> ""
      in
      let nextnonce = get "nextnonce" in
      if nextnonce <> "" then current_nonce <- nextnonce
  end


(**********************************************************************)
(***           THE BUFFER FOR THE REPLY BEING RECEIVED              ***)
(**********************************************************************)

(* The class 'recv_buffer' is a queue of octets which can be filled by
 * a Unix.read call at its end, and from which octets can be removed
 * at its beginning ("consuming octets").
 * There is also functionality to remove 1XX responses at the beginning
 * of the buffer, and to interpret the beginning of the buffer as HTTP
 * status line.
 * The idea of the buffer is that octets can be added at the end of the
 * buffer while the beginning of the buffer is interpreted as the beginning
 * of the next message. Once enough octets have been added that the message
 * is complete, it is removed (consumed) from the buffer, and the possibly
 * remaining octets are the beginning of the following message.
 *)


class recv_buffer fd =
  object (self)
    val fd = fd
    val io_buf = String.create 8192
    val mutable contents = B.create 8192
    val mutable eof = false
    val mutable timeout = false
    method unix_read () =
      if not eof && not timeout then
        let n =
          syscall (fun () -> Unix.read fd io_buf 0 (String.length io_buf))
        in
        if n = 0 then eof <- true else B.add_sub_string contents io_buf 0 n
    method set_timeout = timeout <- true
    method contents = contents
    method eof = eof
    method timeout = timeout
    method consume n = B.delete contents 0 n
    method drop_'continue'_responses =
      let c100 = ref false in
      let n = ref 0 in
      try
        while true do
          let nl = B.index_from contents 0 '\n' in
          let line = B.sub contents 0 nl in
          let (version, code, text) = Http_client_aux.match_status line in
          if code >= 100 && code < 200 then
            let rec search_empty_line pos =
              let pos_lineend = B.index_from contents pos '\n' in
              if pos = pos_lineend or
                 pos + 1 = pos_lineend &&
                 (B.unsafe_buffer contents).[pos] = '\r'
              then
                pos_lineend + 1
              else search_empty_line (pos_lineend + 1)
            in
            if code = 100 then c100 := true;
            let length_of_continue_response = search_empty_line (nl + 1) in
            self#consume length_of_continue_response; incr n
          else raise Not_found
        done;
        assert false
      with
        Not_found -> !c100, !n
    method status_line =
      let nl = B.index_from contents 0 '\n' in
      let line = B.sub contents 0 nl in
      let triple = Http_client_aux.match_status line in triple, nl + 1
  end

(**********************************************************************)
(***                PROTOCOL STATE OF A SINGLE MESSAGE              ***)
(**********************************************************************)

(* The class 'message_transport' is a container for the message and the
 * associated protocol state, and defines the methods to send
 * the request, and to receive the reply.
 * The protocol state stored here mainly controls the send and receive
 * buffers (e.g. how many octets have already been sent? Are the octets
 * received so far already a complete message or not?)
 *)


type message_state =
    Unprocessed
  | Sending
  | Waiting
  | Receiving
  | Complete


class message_transport (m : message) (f_done : message -> unit) the_options =
  object (self)
    val mutable state = Unprocessed
    val indicate_done = f_done
    val msg = m
    val mutable string_to_send = ""
    val mutable send_position = 0
    val mutable header_length = 0
    val mutable auth_required = false
    val mutable verbose_status = the_options.verbose_status
    val mutable verbose_request_header = the_options.verbose_request_header
    val mutable verbose_response_header = the_options.verbose_response_header
    val mutable verbose_request_contents =
      the_options.verbose_request_contents
    val mutable verbose_response_contents =
      the_options.verbose_response_contents
    val mutable verbose_connection = the_options.verbose_connection
    method state = state
    method auth_required = auth_required
    method got_401 = auth_required <- true
    method f_done = indicate_done
    method reset =
      state <- Unprocessed;
      string_to_send <- "";
      send_position <- 0;
      auth_required <- false
    method send fd only_header =
      assert (state = Unprocessed || state = Sending);
      if state = Unprocessed then
        begin
          let body = msg#get_req_body () in
          msg#set_req_header "content-length"
            (string_of_int (String.length body));
          let request_string = msg#get_request () in
          let header = msg#get_req_header () in
          let crlf = "\r\n" in
          string_to_send <-
            request_string ^ crlf ^
              String.concat ""
                (List.map (fun (n, v) -> n ^ ": " ^ v ^ crlf) header) ^
              crlf ^ body;
          send_position <- 0;
          header_length <- String.length string_to_send - String.length body;
          if verbose_status then
            prerr_endline ("HTTP request: " ^ request_string);
          if verbose_request_header then
            msg#dump_header "HTTP request " header;
          if verbose_request_contents then
            prerr_endline ("HTTP request body:\n" ^ body)
        end;
      let l_all = String.length string_to_send in
      let l = if only_header then header_length else l_all in
      let n_to_send = min 16384 (l - send_position) in
      let n =
        syscall
          (fun () -> Unix.write fd string_to_send send_position n_to_send)
      in
      send_position <- send_position + n;
      if send_position >= l_all then state <- Waiting else state <- Sending
    method header_is_sent =
      state <> Unprocessed && send_position >= header_length
    method abort_sending =
      string_to_send <- ""; send_position <- 0; state <- Waiting
    method receive (rbuf : recv_buffer) =
      assert (state = Waiting || state = Receiving);
      let received_buffer = rbuf#contents in
      try
        let need_to_init_header = state = Waiting in
        msg#set_response received_buffer need_to_init_header;
        msg#decode_header ();
        let (header_length, body_length) = msg#received_body_is_complete () in
        let (version, code, code_as_string) = msg#dest_status () in
        if verbose_status then
          begin
            prerr_endline ("HTTP response code: " ^ string_of_int code);
            prerr_endline ("HTTP response code: " ^ code_as_string);
            prerr_endline ("HTTP response protocol: " ^ version)
          end;
        if verbose_response_header then
          msg#dump_header "HTTP response " (msg#get_resp_header ());
        msg#decode_body () verbose_response_header verbose_response_contents;
        let total_length = header_length + body_length in
        rbuf#consume total_length; msg#set_served (); state <- Complete
      with
        Header_is_incomplete -> ()
      | Body_is_incomplete -> ()
      | Body_maybe_complete -> ()
    method receive_eof (rbuf : recv_buffer) =
      assert (state = Waiting || state = Receiving);
      let received_buffer = rbuf#contents in
      try
        let need_to_init_header = state = Waiting in
        msg#set_response received_buffer need_to_init_header;
        msg#decode_header ();
        let total_length =
          try
            let (header_length, body_length) =
              msg#received_body_is_complete ()
            in
            header_length + body_length
          with
            Body_maybe_complete -> B.length received_buffer
        in
        let (version, code, code_as_string) = msg#dest_status () in
        if verbose_status then
          begin
            prerr_endline ("HTTP response code: " ^ string_of_int code);
            prerr_endline ("HTTP response code: " ^ code_as_string);
            prerr_endline ("HTTP response protocol: " ^ version)
          end;
        if verbose_response_header then
          msg#dump_header "HTTP response " (msg#get_resp_header ());
        msg#decode_body () verbose_response_header verbose_response_contents;
        rbuf#consume total_length;
        msg#set_served ();
        state <- Complete
      with
        Header_is_incomplete -> raise (Bad_message "Header is incomplete")
      | Body_is_incomplete -> raise (Bad_message "Message body is incomplete")
    method indicate_pipelining =
      assert (state = Complete);
      let (version, _, _) = msg#dest_status () in
      if version = "HTTP/1.1" then
        let conn_header =
          try msg#assoc_resp_header "connection" with
            Not_found -> ""
        in
        conn_header <> "close"
      else false
    method indicate_sequential_persistency =
      assert (state = Complete);
      let proxy_connection =
        try msg#assoc_resp_header "proxy-connection" with
          Not_found -> ""
      in
      let connection =
        try msg#assoc_resp_header "connection" with
          Not_found -> ""
      in
      String.lowercase connection = "keep-alive" ||
      String.lowercase proxy_connection = "keep-alive"
    method postprocess = indicate_done msg
    method message = msg
  end


(**********************************************************************)
(**********************************************************************)
(**********************************************************************)
(***                                                                ***)
(***           THE PROTOCOL STATE OF THE CONNECTION                 ***)
(***                                                                ***)
(**********************************************************************)
(**********************************************************************)
(**********************************************************************)

(* This is the core of this HTTP implementation: The object controlling
 * the state of the connection to a server (or a proxy).
 *)

type sockstate =
    Down
  | Up_rw
  | Up_r


class
  connection
  the_esys
  (the_peer_host, the_peer_port)
  (the_proxy_user, the_proxy_password)
  the_auth_methods
  the_options
  =
  object (self)
    val mutable esys = the_esys
    val mutable group = None
    val mutable timeout_groups = []
    val mutable peer_host = the_peer_host
    val mutable peer_port = the_peer_port
    val mutable socket = stdin
    val mutable socket_state = Down
    val mutable recv = new recv_buffer stdin
    val mutable write_queue = Queue.create ()
    val mutable read_queue = Queue.create ()
    val mutable polling_wr = false
    val mutable connecting = false
    val mutable connect_pause = 0.0
    val mutable enable_persistency = false
    val mutable sending_first_message = true
    val mutable done_first_message = false
    val mutable synchronization = the_options.synchronization
    val mutable inhibit_pipelining_byserver = false
    val mutable pe_got_some_status = false
    val mutable pe_trial = 0
    val mutable pe_waiting_for_status = false
    val mutable pe_timer = None
    val mutable connect_started = 0.0
    val mutable connect_time = 0.0
    val mutable totally_failed_connections = 0
    val mutable max_totally_failed_connections =
      the_options.maximum_connection_failures
    val mutable got_message_status = false
    val mutable close_connection = false
    val mutable no_persistency = the_options.inhibit_persistency
    val mutable maximum_number_of_errors = the_options.maximum_message_errors
    val mutable waiting_for_status100 = ref 0
    val mutable proxy_user = the_proxy_user
    val mutable proxy_password = the_proxy_password
    val mutable proxy_credentials_required = false
    val mutable proxy_cookie = ""
    val mutable auth_methods = the_auth_methods
    val mutable current_auth_method = None
    val mutable deferred_additions = Queue.create ()
    val mutable critical_section = false
    val mutable options = the_options
    val mutable verbose_status = the_options.verbose_status
    val mutable verbose_request_header = the_options.verbose_request_header
    val mutable verbose_response_header = the_options.verbose_response_header
    val mutable verbose_request_contents =
      the_options.verbose_request_contents
    val mutable verbose_response_contents =
      the_options.verbose_response_contents
    val mutable verbose_connection = the_options.verbose_connection
    method length = Queue.length read_queue + Queue.length deferred_additions
    method add (m : message) f_done = ignore (self#add_msg m f_done)
    method private add_msg m f_done =
      if socket_state = Down then ignore self#inet_addr;
      begin match synchronization with
        Sync_with_handshake_before_request_body _ ->
          if m#get_req_body () <> "" then
            m#set_req_header "expect" "100-continue"
      | _ -> ()
      end;
      if proxy_credentials_required && m#using_proxy then
        begin
          if proxy_cookie = "" then
            proxy_cookie <-
              Netencoding.Base64.encode (proxy_user ^ ":" ^ proxy_password);
          m#set_req_header "proxy-authorization" ("Basic " ^ proxy_cookie)
        end;
      begin match current_auth_method with
        None -> ()
      | Some a ->
          if try let _ = m#assoc_req_header "authorization" in false with
               Not_found -> true
          then
            a#set_authorization m "authorization"
      end;
      let trans = new message_transport m f_done options in
      if critical_section then Queue.add trans deferred_additions
      else
        begin
          Queue.add trans write_queue;
          Queue.add trans read_queue;
          if group = None then self#attach_to_esys;
          self#maintain_polling
        end;
      trans
    method leave_critical_section : unit =
      Queue.iter
        (fun trans -> Queue.add trans write_queue; Queue.add trans read_queue)
        deferred_additions;
      if Queue.length deferred_additions > 0 then
        begin
          if group = None then self#attach_to_esys;
          self#maintain_polling;
          Queue.clear deferred_additions
        end
    method private add_again m_trans =
      let m = m_trans#message in
      let f_done = m_trans#f_done in m#set_unserved (); self#add_msg m f_done
    method set_options p =
      options <- p;
      synchronization <- options.synchronization;
      max_totally_failed_connections <- options.maximum_connection_failures;
      no_persistency <- options.inhibit_persistency;
      maximum_number_of_errors <- options.maximum_message_errors;
      verbose_status <- options.verbose_status;
      verbose_request_header <- options.verbose_request_header;
      verbose_response_header <- options.verbose_response_header;
      verbose_request_contents <- options.verbose_request_contents;
      verbose_response_contents <- options.verbose_response_contents;
      verbose_connection <- options.verbose_connection
    method private attach_to_esys =
      assert (group = None);
      let g = Unixqueue.new_group esys in group <- Some g; self#reinitialize
    method private reinitialize =
      assert (socket_state = Down);
      let g =
        match group with
          Some x -> x
        | None -> assert false
      in
      connecting <- false;
      enable_persistency <- false;
      sending_first_message <- true;
      done_first_message <- false;
      close_connection <- false;
      polling_wr <- false;
      critical_section <- false;
      inhibit_pipelining_byserver <- false;
      waiting_for_status100 <- ref 0;
      pe_got_some_status <- false;
      got_message_status <- false;
      let g1 = Unixqueue.new_group esys in
      Unixqueue.once esys g1 connect_pause
        (fun () ->
           try
             connect_pause <- 0.0;
             self#connect_server;
             let timeout_value = options.connection_timeout in
             Unixqueue.add_resource esys g
               (Unixqueue.Wait_in socket, timeout_value);
             Unixqueue.add_close_action esys g
               (socket, (fun _ -> self#shutdown));
             Unixqueue.add_handler esys g self#handler;
             self#maintain_polling
           with
             Exit -> ())
    method private maintain_polling =
      let timeout_value = options.connection_timeout in
      let actual_max_drift =
        if inhibit_pipelining_byserver then 0
        else
          match synchronization with
            Pipeline drift -> drift
          | _ -> 0
      in
      if Queue.length write_queue = 0 && Queue.length read_queue > 0 or
         Queue.length read_queue - Queue.length write_queue >
           actual_max_drift or
         not done_first_message && not sending_first_message or
         socket_state <> Up_rw or pe_waiting_for_status or
         !waiting_for_status100 = 1
      then
        begin
          if polling_wr then
            begin
              let g =
                match group with
                  Some x -> x
                | None -> assert false
              in
              Unixqueue.remove_resource esys g (Unixqueue.Wait_out socket)
            end;
          polling_wr <- false
        end;
      if (Queue.length write_queue > 0 or
          Queue.length write_queue = 0 && Queue.length read_queue = 0) &&
         Queue.length read_queue - Queue.length write_queue <=
           actual_max_drift &&
         (done_first_message || sending_first_message) &&
         socket_state = Up_rw && not pe_waiting_for_status &&
         !waiting_for_status100 <> 1
      then
        begin
          if not polling_wr then
            begin
              let g =
                match group with
                  Some x -> x
                | None -> assert false
              in
              Unixqueue.add_resource esys g
                (Unixqueue.Wait_out socket, timeout_value)
            end;
          polling_wr <- true
        end
    method private shutdown =
      if verbose_connection then prerr_endline "HTTP connection: Shutdown!";
      begin match socket_state with
        Down -> ()
      | Up_rw | Up_r ->
          if verbose_connection then
            prerr_endline "HTTP connection: Closing socket!";
          syscall (fun () -> Unix.close socket)
      end;
      socket_state <- Down;
      begin match group with
        Some g -> Unixqueue.clear esys g; group <- None
      | None -> ()
      end;
      List.iter (Unixqueue.clear esys) timeout_groups;
      timeout_groups <- []
    method private clear_timeout g =
      Unixqueue.clear esys g;
      timeout_groups <- List.filter (fun x -> x <> g) timeout_groups
    method private abort_connection =
      match group with
        Some g ->
          Unixqueue.remove_resource esys g (Unixqueue.Wait_in socket);
          if polling_wr then
            begin
              Unixqueue.remove_resource esys g (Unixqueue.Wait_out socket);
              polling_wr <- false
            end;
          assert (group = None)
      | None -> ()
    method private inet_addr =
      try inet_addr_of_string (Http_client_aux.match_ip peer_host) with
        Not_found ->
          try let h = gethostbyname peer_host in h.h_addr_list.(0) with
            Not_found ->
              raise
                (Sys_error
                   ("Http_client: host name lookup failed for " ^ peer_host))
    method private connect_server =
      if verbose_connection then
        prerr_endline ("HTTP connection: Connecting to server " ^ peer_host);
      let addr = self#inet_addr in
      let s = syscall (fun () -> Unix.socket PF_INET SOCK_STREAM 0) in
      connect_started <- Unix.gettimeofday ();
      Unix.set_nonblock s;
      begin try
        syscall (fun () -> Unix.connect s (ADDR_INET (addr, peer_port)));
        let t1 = Unix.gettimeofday () in
        connect_time <- t1 -. connect_started;
        connecting <- false;
        if verbose_connection then prerr_endline "HTTP connection: Connected!"
      with
        Unix.Unix_error (Unix.EINPROGRESS, _, _) -> connecting <- true
      | Unix.Unix_error (_, _, _) as err ->
          begin match group with
            Some g -> Unixqueue.clear esys g; group <- None
          | None -> ()
          end;
          Unix.close s;
          Queue.iter
            (fun m ->
               m#message#set_error_exception () err;
               self#critical_postprocessing m)
            read_queue;
          Queue.clear read_queue;
          Queue.clear write_queue;
          raise Exit
      end;
      socket <- s;
      socket_state <- Up_rw;
      recv <- new recv_buffer socket
    method private check_connection =
      if connecting then
        begin
          Unix.clear_nonblock socket;
          let t1 = Unix.gettimeofday () in
          connect_time <- t1 -. connect_started;
          connecting <- false;
          if verbose_connection then
            prerr_endline "HTTP connection: Got connection status"
        end
    method private handler _ _ ev =
      let g =
        match group with
          Some x -> x
        | None -> raise Equeue.Reject
      in
      match ev with
        Unixqueue.Input_arrived (g0, fd0) ->
          if g0 = g then self#handle_input else raise Equeue.Reject
      | Unixqueue.Output_readiness (g0, fd0) ->
          if g0 = g then self#handle_output else raise Equeue.Reject
      | Unixqueue.Timeout (g0, _) ->
          if g0 = g then self#handle_timeout else raise Equeue.Reject
      | _ -> raise Equeue.Reject
    method private handle_timeout = recv#set_timeout; self#handle_input
    method private handle_input =
      if socket_state = Down then raise Equeue.Reject;
      if verbose_connection then
        prerr_endline "HTTP connection: Input event!";
      let g =
        match group with
          Some x -> x
        | None -> assert false
      in
      let end_of_queueing = ref false in
      if not recv#timeout then
        begin try
          if connecting then self#check_connection; recv#unix_read ()
        with
          Unix.Unix_error (e, a, b) as err ->
            if verbose_connection then
              prerr_endline
                ("HTTP connection: Unix error " ^ Unix.error_message e);
            self#reset_after_unix_error err;
            raise (Unix.Unix_error (e, a, b))
        end;
      if recv#eof || recv#timeout then
        begin
          if verbose_connection && recv#eof then
            prerr_endline "HTTP connection: Got EOF!";
          if verbose_connection && recv#timeout then
            prerr_endline "HTTP connection: Connection timeout!";
          if not recv#eof then
            begin try
              syscall (fun () -> Unix.shutdown socket Unix.SHUTDOWN_SEND)
            with
              Unix.Unix_error (Unix.ENOTCONN, _, _) -> ()
            end;
          self#abort_connection;
          end_of_queueing := true
        end;
      let rec read_loop () =
        if B.length recv#contents > 0 then
          let this = Queue.peek read_queue in
          match this#state with
            Unprocessed ->
              let (_, n_continue) = recv#drop_'continue'_responses in
              if n_continue > 0 then pe_got_some_status <- true;
              if B.length recv#contents > 0 then
                begin
                  if verbose_connection then
                    prerr_endline "HTTP connection: protocol error (A)";
                  raise Abort_on_protocol_error
                end
          | Sending ->
              assert
                (try Queue.peek write_queue == this with
                   Queue.Empty -> false);
              let (c100, n_continue) = recv#drop_'continue'_responses in
              if n_continue > 0 then pe_got_some_status <- true;
              if c100 then waiting_for_status100 := 2;
              if B.length recv#contents > 0 then
                begin
                  if verbose_connection then
                    prerr_endline
                      "HTTP connection: Got asynchronous response";
                  begin try
                    ignore recv#status_line;
                    pe_got_some_status <- true;
                    got_message_status <- true;
                    waiting_for_status100 := 2
                  with
                    Not_found ->
                      if verbose_connection then
                        prerr_endline "HTTP connection: protocol error (B)";
                      raise Abort_on_protocol_error
                  end;
                  if not recv#eof then
                    begin
                      if verbose_connection then
                        prerr_endline
                          "HTTP connection: Sending asynchronous EOF";
                      syscall
                        (fun () -> Unix.shutdown socket Unix.SHUTDOWN_SEND);
                      socket_state <- Up_r
                    end;
                  ignore (Queue.take write_queue);
                  this#abort_sending;
                  assert (this#state = Waiting);
                  read_loop ()
                end
          | Waiting | Receiving ->
              let (c100, n_continue) = recv#drop_'continue'_responses in
              if n_continue > 0 then pe_got_some_status <- true;
              if c100 then waiting_for_status100 := 2;
              begin try
                ignore recv#status_line;
                pe_got_some_status <- true;
                got_message_status <- true;
                waiting_for_status100 := 2
              with
                Not_found -> ()
              end;
              begin try
                if recv#eof then this#receive_eof recv else this#receive recv
              with
                Bad_message s as x ->
                  if verbose_connection then
                    prerr_endline
                      ("HTTP connection: Protocol error (Bad message: " ^ s ^
                         ")");
                  let m = this#message in
                  m#set_error_exception () x;
                  m#set_error_counter () (m#get_error_counter () + 1);
                  raise Abort_on_protocol_error
              end;
              if this#state = Complete then
                let able_to_pipeline = this#indicate_pipelining in
                let only_sequential_persistency =
                  this#indicate_sequential_persistency
                in
                if only_sequential_persistency then
                  begin
                    if verbose_connection then
                      prerr_endline "HTTP connection: using HTTP/1.0 style persistent connection";
                    enable_persistency <- true;
                    inhibit_pipelining_byserver <- true
                  end
                else
                  begin
                    close_connection <-
                      close_connection || not able_to_pipeline;
                    enable_persistency <-
                      enable_persistency || able_to_pipeline
                  end;
                done_first_message <- true;
                waiting_for_status100 <- ref 0;
                ignore (Queue.take read_queue);
                self#postprocess_complete_message this;
                read_loop ()
          | Complete -> assert false
      in
      begin try read_loop () with
        Queue.Empty ->
          if B.length recv#contents > 0 then
            begin
              if verbose_connection then
                begin
                  let n = B.length recv#contents in
                  prerr_endline
                    "HTTP connection: Extra octets -- aborting connection";
                  prerr_endline ("Number of extra bytes: " ^ string_of_int n);
                  if n < 20 then
                    prerr_endline
                      ("Extra bytes: " ^
                         encode_hex (B.contents recv#contents))
                end;
              self#abort_connection;
              end_of_queueing := true
            end
      | Abort_on_protocol_error ->
          if verbose_connection then
            prerr_endline
              "HTTP connection: Aborting the connection after protocol error";
          self#abort_connection;
          end_of_queueing := true
      end;
      if pe_trial > 0 then
        (if pe_got_some_status then
           begin
             if verbose_connection then
               prerr_endline "HTTP connection: resuming normal operation";
             pe_trial <- 0;
             pe_waiting_for_status <- false;
             self#pe_disable_timer
           end
         else if !end_of_queueing then
           begin
             if verbose_connection then
               prerr_endline "HTTP connection: continuing special handling after further premature EOF";
             pe_trial <- pe_trial + 1;
             pe_waiting_for_status <- false;
             self#pe_disable_timer;
             let tm = Unixqueue.new_group esys in
             let en = ref true in
             let timeout = ref (max 1.0 connect_time) in
             for k = 1 to pe_trial do timeout := !timeout *. 2.0 done;
             Unixqueue.once esys tm !timeout (self#pe_timeout en);
             pe_timer <- Some tm;
             timeout_groups <- tm :: timeout_groups
           end)
      else if not pe_got_some_status && !end_of_queueing then
        begin
          if verbose_connection then
            prerr_endline
              "HTTP connection: enabling special code after premature EOF";
          pe_trial <- 1;
          pe_waiting_for_status <- false;
          self#pe_disable_timer;
          let tm = Unixqueue.new_group esys in
          let en = ref true in
          Unixqueue.once esys tm (max 1.0 connect_time *. 2.0)
            (self#pe_timeout en);
          pe_timer <- Some tm;
          timeout_groups <- tm :: timeout_groups
        end;
      if !end_of_queueing then
        begin assert (group = None); self#cleanup_on_eof No_exception end;
      self#leave_critical_section;
      self#maintain_polling
    method private cleanup_on_eof err =
      (assert (group = None);
       if not got_message_status then
         begin
           totally_failed_connections <- totally_failed_connections + 1;
           if verbose_connection then
             prerr_endline "HTTP connection: total failure";
           if totally_failed_connections > max_totally_failed_connections then
             begin
               Queue.iter
                 (fun m ->
                    begin try
                      ignore (m#message#get_resp_header ());
                      m#message#set_error_exception ()
                        (if err = No_exception then
                           Bad_message
                             "Unknown reason (e.g. unexpected eof, timeout)"
                         else err)
                    with
                      _ -> ()
                    end;
                    self#critical_postprocessing m)
                 read_queue;
               Queue.clear read_queue;
               Queue.clear write_queue;
               totally_failed_connections <- 0;
               pe_trial <- 0;
               pe_waiting_for_status <- false;
               self#pe_disable_timer
             end
         end
       else totally_failed_connections <- 0;
       let n_read = Queue.length read_queue in
       let n_write = Queue.length write_queue in
       if n_read > 0 || n_write > 0 then
         begin
           assert (n_read >= n_write);
           assert (group = None);
           connect_pause <- 0.5;
           if n_read = n_write then
             begin
               assert (Queue.length write_queue > 0);
               (Queue.peek write_queue)#reset;
               self#attach_to_esys
             end
           else
             begin
               for i = 1 to n_read - n_write do
                 let m_trans = Queue.take read_queue in
                 let m = m_trans#message in
                 if m#get_error_counter () <= maximum_number_of_errors then
                   let do_reconnect =
                     match m#get_reconnect_mode with
                       Send_again -> true
                     | Request_fails -> false
                     | Inquire f ->
                         try f m with
                           x ->
                             prerr_string "Exception caught in Http_client: ";
                             prerr_endline (Printexc.to_string x);
                             false
                   in
                   if do_reconnect then
                     begin
                       m#set_error_exception () No_exception;
                       m_trans#reset;
                       Queue.add m_trans write_queue;
                       Queue.add m_trans read_queue
                     end
                   else
                     begin
                       begin try
                         ignore (m#get_resp_header ());
                         m#set_error_exception () No_reply
                       with
                         _ -> ()
                       end;
                       self#critical_postprocessing m_trans
                     end
                 else self#critical_postprocessing m_trans
               done;
               let n_read = Queue.length read_queue in
               let n_write = Queue.length write_queue in
               assert (n_read = n_write);
               if n_write > 0 then
                 begin
                   assert (Queue.peek read_queue == Queue.peek write_queue);
                   if group = None then self#attach_to_esys
                 end
               else self#pe_disable_timer
             end
         end :
       unit)
    method critical_postprocessing m =
      critical_section <- true;
      try m#postprocess; critical_section <- false with
        any -> critical_section <- false; raise any
    method private reset_after_unix_error err =
      self#abort_connection;
      self#pe_disable_timer;
      assert (group = None);
      self#cleanup_on_eof err;
      self#leave_critical_section
    method reset =
      self#abort_connection;
      self#pe_disable_timer;
      Queue.iter
        (fun m ->
           m#message#set_error_exception () No_reply;
           self#critical_postprocessing m)
        read_queue;
      Queue.clear read_queue;
      Queue.clear write_queue;
      totally_failed_connections <- 0;
      pe_trial <- 0;
      pe_waiting_for_status <- false;
      self#leave_critical_section
    method private pe_timeout is_enabled () =
      if verbose_connection then
        prerr_endline "HTTP connection: timeout; resuming normal operation";
      pe_trial <- 0;
      pe_waiting_for_status <- false;
      begin match pe_timer with
        Some g ->
          timeout_groups <- List.filter (fun x -> x <> g) timeout_groups
      | _ -> assert false
      end;
      pe_timer <- None;
      self#maintain_polling
    method private pe_disable_timer =
      begin match pe_timer with
        None -> ()
      | Some g -> self#clear_timeout g
      end;
      pe_timer <- None
    method private postprocess_complete_message msg_trans =
      let default_action () = self#critical_postprocessing msg_trans in
      let scan_auth_header h =
        let p = parse_header_value h in
        match p with
          Word m :: p' -> String.lowercase m, p'
        | _ -> raise Not_found
      in
      let msg = msg_trans#message in
      let (_, code, _) = msg#dest_status () in
      match code with
        407 ->
          if try
               let _ = msg#assoc_req_header "proxy-authorization" in
               if verbose_status then
                 prerr_endline
                   "HTTP auth: proxy authentication required again";
               false
             with
               Not_found -> true
          then
            begin
              if msg#using_proxy then
                begin
                  if verbose_status then
                    prerr_endline "HTTP auth: proxy authentication required";
                  if proxy_user <> "" then
                    begin
                      if not proxy_credentials_required then
                        begin
                          proxy_credentials_required <- true;
                          proxy_cookie <- ""
                        end;
                      if verbose_status then
                        prerr_endline "HTTP auth: proxy credentials added";
                      ignore (self#add_again msg_trans)
                    end
                  else if verbose_status then
                    prerr_endline "HTTP auth: user/password missing";
                  default_action ()
                end
              else if verbose_status then
                prerr_endline "HTTP auth: intrusion by proxy authentication";
              default_action ()
            end
          else default_action ()
      | 401 ->
          if msg_trans#auth_required then
            begin
              if verbose_status then
                prerr_endline
                  "HTTP auth: server authentication required again";
              default_action ()
            end
          else
            begin
              if verbose_status then
                prerr_endline "HTTP auth: server authentication required";
              msg_trans#got_401;
              try
                let challenge = msg#assoc_resp_header "www-authenticate" in
                let (auth_method_name, params) = scan_auth_header challenge in
                if verbose_status then
                  begin
                    prerr_endline ("HTTP auth: method=" ^ auth_method_name);
                    prerr_endline
                      ("HTTP auth: params=" ^ string_of_token_list params)
                  end;
                let auth_method = List.assoc auth_method_name auth_methods in
                if verbose_status then
                  prerr_endline "HTTP auth: method found";
                auth_method#www_authenticate msg params;
                if verbose_status then
                  prerr_endline "HTTP auth: method analyzed requirements";
                auth_method#set_authorization msg "authorization";
                if verbose_status then
                  prerr_endline "HTTP auth: method added credentials";
                let new_msg_trans = self#add_again msg_trans in
                new_msg_trans#got_401;
                current_auth_method <- Some auth_method;
                if verbose_status then
                  prerr_endline "HTTP auth: augmented request added"
              with
                Not_found -> default_action ()
            end
      | _ -> default_action ()
    method private handle_output =
      if socket_state <> Up_rw then raise Equeue.Reject;
      if verbose_connection then
        prerr_endline "HTTP connection: Output event!";
      let g =
        match group with
          Some x -> x
        | None -> assert false
      in
      if connecting then self#check_connection;
      let rec write_loop () =
        let this = Queue.peek write_queue in
        match this#state with
          Unprocessed | Sending ->
            if no_persistency && this#state = Unprocessed then
              this#message#set_req_header "connection" "close";
            let do_handshake =
              match synchronization with
                Sync_with_handshake_before_request_body timeout ->
                  !waiting_for_status100 = 0
              | _ -> false
            in
            if enable_persistency || sending_first_message then
              begin
                begin try
                  this#send socket (pe_trial > 0 || do_handshake);
                  if pe_trial > 0 && this#header_is_sent then
                    begin
                      pe_waiting_for_status <- true;
                      if verbose_connection then
                        prerr_endline
                          "HTTP connection: waiting for status line"
                    end;
                  if do_handshake && this#header_is_sent &&
                     this#state <> Waiting
                  then
                    match synchronization with
                      Sync_with_handshake_before_request_body timeout ->
                        let w = ref 1 in
                        waiting_for_status100 <- w;
                        let tm = Unixqueue.new_group esys in
                        timeout_groups <- tm :: timeout_groups;
                        Unixqueue.once esys tm timeout
                          (fun () ->
                             if !w = 1 && w == waiting_for_status100 then
                               begin w := 2; self#maintain_polling end;
                             self#clear_timeout tm);
                        if verbose_connection then
                          prerr_endline
                            "HTTP connection: waiting for 100 CONTINUE"
                    | _ -> assert false
                with
                  Unix.Unix_error (Unix.EPIPE, _, _) ->
                    if verbose_connection then
                      prerr_endline "HTTP connection: broken pipe";
                    this#reset;
                    raise Broken_pipe
                | Unix.Unix_error (e, a, b) as err ->
                    if verbose_connection then
                      prerr_endline
                        ("HTTP connection: Unix error " ^
                           Unix.error_message e);
                    this#reset;
                    self#reset_after_unix_error err;
                    raise (Unix.Unix_error (e, a, b))
                end;
                if sending_first_message && this#state = Waiting then
                  sending_first_message <- false;
                if this#state = Waiting then ignore (Queue.take write_queue)
              end
        | Waiting | Receiving | Complete ->
            ignore (Queue.take write_queue); write_loop ()
      in
      let broken_connection = ref false in
      begin try write_loop () with
        Queue.Empty -> ()
      | Broken_pipe -> broken_connection := true
      end;
      if Queue.length write_queue = 0 && Queue.length read_queue = 0 or
         no_persistency && not sending_first_message or close_connection or
         !broken_connection
      then
        begin
          assert (socket_state = Up_rw);
          if verbose_connection then
            prerr_endline "HTTP connection: Sending EOF!";
          if not !broken_connection then
            syscall (fun () -> Unix.shutdown socket Unix.SHUTDOWN_SEND);
          socket_state <- Up_r
        end;
      self#maintain_polling
  end


(**********************************************************************)
(**********************************************************************)
(**********************************************************************)
(***                                                                ***)
(***                 THE PIPELINE INTERFACE                         ***)
(***                                                                ***)
(**********************************************************************)
(**********************************************************************)
(**********************************************************************)

(* The following class, 'pipeline' defines the interface for the outside
 * world.
 *)

class pipeline =
  object (self)
    val mutable esys = Unixqueue.create_unix_event_system ()
    val mutable proxy = ""
    val mutable proxy_port = 80
    val mutable proxy_auth = false
    val mutable proxy_user = ""
    val mutable proxy_password = ""
    val mutable www_auth = ([] : (string * basic_auth_method) list)
    val mutable no_proxy_for = []
    val mutable connections = Hashtbl.create 10
    val mutable open_messages = 0
    val mutable open_connections = 0
    val mutable options =
      {synchronization = Pipeline 5; maximum_connection_failures = 1;
       maximum_message_errors = 2; inhibit_persistency = false;
       connection_timeout = 300.0; number_of_parallel_connections = 2;
       verbose_status = false; verbose_request_header = false;
       verbose_response_header = false; verbose_request_contents = false;
       verbose_response_contents = false; verbose_connection = false}
    method set_event_system new_esys =
      esys <- new_esys; Hashtbl.clear connections
    method add_authentication_method m =
      let name = m#name in www_auth <- (name, m) :: listrm name www_auth
    method set_proxy the_proxy the_port =
      proxy <- the_proxy; proxy_port <- the_port; ()
    method set_proxy_auth user passwd =
      proxy_auth <- user <> ""; proxy_user <- user; proxy_password <- passwd
    method avoid_proxy_for l = no_proxy_for <- l
    method set_proxy_from_environment () =
      let http_proxy =
        try Sys.getenv "http_proxy" with
          Not_found -> ""
      in
      begin try
        let (user, password, host, port, path) =
          Http_client_aux.match_http http_proxy
        in
        self#set_proxy (Cgi.decode host) port;
        match user with
          Some user_s ->
            begin match password with
              Some password_s ->
                self#set_proxy_auth (Cgi.decode user_s)
                  (Cgi.decode password_s)
            | None -> ()
            end
        | None -> ()
      with
        Not_found -> ()
      end;
      let no_proxy =
        try Sys.getenv "no_proxy" with
          Not_found -> ""
      in
      let no_proxy_list = Http_client_aux.split_words_by_commas no_proxy in
      self#avoid_proxy_for no_proxy_list
    method reset () =
      Hashtbl.iter (fun _ cl -> List.iter (fun c -> c#reset) !cl) connections
    method
      private
      add_with_callback_no_redirection
      (request : message)
      f_done
      =
      request#set_unserved ();
      let host = request#get_host () in
      let port = request#get_port () in
      let proxy_allowed =
        request#is_proxy_allowed () &
        not
          (List.exists
             (fun dom ->
                if dom <> "" & dom.[0] = '.' &
                   String.length host > String.length dom
                then
                  let ld = String.length dom in
                  String.lowercase
                    (String.sub host (String.length host - ld) ld) =
                    String.lowercase dom
                else dom = host)
             no_proxy_for)
      in
      request#prepare (proxy <> "" && proxy_allowed);
      let (peer, peer's_port) =
        if proxy = "" || not proxy_allowed then host, port
        else proxy, proxy_port
      in
      let conn =
        let connlist =
          try Hashtbl.find connections (peer, peer's_port) with
            Not_found ->
              let new_connlist = ref [] in
              Hashtbl.add connections (peer, peer's_port) new_connlist;
              new_connlist
        in
        if List.length !connlist < options.number_of_parallel_connections then
          let new_conn =
            new connection esys (peer, peer's_port)
              (proxy_user, proxy_password) www_auth options
          in
          open_connections <- open_connections + 1;
          connlist := new_conn :: !connlist;
          new_conn
        else
          List.fold_left
            (fun best_conn a_conn ->
               if a_conn#length < best_conn#length then a_conn else best_conn)
            (List.hd !connlist) (List.tl !connlist)
      in
      conn#add request
        (fun m ->
           f_done m;
           let l = conn#length in
           if l = 0 then
             begin
               open_connections <- open_connections - 1;
               let connlist =
                 try Hashtbl.find connections (peer, peer's_port) with
                   Not_found -> assert false
               in
               connlist := List.filter (fun c -> c != conn) !connlist;
               if !connlist = [] then
                 Hashtbl.remove connections (peer, peer's_port)
             end;
           self#update_open_messages);
      open_messages <- open_messages + 1
    method private update_open_messages =
      open_messages <- 0;
      Hashtbl.iter
        (fun _ cl ->
           List.iter (fun c -> open_messages <- open_messages + c#length) !cl)
        connections
    method add_with_callback (request : message) f_done =
      self#add_with_callback_no_redirection request
        (fun m ->
           try
             let (_, code, _) = m#dest_status () in
             match code with
               301 | 302 ->
                 let do_redirection =
                   match m#get_redirect_mode with
                     Redirect -> true
                   | Do_not_redirect -> false
                   | Redirect_inquire f ->
                       try f m with
                         x ->
                           prerr_string "Exception caught in Http_client: ";
                           prerr_endline (Printexc.to_string x);
                           false
                 in
                 if do_redirection then
                   let location = m#assoc_resp_header "location" in
                   m#init_query () location; self#add_with_callback m f_done
                 else f_done m
             | _ -> f_done m
           with
             Http_protocol _ | Not_found -> f_done m)
    method add request = self#add_with_callback request (fun _ -> ())
    method run () = Unixqueue.run esys
    method get_options = options
    method set_options p =
      options <- p;
      Hashtbl.iter (fun _ cl -> List.iter (fun c -> c#set_options p) !cl)
        connections
    method number_of_open_messages = open_messages
    method number_of_open_connections = open_connections
  end

(**********************************************************************)
(**********************************************************************)
(**********************************************************************)
(***                                                                ***)
(***                 THE CONVENIENCE MODULE                         ***)
(***                                                                ***)
(**********************************************************************)
(**********************************************************************)
(**********************************************************************)

(* This module is intended for beginners and for simple applications
 * of this HTTP implementation.
 *)


module Convenience =
  struct
    class simple_basic_auth_method f =
      object
        inherit basic_auth_method method get_credentials () = f current_realm
      end
    class simple_digest_auth_method f =
      object
        inherit digest_auth_method method get_credentials () = f current_realm
      end
    let http_url_decode url = Http_client_aux.match_http url
    let http_trials = ref 3
    let http_user = ref ""
    let http_password = ref ""
    let this_user = ref ""
    let this_password = ref ""
    let auth_basic =
      new simple_basic_auth_method
        (fun realm ->
           if !this_user <> "" then !this_user, !this_password
           else if !http_user <> "" then !http_user, !http_password
           else raise Not_found)
    let auth_digest =
      new simple_digest_auth_method
        (fun realm ->
           if !this_user <> "" then !this_user, !this_password
           else if !http_user <> "" then !http_user, !http_password
           else raise Not_found)
    let get_default_pipe () =
      let p = new pipeline in
      p#set_proxy_from_environment ();
      p#add_authentication_method auth_basic;
      p#add_authentication_method auth_digest;
      p
    let pipe = lazy (get_default_pipe ())
    let pipe_empty = ref true
    let mutex = Http_client_aux.Mtx.create ()
    let request m trials =
      Http_client_aux.Mtx.lock mutex;
      try
        let p = Lazy.force pipe in
        if not !pipe_empty then p#reset ();
        p#add_with_callback m (fun _ -> pipe_empty := true);
        pipe_empty := false;
        let rec next_trial todo e =
          if todo > 0 then
            try p#run () with
              Http_error (n, s) as e' ->
                if List.mem n [408; 413; 500; 502; 503; 504] then
                  next_trial (todo - 1) e'
                else raise e'
            | e' -> next_trial (todo - 1) e'
          else raise e
        in
        next_trial trials (Failure "bad number of http_trials");
        Http_client_aux.Mtx.unlock mutex
      with
        any -> Http_client_aux.Mtx.unlock mutex; raise any
    let prepare_url url =
      Http_client_aux.Mtx.lock mutex;
      try
        this_user := "";
        let (user, password, host, port, path) = http_url_decode url in
        begin match user with
          Some user_s ->
            this_user := Cgi.decode user_s;
            this_password := "";
            begin match password with
              Some password_s -> this_password := Cgi.decode password_s
            | None -> ()
            end
        | None -> ()
        end;
        Http_client_aux.Mtx.unlock mutex;
        "http://" ^ host ^ ":" ^ string_of_int port ^ path
      with
        Not_found -> Http_client_aux.Mtx.unlock mutex; url
      | any -> Http_client_aux.Mtx.unlock mutex; raise any
    let http_get_message url =
      let m = new get (prepare_url url) in request m !http_trials; m
    let http_get url = (http_get_message url)#get_resp_body ()
    let http_head_message url =
      let m = new head (prepare_url url) in request m !http_trials; m
    let http_post_message url params =
      let m = new post (prepare_url url) params in request m 1; m
    let http_post url params = (http_post_message url params)#get_resp_body ()
    let http_put_message url content =
      let m = new put (prepare_url url) content in request m !http_trials; m
    let http_put url content = (http_put_message url content)#get_resp_body ()
    let http_delete_message url =
      let m = new delete (prepare_url url) in request m 1; m
    let http_delete url = (http_delete_message url)#get_resp_body ()
    let http_verbose () =
      Http_client_aux.Mtx.lock mutex;
      try
        let p = Lazy.force pipe in
        let opt = p#get_options in
        p#set_options
          {opt with verbose_status = true; verbose_request_header = true;
            verbose_response_header = true; verbose_request_contents = true;
            verbose_response_contents = true; verbose_connection = true};
        Http_client_aux.Mtx.unlock mutex
      with
        any -> Http_client_aux.Mtx.unlock mutex; raise any
  end


(* ======================================================================
 * History:
 *
 * $Log: http_client.ml,v $
 * Revision 1.1.1.1  2004/07/12 17:35:09  gozdal
 * Imported into local CVS
 *
 * Revision 1.2  2003/01/25 07:22:51  uuu
 *
 * -
 *
 * Revision 1.33  2001/10/26 19:20:14  gerd
 * 	Base64 -> Netencoding.Base64
 *
 * Revision 1.32  2001/09/05 21:41:13  gerd
 * 	Fixed some error handling cases.
 * 	Number of connection trials is now 2.
 *
 * Revision 1.31  2001/09/05 12:44:30  gerd
 * 	Added: message # get_uri
 * 	Added: pipeline # set_proxy_from_environment
 *
 * Revision 1.30  2001/09/02 23:39:24  gerd
 * 	Fixed various minor bugs.
 *
 * Revision 1.29  2001/09/02 19:55:44  gerd
 * 	new option synchronization: it is now possible to handshake
 * using 100 CONTINUE responses. This is new in RFC 2616.
 *
 * Revision 1.28  2000/02/11 13:46:01  gerd
 * 	Bugfix: in B.index_from
 *
 * Revision 1.27  2000/02/11 12:59:53  gerd
 * 	New option: number_of_parallel_connections.
 *
 * Revision 1.26  2000/02/10 22:08:29  gerd
 * 	Bugfix: inhibit_pipelining works now.
 *
 * Revision 1.25  2000/02/10 21:30:56  gerd
 * 	Bugfix: The callback interface was not yet safe. Now every
 * callback is considered "critical".
 * 	Added: If a HTTP/1.0 proxy sends the "proxy-connection: keep-alive"
 * token, the connection is kept open, but without pipelining.
 *
 * Revision 1.24  2000/02/10 19:03:13  gerd
 * 	Bugfix: If a 'connect' is timed out, it was tried to shut down
 * the socket. This is of course impossible. Fix: The exception is caught
 * and ignored.
 *
 * Revision 1.23  2000/02/10 18:10:07  gerd
 * 	Optimization of buffers.
 *
 * Revision 1.22  2000/02/10 17:11:03  gerd
 * 	Added methods 'number_of_open_messages' and
 * 'number_of_open_connections' to improve the possibilities to
 * control the pipeline.
 *
 * Revision 1.21  2000/02/10 02:51:24  gerd
 * 	Improvement: Better memory management using extensible
 * string buffers.
 *
 * Revision 1.20  2000/02/10 00:47:47  gerd
 * 	Bugfix: The client does not expect a message body if the
 * request is a HEAD method; "content-length" lines are ignored.
 * 	Workaround: DNS lookups are done very early, to prevent that
 * DNS errors cause some bad state of the engine. The better solution
 * would be better exception handling.
 * 	Bugfix: The config parameter "maximum_number_of_errors" is now
 * interpreted as the maximum tolerated number of message errors, not
 * as the maximum-1.
 * 	Bugfix: The pseudo exception No_reply is now really used.
 * 	Bugfix: It is taken into account that the message callback
 * may add further requests to the pipeline, and that this may implicitly
 * re-attach the engine to the event queue. (Fixes an Assert_failure.)
 *
 * Revision 1.19  2000/02/04 23:04:12  gerd
 * 	Added code for redirections.
 *
 * Revision 1.18  2000/02/04 22:22:04  gerd
 * 	Added the http_options interface.
 * 	Added that inhibit_persistency is respected.
 * 	Added general connection timeout handling.
 * 	Added pipeline # reset.
 *
 * Revision 1.17  2000/02/04 03:15:48  gerd
 * 	The callback function is called always if the message leaves
 * the queues; i.e. it is also called if the message is simply dropped.
 * 	Unix errors are handled appropriately. EINTR repeats the
 * system call. Other errors clean up the state of the object, and
 * are re-raised. The Unixqueue stops, but is restartable.
 *
 * Revision 1.16  2000/02/03 01:48:20  gerd
 * 	The connection is established in non-blocking mode. -
 * 	There is now a counter that limits the number of connection
 * attempts where the connection first is successful, but never a
 * response from the server is seen.
 * 	The read_queue can no longer become arbitrary longer than
 * the write_queue. There is now a maximum (max_drift). Advantage: If
 * the connection breaks, only max_drift requests must be resent to the
 * server.
 * 	Bugfix: The code that separates the message of the pipeline
 * was wrong. If several replies arrived at once, the first reply
 * triggered an exception because it thought it must have been the
 * last reply. (Under some circumstances; at least that happened if
 * the EOF was reached.)
 *
 * Revision 1.15  2000/01/30 02:44:28  gerd
 * 	The pe timer is also disabled if the queues become empty.
 *
 * Revision 1.14  2000/01/24 03:35:49  gerd
 * 	Added code to handle premature EOFs correctly. An EOF is
 * "premature" if it arrives before any status line. In this case, a
 * special algorithm must be used to reconnect. See all the pe_*
 * variables.
 *
 * Revision 1.13  2000/01/23 23:43:28  gerd
 * 	Bugfix: If the connection crashed in the middle of a large
 * PUT or POST request, the request buffer was not reset. After the
 * new connection was established, the request was simply continued.
 * This is now fixed; the request is restarted in this case.
 * Tested by framed-brokenpipe.
 * 	Added: Handling of EPIPE. This is untested because it is
 * difficult to force a broken pipe situation.
 *
 * Revision 1.12  2000/01/23 20:25:18  gerd
 * 	Improved verbose messages.
 *
 * Revision 1.11  1999/12/21 01:02:53  gerd
 * 	Added "using_proxy" in class "message".
 * 	Integrated the authentication stuff back into the state engine.
 * This has been tested by ad-hoc tests with the local Apache instance.
 * Both "Basic" and "Digest" methods seem to work. The regression tests are
 * still missing.
 * 	Added and updated comments.
 *
 * Revision 1.10  1999/12/13 23:40:36  gerd
 * 	Added: The 'reconnect_mode' stores the way messages
 * are to be handled in the case of a possible reconnection.
 * 	Changed: The 'message' class stores the last exception, and
 * provides a counter for the number of exceptions.
 * 	Changed: Exceptions happening during a request/response round
 * are stored in the 'message' object, and the counter is increased. Such
 * an exception forces aborting the connection.
 * 	Changed: In the case that the connection is closed (or aborted)
 * but some messages are still unsent or we are still waiting for some
 * response, it is checked whether requests may be sent again to the server
 * or not (reconnect mode). If so, the internal state is repaired (the
 * read and write queues are filled up again), and the server is reconnected.
 * 	Added many comments.
 *
 * Revision 1.9  1999/11/21 20:08:40  gerd
 * 	Added class 'post_raw'.
 * 	Improvement: Only a limited amount of octets is sent at once
 * (currently 16384 octets); after this amount it is first checked whether
 * there is already an answer or not before sending continues. This has the
 * advantage that early errors can be detected in a more reliable way.
 * 	Bugfix: If a HTTP/1.0 response or a message with a 'connection:
 * close' token arrives, the connection will be immediately closed, i.e.
 * the client sends an EOF if the server does not. The new instance variable
 * 'done_first_message' stores whether the reply of the first request has
 * already arrived; in this case, another 'output' ressource is added to
 * the event system such that we have a chance to send such an EOF after the
 * first reply.
 * 	Bugfix: If the 'socket_state' changes there may be still events
 * in the queue for the old state. Because of this some assertions were
 * turned into 'if ... then raise Reject', i.e. if there is still some old
 * event it is simply ignored.
 * 	Added: If n_read = n_write after a connection close, the server
 * will be reconnected. [The code for the case n_read <> n_write is still
 * missing.]
 *
 * Revision 1.8  1999/11/15 23:06:00  gerd
 * 	Reviewed the message decoder. If decoding fails, the new
 * exception Bad_message is raised. Furthermore, the status line is
 * decoded very early, and malformed status lines (which indicate
 * that the connection lost synchronization) are rejected immediately.
 * 	The header is only decoded once for every response.
 * 	The 'receive' and 'receive_eof' methods in class 'message_transport'
 * have been updated for the new message decoder.
 * 	The 1XX status responses are handled correctly (I hope). They
 * are now simply discarded before decoding of the message begins.
 * 	Some minor bug fixes.
 *
 * Revision 1.7  1999/11/12 17:44:04  gerd
 * 	Added methods assoc_multi_{req,resp}_header.
 * 	Change: A folded header is normalized. A header entry can be
 * transmitted by multiple lines if the continuation lines begin with
 * spaces or tabs - the HTTP spec says that the continuation has the same
 * semantics as a single space character, and because of this the
 * continuations are actually converted to space characters.
 * 	Fix: The server is allowed to respond with an error code even
 * if the request is not fully sent to the server. This case is handled;
 * note that it is also possible that the server sends "continue" messages
 * to the client while the request is transmitted, which must not be mixed
 * up with the error case. If an error message is detected, the connection
 * is immediately closed.
 * 	Fix: The current request is removed from the write_queue immediately
 * after it has been fully sent to the server; otherwise the write_queue can
 * become longer than the read_queue (violating some assertions).
 *
 * Revision 1.6  1999/10/31 18:01:49  gerd
 * 	Redesign of the 'pipeline' code in order to support pipelining
 * and event-driven programming style. The pipelining code works (tested
 * against Apache only), but a number of conditions are not yet properly
 * handled, and a number of features are not supported yet.
 * 	Conditions: Especially asynchronously closed TCP connections are
 * not properly handled; they simply lead to a "Broken Pipe" exception.
 * HTTP/1.1 specifies here that the client should retry the requests (if
 * they are idempotent), but the 100 return code needs special care.
 * 	Furthermore, the pipeline is not refilled if the server understands
 * only HTTP/1.0. In this case, the write_queue needs to be copied from the
 * read_queue, and the server must be reconnected.
 * 	Missing features: The authentication code has been left out. This
 * is rather simple, because the re-sent requests can be put into the pipeline
 * again. (Possibly it is necessary to insert such requests at the front end
 * of the queues!) Digest authentication needs special care.
 * 	Furthermore, redirections are not followed. This is much more
 * difficult, because a callback from the "connection" class to the
 * "pipeline" class is necessary.
 * 	The implementation is not yet thread-safe. Mainly, a thread-safe
 * version of Equeue is necessary.
 * 	Another missing feature: The dependency on Cgi should go away.
 *
 * Revision 1.5  1999/07/08 02:59:47  gerd
 * 	Added support for multi-threaded applications. All regexps and
 * all system calls have been moved to the module Http_client_aux, for
 * which two implementations exist, one for MT apps, one for non-MT apps.
 * 	The Convenience module has automatic serialization.
 *
 * Revision 1.4  1999/06/10 19:26:15  gerd
 * 	Bugfix: The "basic" authentication method was  added
 * twice to the convenience pipeline, which is incorrect.  Now "basic" and
 * "digest" are added.
 * 	Bugfix: The End-of-file condition while receiving frameless
 * messages (no chunks, no content-length header) does not cause a
 * Broken_connection any longer. Instead, the message consists of all
 * what has been read till EOF.
 * 	Added: In verbose mode, the HTTP protocol version of the
 * server is printed, too.
 *
 * Revision 1.3  1999/06/10 00:12:53  gerd
 * 	Change: The HTTP response codes 301 and 302 ("moved permanently",
 * resp. "moved temporarily") are now interpreted by the 'pipeline' class.
 * (But 303 not (yet?) -- perhaps there should be a switch to turn this
 * feature on or off once it gets implemented...)
 * 	Bugfix: The decision whether a proxy should be used or not works
 * now. The weird function 'dest_query' has gone, it is substituted by
 * 'init_query' which can be called in the initializers of the method
 * subclasses. Thus the query is analyzed very early which is very useful
 * in order to decide if a proxy is needed to reach a certain host.
 * 	Added: There is now a Convenience module which has a simplified
 * interface. It is sufficient for many applications that only want to do
 * simple GET and POST operations.
 *
 * Revision 1.2  1999/06/09 19:41:32  gerd
 * 	Bugfix: Responses that neither have chunked encoding nor
 * are accompanied with a "content-length" header, are now read until
 * EOF. Formerly, the behaviour was that only the first network block
 * was read and the rest was discarded. This was especially a problem
 * with HTTP/1.0 servers and CGI output.
 *
 * Revision 1.1  1999/03/26 01:16:42  gerd
 * 	initial revision
 *
 *
 *)

