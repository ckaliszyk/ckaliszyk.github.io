(* $Id: http_client.mli,v 1.1.1.1 2004/07/12 17:35:09 gozdal Exp $
 * ----------------------------------------------------------------------
 *
 *)

(**********************************************************************)
(* HTTP/1.1 client                                                    *)
(* written by Gerd Stolpmann                                          *)
(**********************************************************************)

(* Implements much of HTTP/1.1.
 * Implements the following advanced features:
 *  - chunked messages
 *  - persistent connections
 *  - connections in pipelining mode ("full duplex" connections)
 *  - modular authentication methods, currently Basic and Digest
 *  - event-driven implementation; allows concurrent service for
 *    several network connections 
 * Left out:
 *  - multipart messages, including multipart/byterange
 *  - content encoding (compression)    (1)
 *  - content digests specified by RFC 2068 and 2069   (1)
 *  - content negotiation   (1)
 *  - conditional and partial GET   (1)
 *  - following code 303 redirections automatically    (1)
 *  - client-side caching   (1)
 *  - HTTP/0.9 compatibility
 *
 * (1) These features can be implemented on top of this module if really needed,
 *     but there is no special support for them.
 *)

(* TODO list:
 * - Currently all data are kept in main memory. It should be possible to
 *   upload from files, and to download into files. (like the Cgi module)
 *   The MIME decoder from Netstring should be used.
 * - digest authentication: should be updated from RFC 2069 to RFC 2617.
 *)

(* RESTRICTED THREAD-SAFETY - NEW SINCE RELEASE 0.3:
 *
 * The module can be compiled such that it is thread-safe. In particular,
 * one has to use the netclient_mt.cm[x]a archive, and thread-safety is
 * restricted to the following kinds of usage:
 * - The golden rule is that threads must not share pipeline objects.
 *   If every thread uses its own pipeline, every thread will have its own
 *   set of state variables.
 *   It is not detected if two threads errornously share a pipeline,
 *   neither by an error message nor by implicit serialization. Strange
 *   things may happen.
 * - The same applies to the other objects: "get", "trace", "options",
 *   "head", "post", "put", "delete", "basic_auth_method", and 
 *   "digest_auth_method". But sharing these objects would make no sense
 *   at all.
 * - Of course, it would be possible to use lots of mutexes to make
 *   the module fully thread-safe. Perhaps in the next release.
 * - The Convenience module serializes; see below.
 *)


(**********************************************************************
 *** NOTE: At the end of this interface specification there is a    ***
 *** SIMPLIFIED interface that is sufficient for many applications. ***
 *** The simplified interface is recommended for beginners.         ***
 **********************************************************************)



exception Header_is_incomplete
exception Body_is_incomplete
exception Body_maybe_complete

exception Bad_message of string
  (* The server sent a message which cannot be interpreted. The string
   * indicates the reason.
   *)

exception Http_error of (int * string)
  (* The server sent an error message. The left component of the pair is
   * the error code, the right component is the error text.
   *)

exception No_reply
  (* There was no response to the request because some other request failed
   * earlier and it was not allowed to send the request again.
   *)


exception Http_protocol of exn
  (* The request could not be processed because the exception condition 
   * was raised.
   *)

type secret
  (* You cannot call methods requiring a parameter of type secret *)

type buffer_type
  (* internally used *)

type token
  (* internally used *)

type 'message_class how_to_reconnect =
    Send_again
  | Request_fails
  | Inquire of ('message_class -> bool)


type 'message_class how_to_redirect =
    Redirect
  | Do_not_redirect
  | Redirect_inquire of ('message_class -> bool)


type synchronization =
    Sync_with_handshake_before_request_body of float
  | Sync
  | Pipeline of int


type http_options =
  { synchronization : synchronization;
    maximum_connection_failures : int;
    maximum_message_errors : int;
    inhibit_persistency : bool;
    connection_timeout : float;
    number_of_parallel_connections : int;
    verbose_status : bool;
    verbose_request_header : bool;
    verbose_response_header : bool;
    verbose_request_contents : bool;
    verbose_response_contents : bool;
    verbose_connection : bool }


(*************************************************************)
(***** class message: core functionality of all messages *****)
(*************************************************************)

class virtual message :
  object ('self)
    method virtual prepare : bool -> unit
    method is_served : bool
    method using_proxy : bool
    method get_host : unit -> string
    method get_port : unit -> int
    method get_uri : unit -> string
    method get_req_body : unit -> string
    method get_req_header : unit -> (string * string) list
    method assoc_req_header : string -> string
    method assoc_multi_req_header : string -> string list
    method set_req_header : string -> string -> unit
    method get_req_uri : unit -> string
    method get_req_method : unit -> string
    method get_resp_header : unit -> (string * string) list
    method assoc_resp_header : string -> string
    method assoc_multi_resp_header : string -> string list
    method get_resp_body : unit -> string
    method dest_status : unit -> string * int * string
    method get_reconnect_mode : message how_to_reconnect
    method set_reconnect_mode : message how_to_reconnect -> unit
    method get_redirect_mode : message how_to_redirect
    method set_redirect_mode : message how_to_redirect -> unit
    method no_proxy : unit -> unit
    method is_proxy_allowed : unit -> bool
    method dump_header : string -> (string * string) list -> unit
    method init_query : secret -> string -> unit
    method set_served : secret -> unit
    method set_unserved : secret -> unit
    method get_request : secret -> string
    method set_response : buffer_type -> bool -> unit
    method get_error_counter : secret -> int
    method set_error_counter : secret -> int -> unit
    method set_error_exception : secret -> exn -> unit
    method decode_header : secret -> unit
    method decode_header_at :
      secret -> buffer_type -> int -> (string * string) list * int
    method decode_body : secret -> bool -> bool -> unit
    method body_is_complete :
      secret -> (string * string) list -> buffer_type -> int -> int
    method received_body_is_complete : secret -> int * int
  end


(*****************************************)
(***** message types by http methods *****)
(*****************************************)

(* For all method classes: the query string MUST NOT contain usernames and
 * passwords!
 *)

class get : string -> object inherit message method prepare : bool -> unit end


class trace :
  string -> int -> object inherit message method prepare : bool -> unit end


class options :
  string -> object inherit message method prepare : bool -> unit end


class head :
  string -> object inherit message method prepare : bool -> unit end


class post :
  string ->
    (string * string) list ->
      object inherit message method prepare : bool -> unit end


class post_raw :
  string -> string -> object inherit message method prepare : bool -> unit end


class put :
  string -> string -> object inherit message method prepare : bool -> unit end


class delete :
  string -> object inherit message method prepare : bool -> unit end



(**********************************)
(***** Authentication methods *****)
(**********************************)

class basic_auth_method :
  object
    val mutable current_realm : string
    method name : string
    method set_realm : string -> string -> string -> unit
    method get_credentials : unit -> string * string
    method www_authenticate : message -> token list -> unit
    method set_authorization : message -> string -> unit
    method update : message -> token list -> unit
  end


class digest_auth_method : object inherit basic_auth_method end



(**********************************************)
(***** class pipeline: the http processor *****)
(**********************************************)

class pipeline :
  object
    method set_event_system : Unixqueue.event_system -> unit
    method add_authentication_method : basic_auth_method -> unit
    method set_proxy : string -> int -> unit
    method set_proxy_auth : string -> string -> unit
    method avoid_proxy_for : string list -> unit
    method set_proxy_from_environment : unit -> unit
    method reset : unit -> unit
    method add : message -> unit
    method add_with_callback : message -> (message -> unit) -> unit
    method run : unit -> unit
    method get_options : http_options
    method set_options : http_options -> unit
    method number_of_open_messages : int
    method number_of_open_connections : int
  end


(**************************************************)
(***** Convenience module for simple purposes *****)
(**************************************************)

(* Do 'open Http_client.Convenience' for simple applications.
 *
 * - The environment variables "http_proxy" and "no_proxy" determine 
 *   the proxy settings. "http_proxy" must be an http-URL that contains
 *   the proxy's name, its port, and optionally user and password.
 *   E.g. "http://eric:eric'spassword@proxy:8080/".
 *   The variable "no_proxy" is a comma-separated list of hosts and
 *   domains for which no proxy must be used.
 *   E.g. "localhost, sun, moon, .intra.net"
 * - There is a default behaviour to authenticate. Both "basic" and "digest"
 *   methods are enabled. Two global variables, http_user and http_password
 *   set the user and password if the URL does not specify them. In the case
 *   that user and password are included in the URL, these values are always
 *   used.
 * - There is a default error behaviour. If a request fails, it is automatically
 *   repeated. The variable http_trials specifies the number of times a request
 *   is submitted at most.
 *   Requests are not repeated if there is a HTTP return code that indicates
 *   a normal operating condition.
 *   POST and DELETE requests are never repeated.
 *)

(* RESTRICTED THREAD SAFETY - NEW SINCE RELEASE 0.3:
 *
 * The Convenience module is fully thread-safe with the exception of the
 * exported variables (http_trials, http_user, and http_password). Note
 * that all threads share the same pipeline, and access to the pipeline
 * is serialized.
 * The latter simply means that it always works, but that threads may 
 * block each other (i.e. the program slows down if more than one thread
 * wants to open http connections at the same time).
 *)


module Convenience :
  sig
    val http_trials : int ref
    val http_user : string ref
    val http_password : string ref
    val http_get_message : string -> message
    val http_head_message : string -> message
    val http_post_message : string -> (string * string) list -> message
    val http_put_message : string -> string -> message
    val http_delete_message : string -> message
    val http_get : string -> string
    val http_post : string -> (string * string) list -> string
    val http_put : string -> string -> string
    val http_delete : string -> string
    val http_verbose : unit -> unit
  end


(* ======================================================================
 * History:
 * 
 * $Log: http_client.mli,v $
 * Revision 1.1.1.1  2004/07/12 17:35:09  gozdal
 * Imported into local CVS
 *
 * Revision 1.2  2003/01/25 07:22:51  uuu
 *
 * -
 *
 * Revision 1.18  2001/09/05 12:44:30  gerd
 * 	Added: message # get_uri
 * 	Added: pipeline # set_proxy_from_environment
 *
 * Revision 1.17  2001/09/02 19:55:44  gerd
 * 	new option synchronization: it is now possible to handshake
 * using 100 CONTINUE responses. This is new in RFC 2616.
 *
 * Revision 1.16  2000/02/11 12:59:53  gerd
 * 	New option: number_of_parallel_connections.
 *
 * Revision 1.15  2000/02/10 17:11:03  gerd
 * 	Added methods 'number_of_open_messages' and
 * 'number_of_open_connections' to improve the possibilities to
 * control the pipeline.
 *
 * Revision 1.14  2000/02/10 02:51:42  gerd
 * 	Updated comments.
 * 	Updated signatures of internal methods.
 *
 * Revision 1.13  2000/02/04 23:03:58  gerd
 * 	Added interface for redirection control. Note that automatic
 * redirection is performed only for 301 and 302 type redirections,
 * and by default only for GET and HEAD requests. The latter may be
 * changed. (Type 303 redirections demand that a GET request must be
 * used - better the user of Netclient does it itself. Type 300
 * redirections are used for content negotiation - no idea how to
 * support that.)
 *
 * Revision 1.12  2000/02/04 22:20:36  gerd
 * 	Added http_options interface (and removed all the verbose_* stuff).
 * -
 * 	Updated the comments.
 *
 * Revision 1.11  2000/02/03 01:49:04  gerd
 * 	New exception: No_reply.
 *
 * Revision 1.10  2000/01/24 03:39:54  gerd
 * 	Exception Broken_connection removed. The code to automatically
 * reconnect even in catastrophe situations has been added.
 *
 * Revision 1.9  1999/12/21 01:00:03  gerd
 * 	Added method "using_proxy". This was necessary be the internal
 * logic of the client.
 *
 * Revision 1.8  1999/12/13 23:30:55  gerd
 * 	New exceptions: Bad_message and Http_protocol.
 * 	Added: Type 'how_to_reconnect'. It is now possible to set the
 * reconnection mode (get/set_reconnect_mode).
 * 	Changed: The message object can store the last exception which
 * aborted the connection, and it counts the number of such exceptions.
 * Normally, such an exception only forces that the request is sent again,
 * but this is limited by a maximum number of exceptions that are allowed
 * to occur.
 * 	Added: class post_raw.
 *
 * Revision 1.7  1999/11/15 23:06:20  gerd
 * 	Updated the signatures of internal methods.
 *
 * Revision 1.6  1999/11/12 17:33:44  gerd
 * 	Added methods assoc_multi_{req,resp}_header.
 *
 * Revision 1.5  1999/10/31 18:02:10  gerd
 * 	Preparing the pipelining version of the client.
 *
 * Revision 1.4  1999/07/08 03:00:03  gerd
 * 	Added comments how to use the new MT support.
 *
 * Revision 1.3  1999/06/10 19:28:01  gerd
 * 	Added Message_maybe_complete.
 *
 * Revision 1.2  1999/06/10 00:12:54  gerd
 * 	Change: The HTTP response codes 301 and 302 ("moved permanently",
 * resp. "moved temporarily") are now interpreted by the 'pipeline' class.
 * (But 303 not (yet?) -- perhaps there should be a switch to turn this
 * feature on or off once it gets implemented...)
 * 	Bugfix: The decision whether a proxy should be used or not works
 * now. The weird function 'dest_query' has gone, it is substituted by
 * 'init_query' which can be called in the initializers of the method
 * subclasses. Thus the query is analyzed very early which is very useful
 * in order to decide if a proxy is needed to reach a certain host.
 * 	Added: There is now a Convenience module which has a simplified
 * interface. It is sufficient for many applications that only want to do
 * simple GET and POST operations.
 *
 * Revision 1.1  1999/03/26 01:16:42  gerd
 * 	initial revision
 *
 * 
 *)
