DIR:=Common/Http_client
TARGET:=http_client.$(LIB_SUF)
FILES:=http_client_aux http_client
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -a -o $@ $^
