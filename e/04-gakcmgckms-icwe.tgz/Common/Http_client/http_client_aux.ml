(* $Id: http_client_aux.ml,v 1.1.1.1 2004/07/12 17:35:09 gozdal Exp $
 * ----------------------------------------------------------------------
 * Auxiliary functions: this version uses the xstr package and is
 * multithreading-safe.
 *)

open Xstr_match
open Xstr_split

let digits = mkset "0-9"
let hex_digits = mkset "0-9a-fA-F"
let space_tab = mkset " \t"
let no_slash_no_colon = mknegset "/:"
let no_slash_no_colon_no_at = mknegset "/:@"
let no_space = mknegset " "
let no_space_no_tab = mknegset " \t"
let no_cr_no_lf = mknegset "\n\r"


let ms which re s =
  try match_string re s with
    Failure e as f -> prerr_endline ("Failure in " ^ which); raise f


let match_query query =
  let host = var "" in
  let port = var "80" in
  let path = var "" in
  let query_re =
    [Literal "http://";
     Record
       (host,
        [Anychar_from no_slash_no_colon; Anystring_from no_slash_no_colon]);
     Optional
       [Literal ":";
        Record (port, [Anychar_from digits; Anystring_from digits])];
     Record (path, [Anystring_from no_space])]
  in
  if match_string query_re query then
    String.lowercase (found_string_of_var host),
    int_of_string (string_of_var port), found_string_of_var path
  else raise Not_found


let match_status status_line =
  let version = var "" in
  let code = var "" in
  let message = var "" in
  let status_re =
    [Record
       (version,
        [Anychar_from no_space_no_tab; Anystring_from no_space_no_tab]);
     Anychar_from space_tab; Anystring_from space_tab;
     Record
       (code,
        [Anychar_from digits; Anychar_from digits; Anychar_from digits]);
     Anychar_from space_tab; Anystring_from space_tab;
     Record (message, [Anystring_from no_cr_no_lf]); Optional [Literal "\r"]]
  in
  if match_string status_re status_line then
    found_string_of_var version, int_of_string (found_string_of_var code),
    found_string_of_var message
  else raise Not_found
  

let match_header_line line =
  let name = var "" in
  let value = var "" in
  let line_re =
    [Record
       (name, [Anychar_from no_space_no_tab; Anystring_from no_space_no_tab]);
     Anystring_from space_tab; Literal ":"; Anystring_from space_tab;
     Record (value, [Anystring])]
  in
  if match_string line_re line then
    String.lowercase (found_string_of_var name), found_string_of_var value
  else raise Not_found


let match_hex hex =
  let hexnum = var "" in
  let hex_re =
    [Record (hexnum, [Anychar_from hex_digits; Anystring_from hex_digits]);
     Anystring]
  in
  if match_string hex_re hex then found_string_of_var hexnum
  else raise Not_found


let match_ip ip =
  let ipnum = var "" in
  let ip_re =
    [Record
       (ipnum,
        [Anychar_from digits; Anystring_from digits; Literal ".";
         Anychar_from digits; Anystring_from digits; Literal ".";
         Anychar_from digits; Anystring_from digits; Literal ".";
         Anychar_from digits; Anystring_from digits])]
  in
  if match_string ip_re ip then ip else raise Not_found


let match_http url =
  let user = var "" in
  let password = var "" in
  let host = var "" in
  let port = var "" in
  let path = var "" in
  let http_re =
    [Literal "http://";
     Optional
       [Record
          (user,
           [Anychar_from no_slash_no_colon_no_at;
            Anystring_from no_slash_no_colon_no_at]);
        Optional
          [Literal ":";
           Record
             (password,
              [Anychar_from no_slash_no_colon_no_at;
               Anystring_from no_slash_no_colon_no_at])];
        Literal "@"];
     Record
       (host,
        [Anychar_from no_slash_no_colon_no_at;
         Anystring_from no_slash_no_colon_no_at]);
     Optional
       [Literal ":";
        Record (port, [Anychar_from digits; Anystring_from digits])];
     Optional [Record (path, [Literal "/"; Anystring])]]
  in
  if match_string http_re url then
    (try Some (found_string_of_var user) with
       Not_found -> None),
    (try Some (found_string_of_var password) with
       Not_found -> None),
    found_string_of_var host,
    (try int_of_string (found_string_of_var port) with
       Not_found -> 80),
    (try found_string_of_var path with
       Not_found -> "")
  else raise Not_found
	  
		
let split_words_by_commas = split_string " \t\r\n" true true [","]


module Mtx = Mutex  

(* ======================================================================
 * History:
 * 
 * $Log: http_client_aux.ml,v $
 * Revision 1.1.1.1  2004/07/12 17:35:09  gozdal
 * Imported into local CVS
 *
 * Revision 1.2  2003/01/25 07:22:51  uuu
 *
 * -
 *
 * Revision 1.2  2001/09/05 21:43:03  gerd
 * 	Updated
 *
 * Revision 1.1  1999/07/08 03:00:47  gerd
 * 	Initial revision.
 *
 * 
 *)
