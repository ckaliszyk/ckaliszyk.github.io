type forced_t = {
  mutable providers: (string -> string) list; (** List of provider in order of decreasing priority. *)
};;

type t = forced_t lazy_t;;

let current_prov = ref { providers = []; }
;;

let create prog_name =
  Log.echo ("Config.create " ^ prog_name);
  CommandLine.read_args prog_name;

  let _providers = [] in
  let _providers = (ConfigOverseer.init (CommandLine.get_overseer ())) :: _providers in
  let _providers = (ConfigPlainFile.init (CommandLine.get_plainfile ())) :: _providers in
  
  Log.echo ("Using Overseer on " ^ (CommandLine.get_overseer ()));
  Log.echo ("Using config file " ^ (CommandLine.get_plainfile ()));

  lazy ( { providers = _providers; } )
;;

let get lazy_config param_name =
  let config = Lazy.force lazy_config in
  Log.echo ("Config.get " ^ param_name);
  let check_provider prov =
    try prov param_name; true
    with Not_found -> false
  in
  let ret = try 
    let first_provider = List.find check_provider config.providers in
    first_provider param_name
  with 
  | Not_found -> ""
  in 
  Log.echo ("Config.get returning " ^ ret);
  ret
;;

(**

let dump_info cout = 
  let print s = output_string cout ("# " ^ s ^ "\n")
  in
  print "This file is configuration dumped from Overseer.";
  print "It is read by Overseer on (re)start.";
  print "Overseer stores configuration in table 'config'.";
  print "Table 'config' is of type string * string.";
  print "Key is option name, and value is option value";
  print "- - - - - - - - - - - - - - - - - - - - - - - - -\n";
  print "Option description:";
  print "searchfile: name of file that is refered to when searching";
  print "query: name of GET argument that stores query to searchengine";
  print "page: name of GET argument that stores number of search result";
  print "      page to be displayed";
  print "and: AND conjunction in queries to searchengine";
  print "or: OR conjunction in queries to searchengine";
  print "minus: MINUS conjunction in queries to searchengine";
  print "min_length: minumum length of word interesting to searchengine";
  print "max_length: maximum length of word interesting to searchengine";
  print "uninteresting: list of words uninteresting to searchengine";
  print "links_per_page: number of links per search result page";
  print "global_share: number of 'global' links per search result page";
  print "criteria: list of int identifiers of criterias used to judge pages";
  print "fixed_weights: weights to use in all situations";
  print "adapter_links: number of links to be added by Adapter (deafault)";
  print "searchengine: (\"SEE\" or \"LOCAL\") use SEE or not? (deafault)";
  print "- - - - - - - - - - - - - - - - - - - - - - - - -\n";

;;

let dump lst = 
  let cout = 
    try
      open_out config_file 
    with
    | Sys_error s -> failwith ("Writing to config file failed: " ^ s)
  in
  let dumper (name, aval) = 
    output_string cout (name ^ " = " ^ aval ^ "\n")
  in
  dump_info cout;
  List.iter dumper lst;
  close_out cout
;;

read ();;

*)
