(** Interface of configuration provider which is backed up by Overseer database.

    @author Marcin Gozdalik
*)

(** [init overseer_addr] Reads configuration table from Overseer located on
    [overseer_addr] returns a config provider. 
*)
val init: string -> (string -> string);;
