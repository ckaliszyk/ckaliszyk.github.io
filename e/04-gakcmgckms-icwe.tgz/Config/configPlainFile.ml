(** Implementation of configuration provider which is backed up by a plain text
    file.

    @author Marcin Gozdalik
*)

(** [provider param_hash param_name] looks up [param_name] in hash table
    [param_hash]. *)
let provider param_hash param_name = 
  Hashtbl.find param_hash param_name
;;

let read file_name = 
  let cin = 
    try
      open_in file_name
    with
    | Sys_error s -> failwith ("While trying to read " ^ file_name ^ ": " ^ s)
  in
  let name = ref "" in
  let eq = ref "" in
  let aval = ref "" in
  let lst = ref [] in
  let scanner r s = r:=s in
  let rec get () = 
    try
      let _ = 
        try
          (* reading option name *)
          Scanf.fscanf cin "%s" (scanner name);
          if (String.get !name 0) = '#' then
            failwith "comment";
          (* reading = *)
          Scanf.fscanf cin "%s" (scanner eq);
        with
        | _ -> eq := ""
      in
      (* reading val *)
      aval := input_line cin;
      if !eq = "=" then 
        lst := (!name, !aval) :: !lst;
      get ()
    with
    | End_of_file -> () 
  in 
  let _ = 
    try 
      get () 
    with | _ -> ()
  in
  close_in cin;
  !lst
;;

(** [init file_name] Reads configuration file [file_name] and return provider
    which returns values stored in the file. *)
let init file_name =
  let params = read file_name in
  let hash_tab = Hashtbl.create 100 in
  let adder (key, value) = Hashtbl.add hash_tab key value in
  let _ = List.iter adder params in
  provider hash_tab
;;

let iter file_name f =
  let params = read file_name in
  List.iter f params
;;
