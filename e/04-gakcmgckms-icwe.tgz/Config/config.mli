(** Abstract configuration module able to retrieve parameters from different
 * sources. Implemented modules include plain file and Overseer storage.
 *
 * Syntax of plain file configuration:
 * Each line should be of one of the forms:
 * - <param_name> = <param value>
 * - # comment... should have more than two words... ;)
 *
 * Overseer configuration provider reads parameters from a table in 
 * {!Overseer}. The table is a hashtable from string to string.
 *
 * @author Mateusz Srebrny
 * @author Marcin Gozdalik
 *) 

(** Abstract type to retrieve configuration parameters from. *)
type t;;

(** [init prog_name] initializes Config subsystem using options passed in
 * command line and returns object which then can be queried using [get].
*)
val create : string -> t;;

(** [get config param_name] retrieve config setting from [config] for [param_name].
*)
val get : t -> string -> string;;
