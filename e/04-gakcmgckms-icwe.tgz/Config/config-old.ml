let config_file = "sie.config";;


let read () = 
  let cin = 
    try
      open_in config_file
    with
    | Sys_error s -> failwith ("Reading config file failed: " ^ s)
  in
  let name = ref "" in
  let eq = ref "" in
  let aval = ref "" in
  let lst = ref [] in
  let scanner r s = r:=s in
  let rec get () = 
    try
      let _ = 
        try
          (* reading option name *)
          Scanf.fscanf cin "%s" (scanner name);
          if (String.get !name 0) = '#' then
            raise (Failure "comment");
          (* reading = *)
          Scanf.fscanf cin "%s" (scanner eq);
        with
        | _ -> eq := ""
      in
      (* reading val *)
      aval := input_line cin;
      if !eq = "=" then 
        lst := (!name, !aval) :: !lst;
      get ()
    with
    | End_of_file -> () 
  in 
  let _ = 
    try 
      get () 
    with | _ -> ()
  in
  close_in cin;
  !lst
;;


let dump_info cout = 
  let print s = output_string cout ("# " ^ s ^ "\n")
  in
  print "This file is configuration dumped from Overseer.";
  print "It is read by Overseer on (re)start.";
  print "Overseer stores configuration in table 'config'.";
  print "Table 'config' is of type string * string.";
  print "Key is option name, and value is option value";
  print "- - - - - - - - - - - - - - - - - - - - - - - - -\n";
  print "Option description:";
  print "searchfile: name of file that is refered to when searching";
  print "query: name of GET argument that stores query to searchengine";
  print "page: name of GET argument that stores number of search result";
  print "      page to be displayed";
  print "and: AND conjunction in queries to searchengine";
  print "or: OR conjunction in queries to searchengine";
  print "minus: MINUS conjunction in queries to searchengine";
  print "min_length: minumum length of word interesting to searchengine";
  print "max_length: maximum length of word interesting to searchengine";
  print "uninteresting: list of words uninteresting to searchengine";
  print "links_per_page: number of links per search result page";
  print "global_share: number of 'global' links per search result page";
  print "criteria: list of int identifiers of criterias used to judge pages";
  print "fixed_weights: weights to use in all situations";
  print "adapter_links: number of links to be added by Adapter (deafault)";
  print "searchengine: (\"SEE\" or \"LOCAL\") use SEE or not? (deafault)";
  print "- - - - - - - - - - - - - - - - - - - - - - - - -\n";

;;

let dump lst = 
  let cout = 
    try
      open_out config_file 
    with
    | Sys_error s -> failwith ("Writing to config file failed: " ^ s)
  in
  let dumper (name, aval) = 
    output_string cout (name ^ " = " ^ aval ^ "\n")
  in
  dump_info cout;
  List.iter dumper lst;
  close_out cout
;;

read ();;
