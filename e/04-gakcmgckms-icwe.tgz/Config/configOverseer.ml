let param_mutex = Mutex.create ();;

let param_hash = ref (Hashtbl.create 0);;

(** [provider param_name] looks up [param_name] in parameters hash table. *)
let provider param_name = 
  Log.echo ("ConfigOverseer provider: " ^ param_name);
  Mutex.lock param_mutex;
  let ret = try
    Hashtbl.find !param_hash param_name
  with
  | Not_found -> (
    Mutex.unlock param_mutex;
    raise Not_found;
  )
  in
  Mutex.unlock param_mutex;
  Log.echo ("ConfigOverseer returning: " ^ ret);
  ret
;;

let rec notify_cb table_name =
  assert (table_name = Db.config_table_name);
  update_params()

and
  (* TODO: currently run-time changing of params doesn't work *)
  config_table () = 
    Db.init Db.config_table_name None

and
  update_params () =
    Mutex.lock param_mutex;
    let _ = param_hash := (
      match Db.get (config_table()) () with
      | None -> Hashtbl.create 0
      | Some(table) -> table
    ) 
    in
    Mutex.unlock param_mutex
;;
    

(** [init overseer_addr] Reads configuration table from Overseer running on
* [overseer_addr]. Returns provider which takes string (key) and returns string
* (value).
* Throws Not_found if key is not found.
*)
let init overseer_addr =
  update_params();
  provider
