(** Interface of configuration provider which is backed up by a plain text
    file.

    @author Marcin Gozdalik
*)

(** [init file_name] Reads configuration file [file_name] and return provider
    which returns values stored in the file. 
*)
val init: string -> (string -> string);;

(** [iter file_name iter_fun] 
 *)
val iter: string -> ((string * string) -> unit) -> unit;;
