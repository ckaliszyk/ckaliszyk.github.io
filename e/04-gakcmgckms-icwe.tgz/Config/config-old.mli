(* config.mli
 *
 * 2003.05.07,  Mateusz Srebrny 
 *)


(** Module Config is responsible for configuration file for whole SIE.
 *
 *  It's name is 'sie.config'.
 *  Syntax of this file is rather simple.
 *  Each line should be of one of the forms:
 *  - <param_name> = <param value>
 *  - # comment... should have more than two words... ;)
 *
 *  The values are defaultly located in {!Overseer} in table named 'config'.
 *  The table is hastable of type (string, string).
 *  It means that values (as well as names) are interpreted as strings and
 *  should be reinterpreted by users.
 *
 *  @author Mateusz Srebrny
 *) 

(** Reads configuration file and returns all (name, value) pairs.
 *  Used by {!Overseer} on startup and upon receiving SIGHUP.
 *
 *  @return list of pairs - configuration to be written to table 'config'
 *  @author Mateusz Srebrny
 *)
val read : unit -> (string * string) list;;

(** [dump conf_list] Overwrites configuration file with configuration
 *  for conf_list.
 *  Used by {! Overseer} upon receiving SIGUSR1.
 *
 *  @param conf_list list of pairs (param_name, param_value)
 *  @author Mateusz Srebrny
 *)
val dump : (string * string) list -> unit;;
