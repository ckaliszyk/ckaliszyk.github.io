open Genlex

type type_expr = Int_type | String_type | Bool_type

type expr =
  | Int_const of int 
  | String_const of string 
  | Bool_const of bool
  | Variable of string
  | Unary_op of string * expr
  | Binary_op of string * expr * expr
  | Current_page

type instr = 
  | Assign of string * expr
  | Block of instr list
  | Declaration of string * type_expr * expr
  | Pass
  | If of expr * instr * instr
  | While of expr * instr

  | Delay of float
  | Print of expr

  | Goto of expr 
  | Click of (expr option) * (expr option)
  | Back
  | Submit of (expr option) * ((expr * expr) list)

let unary_ops = ["not"; "-"]
let binary_ops = ["+"; "-"; "*"; "/"; "=="; "!="; "<"; "<="; ">"; ">="; "and"; "or"; "matches"; "extract"]
let other_kwds = 
  ["("; ")"; "true"; "false"; "current_page"; "="; "int"; "string"; "bool";
   "goto"; "click"; "click_url"; "submit"; "submit_url"; "back"; "delay";
   "if"; "then"; "else"; "while"; "do"; 
   "print";  "{"; "}"; "pass"; ";"
  ]

let rec parse_list parse_elt separator = 
  let rec parse_tail = parser
    | [< 'Kwd s when s = separator; elt = parse_elt; tail = parse_tail>] -> elt :: tail
    | [< >] -> []
  in parser
  | [< elt = parse_elt; tail = parse_tail >] -> elt :: tail
  | [< >] -> []
;;

let rec parse_simple_expr = parser
  | [< 'Kwd "("; e = parse_expr; 'Kwd ")" >] -> e
  | [< 'Kwd "false">] -> Bool_const false
  | [< 'Kwd "true" >] -> Bool_const true
  | [< 'String s >] -> String_const s
  | [< 'Int i >] -> Int_const i
  | [< 'Ident id >] -> Variable id
  | [< 'Kwd "current_page" >] -> Current_page
  | [< 'Kwd op when List.mem op unary_ops; e = parse_expr >] -> Unary_op (op, e)
and parse_rest_expr e1 = parser
  | [< 'Kwd op when List.mem op binary_ops ; e2 = parse_expr >] -> Binary_op (op, e1, e2)
  | [< >] -> e1
and parse_expr = parser
  | [< e1 = parse_simple_expr; e2 = parse_rest_expr e1 >] -> e2

let parse_type = parser
  | [<'Kwd "int" >] -> Int_type
  | [<'Kwd "string" >] -> String_type
  | [<'Kwd "bool" >] -> Bool_type

let rec parse_params = parser
  | [<e1 = parse_expr; 'Kwd "="; e2 = parse_expr; tail = parse_params >] -> (e1, e2) :: tail
  | [< >] -> []
 
let rec parse_instr lexems = 
  match lexems with parser
  | [< t = parse_type; 'Ident i; 'Kwd "="; e = parse_expr>] -> Declaration (i, t, e)
  | [<'Kwd "goto"; e = parse_expr>] -> Goto e
  | [<'Kwd "click"; e = parse_expr>] -> Click (Some e, None)
  | [<'Kwd "click_url"; e = parse_expr>] -> Click (None, Some e)
  | [<'Kwd "back" >] -> Back
  | [<'Kwd "delay"; 'Float f>] -> Delay f
  | [<'Kwd "submit"; params = parse_params >] -> Submit (None, params)
  | [<'Kwd "submit_url"; url_e = parse_expr; params = parse_params >] -> Submit (Some url_e, params)
  | [<'Kwd "if"; cond = parse_expr; 'Kwd "then"; then_i = parse_instr >] ->
      let else_i =
        match lexems with parser
        | [<'Kwd "else"; i = parse_instr >] -> i
        | [< >] -> Block []
      in If (cond, then_i, else_i)
  | [<'Kwd "while"; cond = parse_expr; 'Kwd "do"; i = parse_instr >] -> While (cond, i)
  | [<'Ident id; 'Kwd "="; e = parse_expr>] -> Assign (id, e)
  | [<'Kwd "print"; e = parse_expr >] -> Print e
  | [<'Kwd "{"; l = parse_list parse_instr ";"; 'Kwd "}" >] -> Block l
  | [<'Kwd "pass" >] -> Pass
  | [< >] -> Pass

let parse stream = 
  let lexer = Genlex.make_lexer (unary_ops @ binary_ops @ other_kwds) in
  let lexems = lexer stream in
  Block (parse_list parse_instr ";" lexems)

