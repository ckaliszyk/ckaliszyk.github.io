type 'a t 

val empty : 'a t
val add : string -> 'a -> 'a t -> 'a t
val get : string -> 'a t -> 'a
