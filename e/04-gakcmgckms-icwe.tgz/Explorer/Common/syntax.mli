type type_expr = Int_type | String_type | Bool_type

type expr =
  | Int_const of int 
  | String_const of string 
  | Bool_const of bool
  | Variable of string
  | Unary_op of string * expr
  | Binary_op of string * expr * expr
  | Current_page

type instr = 
  | Assign of string * expr
  | Block of instr list
  | Declaration of string * type_expr * expr
  | Pass
  | If of expr * instr * instr
  | While of expr * instr

  | Delay of float
  | Print of expr

  | Goto of expr 
  | Click of (expr option) * (expr option)
  | Back
  | Submit of (expr option) * ((expr * expr) list)


val parse : char Stream.t -> instr

