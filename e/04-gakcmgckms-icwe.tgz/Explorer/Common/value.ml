exception Execution_error of string

type t = 
  | Int    of int
  | String of string 
  | Bool   of bool

let error s = raise (Execution_error s)

let int = function
  | Int i -> i
  | _ -> error "not an int value"

let string = function
  | String s -> s
  | _ -> error "not a string value"

let bool = function 
  | Bool b -> b
  | _ -> error "not a bool value"

let print v = 
  let str = 
    match v with
    | Int i -> string_of_int i
    | String s -> s
    | Bool b -> if b then "true" else "false"
  in
  print_endline str;
  flush stdout

