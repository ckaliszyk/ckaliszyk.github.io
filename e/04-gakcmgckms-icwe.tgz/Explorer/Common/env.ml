type 'a t = (string * 'a) list

let empty = []
let add var var_val env = (var, var_val) :: env
let get var env = 
  try List.assoc var env with Not_found -> Value.error ("variable " ^ var ^ " not found");;
 
