exception Execution_error of string

type t = 
  | Int of int
  | String of string 
  | Bool of bool

val int    : t -> int
val string : t -> string
val bool   : t -> bool
val print  : t -> unit

val error  : string -> 'a