exception At_starting_page
;;

exception Update_frame of string option * Www.t option (* (nazwa ramki, nowa tresc ramki) *)
;;

exception New_full_page of Www.t
;;

let history = Stack.create ()
;;

let regexp_of_option = function
  | Some x -> x
  | None -> Str.regexp "[.\n]*"
;;

(* zwraca pare string option (target, href) reprezentujaca a_tag dopasowany do regexpa *)
let rec get_a_tag regexp url_regexp = function
  | h::t -> begin
      match get_a_tag_aux regexp url_regexp h with
      | None, None -> get_a_tag regexp url_regexp t
      | x -> x
  end
  | [] -> None, None
and get_a_tag_aux regexp url_regexp = function
  | Nethtml.Element ("a", args, subnodes) -> begin
      let href = Www.extract_param "href" args in
      match href with
      | None -> None, None
      | Some x ->
	  if Str.string_match url_regexp x 0 then
	    let buf = Buffer.create 16 in
	    Nethtml.write ~dtd: Nethtml.relaxed_html40_dtd
	      (*(new Netchannels.output_buffer buf)*) (Buffer.add_string buf) subnodes;
	    if Str.string_match regexp (Buffer.contents buf) 0 then
	      Www.extract_param "target" args, href
	    else None, None
	  else
	    None, None
  end
  | Nethtml.Element (_, _, subnodes) ->
      get_a_tag regexp url_regexp subnodes
  | Nethtml.Data _ -> None, None
;;

(* to jest hardcore

   jesli uzytkownik kliknal na cos, co sie otwiera w ramce, to funkcja zwraca
   'pelna' strone z podmieniona odpowiednia ramka (gotowe do wrzucenia do
   history)

   jesli uzytkownik kliknal na cos co sie otwiera nie w ramce, to funkcja
   rzuca New_full_page z argumentem bedacym sciagnieta nowa 'pelna' strona
   jesli uzytkownik kliknal cos czego nie ma na stronie, to funkcja rzuca
   Not_found

   jesli strona jest Document costam (nie Frames), to funkcja moze dodatkowo
   rzucic Update_frame, ktory trzeba przechwycic na zewnatrz - taka sytuacja
   moglaby sie zdarzyc przy niepoprawnej stronie (no bo skoro jest tylko
   Document, to nie ma ramek, a jakis link kaze otwierac w ramce) 
*)
let rec click_a_tag regexp url_regexp = function
  | Www.Frames frames ->
      let aux (name, frame) =
	match frame with
	| None -> name, frame
	| Some fr ->
	    try name, Some (click_a_tag regexp url_regexp fr) with
	    | Not_found -> name, None in
      Www.Frames begin
	try ignore (List.map aux frames); raise Not_found with
	| Update_frame (name, page) ->
	    ((name, page)::(List.remove_assoc name frames))
      end
  | Www.Document (base, target, page) ->
      match target, get_a_tag regexp url_regexp
	  (Nethtml.parse ~dtd: Nethtml.relaxed_html40_dtd (new Netchannels.input_string page)) with (* szukamy taga do klikniecia *)
      | _, (_, None) -> (* nie znaleziono taga lub brakuje mu hrefa *)
	  raise Not_found
      | None, (None, Some href) -> (* otwieramy nowa strone (nie ma targeta) *)
	  raise (New_full_page (Www.get_full_page (Www.apply_base base href) (Www.Method_get [])))
      | targ, (None, Some href)
      | _, (targ, Some href) -> (* otwieramy w ramce *)
	  raise (Update_frame
	    (targ,
	     try Some (Www.get_full_page (Www.apply_base base href) (Www.Method_get [])) with
	     | Www.Dead_link -> None))
;;

let match_controls controls supplied =
  let filter_hidden = function
    | _, Form.Hidden _ -> true
    | _ -> false in
  let hidden = List.filter filter_hidden controls
  and not_hidden = List.filter (fun x -> not (filter_hidden x)) controls in
  let not_hidden_names = fst (List.split not_hidden)
  and supplied_names = fst (List.split supplied) in
  match (List.sort compare not_hidden_names) = (List.sort compare supplied_names) with
  | false -> None
  | true -> Some (supplied @ (List.map Form.loose_input_type hidden))
;;

(*let rec get_form_nethtml supplied = function
  | h::t -> begin
      match aux_get_form_nethtml supplied h with
      | _, None -> get_form_nethtml supplied t
      | x -> x
  end
  | [] -> None, None
and aux_get_form_nethtml supplied = function
  | Nethtml.Element ("form", args, subnodes) -> begin
      Printf.printf "zxcv\n";
      let buf = Buffer.create 16 in
      Nethtml.write ~dtd: Nethtml.relaxed_html40_dtd
	(new Netchannels.output_buffer buf) (*(Buffer.add_string buf)*) subnodes;
      List.iter (fun (a, b) -> Printf.printf "%s=%s\n" a b) args;
      Printf.printf "%s" (Buffer.contents buf);
      Printf.printf "zxcv\n";
      try
	let action = List.assoc "action" args
	and controls = Form.preprocess_form [] subnodes in
	Www.extract_param "target" args,
	match match_controls controls supplied with
	| None -> None
	| Some params ->
	    Some (action,
		  try
		    match List.assoc "method" args with
		    | "post" -> Www.Method_post params
		    | _ -> Www.Method_get params
		  with
		  | Not_found -> Www.Method_get params (* domyslnie get *))
      with
      | Not_found -> None, None
  end
  | Nethtml.Element (_, _, subnodes) ->
      get_form_nethtml supplied subnodes
  | Nethtml.Data _ -> None, None
;;*)

let get_form supplied page =
  let start_regexp = Str.regexp_case_fold "<form [^>]*>" (* chyba newline tez powinien sie matchowac... *)
  and end_regexp = Str.regexp_case_fold "</form>" in
  let rec aux pos =
    let header_s = Str.search_forward start_regexp page pos in
    let header_e = Str.match_end () in
    let end_s = Str.search_forward end_regexp page header_e in
    let end_e = Str.match_end () in
    let header = String.sub page header_s (header_e - header_s)
    and cont = String.sub page header_e (end_s - header_e) in
    let res =
      match (Nethtml.parse ~dtd: Nethtml.relaxed_html40_dtd (new Netchannels.input_string header)) with
      | [Nethtml.Element ("form", args, _)] -> begin
	  try
	    let action = List.assoc "action" args
	    and controls = Form.preprocess_form []
		(Nethtml.parse ~dtd: Nethtml.relaxed_html40_dtd (new Netchannels.input_string cont)) in
	    Www.extract_param "target" args,
	    match match_controls controls supplied with
	    | None -> None
	    | Some params ->
		Some (action,
		      try
			match List.assoc "method" args with
			| "post" -> Www.Method_post params
			| _ -> Www.Method_get params
		      with
		      | Not_found -> Www.Method_get params (* domyslnie get *))
	  with
	  | Not_found -> None, None
      end
      | _ -> None, None in
    match res with
    | (_, None) -> aux end_e
    | _ -> res in
  try aux 0 with
  | Not_found -> None, None
;;

let rec submit_form controls = function
  | Www.Frames frames ->
      let aux (name, frame) =
	match frame with
	| None -> name, frame
	| Some fr ->
	    try name, Some (submit_form controls fr) with
	    | Not_found -> name, None in
      Www.Frames begin
	try ignore (List.map aux frames); raise Not_found with
	| Update_frame (name, page) ->
	    ((name, page)::(List.remove_assoc name frames))
      end
  | Www.Document (base, target, page) ->
      match target, get_form controls page with (* szukamy odpowiedniego formularza *)
      | _, (_, None) -> (* nie znaleziono odpowiedniego formularza *)
	  raise Not_found
      | None, (None, Some (href, http_method)) -> (* otwieramy nowa strone (nie ma targeta) *)
	  raise (New_full_page (Www.get_full_page (Www.apply_base base href) http_method))
      | targ, (None, Some (href, http_method))
      | _, (targ, Some (href, http_method)) -> (* otwieramy w ramce *)
	  raise (Update_frame
	    (targ,
	     try Some (Www.get_full_page (Www.apply_base base href) http_method) with
	     | Www.Dead_link -> None))
;;


let goto url =
  try Stack.push (Www.get_full_page url (Www.Method_get [])) history with
  | Www.Dead_link -> Printf.fprintf Www.log_chann "Dead link: %s!\n" url
;;

let back () =
  if Stack.length history > 1 then
    ignore (Stack.pop history)
  else
    raise At_starting_page
;;

(* do uzytku w jezyku - klikniecie na a_tagu pasujacego do regexpu *)
let click rexp url_rxp =
  let regexp = regexp_of_option rexp
  and url_regexp = regexp_of_option url_rxp in
  try
    let new_www =
      try click_a_tag regexp url_regexp (Stack.top history) with
      | New_full_page p -> p in
    Stack.push new_www history
  with
  | Not_found
  | Update_frame _ ->
      Printf.fprintf Www.log_chann "Couldn't click!\n"
;;

let submit url_regexp params =
  try
    let new_www =
      try submit_form params (Stack.top history) with
      | New_full_page p -> p in
    Stack.push new_www history
  with
  | Not_found
  | Update_frame _ ->
      Printf.fprintf Www.log_chann "Couldn't submit!\n"
;;

let get_current_page () =
  let buf = Buffer.create 16 in
  let rec get_current_page_aux = function
    | Www.Frames fr ->
	let wwws = snd (List.split fr)
	and aux = function
	  | Some www -> get_current_page_aux www
	  | None -> () in
	List.iter aux wwws
    | Www.Document (_, _, page) -> Buffer.add_string buf page in
  get_current_page_aux (Stack.top history);
  Buffer.contents buf
;;

let log str = print_endline str; flush stdout;;

(*start "http://www.mimuw.edu.pl";;
print_www (Stack.top history);;
Printf.printf "\n\n\n************************\n\n\n";;
click (Str.regexp "Instytuty");;
print_www (Stack.top history);;
Printf.printf "\n\n\n************************\n\n\n";;
back ();;
print_www (Stack.top history);;
Printf.printf "\n\n\n************************\n\n\n";;
click (Str.regexp "Biblioteka");;
print_www (Stack.top history);;
Printf.printf "\n\n\n************************\n\n\n";;
submit ["ps_query", "Ciebiera"];;*)

let rec print_nethtml pad nodes =
  List.iter (print_nethtml_aux pad) nodes
and print_nethtml_aux pad = function
  | Nethtml.Element (name, args, subnodes) ->
      Printf.printf "%s---- element: %s ----\n" pad name;
      print_nethtml (pad ^ "    ") subnodes
  | Nethtml.Data _ ->
      Printf.printf "%s---- data ----\n" pad
;;
(*
goto "http://www.google.com";;
Www.print_www (Stack.top history);;
Printf.printf "\n\n\n************************\n\n\n";;
submit ["q", "Ciebiera"];;
Www.print_www (Stack.top history);;
*)
