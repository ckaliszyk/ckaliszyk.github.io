val start_program : Syntax.instr -> unit 
