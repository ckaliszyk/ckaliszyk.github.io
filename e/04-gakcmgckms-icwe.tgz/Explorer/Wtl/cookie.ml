let cookies =
  ref []
;;

let print_cookie c =
  Printf.printf "name: %s\n" c.Cgi.cookie_name;
  Printf.printf "value: %s\n" c.Cgi.cookie_value;
  Printf.printf "expires: %s\n"
    (match c.Cgi.cookie_expires with
    | Some x -> "Some " ^ (string_of_float x)
    | None -> "None");
  Printf.printf "domain: %s\n"
    (match c.Cgi.cookie_domain with
    | Some x -> "Some " ^ x
    | None -> "None");
  Printf.printf "path: %s\n"
    (match c.Cgi.cookie_path with
    | Some x -> "Some " ^ x
    | None -> "None");
  Printf.printf "secure: %b\n" c.Cgi.cookie_secure
;;

(* przerobione z Cgi *)
let split_name_is_value s =
  if String.lowercase s = "secure" then "secure", ""
  else
    let p = String.index s '=' in
    String.sub s 0 p, String.sub s (p+1) (String.length s - p - 1)
;;

(* przerobione z Cgi *)
let split_cookie cookie =
  let parts = Str.split (Str.regexp "[ \t\r\n]*;[ \t\r\n]*") cookie in
  List.map
    (fun part ->
      let n, v = split_name_is_value part in
      let n_dec = Netencoding.Url.decode n in
      let v_dec = Netencoding.Url.decode v in
      let n_final =
	match String.lowercase n_dec with
	| "expires"
	| "domain"
	| "path"
	| "secure" -> String.lowercase n_dec
	| _ -> n_dec in
      n_final, v_dec
    )
    parts
;;

let string_of_option = function
  | Some x -> x
  | None -> ""
;;

let add_cookie cookie =
  let signature c =
    c.Cgi.cookie_name ^ (string_of_option c.Cgi.cookie_domain) ^ (string_of_option c.Cgi.cookie_path) in
  cookies := cookie::(List.filter (fun c -> signature c <> signature cookie) !cookies);
  (*print_endline "Added cookie:"; print_cookie cookie*)
;;

let retrieve_cookies_aux default_domain raw =
  try
    let parts = split_cookie raw in
    let name, vlue =
      List.find (fun (n, _) -> n <> "expires" && n <> "domain" && n <> "path" && n <> "secure") parts in
    let expires =
      try Some (Netdate.parse_epoch (List.assoc "expires" parts)) with
      | Not_found -> None in
    let domain =
      try Some (List.assoc "domain" parts) with
      | Not_found -> Some default_domain in
    let path =
      try Some (List.assoc "path" parts) with
      | Not_found -> None in
    let secure = List.exists (fun (n, _) -> n = "secure") parts in
    if secure then ()
    else
      let cookie = {
	Cgi.cookie_name = name;
	Cgi.cookie_value = vlue;
	Cgi.cookie_expires = expires;
	Cgi.cookie_domain = domain;
	Cgi.cookie_path = path;
	Cgi.cookie_secure = secure
      } in
      add_cookie cookie
  with
  | Not_found -> ()
;;

let retrieve_cookies message =
  let sets = List.filter (fun (n, _) -> String.lowercase n = "set-cookie") (message#get_resp_header ())
  and default_domain = Neturl.url_host (Neturl.url_of_string Aux.http_syntax (message#get_uri ())) in
  List.iter (retrieve_cookies_aux default_domain) (snd (List.split sets))
;;

let remove_expired () =
  let time = Unix.time () in
  cookies := List.filter
      (fun cookie ->
	match cookie.Cgi.cookie_expires with

	| Some t -> t > time
	| None -> true) !cookies
;;

let enrich str_url message =
  remove_expired ();
  let url = Neturl.url_of_string Aux.http_syntax str_url in
  let host = Neturl.url_host url
  and path = List.fold_left (fun p x -> p ^ "/" ^ x) "" (Neturl.url_path url) in
  let relevant = List.filter
      (fun c ->
	let dom =
	  match c.Cgi.cookie_domain with
	  | Some x -> x
	  | None -> "" in
	let len = String.length dom in
	let pth = string_of_option c.Cgi.cookie_path in
	try
	  String.sub host ((String.length host) - len) len = dom &&
	  String.sub path 0 (String.length pth) = pth
	with
	| Invalid_argument _ -> false)
      !cookies in
  (*print_endline "Enriching with cookies:"; List.iter print_cookie relevant;*)
  let encoded = List.map
      (fun c ->
	Netencoding.Url.encode ~plus:false c.Cgi.cookie_name,
	Netencoding.Url.encode ~plus:false c.Cgi.cookie_value)
      relevant in
  let rec compose cookie = function
    | [] -> cookie
    | [n, v] -> cookie ^ n ^ "=" ^ v
    | (n, v)::t -> compose (cookie ^ n ^ "=" ^ v ^ "; ") t in
  message#set_req_header "Cookie" (compose "" encoded)
;;
