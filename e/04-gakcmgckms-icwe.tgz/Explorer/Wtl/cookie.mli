(* wyciaga cookiesy z message'a i skladuje je *)
val retrieve_cookies: Http_client.message -> unit

(* dopisuje odpowiednie cookiesy do message'a *)
val enrich: string -> Http_client.message -> unit
