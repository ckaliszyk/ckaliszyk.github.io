open Printf;;

let usage () = 
  printf "Usage: %s [wtl_compiled_file]\n" Sys.argv.(0);
  exit 1
;;
  
let main () =
  if Array.length Sys.argv < 2 then usage () else
  try 
    let src_channel = open_in Sys.argv.(1) in
    let program : Syntax.instr = input_value src_channel in
    Engine.start_program program
  with
  | Sys_error s -> printf "error: %s\n" s
  | Failure "input_value: bad object" -> 
      printf "error: %s in not a wtl binary file\n" Sys.argv.(1)
        
;;

main ()
