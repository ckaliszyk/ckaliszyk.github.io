val matches : string -> string -> bool
val extract : string -> string -> string