type control =
  | Text of string (* input::text lub input::password lub textarea *)
  | Hidden of string (* input::hidden *)
;;

let loose_input_type (name, control) =
  name,
  match control with
  | Text x -> x
  | Hidden x -> x
;;

let rec preprocess_form controls =
  List.fold_left preprocess_form_aux controls
and preprocess_form_aux controls = function
  | Nethtml.Element ("input", args, _) -> begin
      try
	let t = try List.assoc "type" args with Not_found -> "text"
	and name = List.assoc "name" args
	and init_value =
	  try List.assoc "value" args with
	  | Not_found -> "" in
	match t with
	| "text"
	| "password" -> (name, Text init_value)::controls
	| "hidden" -> (name, Hidden init_value)::controls
	| _ -> controls
      with
      | Not_found -> controls
  end
  | Nethtml.Element ("textarea", args, subnodes) ->
      let name = List.assoc "name" args
      and buf = Buffer.create 16 in
      Nethtml.write ~dtd: Nethtml.relaxed_html40_dtd
	(*(new Netchannels.output_buffer buf)*) (Buffer.add_string buf) subnodes;
      let init_value = Buffer.contents buf in
      (name, Text init_value)::controls
  | Nethtml.Element (_, _, subnodes) ->
      preprocess_form controls subnodes
  | Nethtml.Data _ -> controls
;;
