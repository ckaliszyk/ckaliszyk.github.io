(* 'pelna' strona www (cala struktura ramek) *)
type t =
  | Frames of (string option * t option) list
  | Document of string * string option * string
	(* (base, target, page) *)
;;

type http_method =
  | Method_get of (string * string) list
  | Method_post of (string * string) list
;;

exception Dead_link
;;

let log_chann = stdout
;;

let extract_param param args =
  try Some (List.assoc param args) with Not_found -> None
;;

(* zwraca parametry (href, target) wyciagniete z taga BASE (jako para string option) *)
let rec get_base = function
  | h::t -> begin
      match get_base_aux h with
      | None, None -> get_base t
      | x -> x
  end
  | [] -> None, None
and get_base_aux = function
  | Nethtml.Element ("base", args, _) ->
      extract_param "href" args, extract_param "target" args
  | Nethtml.Element (_, _, subnodes) ->
      get_base subnodes
  | Nethtml.Data _ -> None, None
;;

let rec apply_base base link =
  if String.length base > 0 && base.[String.length base - 1] <> '/'
      && String.length link > 0 && link.[0] <> '/' then
    apply_base (base ^ "/") link
  else
    let link_url = Neturl.url_of_string Aux.http_syntax link in
    let base_url = Neturl.url_of_string Aux.http_syntax base in
    Neturl.string_of_url (Neturl.apply_relative_url base_url link_url)
;;

(* pobiera strone o adresie url i zwraca ja sparsowana
   albo rzuca Dead_link jesli strony nie mozna pobrac *)
let get_page url http_method =
  let message =
    match http_method with
    | Method_get params ->
	let s = List.map (fun (n, v) -> n ^ "=" ^ Cgi.encode v) params in
	let full_url =
	  if params = [] then url
	  else
	    match String.contains url '?' with
	    | true -> url ^ "&" ^ (String.concat "&" s)
	    | false -> url ^ "?" ^ (String.concat "&" s) in
	new Http_client.get full_url
    | Method_post params -> new Http_client.post url params in
  Cookie.enrich url message;
  let pipeline = new Http_client.pipeline in
  pipeline#add message;
  pipeline#run ();
  if not message#is_served then raise Dead_link;
  let (_, code, _) = message#dest_status () in
  if code <> 200 then raise Dead_link;
  Cookie.retrieve_cookies message;
  let page = message#get_resp_body () in
  (
   try message#assoc_resp_header "Content-Location" with
   (*| Http_client.Http_protocol _ -> ""*)
   | Not_found -> ""
  ),
  page
  (*Nethtml.parse ~dtd: Nethtml.relaxed_html40_dtd
    (new Netchannels.input_string page)*)
;;

(* zwraca liste par string option (name, src),
   lista ta reprezentuje ramki na danej stronie *)
let rec get_frames frames = function
  | h::t -> get_frames (get_frames_aux frames h) t
  | [] -> frames
and get_frames_aux frames = function
  | Nethtml.Element ("frame", args, _) ->
      (extract_param "name" args, extract_param "src" args)::frames
  | Nethtml.Element (_, _, subnodes) ->
      get_frames frames subnodes
  | Nethtml.Data _ -> frames
;;

(* zwraca 'pelna' strone www (czyli strone, jej ramki, ramki tych ramek, itd.) *)
let rec get_full_page href http_method =
  let http_base, page = get_page href http_method in
  let parsed = (Nethtml.parse ~dtd: Nethtml.relaxed_html40_dtd (new Netchannels.input_string page)) in
  let frames = get_frames [] parsed in
  let html_base, target = get_base parsed in
  let base =
    (* wg specyfikacji html:
       jesli jest base w dokumencie html, to go uzywamy
       jesli nie, ale jest base w message'u http, to go uzywamy
       jesli nie, to za base przyjmujemy adres strony *)
    match html_base with
    | Some x -> x
    | None ->
	if http_base = "" then href
	else http_base in
  match frames with
  | [] -> Document (base, target, page)
  | _ ->
      let aux_get = function (* sciaganie ramek *)
	| None -> None
	| Some fr_href ->
	    let url = apply_base base fr_href in
	    try Some (get_full_page url (Method_get [])) with
	    | Dead_link ->
		Printf.fprintf log_chann "Error downloading %s!\n" url;
		None in
      Frames (List.map (fun (name, fr_href) -> name, aux_get fr_href) frames)
;;

let rec print_www = function
  | Frames fr -> List.iter print_frame fr
  | Document (_, _, page) -> print_string page
      (*Nethtml.write ~dtd: Nethtml.relaxed_html40_dtd
        (new Netchannels.output_channel stdout) page*)
and print_frame (name, body) =
  begin
    match name with
    | None -> Printf.printf "\n\n******** Frame: <No name> ********\n\n"
    | Some x -> Printf.printf "\n\n******** Frame: %s ********\n\n" x
  end;
  begin
    match body with
    | None -> Printf.printf "******** <No body> ********\n"
    | Some x -> print_www x
  end;
  Printf.printf "\n"
;;
