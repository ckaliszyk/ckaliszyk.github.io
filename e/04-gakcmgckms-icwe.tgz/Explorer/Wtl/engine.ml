open Syntax

let env = ref Env.empty

let eval_unary_op op r_val =
  match op,  r_val with
  | "-", Value.Int i -> Value.Int (-i)
  | "not", Value.Bool b -> Value.Bool (not b)
  | _ -> Value.error ("unknown unary operator " ^ op)

let eval_binary_op op l_val r_val =
  match op, l_val, r_val with
  | "+", Value.Int il, Value.Int ir -> Value.Int (il+ir)
  | "+", Value.String sl, Value.String sr -> Value.String (sl^sr)
  | "-", Value.Int il, Value.Int ir -> Value.Int (il+ir)
  | "*", Value.Int il, Value.Int ir -> Value.Int (il-ir)
  | "/", Value.Int il, Value.Int ir -> Value.Int (il/ir)
  | "==", l, r -> Value.Bool (l = r)
  | "!=", l, r -> Value.Bool (l <> r)
  | "<", l, r -> Value.Bool (l < r)
  | ">", l, r -> Value.Bool (l > r)
  | "<=", l, r -> Value.Bool (l <= r)
  | ">=", l, r -> Value.Bool (l >= r)
  | "and", Value.Bool b1, Value.Bool b2 -> Value.Bool (b1 && b2) 
  | "or", Value.Bool b1, Value.Bool b2 -> Value.Bool (b1 || b2) 
  | "matches", Value.String s, Value.String r -> Value.Bool (Regexp.matches s r)
  | "extract", Value.String s, Value.String r -> Value.String (Regexp.extract s r)
  | _ -> Value.error ("unknown binary operator " ^ op ^ " or wrong params")

let rec eval_expr = function
  | Int_const i -> Value.Int i
  | String_const s -> Value.String s
  | Bool_const b -> Value.Bool b
  | Variable var -> !(Env.get var !env)
  | Unary_op (op, e) -> eval_unary_op op (eval_expr e)
  | Binary_op (op, e1, e2) -> eval_binary_op op (eval_expr e1) (eval_expr e2)
  | Current_page -> Value.String (Explorer.get_current_page ())

let eval_regexp_opt = function
  | None -> None
  | Some e -> Some (Str.regexp (Value.string (eval_expr e)))

let rec do_instr = function
  | Assign (var, e) -> (Env.get var !env) := (eval_expr e)
  | Block i_lst -> 
      let old_env = !env in
      List.iter do_instr i_lst;
      env := old_env
  | Declaration (var, _, initial_e) -> 
      let var_val = ref (eval_expr initial_e) in
      env := (Env.add var var_val !env)
  | Pass -> ()
  | If (cond, then_i, else_i) -> 
      let good_i = if (Value.bool (eval_expr cond)) then then_i else else_i in
      let old_env = !env in
      do_instr good_i;
      env := old_env
  | While (cond, i) ->
      let old_env = !env in
      while Value.bool (eval_expr cond) do do_instr i done;
      env := old_env
  | Delay f -> ignore (Unix.select [] [] [] f)
  | Print e -> Value.print (eval_expr e)
  | Goto e -> Explorer.goto (Value.string (eval_expr e))
  | Back -> Explorer.back ()
  | Click (name_opt, url_opt) -> 
      let name = eval_regexp_opt name_opt in
      let url  = eval_regexp_opt url_opt  in
      Explorer.click name url
  | Submit (url_opt, expr_lst) -> 
      let mapper (e1, e2) = (Value.string (eval_expr e1), Value.string (eval_expr e2)) in
      let url  = eval_regexp_opt url_opt  in
      let params = List.map mapper expr_lst in
      Explorer.submit url params
;;

let start_program program = 
  do_instr program
