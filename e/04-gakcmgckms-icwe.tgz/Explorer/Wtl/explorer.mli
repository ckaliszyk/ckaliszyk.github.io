exception At_starting_page

val get_current_page: unit -> string

val goto: string -> unit

val click: Str.regexp option -> Str.regexp option -> unit

(* rzuca At_starting_page jesli probujemy zrobic back na startowej stronie *)
val back: unit -> unit

val submit: Str.regexp option -> (string * string) list -> unit
