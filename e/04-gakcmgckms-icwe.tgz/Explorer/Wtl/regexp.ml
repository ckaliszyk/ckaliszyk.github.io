(*exception  Err of string;;
module Value = struct 
  let error s = raise (Err s) 
end
;;
*)
let matches str regexp_str = 
  try 
    let regexp = Str.regexp regexp_str in
    ignore (Str.search_forward regexp str 0);
    true
  with
  | Failure s -> Value.error ("illegal regexp: " ^ s)
  | Not_found -> false
;;

let extract str regexp_str = 
  try 
    if matches str regexp_str then 
      Str.matched_group 1 str
    else
      Value.error ("couldn't extract regexp: " ^ regexp_str)
  with
  | Not_found -> 
      Value.error (
      "illegal regexp for `extract`, use \"\\(\" and \"\\)\"" ^  
      " to delimit extraction group" ) 
;;
