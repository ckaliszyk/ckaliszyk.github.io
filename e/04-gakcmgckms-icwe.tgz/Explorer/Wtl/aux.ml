let http_syntax =
  let required_syntax = Hashtbl.find Neturl.common_url_syntax "http" in
  Neturl.partial_url_syntax required_syntax
;;
