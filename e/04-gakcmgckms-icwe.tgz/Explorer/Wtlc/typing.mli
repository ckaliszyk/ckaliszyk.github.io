type result = Ok of Syntax.instr | Error of string

val type_program : Syntax.instr -> result

