open Syntax;;

type result = Ok of Syntax.instr | Error of string

exception Typing_error of string

let string_of_type = function
  | Int_type    -> "int"
  | String_type -> "string"
  | Bool_type   -> "bool"


let check_types s t1 t2 = 
  if t1 <> t2 then 
    let s1 = string_of_type t1 
    and s2 = string_of_type t2 in
    raise (Typing_error (s ^ " has type " ^ s1 ^ " and should have type " ^ s2))
  else ()


let env = ref Env.empty



let type_unary_op op param_type = 
  let get_unary_op_typing = function
    | "-" -> (Int_type, Int_type)
    | "not" -> (Bool_type, Bool_type)
    | _ -> assert false
  in
  let (result_type, want_type) = get_unary_op_typing op in
  check_types ("unary operator " ^ op) param_type want_type;
  result_type

  
let type_binary_op op left_type right_type =
  let wrong_binary_op_types op t1 t2 = 
    let s1 = string_of_type t1 
    and s2 = string_of_type t2 in
    let error_msg = 
      "operator " ^ op ^ ": type of left argument is "  ^ s1 ^ " and type of right argument is " ^ s2 
    in
    raise (Typing_error error_msg)
  in
  match op with 
  | "+" ->
    if left_type <> right_type || (left_type <> Int_type && left_type <> String_type) then
      wrong_binary_op_types op left_type right_type
    else
      left_type
  | "-" | "*" | "/" ->
    if left_type <> Int_type || right_type <> Int_type then
      wrong_binary_op_types op left_type right_type
    else
      Int_type
  | "==" | "!=" | "<" | "<=" | ">" | ">=" ->
    if left_type <> right_type then
      wrong_binary_op_types op left_type right_type
    else
      Bool_type
  | "and" | "or" ->
    if left_type <> Bool_type || right_type <> Bool_type then
      wrong_binary_op_types op left_type right_type
    else
      Bool_type
  | "matches" ->
    if left_type <> String_type || right_type <> String_type then
      wrong_binary_op_types op left_type right_type
    else
      Bool_type
  | "extract" ->
    if left_type <> String_type || right_type <> String_type then
      wrong_binary_op_types op left_type right_type
    else
      String_type
  | _ -> assert false
  

let rec type_expr = function
  | Int_const i -> Int_type
  | String_const s -> String_type
  | Bool_const b -> Bool_type
  | Variable var -> Env.get var !env
  | Unary_op (op, e) -> type_unary_op op (type_expr e)
  | Binary_op (op, e1, e2) -> type_binary_op op (type_expr e1) (type_expr e2)
  | Current_page -> String_type

let type_int_expr s e = 
  check_types s (type_expr e) Int_type

let type_string_expr s e = 
  check_types s (type_expr e) String_type

let type_bool_expr s e = 
  check_types s (type_expr e) Bool_type

let type_string_expr_opt s = function
  | None -> ()
  | Some e -> type_string_expr s e


let rec type_instr = function
  | Assign (var, e) -> 
      check_types ("right side of assinment to " ^ var) (type_expr e) (Env.get var !env)
  | Block i_lst ->
      let old_env = !env in
      List.iter type_instr i_lst;
      env := old_env
  | Declaration (var, var_type, initial_e) ->
      check_types ("right side of declaration of " ^ var) (type_expr initial_e) var_type;
      env := (Env.add var var_type !env)
  | Pass -> ()
  | If (cond, then_i, else_i) ->
      let old_env = !env in
      type_bool_expr "if condition" cond;
      type_instr then_i;
      type_instr else_i;
      env := old_env
  | While (cond, i) ->
      let old_env = !env in
      type_bool_expr "while condition" cond;
      type_instr i;
      env := old_env
  | Delay f -> ()
  | Print e -> ignore (type_expr e)
  | Goto e -> type_string_expr "goto param" e
  | Back -> ()
  | Click (name_opt, url_opt) -> 
      type_string_expr_opt "click name param" name_opt;
      type_string_expr_opt "click url param" url_opt
  | Submit (url_opt, param_lst) ->
      let type_param (e1, e2) = 
        type_string_expr "left param of submit params" e1; 
        type_string_expr "left param of submit params" e2
      in
      type_string_expr_opt "click url param" url_opt;
      List.iter  type_param param_lst


let type_program program = 
  try type_instr program; Ok program with
  | Typing_error s -> Error (s)
  | Value.Execution_error s -> Error ("no_variable " ^ s)
  