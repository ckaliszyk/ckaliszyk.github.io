open Printf;;

let usage () = 
  printf "Usage: %s [wtl_source_file]\n" Sys.argv.(0);
  exit 1
;;

let make_outfile_name in_name = 
  let name = 
    try Filename.chop_extension in_name with
    | Invalid_argument _ -> in_name
  in
  name ^ ".wtb"
;;

let main () =
  if Array.length Sys.argv < 2 then usage () else
  try 
    let src_channel = open_in Sys.argv.(1) in
    let src_stream = Stream.of_channel src_channel in
    try 
      let src_parsed = Syntax.parse src_stream in
      
      match Typing.type_program src_parsed with
      | Typing.Ok src_typed -> 
          let out_name = make_outfile_name Sys.argv.(1) in
          let out_ch = open_out_bin out_name in
          output_value out_ch src_typed;
          close_out out_ch
      | Typing.Error s ->
          printf "typing error: %s\n" s;
    with
    | Stream.Error s -> 
        printf "syntax error\n" (*(pos_in src_channel)*)
  with
  | Sys_error s -> 
      printf "error: %s\n" s
        
;;

main ()
