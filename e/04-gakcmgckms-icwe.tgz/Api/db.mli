(** Database Api operations

   Operations required to access the database stored at the Overseer*)

(** Type representing a database table with the given association types stored
   at the Overseer.
*)
type ('a, 'b) t;;

(** [init table_name cb] returns [t] associated with the given 
   [table_name] in Overseer. Prior to using this function main function of
   executable should read command line arguments using Config.init.
   It looks for the table in the Overseer and return the unique identifier of
   the table. 
   If [cb] is not None, it is called every time underlying Overseer table has
   chnaged. Please note that it is caller's responsibility to re-get all values
   from the Overseer to update its local cache.
   Warning: [cb] is called asynchronously, probably from another thread, so care
   should be taken to avoid any concurrency issues that may arise.
   
   Throws Unix.Unix_error

   Usage:
   [let my_db : (int, string) Db.t = Db.init "my_table" None]
   or
   [let my_db : (int, string) Db.t = Db.init "my_table" Some(my_callback)]
*)
val init : string -> (string -> unit) option -> ('a, 'b) t;;

(** [get table id] returns the value associated with [id] stored int table 
   [table] at the Overseer. *)
val get : ('a, 'b) t -> 'a -> 'b option;;

(** [set table id new_val] sets [id] in [table] to [new_val]. *)
val set : ('a, 'b) t -> 'a -> 'b -> unit;;

(** [remove table id] removes value associated with [id]. *)
val remove : ('a, 'b) t -> 'a -> unit;;

(** Name of the table in Overseer which stores configuration. *)
val config_table_name : string;;
