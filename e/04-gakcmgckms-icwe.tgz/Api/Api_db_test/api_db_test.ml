let foo _ = Some("foo")

let bar = (fun _ -> Some("bar"));;

let none _ =
  None

let print = function
  | None -> print_endline "None"
  | Some(str) -> print_endline ("Some(" ^ str ^ ")");;

let tbl_handle : (int, string) Db.t = Db.init "asdf" false;;

Db.set tbl_handle 4 "foo";; (* we put "foo" at 4 *)
Db.set tbl_handle 7 "bar";;
print (Db.get tbl_handle 4);; (* we print the string stored at 4 *)
print (Db.get tbl_handle 7);;
print (Db.get tbl_handle 9);;
Db.set tbl_handle 4 "bar";;
Db.set tbl_handle 7 "";;
print (Db.get tbl_handle 4);;
print (Db.get tbl_handle 7);;
flush stdout;;
(* Czy jest twardy? *)
for i = 1 to 1200 do
  Db.set tbl_handle i "asd";
  print_int i;
  flush stdout
done;
for i = 1 to 1200 do
  assert (Db.get tbl_handle i = Some "asd");
  print_int i;
  flush stdout
done;
(* Jest! *)
