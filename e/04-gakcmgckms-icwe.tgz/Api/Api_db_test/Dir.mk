DIR:=Api/Api_db_test
TARGET:=api_db_test
FILES:=
FILES_NOMLI:=api_db_test
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
FILES_NOMLI:=$(addprefix out/${DIR}/,${FILES_NOMLI})
-include $(addsuffix .dm,${FILES_NOMLI})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Api/api.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .$(OBJ_SUF),${FILES_NOMLI}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -o $@ unix.$(LIB_SUF) $^
