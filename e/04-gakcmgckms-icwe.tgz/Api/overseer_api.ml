type ('a, 'b) db_t =
  | Query_init of string
  | Resp_table_id of int
  | Resp_table_change of int
  | Query_get of int * 'a
  | Resp_get of 'b option
  | Query_set of int * 'a * 'b option
  | Resp_set
;;

let push_cookie = Int64.one;;
