(**
 * Interface of a buffered socket with convenient access. Necessary
 * to support libEvent.
 *
 * @author Marcin Gozdalik
 *)

(** Possible errors on the connection. *)
type error =
  | NO_ERROR                            (** No error. *)
  | NO_VALUE                            (** No value received. *)
  | WRITE_BLOCKED                       (** Write has received EAGAIN. *)
  | CLOSED_OK                           (** Connection was gracefully closed. *)
  | CLOSED_ERROR of Unix.error          (** Connection was terminated because of an error. *)

(** Exception raised by read & write. *)
exception Exc of error

(** Abstract type representing buffered socket. *)
type t

(** Creates a buffered socket from given Unix descriptor. *)
val create: Unix.file_descr -> t

(** [read_exactly bufsock len] returns exactly [len] bytes from underlying socket. If
  * [len] bytes could not be read - returns empty string. *)
val read_exactly: t -> int -> string

(** [write_exactly bufsock buf len] writes exactly [len] bytes from [buf] to
* [bufsock]. If the socket is congested it raises Exc(WRITE_BLOCKED) and the
* caller is responsible to call [flush bufsock] whenever the socket becomes
* ready to be written to.
*)
val write_exactly: t -> string -> int -> unit

(** [output_value bufsock obj] marshals [obj] and outputs its represenation to
* buffer in [bufsock]. To actually output data use [flush].
*)
val output_value: t -> 'a -> unit

(** [input_value bufsock] returns an object unmarshalled from socket [bufsock].
* If there is no object currently to be read - throws Bufsock_exc(NO_VALUE).
*)
val input_value: t -> 'a

(** [flush bufsock] flushes any pending data from the output buffer of
* [bufsock]. Can raise Exc(WRITE_BLOCKED) (see [write_exactly]). *)
val flush: t -> unit

(** [file_descr bufsock] returns underlying Unix descriptor. *)
val file_descr: t -> Unix.file_descr

(** [close bufsock] closes underlying Unix descriptor. *)
val close: t -> unit
