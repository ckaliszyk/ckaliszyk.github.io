DIR:=Api
TARGET:=api.$(LIB_SUF)
FILES:=log monitor commandLine bufferedSocket asyncSocket url db
FILES_NOMLI:=overseer_api unixTCP
CFILES:=tcpsockopt

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
FILES_NOMLI:=$(addprefix out/${DIR}/,${FILES_NOMLI})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
-include $(addsuffix .dm,${FILES_NOMLI})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES_NOMLI}) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -linkall -a -o $@ $^
