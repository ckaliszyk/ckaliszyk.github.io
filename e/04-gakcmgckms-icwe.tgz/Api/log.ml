type 'a t = Log of out_channel * Mutex.t;;

let tab_log = 
  Hashtbl.create 3;; (* hashtable of log files *)

let create_log filename : 'a t = 
  try
    Obj.magic (Hashtbl.find tab_log filename)
  with Not_found ->
  begin
    let log_file = open_out_gen 
      [Open_wronly;Open_append;Open_creat;Open_binary] 
      (256+128) filename
    in 
    let mut = Mutex.create () in
    Hashtbl.add tab_log filename (Log (log_file, mut));
    Obj.magic (Log (log_file, mut))
  end
;;

let log (Log (out, mut)) log_data =
  Mutex.lock mut;
  output_value out log_data;
  flush out;
  Mutex.unlock mut
;;

let echo_mutex = Mutex.create ();;

(*
let echo str =
  Mutex.lock echo_mutex;
  print_int (Thread.id (Thread.self ()));
  print_string ": ";
  print_string (string_of_float (Unix.gettimeofday ()));
  print_string ": ";
  print_endline str;
  flush Pervasives.stdout;
  Mutex.unlock echo_mutex
;;
*)
let echo _ = () ;;

(** Debug disabled *)
let debug str =
  ();;

(* Since we currently view the logs directly there is no need for other
   communication type *)
let error = echo;;
