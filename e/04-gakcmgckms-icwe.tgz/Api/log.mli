(** Logging Api operations *)

(** Type representing log associated with a file. It can store values of
   the certain type given at the creation of the log.
*)
type 'a t;;

(** [create_log filename] returns [file_log] associated with the given 
   [filename]. It looks for the filename in the hashtable of log files 
   creates and adds a new file_log if not found.
   
   Should be used like this:

   [let my_log : int * int Api_log.file_log = Api_log.create_log "my file"]
*)
val create_log : string -> 'a t;;

(** [log file_log log_data] appends the given [log_data] which has to be
   of the correct type to the [file_log] *)
val log : 'a t -> 'a -> unit;;

(** Simple print_endline, but thread_safe - use only for debugging
   The final application will close it's stdout, so only Log.error
   will be available *)
val echo : string -> unit;;

val debug : string -> unit;;

(** Logs a really important error to the administrator somehow *)
val error : string -> unit;;
