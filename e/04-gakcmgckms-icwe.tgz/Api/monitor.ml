type t = {
  mutex : Mutex.t;
  can_read : Condition.t;
  can_write : Condition.t;
  mutable awaiting_read : int;
  mutable readers : int;
  mutable awaiting_write : int;
  mutable writing : bool;
};;

let create () = {
  mutex = Mutex.create ();
  can_read = Condition.create ();
  awaiting_read = 0;
  readers =  0;
  can_write = Condition.create ();
  awaiting_write = 0;
  writing = false;
};;

let begin_reading m =
  Mutex.lock m.mutex;
  m.awaiting_read <- m.awaiting_read + 1;
  while m.writing || m.awaiting_write > 0 do
	  Condition.wait m.can_read m.mutex
  done;
  m.awaiting_read <- m.awaiting_read - 1;
  m.readers <- m.readers + 1;
  Condition.signal m.can_read;
  Mutex.unlock m.mutex
;;

let end_reading m =
  Mutex.lock m.mutex;
  m.readers <- m.readers - 1;
  if m.readers = 0 then
    Condition.signal m.can_write;
  Mutex.unlock m.mutex
;;

let begin_writing m = 
  Mutex.lock m.mutex;  
  m.awaiting_write <- m.awaiting_write + 1;
  while m.readers <> 0 || m.writing do
  	Condition.wait m.can_write m.mutex
  done;
  m.awaiting_write <- m.awaiting_write - 1;
  m.writing <- true;
  Mutex.unlock m.mutex
;;
  
let end_writing m =
  Mutex.lock m.mutex;  
  m.writing <- false;
  if m.awaiting_read > 0 then
	  Condition.signal m.can_read 
  else
	  Condition.signal m.can_write;
  Mutex.unlock m.mutex
;;
