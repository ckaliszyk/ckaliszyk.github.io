type config = {
  mutable overseer_init: string;        (** Initialization for Overseer (Host and port). **)
  mutable plain_file_init: string;      (** Initialization for plain file (file name). **)
};;

let default_config = {
  overseer_init = "localhost:8000";
  plain_file_init = "sie.config";
};;

let current_conf = ref default_config
;;

let set_config cf value =
  cf.plain_file_init <- value
;;

let set_overseer cf value =
  cf.overseer_init <- value
;;

let get_overseer () =
  !current_conf.overseer_init
;;

let get_plainfile () =
  !current_conf.plain_file_init
;;

let read_args prog_name =
  let speclist =
    [("-overseer", Arg.String (set_overseer !current_conf), "Overseer address");
     ("-config", Arg.String (set_config !current_conf), "Config file name");
    ] in
  let usage_msg = "Usage: " ^ prog_name ^ " -overseer [host:port] -config [filename]" in
  Arg.parse speclist (fun s -> ()) usage_msg;
;;

