(**
 * Interface of a asynchronous socket with convenient access.
 * Built on top of BufferedSocker.
 *
 * @author Marcin Gozdalik
 *)

(** Possible errors on the connection. *)
type error =
  | CLOSED_OK                           (** Connection was gracefully closed. *)
  | CLOSED_ERROR of Unix.error          (** Connection was terminated because of an error. *)

(** Exception raised by read & write. *)
exception Exc of error

(** Abstract type representing asynchronous socket. *)
type t

(** [bind addr port accept_cb reader_cb] binds to address [addr] and port [port]. 
* When a new connection is accepted [accept_cb] is invoked with the address of
* remote end allowing caller to decide which connections are accepted and
* rejected (returning respectively true and false from [accept_fd]). *)
val bind: string -> int -> (Unix.sockaddr -> bool) -> (t -> unit) -> unit

(** [connect hostname port reader_cb] returns a socket connected to any of
* the addresses associated in DNS with [hostname] on port [port]. Connection is
* carried out asynchronously, so this function returns immediately. Any reader
* event on the socket is reported using [reader_cb] which is called with
* parameter indicating created socket. Returns created socket. *)
val connect: string -> int -> (t -> unit) -> t

(** [output_value sock obj] marshals [obj] and outputs its represenation to
* [sock].
*)
val output_value: t -> 'a -> unit

(** [input_value sock] returns an object unmarshalled from [bufsock].
* If there is no object currently to be read - returns None.
*)
val input_value: t -> 'a option

(** [close sock] closes asynchronous socket. *)
val close: t -> unit

(** [dispatch] enters endless loop processing events on all asynchronous sockets
* and calling appropriate callbacks. *)
val dispatch: unit -> unit

val flush: t -> unit
