(**
 * Interface for command line parser.
 *
 * @author Marcin Gozdalik
 *)

(** [get_overseer ()] returns configured Overseer address in the format of
* "host:port". *)
val get_overseer: unit -> string;;

(** [get_plainfile ()] returns configured config file name. *)
val get_plainfile: unit -> string;;

(** [read_args progname] reads command line arguments for program named
* [progname]. *)
val read_args: string -> unit;;
