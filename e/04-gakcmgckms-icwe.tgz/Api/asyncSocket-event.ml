type error =
  | CLOSED_OK
  | CLOSED_ERROR of Unix.error;;

exception Exc of error;;

type t = {
  bufsock: BufferedSocket.t;                 (** Underlying buffered socket. *)
  mutable revent: Event.event option;        (** Read event. *)
  mutable wevent: Event.event option;        (** Write event. *)
};;

let rec writer (sock, event) fd event_type =
  Log.echo "Writer event";
  try 
    BufferedSocket.flush sock.bufsock;
    (* if reached that far it means that there is no outstanding output
    * buffer - the writer event can be deleted *)
    Event.del event;
    sock.wevent <- None
  with 
  (* As a special case do nothing on WRITE_BLOCKED - the event to invoke
  * writer is already registered *)
  | BufferedSocket.Exc(BufferedSocket.WRITE_BLOCKED) -> ()
  | BufferedSocket.Exc(error) -> handle_bufsock_error sock error

and handle_bufsock_error sock error =
  match error with
  | BufferedSocket.CLOSED_OK -> raise (Exc(CLOSED_OK))
  | BufferedSocket.CLOSED_ERROR(unix_error) -> raise (Exc(CLOSED_ERROR(unix_error)))
  | BufferedSocket.WRITE_BLOCKED -> (
    Log.echo "WRITE_BLOCKED";
    (* Whenever the socket becomes ready to be written to - invoke writer *)
    let write_event = Event.create () in
    Event.set write_event (BufferedSocket.file_descr sock.bufsock) 
                 [Event.WRITE] true (writer (sock, write_event));
    Event.add write_event None;
    sock.wevent <- Some(write_event)
  )
  | BufferedSocket.NO_VALUE | BufferedSocket.NO_ERROR -> ()
;;

let reader event sock reader_cb fd event_type =
  let _ = match event_type with
  | Event.TIMEOUT -> Log.echo "TIMEOUT"
  | Event.READ -> Log.echo "READ"
  | Event.WRITE -> Log.echo "WRITE"
  | Event.SIGNAL -> Log.echo "SIGNAL"
  in Log.echo "Reader event";
  Event.add event None;
  try 
    reader_cb sock
  with 
    | BufferedSocket.Exc(error) -> handle_bufsock_error sock error
;;

let bind addr port accept_cb reader_cb =
  let addr = Unix.ADDR_INET((Unix.inet_addr_of_string addr), port) in
  let sock = Unix.socket Unix.PF_INET Unix.SOCK_STREAM 0 in
  Unix.setsockopt sock Unix.SO_REUSEADDR true;
  Unix.bind sock addr;
  Unix.listen sock 100;
  Unix.set_nonblock sock;

  let acceptor event accept_cb reader_cb fd event_type =
    try 
      let (desc, addr) = Unix.accept fd in 
      (* If the caller does not want this connection - close it *)
      if (not (accept_cb addr)) then Unix.close fd;
      Unix.set_nonblock desc;
      let _ = match addr with
        | Unix.ADDR_INET(addr, port) -> 
          Log.echo ("Accepted connection from " ^ (Unix.string_of_inet_addr addr) ^ ":" ^ (string_of_int port));
        | _ -> ();
      in 
      let bufsocket = BufferedSocket.init desc in
      let read_event = Event.create () in
      let sock = {
        bufsock = bufsocket;
        revent = None;
        wevent = None;
      } in
      let _ = Event.set read_event desc [Event.READ] false (reader read_event sock reader_cb) in
      let _ = Event.add read_event None in
      sock.revent <- Some(read_event);
      Log.echo ("Added READ event of Id " ^ (string_of_int (Event.event_id read_event)));
      Event.add event None
    with 
      | Unix.Unix_error(error, _, _) -> (
        Log.echo ("Error while accepting: " ^ (Unix.error_message error));
        Unix.close fd;
      )
  in
  
  let event = Event.create () in
  Event.set event sock [Event.READ] false (acceptor event accept_cb reader_cb);
  Event.add event None;
  Log.echo ("Added READ (accept) event of Id " ^ (string_of_int (Event.event_id event)));
  ()
;;

let input_value sock =
  try
    Some(BufferedSocket.input_value sock.bufsock)
  with
  | BufferedSocket.Exc(error) -> 
      handle_bufsock_error sock error;
      None
;;

let output_value sock obj =
  try
    BufferedSocket.output_value sock.bufsock obj
  with
  | BufferedSocket.Exc(error) ->
      handle_bufsock_error sock error
;;

let close sock =
  Log.echo "AsyncSocket.close";
  (* drop references to events so that GC can do it's job *)
  let _ = match sock.revent with
  | Some(event) -> Event.del event
  | None -> ()
  in sock.revent <- None;
  let _ = match sock.wevent with
  | Some(event) -> Event.del event
  | None -> ()
  in sock.wevent <- None;
  BufferedSocket.close sock.bufsock
;;

let dispatch () = 
  Event.dispatch()
