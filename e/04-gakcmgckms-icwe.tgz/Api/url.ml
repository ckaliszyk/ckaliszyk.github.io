(** Decoding urls
  @author Grzegorz Andruszkiewicz
*)
(* #load "/usr/lib/ocaml/3.07/str.cma";; *)

exception Error;;

let char_as_hex2int = function
  | '0' -> 0  
  | '1' -> 1
  | '2' -> 2
  | '3' -> 3
  | '4' -> 4
  | '5' -> 5 
  | '6' -> 6 
  | '7' -> 7 
  | '8' -> 8 
  | '9' -> 9 
  | 'a' -> 10 
  | 'A' -> 10 
  | 'b' -> 11 
  | 'B' -> 11 
  | 'c' -> 12
  | 'C' -> 12 
  | 'd' -> 13
  | 'D' -> 13
  | 'e' -> 14
  | 'E' -> 14
  | 'f' -> 15
  | 'F' -> 15
  | _ -> failwith "bad hex digit"
;;

let set_plus_to_space str =
  try
    while true do
      let i = String.index str '+' in
      str.[i] <- ' '
    done
  with Not_found -> ()
;;

let rec decode_percent str = 
  try
    let i = String.index str '%' in
    if String.length str <= i+2 then failwith "decode_percent"
    else
      let k = Char.chr ((char_as_hex2int(str.[i+1]))*16
    	    +char_as_hex2int(str.[i+2])) in
        (String.sub str 0 i) ^ (String.make 1 k) 
	^ (decode_percent (String.sub str (i+3) ((String.length str)-i-3)))
  with Not_found -> str
;;


(* Charakters that will be escaped *)
let reserved_chars = Hashtbl.create 20;;
Hashtbl.replace reserved_chars '/' "%2F";;
Hashtbl.replace reserved_chars '#' "%23";;
Hashtbl.replace reserved_chars ':' "%3A";;
Hashtbl.replace reserved_chars ';' "%3B";;
Hashtbl.replace reserved_chars '?' "%3F";;
Hashtbl.replace reserved_chars '&' "%26";;
Hashtbl.replace reserved_chars '=' "%3D";;
Hashtbl.replace reserved_chars '@' "%40";;


(* encode_percent escapes all reserved charakters (listed above) *)

let encode_percent str =
  let str_buf = Buffer.create ((String.length str) + 10) in
  let escape c = if Hashtbl.mem reserved_chars c then 
                    Buffer.add_string str_buf (Hashtbl.find reserved_chars c)
                 else Buffer.add_char str_buf c in
  let _ = String.iter escape str in
  Buffer.contents str_buf
;;

(*Finds the name of the host in an url with the protocol cut out *)
let get_url_name str =
  try
    let j = try String.index str '/'
            with Not_found -> String.length str in(*the first occurence of '/'*)
    let i = String.index str ':' in
    if i = 0 then ("", str)
    else if (i<j) then (String.sub str 0 i, String.sub str i ((String.length str) - i))
    else raise Not_found  (*If first ':' is after first '/', its not port number! *)
  with Not_found -> try
    let i = String.index str '/' in
    if i=0 then ("", str) else
    (String.sub str 0 i, String.sub str i ((String.length str) - i))
  with Not_found -> (str, "")
;;

let get_url_port str =
  let len = String.length str in
  if len = 0 then (80, "") else
  if str.[0] <> ':' then (80, str) else
  try
    let i = try String.index str '/' 
            with Not_found -> len
    in
    let rest = String.sub str i (len - i) in
    let port = 
      if i = 1 then 
        80
      else
        int_of_string (String.sub str 1 (i-1))
    in
    if (port < 1 or port > 65535) then
      raise Error
    else
      (port, rest)
  with
  | Not_found -> (80, str)
  | Failure _ -> raise Error
;;

let get_url_file str =
  if String.length str = 0 then ("", "")
  else try
    let i = String.index str '?' in
      (String.sub str 0 i, String.sub str (i+1) ((String.length str) -i -1))
  with Not_found -> (str, "")
;;

let rec get_params_from_str c str =
  if String.length str = 0 then []
  else
    try
      let i = String.index str '=' in
      let pocz = String.sub str 0 i in
      let kon = String.sub str (i+1) ((String.length str) -i-1) in
      try
        let j = String.index kon(*pocz*) c in
        (pocz, (String.sub kon 0 j)) ::
            (get_params_from_str c (String.sub kon (j + 1) ((String.length kon) -j-1)))
      with
        Not_found -> [(pocz, kon)]
    with Not_found -> failwith "get_params_from_string"
;;

let get_file_params str =
  let i = try String.index str '#'
          with Not_found -> String.length str in
  let params = String.sub str 0 i in
  let label = if i<(String.length str) then String.sub str i ((String.length str) -i-1) 
                else ""
  in
  let ret = get_params_from_str '&' params in
(*  List.iter 
    (fun (param, value) -> Log.echo ("{" ^ param ^ "|" ^ value ^ "}"))
    ret;
*)
  (ret, label)
;;



let parse_URL my_url =
  (*let _ = Log.echo ("my_url = " ^ my_url) in*)
  let without_params = try 
    let i = String.index my_url '?' 
      in String.sub my_url 0 i
    with Not_found -> my_url in
  let regexp = Str.regexp_string "://" in 
  let (protocol, my_url) = try let i = (Str.search_forward regexp without_params 0)
                   in (String.sub my_url 0 i, 
                       String.sub my_url (i+3) ((String.length my_url) -i -3))
              with Not_found -> ("http", my_url) 
  in (* the string "http://" in the beginning has been truncated *)
  let _ = set_plus_to_space my_url in
  (*let _ = Log.echo ("My_url2 = " ^ my_url) in*)
  let (url, rest) = get_url_name my_url in (*gets host name and port number *)  
  (*let _ = Log.echo ("rest3 = " ^ rest) in
  let _ = Log.echo ("url4 = " ^ url) in*)
  let (port, rest) = get_url_port rest in
  (*let _ = Log.echo ("rest5 = " ^ rest) in*)
  let (file, rest) = get_url_file rest in
  (*let _ = Log.echo ("rest6 = " ^ rest) in*)
  let (file_params, label) = get_file_params rest in
  let decoded_file = decode_percent file in
  let decoder (a, b) = (decode_percent a, decode_percent b) in
  let decoded_file_params = List.map decoder file_params in
  let decoded_file = if decoded_file="" then "/" else decoded_file in
  (protocol,decode_percent url, port, decoded_file, decoded_file_params,
  decode_percent label)
;;

let deparse_URL (protocol, host, port, file, params, label) =
  let url = protocol ^ "://" ^ host in
  let url = if port<>80 then url ^ ":" ^ (string_of_int port)
            else url in
  let file = if file="" then "/" else file in
  let url = url ^ file in
  let url = match params with
  | [] -> url
  | lst ->
      let rewrite (param, pval) = 
           (encode_percent param) ^ "=" ^ (encode_percent pval) in
      let strlist = List.map rewrite lst in
      let rest = String.concat "&" strlist in
      url ^ "?" ^ rest
  in if label="" then url
  else url ^ "#" ^ (encode_percent label)
;;
  
let get_protocol url = 
  let (protocol, _, _, _, _, _) = parse_URL url in
  protocol
;;

let get_host url = 
  let (_, host, _, _, _, _) = parse_URL url in
  host
;;

let get_file url =
  let (_, _, _, file, _ , _) = parse_URL url in
  file
;;

let get_baselocation url = 
  let (protocol, host, port, file, _, _) = parse_URL url in
  let path = try let i = String.index file '/' in
                     String.sub file 0 (i+1)
             with Not_found -> "/"
  in protocol ^ "://" ^ host ^ path
;;
      
