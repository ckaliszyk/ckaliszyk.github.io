(* $Id: monitor.mli,v 1.1 2004/07/24 09:51:01 gozdal Exp $ *)
 
(** Read-write monitor.

    Standard version of the Read-write problem. Solution taken from Ben-Ari.
    
    A thread willing to read/write calls 
    [Monitor.begin_reading] / [Monitor.begin_writing mon]. 
    Then it reads/writes and finally calls 
    [Monitor.end_reading mon] / [Monitor.end_writing mon].
*)
   
(** Monitor data. *)
type t = {
  mutex : Mutex.t;  		(** Access mutex *)
  can_read : Condition.t;	(** Wait for reading *)
  can_write : Condition.t;	(** Wait for writing *)
  mutable awaiting_read : int;	(** Number of readers who wait *)
  mutable readers : int;		(** Number of readers who read *)
  mutable awaiting_write : int;	(** Number of writers who wait *)
  mutable writing : bool;		(** Someone is writing *)
}

(** [Monitor.create ()] creates a monitor. *)
val create : unit -> t

(** [Monitor.begin_reading mon] gives acces to a resource protected by [mon],
    if there is noone writing and noone else waiting to write. *)
val begin_reading : t -> unit

(** [Monitor.end_reading mon] marks that the caller frees a resource protected
    by [mon]. If there are no readers left, it gives access to the resource to
    the first writer in line. *)
val end_reading : t -> unit

(** [Monitor.begin_writing mon] gives acces to a resource protected by [mon],
    if there is noone writing and noone else waiting to read *)
val begin_writing : t -> unit

(** [Monitor.end_writing mon] marks that the caller frees a resource protected
    by [mon] and gives access to the resource to the first reader/writer in 
    line. *)
val end_writing : t -> unit
