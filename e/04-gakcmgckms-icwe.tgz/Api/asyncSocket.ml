(** Implementation of asyncSocket using only select Unix call.
* TODO: reimplement the libEvent one.
*)

type error =
  | CLOSED_OK
  | CLOSED_ERROR of Unix.error;;

exception Exc of error;;

type register =
  | READ
  | READ_WRITE;;

type t = {
  bufsock: BufferedSocket.t;                 (** Underlying buffered socket. *)
};;

type accept_callback = (Unix.sockaddr -> bool);;
type reader_callback = (t -> unit);;

let socks : (Unix.file_descr, register) Hashtbl.t = Hashtbl.create 10;;
let async_socks : (Unix.file_descr, (t * reader_callback)) Hashtbl.t = Hashtbl.create 10;;
let bind_socks : (Unix.file_descr, (accept_callback * reader_callback)) Hashtbl.t = Hashtbl.create 10;;

let rec writer sock fd =
  Log.debug "Writer event";
  try 
    BufferedSocket.flush sock.bufsock;
    (* if reached that far it means that there is no outstanding output
    * buffer - the writer event can be deleted *)
    Hashtbl.replace socks (BufferedSocket.file_descr sock.bufsock) READ;
  with 
  (* As a special case do nothing on WRITE_BLOCKED - the event to invoke
  * writer is already registered *)
  | BufferedSocket.Exc(BufferedSocket.WRITE_BLOCKED) -> ()
  | BufferedSocket.Exc(error) -> handle_bufsock_error sock error

and handle_bufsock_error sock error =
  match error with
  | BufferedSocket.CLOSED_OK -> raise (Exc(CLOSED_OK))
  | BufferedSocket.CLOSED_ERROR(unix_error) -> raise (Exc(CLOSED_ERROR(unix_error)))
  | BufferedSocket.WRITE_BLOCKED -> (
    Log.debug "WRITE_BLOCKED";
    (* Whenever the socket becomes ready to be written to - invoke writer *)
    Hashtbl.replace socks (BufferedSocket.file_descr sock.bufsock) READ_WRITE;
  )
  | BufferedSocket.NO_VALUE | BufferedSocket.NO_ERROR -> ()
;;

let flush sock =
  BufferedSocket.flush sock.bufsock
;;

let reader sock reader_cb =
  Log.debug "Reader event";
  try 
    reader_cb sock
  with 
    | BufferedSocket.Exc(error) -> (
      handle_bufsock_error sock error
    )
;;

let add_desc desc reader_cb =
  let bufsocket = BufferedSocket.create desc in
  let sock = {
    bufsock = bufsocket;
  } in
  Hashtbl.replace socks desc READ;
  Hashtbl.replace async_socks desc (sock, reader_cb);
  sock
;;

let acceptor accept_cb reader_cb fd =
  try 
    let (desc, addr) = Unix.accept fd in 
    (* If the caller does not want this connection - close it *)
    if (not (accept_cb addr)) then Unix.close fd;
    Unix.set_nonblock desc;
    UnixTCP.setsockopt desc UnixTCP.TCP_NODELAY true;
    let _ = match addr with
      | Unix.ADDR_INET(addr, port) -> 
        Log.echo ("Accepted connection from " ^ (Unix.string_of_inet_addr addr) ^ ":" ^ (string_of_int port));
      | _ -> ();
    in 
    let _ = add_desc desc reader_cb in
    ()
  with 
    | Unix.Unix_error(error, _, _) -> (
      Log.echo ("Error while accepting: " ^ (Unix.error_message error));
      Unix.close fd;
    )
;;

let bind addr port accept_cb reader_cb =
  let addr = Unix.ADDR_INET((Unix.inet_addr_of_string addr), port) in
  let sock = Unix.socket Unix.PF_INET Unix.SOCK_STREAM 0 in
  Unix.setsockopt sock Unix.SO_REUSEADDR true;
  Unix.bind sock addr;
  Unix.listen sock 100;
  Unix.set_nonblock sock;

  Hashtbl.replace bind_socks sock (accept_cb, reader_cb)
;;

let resolve_first host port = 
  let host = Unix.gethostbyname host in
  let host_addr = host.Unix.h_addr_list.(0) in
  Unix.ADDR_INET(host_addr, port)
;;

let connect hostname port reader_cb =
  try 
    let addr = resolve_first hostname port in
    let sock = Unix.socket Unix.PF_INET Unix.SOCK_STREAM 0 in
    Unix.connect sock addr;
    Unix.set_nonblock sock;
    UnixTCP.setsockopt sock UnixTCP.TCP_NODELAY true;
    add_desc sock reader_cb
  with 
  | Unix.Unix_error(error, _, _) -> 
      raise (Exc(CLOSED_ERROR(error)))
;;

let input_value sock =
  try
    Some(BufferedSocket.input_value sock.bufsock)
  with
  | BufferedSocket.Exc(error) -> (
    handle_bufsock_error sock error;
    None
  )
;;

let output_value sock obj =
  try
    BufferedSocket.output_value sock.bufsock obj
  with
  | BufferedSocket.Exc(error) ->
      handle_bufsock_error sock error
;;

let close sock =
  let counter _ _ i = (i+1) in
  Log.debug "AsyncSocket.close";
  let len = Hashtbl.fold counter socks 0 in
  Log.debug ("Socks len before: " ^ (string_of_int len));
  let descr = (BufferedSocket.file_descr sock.bufsock) in
  Hashtbl.remove socks descr;
  Hashtbl.remove async_socks descr;
  let len = Hashtbl.fold counter socks 0 in
  Log.debug ("Socks len after: " ^ (string_of_int len));
  BufferedSocket.close sock.bufsock
;;

let rec dispatch () = 
  Log.debug ("dispatch");
  let folder descr reg (read_list, write_list) =
    let read_list = descr::read_list in
    let write_list = 
      if (reg = READ_WRITE) then descr::write_list else write_list
    in (read_list, write_list)
  in
  let (read_list, write_list) = Hashtbl.fold folder socks ([], []) in

  let bind_folder descr _ read_list =
    (descr::read_list)
  in
  let read_list = Hashtbl.fold bind_folder bind_socks read_list in

  Log.debug ("Selecting " ^ (string_of_int (List.length read_list)));

  let (read_descr, write_descr, exc_descr) = 
    try
      Unix.select read_list write_list read_list (-1.0)
    with
    | Unix.Unix_error(code, f, _) ->
        Log.error ("Error in " ^ f ^ ": " ^ (Unix.error_message code));
        failwith "Error";
  in 

  let rec readers descr =
    match descr with
    | descr::rest -> (
      if (Hashtbl.mem bind_socks descr) then (
        let (accept_cb, reader_cb) = Hashtbl.find bind_socks descr
        in acceptor accept_cb reader_cb descr;
      ) else (
        let (sock, reader_cb) = Hashtbl.find async_socks descr 
        in reader sock reader_cb;
      );
      readers rest
    )
    | [] -> ()
  in 
  let rec writers descr =
    match descr with
    | descr::rest -> (
      let (async_sock, _) = Hashtbl.find async_socks descr in
      writer async_sock descr;
      writers rest
    )
    | [] -> ()
  in
  let rec exceptions descr =
    match descr with
    | descr::rest -> (
      let (async_sock, _) = Hashtbl.find async_socks descr in
      handle_bufsock_error async_sock BufferedSocket.CLOSED_OK;
      exceptions rest
    )
    | [] -> ()
  in
  readers read_descr;
  writers write_descr;
  exceptions exc_descr;

  Log.debug ("Tail recursion");
  dispatch()
;;
