type socket_bool_option =
  | TCP_CORK
  | TCP_NODELAY
  | TCP_QUICKACK

type socket_int_option =
  | TCP_DEFER_ACCEPT
  | TCP_KEEPCNT
  | TCP_KEEPIDLE
  | TCP_KEEPINTVL
  | TCP_LINGER2
  | TCP_MAXSEG
  | TCP_SYNCNT
  | TCP_WINDOW_CLAMP

external getsockopt : Unix.file_descr -> socket_bool_option -> bool
                                          = "unix_gettcpopt_bool"
external setsockopt : Unix.file_descr -> socket_bool_option -> bool -> unit
                                          = "unix_settcpopt_bool"
external getsockopt_int : Unix.file_descr -> socket_int_option -> int
                                          = "unix_gettcpopt_int"
external setsockopt_int : Unix.file_descr -> socket_int_option -> int -> unit
                                          = "unix_settcpopt_int"
