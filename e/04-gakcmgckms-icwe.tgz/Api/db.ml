let config_table_name = "SIE_CONFIG";;

let _ = Random.self_init();;

type ('a, 'b) forced_t = {
  tbl_id : int;
};;

type ('a, 'b) t = ('a, 'b) forced_t lazy_t;;

let no_cookie = Int64.zero;;
(** Last cookie received in handle read - zero is a special value meaning that
* after last response no cookie was received. *)
let last_cookie = ref no_cookie;;

(** Hashtable of waiters. Every waiter waits on a condition associated with cookie. *)
let waiters : (Int64.t, (Mutex.t * Condition.t)) Hashtbl.t = Hashtbl.create 5;;
(** Mutex governing sending queries. *)
let db_mutex = Mutex.create ();;
(** Dispatch thread. *)
let dispatch_thread = ref (Thread.self());;
(** Mutex governing [value_cond]. *)
let value_mutex = Mutex.create();;
(** Condition used for waiting on calling thread to pick up value from Overseer. *)
let value_cond = Condition.create();;
(** Hashtable of notification callbacks, indicating change in Overseer table. *)
let notifications = Hashtbl.create 5;;

let handle_error sock error =
  match error with
  | AsyncSocket.CLOSED_OK -> 
      Log.error ("While contacting Overseer on " ^ (CommandLine.get_overseer()) ^ 
                 ": " ^ (Unix.error_message(Unix.ECONNABORTED)));
      raise (Unix.Unix_error(Unix.ECONNABORTED, "Db", ""))
  | AsyncSocket.CLOSED_ERROR(error) ->
      Log.error ("While contacting Overseer on " ^ (CommandLine.get_overseer()) ^ 
                 ": " ^ (Unix.error_message(error)));
      raise (Unix.Unix_error(error, "Db", ""))
;;

let handle_read_cookie sock =
  Log.debug ("handle_read_cookie");
  let cookie = AsyncSocket.input_value sock
  in match cookie with
  | None -> 
      Log.debug ("No cookie read");
      false
  | Some(cookie) -> 
      Log.debug ("Cookie read");
      Log.debug ("Locking value_mutex");
      Mutex.lock value_mutex;
      last_cookie := cookie; 
      Log.debug ("Unlocking value_mutex");
      Mutex.unlock value_mutex;
      true
;;

let notify_change id =
  try 
    let (name, notify_cb) = Hashtbl.find notifications id in
    notify_cb name
  with
  | Not_found -> ()
;;

let handle_push sock =
  let push = AsyncSocket.input_value sock in
  match push with
  | None -> false
  | Some(resp) -> 
      match resp with
      | Overseer_api.Resp_table_change(id) -> 
          notify_change id;
          last_cookie := no_cookie;
          true
      | _ -> assert false
;;

let handle_read_value sock =
  if (!last_cookie = Overseer_api.push_cookie) then
    handle_push sock
  else begin
    Log.debug ("handle_read_value: Locking value_mutex");
    Mutex.lock value_mutex;

    Log.debug ("handle_read_value letting other thread go");
    let (mutex, cond) = 
      (* Not_found handled in handle_read *)
      Hashtbl.find waiters !last_cookie
    in 
    Log.debug ("handle_read_value: Locking mutex");
    Mutex.lock mutex;
    Log.debug ("handle_read_value: Signalling cond");
    Condition.signal cond;
    Log.debug ("handle_read_value: Unlocking mutex");
    Mutex.unlock mutex;

    Log.debug ("handle_read_value: Waiting on value_cond, value_mutex");
    Condition.wait value_cond value_mutex;

    let ret = 
      if (!last_cookie = no_cookie) then begin
        Log.debug ("Returning true - value read");
        true
      end else begin
        Log.debug ("Returning false - value NOT read");
        false
      end
    in
    Log.debug ("handle_read_value: Unlocking value_mutex");
    Mutex.unlock value_mutex;

    ret
  end
;;

let rec handle_read sock =
  Log.debug ("handle_read");
  try
    let read_cookie =
      if (!last_cookie = no_cookie) then
        handle_read_cookie sock
      else
        true
    in let read_value =
      if read_cookie then
        handle_read_value sock
      else
        false
    in if read_value then
      handle_read sock
  with 
  | Not_found ->
      Log.echo ("Unknown cookie received, " ^ (Int64.to_string !last_cookie))
  | AsyncSocket.Exc(error) ->
      handle_error sock error;
;;

let connect_to_overseer () =
  Log.echo ("Connecting to Overseer");
  let overseer_addr = CommandLine.get_overseer() in
  let (_, hostname, port, _, _, _) = Url.parse_URL overseer_addr in
  try
    let ret = AsyncSocket.connect hostname port handle_read in
    Log.echo ("Connected to Overseer");
    dispatch_thread := (Thread.create AsyncSocket.dispatch ());
    Log.echo ("Launched dispatch");
    ret
  with 
  | AsyncSocket.Exc(error) -> begin
      let _ = match error with
      | AsyncSocket.CLOSED_ERROR(Unix.EAGAIN) 
      | AsyncSocket.CLOSED_ERROR(Unix.EINPROGRESS)
      | AsyncSocket.CLOSED_ERROR(Unix.EWOULDBLOCK) -> ()
      | AsyncSocket.CLOSED_ERROR(unix_error) -> begin
          Log.error ("Error connecting to Overseer on " ^
            overseer_addr ^ ": " ^ (Unix.error_message unix_error))
        end
      | AsyncSocket.CLOSED_OK -> begin
          Log.error ("Error connecting to Overseer on " ^ overseer_addr)
        end
      in raise (AsyncSocket.Exc(error))
  end
;;

let overseer_sock : AsyncSocket.t lazy_t = lazy (
  connect_to_overseer()
);;

let overseer_conn () =
  Lazy.force overseer_sock
;;

let print_hexchar c =
  let i = (int_of_char c) in
  Printf.printf "%02x " i;
;;

(*
let hexdump str = 
  String.iter print_hexchar str;
  print_newline ()
;;
*)
let hexdump _ = () ;;

let dump_hex obj =
  let str = Marshal.to_string obj [] in
  hexdump str
;;

let random_64 () =
  Random.int64 (Int64.max_int)
;;

let rec _wait (mutex, cond) =
  Log.debug ("_wait: locking value_mutex");
  Mutex.lock value_mutex;

  Log.debug "_wait";
  let resp : ('a, 'b) Overseer_api.db_t option =
    AsyncSocket.input_value (overseer_conn())
  in match resp with
  | None -> 
      Log.debug ("_wait: signalling value_cond");
      Condition.signal value_cond;
      Log.debug ("_wait: unlocking value_mutex");
      Mutex.unlock value_mutex;
      Log.debug ("_wait: waiting on cond mutex");
      Condition.wait cond mutex;
      _wait (mutex, cond)
  | Some(resp) -> 
      Log.debug ("_wait: zeroing last_cookie");
      last_cookie := no_cookie;
      Log.debug ("_wait: signalling value_cond");
      Condition.signal value_cond;
      Log.debug ("_wait: unlocking value_mutex");
      Mutex.unlock value_mutex;
      Log.debug ("_wait: unlocking mutex");
      Mutex.unlock mutex; 
      resp
;;

let wait (mutex, cond) =
  Log.debug ("wait: waiting on cond mutex");
  Condition.wait cond mutex;
  _wait (mutex, cond)
;;

let send_and_wait query =
  Log.debug ("send_and_wait");
  let cookie = random_64() in
  let mutex = Mutex.create () in
  let cond = Condition.create () in
  Log.debug ("wait: locking mutex");
  Mutex.lock mutex;
  Hashtbl.replace waiters cookie (mutex, cond);
  
  Mutex.lock db_mutex;
  
  Log.echo ("Writing cookie");
  AsyncSocket.output_value (overseer_conn()) cookie;
  Log.echo ("Writing query");
  AsyncSocket.output_value (overseer_conn()) query;
  AsyncSocket.flush (overseer_conn());
  Log.echo ("Query written");

  Mutex.unlock db_mutex;

  let resp = wait (mutex, cond) in
  Log.echo ("Query responded, removing cookie");
  Hashtbl.remove waiters cookie;
  resp
;;

let add_notification table_name id cb =
  Hashtbl.replace notifications id (table_name, cb)
;;

let forced_init table_name cb =
  Log.echo ("Db.forced_init " ^ table_name);
  try
    let resp : ('a, 'b) Overseer_api.db_t = 
      send_and_wait (Overseer_api.Query_init(table_name)) 
    in match resp with
    | Overseer_api.Resp_table_id(id) -> begin
      let _ = match cb with
      | Some(cb) -> add_notification table_name id cb
      | None -> ()
      in
      { tbl_id = id; }
    end
    | _ -> assert false
  with
  | AsyncSocket.Exc(error) -> 
      handle_error (overseer_conn()) error
;;

let init table_name cb =
  Log.echo ("Db.init " ^ table_name);
  lazy (forced_init table_name cb)
;;

let get lazy_table key =
  let table = Lazy.force lazy_table in
  try
    let resp : ('a, 'b) Overseer_api.db_t =
      send_and_wait (Overseer_api.Query_get(table.tbl_id, key))
    in match resp with
    | Overseer_api.Resp_get(value) -> value
    | _ -> assert false
  with
  | AsyncSocket.Exc(error) ->
      handle_error (overseer_conn()) error
;;

let change lazy_table key new_val =
  let table = Lazy.force lazy_table in
  try
    let resp : ('a, 'b) Overseer_api.db_t =
      send_and_wait (Overseer_api.Query_set(table.tbl_id, key, new_val))
    in match resp with
    | Overseer_api.Resp_set -> ()
    | _ -> assert false
  with
  | AsyncSocket.Exc(error) ->
      handle_error (overseer_conn()) error
;;

let set a_db key new_val =
  change a_db key (Some new_val)
;;

let remove a_db key =
  change a_db key (None)
;;

