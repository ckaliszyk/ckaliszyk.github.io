(**
 * Implementation of a buffered socket with convenient access. Necessary
 * to support libEvent.
 *)

type error =
  | NO_ERROR
  | NO_VALUE
  | WRITE_BLOCKED
  | CLOSED_OK
  | CLOSED_ERROR of Unix.error;;

exception Exc of error;;

type t = {
  inbuf: Buffer.t;              (** Input buffer. *)
  mutable inbuf_changed: bool;  (** Has input buffer been changed after inbuf_cache was taken. *)
  mutable inbuf_cache: string;  (** Cached contents of inbuf. *)
  mutable inpos: int;           (** Current position in buffer (when something has been cut from the beginning). *)
  outbuf: Buffer.t;             (** Output buffer. *)
  mutable outbuf_changed: bool; (** Has the output buffer been changed since cache was last updated. *)
  mutable outbuf_cache: string; (** Cached contents of outbuf. *)
  mutable outpos: int;          (** Current position in the output buffer. *)
  mutable last_error: error;    (** Last error to be returned (after whole inbuf has been returned to user). *)
  mutable stored_header: string;(** Stored marshalled header. *)
  sock: Unix.file_descr;        (** Socket descriptor. *)
};;

(** Empty string, used as a return value sometimes. *)
let empty = "";;
(** Default buffer length used for reading. *)
let buf_len = 4096;;

let create unix_socket =
  { 
    inbuf = Buffer.create 1000; 
    inbuf_changed = false;
    inbuf_cache = "";
    inpos = 0; 
    outbuf = Buffer.create 10; (* Usually won't be used (hopefully), so try to conserve memory. *)
    outbuf_changed = false;
    outbuf_cache = "";
    outpos = 0;
    last_error = NO_ERROR;
    stored_header = "";
    sock = unix_socket;
  }
;;

(** Retrieve the number of bytes left in [inbuf]. *)
let buf_left bufsock =
  (Buffer.length bufsock.inbuf) - bufsock.inpos
;;

(** Store a copy of contents in buffer into [inbuf_cache] if necessary. *)
let update_incache bufsock =
  if (bufsock.inbuf_changed) then (
    bufsock.inbuf_changed <- false;
    bufsock.inbuf_cache <- Buffer.contents bufsock.inbuf;
  )
;;

(** Advance [inpos] in [bufsock] by [len] bytes. If [inpos] reaches end of [inbuf]
 * it is reset.
*)
let buf_advance bufsock len =
  bufsock.inpos <- (bufsock.inpos + len);
  if (bufsock.inpos = Buffer.length bufsock.inbuf) then (
    Buffer.reset bufsock.inbuf;
    bufsock.inbuf_cache <- empty;
    bufsock.inbuf_changed <- false;
    bufsock.inpos <- 0;
  )
;;

(** Return a string cotaining first [len] bytes from [inbuf]. *)
let buf_cut bufsock len =
  update_incache bufsock;
  let result = String.sub bufsock.inbuf_cache bufsock.inpos len in
  let _ = buf_advance bufsock len in
  result
;;

(** Return exactly [len] bytes from underlying socket. If
  * [len] bytes could not be read - returns empty string. *)
let read_exactly bufsock len =
  Log.debug ("read_exactly of " ^ (string_of_int len));
  
  let rec reader acc = 
    Log.debug ("reader " ^ (string_of_int acc));
    let temp = String.create buf_len in
    Log.debug ("Doing Unix.read of " ^ (string_of_int buf_len) ^ " bytes");
    (* Try to read. When exception occurs - wrap it with Exc *)
      let ret = try Unix.read bufsock.sock temp 0 buf_len with
      | Unix.Unix_error(error, _, _) -> raise (Exc(CLOSED_ERROR(error)))
    in
    (* 0 bytes returned means the connection was closed gracefully.
    * If the connection was terminated because of an error - it will raise
    * an exception, caught below. If there is no data to read and connection
    * is still established it will raise EAGAIN or EWOULDBLOCK which will
    * be as well caught below.
    *)
    Log.debug ("Unix.read returned " ^ (string_of_int ret) ^ " bytes");
    if ret = 0 then raise (Exc(CLOSED_OK));
    bufsock.inbuf_changed <- true;
    Buffer.add_substring bufsock.inbuf temp 0 ret;
    (* Read until we get an exception *)
    reader (acc+ret)
  in

  (* If there is enough data in the inbuf - return it without trying to read *)
  Log.debug ("In buf " ^ (string_of_int (buf_left bufsock)) ^ ", needed " ^ (string_of_int len));
  if (buf_left bufsock >= len) then (
    buf_cut bufsock len
  ) else
    try 
      (* Try to read only if the connection is OK *)
      if bufsock.last_error = NO_ERROR then 
        reader 0
      else
        raise (Exc(bufsock.last_error))
    with
    | Exc(error) -> match error with
      | NO_VALUE -> raise (Failure("Exception Bufsock with NO_VALUE!"))
      | NO_ERROR -> raise (Failure("Exception Bufsock with NO_ERROR!"))
      | WRITE_BLOCKED -> raise (Failure("Exception Bufsock with WRITE_BLOCKED!"))
      | CLOSED_ERROR(Unix.EAGAIN) | CLOSED_ERROR(Unix.EWOULDBLOCK) -> (
        Log.debug ("EAGAIN");
        (* We read some bytes, check if this is enough *)
        if (buf_left bufsock >= len) then (
          Log.debug ("After EAGAIN: in buf " ^ (string_of_int (buf_left bufsock)) ^ ", needed " ^ (string_of_int len));
          (* If we read enough return it *)
          buf_cut bufsock len
        ) else 
          (* Raise error if necessary *)
          if (bufsock.last_error <> NO_ERROR) then
            raise (Exc(bufsock.last_error))
          else (* If we failed to read necessary amount of data return empty string *)
            empty
          )
      | CLOSED_OK -> (
        Log.debug ("Got CLOSED_OK");
        bufsock.last_error <- CLOSED_OK;
        raise(Exc(CLOSED_OK))
      )
      | CLOSED_ERROR(error) -> (
        bufsock.last_error <- CLOSED_ERROR(error);
        raise(Exc(CLOSED_ERROR(error)))
      )
;;

let update_outcache bufsock =
  if (bufsock.outbuf_changed) then (
    bufsock.outbuf_changed <- false;
    bufsock.outbuf_cache <- Buffer.contents bufsock.outbuf;
  )
;;

(** Try to write whole output buffer. *)
let flush bufsock =
  let total_len = Buffer.length bufsock.outbuf in
  if total_len > 0 then begin
    (* Make sure outbuf_cache contains current snapshot of the buffer. *)
    update_outcache bufsock;
    (* Calculate number of bytes pending to write *)
    let len = total_len - bufsock.outpos in
    (* Try to write *)
    let ret = Unix.write bufsock.sock bufsock.outbuf_cache bufsock.outpos len in
    (* Advance the outpos pointer *)
    bufsock.outpos <- bufsock.outpos + ret;
    (* Deallocate the stream if it's been written in whole *)
    if (bufsock.outpos = total_len) then begin
      Buffer.reset bufsock.outbuf;
      bufsock.outbuf_changed <- true;
      bufsock.outpos <- 0;
    end else
      (* Raise exception to indicate there is still something to write *)
      raise (Exc(WRITE_BLOCKED))
  end
;;

let append_out bufsock buf ofs len =
  Buffer.add_substring bufsock.outbuf buf ofs len;
  bufsock.outbuf_changed <- true;
;;

(* Write exactly [len] bytes from [buf] to socket in [bufsock]. *)
let write_exactly bufsock buf len =
  append_out bufsock buf 0 len;
;;

let print_hexchar c =
  let i = (int_of_char c) in
  Printf.printf "%02x " i;
;;

(*
let hexdump str = 
  String.iter print_hexchar str;
  print_newline();
;;
*)
let hexdump _ = () ;;

let output_value bufsock obj =
  let marshalled = Marshal.to_string obj [] in
  Log.debug ("BufferedSocket.output_value of: ");
  hexdump (marshalled);
  (* Just buffer the value *)
  write_exactly bufsock marshalled (String.length marshalled)
;;

let input_value bufsock =
  Log.debug "BufferedSocket.input_value";
  if (bufsock.stored_header = "") then
    bufsock.stored_header <- (read_exactly bufsock Marshal.header_size);
  Log.debug ("Want for header: " ^ (string_of_int Marshal.header_size));
  if (bufsock.stored_header = "") then (
    Log.debug ("Not enough for header, raising NO_VALUE");
    raise (Exc(NO_VALUE))
  ) else 
    try
      let data_size = (Marshal.data_size bufsock.stored_header 0) in
      Log.debug ("Read header, data_size == " ^ (string_of_int data_size));
      let marshaled = read_exactly bufsock data_size in
      match marshaled with
      | "" -> raise (Exc(NO_VALUE))
      | any -> (
        let buf = Buffer.create (data_size + Marshal.header_size) in
        Buffer.add_string buf bufsock.stored_header;
        Buffer.add_string buf any;
        bufsock.stored_header <- "";
        hexdump (Buffer.contents buf);
        Marshal.from_string (Buffer.contents buf) 0
      )
    with
    | Failure(_) -> (
      Log.echo ("Got rubbish, closing");
      raise(Exc(CLOSED_OK))
    )
;;

let close bufsock =
  Log.debug "BufferedSocket.close";
  try Unix.close bufsock.sock with
  | _ -> ()
;;

let file_descr bufsock =
  bufsock.sock
;;
