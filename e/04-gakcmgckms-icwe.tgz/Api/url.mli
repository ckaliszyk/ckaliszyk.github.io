(** Functions for decoding urls
  @author Grzegorz Andruszkiewicz
*)

exception Error

(** [char_as_hex2int hexdigit] returns the integer value of hexadecimal digit *)
val char_as_hex2int : char -> int

(** [set_plus_to_space str] changes all spaces to pluses in given url *)
val set_plus_to_space : string -> unit

(** [decode_percent url] returns an url with decoded escaped charakters (eg %6E)
 *)
val decode_percent : string -> string

(** [get_url_name url_name_without_protocol] returns a pair (the url part, the
  rest, which can be nothing or the rest of an url) *)
val get_url_name : string -> string * string

(** [get_url_port url_without_hostname] returns a pair (port if string begins
  with ':', else 80, rest) *)
val get_url_port : string -> int * string

(** [get_url_file filename_with_parameters] returns a pair (filename, unparsed
  parametres) *)
val get_url_file : string -> string * string

(** [get_params_from_str splitter unparsed_parameters_separated_by_splitter] returns a list of pairs
 of (parameter name, param value) *)
val get_params_from_str : char -> string -> (string * string) list

(** [get_file_params unparsed_file_parameters] returns a list of pairs
 of (parameter name, param value) and label*)
val get_file_params : string -> (string * string) list * string

(** [parse_URL url] returns all parts of url: (protocol, host, port, file, 
                                               list of params, label) *)
val parse_URL : string -> string * string * int * string * (string * string) list * string

(** [deparse_URL (protocol, host, port, file, list of params, label)] returns valid url
 *)
val deparse_URL :  string * string * int * string * (string * string) list * string-> string

(** [get_baselocation url] returns the beginning of the url pointing to the
  directory in which is the document *)
val get_baselocation : string -> string


(** [get_protocol url] returns the protocol extracted from an url *)
val get_protocol : string -> string

(** [get_host url] returns the host extracted from an url *)
val get_host : string -> string

(** [get_file url] returns the file extracted from an url *)
val get_file : string -> string

