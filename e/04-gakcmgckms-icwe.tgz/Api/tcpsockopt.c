#include <mlvalues.h>
#include <alloc.h>

#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> 
#include <netinet/tcp.h>

#define Nothing ((value) 0)
typedef socklen_t socklen_param_type;

static int tcpopt_bool[] = {
  TCP_CORK, TCP_NODELAY, TCP_QUICKACK
};

static int tcpopt_int[] = {
  TCP_DEFER_ACCEPT, TCP_KEEPCNT, TCP_KEEPIDLE, 
  TCP_KEEPINTVL, TCP_LINGER2, TCP_MAXSEG, TCP_SYNCNT, TCP_WINDOW_CLAMP
};

static CAMLprim value getsockopt_int(int *sockopt, value socket,
                              int level, value option)
{
  int optval;
  socklen_param_type optsize;

  optsize = sizeof(optval);
  if (getsockopt(Int_val(socket), level, sockopt[Int_val(option)],
                 (void *) &optval, &optsize) == -1)
    uerror("getsockopt", Nothing);
  return Val_int(optval);
}

static CAMLprim value setsockopt_int(int *sockopt, value socket, int level,
                              value option, value status)
{
  int optval = Int_val(status);
  if (setsockopt(Int_val(socket), level, sockopt[Int_val(option)],
                 (void *) &optval, sizeof(optval)) == -1)
    uerror("setsockopt", Nothing);
  return Val_unit;
}

CAMLprim value unix_gettcpopt_bool(value socket, value option) {
  value res = getsockopt_int(tcpopt_bool, socket, SOL_TCP, option);
  return Val_bool(Int_val(res));
}

CAMLprim value unix_settcpopt_bool(value socket, value option, value status)
{
 return setsockopt_int(tcpopt_bool, socket, SOL_TCP, option, status);
}

CAMLprim value unix_gettcpopt_int(value socket, value option) {
  return getsockopt_int(tcpopt_int, socket, SOL_TCP, option);
}

CAMLprim value unix_settcpopt_int(value socket, value option, value status)
{
 return setsockopt_int(tcpopt_int, socket, SOL_TCP, option, status);
}
