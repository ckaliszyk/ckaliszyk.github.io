(** BLogReader *)

type click = (float * string * string * string);;
type entry = (string * string * click list);;

(** [iter filename] read filename's log entries. 
 *)
val read : string -> entry list ;;
