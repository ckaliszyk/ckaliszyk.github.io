type click = (float * string * string * string);;

type entry = (string * string * click list);;

let read filename = 
  let log = (open_in_gen [Open_rdonly;Open_binary] (256+128) filename) in
  let rec read_acc acc =
    try
      let data : entry = input_value log in
      read_acc (data::acc)
      
      (* FIXME: Filter out SIE_ROBOT and SIE_BENCHMARK *)
      (*if String.length cli_no < 16 then () else
      Array.iter (iterator cli_no sess_name) clicks*)
      
    with
    | End_of_file -> List.rev acc
  in let res = read_acc [] in
  close_in log;
  res
;;
