(** Box link rewriter *)

(** stores all params for the client *)
val remember_params : (string, unit) Hashtbl.t;;

(** [remove_params request] removes all unnecessary session params
   from the request *)
val remove_params : Types.request -> unit

(** [set_magic_links request response] rewrites all links in the html tree
   so that their from address is known and remeblers all params for the
   client *)
val set_magic_links : Types.request -> Types.response -> unit

(** [get_real_link request] sets the from field in the request *)
val get_real_link : Types.request -> Types.response option

val init : unit -> Types.sie_module_init
