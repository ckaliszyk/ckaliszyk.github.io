exception Error;;

let get_params lexbuf =
  let rec get_params_rec acc ct =
    match Response_lexer.lex_params lexbuf with
      None -> (List.rev acc, ct)
    | Some (param) ->
        let _ = Response_lexer.lex_equal lexbuf in
        let value = Response_lexer.lex_paramval lexbuf in
        let _ = Response_lexer.lex_eol lexbuf in
        if param = "Content-Type" then 
          get_params_rec acc value
        else if param = "Keep-Alive" then
	  get_params_rec acc ct
        else if param = "Connection" then
	  get_params_rec ((param," Close") :: acc) ct
        else
	  get_params_rec ((param, value) :: acc) ct
  in
  get_params_rec [] ""
;;

let parse_headers lexbuf desc buf_opt_ref = 
  lexbuf.Lexing.lex_last_action <- 0;
  let ver = Response_lexer.lex_ver lexbuf in
  let keep = if ver = 11 then true else false in
  let code = Response_lexer.lex_no lexbuf in
  let phrase = Response_lexer.lex_paramval lexbuf in
  let _ = Response_lexer.lex_eol lexbuf in
  let response = 
  { Types.html_tree = [];
    Types.server_ver = ver;
    Types.status_code = code;
    Types.status_phrase = phrase;
    Types.set_cookie = "";
    Types.content_encoding = Types.Identity;
    Types.transfer_coding = Types.Normal;
    Types.content_language = "";
    Types.content_type = "";
    Types.response_params = [];
    Types.panel = Nethtml.Data "";
    Types.content_length = 0;
    Types.server_keep_alive = keep;
    Types.location = "";
    Types.content_location = "";
  } in
  let rec get_record () =
    match Response_lexer.lex_params lexbuf with
      None -> ()
    | Some param ->
        let _ = Response_lexer.lex_equal lexbuf in
        let value = Response_lexer.lex_paramval lexbuf in
        let _ = Response_lexer.lex_eol lexbuf in
	(match String.uppercase param with
	  "CONTENT-ENCODING" -> response.Types.content_encoding <-
	                       (match (String.lowercase value) with
	                           "gzip" -> Types.Gzip
				 | "compress" -> Types.Compress
				 | "deflate" -> Types.Deflate
				 | "identity" -> Types.Identity
				 | other -> Types.Other_coding other)
	| "TRANSFER-ENCODING" -> response.Types.transfer_coding <-
	                       (match (String.lowercase value) with
	                           "normal" -> Types.Normal
				 | "chunked" -> Types.Chunked
				 | other -> Types.Other_transfer other)
	| "CONTENT-LANGUAGE" -> response.Types.content_language <- value
	| "CONTENT-TYPE" -> response.Types.content_type <- value
	| "CONTENT-LENGTH" -> response.Types.content_length <- (int_of_string value) 
	| "CONNECTION" -> if (String.lowercase value)="keep-alive"
	                    then response.Types.server_keep_alive <- true
			    else response.Types.server_keep_alive <- false
        | "LOCATION" -> response.Types.location <- value
        | "CONTENT-LOCATION" -> response.Types.content_location <- value
	| other -> response.Types.response_params <- (param, value) ::
	                           response.Types.response_params
	);
	get_record ()
  in get_record();
  lexbuf.Lexing.lex_last_action <- 0;
  match response.Types.transfer_coding with
  | Types.Other_transfer _ -> raise Error
  | Types.Normal ->

      if Utils.is_text_html response then
        response.Types.html_tree <- Nethtml.parse_document lexbuf;
      response
  | Types.Chunked ->
      let buf = Buffer.create 1024 in
      try
        if Utils.is_text_html response then begin
          while true do
            let chnk = Response_lexer.lex_chunk lexbuf in
            let transfer_len len = 
              Log.echo ("Chunk: " ^ string_of_int len);
              ignore (Response_lexer.lex_eol lexbuf);
              Log.echo "EolOk";
              if len = 0 then raise Exit else
              let more = Box_io.buf_lexer_len buf lexbuf len in
(*              Log.echo (Buffer.contents buf);*)
              Log.echo ("More: " ^ string_of_int more);
              Box_io.transfer_buf_len desc buf more buf_opt_ref;
              Log.echo ("Done");
            in
            Scanf.sscanf chnk "%x" transfer_len;
            (* The chunk was not a last one, so get another crlf *)
            ignore (Response_lexer.lex_eol lexbuf)
          done;
        end;
        response
      with Exit -> 
        let cnt = Buffer.contents buf in
        let lex = Lexing.from_string cnt in
        response.Types.html_tree <- Nethtml.parse_document lex;
        response
;;

(*
let output_lexer desc lexbuf =
  let lexstr = lexbuf.Lexing.lex_buffer
  and lexbeg = lexbuf.Lexing.lex_curr_pos in
  let lexlen = lexbuf.Lexing.lex_buffer_len - lexbeg in
  let str = String.sub lexstr lexbeg lexlen in
  Io.write desc str
;;
*)
let output cli_desc request response svr_opt_ref buf_opt_ref = 
  response.Types.set_cookie <- request.Types.cli_no;
  let html_buff = 
    if response.Types.html_tree <> [] then begin
      response.Types.transfer_coding <- Types.Normal;
      let len_buff = Buffer.create 4096 in
      Nethtml.write (Buffer.add_string len_buff) response.Types.html_tree;
      response.Types.content_length <- Buffer.length len_buff;
      len_buff
    end else Buffer.create 0
  in
  response.Types.server_ver <- 10;
  response.Types.server_keep_alive <- false;
  let out_buff = Buffer.create 1000 in
  let add_str = Buffer.add_string out_buff
  and add_char = Buffer.add_char out_buff in
  add_str (Response_lexer.ver_to_string response.Types.server_ver);
  add_str (string_of_int response.Types.status_code);
  add_char ' ';
  add_str response.Types.status_phrase;
  add_char '\n';
  (* Specific headers *)
  if response.Types.content_type <> "" then begin
    add_str "Content-Type: ";
    add_str response.Types.content_type;
    add_char '\n' 
  end else ();
  begin match response.Types.content_encoding with
    Types.Gzip -> add_str "Content-encoding: Gzip\n"
  | Types.Compress -> add_str "Content-encoding: Compress\n"
  | Types.Deflate -> add_str "Content-encoding: Deflate\n"
  | Types.Identity -> ()
  | Types.Other_coding s -> add_str ("Content-encoding: " ^ s ^ "\n")
  end;
  begin match response.Types.transfer_coding with
    Types.Chunked -> add_str "Transfer-encoding: chunked\n"
  | Types.Normal -> ()
  | Types.Other_transfer s -> add_str ("Transfer-encoding: " ^ s ^ "\n")
  end;
  if response.Types.content_length > 0 then begin
    add_str "Content-length: ";
    add_str (string_of_int response.Types.content_length);
    add_char '\n';
  end else ();
  
  if response.Types.content_language <> "" then begin
    add_str "Content-language: ";
    add_str response.Types.content_language;
    add_char '\n';
  end else ();
  
  add_str "Connection: ";
  if response.Types.server_keep_alive then 
    add_str "Keep-Alive\n"
  else 
    add_str "Close\n";

  if response.Types.set_cookie <> "" then begin
    let b = response.Types.set_cookie in 
    add_str ("Set-Cookie: " ^ Request.cookie_name ^ "=" ^ b ^
             "; expires=Sun, 17-Jan-2038 19:14:07 GMT; path=/\n"); 
  end else ();
  if response.Types.location<>"" then begin
    add_str "Location: ";
    add_str response.Types.location;
    add_str "\r\n"
  end;
  if response.Types.content_location<>"" then begin
    add_str "Content-Location: ";
    add_str response.Types.content_location;
    add_str "\r\n"
  end;

  (* unrecognized params *)
  let iterator (param, value) =
    add_str param;
    add_str ": ";
    add_str value;
    add_char '\n' in
  List.iter iterator (List.rev response.Types.response_params);
  add_char '\n';
  Box_io.write_buf cli_desc out_buff;
  Box_io.write_buf cli_desc html_buff;
  match response.Types.transfer_coding with
  | Types.Other_transfer _ -> raise Error
  | Types.Normal ->
      let more = response.Types.content_length in
      if Buffer.length html_buff = 0 && more > 0 then begin
        let (svr_desc, svr_lexbuf) = Utils.get_svr svr_opt_ref in
        let more = Box_io.output_lexer_len cli_desc svr_lexbuf more in
        Box_io.transfer_len svr_desc cli_desc more buf_opt_ref
      end
  | Types.Chunked ->
      let (svr_desc, svr_lexbuf) = Utils.get_svr svr_opt_ref in
      if Utils.is_text_html response then () else
      try
        while true do
          let chnk = Response_lexer.lex_chunk svr_lexbuf in
          let transfer_len len = 
            Log.echo ("Chunk: " ^ string_of_int len);
            ignore (Response_lexer.lex_eol svr_lexbuf);
            Box_io.write cli_desc (Printf.sprintf "%x\r\n" len);
            Log.echo "EolOk";
            if len = 0 then raise Exit else
            let more = Box_io.output_lexer_len cli_desc svr_lexbuf len in
            Box_io.transfer_len svr_desc cli_desc more buf_opt_ref;
            Log.echo ("Done");
          in
          Scanf.sscanf chnk "%x" transfer_len;
          (* The chunk was not a last one, so get another crlf *)
          ignore (Response_lexer.lex_eol svr_lexbuf);
          Box_io.write cli_desc "\r\n";
        done;
      with Exit -> ()
;;
