(** Main worker module *)

(** [get_response request cli_desc cli_lexbuf svr_opt_ref buf_opt_ref] Gets
   the response for a request from real server *)
val get_response :
  Types.request ->
  Unix.file_descr ->
  Lexing.lexbuf ->
  (Unix.file_descr * Lexing.lexbuf) option ref ->
  string option ref -> Types.response;;

(** [process_request cli_desc cli_lex cli_ip ser_opt_ref buf_opt_ref]
   Processes a single request in the connection *)
val process_request :
  Unix.file_descr ->
  Lexing.lexbuf ->
  string ->
  (Unix.file_descr * Lexing.lexbuf) option ref -> 
  string option ref -> 
  Types.sie_module list ->
  (string, Types.sie_module list) Hashtbl.t ->
  unit;;

(** [worker cli_desc use_rb_ip ip] A single worker thread that is responsible
   for processing a single connection from a client *)
val worker : 
  Unix.file_descr -> 
    bool -> 
      Types.sie_module list ->
        (string, Types.sie_module list) Hashtbl.t ->
          Unix.sockaddr -> 
            unit;;
