(** Box utilities *)

(** [is_text_html response] Checks if the given response should be processed by all response modifiers *)
val is_text_html : Types.response -> bool

(** [get_ip desc ip] Gets the ip of the client from Request broker or from
   address if the connection is a local one *)
val get_ip : Unix.file_descr -> Unix.sockaddr -> bool -> string

(** [get_svr svr_opt_ref] Returns the connection to the server and lexbuffer or creates one if none available *)
val get_svr :
  (Unix.file_descr * Lexing.lexbuf) option ref ->
  Unix.file_descr * Lexing.lexbuf

(** [get_buf buf_opt_ref] Gets a free buffer or creates a new one if none available *)
val get_buf : string option ref -> string

val resolve_first : string -> int -> Unix.sockaddr
