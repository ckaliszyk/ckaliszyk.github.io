DIR:=Box
TARGET:=Box
FILES:= box_io utils request_lexer request \
	response_lexer response session rewriter worker box 
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Api/api.$(LIB_SUF) out/Config/config.$(LIB_SUF) out/Panel/panel.$(LIB_SUF) out/SEE/Common/see.$(LIB_SUF) out/SEE/E/e_see.$(LIB_SUF) out/Adapter/Common/common.$(LIB_SUF) out/Adapter/BM/better_maker.$(LIB_SUF) out/Common/Pcre/pcre.$(LIB_SUF) out/Common/Netstring/netstring.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} unix.$(LIB_SUF) threads.$(LIB_SUF) str.$(LIB_SUF) -o $@ $^
