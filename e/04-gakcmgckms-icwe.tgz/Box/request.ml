exception Error;;

let config = Config.create "Box/request";;

let cookie_name = Config.get config "COOKIE_NAME";;
(* Internal, reads all http request params (sth=sth) and stores them in a
 * tuple list.
 * Called by Request.input
 *)
let get_params lexbuf =
  let rec get_params_rec acc =
    match Request_lexer.lex_params lexbuf with
      None -> List.rev acc
    | Some (param) ->
        let _ = Request_lexer.lex_equal lexbuf in
        let value = Request_lexer.lex_paramval lexbuf in
        let _ = Request_lexer.lex_eol lexbuf in
        if param = "Keep-Alive" then
          get_params_rec acc
        else if param = "Connection" then
          get_params_rec ((param," Close") :: acc)
        else
          get_params_rec ((param, value) :: acc)
  in
  get_params_rec []
;;


let get_cookies str =
  Url.get_params_from_str ';' str
;;

let rec get_cli_no cookie_lst =
  try List.assoc cookie_name cookie_lst
  with Not_found -> ""
;;

(* Parses a request coming from descriptor.
 * Calls Request_lexer.*, Request.get_params
 * Throws Request.Error
 *)
let input lexbuf cli_ip =
  try
    lexbuf.Lexing.lex_last_action <- 0;
    let mthd = Request_lexer.lex_method lexbuf in
    let file = Request_lexer.lex_file lexbuf in
    let ver = Request_lexer.lex_ver lexbuf in
    let keep = if ver=11 then true
                else false in
    let _ = Log.echo ("MORWA: do parsera " ^ file) in
    let (protocol, url, port, file, file_params, label) = Url.parse_URL file in
    let request =
    {
      Types.mthd = mthd;
      Types.protocol = protocol;
      Types.file = file; (* new file! *)
      Types.from = "";
      Types.ver = ver;
      Types.data_length = 0;
      Types.unrecognized_params = [];
      Types.cli_no = ""; (* Na razie, potem jak wiemy wi�cej to zminimy *)
      Types.host = url;
      Types.port = port;
      Types.file_params = file_params;
      Types.sie_params = [];
      Types.label = label;
      Types.x_forwarded_for = None;
      Types.robot = false;
      Types.cookies = [];
      Types.ip = cli_ip;
      Types.keep_alive = keep;
      Types.link_content = "";
      Types.link_original = Config.get config "SIE_TARGETURL";
      Types.referer = "";
      Types.is_internal_page = false;
    } in
    let rec get_record () =
      match Request_lexer.lex_params lexbuf with
      None -> ()
      | Some param ->
        let _ = Request_lexer.lex_equal lexbuf in
        let value = Request_lexer.lex_paramval lexbuf in
        let _ = Request_lexer.lex_eol lexbuf in
	(match String.uppercase param with
	    "HOST" -> (
              Log.echo ("Tu HOST: File = " ^ request.Types.file);
              if request.Types.host = "" then
                try
                  let i = String.index value ':' in
                  request.Types.host <- String.sub value 0 i;
                  let rest = 
                    String.sub value (i + 1) ((String.length value) - i - 1) in
                  request.Types.port <- int_of_string rest
                with
                Not_found -> request.Types.host <- value
                else ()
            )
	  | "X-FORWARDED-FOR" -> request.Types.x_forwarded_for <- Some value
	  | "CONTENT-LENGTH" -> request.Types.data_length <- int_of_string 
                value
	  | "COOKIE" -> request.Types.cookies <- 
	                       (get_cookies value) @ request.Types.cookies
	  | "CONNECTION" -> if (String.lowercase value)="keep-alive"
	                    then request.Types.keep_alive <- true
			    else request.Types.keep_alive <- false
          | "REFERER" -> request.Types.referer <- value	  
          | unrec -> request.Types.unrecognized_params 
	               <- (param, value)::request.Types.unrecognized_params
	);
	get_record ()
    in begin
      get_record ();
      let cookie_cli_no = get_cli_no request.Types.cookies in
      if cookie_cli_no <> "" then request.Types.cli_no <- cookie_cli_no;
      request
    end
  with
    Failure _ -> raise Error
;;

let cut_off_parameters url =
  let (_, host, _, _, _, _) = Url.parse_URL url
  in host
;;

(* Deparses a request and outputs it to out_chann.
 * Calls Request_lexer.*
 *)
let output svr_desc request cli_lexbuf cli_desc buf_opt_ref =
(*  request.Types.ver <- 10; *)
  request.Types.keep_alive <- false;
  let out_buff = Buffer.create 100 in
  let add_str = Buffer.add_string out_buff
  and add_char = Buffer.add_char out_buff in
  add_str (Request_lexer.mthd_to_string request.Types.mthd);
  add_char ' ';
  if request.Types.host <> "" && request.Types.ver = 10 then begin
    (*
    add_str "http://";
    add_str request.Types.host;
    if request.Types.port <> 80 then begin
      add_char ':';
      add_str (string_of_int request.Types.port);
    end else (); *)
    Log.echo ("Chuj: " ^ request.Types.link_original);
    add_str (cut_off_parameters request.Types.link_original);
  end else ();
  Log.echo ("File: " ^ request.Types.file);
  add_str request.Types.file;
    
  let file_params = request.Types.file_params in
   if file_params<>[] then begin
    add_char '?';
    let rec output_l list =
      match list with
        [] -> ()
      | [(param, value)] -> add_str param;
          add_char '=';
          add_str value;
      | (param, value)::ending ->add_str param;
          add_char '=';
          add_str value;
	  add_char '&';
	  output_l ending; 
        
    in
    output_l (List.rev file_params)
  end else ();
  if (request.Types.ver > 9) then begin
    add_char ' ';
    add_str (Request_lexer.ver_to_string request.Types.ver);
    (* Named params *)
    if request.Types.ver = 11 then begin
      add_str "Host: ";
      (*
      add_str request.Types.host;
      if request.Types.port <> 80 then begin
        add_char ':';
        add_str (string_of_int request.Types.port);
      end else ();*)
      Log.echo ("After cuf_off: " ^ (cut_off_parameters request.Types.link_original));
      add_str (cut_off_parameters request.Types.link_original);

      add_str "\r\n";
    end;
    begin match request.Types.x_forwarded_for with
      None -> ()
    | Some value -> add_str ("X_forwarded_for: " ^ value ^ "\r\n")
    end;
    if request.Types.cookies=[] then ()
    else begin
      add_str "Cookie: ";
      let rec output_c list =
        match list with
          [] -> ()
        | [(param, value)] -> add_str param;
            add_char '=';
            add_str value;
        | (param, value)::ending ->add_str param;
            add_char '=';
            add_str value;
	    add_char ';';
	    add_char ' ';
	    output_c ending; 
      in
      output_c request.Types.cookies;
      add_str "\r\n";
    end;
    if request.Types.data_length > 0 then begin
      add_str "Content-Length: ";
      add_str (string_of_int request.Types.data_length);
      add_str "\r\n"
    end;
    if request.Types.referer<>"" then begin
      add_str "Content-Location: ";
      add_str request.Types.referer;
      add_str "\r\n"
    end;

    if request.Types.keep_alive then add_str "Connection: Keep-Alive\r\n"
    else add_str "Connection: Close\r\n";
    (*Unrecognized params*)
    let iterator (param, value) =
      add_str param;
      add_str ": ";
      add_str value;
      add_str "\r\n" in
    List.iter iterator (List.rev request.Types.unrecognized_params)
  end;
  add_str "\r\n";
  Box_io.write svr_desc (Buffer.contents out_buff);
  Log.echo (Buffer.contents out_buff);
  let more = request.Types.data_length in
  let more = Box_io.output_lexer_len svr_desc cli_lexbuf more in
  Box_io.transfer_len cli_desc svr_desc more buf_opt_ref
;;
