(** Main box program *)
open Unix

let config = Config.create "Box";;

let add_type old_types sie_mod new_type =
  let old_list = try
    Hashtbl.find old_types new_type 
  with
  | Not_found -> []
  in
  Hashtbl.replace old_types new_type (sie_mod::old_list)
;;

let add_types new_types old_types sie_mod =
  List.iter (add_type old_types sie_mod) new_types;
  old_types
;;

let init_module name init (modules, content_types) =
  match init() with
  | Types.Failed(reason) -> 
      Log.error("Could not init " ^ name ^ ": " ^ reason);
      (modules, content_types)
  | Types.Success(sie_mod) ->
      (sie_mod::modules, 
        (add_types sie_mod.Types.supported_content_types content_types sie_mod))
;;

let sort_modules modules =
  let compare sie_mod1 sie_mod2 =
    (sie_mod1.Types.priority_before - sie_mod2.Types.priority_before)
  in
  List.sort compare modules
;;

let sort_handlers handlers =
  let sort_after modules =
    let compare sie_mod1 sie_mod2 =
      (sie_mod1.Types.priority_after - sie_mod2.Types.priority_after)
    in
    List.sort compare modules
  in
  let process_type content_type type_handlers =
    Hashtbl.replace handlers content_type (sort_after type_handlers)
  in
  Hashtbl.iter process_type handlers;
  handlers
;;

let init_modules () =
  let modules = [] in
  let handlers = Hashtbl.create 5 in
  let (modules, handlers) = init_module "Rewriter" Rewriter.init (modules, handlers) in
  let (modules, handlers) = init_module "E_SEE" E_see.init (modules, handlers) in
  let (modules, handlers) = init_module "BetterMaker" LinkAdder.init (modules, handlers) in
  let (modules, handlers) = init_module "Panel" Panel.init (modules, handlers) in
  (sort_modules modules, sort_handlers handlers)
;;

(** [box port] is the box mainloop. Calls Worker.worker. Throws Unix.Unix_error
 *)
(* We ignore Sys.sigpipe since we sometimes want to write an error message to
 * the client after the client has closed the connection.
 *)
let box port use_rb =
  Log.echo ("Box starting...");
  Sys.set_signal Sys.sigpipe Sys.Signal_ignore;
  let addr = ADDR_INET (inet_addr_any, port) in
  let sock = socket PF_INET SOCK_STREAM 0 in
  begin
    try
      setsockopt sock SO_REUSEADDR true;
      bind sock addr;
      listen sock 100;
    with
    | Unix_error (a,_,_) ->
      Log.error ("While trying to bind to port " ^ (string_of_int port) ^ ": " ^ (Unix.error_message a));
      exit 1
  end;
  let (modules, handlers) = init_modules () in
  ignore (Thread.create Session.thread ());
  (* Loop not recursive function becouse we need to create threads *)
  while true do
    let (desc, caller) = accept sock in
    ignore (Thread.create (Worker.worker desc use_rb modules handlers) caller)
  done
;;

let main() =
  flush_all();
  let rb_host = (Config.get config "RB_HOST") in
  let rb_port = try int_of_string (Config.get config "RB_PORT") with _ -> 0 in
  Log.echo ("RB_HOST: '" ^ rb_host ^ "', RB_PORT: '" ^ (string_of_int rb_port) ^ "'");
  let use_rb = (rb_host <> "") in
  if use_rb then begin
    try
      let rb_addr = Utils.resolve_first rb_host rb_port in
      let rb_desc = socket PF_INET SOCK_STREAM 0 in
      connect rb_desc rb_addr;
    with
    | Unix_error _ -> 
        Printf.eprintf "Unable to contact Request Broker at %s:%i\n" rb_host rb_port;
    | Not_found ->
        Printf.eprintf "Unknown hostname %s\n" rb_host;
  end;
  let baseurl = (Config.get config "SIE_BASEURL") in
  let (_, _, port, _, _, _) = Url.parse_URL baseurl in
  ignore (box port use_rb);
;;

main();;
