(** Box input output low level operations *)

(** Read a string from the given desc *)
val read : Unix.file_descr -> 'a -> string

(** Output a string to the given desc *)
val write : Unix.file_descr -> string -> unit

(** Outputs the contents of buffer to given descriptor *)
val write_buf : Unix.file_descr -> Buffer.t -> unit

(** [transfer_data in_desc out_desc buff] Transfers all available data from 
   [in_desc] to [out_desc] using [buff] *)
val transfer_data : Unix.file_descr -> Unix.file_descr -> string -> unit

(** [transfer_len in_desc out_desc len buff_opt_ref] Transfers all available
 data from [in_desc] to [out_desc] using [buff_opt_ref], but at most [len]
 bytes *)
val transfer_len :
  Unix.file_descr -> Unix.file_descr -> int -> string option ref -> unit

(** [transfer_buf_len in_desc buf len buff_opt_ref] Transfers all available
   data from [in_desc] to [buffer] using [buff_opt_ref], but at most [len]
   bytes *)
val transfer_buf_len :
  Unix.file_descr -> Buffer.t -> int -> string option ref -> unit


(** [transfer_nonblocking in_desc out_desc buff] Transfers all available data
from [in_desc] to [out_desc] without blocking the thread *)
val transfer_nonblocking :
  Unix.file_descr -> Unix.file_descr -> string -> unit

(** [output_lexer_len desc lexbuf len] transfers all already read data from 
   [lexbuf] to [desc], but at most [len] bytes *)
val output_lexer_len : Unix.file_descr -> Lexing.lexbuf -> int -> int

(** [buf_lexer_len buf lexbuf len] transfers all already read data from
   [lexbuf] to [buf], but at most [len] bytes *)
val buf_lexer_len : Buffer.t -> Lexing.lexbuf -> int -> int

(** [lexer_of_desc desc] Creates a lexer from descriptor *)
val lexer_of_desc : Unix.file_descr -> Lexing.lexbuf
