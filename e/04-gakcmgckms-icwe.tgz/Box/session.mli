(** Box session manager *)

(** The thread forgeting all unnecessary info *)
val thread : unit -> unit;;

(** Updates the client session information *)
val update_client : Types.request -> unit;;

(** Returns the Hashtable of rewritten client's links for use of link rewriter *)
val get_client_links : Types.request -> (string, string * string * string) Hashtbl.t;;

(** Checks if the request is for a Box internal resource *)
val check_get : Types.request -> Types.response option;;

(** Adds all remembered params for sending them to the server *)
val add_params : Types.request -> unit;;

(** Removes all unnecessary params and remembers them. *)
val remember : Types.request -> (string, string) Hashtbl.t -> unit;;
