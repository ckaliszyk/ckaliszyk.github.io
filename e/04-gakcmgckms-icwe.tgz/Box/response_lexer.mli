val __ocaml_lex_tables : Lexing.lex_tables
val lex_ver : Lexing.lexbuf -> int
val __ocaml_lex_lex_ver_rec : Lexing.lexbuf -> int -> int
val lex_no : Lexing.lexbuf -> int
val __ocaml_lex_lex_no_rec : Lexing.lexbuf -> int -> int
val lex_params : Lexing.lexbuf -> string option
val __ocaml_lex_lex_params_rec : Lexing.lexbuf -> int -> string option
val lex_paramval : Lexing.lexbuf -> string
val __ocaml_lex_lex_paramval_rec : Lexing.lexbuf -> int -> string
val lex_eol : Lexing.lexbuf -> bool
val __ocaml_lex_lex_eol_rec : Lexing.lexbuf -> int -> bool
val lex_equal : Lexing.lexbuf -> bool
val __ocaml_lex_lex_equal_rec : Lexing.lexbuf -> int -> bool
val lex_chunk : Lexing.lexbuf -> string
val __ocaml_lex_lex_chunk_rec : Lexing.lexbuf -> int -> string
val ver_to_string : int -> string
