(** Main box program *)

(** [box port] is the box mainloop. Calls Worker.worker. Throws Unix.Unix_error
 *)
