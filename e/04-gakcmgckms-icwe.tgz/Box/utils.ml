let config = Config.create "Box/utils";;

let is_text_html response =
  let cnt_type =
    try
      let pos = String.index response.Types.content_type ';' in
      String.sub response.Types.content_type 0 pos
    with
      Not_found -> response.Types.content_type
    | _ -> assert false
  in 
  cnt_type = "text/html"
;;

let resolve_first host port = 
  let host = Unix.gethostbyname host in
  let host_addr = host.Unix.h_addr_list.(0) in
  Unix.ADDR_INET(host_addr, port)
;;

let get_svr svr_opt_ref =
  match !svr_opt_ref with
  | None ->
      let desc = Unix.socket Unix.PF_INET Unix.SOCK_STREAM 0 in
      let server = resolve_first
        (Config.get config "SERVER_ADDR")
        (int_of_string (Config.get config "SERVER_PORT"))
      in Unix.connect desc server;
      let lexbuf = Box_io.lexer_of_desc desc in
      svr_opt_ref := Some (desc, lexbuf);
      (desc, lexbuf)
  | Some pair -> pair
;;

let get_ip desc ip = function
  | true ->
      let read_ip = String.create 11 in
      if (Unix.read desc read_ip 0 11) < 11 then
        failwith "Ip get error";
      let convert a b c d = Printf.sprintf "%d.%d.%d.%d" a b c d in
      Scanf.sscanf read_ip "%x %x %x %x" convert
  | false ->
      match ip with
      | Unix.ADDR_UNIX s -> ("Local: " ^ s)
      | Unix.ADDR_INET (ip, port) -> Unix.string_of_inet_addr ip
;;

let get_buf buf_opt_ref =
  match !buf_opt_ref with
  | None -> 
      let ret = String.create 4096 in
      buf_opt_ref := Some ret;
      ret
  | Some buf -> buf
;;
