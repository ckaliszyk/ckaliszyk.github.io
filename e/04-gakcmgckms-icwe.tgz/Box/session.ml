let timeout = 60. *. 1.;; (* 1 min *)

let session_mutex = Mutex.create ();;
let sessions = Hashtbl.create 10;;
  
let new_session lst = 
  (lst, Hashtbl.create 5, "", [])
;;

(* Gets session info for a client who sent the request *)
let get request =
  let cli_no = request.Types.cli_no in
  Mutex.lock session_mutex;
  let ret =
    try Hashtbl.find sessions cli_no
    with Not_found -> 
      let ret = new_session [] in
      Hashtbl.replace sessions cli_no ret;
      ret
  in
  Mutex.unlock session_mutex;
  ret
;;  


(* Alters the session for a client who set the [request] using function [fnctn]
   session = ( , links, , , parameters),
 where
   links - a hashtable with all links the client was using 
              - triple (current_link, a_content, real link) *) 
let set request fnctn =
  Mutex.lock session_mutex;
  let (lst, sth, name, params) =
    try
      Hashtbl.find sessions request.Types.cli_no 
    with
      Not_found -> new_session []
  in
  Hashtbl.replace sessions request.Types.cli_no 
    (fnctn (lst, sth, name, params));
  Mutex.unlock session_mutex;
;;  

let get_client_links request =
  let (_, links, _, _) = get request in
  links
;;

let update_client request =
  let url_to =
    match request.Types.file_params with
    | [] -> request.Types.file
    | lst ->
        let rewrite (param, pval) = param ^ "=" ^ pval in
        let strlist = List.map rewrite lst in
        let rest = String.concat "&" strlist in
        request.Types.file ^ "?" ^ rest
  in
  let url_from = request.Types.from in
  Mutex.lock session_mutex;
  try
    let (lst, sth, name, params) = 
      Hashtbl.find sessions request.Types.cli_no 
    in
    let link_content = request.Types.link_content in
    let new_lst = (Unix.time (), url_from, url_to, link_content) :: lst in
    Hashtbl.replace sessions request.Types.cli_no 
      (new_lst, sth, name, params);
    Mutex.unlock session_mutex
  with Not_found ->
    let new_lst = [Unix.time (), request.Types.from, url_to, ""] in
    let session = (new_session new_lst) in
    Hashtbl.replace sessions request.Types.cli_no session;
    Mutex.unlock session_mutex;
;;

let basic_log
    : (string * string * (float * string * string * string) list) Log.t 
    = Log.create_log "basic.log"
;;

let log_it cli_no (clicks, _, sess_name,  _) =
  Log.log basic_log (cli_no, sess_name, List.rev clicks);
;;

let test_timeouts () =
  let timed = ref [] in
  let test_client_timeout cli_no ((clicks, _, _, _) as session) =
    try
      let (time, _, _, _) = List.hd clicks in
      if Unix.time () -. time < timeout then () else
      timed := (cli_no, session) :: !timed
    with
      _ -> () (*Failure hd *)
  in
  let restart_client (cli_no, session) =
    log_it cli_no session;
    Hashtbl.remove sessions cli_no
  in
  Mutex.lock session_mutex;
  timed := [];
  Hashtbl.iter test_client_timeout sessions;
  List.iter restart_client !timed;
  Mutex.unlock session_mutex
;;

let rec thread () =
  Unix.sleep 60;
  test_timeouts ();
  thread ()
;;

open Types;;

let wtl_of_lst lst =
  Random.self_init ();
  let oldtime = ref 0. in
  let mapper (time, from, url_to, content) =
    let click_str = Printf.sprintf 
        "(* from '%s' to '%s' *)\nclick \"%s\";\n\n" from url_to content
    in
    let ntime = time -. !oldtime +. (Random.float 1.0) in
    let delay_str =
      if !oldtime = 0. then "" else Printf.sprintf "delay %.2f;\n" ntime 
    in
    oldtime := time;
    if content = "" then "" else delay_str ^ click_str
  in
  match lst with
  | [] -> "(* Empty session *)\n"
  | (_,_,start,_) :: tail ->
      let start_line = "(* goto \"http://your_host" ^ start ^ "\" *)\n" in
      start_line ^ (String.concat "" (List.map mapper tail))
;;
  
(* FIXME: This function should be moved to Wtl module *)
let check_get request =
  match request.Types.file with
  | "/uuu_session_restart" ->
      let replace _ = new_session [] in
      set request replace; 
      let response = { 
        server_ver = 0;
        status_code = 200;
        status_phrase = "OK";
        set_cookie = "";
        content_encoding = Identity;
        transfer_coding = Normal;
        content_language = "pl";
        content_length = 0;
        html_tree = [Nethtml.Data "<html><body>ok</body></html>"];
        response_params = [];
        panel = Nethtml.Data "";
        content_type = "text/html";
        server_keep_alive = false;
        location = "";
        content_location = "";
      } in
      Some(response)
  | "/uuu_session_get" ->
      let (lst, _, _, _) = get request in
      let response = { 
        server_ver = 0;
        status_code = 200;
        status_phrase = "OK";
        set_cookie = "";
        content_encoding = Identity;
        transfer_coding = Normal;
        content_language = "pl";
        content_length = 0;
        html_tree = [Nethtml.Data (wtl_of_lst (List.rev lst))];
        response_params = [];
        panel = Nethtml.Data "";
        content_type = "binary/octet";
        server_keep_alive = false;
        location = "";
        content_location = "";

      } in
      Some(response)
  | _ -> None
;;

let add_params request =
  let (_, _, _, params) = get request in
  request.Types.file_params <- params @ request.Types.file_params
;;

let remember request hash =
  let folder param aval lst = (param, aval) :: lst in
  let removed = Hashtbl.fold folder hash [] in
  let replace (a, b, c, _) = (a, b, c, removed) in
  set request replace
;;
