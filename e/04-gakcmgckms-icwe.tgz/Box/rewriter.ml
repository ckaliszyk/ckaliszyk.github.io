(** Rewriting links in HTTP document
  
  @author Grzegorz Andruszkiewicz, Cezary Kaliszyk
*)

(* Get names for http parameters from the config system *) 

let config = Config.create "Box/rewriter";;

let sie_link = Config.get config "PARAM_LINK"
and sie_session = Config.get config "PARAM_SESSION"
and sie_original = Config.get config "PARAM_ORIGINAL"
and sie_baseurl = Config.get config "SIE_BASEURL"
;;

let added_params = [
  (Config.get config "PARAM_LINK");
  (Config.get config "PARAM_SESSION");
  (Config.get config "PARAM_ORIGINAL");
];;

let is_added_param param =
  List.mem param added_params 
;;

(* Get session/client id - currently just client no*)
let session_id request = request.Types.cli_no
;;

(* FIXME make it correct *)
let is_url_handled url = Panel.is_url_handled url
;;

let set_cli_no request response =
  response.Types.set_cookie <- session_id request
;;

let random_word i =
  let ret = String.create i in
  for i = 0 to i - 1 do
    let ent = Random.int 36 in
    let set = if ent < 10 then Char.chr (48 + ent) else Char.chr (55 + ent) in
    ret.[i] <- set
  done;
  ret
;;

let remember_params = Hashtbl.create 10;;
Hashtbl.replace remember_params "SID" ();;
Hashtbl.replace remember_params "PHPSESSID" ();;
Hashtbl.replace remember_params "JSESSIONID" ();;

(** Make a link a full URL (including http://servername*)
(*FIXME add link base *)
let make_full_url link link_to_this_page =
  (*Log.echo ("Link = " ^ link ^ ", this_page = " ^ link_to_this_page);*)
  let without_params = try 
    let i = String.index link '?' 
      in String.sub link 0 i
    with Not_found -> link
  in let regexp = Str.regexp_string "://" in 
  if (try ignore (Str.search_forward regexp without_params 0) ; true
              with Not_found -> false) 
  then link (*an absolute link *)
  else let link = if (String.length link) > 0 && link.[0]='/' then
                   String.sub link 1 ((String.length link)-1)
                  else link
  in (Url.get_baselocation link_to_this_page) ^ link 
;;

(*
  Log.echo ("Link = " ^ link ^ ", this_page = " ^ link_to_this_page);
  let without_params = try 
    let i = String.index link '?' 
      in String.sub link 0 i
    with Not_found -> link
  in let regexp = Str.regexp_string "://" in 
  if (try ignore (Str.search_forward regexp without_params 0) ; true
              with Not_found -> false) 
  then link
  else try let found = String.rindex link_to_this_page '/' 
             in (String.sub link_to_this_page 0 (found+1)) ^ link
       with Not_found -> (link_to_this_page ^ "/" ^ link)
;;
*)

(** Sets links
  Parameters
    hasz - 
    new_link - session_id (FIXME losowy klucz do hasztabelki)
    links - a hashtable containing all links visited by client (contained in a
            session) 
    a_content - the content of used <a> tag
    old_link - the string that was in "href" attribute of the <a> tag 
*)

let set_magic_link hasz request a_content old_href =
  let old_link = if (not (is_url_handled old_href)) then
                        make_full_url old_href request.Types.link_original 
               else (*if request.Types.is_internal_page then*)
                    request.Types.link_original
  in let _ = request.Types.referer <- request.Types.link_original
  (* in let source_page = 
    match request.Types.file_params with
    | [] -> request.Types.file
    | lst ->
        let rewrite (param, pval) = param ^ "=" ^ pval in
        let strlist = List.map rewrite lst in
        let rest = String.concat "&" strlist in
        request.Types.file ^ "?" ^ rest *)
  in let source_page = Url.deparse_URL (request.Types.protocol,
                                        request.Types.host,
                                        request.Types.port,
                                        request.Types.file,
                                        request.Types.file_params,
                                        request.Types.label) in
  let (protocol, _, _, path, params, label) = 
     Url.parse_URL (make_full_url old_href request.Types.link_original) in
  let filter (str, _) = Hashtbl.mem remember_params str in
  let remember = (List.filter filter params) in
  let iterator (param, aval) = Hashtbl.replace hasz param aval in
  let _ = List.iter iterator remember in

  let new_file = random_word 16 in
  let links = Session.get_client_links request in
  let _ = Hashtbl.replace links new_file (source_page, a_content, old_link) in
                             (* FIXME - the first element was source_page *)
  let filter (str, _) = not (Hashtbl.mem remember_params str) in
  let params = (List.filter filter params) in
  let ses_id = session_id request in
  let params = (sie_session, ses_id) :: params in
  let params = (sie_link, new_file) :: params in
  (* We will use the sie_original parameter to store the information from which
     page our internal page was clicked *)
  let params =  (sie_original, old_link) :: params in              
  let (_, basehost, baseport, _, _, _) = Url.parse_URL sie_baseurl in
  (*let _ = Log.echo (string_of_int baseport) in*)
      Url.deparse_URL (protocol, basehost, baseport, path, params, label)
;;

let remove_params request =
  let filter (str, _) = not (Hashtbl.mem remember_params str) in
  request.Types.file_params <- List.filter filter request.Types.file_params;
;;

(* TODO any other tags may contain links? *)
let set_magic_links request response =
  let hasz = Hashtbl.create 3 in
  let new_location = if response.Types.location="" then ""
                     else if request.Types.is_internal_page then
                       response.Types.location
                     else set_magic_link hasz request "" response.Types.location
  in let new_content_location = if response.Types.content_location="" then ""
                     else set_magic_link hasz request "" response.Types.content_location
  in let mapper a_content find (aname, aval) =
    if aname <> find then (aname, aval) else
    aname, (set_magic_link hasz request a_content aval)
  in
  let rec search_and_replace_links = function
    | Nethtml.Data s -> Nethtml.Data s
    | Nethtml.Element("a", atts, subdocs) ->
        let abuf = Buffer.create 20 in
        Nethtml.write (Buffer.add_string abuf) subdocs;
        let a_content = Buffer.contents abuf in
        let atts' = List.map (mapper a_content "href") atts in
        Nethtml.Element("a", atts', subdocs)
    | Nethtml.Element("form", atts, subdocs) ->
        let atts' = List.map (mapper "" "action") atts in
        let subdocs' = List.map search_and_replace_links subdocs in
        Nethtml.Element("form", atts', subdocs')
    | Nethtml.Element(name, atts, subdocs) -> 
        let subdocs' = List.map search_and_replace_links subdocs in
        Nethtml.Element(name, atts, subdocs')
  in 
  let rewriten_html = 
    List.map search_and_replace_links response.Types.html_tree 
  in
  let _ = response.Types.html_tree <- rewriten_html in
  let _ = response.Types.location <- new_location in
  let _ = response.Types.content_location <- new_content_location in
  Session.remember request hasz
;;

(* This function modifies the request object:
   - sets the client number, from (rewritten link), link_content and gives a new
number to client if she hasn't got one *)
let get_real_link request =
  begin try 
    let client_no = List.assoc sie_session request.Types.file_params in
    (*let (source_page, client_no) = Hashtbl.find magic_links link in*)
    
    let current = List.assoc sie_link request.Types.file_params in
    let links = Session.get_client_links request in
    let (source_page, a_cnt, old_link) = 
      try Hashtbl.find links current
      with Not_found -> ("", "", try List.assoc sie_original request.Types.file_params
                                 with Not_found -> "")
    in
    request.Types.from <- source_page;
    request.Types.cli_no <- client_no;
    request.Types.link_original <- old_link;
    request.Types.link_content <- if a_cnt = "" then old_link else a_cnt;
      (*FIXME checking if url is handled should be done nicer *)
    if is_url_handled request.Types.file then request.Types.is_internal_page <- true;
  with 
    Not_found -> 
      if request.Types.cli_no = ""
      then request.Types.cli_no <- random_word 16
  end;
  let (sie_params, other_params) = 
    List.partition (fun (name, value) -> is_added_param name) request.Types.file_params in
  request.Types.file_params <- other_params;
  request.Types.sie_params <- sie_params;

  Log.echo ("GRZES: link_original = " ^ request.Types.link_original);
  None
;;

let init()  = 
  try 
    let sie_mod = {
      Types.name = "Rewriter";
      Types.supported_content_types = ["text/html"];
      Types.needs_html_tree = true;
      Types.priority_before = (int_of_string (Config.get config "REWRITER_PRIORITY_BEFORE"));
      Types.before = get_real_link;
      Types.priority_after = (int_of_string (Config.get config "REWRITER_PRIORITY_AFTER"));
      Types.after = set_magic_links;
      Types.session_ended = (fun _ -> ());
    } in Types.Success(sie_mod)
  with
  | Failure (reason) -> 
      Types.Failed(reason)
;;
