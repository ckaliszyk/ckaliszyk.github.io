{
}

(* TODO sprawdzi� w RFC jakie inne znaki *)
let skip = [' ' '\t']+
let eol  = '\r'?'\n'
let paramname = [^':''\n''\r']+
let paramval = [^'\n''\r']+
let file = [^' ''\t']+

rule lex_ver = parse
| skip            {lex_real_ver lexbuf}
| eol             {9}
| eof             {9}

and lex_real_ver = parse
| "HTTP/1.1" eol  {11}
| "HTTP/1.0" eol  {10}

and lex_method = parse
| "GET"     skip {Types.Mthd_get}
| "HEAD"    skip {Types.Mthd_head}
| "PUT"     skip {Types.Mthd_put}
| "POST"    skip {Types.Mthd_post}
| "OPTIONS" skip {Types.Mthd_options}
| "DELETE"  skip {Types.Mthd_delete}
| "TRACE"   skip {Types.Mthd_trace}
| "CONNECT" skip {Types.Mthd_connect}

and lex_file = parse
| file           {Lexing.lexeme lexbuf}

and lex_params = parse
| eol            {None}
| eof            {None}
| paramname      {Some(Lexing.lexeme lexbuf)}

and lex_paramval = parse
| paramval      {Lexing.lexeme lexbuf}

and lex_eol = parse
| eol            {true}

and lex_equal = parse
| ':' skip?            {true}

{

let mthd_to_string = function
  | Types.Mthd_get -> "GET"
  | Types.Mthd_head -> "HEAD"
  | Types.Mthd_put -> "PUT"
  | Types.Mthd_post -> "POST"
  | Types.Mthd_options -> "OPTIONS"
  | Types.Mthd_delete -> "DELETE"
  | Types.Mthd_trace -> "TRACE"
  | Types.Mthd_connect -> "CONNECT"
;;

let ver_to_string = function
  | 10 -> "HTTP/1.0\r\n"
  | 11 -> "HTTP/1.1\r\n"
  | _ -> "\r\n"
;;
  
}
