let get_response request cli_desc cli_lexbuf svr_opt_ref buf_opt_ref =
  let svr_desc, svr_lexbuf = Utils.get_svr svr_opt_ref in
  Session.add_params request;
  Request.output svr_desc request cli_lexbuf cli_desc buf_opt_ref;
  Rewriter.remove_params request;
  Response.parse_headers svr_lexbuf svr_desc buf_opt_ref
;;

let before_server request modules =
  Log.echo "before_server";
  let handler old_resp sie_mod =
    let resp = match old_resp with
    | Some(resp) -> begin
      Log.echo "Some response, passing";
      Some(resp)
    end
    | None -> begin
      Log.echo ("No response, calling " ^ sie_mod.Types.name);
      sie_mod.Types.before request
    end;
    in
    resp
  in
  List.fold_left handler None modules
;;

let after_server request response handlers =
  Log.echo "after_server";
  let content_type = response.Types.content_type in
  let semicolon = 
    try 
      String.index content_type ';'
    with
    | Not_found -> String.length content_type
  in
  let content_type = String.sub content_type 0 semicolon in
  Log.echo ("Content-Type: " ^ content_type);
  let modules = try
    Hashtbl.find handlers content_type
  with
  | Not_found -> []
  in
  List.iter (fun sie_mod -> sie_mod.Types.after request response) modules
;;

let process_request cli_desc cli_lex cli_ip ser_opt_ref buf_opt_ref modules type_handlers =
  let request = Request.input cli_lex cli_ip in

  (*
  Rewriter.get_real_link request;
  Panel.before_server request;
  E_see.e_see request;
  Session.check_get request;
  *)
  let response =
    match before_server request modules with
    | Some response -> response
    | None -> get_response request cli_desc cli_lex ser_opt_ref buf_opt_ref
  in
  (* FIXME: Make it more intelligent in updating session *)
  if Utils.is_text_html response then
    Session.update_client request;
    
  (*
  LinkAdder.addLinks request response;
  Rewriter.set_magic_links request response;
  *)
  after_server request response type_handlers;
  
  response.Types.set_cookie <- request.Types.cli_no;
  Response.output cli_desc request response ser_opt_ref buf_opt_ref
;;
  
let worker cli_desc use_rb_ip modules type_handlers ip =
  begin
    try
      Log.echo "worker start";
      let cli_ip = Utils.get_ip cli_desc ip use_rb_ip
      and ser_opt_ref = ref None
      and buf_opt_ref = ref None
      and cli_lexbuf = Box_io.lexer_of_desc cli_desc in
      Log.echo "before req_prc";
      let rec req_prc () =
        Log.echo "req_prc";
        process_request cli_desc cli_lexbuf cli_ip ser_opt_ref buf_opt_ref modules type_handlers;
        ()(*req_prc ()*)
      in
      req_prc ();
      match !ser_opt_ref with
      | None -> ()
      | Some (desc, _) -> Unix.close desc; ()
    with
      Request.Error -> Log.echo "Bad request"
    | Response.Error -> Log.echo "Bad response"
    | Failure str -> Log.echo ("Failure: " ^ str)
    | Unix.Unix_error (Unix.EPIPE, _, _) -> Log.echo "Client has disconnected"
    | Unix.Unix_error (Unix.ECONNREFUSED, _, _) -> 
        Log.echo "Cannot Connect to server"
    | Unix.Unix_error (a, _, _) -> Log.echo (Unix.error_message a)
    | Exit -> ()
  end;
  Log.echo "Done";
  Unix.close cli_desc
;;
