(** Box input output low level operations *)

let rec do_read desc buff pos len =
  try Unix.read desc buff pos len with
    Unix.Unix_error (Unix.EINTR, _, _) -> do_read desc buff pos len
;;

let rec do_write desc buff pos len =
  try Unix.write desc buff pos len with
    Unix.Unix_error (Unix.EINTR, _, _) -> do_write desc buff pos len
;;

(** Read a string from the given desc *)
let read desc buff =
  let in_buff = Buffer.create 4096 in
  let buff = String.create 4096 in
  let rec reader () =
    let len = do_read desc buff 0 4096 in
    if len = 0 then Buffer.contents in_buff
    else begin Buffer.add_substring in_buff buff 0 len; reader () end
  in
  reader ()
;;

(** Output a string to the given desc *)
let write desc str =
  let str_len = String.length str in
  if str_len = 0 then () else
  let rec writer pos len =
    let written = do_write desc str pos len in
    if written < len then writer (pos + written) (len - written)
  in
  writer 0 str_len
;;

(*TODO*)
(** Outputs the contents of buffer to given descriptor *)
let write_buf desc buf =
  let str_len = Buffer.length buf
  and str = Buffer.contents buf in
  let rec writer pos len =
    let written = do_write desc str pos len in
    if written < len then writer (pos + written) (len - written)
  in
  writer 0 str_len
;;

(** [transfer_data in_desc out_desc buff] Transfers all available data from
   [in_desc] to [out_desc] using [buff] *)
let transfer_data in_desc out_desc buff =
  let buff_len = String.length buff in
  let rec transfer_write len pos =
    let len_wr = do_write out_desc buff pos len in
    if len_wr = 0 then failwith "Unable to send";
    if len_wr < len then transfer_write (len - len_wr) (pos + len_wr)
  in
  let rec transfer_read () =
    let len = do_read in_desc buff 0 buff_len in
    if len > 0 then begin transfer_write len 0; transfer_read () end
  in
  transfer_read ()
;;

(** [transfer_len in_desc out_desc len buff_opt_ref] Transfers all available
   data from [in_desc] to [out_desc] using [buff_opt_ref], but at most [len]
   bytes *)
let transfer_len in_desc out_desc len buf_opt_ref =
  if len = 0 then () else
  let buff = 
    match !buf_opt_ref with
    | None ->
        let ret = String.create 4096 in
        buf_opt_ref := Some ret;
        ret
    | Some buf -> buf
  in
  let buff_len = String.length buff in
  let rec transfer_write len pos =
    let len_wr = do_write out_desc buff pos len in
    if len_wr = 0 then failwith "Unable to send";
    if len_wr < len then transfer_write (len - len_wr) (pos + len_wr)
  in
  let rec transfer_read more =
    let len = do_read in_desc buff 0 (min buff_len more) in
    if len > 0 then begin 
      transfer_write len 0; 
      if more - len > 0 then
        transfer_read (more - len)
    end
  in
  transfer_read len
;;

(** [transfer_buf_len in_desc buf len buff_opt_ref] Transfers all available
   data from [in_desc] to [buffer] using [buff_opt_ref], but at most [len]
   bytes *)
let transfer_buf_len in_desc buf len buf_opt_ref =
  if len = 0 then () else
  let buff = 
    match !buf_opt_ref with
    | None ->
        let ret = String.create 4096 in
        buf_opt_ref := Some ret;
        ret
    | Some buf -> buf
  in
  let buff_len = String.length buff in
  let rec transfer_write len =
    Buffer.add_substring buf buff 0 len
  in
  let rec transfer_read more =
    let len = do_read in_desc buff 0 (min buff_len more) in
    if len > 0 then begin 
      transfer_write len; 
      if more - len > 0 then
        transfer_read (more - len)
    end
  in
  transfer_read len
;;

(** [transfer_nonblocking in_desc out_desc buff] Transfers all available
   data from [in_desc] to [out_desc] without blocking *)
let transfer_nonblocking src dst buff =
  Unix.set_nonblock src;
  let buff_len = String.length buff in
  let rec transfer () =
    try
      let len = Unix.read src buff 0 buff_len in
      ignore (Unix.write dst buff 0 len);
      transfer ()
    with
      _ -> ()
  in transfer ()
;;

(* TODO jak nixzej *)
(** [output_lexer_len desc lexbuf len] transfers all already read data from 
   [lexbuf] to [desc], but at most [len] bytes *)
let output_lexer_len desc lexbuf len =
  if len = 0 then 0 else
  let lexstr = lexbuf.Lexing.lex_buffer
  and lexbeg = lexbuf.Lexing.lex_curr_pos in
  let lexlen = lexbuf.Lexing.lex_buffer_len - lexbeg in
  let str, more = 
    if lexlen >= len then (String.sub lexstr lexbeg len, 0)
    else (String.sub lexstr lexbeg lexlen, len - lexlen)
  in
  write desc str;
  lexbuf.Lexing.lex_curr_pos <- lexbuf.Lexing.lex_buffer_len;
  lexbuf.Lexing.lex_last_action <- 0;
  more
;;

(** [buf_lexer_len buf lexbuf len] transfers all already read data from 
   [lexbuf] to [buf], but at most [len] bytes *)
let buf_lexer_len buf lexbuf len =
  if len = 0 then 0 else
  let lexstr = lexbuf.Lexing.lex_buffer
  and lexbeg = lexbuf.Lexing.lex_curr_pos in
  let lexlen = lexbuf.Lexing.lex_buffer_len - lexbeg in
  lexbuf.Lexing.lex_last_action <- 0;
  if lexlen >= len then begin
    lexbuf.Lexing.lex_curr_pos <- lexbuf.Lexing.lex_curr_pos + len;
    Buffer.add_string buf (String.sub lexstr lexbeg len);
    0
  end else begin
    lexbuf.Lexing.lex_curr_pos <- lexbuf.Lexing.lex_buffer_len;
    Buffer.add_string buf (String.sub lexstr lexbeg lexlen);
    len - lexlen
  end
;;


open Lexing;;
(** [lexer_of_desc desc] Creates a lexer from descriptor *)
(* TODO efektywniejsze z doczytaniem nie na pocz�tek jakos tak:
  let buff_len = 4096 in
  let buff = String.create buff_len in
    {refill_buff = (fun lexbuf -> lexbuf.lex_eof_reached <- true);
    lex_buffer = buff; lex_buffer_len = len; lex_abs_pos = 0;
    lex_start_pos = 0; lex_curr_pos = 0; lex_last_pos = 0;
    lex_last_action = 0; lex_eof_reached = true}*)
let lexer_of_desc desc =
  let fnctn buf n =
    let len = Unix.read desc buf 0 n in
(*    Log.echo (String.sub buf 0 len);*)
    len 
  in
  Lexing.from_function fnctn
;;
