val __ocaml_lex_tables : Lexing.lex_tables
val lex_ver : Lexing.lexbuf -> int
val __ocaml_lex_lex_ver_rec : Lexing.lexbuf -> int -> int
val lex_real_ver : Lexing.lexbuf -> int
val __ocaml_lex_lex_real_ver_rec : Lexing.lexbuf -> int -> int
val lex_method : Lexing.lexbuf -> Types.mthd_type
val __ocaml_lex_lex_method_rec : Lexing.lexbuf -> int -> Types.mthd_type
val lex_file : Lexing.lexbuf -> string
val __ocaml_lex_lex_file_rec : Lexing.lexbuf -> int -> string
val lex_params : Lexing.lexbuf -> string option
val __ocaml_lex_lex_params_rec : Lexing.lexbuf -> int -> string option
val lex_paramval : Lexing.lexbuf -> string
val __ocaml_lex_lex_paramval_rec : Lexing.lexbuf -> int -> string
val lex_eol : Lexing.lexbuf -> bool
val __ocaml_lex_lex_eol_rec : Lexing.lexbuf -> int -> bool
val lex_equal : Lexing.lexbuf -> bool
val __ocaml_lex_lex_equal_rec : Lexing.lexbuf -> int -> bool
val mthd_to_string : Types.mthd_type -> string
val ver_to_string : int -> string
