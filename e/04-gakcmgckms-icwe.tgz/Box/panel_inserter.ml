(* Nigdzie nie moglem znalezc egg-interface'u, wiec na razie jest tak: *)

(*exception Body_missing;;*)

(*let rec insert_html panel = function
  | node::t -> begin
      try (insert_aux panel node)::t with
      |	Body_missing -> node::(insert_html panel t) end
  | [] -> raise Body_missing
and insert_aux panel = function
  | Nethtml.Element ("body", args, subnodes) ->
      Nethtml.Element ("body", args, panel::subnodes)
  | Nethtml.Element (name, args, subnodes) ->
      Nethtml.Element (name, args, insert_html panel subnodes)
  | Nethtml.Data _ -> raise Body_missing
;;*)

let rec insert panel = function
  | Nethtml.Element ("body", args, subnodes) ->
      Nethtml.Element ("body", args, panel::subnodes)
  | Nethtml.Element (name, args, subnodes) ->
      Nethtml.Element (name, args, List.map (insert panel) subnodes)
  | data -> data
;;

let insert_panel response =
  let parsed = response.Types.html_tree in
  let mapper elem = (insert response.Types.panel elem) in
  let panelized = List.map mapper parsed in
  response.Types.html_tree <- panelized
;;

(*  let panel_lenbuf = Buffer.create 20 in
  Nethtml.write (Buffer.add_string panel_lenbuf) [panel_elem];
  if response.Types.content_length > 0 then
    response.Types.content_length <-
      response.Types.content_length + (Buffer.length panel_lenbuf);*)


