{
}

let l = [^ '\n' '\r' ]
let eol  = '\r'?'\n'
let skip = [' ' '\t']+
let paramname = [^':''\n''\r']+
let paramval = [^'\n''\r']+
let hex = ['a'-'f' 'A'-'F' '0'-'9']

rule lex_ver = parse
| "HTTP/1.1" skip {11}
| "HTTP/1.0" skip {10}

and lex_no = parse
| ['0' - '9']+ {int_of_string (Lexing.lexeme lexbuf)}

and lex_params = parse
| eol            {None}
| eof            {None}
| paramname      {Some(Lexing.lexeme lexbuf)}

and lex_paramval = parse
| paramval      {Lexing.lexeme lexbuf}

and lex_eol = parse
| ' '?eol            {true}

and lex_equal = parse
| ':' skip?       {true}

and lex_chunk = parse
| hex+           {Lexing.lexeme lexbuf}

{

let ver_to_string = function
  | 11 -> "HTTP/1.1 "
  | _ -> "HTTP/1.0 "
;;

}
