BYTECODE = NO
PROFILE = NO

ifeq ($(BYTECODE),NO)
  OCAML_COMP=ocamlopt.opt -I out ${OINCLUDES} -thread
  OBJ_SUF=cmx
  LIB_SUF=cmxa
else
  ifeq ($(PROFILE),YES)
    OCAML_COMP=ocamlcp -p a -I out ${OINCLUDES}
  else
    OCAML_COMP=ocamlc -I out ${OINCLUDES} -thread
  endif
  OBJ_SUF=cmo
  LIB_SUF=cma
endif

