(** Request Broker I/O functions *)

(** [do_read desc buff buff_size] reads up to [buff_size] from [desc] to [buff]
   @return number of rewriten bytes. *)
val do_read : Unix.file_descr -> string -> int -> int;;

(** [do_write desc buff len] writes up to [len] bytes from [buff] to [desc] *)
val do_write : Unix.file_descr -> string -> int -> unit;;

(** [do_rewrite desc_in desc_out] rewrites data from [desc_in] to [desc_out].
   @return number of rewriten bytes. *)
val do_rewrite : Unix.file_descr -> Unix.file_descr -> int;;

(** [do_server_socket port] creates a TCP socket which will be used to accept
   new connections *)
val do_server_socket : int -> Unix.file_descr;;

