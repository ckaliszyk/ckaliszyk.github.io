DIR:=RequestBroker
TARGET:=RequestBroker
FILES:=io requestBroker
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Config/config.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} unix.$(LIB_SUF) threads.$(LIB_SUF) str.$(LIB_SUF) -o $@ $^
