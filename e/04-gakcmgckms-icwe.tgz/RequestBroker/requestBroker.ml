open ThreadUnix;;

let box_timeout = 3.0;; (* Box timeout param *)
let real_svr_addr = Unix.ADDR_INET (Unix.inet_addr_of_string "193.0.96.2", 80);;

let client_number_to_box = Hashtbl.create 1024;;
let box_addr_list = ref [];;
let rb_lock = Mutex.create ();;

let new_box_for_client () =
  let random_box = Random.int (List.length !box_addr_list) in
  let box_addr = List.nth !box_addr_list random_box in
  box_addr
;;

let find_box_for_client_number client_number =
  Mutex.lock rb_lock;
  try
    let box_addr = Hashtbl.find client_number_to_box client_number in
    Mutex.unlock rb_lock;
    box_addr
  with
  | Not_found ->
    Mutex.unlock rb_lock;
    let box_addr = new_box_for_client() in
    box_addr
;;

let set_box_for_client_number client_number box_addr =
  Mutex.lock rb_lock;
  Hashtbl.replace client_number_to_box client_number box_addr;
  Mutex.unlock rb_lock
;;

let get_client_number_from_http http_header str c_end =
  try
    let pos = Str.search_forward (Str.regexp_string str) http_header 0 in
    let str_len = String.length str in
    let pos2 = String.index_from http_header (pos+str_len) c_end in
    String.sub http_header (pos + str_len) (pos2-pos-str_len)
  with
  | Not_found -> ""
;;

let find_box_for_client http_header =
  let client_no = get_client_number_from_http http_header "\r\nCookie: UUUCEKRULEZZPP=" '\r' in
  if client_no = "" then begin
    let client_no = get_client_number_from_http http_header "&uuu_clino=" '&' in
    if client_no = "" then
      new_box_for_client ()
    else
      find_box_for_client_number client_no
  end else
    find_box_for_client_number client_no
;;

let set_box_for_client http_header box_addr =
  let client_no = get_client_number_from_http http_header "\r\nSet-Cookie: UUUCEKRULEZZPP=" '\r' in
  if client_no = "" then begin
    let client_no = get_client_number_from_http http_header "&uuu_clino=" '&' in
    if client_no = "" then
      ()
    else
      set_box_for_client_number client_no box_addr
  end else
    set_box_for_client_number client_no box_addr
;;


let add_new_client (client_sock, client_addr_host) =
  Unix.set_nonblock client_sock;
  if select [client_sock] [] [client_sock] 3.0 = ([], [], []) then Thread.exit ();
  let buf = String.create 1024 in
  let buf_len = Io.do_read client_sock buf 1024 in
  Printf.printf "%i\n" buf_len;
  flush stdout;
  let box_addr = find_box_for_client buf
  and box_sock = socket Unix.PF_INET Unix.SOCK_STREAM 0 in
  connect box_sock box_addr;
  Unix.set_nonblock box_sock;
  let string_ip = Unix.string_of_inet_addr client_addr_host in
  let convert a b c d = Printf.sprintf "%.2x %.2x %.2x %.2x" a b c d in
  let send_ip = Scanf.sscanf string_ip "%d.%d.%d.%d" convert in
  Io.do_write box_sock send_ip 11;
  Io.do_write box_sock buf buf_len;
  (* WATCHDOG *)
  let box_sock =
    if select [box_sock] [] [box_sock] box_timeout <> ([], [], []) then begin
      let buf_len = Io.do_read box_sock buf 1024 in
      set_box_for_client buf box_addr;
      Io.do_write client_sock buf buf_len;
      box_sock
    end else begin
      let real_svr_sock = socket Unix.PF_INET Unix.SOCK_STREAM 0 in
      connect real_svr_sock real_svr_addr;
      Unix.set_nonblock real_svr_sock;
      Io.do_write real_svr_sock buf buf_len;
      real_svr_sock
    end
  in
  (* /WATCHDOG *)
  let socks = [client_sock; box_sock] in
  let rec rewrite_loop () =
    let (ready_sock, _, error_sock) = select socks [] socks (-1.0) in
    match error_sock with
    | [] -> 
      begin match ready_sock with
      | sock :: _ ->
        if sock = client_sock then begin
	  let rewrite_count = Io.do_rewrite client_sock box_sock in
          if rewrite_count > 0 then rewrite_loop ();
        end else begin
  	  let rewrite_count = Io.do_rewrite box_sock client_sock in
          if rewrite_count > 0 then rewrite_loop ();
	end
      | [] -> ()
      end
    | _ :: _ -> ()
  in
  rewrite_loop ();
  Unix.close client_sock;
  Unix.close box_sock;
  Thread.exit ()
;;

let add_new_client_check param =
  try
    add_new_client param
  with
  | Unix.Unix_error (Unix.EPIPE, _, _) -> Thread.exit () (* Client disconnected *)
  | Unix.Unix_error (Unix.ECONNREFUSED, _, _) -> 
      print_endline "Cannot connect to server"; flush stdout; Thread.exit ()
;;

let add_new_box box_sock box_connect_port =
  let (new_sock, box_addr) = accept box_sock in
  Unix.close new_sock;
  match box_addr with
  | Unix.ADDR_INET (box_addr_host, _) ->
      Mutex.lock rb_lock;
      box_addr_list :=
        Unix.ADDR_INET (box_addr_host, box_connect_port) :: !box_addr_list;
      Mutex.unlock rb_lock
  | _ -> ()
;;

  
let request_broker client_accept_port box_accept_port box_connect_port =
  (* first wait for any box *)
  let box_sock = Io.do_server_socket box_accept_port in
  add_new_box box_sock box_connect_port;
  let client_sock = Io.do_server_socket client_accept_port in
  let rec loop () =
    let socks = [client_sock; box_sock] in
    let (ready_sock, _, _) = select socks [] [] (-1.0) in
    begin match ready_sock with
    | sock :: _ ->
        if sock = client_sock then begin
          let (new_sock, client_addr) = accept client_sock in
          begin match client_addr with
          | Unix.ADDR_INET (client_addr_host, _) ->
              ignore 
                (Thread.create add_new_client_check (new_sock, client_addr_host))
          | _ -> ()
	  end
        end else if sock = box_sock then begin
          add_new_box box_sock box_connect_port
        end
    | _ -> ()
    end;
    loop ()
  in
  loop ()
;;

(* Start request_broker on given ports *)
let _ = ignore (request_broker 8040 2536 8080);;
