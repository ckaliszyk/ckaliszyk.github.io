open ThreadUnix

let do_read desc buff buff_size =
  let rec real_read pos len =
    try read desc buff pos len with
      Unix.Unix_error (Unix.EINTR, _, _) -> real_read pos len
    | Unix.Unix_error (Unix.EAGAIN, _, _) -> 0
    | Unix.Unix_error (Unix.EWOULDBLOCK, _, _) -> 0
    | End_of_file -> 0
  in
  let rec read_all pos len =
    let count = real_read pos len in
    if count > 0 then read_all (pos + count) (len - count)
    else (buff_size - len)
  in
  read_all 0 buff_size
;;

let do_write desc buff len =
  let rec real_write pos len =
    try write desc buff pos len with
      Unix.Unix_error (Unix.EINTR, _, _) -> real_write pos len
    | Unix.Unix_error (Unix.EAGAIN, _, _) -> 0
    | Unix.Unix_error (Unix.EWOULDBLOCK, _, _) -> 0
    | End_of_file -> 0
  in
  let rec write_all pos len =
    let count = real_write pos len in
    if count > 0 && count < len then write_all (pos + count) (len - count)
  in
  write_all 0 len
;;

let do_rewrite desc_in desc_out =
  let buff = String.create 4096 in
  let rec real_rewrite count =
    let len = do_read desc_in buff 4096 in
    if len > 0 then begin
      do_write desc_out buff len;
      real_rewrite (len + count)
    end else
      count
  in
  real_rewrite 0
;;

let do_server_socket port =
  Sys.set_signal Sys.sigpipe Sys.Signal_ignore;
  let addr = Unix.ADDR_INET (Unix.inet_addr_any, port)
  and sock = socket Unix.PF_INET Unix.SOCK_STREAM 0 in
  Unix.setsockopt sock Unix.SO_REUSEADDR true;
  Unix.bind sock addr;
  Unix.listen sock 100;
  sock
;;

