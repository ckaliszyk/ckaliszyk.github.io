(** Request Broker *)

(** [add_new_client (client_sock, client_addr_host)] thread routine for 
   processing a single connection from a client *)
val add_new_client : (Unix.file_descr * Unix.inet_addr) -> unit;;

(** [add_new_box box_sock box_connect_port] register new box *)
val add_new_box : Unix.file_descr -> int -> unit;;
  
(** [request_broker client_accept_port box_accept_port box_connect_port]
    main Request Broker function *)
val request_broker : int -> int -> int -> unit;;
