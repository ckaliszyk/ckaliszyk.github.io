open Types_ad;;
open Libdebug;;

(* let empty_url = "";; *)
let empty_ses = Leaf;;
let empty_log = [];;

(** returns all sessions registered from the file
    from the starting date till the ending date

    @param filename File name of log file
    @param from Starting date
    @param till Ending date 
 *)
let read filename from till =

  let printnspaces n = print_string (String.make n ' ') in
  let print2xspaces n = printnspaces (2*n) in
  let print_str n str = print2xspaces n; print_string str in

  let stack = Stack.create () in
  let push_empty_node str = Stack.push (Node(Some(str), [])) stack in
  let ignore_session = ref "" in
  let res = ref [] in 
  let titles = ref [] in 
  
  let iter_fun client session (time, url_from, url_to, a_content) =
    debug (lazy(
      print_str (Stack.length stack) (client ^ " " ^ session ^ " " ^ url_from ^ "->" ^ url_to ^ " using " ^ a_content);
      print_newline ();
    ));
    (* if this session has been ignored *)
    if session = (!ignore_session) then ();
    (* remeber titles *)
    if (url_to != "" && a_content != "") then titles := (url_to, a_content)::(!titles);
    (* not ignored *)
    let new_session () =
      (* check if time falls between from and till *)
      let ses_date = (date_of_tm (Unix.localtime time)) in
      debug ( lazy ( print_endline ("Session logged at " ^ (string_of_date ses_date)); ));
      if (compare_date from ses_date <= 0) && 
         (compare_date ses_date till <= 0) then 
      (
        ignore_session := "";
        (* push the session beginning onto stack *)
        if url_from="" then () else ( push_empty_node url_from );
        push_empty_node url_to;
      ) else (
        (* ignore this session *)
        ignore_session := session;
      )
    in 
    if Stack.is_empty stack then (
      (* new session *)
      new_session ();
    ) else (
      (* stack is not empty - find url_from on the stack *)
      let rec attach url_from url_to =
          match Stack.top stack with
          | Node(url, sons) as node -> 
              if url=Some(url_from) then (
                push_empty_node url_to
              ) else (
                ignore (Stack.pop stack);
                try 
                  match Stack.pop stack with
                  | Node(parent_url, brothers) -> 
                      Stack.push (Node(parent_url, node::brothers)) stack;
                      attach url_from url_to;
                  | Leaf -> () (* won't happen *)
                with Stack.Empty -> (
                  res := node::(!res);
                  new_session ();
                )
              )
          | Leaf -> () (* won't happen *)
      in attach url_from url_to;
    )
  in
  let sessions = Blogreader.read filename in
  let outer_iter (client, session, clicks) =
    List.iter (fun click -> iter_fun client session click) clicks
  in List.iter outer_iter sessions;
  
  (* get the last session from stack *)
  let rec finish () =
    match Stack.pop stack with
    | Node(url, sons) as node -> (
        try 
          match Stack.pop stack with
          | Node(parent_url, brothers) -> 
              Stack.push (Node(parent_url, node::brothers)) stack;
              finish ();
          | Leaf -> () (* won't happen *)
        with Stack.Empty ->
          res := node::(!res);
    )
    | Leaf -> () (* won't happen *)
  in if not (Stack.is_empty stack) then finish ();

  let rec reverse_node = function
    | Node(url, sons) -> Node(url, (List.map reverse_node (List.rev sons)))
    | Leaf -> Leaf
  in 
  (List.map reverse_node (List.rev (!res)), !titles)

  (*
      let extract_sessions =

        let attach_episode ses episode =
          match ses with
          | Node (url, sons) -> Node (url, sons@[episode])
      | Leaf -> episode
    in

    let ses_id_pos = res#fnumber "session" in
    let url_from_pos = res#fnumber "url_from" in 
    let url_to_pos = res#fnumber "url_to" in
    let num_pos = res#fnumber "date" in

    let ntuples = res#ntuples in
    
    let rec read_subtree ses tup_num last_id last_url first =
      
      debug (lazy(
        print_str tup_num "read_subtree tup_num="; print_string (string_of_int tup_num);
        print_string " last_id="; print_string (string_of_int last_id);
        print_string " last_url="; print_string (string_of_url last_url);
        print_newline()
      ));

      if tup_num >= ntuples then (last_id, None, ses, tup_num)
      else (
        assert (res#getisnull tup_num ses_id_pos = false);
        (* url_from is NULL in the first row *)
        (* assert (res#getisnull tup_num url_from_pos = false);*)
        assert (res#getisnull tup_num url_to_pos = false);
        assert (res#getisnull tup_num num_pos = false);
        let ses_id = int_of_string (res#getvalue tup_num ses_id_pos) in
        (* starting url can be either NULL or 0 length string *)
        let url_from = match res#getisnull tup_num url_from_pos with
          | true -> None
          | false -> Some (res#getvalue tup_num url_from_pos) in
        let url_from = match url_from with 
          | None -> None
          | Some (str) -> if str = "" then None else Some (str) in
        let url_to = Some (res#getvalue tup_num url_to_pos) in
        (* let num_in_ses = res#getvalue tup_num num_pos in *)
        if (last_id <> ses_id) then (ses_id, None, ses, tup_num)
        else if (not first) && (url_from <> last_url) then (ses_id, url_from, ses, tup_num)
        else let ses = if first then (Node (url_from, [])) else ses in
        let node = attach_episode ses (Node (url_to, [])) in 
        let (ses_id, stop_url, episode, last_tup_num) =
          read_subtree Leaf (tup_num+1) last_id url_to false in
        let new_ses = attach_episode node episode in

        debug (lazy(
          print_str tup_num " got stop_url="; print_string (string_of_url stop_url);
          print_string " last_tup_num="; print_string (string_of_int last_tup_num);
          print_newline();
        ));
          
        if stop_url = url_from then
          read_subtree new_ses last_tup_num last_id url_from false
        else 
          (ses_id, stop_url, new_ses, last_tup_num)
      )
    in

    let rec extract_session last_id tup_num log = 

      let rec read_tree ses tup_num last_id last_url =
        let (new_id, stop_url, session, new_pos) =
          read_subtree ses tup_num last_id last_url true in
        debug ( lazy (
          Printf.printf " in read_tree, last_id==%i new_id==%i stop_url==%s\n" last_id new_id (string_of_url stop_url);
        ));
        if (last_id <> new_id) then (new_id, stop_url, session, new_pos)
        else (-1, stop_url, session, new_pos)
      in
      let (new_id, _, session, new_pos) =
        read_tree empty_ses tup_num last_id None in
      (* let _ = assert (new_pos > tup_num) in *)
      debug ( lazy (
        Printf.printf " in extract_session, last_id==%i new_id==%i\n" last_id new_id;
      ));
      let new_log = match session with
      | Leaf -> log
      | _ -> session::log in
      if (new_pos >= ntuples) then new_log
      else extract_session new_id new_pos new_log
    in

    List.rev (extract_session (-1) 0 [])
	  
  in

  (* Sort by session_id so that sessions can be distinguished easily *)
  let query = Printf.sprintf
	      "SELECT * FROM Clicks WHERE date BETWEEN 
              TO_DATE('%i/%i/%i', 'dd/mm/yyyy') AND 
              TO_DATE('%i/%i/%i', 'dd/mm/yyyy') AND
              session = 3
               ORDER BY session, date" 
               from.d from.m from.y till.d till.m till.y
  in
  debug (lazy(
    print_endline query;
  ));
  conn # send query;
  match conn#get_result with
    | Some res ->
      (match res#status with
       | Postgres.Result.Tuples_ok -> extract_sessions res
       | stat -> failwith ("PostgreSQL said: " ^ (Postgres.Result.string_of_status stat))
      )
    | None -> empty_log
  *)
;;

(** splits given list into 3 lists, distributing list elements randomly

    @param sessions Initial list
    @param learning Fractional size (in reference to size of sessions list) of first list
    @param validation Fractional size (in reference to size of sessions list) of second list
    @param testing Fractional size (in reference to size of sessions list) of third list 
 *)
let split_sessions_random sessions learning validation testing =

  let max_rand = 100 in

  let rec split count_1 count_2 target_1 target_2 list_1 list_2 probab_1 list_orig =
    let new_probab = 
      if count_1 = target_1 then 
        -1
      else if count_2 = target_2 then 
        max_rand
      else 
        probab_1 in
      match list_orig with
      | hd::tl -> 
        (let rand = Random.int max_rand in
              
              (*
               print_string "rand: ";
               print_int rand;
               print_string " probab_1: ";
               print_int probab_1;
               print_newline();
              *)
               
         if rand < probab_1 then
           split (count_1+1) count_2 target_1 target_2 (hd::list_1) list_2 new_probab tl
         else
           split count_1 (count_2+1) target_1 target_2 list_1 (hd::list_2) new_probab tl
        )
      | [] -> (list_1, list_2)
  in

  let split_list orig_list count1 count2 =
    let list_len = List.length orig_list in
    let probab = int_of_float (((float_of_int count1) /. (float_of_int list_len)) *. 
			      (float_of_int max_rand)) in
    split 0 0 count1 count2 [] [] probab orig_list
  in
  
  (* FIXME: maybe do a better seeding? *)
  Random.init (int_of_float (Unix.gettimeofday()));
  
  let sum = learning +. validation +. testing in
  let learn_part = learning /. sum in
  let valid_part = validation /. sum in
  let test_part = testing /. sum in
  
  let sess_total = float_of_int (List.length sessions) in
  let learn_total = int_of_float (sess_total *. learn_part) in
  let valid_total = int_of_float (sess_total *. valid_part) in
  let test_total = (int_of_float sess_total) - learn_total - valid_total in

  let (learn_tmp, test) = split_list sessions (learn_total+valid_total) test_total in
  let (learn, valid) = split_list learn_tmp learn_total valid_total in
  (learn, valid, test)
;;

(** cleans sessions of stop urls and stop parameters

    @param log sessions list
    @param stop_urls list of stop urls
    @param stop_params list of stop parameters
    @return cleaned log
 *)
let clean log stop_urls stop_params =
  
  (* cuts away substring <pos, right_pos> from str *)
  let cut str len pos right_pos =
    if len-right_pos-1 > 0 then 
      String.blit str (right_pos+1) str pos (len-right_pos-1);
    String.sub str 0 (len-(right_pos-pos+1))
  in
  
  let cut_param str param =
    (* URL with parametr will look like this:
     * /path1/path2/url?param1=ala&SID=kot
    *)
    let len = String.length str in
    let pos = Str.search_forward (Str.regexp_string (param ^ "=")) str 0 in
    if (pos = 0) then raise Not_found
    else if (str.[pos-1] <> '?') && (str.[pos-1] <> '&') then raise Not_found
    else let right_pos = 
      (try (String.index_from str pos '&') with Not_found -> (len-1)) in
    cut str len pos right_pos
  in  
    
  let cut_params str params =
    let new_str = ref str in
    
    let rec f param =
      try
        new_str := cut_param !new_str param;
        f param
      with Not_found -> ()
    in
    
    List.iter f params;
    !new_str
  in
  
  (* clean any left over on the end of the url, e.g. if url was a.html?SID=ala
   * initially, after cleaning SID=ala it will be a.html?, so it needs to be cut
   * to a.html
  *)
  let rec clean_right url len =
    let right = url.[len-1] in
    if (right = '&') || (right = '?') then
      clean_right (String.sub url 0 (len-1)) (len-1)
    else url
  in
  
  let clean_param = function
    | None -> ""
    | Some(url) ->
        let cut_url = cut_params url stop_params in
        clean_right cut_url (String.length cut_url)
  in
  
  (* FIXME: convert stop_url list to Set *)
  let is_stop_url url =
    List.exists (fun stop_url -> (compare url stop_url) = 0) stop_urls
  in
    
  let rec clean_subtree = function
    | Leaf -> []
    | Node(url, sons) ->
        let cleaned_url = clean_param url in
        let len = String.length cleaned_url in
        let right_pos = try String.index cleaned_url '?' with Not_found -> len in
        let url_without_params = String.sub cleaned_url 0 right_pos in
        (* rev_map is faster but order of sons should not be changed *)
        let cleaned_sons = List.flatten (List.map clean_subtree sons) in
        if (is_stop_url url_without_params) || (len = 0) then
          cleaned_sons 
        else
          [ Node(Some(cleaned_url), cleaned_sons) ]
  in
  (* rev_map can be used here as the order of sessions does not matter *)
  List.flatten (List.rev_map clean_subtree log)
;;
