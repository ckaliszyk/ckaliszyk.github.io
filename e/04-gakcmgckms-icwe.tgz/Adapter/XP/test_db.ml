open Types_xp;;
open Xp_db;;

try
  let conn = connect "dbname=uuu" in
    print_string "Connection successfull!";
    print_newline();
    let from = { d=6; m=1; y=2003; } in
    let till = { from with y=2004; } in
    let _ = Sessions.read conn from till in
    disconnect conn;
with Postgres.Error x ->
  print_string "Postgres error: " ;
  print_string (Postgres.string_of_error x) ;;
