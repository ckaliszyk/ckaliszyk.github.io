(** Main file for eXPerimenter module (command-line backend)
 
    @author Marcin Gozdalik
 *)

open Types_ad;;
open Libdebug;;

type config = {
  mutable from: date; (** starting date **)
  mutable till: date; (** ending date **)
  mutable learn_percent: int; (** percentage of log for learning **)
  mutable validate_percent: int; (** percentage of log for validating **)
  mutable test_percent: int; (** percentage of log for testing **)
  mutable size: int; (** model size (AKA maximum subepisode length **)
  mutable log_files: string list; (** log files to read sessions from **)
  mutable threshold: float; (** support threshold **)
  mutable stop_urls: string list; (** ignored URLs **)
  mutable stop_params: string list; (** ignored parameters (like SID) **)
  mutable outtest: bool; (** output test log *)
};;

let default_config = {
  from = { d=1; m=1; y=2003; };
  till = { d=31; m=12; y=2003; };
  learn_percent = 60;
  validate_percent = 25;
  test_percent = 15;
  log_files = [];
  size = 5;
  threshold = 0.005; (* 5 promiles *)
  stop_urls = [ "/htdig" ];
  stop_params = [ "SID" ];
  outtest = false;
};;

let set_from cf from_string = 
  try cf := {!cf with from = (date_of_string from_string)}
  with Failure str -> 
    prerr_string "Error reading from date: ";
    prerr_endline str;
    exit 2;
;;

let set_till cf till_string = 
  try cf := {!cf with till = (date_of_string till_string)}
  with Failure str -> 
    prerr_string "Error reading till date: ";
    prerr_endline str;
    exit 2;
;;    

let set_learn cf percent =
  cf := {!cf with learn_percent = percent};;

let set_validate cf percent =
  cf := {!cf with validate_percent = percent};;

let set_test cf percent =
  cf := {!cf with test_percent = percent};;

let set_out_test cf percent =
  cf := {!cf with outtest = true};;

let set_size cf size =
  cf := {!cf with size = size};;

let set_threshold cf threshold =
  cf := {!cf with threshold = (threshold /. 100.0)};;

let set_stop_urls cf urls =

  let parse_urls urls =
    
    let rec parse_acc urls acc =
      let len = String.length urls in
      let pos = try String.index urls ','
        with Not_found -> -1
      in let ret = if len > 0 then (urls)::acc else acc in
      if pos = -1 then ret else
      let ret = if pos > 0 then (String.sub urls 0 pos)::acc else acc in
      parse_acc (String.sub urls (pos+1) (len-pos-1)) ret
    in
    parse_acc urls []
  in

  cf := {!cf with stop_urls = (parse_urls urls)};;

let set_stop_params cf params =

  let parse_params params =
    
    let rec parse_acc params acc =
      let len = String.length params in
      let pos = try String.index params ','
        with Not_found -> -1
      in let ret = if len > 0 then params::acc else acc in
      if pos = -1 then ret else
      let ret = if pos > 0 then (String.sub params 0 pos)::acc else acc in
      parse_acc (String.sub params (pos+1) (len-pos-1)) ret
    in
    parse_acc params []
  in
  cf := {!cf with stop_params = (parse_params params)};;

let set_log_opt cf opt =
  cf := {!cf with log_files = (opt::((!cf).log_files))};;

let read_args () =
  let cf = ref default_config in
  let speclist =
    [("-from", Arg.String (set_from cf), "starting date");
     ("-till", Arg.String (set_till cf), "ending date");
     ("-learn", Arg.Int (set_learn cf), "percentage of log used for learning");
     ("-validate", Arg.Int (set_validate cf), "percentage of log used for validation");
     ("-test", Arg.Int (set_test cf), "percentage of log used for testing");
     ("-size", Arg.Int (set_size cf), "model size (AKA maximum sub-episode length)");
     ("-threshold", Arg.Float (set_threshold cf), "support threshold (percentage, float)");
     ("-stopurl", Arg.String (set_stop_urls cf), "list of ignored URLs (like search.html), separated by commas");
     ("-stoparam", Arg.String (set_stop_params cf), "list of ignored parameters (like SID), separated by commas");
     ("-outtest", Arg.Int (set_out_test cf), "output test log right after the model");
    ] in 
  let usage_msg = "Usage: xp [-from dd/mm/yyyy] [-till dd/mm/yyyy] 
    [-learn percent] [-validate percent] [-test percent] [-size size] 
    [-threshold threshold] [-stopurl list_of_stop_URLs]
    [-stoparam list_of_stop_params] [log_file]" in
  Arg.parse speclist (set_log_opt cf) usage_msg; !cf;;

(* main function *)

let main () =
  let cf = read_args() in
  if compare cf.from cf.till > 0 then (
    prerr_endline "From date later than till date";
    exit 2;
  );
  if cf.learn_percent < 1 || cf.learn_percent >= 100 then (
    prerr_endline "Invalid percentage of log used for learning";
    exit 2;
  );
  if cf.validate_percent < 1 || cf.validate_percent >= 100 then (
    prerr_endline "Invalid percentage of log used for validation";
    exit 2;
  );
  if cf.test_percent < 1 || cf.test_percent >= 100 then (
    prerr_endline "Invalid percentage of log used for testing";
    exit 2;
  );
  if cf.test_percent + cf.validate_percent + cf.learn_percent <> 100 then (
    prerr_endline "Percentages given must sum up to 100";
    exit 2;
  );
  if cf.size > 10 then (
    prerr_endline "Size has to be smaller than 10";
    exit 2;
  );

  let rec append_ses names (ses, titles) =
    match names with
    | filename::r -> (
      debug ( lazy ( print_endline ("Processing " ^ filename);));
      let (read_ses, read_titles) = Sessions.read filename cf.from cf.till in
      debug ( lazy ( Printf.printf "Got %i elements\n" (List.length read_ses) ;));
      append_ses r ( (read_ses::ses), (read_titles::titles) )
    )
    | [] -> (ses, titles)
  in 
  let (ses, titles) = append_ses cf.log_files ([], []) in
  let ses = List.flatten (List.rev ses) in
  let cleaned_ses = Sessions.clean ses cf.stop_urls cf.stop_params in
  debug ( lazy ( 
    print_endline "Read sessions: ";
    List.iter (fun ses -> print_ses ses) ses;
    print_endline "Cleaned sessions: ";
    List.iter (fun ses -> print_ses ses) cleaned_ses;
  ));

  let test_fract = (float_of_int cf.test_percent) /. 100.0 in
  let validate_fract = (float_of_int cf.validate_percent) /. 100.0 in
  let learn_fract = (float_of_int cf.learn_percent) /. 100.0 in
  let (learn_ses, valid_ses, test_ses) = 
    Sessions.split_sessions_random cleaned_ses learn_fract validate_fract test_fract in 
  let model = UsedModel.Model.make cf.size cf.threshold in
  debug ( lazy ( 
    Printf.printf "Length ses == %i\n" (List.length ses);
    Printf.printf "Length learn_ses == %i\n" (List.length learn_ses);
    Printf.printf "Length valid_ses == %i\n" (List.length valid_ses);
    Printf.printf "Length test_ses == %i\n" (List.length test_ses);
  ));
  UsedModel.Model.teach model learn_ses;
  UsedModel.Model.validate model valid_ses;
  UsedModel.Model.output_value model stdout;
  if (cf.outtest) then (
    output_value stdout test_ses;
  );
  flush stdout;
  (*
      let quality = QualityCheck.evaluateModelQuality prunedModel test_ses in
  *)
  exit 1;
;;

main();;

