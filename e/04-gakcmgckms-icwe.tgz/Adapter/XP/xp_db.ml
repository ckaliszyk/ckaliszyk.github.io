(** Implementation of database access for eXPerimenter for Postgres database 
 
    @author Marcin Gozdalik
 *)

(* Insert dbname, user and password here *)
let conninfo = "dbname=uuu";;

(** Connect to the database described by conninfo 
 
    @param conninfo Connection information (as specified in Postgres module)
 *)
let connect conninfo = 
  new Postgres.connection conninfo 
;;

(** Disconnect the connection 
 
    @param connection Connection to disconnect
 *)
let disconnect connection =
  connection # close
;;
