DIR:=Adapter/XP
TARGET:=xp
FILES:=sessions
FILES_NOMLI:=xp xp_test
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
FILES_NOMLI:=$(addprefix out/${DIR}/,${FILES_NOMLI})
-include $(addsuffix .dm,${FILES_NOMLI})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Adapter/Common/common.$(LIB_SUF) out/Common/Netstring/netstring.$(LIB_SUF) out/BLogReader/blogreader.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .$(OBJ_SUF),${FILES_NOMLI}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -o $@ unix.$(LIB_SUF) threads.$(LIB_SUF) str.$(LIB_SUF) $^
