(** Interface to database access for eXPerimenter

    @author Marcin Gozdalik
 *)

(** Connect to the database *) 
val connect: string -> Postgres.connection ;;

(** Disconnect from the database *)
val disconnect: Postgres.connection -> unit ;;
