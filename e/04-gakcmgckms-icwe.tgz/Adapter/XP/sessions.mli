(** Interface for managing sessions: reading and splitting logs into smaller
    parts

    @author Marcin Gozdalik
*)

open Types_ad;;

(** [read filename from till] returns all sessions registered in logfile given by name
    from the 'from' date to the 'till' date and a list of (URL, title) pairs
 *)
val read: string -> date -> date -> (log * ((string * string) list));;

(** splits given list into 3 lists, distributing list elements randomly
    sizes of 3 lists are given as floats \in (0;1)
 *)
val split_sessions_random :
  'a list -> float -> float -> float -> 'a list * 'a list * 'a list;;

(** clean stop_urls stop_params log cleans log of stop urls and stop params
 *)
val clean :
  Types_ad.session list -> string list -> string list -> Types_ad.session list
