open Types_ad;;

let printit epi last =
  let printone a =
    print_string (string_of_url a); print_string " ";
  in 
  print_string "epi: ";
  List.iter printone epi;
  print_string "last: ";
  print_endline (string_of_url last)
in

let test_main () =

  let log = [(Node(Some("2"), 
			    [(Node(Some("5"),
				[(Node(Some("7"),
				    [(Node(Some("34"),
					[(Node(Some("3"), 
					    [(Node(Some("55"),
						[(Node(Some("75"),
						    [(Node(Some("32"),[]))
						    ]));
						]))
					    ]));
					 (Node(Some("96"),
					    [(Node(Some("124"),[]))
			    		    ]));
				         (Node(Some("92"),
					    [(Node(Some("122"),[]))
			    		    ]))
				    
					]))
				     ]))
				  ]))
				]));
			 (Node(Some("9"),
				[(Node(Some("12"),[]));    
				 (Node(Some("13"),[]));
				 (Node(Some("91"),
				    [(Node(Some("127"),[]));    
				     (Node(Some("139"),[]))
			    	    ]))
			        ]))
                  ]
  in

  let make_log count log =
    let rec make_log_acc count log acc =
      if count = 0 then acc
      else make_log_acc (count-1) log (List.append log acc)
    in
    make_log_acc count log []
  in

  (*let test_log = make_log 100000 log in*)
  let test_log = make_log 10 log in
  
  let func epi last len _ _ =
    printit epi last
  in
  Libepi.processLog test_log func 5 ();
  (*
  let processSubepi subepi last_uurl _ _ =
    printit subepi last_uurl
  in
  let processEpisode epi _ = Libepi.forallSubepisodes processSubepi 5 epi () in
  let processSes ses = Libepi.forallEpisodes ses processEpisode () in
  List.iter processSes test_log;
  *)
  
  (*
  let processSubepi2 subepi last_uurl len a par =
    (*printit subepi last_uurl*)
    ()
  in
  Log2epi.processLog test_log 5 processSubepi2 ();
  *)

in 

(*test_main()*)
()

;;
