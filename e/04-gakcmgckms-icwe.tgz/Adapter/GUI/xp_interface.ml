(** eXPerimenter GUI - interface

    @author Janusz Dutkowski
*)

(*glowne okienko*)
class top_window2 callbacks =
let tooltips = GData.tooltips () in
let accel_group = GtkData.AccelGroup.create () in
let window2 = GWindow.window
~wm_name: "eXPerimenter"
~position:`NONE
~kind:`TOPLEVEL
~modal:false
~allow_shrink:false
~allow_grow:true
~auto_shrink:false
()
in

let _ =window2#connect#destroy ~callback:callbacks#gtk_main_quit in
(*let _ =window2#connect#close ~callback:callbacks#quit in*)

let _ = window2#add_accel_group accel_group in
let vbox1 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:window2#add
()
in
let menubar1 = GMenu.menu_bar ~packing:(vbox1#pack ~padding:0
~fill:false
~expand:false
)
~height:25
()
in
let menuitem8 = GMenu.menu_item ~label: "File"
~packing:menubar1#add
()
in
let menuitem8_menu = GMenu.menu ~packing:menuitem8#set_submenu
()
in
let menuitem10 = GMenu.menu_item ~label: "New"
~packing:menuitem8_menu#add
()
in
let _ = menuitem10#misc#add_accelerator
  ~group:accel_group 
  GdkKeysyms._q
  ~sgn:{ GtkSignal.name = "activate"; 
  GtkSignal.marshaller = GtkSignal.marshal_unit;
  GtkSignal.classe = `base }
  ~modi:[`CONTROL;]
in

let menuitem15 = GMenu.menu_item ~label: "Open"
~packing:menuitem8_menu#add
()
in
let _ = menuitem15#misc#add_accelerator
  ~group:accel_group 
  GdkKeysyms._q
  ~sgn:{ GtkSignal.name = "activate"; 
  GtkSignal.marshaller = GtkSignal.marshal_unit;
  GtkSignal.classe = `base }
  ~modi:[`CONTROL;]
in

let sep1 = GMenu.menu_item ~packing:menuitem8_menu#add
()
in


let menuitem9 = GMenu.menu_item ~label: "Exit"
~packing:menuitem8_menu#add
()
in
let _ = menuitem9#misc#add_accelerator
  ~group:accel_group 
  GdkKeysyms._q
  ~sgn:{ GtkSignal.name = "activate"; 
  GtkSignal.marshaller = GtkSignal.marshal_unit;
  GtkSignal.classe = `base }
  ~modi:[`CONTROL;]
in

let menuitem13 = GMenu.menu_item ~label: "Help"
~packing:menubar1#add
()
in
let menuitem13_menu = GMenu.menu ~packing:menuitem13#set_submenu
()
in
let menuitem14 = GMenu.menu_item ~label: "About"
~packing:menuitem13_menu#add
()
in
let _ = menuitem14#misc#add_accelerator
  ~group:accel_group 
  GdkKeysyms._a
  ~sgn:{ GtkSignal.name = "activate"; 
  GtkSignal.marshaller = GtkSignal.marshal_unit;
  GtkSignal.classe = `base }
  ~modi:[`CONTROL;]
in

let _ = menuitem9#connect#activate
	~callback:callbacks#quit in
let _ = menuitem10#connect#activate
	~callback:callbacks#new_model in
let _ = menuitem15#connect#activate
	~callback:callbacks#open_model in
let _ = menuitem14#connect#activate
	~callback:callbacks#about in


let notebook1 = GPack.notebook
~tab_pos:`TOP
~tab_border:2
~show_border:true
~scrollable:false
~popup:false
~packing:(vbox1#pack ~padding:0
~fill:true
~expand:true
)
()
in
let _ = GtkBase.Widget.set_can_focus notebook1#as_widget true in
let hbox1 = GPack.hbox
~spacing:0
~homogeneous:false
()
in
let vbox2 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:(hbox1#pack ~padding:0
~fill:true
~expand:true
)
()
in
let frame1 = GBin.frame
~label: "Model Parameters"
~packing:(vbox2#pack ~padding:0
~fill:true
~expand:true
)
~width:280
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table4 = GPack.table
~rows:2
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame1#add

()
in
let label7 = GMisc.label
~text: "Model Id:
Sessions From:
Sessions Till:
Model Size:
Learning Part:
Validating Part:
Test Part:
Threshold:
DB Options:"
~packing:(table4#attach ~left:0
~top:1
~right:1
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label8 = GMisc.label
~text: ""
~packing:(table4#attach ~left:1
~top:1
~right:2
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let frame2 = GBin.frame
~label: "Model Stats"
~packing:(vbox2#pack ~padding:0
~fill:true
~expand:true
)
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table5 = GPack.table
~rows:2
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame2#add
()
in
let label9 = GMisc.label
~text: "Teaching Sessions Processed:
Validating Sessions Processed:
Testing Sessions Processed:"
~packing:(table5#attach ~left:0
~top:1
~right:1
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label10 = GMisc.label
~text: "N/A
N/A
N/A"
~packing:(table5#attach ~left:1
~top:1
~right:2
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let frame3 = GBin.frame
~label: "Model Status"
~packing:(vbox2#pack ~padding:0
~fill:true
~expand:true
)
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table6 = GPack.table
~rows:2
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame3#add
()
in
let label12 = GMisc.label
~text: "Created:
Saved in PostgreSQL:
Saved in Overseer:"
~packing:(table6#attach ~left:0
~top:1
~right:1
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label11 = GMisc.label
~text: "No
No
No"
~packing:(table6#attach ~left:1
~top:1
~right:2
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let vbox3 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:(hbox1#pack ~padding:0
~fill:true
~expand:true
)
()
in
let table3 = GPack.table
~rows:3
~columns:3
~row_spacings:0
~col_spacings:0
~border_width:4
~homogeneous:false
~packing:(vbox3#pack ~padding:0
~fill:true
~expand:true
)
()
in
let frame4 = GBin.frame
~packing:(table3#attach ~left:1
~top:1
~right:2
~bottom:2
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
~border_width:1
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let pixmap1 = GMisc.pixmap
(GDraw.pixmap_from_xpm ~file:"pixmaps/znakBesciak.xpm" ())~packing:frame4#add
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
()
in
let fixed1 = GPack.fixed
~packing:(table3#attach ~left:0
~top:1
~right:1
~bottom:2
~xpadding:0
~ypadding:0
~expand:`X
~shrink:`NONE
~fill:`BOTH
)
()
in
let fixed2 = GPack.fixed
~packing:(table3#attach ~left:1
~top:2
~right:2
~bottom:3
~xpadding:0
~ypadding:0
~expand:`Y
~shrink:`NONE
~fill:`BOTH
)
()
in
let fixed3 = GPack.fixed
~packing:(table3#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`Y
~shrink:`NONE
~fill:`BOTH
)
()
in
let fixed4 = GPack.fixed
~packing:(table3#attach ~left:2
~top:1
~right:3
~bottom:2
~xpadding:0
~ypadding:0
~expand:`X
~shrink:`NONE
~fill:`BOTH
)
()
in
let vbuttonbox1 = GPack.button_box `VERTICAL
~spacing:10
~child_width:85
~child_height:23
~layout:`SPREAD
~packing:(vbox3#pack ~padding:0
~fill:true
~expand:true
)
()
in
let button1 = GButton.button
~packing:(vbuttonbox1#pack )
~label: "Create Model"
()
in
let _ = GtkBase.Widget.set_can_focus button1#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button1#as_widget true in*)
let _ =button1#connect#clicked ~callback:callbacks#create_model in

let button2 = GButton.button
~packing:(vbuttonbox1#pack )
~label: "Save in PostgreSQL "
()
in
let _ = GtkBase.Widget.set_can_focus button2#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button2#as_widget true in*)
let _ =button2#connect#clicked ~callback:callbacks#put_in_postgres in


let button3 = GButton.button
~packing:(vbuttonbox1#pack )
~label: "Save in Overseer"
()
in
let _ = GtkBase.Widget.set_can_focus button3#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button3#as_widget true in*)
let _ =button3#connect#clicked ~callback:callbacks#put_in_overseer in

let label1 = GMisc.label
~text: "XP Model"
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
~width:80
()
in
let hbox2 = GPack.hbox
~spacing:5
~homogeneous:false
()
in
let table7 = GPack.table
~rows:12
~columns:2
~row_spacings:5
~col_spacings:5
~border_width:5
~homogeneous:false
~packing:(hbox2#pack ~padding:0
~fill:true
~expand:true
)
()
in
let label13 = GMisc.label
~text: "Model Id:"
~packing:(table7#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label14 = GMisc.label
~text: "Sessions From:"
~packing:(table7#attach ~left:0
~top:1
~right:1
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label15 = GMisc.label
~text: "Sessions Till:"
~packing:(table7#attach ~left:0
~top:2
~right:1
~bottom:3
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label16 = GMisc.label
~text: "Model Size:"
~packing:(table7#attach ~left:0
~top:3
~right:1
~bottom:4
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label17 = GMisc.label
~text: "Learning Part:"
~packing:(table7#attach ~left:0
~top:4
~right:1
~bottom:5
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label18 = GMisc.label
~text: "Validating Part:"
~packing:(table7#attach ~left:0
~top:5
~right:1
~bottom:6
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label19 = GMisc.label
~text: "Test Part:"
~packing:(table7#attach ~left:0
~top:6
~right:1
~bottom:7
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label20 = GMisc.label
~text: "Threshold:"
~packing:(table7#attach ~left:0
~top:7
~right:1
~bottom:8
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label21 = GMisc.label
~text: "Learning Method:"
~packing:(table7#attach ~left:0
~top:8
~right:1
~bottom:9
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label22 = GMisc.label
~text: "Prunning Method"
~packing:(table7#attach ~left:0
~top:9
~right:1
~bottom:10
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label23 = GMisc.label
~text: "DB Options:"
~packing:(table7#attach ~left:0
~top:10
~right:1
~bottom:11
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let entry1 = GEdit.entry
~packing:(table7#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`X
~shrink:`NONE
~fill:`X
)
~text: "New_Model"
~max_length:0
~visibility:true
~editable:true
()
in
let _ = GtkBase.Widget.set_can_focus entry1#as_widget true in
let hbox3 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:1
~right:2
~bottom:2
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton1 = GEdit.spin_button
~adjustment:(GData.adjustment~value:1.
~lower:1.
~upper:31.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox3#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton1#as_widget true in
let spinbutton2 = GEdit.spin_button
~adjustment:(GData.adjustment~value:1.
~lower:1.
~upper:12.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox3#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton2#as_widget true in
let spinbutton3 = GEdit.spin_button
~adjustment:(GData.adjustment~value:2003.
~lower:1950.
~upper:3000.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox3#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton3#as_widget true in
let hbox4 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:2
~right:2
~bottom:3
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton4 = GEdit.spin_button
~adjustment:(GData.adjustment~value:31.
~lower:1.
~upper:31.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox4#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton4#as_widget true in
let spinbutton5 = GEdit.spin_button
~adjustment:(GData.adjustment~value:12.
~lower:1.
~upper:12.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox4#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton5#as_widget true in
let spinbutton6 = GEdit.spin_button
~adjustment:(GData.adjustment~value:2003.
~lower:1950.
~upper:3000.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox4#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton6#as_widget true in
let hbox5 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:3
~right:2
~bottom:4
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton7 = GEdit.spin_button
~adjustment:(GData.adjustment~value:5.
~lower:1.
~upper:100.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox5#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton7#as_widget true in
let hbox6 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:4
~right:2
~bottom:5
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton8 = GEdit.spin_button
~adjustment:(GData.adjustment~value:60.
~lower:1.
~upper:100.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox6#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton8#as_widget true in
let hbox7 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:5
~right:2
~bottom:6
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton9 = GEdit.spin_button
~adjustment:(GData.adjustment~value:25.
~lower:1.
~upper:100.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox7#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton9#as_widget true in
let hbox8 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:6
~right:2
~bottom:7
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton10 = GEdit.spin_button
~adjustment:(GData.adjustment~value:15.
~lower:1.
~upper:100.
~step_incr:1.
~page_incr:10.
~page_size:10.
 ())
~packing:(hbox8#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:0
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton10#as_widget true in
let hbox9 = GPack.hbox
~spacing:0
~homogeneous:false
~packing:(table7#attach ~left:1
~top:7
~right:2
~bottom:8
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`BOTH
)
()
in
let spinbutton11 = GEdit.spin_button
~adjustment:(GData.adjustment~value:0.005
~lower:0.
~upper:1.
~step_incr:0.001
~page_incr:0.01
~page_size:0.01
 ())
~packing:(hbox9#pack ~padding:0
~fill:true
~expand:true
)
~rate:1.
~digits:3
~update_policy:`ALWAYS
~numeric:true
~wrap:false
~snap_to_ticks:false
()
in
let _ = GtkBase.Widget.set_can_focus spinbutton11#as_widget true in
let optionmenu1 = GMenu.option_menu
~packing:(table7#attach ~left:1
~top:8
~right:2
~bottom:9
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`X
)
()
in
let internal_glade_menu_optionmenu1 = GMenu.menu ~show:true () in
let _ = internal_glade_menu_optionmenu1#append (GMenu.menu_item ~label:"All" ()) in
let _ = internal_glade_menu_optionmenu1#append (GMenu.menu_item ~label:"eLeL" ()) in
let _ = internal_glade_menu_optionmenu1#append (GMenu.menu_item ~label:"Last Visited" ()) in
let _ = optionmenu1#set_menu internal_glade_menu_optionmenu1 in
let _ = optionmenu1#set_history 0 in
let _ = GtkBase.Widget.set_can_focus optionmenu1#as_widget true in
let optionmenu2 = GMenu.option_menu
~packing:(table7#attach ~left:1
~top:9
~right:2
~bottom:10
~xpadding:0
~ypadding:0
~expand:`NONE
~shrink:`NONE
~fill:`X
)
()
in
let internal_glade_menu_optionmenu2 = GMenu.menu ~show:true () in
let _ = internal_glade_menu_optionmenu2#append (GMenu.menu_item ~label:"Complete" ()) in
let _ = internal_glade_menu_optionmenu2#append (GMenu.menu_item ~label:"Selective" ()) in
let _ = optionmenu2#set_menu internal_glade_menu_optionmenu2 in
let _ = optionmenu2#set_history 0 in
let _ = GtkBase.Widget.set_can_focus optionmenu2#as_widget true in
let entry2 = GEdit.entry
~packing:(table7#attach ~left:1
~top:10
~right:2
~bottom:11
~xpadding:0
~ypadding:0
~expand:`X
~shrink:`NONE
~fill:`X
)
~text: "dbname=uuu"
~max_length:0
~visibility:true
~editable:true
()
in
let _ = GtkBase.Widget.set_can_focus entry2#as_widget true in
let vbox6 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:(hbox2#pack ~padding:0
~fill:true
~expand:true
)
()
in
let frame6 = GBin.frame
~packing:(vbox6#pack ~padding:0
~fill:true
~expand:true
)
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let vbox7 = GPack.vbox
~border_width:5
~spacing:0
~homogeneous:false
~packing:frame6#add
()
in
  let vbox = GPack.vbox ~border_width:0
~packing:(vbox7#pack ~padding:0
~fill:true
~expand:true
)
(*~width:630
*)
  ~height:100
  () in
  let hbox = GPack.hbox ~packing:vbox#add () in
  let sb =
    GRange.scrollbar `VERTICAL ~packing:(hbox#pack ~from:`END) () in

  let list1 =  GList.clist ~titles:["Stop Urls"] ~shadow_type:`OUT
     ~packing:hbox#add ~vadjustment:sb#adjustment
  ()in
  let _ =  list1#connect#select_row ~callback:callbacks#list1_sel in
  let _ =  list1#connect#unselect_row ~callback:callbacks#list1_unsel in

let label24 = GMisc.label
~text: "Stop Url:"
~packing:(vbox7#pack ~padding:0
~fill:false
~expand:true
)
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let entry3 = GEdit.entry
~packing:(vbox7#pack ~padding:0
~fill:false
~expand:false
)
~max_length:0
~visibility:true
~editable:true
()
in
let _ = GtkBase.Widget.set_can_focus entry3#as_widget true in
let hbuttonbox2 = GPack.button_box `HORIZONTAL
~spacing:20
~child_width:85
~child_height:20
~layout:`SPREAD
~packing:(vbox7#pack ~padding:0
~fill:true
~expand:true
)
()
in
let button8 = GButton.button
~packing:(hbuttonbox2#pack )
~label: "Add"
()
in
let _ = GtkBase.Widget.set_can_focus button8#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button8#as_widget true in*)

let _ =button8#connect#clicked ~callback:callbacks#add_list1 in

let button9 = GButton.button
~packing:(hbuttonbox2#pack )
~label: "Delete"
()
in
let _ = GtkBase.Widget.set_can_focus button9#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button9#as_widget true in
*)
let _ =button9#connect#clicked ~callback:callbacks#del_list1 in

let button10 = GButton.button
~packing:(hbuttonbox2#pack )
~label: "Replace"
()
in
let _ = GtkBase.Widget.set_can_focus button10#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button10#as_widget true in
*)
let _ =button10#connect#clicked ~callback:callbacks#edit_list1 in


let button18 = GButton.button
~packing:(hbuttonbox2#pack )
~label: "Clear"
()
in
let _ = GtkBase.Widget.set_can_focus button18#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button18#as_widget true in
*)
let _ =button18#connect#clicked ~callback:callbacks#clear_list1 in



let frame7 = GBin.frame
~packing:(vbox6#pack ~padding:0
~fill:true
~expand:true
)
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let vbox8 = GPack.vbox
~border_width:5
~spacing:0
~homogeneous:false
~packing:frame7#add
()
in
let vbox = GPack.vbox ~border_width:0
~packing:(vbox8#pack ~padding:0
~fill:true
~expand:true
)
(*  ~width:630
 *) ~height:100

  () in
  let hbox = GPack.hbox ~packing:vbox#add 
() in
  let sb =
    GRange.scrollbar `VERTICAL ~packing:(hbox#pack 
    ~from:`END) () in
  let list2 =  GList.clist ~titles:["Stop Parameters"] ~shadow_type:`OUT
     ~packing:hbox#add ~vadjustment:sb#adjustment
  ()in
  let _ =  list2#connect#select_row ~callback:callbacks#list2_sel in
  let _ =  list2#connect#unselect_row ~callback:callbacks#list2_unsel in



let label25 = GMisc.label
~text: "Stop Parameter:"
~packing:(vbox8#pack ~padding:0
~fill:false
~expand:true
)
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let entry4 = GEdit.entry
~packing:(vbox8#pack ~padding:0
~fill:false
~expand:false
)
~max_length:0
~visibility:true
~editable:true
()
in
let _ = GtkBase.Widget.set_can_focus entry4#as_widget true in
let hbuttonbox3 = GPack.button_box `HORIZONTAL
~spacing:20
~child_width:85
~child_height:20
~layout:`SPREAD
~packing:(vbox8#pack ~padding:0
~fill:true
~expand:true
)
()
in
let button11 = GButton.button
~packing:(hbuttonbox3#pack )
~label: "Add"
()
in
let _ = GtkBase.Widget.set_can_focus button11#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button11#as_widget true in
*)
let _ =button11#connect#clicked ~callback:callbacks#add_list2 in

let button12 = GButton.button
~packing:(hbuttonbox3#pack )
~label: "Delete"
()
in
let _ = GtkBase.Widget.set_can_focus button12#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button12#as_widget true in
*)
let _ =button12#connect#clicked ~callback:callbacks#del_list2 in

let button13 = GButton.button
~packing:(hbuttonbox3#pack )
~label: "Replace"
()
in
let _ = GtkBase.Widget.set_can_focus button13#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button13#as_widget true in
*)
let _ =button13#connect#clicked ~callback:callbacks#edit_list2 in

let button19 = GButton.button
~packing:(hbuttonbox3#pack )
~label: "Clear"
()
in
let _ = GtkBase.Widget.set_can_focus button19#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button19#as_widget true in
*)
let _ =button19#connect#clicked ~callback:callbacks#clear_list2 in

let hbuttonbox4 = GPack.button_box `HORIZONTAL
~spacing:7
~child_width:160
~child_height:23
~border_width:3
~layout:`SPREAD
~packing:(vbox6#pack ~padding:0
~fill:false
~expand:true
)
()
in
let button16 = GButton.button
~packing:(hbuttonbox4#pack )
~label: "Apply"
()
in
let _ = GtkBase.Widget.set_can_focus button16#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button16#as_widget true in
*)
let _ =button16#connect#clicked ~callback:callbacks#apply in

let button17 = GButton.button
~packing:(hbuttonbox4#pack )
~label: "Discard"
()
in
let _ = GtkBase.Widget.set_can_focus button17#as_widget true in
(*let _ = GtkBase.Widget.set_can_default button17#as_widget true in
*)
let _ =button17#connect#clicked ~callback:callbacks#discard in

let label2 = GMisc.label
~text: "Settings"
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
~width:80
()
in

let hbox10 = GPack.hbox
~spacing:0
~homogeneous:false
()
in

let table8 = GPack.table
~rows:2
~columns:4
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:(hbox10#pack ~padding:0 ~expand:true
)
()
in
let frame14 = GBin.frame
~label: "Overall Results"
~packing:(table8#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)

~width:280
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table15 = GPack.table
~rows:1
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame14#add
()
in
let label26 = GMisc.label
~text: "Episodes tested:
Total hits on target:
Choice most often hit:
Probability level most often hit:"
~packing:(table15#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label27 = GMisc.label
~text: ""
~packing:(table15#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in

let frame8 = GBin.frame
~label: "First Choice Hits"
~packing:(table8#attach ~left:0
~top:1
~right:1
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)

~width:280
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table9 = GPack.table
~rows:1
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame8#add
()
in
let label28 = GMisc.label
~text: "Total:
Prob. level 80-100%:
Prob. level 60-79%:
Prob. level 40-59%:
Prob. level 20-39%:
Prob. level 0-19%:"
~packing:(table9#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label29 = GMisc.label
~text: ""
~packing:(table9#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label30 = GMisc.label
~text: ""
~packing:(table9#attach ~left:2
~top:0
~right:3
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label31 = GMisc.label
~text: ""
~packing:(table9#attach ~left:3
~top:0
~right:4
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in



let frame9 = GBin.frame
~label: "Second Choice Hits"
~packing:(table8#attach ~left:1
~top:1
~right:2
~bottom:2
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)

~width:280
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table10 = GPack.table
~rows:1
~columns:4
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame9#add
()
in
let label32 = GMisc.label
~text: "Total:
Prob. level 80-100%:
Prob. level 60-79%:
Prob. level 40-59%:
Prob. level 20-39%:
Prob. level 0-19%:"
~packing:(table10#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label33 = GMisc.label
~text: ""
~packing:(table10#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label34 = GMisc.label
~text: ""
~packing:(table10#attach ~left:2
~top:0
~right:3
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label35 = GMisc.label
~text: ""
~packing:(table10#attach ~left:3
~top:0
~right:4
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in


let frame10 = GBin.frame
~label: "Third Choice Hits"
~packing:(table8#attach ~left:0
~top:2
~right:1
~bottom:3
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)

~width:280
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table11 = GPack.table
~rows:1
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame10#add
()
in
let label36 = GMisc.label
~text: "Total:
Prob. level 80-100%:
Prob. level 60-79%:
Prob. level 40-59%:
Prob. level 20-39%:
Prob. level 0-19%:"
~packing:(table11#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label37 = GMisc.label
~text: ""
~packing:(table11#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label38 = GMisc.label
~text: ""
~packing:(table11#attach ~left:2
~top:0
~right:3
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label39 = GMisc.label
~text: ""
~packing:(table11#attach ~left:3
~top:0
~right:4
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in

let frame11 = GBin.frame
~label: "Forth Choice Hits"
~packing:(table8#attach ~left:1
~top:2
~right:2
~bottom:3
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)

~width:280
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table12 = GPack.table
~rows:1
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame11#add
()
in
let label40 = GMisc.label
~text: "Total:
Prob. level 80-100%:
Prob. level 60-79%:
Prob. level 40-59%:
Prob. level 20-39%:
Prob. level 0-19%:"
~packing:(table12#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label41 = GMisc.label
~text: ""
~packing:(table12#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label42 = GMisc.label
~text: ""
~packing:(table12#attach ~left:2
~top:0
~right:3
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label43 = GMisc.label
~text: ""
~packing:(table12#attach ~left:3
~top:0
~right:4
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in

let frame12 = GBin.frame
~label: "Fifth Choice Hits"
~packing:(table8#attach ~left:0
~top:3
~right:1
~bottom:4
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
(*~fill:`X*)
)

(*~width:280*)
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table13 = GPack.table
~rows:1
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame12#add
()
in
let label44 = GMisc.label
~text: "Total:
Prob. level 80-100%:
Prob. level 60-79%:
Prob. level 40-59%:
Prob. level 20-39%:
Prob. level 0-19%:"
~packing:(table13#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label45 = GMisc.label
~text: ""
~packing:(table13#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label46 = GMisc.label
~text: ""
~packing:(table13#attach ~left:2
~top:0
~right:3
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label47 = GMisc.label
~text: ""
~packing:(table13#attach ~left:3
~top:0
~right:4
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in

let frame13 = GBin.frame
~label: "Sixth Choice Hits"
~packing:(table8#attach ~left:1
~top:3
~right:2
~bottom:4
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
(*~fill:`X*)
)

(*~width:280*)
~border_width:5
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let table14 = GPack.table
~rows:1
~columns:2
~border_width:5
~row_spacings:0
~col_spacings:0
~homogeneous:false
~packing:frame13#add
()
in
let label48 = GMisc.label
~text: "Total:
Prob. level 80-100%:
Prob. level 60-79%:
Prob. level 40-59%:
Prob. level 20-39%:
Prob. level 0-19%:"
~packing:(table14#attach ~left:0
~top:0
~right:1
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~xpad:0
~ypad:0
~justify:`LEFT
~line_wrap:false
()
in
let label49 = GMisc.label
~text: ""
~packing:(table14#attach ~left:1
~top:0
~right:2
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label50 = GMisc.label
~text: ""
~packing:(table14#attach ~left:2
~top:0
~right:3
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in
let label51 = GMisc.label
~text: ""
~packing:(table14#attach ~left:3
~top:0
~right:4
~bottom:1
~xpadding:0
~ypadding:0
~expand:`BOTH
~shrink:`NONE
~fill:`X
)
~xalign:0.
~yalign:0.5
~justify:`LEFT
~xpad:0
~ypad:0
~line_wrap:false
()
in

let label3 = GMisc.label
~text: "Test Results"
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
~width:80
()
in
let _ =  button17#connect#clicked
	~callback:callbacks#on_button17_clicked in
let _ =  button16#connect#clicked
	~callback:callbacks#on_button16_clicked in
let _ =  button13#connect#clicked
	~callback:callbacks#on_button13_clicked in
let _ =  button12#connect#clicked
	~callback:callbacks#on_button12_clicked in
let _ =  button11#connect#clicked
	~callback:callbacks#on_button11_clicked in
let _ =  button10#connect#clicked
	~callback:callbacks#on_button10_clicked in
let _ =  button9#connect#clicked
	~callback:callbacks#on_button9_clicked in
let _ =  button8#connect#clicked
	~callback:callbacks#on_button8_clicked in
let _ =  button3#connect#clicked
	~callback:callbacks#on_button3_clicked in
let _ =  button2#connect#clicked
	~callback:callbacks#on_button2_clicked in
let _ =  button1#connect#clicked
	~callback:callbacks#on_button1_clicked in
object(self)
method tooltips = tooltips
method window2 = window2
method accel_group = accel_group
method vbox1 = vbox1
method menubar1 = menubar1
method notebook1 = notebook1
method list1 = list1
method list2 = list2
method hbox1 = hbox1
method vbox2 = vbox2
method frame1 = frame1
method table4 = table4
method label7 = label7
method label8 = label8
method frame2 = frame2
method table5 = table5
method label9 = label9
method label10 = label10
method frame3 = frame3
method table6 = table6
method label12 = label12
method label11 = label11
method vbox3 = vbox3
method table3 = table3
method frame4 = frame4
method pixmap1 = pixmap1
method fixed1 = fixed1
method fixed2 = fixed2
method fixed3 = fixed3
method fixed4 = fixed4
method vbuttonbox1 = vbuttonbox1
method button1 = button1
method button2 = button2
method button3 = button3
method label1 = label1
method hbox2 = hbox2
method table7 = table7
method label13 = label13
method label14 = label14
method label15 = label15
method label16 = label16
method label17 = label17
method label18 = label18
method label19 = label19
method label20 = label20
method label21 = label21
method label22 = label22
method label23 = label23
method entry1 = entry1
method hbox3 = hbox3
method spinbutton1 = spinbutton1
method spinbutton2 = spinbutton2
method spinbutton3 = spinbutton3
method hbox4 = hbox4
method spinbutton4 = spinbutton4
method spinbutton5 = spinbutton5
method spinbutton6 = spinbutton6
method hbox5 = hbox5
method spinbutton7 = spinbutton7
method hbox6 = hbox6
method spinbutton8 = spinbutton8
method hbox7 = hbox7
method spinbutton9 = spinbutton9
method hbox8 = hbox8
method spinbutton10 = spinbutton10
method hbox9 = hbox9
method spinbutton11 = spinbutton11
method optionmenu1 = optionmenu1
method optionmenu2 = optionmenu2
method entry2 = entry2
method vbox6 = vbox6
method frame6 = frame6
method vbox7 = vbox7
method label24 = label24
method entry3 = entry3
method hbuttonbox2 = hbuttonbox2
method button8 = button8
method button9 = button9
method button10 = button10
method frame7 = frame7
method vbox8 = vbox8
method label25 = label25
method entry4 = entry4
method hbuttonbox3 = hbuttonbox3
method button11 = button11
method button12 = button12
method button13 = button13
method hbuttonbox4 = hbuttonbox4
method button16 = button16
method button17 = button17
method button18 = button18
method button19 = button19
method label2 = label2
method hbox10= hbox10
method table8 = table8
method frame8 = frame8
method table9 = table9
method frame9 = frame9
method table10 = table10
method frame10 = frame10
method table11 = table11
method frame11 = frame11
method table12 = table12
method frame12 = frame12
method table13 = table13
method frame13 = frame13
method table14 = table14
method frame14 = frame14
method table15 = table15
method label26 = label26
method label27 = label27
method label28 = label28
method label29 = label29
method label30 = label30
method label31 = label31
method label32 = label32
method label33 = label33
method label34 = label34
method label35 = label35
method label36 = label36
method label37 = label37
method label38 = label38
method label39 = label39
method label40 = label40
method label41 = label41
method label42 = label42
method label43 = label43
method label44 = label44
method label45 = label45
method label46 = label46
method label47 = label47
method label48 = label48
method label49 = label49
method label50 = label50
method label51 = label51
method label3 = label3
initializer callbacks#set_window2 self;
notebook1#prepend_page 
~tab_label:label3#coerce hbox10#coerce;
notebook1#prepend_page 
~tab_label:label2#coerce hbox2#coerce;
notebook1#prepend_page 
~tab_label:label1#coerce hbox1#coerce;
notebook1#goto_page 0;
end

(*Error window *)

class top_windowErr callbacks =
let tooltips = GData.tooltips () in
let accel_group = GtkData.AccelGroup.create () in
let windowErr = GWindow.window
~wm_name: "Error"
~position:`CENTER
~kind:`DIALOG
~modal:true
~allow_shrink:false
~allow_grow:true
~auto_shrink:false
()
in

let _ = windowErr#add_accel_group accel_group in
let vbox1 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:windowErr#add
()
in
let vbox2 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:(vbox1#pack ~padding:0
~fill:true
~expand:true
)
~border_width:10
()
in
let labelErr1 = GMisc.label
~text: "The eXPerimenter encounterd some difficulties while 
performing the desired task.
If you like seeing error messeges, here it is:"
~packing:(vbox2#pack ~padding:0
~fill:false
~expand:false
)
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let frameErr = GBin.frame
~packing:(vbox2#pack ~padding:0
~fill:true
~expand:true
)
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let labelErr2 = GMisc.label
~packing:frameErr#add
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let buttonErrOk = GButton.button
~packing:(vbox1#pack ~padding:0
~fill:false
~expand:true
)
~label:"Ok"
~border_width:10
()
in
let _ = GtkBase.Widget.set_can_focus buttonErrOk#as_widget true in
let _ =  buttonErrOk#connect#clicked
	~callback:callbacks#errOk in
object(self)
method tooltips = tooltips
method windowErr = windowErr
method accel_group = accel_group
method vbox1 = vbox1
method vbox2 = vbox2
method labelErr1 = labelErr1
method frameErr = frameErr
method labelErr2 = labelErr2
method buttonErrOk = buttonErrOk
initializer callbacks#set_windowErr self;
end


(*About window *)

class top_windowAbout callbacks =
let tooltips = GData.tooltips () in
let accel_group = GtkData.AccelGroup.create () in
let windowAbout = GWindow.window
~wm_name: "About"
~position:`CENTER
~kind:`DIALOG
~modal:true
~allow_shrink:false
~allow_grow:true
~auto_shrink:false
()
in

let _ = windowAbout#add_accel_group accel_group in
let vbox1 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:windowAbout#add
()
in
let vbox2 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:(vbox1#pack ~padding:0
~fill:true
~expand:true
)
~border_width:10
()
in
let frameAb = GBin.frame
~packing:(vbox2#pack ~padding:0
~fill:true
~expand:true
)
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let labelAb2 = GMisc.label
~packing:frameAb#add
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let buttonAbOk = GButton.button
~packing:(vbox1#pack ~padding:0
~fill:false
~expand:true
)
~label:"Ok"
~border_width:10
()
in
let _ = GtkBase.Widget.set_can_focus buttonAbOk#as_widget true in
let _ =  buttonAbOk#connect#clicked
	~callback:callbacks#abOk in
object(self)
method tooltips = tooltips
method windowAbout = windowAbout
method accel_group = accel_group
method vbox1 = vbox1
method vbox2 = vbox2
method frameAb = frameAb
method labelAb2 = labelAb2
method buttonAbOk = buttonAbOk
initializer callbacks#set_windowAbout self;
end


(*Quit window *)


class top_windowQuit callbacks =
let tooltips = GData.tooltips () in
let accel_group = GtkData.AccelGroup.create () in
let windowQuit = GWindow.window
~wm_name: "eXPerimenter"
~position:`NONE
~kind:`DIALOG
~modal:true
~allow_shrink:false
~allow_grow:true
~auto_shrink:false
()
in

let _ = windowQuit#add_accel_group accel_group in
let vbox3 = GPack.vbox
~spacing:0
~homogeneous:false
~packing:windowQuit#add
()
in
let frameQuit = GBin.frame
~packing:(vbox3#pack ~padding:0
~fill:true
~expand:true
)
~border_width:10
~label_xalign:0.
~shadow_type:`ETCHED_IN
()
in
let label3 = GMisc.label
~text: "Quit the eXPerimenter?"
~packing:frameQuit#add
~xalign:0.5
~yalign:0.5
~xpad:0
~ypad:0
~line_wrap:false
()
in
let hbuttonbox1 = GPack.button_box `HORIZONTAL
~spacing:20
~child_width:153
~child_height:27
~layout:`DEFAULT_STYLE
~packing:(vbox3#pack ~padding:0
~fill:true
~expand:true
)
()
in
let buttonQuitOk = GButton.button
~packing:(hbuttonbox1#pack )
~label:"Ok"
~border_width:10
()
in
let _ = GtkBase.Widget.set_can_focus buttonQuitOk#as_widget true in
let _ = GtkBase.Widget.set_can_default buttonQuitOk#as_widget true in
let buttonQuitCancel = GButton.button
~packing:(hbuttonbox1#pack )
~label:"Cancel"
~border_width:10
()
in
let _ = GtkBase.Widget.set_can_focus buttonQuitCancel#as_widget true in
let _ = GtkBase.Widget.set_can_default buttonQuitCancel#as_widget true in
let _ = GtkBase.Widget.grab_focus buttonQuitCancel#as_widget in
let _ =  buttonQuitCancel#connect#clicked
	~callback:callbacks#quitCancel in
let _ =  buttonQuitOk#connect#clicked
	~callback:callbacks#gtk_main_quit in
object(self)
method tooltips = tooltips
method windowQuit = windowQuit
method accel_group = accel_group
method vbox3 = vbox3
method frameQuit = frameQuit
method label3 = label3
method hbuttonbox1 = hbuttonbox1
method buttonQuitOk = buttonQuitOk
method buttonQuitCancel = buttonQuitCancel
initializer callbacks#set_windowQuit self;
end
