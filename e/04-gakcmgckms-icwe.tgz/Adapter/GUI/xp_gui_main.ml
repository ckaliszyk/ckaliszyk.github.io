(** eXPerimenter GUI - main

    @author Janusz Dutkowski
*)
open GMain
open StdLabels


    module L1 = Log2epi_1.Make ;;
    module L2 = Log2epi_2.Make ;;
    module U = UsedModel.Model ;;
    module R = UsedResult.Make (U) (L1);;

(*these values will be used as default settings*)

let parList1d = ["/htdig"]
let parList2d = ["SID"]
let idd =  "New_Model"
let fromdd = "01/01/2003"
let todd = "31/12/2003"
let learningd = "60"
let evaluatingd = "25"
let testd = "15"
let max_string_lend = "5"
let thresholdd = "0.005"
let urlsd = (String.concat "," parList1d) 
let paramsd = (String.concat "," parList2d)
let dbd = "dbname=uuu"
let added_links=6 



let model = ref (U.make  1 0.0)
let model_created = ref false 
let model_saved_in_overseer = ref false 
let parList1 = ref parList1d
let parList2 = ref parList2d
let id = ref idd
let fromd = ref fromdd   
let tod = ref todd
let learning = ref learningd
let evaluating = ref evaluatingd
let test = ref testd
let max_string_len = ref max_string_lend
let threshold = ref thresholdd
let urls = ref urlsd 
let params = ref paramsd
let db = ref dbd
let parameters = ref (String.concat "\n" [!id;!fromd;!tod;!max_string_len;!learning;!evaluating;!test;
!threshold;!db])
let status = ref (String.concat "\n" ["No";"No";"No"])

let list1s = ref 1 
let list2s = ref 1

let selList1 = ref (-1)      (* row #s *)
let selList2 = ref (-1)

class customized_callbacks = object(self)
inherit Xp_callbacks.default_callbacks

(** quit eXPerimenter
*)
method quit () =
(new Xp_interface.top_windowQuit(new customized_callbacks))#windowQuit#show ()


(** confirm and exit the error window
*)
method errOk () =
self#top_windowErr#windowErr#destroy ()

(** confirm and exit the about window
*)
method abOk () =
self#top_windowAbout#windowAbout#destroy ()

(** cancel quit
*)
method quitCancel () =
self#top_windowQuit#windowQuit#destroy ()

(** add an element to list
*)
method add_list1 () = 
let text = self#top_window2#entry3#text in
if text <> "" then (*FIXME*)
  begin
    let _ =self#top_window2#entry3#set_text "" in
    list1s:=(!list1s +1);
    ignore (self#top_window2#list1#append [text]) 
  end 
else ()

(** add an element to list
*)
method add_list2 () = 
let text = self#top_window2#entry4#text in
if text <> "" then (*FIXME*)
  begin
    let _ =self#top_window2#entry4#set_text "" in
    list2s:=(!list2s +1);
    ignore (self#top_window2#list2#append [text]) 
  end
else ()

(** delete an element from list
*)
method del_list1 () = 
if ((!selList1 > (-1))&&(self#top_window2#entry3#text = self#top_window2#list1#cell_text !selList1 0)) 
  then
  begin
    let _ =self#top_window2#entry3#set_text "" in
    list1s:=(!list1s -1);  
    ignore (self#top_window2#list1#remove !selList1);
    selList1:=-1; 
  end 
else ()

(** delete an element from list
*)
method del_list2 () = 
if ((!selList2 > (-1))&&(self#top_window2#entry4#text = self#top_window2#list2#cell_text !selList2 0)) 
  then
  begin
    let _ =self#top_window2#entry4#set_text "" in
    list2s:=(!list2s -1);  
    ignore (self#top_window2#list2#remove !selList2);
    selList2:=-1; 
  end
  else ()

(**modify selected element of list
*)
method edit_list1 () = 
if (!selList1 > (-1)) then 
  begin
    ignore (self#top_window2#list1#insert !selList1  [self#top_window2#entry3#text]);
    ignore (self#top_window2#list1#remove (!selList1+1));
    self#top_window2#entry3#set_text "";  
  end 
else ()

(**modify selected element of list
*)
method edit_list2 () = 
if (!selList2 > (-1)) then 
  begin
    ignore (self#top_window2#list2#insert !selList2  [self#top_window2#entry4#text]);
    ignore (self#top_window2#list2#remove (!selList2+1));
    self#top_window2#entry4#set_text "";
  end 
else ()

(**clear list
*)
method clear_list1 ()=
  let _ =self#top_window2#list1#clear () in
  selList1:=-1;     
  list1s:=0;
  self#top_window2#entry3#set_text "";  

(**clear list
*)
method clear_list2 ()=
  let _ =self#top_window2#list2#clear () in
  selList2:=-1;
  list2s:=0;
  self#top_window2#entry4#set_text "";

(**select row of list
*)
method list1_sel ~row ~column ~(event:GdkEvent.Button.t option)=
  let text = self#top_window2#list1#cell_text row column in 
  selList1 := row;
  ignore(self#top_window2#entry3#set_text text);

(**unselect row of list
*)
method list1_unsel ~(row:int) ~(column:int) ~(event:GdkEvent.Button.t option)=
  selList1 := (-1);

(**select row of list
*)
method list2_sel ~row ~column ~(event:GdkEvent.Button.t option)=
  let text = self#top_window2#list2#cell_text row column in 
  selList2 := row;
  ignore(self#top_window2#entry4#set_text text);

(**unselect row of list
*)
method list2_unsel ~(row:int) ~(column:int) ~(event:GdkEvent.Button.t option)=
  selList2 := (-1);

(**apply parameter changes
*)
method apply () =
  (*apply changes update variable values*)
  let rec  copy_list list lwnd_list size= 
    match size with
    0-> list|
    _-> copy_list ((lwnd_list#cell_text (size-1) 0)::list) lwnd_list (size-1)
  in
  parList1:= copy_list [] self#top_window2#list1 !list1s;
  parList2:= copy_list [] self#top_window2#list2 !list2s; 

  id := self#top_window2#entry1#text (*"dbname=uuu"*);
  fromd := String.concat "/" [self#top_window2#spinbutton1#text; self#top_window2#spinbutton2#text; self#top_window2#spinbutton3#text];
  tod := String.concat "/" [self#top_window2#spinbutton4#text; self#top_window2#spinbutton5#text; self#top_window2#spinbutton6#text];
  let learn_float = float_of_string self#top_window2#spinbutton8#text in
  let val_float = float_of_string self#top_window2#spinbutton9#text in
  let test_float = float_of_string self#top_window2#spinbutton10#text in
  let total_float =learn_float +. val_float +. test_float in
  let learn_int = int_of_float ((learn_float/.total_float) *. 100.0) in
  let val_int = int_of_float ((val_float/.total_float) *. 100.0) in
  let test_int = int_of_float ((test_float/.total_float) *. 100.0) in
  let total_int = learn_int + val_int + test_int in 
  let learn_int = learn_int + (100 - total_int) in (*they all have to sum up to 100*)
  learning := string_of_int (learn_int);
  evaluating := string_of_int (val_int);
  test := string_of_int (test_int);
  self#top_window2#spinbutton8#set_text !learning;
  self#top_window2#spinbutton9#set_text !evaluating;
  self#top_window2#spinbutton10#set_text !test;
  max_string_len := string_of_int (int_of_float (float_of_string self#top_window2#spinbutton7#text) );
  threshold := string_of_float (float_of_string self#top_window2#spinbutton11#text);
  urls := String.concat "," !parList1;
  params := String.concat "," !parList2;
  db := self#top_window2#entry2#text (*"dbname=uuu"*);

  (*print model properties in the main window*)
  parameters:=String.concat "\n" [!id;!fromd;!tod;!max_string_len;!learning;!evaluating;!test;
  !threshold;!db];
  let _=self#top_window2#label8#set_text !parameters in
  ()

(**discard parameter changes
*)
method discard () = 
  (*discard changes - update settings to previous values*)
  let _ =self#top_window2#entry1#set_text !id in
  let i1= String.index (!fromd) '/' in
  let _ =self#top_window2#spinbutton1#set_text (String.sub !fromd 0 i1)  in
  let i2= String.rindex (!fromd) '/' in
  let _ =self#top_window2#spinbutton2#set_text (String.sub !fromd (i1+1) (i2-i1-1)) in
  let _ =self#top_window2#spinbutton3#set_text (String.sub !fromd (i2+1) ((String.length !fromd) -i2 -1)) in
  let i1= String.index (!tod) '/' in
  let _ =self#top_window2#spinbutton4#set_text (String.sub !tod 0 i1) in
  let i2= String.rindex (!tod) '/' in
  let _ =self#top_window2#spinbutton5#set_text (String.sub !tod (i1+1) (i2-i1-1)) in
  let _ =self#top_window2#spinbutton6#set_text (String.sub !tod (i2+1) ((String.length !tod)-i2 -1)) in
  let _ =self#top_window2#spinbutton8#set_text !learning in
  let _ =self#top_window2#spinbutton9#set_text !evaluating in
  let _ =self#top_window2#spinbutton10#set_text !test in
  let _ =self#top_window2#spinbutton7#set_text !max_string_len in
  let _ =self#top_window2#spinbutton11#set_text !threshold in
  let _ =self#top_window2#spinbutton11#set_text !threshold in
  let _ =self#top_window2#entry2#set_text !db in
  let _ =self#top_window2#list1#clear () in
  let _ =self#top_window2#list2#clear () in
  let _ =self#top_window2#entry3#set_text "" in
  let _ =self#top_window2#entry4#set_text "" in

  let _=self#top_window2#label8#set_text !parameters in

  List.iter ~f:(fun t -> ignore(self#top_window2#list1#append [t])) !parList1;
  List.iter ~f:(fun t -> ignore(self#top_window2#list2#append [t])) !parList2;

  list1s:=(List.length !parList1);
  list2s:=(List.length !parList2);

(**prapare new model
*)
method new_model () =
  (*default settings for a new model*)
  parList1 := parList1d;
  parList2 := parList2d;
  id := idd;
  fromd := fromdd;   
  tod := todd;
  learning := learningd;
  evaluating := evaluatingd;
  test := testd;
  max_string_len := max_string_lend;
  threshold := thresholdd;
  urls := urlsd; 
  params := paramsd;
  db := dbd;
  parameters := (String.concat "\n" [!id;!fromd;!tod;!max_string_len;!learning;!evaluating;!test;
  !threshold;!db]);
  status := (String.concat "\n" ["No";"No";"No"]);
  let _ =self#top_window2#entry1#set_text !id in
  let i1= String.index (!fromd) '/' in
  let _ =self#top_window2#spinbutton1#set_text (String.sub !fromd 0 i1)  in
  let i2= String.rindex (!fromd) '/' in
  let _ =self#top_window2#spinbutton2#set_text (String.sub !fromd (i1+1) (i2-i1-1)) in
  let _ =self#top_window2#spinbutton3#set_text (String.sub !fromd (i2+1) ((String.length !fromd) -i2 -1)) in
  let i1= String.index (!tod) '/' in
  let _ =self#top_window2#spinbutton4#set_text (String.sub !tod 0 i1) in
  let i2= String.rindex (!tod) '/' in
  let _ =self#top_window2#spinbutton5#set_text (String.sub !tod (i1+1) (i2-i1-1)) in
  let _ =self#top_window2#spinbutton6#set_text (String.sub !tod (i2+1) ((String.length !tod)-i2 -1)) in
  let _ =self#top_window2#spinbutton8#set_text !learning in
  let _ =self#top_window2#spinbutton9#set_text !evaluating in
  let _ =self#top_window2#spinbutton10#set_text !test in
  let _ =self#top_window2#spinbutton7#set_text !max_string_len in
  let _ =self#top_window2#spinbutton11#set_text !threshold in
  let _ =self#top_window2#spinbutton11#set_text !threshold in
  let _ =self#top_window2#entry2#set_text !db in
  let _ =self#top_window2#list1#clear () in
  let _ =self#top_window2#list2#clear () in
  let _ =self#top_window2#entry3#set_text "" in
  let _ =self#top_window2#entry4#set_text "" in

  let _=self#top_window2#label8#set_text !parameters in
  let _=self#top_window2#label11#set_text !status in
    
  List.iter ~f:(fun t -> ignore(self#top_window2#list1#append [t])) !parList1;
  List.iter ~f:(fun t -> ignore(self#top_window2#list2#append [t])) !parList2;

  list1s:=(List.length !parList1);
  list2s:=(List.length !parList2);
  
  model_created := false; 
  model_saved_in_overseer := false; 

(**open moedel info file
*)
method open_model () =
let windowA = new Xp_interface.top_windowAbout(new customized_callbacks)  in
				    windowA#labelAb2#set_text "This tiny part of the eXperimenter has not been implemented yet ";
				    windowA#windowAbout#show ();
  
(**show program info
*) 
method about () =
let windowA = new Xp_interface.top_windowAbout(new customized_callbacks)  in
				    windowA#labelAb2#set_text "The eXPerimenter is a part of the SIE system. 
It is responsible for off-line data analysis and model computation. 
Go ahead and eXPeriment... ";
				    windowA#windowAbout#show ();
(*(new Xp_glade_interface.top_window3(new customized_callbacks))#window3#show ()
*)

(**execute xp program with user-set parameters
*) 
method create_model () =

  let test_ses = ref ([] : Types_ad.log) in
  let fd_in = Unix.stdin in
  let fd_out = Unix.stdout in
  let buff = String.create 8192 in 

  let (fd_in, fd_out) = Unix.pipe() in
(*  let fd = Unix.openfile "xp.tmp" [Unix.O_CREAT; Unix.O_RDWR] 666  in    *) 
  let in_chan = (Unix.in_channel_of_descr fd_in) in
  (*let _ = 
  match Unix.fork() with
    0-> (let _ = Unix.dup2 fd_out Unix.stdout in
	try (Unix.execv "../XP/xp" 
	    [|"xp";
	    "-from"; (!fromd);
	    "-till"; (!tod); 
	    "-learn"; (!learning);
	    "-validate"; (!evaluating);
	    "-test"; (!test); 
	    "-size"; (!max_string_len);
	    "-threshold"; (!threshold);
	    "-stopurl"; (!urls);
	    "-outtest"; "1";
	    "-stoparam"; (!params);
	    (!db)|]) with Unix.Unix_error(e,syscall,param)->
			    (let err= Unix.error_message e in
	    			let mess = if param = "" then  (syscall^": "^err) else (syscall^": "^"'"^param^"'"^": "^err) in
				    let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text mess;
				    windowErr#windowErr#show ();))|
   -1-> failwith "fork error"|
*)(*    _-> let (pid,status) = Unix.wait () in 
	match status with 
	   | Unix.WEXITED (i) -> 
		(
		if i=1 then 
		    (model := (U.input_value in_chan); 	
    		    test_ses := input_value in_chan; 
		    model_created:=true;) 
		else ( let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "XP error";
				    windowErr#windowErr#show ();)
		)
	   | _-> (  let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "XP error";
				    windowErr#windowErr#show ();)
*)    
(*    _-> (model := (U.input_value in_chan); 	
    	    test_ses := input_value in_chan; 
	    model_created:=true;) 


  in 
*)
let s = Printf.sprintf "../XP/xp -from %s -till %s -learn %s -validate %s -test %s -size %s -threshold %s -stopurl %s -outtest 1 -stoparam %s %s >tmp\n"
!fromd !tod !learning !evaluating !test !max_string_len !threshold !urls !params !db in

(*Printf.printf "%s\n" s;*)
let pr_status = Unix.system s in
let _=  match pr_status with 
	   | Unix.WEXITED (i) -> 
		(
		if i=1 then 
		    ( let fd = Unix.openfile "tmp" [Unix.O_RDONLY] 0  in    
			let in_chan = (Unix.in_channel_of_descr fd) in
			model := (U.input_value in_chan); 	
			test_ses := input_value in_chan; 
			model_created:=true;
			Unix.close fd;

		    ) 
		else ( let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "XP error";
				    windowErr#windowErr#show ();)
		)
	   | _-> ( let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "XP error";
				    windowErr#windowErr#show ();)   

in 
begin  
    (*Unix.close fd_in; 
    Unix.close fd_out; *)


  if (!model_created) then
    ( status := (String.concat "\n" ["Yes";"No";"No"]);
      let _=self#top_window2#label11#set_text !status in

(*Put values out to interface*)

     let r = R.create 6 in
     R.testModel r !model !test_ses;
     let (s1) = R.get_total_tested_episodes_string r in
     let (s2) = R.get_hits_on_target_string r in
     let (s3) = R.get_common_probability_string r in
     let (s4) = R.get_common_choice_string r in
     let (s5,s6) = R.get_nth_choice_result_strings r 1 in 
     let (s7,s8) = R.get_nth_choice_result_strings r 2 in
     let (s9,s10) = R.get_nth_choice_result_strings r 3 in
     let (s11,s12) = R.get_nth_choice_result_strings r 4 in
     let (s13,s14) = R.get_nth_choice_result_strings r 5 in
     let (s15,s16) = R.get_nth_choice_result_strings r 6 in
     let s17 = R.get_percentage_hit_string r in
    
    let _=self#top_window2#label27#set_text (String.concat "\n" [s1; s2; s4; s3]) in
    let _=self#top_window2#label29#set_text s5 in
    let _=self#top_window2#label30#set_text s6 in
    let _=self#top_window2#label33#set_text s7 in
    let _=self#top_window2#label34#set_text s8 in
    let _=self#top_window2#label37#set_text s9 in
    let _=self#top_window2#label38#set_text s10 in
    let _=self#top_window2#label41#set_text s11 in
    let _=self#top_window2#label42#set_text s12 in
    let _=self#top_window2#label45#set_text s13 in
    let _=self#top_window2#label46#set_text s14 in
    let _=self#top_window2#label49#set_text s15 in
    let _=self#top_window2#label50#set_text s16 in

  ())
  else ();

end;

(**save model and additional info to postgres
*) 
method put_in_postgres ()=
let windowA = new Xp_interface.top_windowAbout(new customized_callbacks)  in
				    windowA#labelAb2#set_text "This tiny part of the eXperimenter has not been implemented yet ";
				    windowA#windowAbout#show ();
  

(**execute put program to put the computed model in overseer
*) 
method put_in_overseer ()=
if !model_created then
(
    let s = Printf.sprintf "../Put/put<tmp\n" in
    (*Printf.printf "%s\n" s;*)
    let pr_status = Unix.system s in
    let _=  match pr_status with 
	   | Unix.WEXITED (i) -> 
		(
		if i=1 then 
		    ( model_saved_in_overseer:=true;	
		    ) 
		else ( let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "Put error. Check if Overseer is running";
				    windowErr#windowErr#show ();)
		)
	   | _-> ( let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "Put error";
				    windowErr#windowErr#show ();)   
    in 

(*
 (
  let (fd_in, fd_out) = Unix.pipe() in
  let _ = 
      match Unix.fork() with
	0->(let _ = Unix.dup2 fd_in Unix.stdin in
	    try (Unix.execv "../Put/put" [||])
	    with Unix.Unix_error(e,syscall,param)->
			    (let err= Unix.error_message e in
	    			let mess = if param = "" then  (syscall^": "^err) else (syscall^": "^"'"^param^"'"^": "^err) in
				    let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text mess;
				    windowErr#windowErr#show ();))|
	-1->failwith "fork error"|
	_->(try ((Marshal.to_channel (Unix.out_channel_of_descr fd_out) (!model) []); model_saved_in_overseer:=true)
	    with Unix.Unix_error(e,syscall,param)->
			    (let err= Unix.error_message e in
	    			let mess = if param = "" then  (syscall^": "^err) else (syscall^": "^"'"^param^"'"^": "^err) in
				    let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text mess;
				    windowErr#windowErr#show ();))
  in
 (Unix.close fd_in;
  Unix.close fd_out;
*)
  if !model_saved_in_overseer then
	    (status := (String.concat "\n" ["Yes";"No";"Yes"]);
	     self#top_window2#label11#set_text !status;
	    )else (); 
)else (( let windowErr = new Xp_interface.top_windowErr(new customized_callbacks) in
				    windowErr#labelErr2#set_text "Model is not created yet";
				    windowErr#windowErr#show ();))

end

(**GUI main function
*) 
let main () = 
let callbacks = new customized_callbacks in
let window2 = new Xp_interface.top_window2 callbacks in
let _ = GtkBase.Widget.add_events window2#window2#as_widget [`ALL_EVENTS] in
callbacks#discard (); (*to change the settings to values set at the top*)
let _ = window2#window2#show() in
Main.main ()

let _ = let locale = GtkMain.Main.init () in 
        Printexc.print main ()





