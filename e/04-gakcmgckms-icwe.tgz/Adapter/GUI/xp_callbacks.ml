(** eXPerimenter GUI - default callbacks

    @author Janusz Dutkowski
*)


class default_callbacks = object(self)
val mutable top_window2_ = (None : Xp_interface.top_window2 option)
method top_window2 =
    match top_window2_ with
      | None -> assert false
      | Some c -> c
method set_window2 c = top_window2_ <- Some c
val mutable top_windowQuit_ = (None : Xp_interface.top_windowQuit option)
method top_windowQuit =
    match top_windowQuit_ with
      | None -> assert false
      | Some c -> c
method set_windowQuit c = top_windowQuit_ <- Some c
val mutable top_windowErr_ = (None : Xp_interface.top_windowErr option)
method top_windowErr =
    match top_windowErr_ with
      | None -> assert false
      | Some c -> c
method set_windowErr c = top_windowErr_ <- Some c

val mutable top_windowAbout_ = (None : Xp_interface.top_windowAbout option)
method top_windowAbout =
    match top_windowAbout_ with
      | None -> assert false
      | Some c -> c
method set_windowAbout c = top_windowAbout_ <- Some c

method on_button17_clicked () =
()
method on_button16_clicked () =
()
method on_button13_clicked () =
()
method on_button12_clicked () =
()
method on_button11_clicked () =
()
method on_button10_clicked () =
()
method on_button9_clicked () =
()
method on_button8_clicked () =
()
method on_button3_clicked () =
()
method on_button2_clicked () =
()
method on_button1_clicked () =
()
method quit () =
()
method window2_destroy () =
() 

method gtk_widget_destroy () =
 prerr_endline "Event clicked from button3";()

method gtk_main_quit () =
 GtkMain.Main.quit ()


method gtk_widget_destroy () =
 prerr_endline "Event clicked from buttonErrOk";()

end
