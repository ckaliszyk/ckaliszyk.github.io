(**Implemantation of simple matrix (MATRIX*)



module Make(V : Val.VAL) : SimpleMatrix.MATRIX with type val_t = V.t =
struct
    type val_t = V.t
    type t = val_t array array
    
    let make i j v =
    Array.make_matrix i j v
    
    let size_x mat =
    Array.length mat
    
    let size_y mat =
    Array.length mat.(0)
    
    let put mat i j x=
    if ((Array.length mat > i)&&(Array.length (mat.(0)) > j )&&( i>=0 )&&(j>=0)) then    
    mat.(i).(j)<-x else failwith "Matrix: out of bounds"
    
    let get mat i j =
    if ((Array.length mat > i) && (Array.length (mat.(0)) > j) &&( i>=0) && (j>=0)) then    
    mat.(i).(j) else failwith "Matrix: out of bounds"
     

end