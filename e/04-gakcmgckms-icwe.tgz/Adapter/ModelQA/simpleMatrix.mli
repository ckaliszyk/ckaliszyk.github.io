(** Interface to a simple matrix
    author Janusz Dutkowski*)
module type MATRIX =
    sig
	type t
	type val_t
	
	val make: int -> int -> val_t -> t
	val size_x: t -> int
	val size_y: t -> int
	val put: t -> int -> int -> val_t -> unit
	val get: t -> int -> int -> val_t
end

 	 