(** Interface to a simple int * int matrix
    author Janusz Dutkowski*)
module type MATRIX =
    sig
	type t

	val make: int -> int -> int * int -> t
	val size_x: t -> int
	val size_y: t -> int
	val put: t -> int -> int -> int * int -> unit
	val get: t -> int -> int -> int * int
end

 	 