(** specifcation of value type in test matrix
    @author: Janusz Dutkowski*)

module type VAL =
    sig
	type t
end