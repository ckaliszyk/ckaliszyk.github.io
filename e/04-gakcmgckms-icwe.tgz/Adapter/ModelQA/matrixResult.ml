(** Checks quality of a given XP model 
    
    @author Janusz Dutkowski
*)

open Types_ad;;
open Libdebug;;

module Make(M : Model.MODEL) (L : Log2epi.LOG2EPI) (X : SimpleIntIntMatrix.MATRIX) : Result.TESTRESULT with type model_t = M.t =
    struct	

    module Pred = Predictor.Make(M);;

      type model_t = M.t
      type t = {matrix: X.t;
    		mutable epis: int;
    		mutable choice: int;
    		mutable prob: int;
		}

(** returns a result type t representing the amount of 
links saved and other stats when using the model
    
    @param model Model to be tested
    @param testSessions List of sessions used to test model
    @param num_of_links_considered How many links will the prediction include    
*)
  let create num_of_choices_considered =
    {epis = 0;
     matrix = X.make (num_of_choices_considered+1) 12 (0,0); 
     choice = 0;
     prob =0;
    }
  let sizeM matrix = 
	X.size_x matrix
  let size result = 
	X.size_x result.matrix
	
  let checkModel model epi = 
     Pred.predict model "" epi

  let rec check_pred_list matrix plist url i shortcut =
    match (i>(sizeM matrix -1)) with
    true->()|
    false->match plist with 
	[]->()|
	(purl,pfloat)::t-> 
	if purl<>url then check_pred_list matrix t url (i+1) shortcut
	else(*good prediction*)
	    (let pr= int_of_float(pfloat*.100.0)/10 in
	    let pr = if pr = 10 then 9 else pr in
	    let (count,short)=X.get matrix i (pr+1) in
	    let _ = X.put matrix i (pr+1) ((count+1),short+shortcut) in 	    		 
	    let (count,short)=X.get matrix i 0 in
	    let _ =X.put matrix i 0 ((count+1),short+shortcut) in 	    		 
	    let (count,short)=X.get matrix 0 (pr+1) in
	    let _ = X.put matrix 0 (pr+1) ((count+1),short+shortcut) in 	    		 
	    let (count,short)=X.get matrix 0 0 in
	    let _ = X.put matrix 0 0 ((count+1),short+shortcut) in ())	    		 

  let single_update epi last_url epi_len (result,model) =
	let pred_list = (checkModel model epi) in
	let _ = result.epis<- (result.epis+1) in
	let _ = check_pred_list (result.matrix) pred_list last_url 1 1 in	
	()
  let rec often_pos matrix i max pos=
	match (i>(sizeM matrix -1)) with 
	true->(pos,max)|
	false->let (m,_) = X.get matrix i 0 in
	   if m<=max then 
		often_pos matrix (i+1) max pos
	    else
		often_pos matrix (i+1) m i
    
    let rec often_prob matrix i max probab=
	match (i>10) with 
	true->(probab,max)|
	false->let (m,_) = X.get matrix 0 i in
	   if (m<=max) then 
		often_prob matrix (i+1) max probab
	    else
		often_prob matrix (i+1) m i
     
    let often_pos_probab result=
	    let (i,_) = often_pos result.matrix 1 0 0 in
	    let (j,_) = often_prob result.matrix 1 0 1 in
	    let _= result.choice<-i in
	    let _=result.prob<-j in ()	 


(** returns a result type t stucture representing the amount of 
	links saved and other stats when using the model
    @param model Model to be tested
    @param testSessions List of sessions used to test model
    @param num_of_links_considered How many links will the prediction include    
*)
   let testModel result model testSessions =
   let _ = L.processLog testSessions single_update (M.maxlen (model)) (result,model) in  
   often_pos_probab result
  

	 
  let get_nth_choice_result_strings result n= 
    let rec make_strings matrix strings i=  
	match ((i+1) > (X.size_y matrix-1)) with 
	true->strings| 
	false->
	    let (s1,s2) = strings in
	    let (a1,b1)=  X.get matrix n i in
	    let (a2,b2)=  X.get matrix n (i+1) in
	    let p = if result.epis = 0 then "0" 
		else string_of_float((float_of_int (a1+a2))/.(float_of_int result.epis)) in
	    let s1 = 
		if s1<>"" then 
		    String.concat "\n" [("A: "^(string_of_int (a1+a2))); s1] 
		else
		 ("A: "^(string_of_int (a1+a2))) 
	    in
	    let s2 =
		if s2 <>"" then 
		    String.concat "\n" [("P: "^p); s2] 
		else 
		    ("P: "^p) 
	    in
		
	make_strings matrix (s1,s2) (i+2)    
    in	
    match ((n> ((X.size_x result.matrix)-1))||(n<0))  with 
    true->("N/A","N/A")|
    false->let (s1,s2) =make_strings result.matrix ("","") 1 in
	    let (a1,b1)= X.get (result.matrix) n 0 in
	    let p = if result.epis = 0 then "0" 
		else string_of_float((float_of_int (a1))/.(float_of_int result.epis)) in
	    let s1 =String.concat "\n" [("A: "^(string_of_int (a1))); s1] in
	    let s2 =String.concat "\n" [("P: "^p); s2] in
  (s1,s2)

let get_total_tested_episodes_string result =
    string_of_int result.epis
let get_hits_on_target_string result =
    let (a,b)=X.get (result.matrix) 0 0 in
    string_of_int a
let get_percentage_hit_string result = 
    let p = if result.epis = 0 then "0" 
		else let (a,b)=X.get (result.matrix) 0 0 in
		    string_of_float((float_of_int (a))/.(float_of_int result.epis))in 
		    p 

let get_common_probability_string result=
    ((string_of_int ((result.prob-1)*10))^"-"^(string_of_int ((result.prob)*10))^"%")  
let get_common_choice_string result=
    string_of_int result.choice 
    
end
