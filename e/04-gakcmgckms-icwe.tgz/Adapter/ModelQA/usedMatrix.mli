(** Specification of commonly used test results matrix
    @author Janusz Dutkowski*)

module Make : SimpleIntIntMatrix.MATRIX 

