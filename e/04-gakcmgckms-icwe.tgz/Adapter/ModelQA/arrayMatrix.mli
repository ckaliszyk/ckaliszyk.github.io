(**Interface to make a simple matrix (MATRIX)

    author Janusz Dutkowski
*)

module Make(V : Val.VAL) : SimpleMatrix.MATRIX with type val_t =V.t  