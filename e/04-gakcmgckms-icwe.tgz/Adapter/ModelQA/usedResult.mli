(**specification of module make commonly used to test xp model
    @author: Janusz Dutkowski*)
    
module Make(M: Model.MODEL) (L: Log2epi.LOG2EPI) : Result.TESTRESULT 
with type model_t=M.t 
