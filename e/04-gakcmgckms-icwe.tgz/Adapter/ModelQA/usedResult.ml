(** Commonly used test results implementation 
    @author Janusz Dutkowski*)
    
module INTAMATRIX = UsedMatrix.Make ;;

module Make(M: Model.MODEL) (L: Log2epi.LOG2EPI) = 
	MatrixResult.Make (M) (L) (INTAMATRIX)