(** Module RESULT interface for testing XP model quality

    @author Janusz Dutkowski
*)

open Types_ad;;

module type TESTRESULT =
  sig
    type model_t
    type t
  
    val create: int -> t
    (** [create size] creates test result structure type t of size [size]  
    *)
        
    val testModel: t -> model_t -> log -> unit
    (** [testModel result model test_log] tests [model] using [test_log]
	modifyng in-place the [result]   
    *)

    val size: t -> int
    (** [size result] returns result size 
    *)
    
    val single_update: episode -> url -> int -> (t * model_t) -> unit
    (** [single_update episode url episode_length result*model] 
	tests model for a single [episode] and [url] and modifies the result
    *)
    
    val get_nth_choice_result_strings: t -> int -> (string * string)
    (** [get_nth_choice_result_strings result n] returns a pair of strings 
	containing the info from [result] (amount, percentage) for [n] -th choice 
    *)
    
    val get_total_tested_episodes_string: t -> string
    (** [get_total_tested_episodes_string result] returns a string representing 
	the number of test episodes used to compute the [result] 
    *)

    val get_hits_on_target_string: t -> string
    (** [get_hits_on_target_string result] returns a string with total number of 
	correct predictions  
    *)

    val get_percentage_hit_string: t -> string
    (** [get_percentage_hit_string result] returns a string with percentage of 
	correct predictions  
    *)


    val get_common_probability_string: t -> string
    (** [get_common_probability_string result] returns a string with most 
	common probability level 
    *)

    val get_common_choice_string: t -> string
    (** [get_common_choice_string result] returns a string with most 
	common choice 
    *)
end
