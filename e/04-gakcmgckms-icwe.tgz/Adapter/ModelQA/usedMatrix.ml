(** Commonly used test results matrix*)

module INTPAIR =
  struct
    type t = (int * int)
    end;;

module Make = ArrayMatrix.Make(INTPAIR) 

