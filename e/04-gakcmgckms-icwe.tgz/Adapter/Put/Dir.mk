DIR:=Adapter/Put
TARGET:=put
FILES:=
FILES_NOMLI:=put
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
FILES_NOMLI:=$(addprefix out/${DIR}/,${FILES_NOMLI})
-include $(addsuffix .dm,${FILES_NOMLI})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Adapter/Common/common.$(LIB_SUF) out/Api/api.$(LIB_SUF) out/Config/config.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .$(OBJ_SUF),${FILES_NOMLI}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -o $@ unix.$(LIB_SUF) str.$(LIB_SUF) threads.$(LIB_SUF) $^
