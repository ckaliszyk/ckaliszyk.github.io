(** Put model into Overseer
 
    @author Marcin Gozdalik
 *)

open Types_ad;;

(* main function *)
module Put =
  functor (M : Model.MODEL) ->
    struct 

      let model:(unit, M.t) Db.t = 
        (* FIXME *)
        Db.init "bm-model" None

      let put () =
        let input_model = M.input_value stdin
        in Db.set model () input_model
    end
;;

module Putter = Put (UsedModel.Model);;

let main() =
  let config = Config.create "Put" in
  Putter.put ()
;;

main()
