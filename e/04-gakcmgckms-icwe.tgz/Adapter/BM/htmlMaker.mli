(* htmlMaker.ml
   part of the BetterMaker   
   tmp version
*)

open Nethtml

module type HTMLMAKER =
  sig
    type session_t

    val makeLinks : int -> session_t -> Nethtml.document
   (** [makeLinks links_count session] returns an Element "filled" with 
       i links *) 

  end

module Make (U : UrlProposer.URLPROPOSER) (T: Titler.TITLER) : HTMLMAKER
  with type session_t=U.session_t

