open Types_ad

module type TITLER =
  sig
    val get_title : Types_ad.url -> string
  end

module Make : TITLER
