
module type URLPROPOSER =
  sig
    type model_t
    type session_t

    val get_useful_urls : int -> model_t -> session_t -> 
			   Types_ad.url list
  end

    module type MYSET =
      sig
        type key_t
	type set_t

        val set_init : int -> set_t
	val set_add : set_t -> key_t -> float -> unit
	val set_sort : set_t -> int -> Types_ad.url list
      end


    module HashSet : (MYSET with type key_t = Types_ad.url)= 
      struct 
	type key_t = Types_ad.url
	type set_t = (key_t, float) Hashtbl.t

	let set_init size = Hashtbl.create size
    
	let set_add s p currentSavings = 
          let v = try Hashtbl.find s p with Not_found -> 0.0
    	  in Hashtbl.replace s p (v +. currentSavings)

	let toList s =
          let f k v l = (k, v)::l in
          Hashtbl.fold f s []  

	let set_sort s m = 
          let l = toList s in
          let compare a b = 
            if (snd a) = (snd b) then 0 
            else if (snd a) < (snd b) then 1 
            else -1
          in
    	  let ls = List.fast_sort compare l in 
          let rec get_best acc l m = 
            match l with
            | []    -> acc 
    	    | h::tl -> 
	      if m = 0 then acc 
    	      else get_best ((fst h)::acc) (List.tl l) (m-1)
    	  in
    	  List.rev (get_best [] ls m)	   
    end	
    

module Make (S : Session_bm.SESSION) (M : Model.MODEL) : (URLPROPOSER with type model_t = M.t and type session_t = S.t) =
  struct
    
    module P = Predictor.Make(M)
  
    type model_t = M.t
    type session_t = S.t
    

    (** returns list of m pages - links to propose, which provide the highest 
        savings
      @param depth_bound
      @param probability_treshold
      @param t trail observed
      @param pi last page in a trial
      @param m number of links to return
      @param model model
      @return list of best m links
    *)

    let min_path depth_bound probability_treshold t pi m model user =

      (** function, that processes all the pages accessible from some page
        @param pages_and_prob (url, float) list
        @param ps probability of trail suffix
        @param ts trial suffix
        @param l length of ts
        @param s set
      *)
      let rec for_each_link pages_and_prob ps ts l s = 
        match pages_and_prob with
        | [] -> s 
        | q::tl -> 
          let prob_q = snd q in (* probability of page q*)
          let url_q = fst q in (* url of page q *) 
          let tq = ts@[url_q] in 
          let s = expected_savings url_q tq (ps *. prob_q) (l+1) s
          in for_each_link tl ps ts l s

      (** constructs a set of pages uurls with the value of their savings
        @param p current page in recursive page traversal 
        @param t Trail prefix
        @param ts Trail suffix
        @param ps probability of suffix Ts
        @param l length of suffix Ts
        @param s set of shorcut destinations and their savings
        @return set of pages together with their savings
      *)
      and expected_savings p ts ps l s = 
        if (l >= depth_bound) or (ps <= probability_treshold) then s
        else
          let currentSavings = (if (l <= 1) then 0.0 else (ps *. (float (l - 1))))
          in HashSet.set_add s p currentSavings;
          let trail = t@ts in 
          let pages_and_prob = P.predict model user trail in
          for_each_link pages_and_prob ps ts l s
      in
      (* minPath main *)
      let emptySet = HashSet.set_init 10 in
      let s = expected_savings pi [] 1.0 0 emptySet
      in HashSet.set_sort s m

    (**  returns list of m links, which best suit user represented by session 
    and model
      
      @param depth_bound
      @param probability_treshold : float;
      @param m number of links to return
      @param model model
      @param session Types_bm.session
      @return list of m links to add (url, title) list 
    *)
    let get_useful_urls_temp depth_bound probability_treshold m model session =     
      Libdebug.debug ( lazy ( Log.echo "<urlProposer.get_useful_urls>" ));
      let t = S.get_last_episode session in
      Libdebug.debug ( lazy ( 
        Log.echo "epi: ";
        List.iter (fun url -> Log.echo ((Types_ad.string_of_url url)^" ")) t;
      ));
      let pi = List.nth t ((List.length t) -1) in
      let user = "S.get_user session" in
      let rec temp_get_links t pi = 
        let res = min_path depth_bound probability_treshold t pi m model user in
        match res with
        | [] -> 
          let t1 = List.tl t in
          temp_get_links t1 pi
	| _  -> res
      in
      let links = temp_get_links t pi in
      Libdebug.debug ( lazy ( Log.echo "</urlProposer.get_useful_urls>" ));
      S.remove_visited session links
             
    let get_useful_urls links_count model session = 
      let useful_urls = get_useful_urls_temp 3 0.1 links_count model session 
      in useful_urls
  end (* LinkAdder *)
