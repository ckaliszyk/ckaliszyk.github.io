open Types_ad

module type TITLER =
  sig
    val get_title : Types_ad.url -> string
  end

module Make =
  struct
    let get_title url = (string_of_url url)
  end
