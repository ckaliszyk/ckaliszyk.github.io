
module type LINKPROPOSER =
  sig
    type session_t
    type model_t
    type titler_t

    val get_useful_links : int -> model_t -> titler_t -> session_t -> (Types_ad.url*string) list
  end
  
module Make (T: Titler.TITLER) :
  LINKPROPOSER with type session_t = S.t and type model_t = M.t and type titler_t = T.t =
  struct
    
    type session_t = S.t
    type model_t = M.t
    type titler_t = T.t

    module Proposer = UrlProposer.Make(S)(M)
    
    let get_useful_links links_count model titler session = 
      Libdebug.debug ( lazy ( Log.echo "<linkProposer.get_useful_links>" ));
      let useful_urls = Proposer.get_useful_urls links_count model session in
      let useful_ut = List.map (fun u -> (u, (T.get_title titler u))) useful_urls in
      Libdebug.debug ( lazy ( Log.echo "</linkProposer.get_useful_links>" ));
      useful_ut
      
  end   
   
