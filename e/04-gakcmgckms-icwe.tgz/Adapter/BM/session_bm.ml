open Types_ad;;

module type SESSION =
  sig
    type t

    val create : unit -> t

    val get_last_episode : t -> Types_ad.episode
    
    (* tego nie zrobilam
    val get_user : t -> user
*)
    val remove_visited : t -> Types_ad.url list -> Types_ad.url list
    
    val update_session : t -> Types_ad.url -> Types_ad.url -> unit
    
  end

module Make = 
  struct
    type t = { window : (Types_ad.url) Queue.t; 
	       stack: (Types_ad.url) Stack.t;
	     }

    let create () = {
      window = Queue.create();
      stack = Stack.create();
    }

(**
  Returns the longest episode that we can get from user's session.
  The episode is sorted so that the pages visited before are earlier on a list. 
  @param session 
  @return the longest episode 
*)    
    let get_last_episode session = 
      let st = session.stack in
      let rec get acc st =
        try get ((Stack.pop st)::acc) st
        with Stack.Empty -> acc
      in
      get [] (Stack.copy st)


    let queue2list que = 
      let rec q2list l que =
        if Queue.is_empty que then l
        else 
          let top = Queue.take que in
          q2list (top::l) que
      in
      q2list [] (Queue.copy que)

    (**
      @param session
      @param links_list
      @return list of links except those from session window
    *)
    let remove_visited session links_list = 
      let list = queue2list session.window in 
        let rec process_links_list res links_list = 
          match links_list with
          | [] -> res
          | h::tl -> 
            if List.mem h list then process_links_list res tl
            else process_links_list (h::res) tl
      in
      List.rev (process_links_list [] links_list)


    let max_window_size = 10

(** Updates last episode (stack) using url_from->url_to and updates the window
*)
    let update_session session url_from url_to = 
      Libdebug.debug ( lazy ( Log.echo "<update_session>" ));
      let update_stack st url_from url_to =
        begin
          try 
            while Stack.top st <> url_from do 
              ignore (Stack.pop st)
            done
          with 
          Stack.Empty -> ();
        end;
        Stack.push url_to st;
      in
  
      Queue.push url_to session.window;
      if Queue.length session.window > max_window_size then 
        ignore (Queue.take session.window);
      update_stack session.stack url_from url_to;
      Libdebug.debug ( lazy ( Log.echo "</update_session>" ));
  end
