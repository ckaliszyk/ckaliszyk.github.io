open Types_ad

module type URLPROPOSER =
  sig
    type model_t
    type session_t

    val get_useful_urls: int -> model_t -> session_t -> Types_ad.url list
    (** [get_useful_urls depth_bound treshold links_count model session] 
        returns list of [links_count] url addresses to add 
    *) 
end;;

module Make(S : Session_bm.SESSION) (M : Model.MODEL) : URLPROPOSER
  with type session_t = S.t and type model_t = M.t  
