(* htmlMaker.ml
   part of the BetterMaker   
   tmp version
*)
open Types_ad;;
open Nethtml;;

let model_name = "bm-model";;
let titler_name = "bm-titler";;

module type HTMLMAKER =
  sig
    type session_t
    
    val makeLinks : int -> session_t -> Nethtml.document
    
  end

module Make (U : UrlProposer.URLPROPOSER) (T: Titler.TITLER) : (HTMLMAKER with type session_t = U.session_t) =
  struct
    type titler_t = T.t
    type model_t = U.model_t
    type session_t = U.session_t

    module FallbackTitler = NullTitler.Make

    let change_mutex = Mutex.create();;
    let model_changed = ref true;;
    let model_cache = ref [];;
    let titler_changed = ref true;;
    let titler_cache = ref [];;

    let rec model_changer table_name =
      assert (table_name = model_name);
      Mutex.lock change_mutex;
      model_changed := true;
      Mutex.unlock change_mutex;
    and bm_model _ = lazy (
      Db.init model_name (Some(model_changer))
    );;

    let rec titler_changer table_name =
      assert (table_name = titler_name);
      Mutex.lock change_mutex;
      titler_changed := true;
      Mutex.unlock change_mutex;
    and bm_titler _ = lazy (
      Db.init titler_name (Some(titler_changer))
    );;

    let model () = 
      Mutex.lock change_mutex;
      if (!model_changed = true) then begin
        model_cache := [(Db.get (Lazy.force (bm_model())) ())];
        model_changed := false;
      end;
      Mutex.unlock change_mutex;
      List.hd !model_cache
    ;;

    let titler () = 
      Mutex.lock change_mutex;
      if (!titler_changed = true) then begin
        titler_cache := [(Db.get (Lazy.force (bm_titler())) ())];
        titler_changed := false;
      end;
      Mutex.unlock change_mutex;
      List.hd !titler_cache
    ;;

    let makeStrings count session = 
      let rec makeStringsAcc i strList session = 
	match i with 
	| 0 -> strList
	| _ -> makeStringsAcc (i-1) ( (Some("/"), "Strona g��wna")::strList) session
      in

      let add_heuristic count recommended session =
        makeStringsAcc count recommended session
      in

      let panel_link = (Some("/panel"), "Panelik") in
  
      let to_add = 
        match model() with 
        | None -> (
          Log.echo "Warning: no BM model!";
          add_heuristic count [] session
        )
        | Some(model) -> (
          let recommended = U.get_useful_urls count model session in
          let recommended = (
            match titler() with
            | None -> (
              Log.echo "Warning: no BM titler!";
              let t = FallbackTitler.make() in
              List.map (fun url -> (url, (FallbackTitler.get_title t url))) recommended
            )
            | Some(titler) ->
              List.map (fun url -> (url, (T.get_title titler url))) recommended
          ) in
          let len = List.length recommended in
          if (len < count) then
            add_heuristic (count-len) recommended session
          else
            recommended
          )
      in List.rev (panel_link::to_add)
  
    let makeElement linkStrings = 
      let mapper (link, data) = 
        Element("tr", [] , [ Element("td", [] , [
        Element("a", ["href", (string_of_url link)], [Data (data)])])
        ]) 
      in
      let lista = List.map mapper linkStrings in
      Element("table", [], lista)
    
    let makeLinks i clicks = 
      let linkStrings = makeStrings i clicks in 
      makeElement linkStrings
  
  end (*Make*)



