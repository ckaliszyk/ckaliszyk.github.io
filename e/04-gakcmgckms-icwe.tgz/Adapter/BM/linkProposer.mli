(* matches urls with titles*)

module type LINKPROPOSER =
  sig
    type session_t
    type model_t
    type titler_t

    val get_useful_links : int -> model_t -> titler_t -> session_t -> (Types_ad.url*string) list
  end
  
module Make(S : Session_bm.SESSION) (M: Model.MODEL) (T: Titler.TITLER) : LINKPROPOSER
  with type session_t=S.t and type model_t=M.t and type titler_t=T.t
