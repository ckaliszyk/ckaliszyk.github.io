open Types_ad;;

module type SESSION =
  sig
    type t
    
    val create : unit -> t
    
    val get_last_episode : t -> Types_ad.episode
    
    (* tego nie zrobilam
    val get_user : t -> user
    *)
    val remove_visited : t -> Types_ad.url list -> Types_ad.url list
    
    val update_session : t -> Types_ad.url -> Types_ad.url -> unit
    
  end;;

module Make : SESSION;;
  
