(* linkAdder.mli
	part of the BetterMaker
  tmp version
 *)

(** Fills the response with links picked by the BetterMaker *)

module type LINKADDER =
  sig
    type session_t
    val addLinks : Types.request -> Types.response -> unit
    val sessionEnded : string -> unit
  end

module Make(S : Session_bm.SESSION) (M : Model.MODEL) (T: Titler.TITLER)
  : LINKADDER with type session_t = S.t

module Sess : Session_bm.SESSION
module Adder : LINKADDER with type session_t = Sess.t

val init: unit -> Types.sie_module_init
