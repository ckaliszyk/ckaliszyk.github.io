(* linkAdder.mli
	part of the BetterMaker
  tmp version
 *)

open Libdebug;;
open Types_ad;;

(** Fills the response with links picked by the BetterMaker *)

module type LINKADDER =
  sig
    type session_t
    val addLinks : Types.request -> Types.response -> unit
    val sessionEnded : string -> unit
  end

module Make(S : Session_bm.SESSION) (M : Model.MODEL) (T : Titler.TITLER) : LINKADDER with type session_t = S.t =
  struct

    module UP = UrlProposer.Make (S) (M)
    
    module H = HtmlMaker.Make (UP) (T)
  
    type session_t = S.t

    let sessions : (string, session_t) Hashtbl.t = Hashtbl.create 5;;

    let rec insert elem = function
      | Nethtml.Element ("body", args, subnodes) ->
          Nethtml.Element ("body", args, elem::subnodes)
      | Nethtml.Element (name, args, subnodes) ->
          Nethtml.Element (name, args, List.map (insert elem) subnodes)
      | data -> data
    ;;

    let insert response links =
      let parsed = response.Types.html_tree in
      let mapper elem = (insert links elem) in
      let inserted = List.map mapper parsed in
      response.Types.html_tree <- inserted
    ;;

    let new_session request =
      let new_sess = S.create () in
      Hashtbl.replace sessions request.Types.cli_no new_sess;
      new_sess
    ;;

    let sessionEnded cli_no =
      Hashtbl.remove sessions cli_no
    ;;

    let get_session request =
      try
        Hashtbl.find sessions request.Types.cli_no
      with
      | Not_found ->
          new_session request
    ;;

    let addLinks request response =
      debug ( lazy ( Log.echo "<BM>" ));
      let session = get_session request in
      let (_, clicks_count) = Panel.get request.Types.cli_no in
      let url_to =
        match request.Types.file_params with
        | [] -> request.Types.file
        | lst ->
          let rewrite (param, pval) = param ^ "=" ^ pval in
          let strlist = List.map rewrite lst in
          let rest = String.concat "&" strlist in
          request.Types.file ^ "?" ^ rest
      in  
      let url_to = Some(url_to) in
      let url_from = request.Types.from in
      let url_from = if url_from = "" then None else Some(url_from) in
      debug ( lazy ( Log.echo ( 
        Printf.sprintf "from: %s to: %s" (string_of_url url_from) (string_of_url url_to)
      )));
      S.update_session session url_from url_to;
      let links = H.makeLinks clicks_count session in
      debug ( lazy ( Log.echo "</BM>" ));
      insert response links

  end

module Sess = Session_bm.Make
module Adder = Make (Sess) (UsedModel.Model) (UsedModel.Titler)

let config = Config.create "Adapter/BM";;

let init()  = 
  try 
    let sie_mod = {
      Types.name = "BetterMaker";
      Types.supported_content_types = ["text/html"];
      Types.needs_html_tree = true;
      Types.priority_before = 0;
      Types.before = (fun _ -> None);
      Types.priority_after = (int_of_string (Config.get config "BM_PRIORITY"));
      Types.after = Adder.addLinks;
      Types.session_ended = Adder.sessionEnded;
    } in Types.Success(sie_mod)
  with
  | Failure (reason) -> 
      Types.Failed(reason)
;;
