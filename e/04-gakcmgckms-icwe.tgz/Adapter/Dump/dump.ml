(** Dump model from stdin
 
    @author Marcin Gozdalik
 *)

open Types_ad;;
open Printf;;

module Dump =
  functor (M : Model.MODEL) ->
    struct

      let dump model =
        
        let print_page (url, probab) =
          printf "(%s, %f) " (string_of_url url) probab
        in
        
        let print_pages pages =
          List.iter print_page pages;
          print_newline();
        in
        
        let print_epi epi =
          List.iter (fun url -> print_string ((string_of_url url)^" ")) epi
        in
        
        let dump_epi epi =
          printf "epi: [";
          print_epi epi;
          printf "] -> ";
          print_pages (M.predict model epi);
        in

        M.iter model dump_epi
    end
;;

module Dumper = Dump (UsedModel.Model);;

(* main function *)

let main () =
  Dumper.dump (UsedModel.Model.input_value stdin)
;;

main();;

