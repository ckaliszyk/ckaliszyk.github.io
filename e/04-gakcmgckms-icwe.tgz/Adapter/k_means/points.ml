
module type PointType =
  sig
    type t
    val create: int -> t
    val getVal: t -> int -> float
    val setVal: t -> int -> float -> t
    val copy: t -> t 
    val compare: t -> t -> int
  end
  
module type P =
  sig 
    type t
    val compare : t -> t -> int
    val create: int -> t
    val getVal: t -> int -> float
    val setVal: t -> int -> float -> t
    val linearAdd : t -> t -> int -> t
    val linearMinus : t -> t-> int -> t
    val squareAdd : t -> float -> int -> float
    val divide : t -> int -> int -> t 
    val dist : t -> t -> int -> float
    val inside : t -> t -> t -> int -> bool
    val empty : t 
    val is_empty : t -> bool
    val copy : t -> t
  end

  
module Make (Point: PointType) =
  struct
    type t = Point.t
        
    let compare = Point.compare 
    
    let create  = Point.create 
    
    let getVal = Point.getVal
      
    let setVal = Point.setVal

(** Adds two points of dimension d 
    @param p1 - first point; t type
    @param p2 - second point; t type
    @param dim - dimension; int value *)
    let linearAdd p1 p2 dim =
      let rec do_add i new_p =
        match i with
	  | -1 -> new_p
	  | _ -> let v1 = getVal p1 i
	         and v2 = getVal p2 i in 
		 do_add (i-1) (setVal new_p i (v1+.v2))
      in do_add (dim-1) (create dim)

(** Similar to above *)
   let linearMinus p1 p2 dim =
     let rec do_minus i new_p =
       match i with
  	 | -1 -> new_p
	 | _ -> let v1 = getVal p1 i
	        and v2 = getVal p2 i in
	        do_minus (i-1) (setVal new_p i (v1-.v2))
     in do_minus (dim-1) (create dim)

(** Adds a squared value of each coordinate to the given value sum 
    @param p - point; type t
    @param s - int value
    @param dim - dimension of point *)    
    let squareAdd p s dim =
      let rec add_sqr i sum =
        match i with 
	  | -1 -> sum
	  | _ -> let v = getVal p i
	         in add_sqr (i-1) ((v*.v)+.sum) 
      in add_sqr (dim-1) s

(** Divides all the values of the point by a given int value 
    @param p - point
    @param i - int value to be divided by
    @ dim - dimension of the point *)
    let divide p i dim =
      let rec do_div j new_p =
        match j with
	  | -1 -> new_p
	  | _ -> let v = getVal p j in
	         let new_p'= setVal new_p j (v/.(float_of_int i)) in
	         do_div (j-1) new_p'
      in do_div (dim-1) (create dim)

(** Returns a distance between two points 
    @param p1 - first point
    @param p2 - second point
    @param dim - dimension of points *)
    let dist p1 p2 dim =
      let rec so_far i res =
        match i with
	  | -1 -> sqrt res
	  | _ -> let v1 = getVal p1 i
	         and v2 = getVal p2 i
		 in so_far (i-1) ((v1-.v2)*.(v1-.v2))
      in so_far (dim-1) 0.

(** Checks whether a given point is inside a given rectangle 
    @param p - point
    @param min_p - minimal point of the rectangle
    @param max_p - maximal point of the rectangle
    @param dim - dimension *)
    let inside p min_p max_p dim =
      let rec so_far i =
        match i with
	  | -1 -> true
	  | _ -> let v1 = getVal min_p i
	         and v2 = getVal max_p i
		 and v = getVal p i
		 in if (v1 <= v) && (v <= v2) then so_far (i-1)
		    else false 
      in so_far (dim-1)
    
(** An empty point with no dimension *)
    let empty = Point.create 0

(** Checks whether a given point p is an empty point *)
    let is_empty p = let e = empty
                     in  e = p

(** Returns a copy of a point *)
    let copy = Point.copy 
  
  end;;


type pointVal = (int * float)
(** Values stored in PointValSet; 
    int - dimension, 
    float - value stored at this dimension *)

module PointVal =
  struct
    type t = pointVal
    let compare = compare
  end
  
module PointValSet = Set.Make (PointVal)
(** A set of pairs (dim, value*)

(** A  module implementing points as Hashtables *)
module HashedPoint =
  struct

(** At each field a set of pointVal values is stored *)
    type t = (int, PointValSet.t) Hashtbl.t
    
(** Creates a hashtable to represent a point of dimension d *)    
    let create d = if (d < 10) then  Hashtbl.create d
                   else if (d < 100) then Hashtbl.create (d/10)
		   else Hashtbl.create (d/100) 

(** Returns a value on d'st dimension of point p *)
    let getVal p d =
      try let ps = Hashtbl.find p d in 
        let rec check_point set =
	        match PointValSet.is_empty set with
		  | true -> 0.
		  | false -> let (i, f) = PointValSet.choose set in
		             if i = d then f
			     else check_point (PointValSet.remove (i, f) set)
         in check_point ps
      with Not_found -> 0.

(** Sets a new value on d'st dimension of point p *)
    let setVal p d v =
      let p' = Hashtbl.copy p in
      try let ps = Hashtbl.find p' d in 
        let rec check_point set =
	  match PointValSet.is_empty set with
	    | true -> PointValSet.add (d, v) ps
	    | false -> let (i, f) = PointValSet.choose set in
		       if i = d then
		         let s' = PointValSet.remove (i, f) ps 
			 in PointValSet.add (d, v) s' 
		       else check_point (PointValSet.remove (i, f) set)
         in let new_ps = check_point ps 
	 in Hashtbl.replace p' d new_ps;
	    p'
      with Not_found -> 
        let new_ps = PointValSet.add (d, v) (PointValSet.empty) 
        in Hashtbl.add p' d new_ps;
	   p'

(** Returns a copy of a given point p*)
    let copy p = Hashtbl.copy p
    
(** Compares two Hashtables *)
    let compare = Pervasives.compare 
  
  end


module Point = Make(HashedPoint);;

module PointSet = Set.Make (Point);;

