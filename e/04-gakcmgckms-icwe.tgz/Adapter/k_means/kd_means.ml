open Points;;

type node = { 
    m : int; 
    ls: Point.t; 
    ss: float;
    min_point: Point.t; 
    max_point : Point.t;
    split_dim : int; 
    l_tree : kd_tree; 
    r_tree : kd_tree 
}

and kd_tree = 
 | Node of node
 | Leaf of node * PointSet.t
 | Null
;;
  
type centroid = {
    me: Point.t;
    c_m: int; 
    c_ls: Point.t;
    c_ss : float; 
    loose : PointSet.t
    }
;;

(* Returns empty_centoid, just for initialisation *)
let empty_centroid = {
    me = Point.create 0;
    c_m = 0;
    c_ls = Point.create 0;
    c_ss = 0.;
    loose = PointSet.empty
    }
;;
(** Creates a new centroid *)
let create_centroid p dim = {
    me = p;
    c_m = 0;
    c_ls = Point.create dim;
    c_ss = 0.;
    loose = PointSet.empty
    }

(** Returns a set formed of a list
    @param list - point list : Point.t list
    @retunt - set : PointSet.t 
*)
let set_of_list list =
  let rec so_far l s =
    match l with
      | [] -> s
      | p::tl -> so_far tl (PointSet.add p s)
  in so_far list (PointSet.empty)
;;

(** Builds a kd-tree on set of points with a specified maximum leaf_size 
    @param points - set of points : PointSet.t 
    @leaf_size - max leaf size : int 
    @param dim - dimension of points : int
*)
let build_kd_tree points leaf_size dim = 
(* recursive function: 
    @param set - set of points of which the rec funcion is going to build 
		 a subtree : PointSet.t; 
    @par_ls - the parent's value of ls
    @par_ss - the parent's value of ss
    @br_ls - the brothers's value of ls
    @br_ss - the brothers's value of ss, so that the funcion doesn't have to
	    calculate those values for the right son separately
*)
  let rec build_kd set par_ls par_ss br_ls br_ss =
    let m' = PointSet.cardinal set in 
    let (ls', ss') = (* ls and ss values of the node *)
      match br_ss with 
        | -1. -> let rec get_sums p_set l s =
                   match (PointSet.is_empty p_set) with
  	           | true -> (l, s)
	           | false -> let p = PointSet.choose p_set in
	                      get_sums (PointSet.remove p p_set)
		              (Point.linearAdd p l dim) 
	                      (Point.squareAdd p s dim)
                 in get_sums set (Point.create dim) 0. 	 
        | _ -> let l = Point.linearMinus par_ls br_ls dim
	       and s = par_ss -. br_ss
	       in (l, s)
    and (min_p, max_p) = (* min_point and max_point values of the node *)
      let rec find_min_max p_set min max =
	match (PointSet.is_empty p_set) with
	  | true ->  (min, max)
	  | false -> 
	    let p = PointSet.choose p_set in 
	    let rec check_point i p1 p2 =
	      match i with
		| -1 -> find_min_max (PointSet.remove p p_set) p1 p2
		| _ -> let v = Point.getVal p i
		       and v1 = Point.getVal p1 i 
		       and v2 = Point.getVal p2 i in
		       let new_min = if v < v1 then Point.setVal p1 i v
		                     else p1
		       and new_max = if v > v2 then Point.setVal p2 i v
		                     else p2 in
		       check_point (i-1) new_min new_max 
	      in check_point (dim-1) min max 
 
	 in let p = PointSet.choose set in  
         find_min_max (PointSet.remove p set) (Point.copy p) (Point.copy p) 
    in let spl_d = 
         let rec find_split_dim i best v =
	   match i with		
	     | -1 -> best
	     | _ -> let v' = (Point.getVal max_p i) -. (Point.getVal min_p i) in
	            if (v' < v) || (best = dim) then find_split_dim (i-1) i v'
		    else find_split_dim (i-1) best v
	 in find_split_dim (dim-1) dim (-1.) 		

    in    Printf.printf "spl_d = %d\n" spl_d;
      if m' < leaf_size then  (* Return leaf *) 
      Leaf ({	m = m'; 
    		ls = ls'; 
		ss = ss'; 
        	min_point = min_p; 
		max_point = max_p;
		split_dim = spl_d;
		l_tree = Null;
		r_tree = Null
	    },	set)
    else  (* Return node *)
      let (l_set, r_set) = 
      (* Splits set of points in two of the same size: for left and right son *)	
        let rec create_split_set p_list d_list =
          match p_list with
            | [] -> ( 
	      let comp (v1, p1) (v2, p2) = compare v1 v2 in
	      let s_list = List.fast_sort comp d_list in
	      let c = List.length s_list in
	      let (l_list, r_list) = 
	        let rec form_lists i ll rl =
		  match i with
		    | -1 -> let (_, ll_p) = List.split ll 
			    and (_, rl_p) = List.split rl
			    in (ll_p, rl_p)
		    | _ -> let new_el = List.nth s_list i in
			   if (i >= c/2) then form_lists (i-1) ll (new_el::rl)
			   else form_lists (i-1) (new_el::ll) rl
		in form_lists (c-1) [] []
	      in let l_s = set_of_list l_list
	         and r_s = set_of_list r_list
	      in (l_s, r_s)
	    )    
	    | p::tl -> let v = Point.getVal p spl_d  
		       in create_split_set tl ((v, p)::d_list)
		       
       in let point_list = PointSet.elements set in
         create_split_set point_list [] 
     in 
     (* Call rec funcion buliding a kd_tree on left son*)
     let l_tree'= build_kd l_set ls' ss' Point.empty (-1.) 
     in 
        let node = match l_tree' with
          | Node n -> n
	  | Leaf (n, _) -> n
	  | Null -> failwith "Empty node\n"
     in let son_ls = node.ls
        and son_ss = node.ss
     in
     (* Call rec funcion buliding a kd_tree on right son*)
     let r_tree' = build_kd r_set ls' ss' son_ls son_ss 
     in 
     Node {	m = m'; 
    		ls = ls'; 
		ss = ss';
        	min_point = min_p; 
		max_point = max_p;
		split_dim = spl_d;
        	l_tree = l_tree'; 
		r_tree = r_tree'
	  }
  in 
  (* split dimension by witch the split of the set is done *) 
  let split_dim = Random.int dim 
  in build_kd points Point.empty (-1.) Point.empty (-1.)
;;


(** Return a shortest distance to the rectangle of points stored in the node
    from a given point
    @param node - node : node
    @param p - point : Point.t
    @param dim - dimension of point : int 
*)
let min_dist node p dim = 
  let min_p = node.min_point
  and max_p = node.max_point in
  match (Point.inside p min_p max_p dim) with
    | true -> 0.
    | false -> 
      let rec closest res i =
        match i with 
          | -1 -> res
          | _ -> 
            let v1 = Point.getVal min_p i
            and v2 = Point.getVal max_p i 
	    and v = Point.getVal p i in
	    let x = if (v <= v1) then v1
	      else if (v >= v2) then v2
	      else v
            in closest (Point.setVal res i x) (i-1)
        in let c = closest (Point.create dim) (dim-1)
      in Point.dist p c dim
;;

(** Return a longest distance to the rectangle of points stored in the node
    from a given point, which is one of the rectangle corners.
    @param node - node : node
    @param p - point : Point.t
    @param dim - point dimension : int
*)
let max_dist node p dim= 
  let min_p = node.min_point
  and max_p = node.max_point in
  let rec furthest res i =
    match i with 
      | -1 -> res
      | _ -> let v1 = Point.getVal min_p i
             and v2 = Point.getVal max_p i 
	     and v = Point.getVal p i in
             let abs_v1 = if (v-.v1) >= 0. then v-.v1 else v1-.v
	     and abs_v2 = if (v-.v2) >= 0. then v-.v2 else v2-.v in
	     if (abs_v1 > abs_v2) then furthest (Point.setVal res i v1) (i-1)
	     else furthest (Point.setVal res i v2) (i-1)
    in let f = furthest (Point.create dim) (dim-1)
  in Point.dist p f dim
;;

(** Return a number of nearest centroid from a list to a given point
    @param p - point : Point.t
    @i_list - list of centroids numbers to check : int list 
    @prototypes - an array of centroids : centroid array
    @dim - point dimension : t
*)
let nearest_cent p i_list prototypes dim =
  let rec so_far list best_p best_d =
    match list with 
      | [] -> best_p
      | i::tl ->let c = Array.get prototypes i in 
	        let d = Point.dist p c.me dim in
	        if d < best_d then so_far tl i d
		else so_far tl best_p best_d
  in try let i' = List.hd i_list in
     let c' = Array.get prototypes i' in
     let d' = Point.dist p c'.me dim
     in so_far (List.tl i_list) i' d'
  with Failure "hd" -> raise Not_found
;;

(** Pruns out centroids that are too far to be the closest to the points stored
    in a given subtree
    @param tree - kd_tree
    @param alive_list - a list of numbers of centroids to check : int list
    @param dim - points dimension : int
    @prototypes - an array of centroids : centroid array
*)
let pruning tree alive_list dim prototypes= 
  let node = 
    match tree with
      | Node n -> n
      | Leaf (n, s) -> n
      | Null -> failwith "Null node\n"
  in  
  let (min_max_list) =
    let rec min_max list min_max_l =
      match list with
        | [] -> min_max_l
        | i::tl -> let p = Array.get prototypes i in
	           let min_el = min_dist node p.me dim
                   and max_el = max_dist node p.me dim
	           in min_max tl ((min_el, max_el, i)::min_max_l)
    in min_max alive_list [] in 

  let min_max_dist = 
    let rec find_min list mm =
      match list with
        | [] -> mm
        | (_, new_m, _)::tl -> if new_m < mm then find_min tl new_m
	                       else find_min tl mm
    in let (_, mm', _) = List.hd min_max_list in 
      find_min (List.tl min_max_list) mm' in
  let rec alive list i res =
    match list with
     | [] -> res
     | (min_el, _, j)::tl ->
         if min_el > min_max_dist then alive tl (i+1) res
         else alive tl (i+1) (j::res)
    in alive min_max_list 0 []
;;

(** One iteration of k-means algorithm
    @param tree - kd_tree
    @alive_list - list of cenroids to check : int_list
    @dim - points dimension : int
    @prototypes - an array of centroids : centroid array
    @return - the actualized array of centroids 
*)
let rec traverse_tree tree alive_list dim prototypes =
  let alive = pruning tree alive_list dim prototypes in
  if (List.length alive = 1) then 
  (* No need to go down, we already have one centroid which seems to be the owner
     (the closest centroid) of all points stored in the tree *)
    let node = match tree with
                 | Node n -> n
		 | Leaf (n,l) -> n
		 | Null -> failwith "Empty tree -> No points to cluster\n"
	       in
    let m' = node.m
    and ls' = node.ls
    and ss' = node.ss
    and i = List.nth alive 0 in
    let c = Array.get prototypes i in
    let new_c = { me = c.me; 
		  c_m = m' + c.c_m; 
                  c_ls = Point.linearAdd ls' c.c_ls dim; 
                  c_ss = ss' +. c.c_ss;
		  loose = c.loose
		}
    in Array.set prototypes i new_c;
       prototypes
  (* We still don't have the owner of the set of points stored in the tree *)
  else match tree with
    | Leaf (_, point_set) -> 
    (* The node is a leaf, so we need to find a nearest centroid to each point
    in the point_set separetely*)
        let rec assign_c p_set =
          match (PointSet.is_empty p_set) with
	    | true -> ()
            | false -> 
	      let p = PointSet.choose p_set in
	      let i = nearest_cent p alive prototypes dim in 
	      let c = Array.get prototypes i in
	      let new_c = {	me = c.me; 
	    			c_m = c.c_m+1; 
		        	c_ls = Point.linearAdd p c.c_ls dim;
		        	c_ss = Point.squareAdd p c.c_ss dim;
				loose = PointSet.add p c.loose
			  }
	      in Array.set prototypes i new_c;
	         assign_c (PointSet.remove p p_set)
	in assign_c point_set;
	prototypes
        
    | Node node -> 
    (* The node is not a leaf, so we call a fuction to its sons *)
        let new_pr= traverse_tree node.l_tree alive dim prototypes 
        in traverse_tree node.r_tree alive dim new_pr
    | Null -> failwith "Empty tree -> No points to cluster\n"
;;

(** Gathers the points that belong to each centroid and retrns them in an array
    @param tree - kd_tree
    @param dim - points dimension : int
    @param centroids - centroid array
*)
let gather_points tree dim centroids =
  let k = Array.length centroids in
  let res_arr = Array.create k (PointSet.empty) in
  (* First fills the array with the loose points of each centroid *)
  let rec fill_loose_points i =
    match i with
      | -1 -> ()
      | _ -> let c = Array.get centroids i in
             Array.set res_arr i c.loose;
	     fill_loose_points (i-1)
  in fill_loose_points (k-1);
  
  (* Then fills the array with the rest...*)
  let rec rec_gather_points tree alive_list =
  (* Calls the pruning function to obtain a new alive list *)
    let alive = pruning tree alive_list dim centroids in
  (* If an unique centroid is left then fills the array with all the points 
  from the subtree *)
    if (List.length alive = 1) then
      let c_num = List.nth alive 0 in
      let c = Array.get centroids c_num in
        match tree with
        | Node n -> let rec gather_node kd_tree = 
	              match kd_tree with
	                | Leaf (n', l') -> 
			  let set = Array.get res_arr c_num in 
			  let set' = PointSet.union set l' in
			  Array.set res_arr c_num set'
			| Node n -> gather_node n.l_tree;
			           gather_node n.r_tree
			| Null -> failwith "Null node"
		    in gather_node tree 
	| Leaf (n,l) -> let set = Array.get res_arr c_num in
	                let set' = PointSet.union set l in
			Array.set res_arr c_num set'
	| Null -> failwith "Null node"
	
(* Otherwise calls a recursive function on it's sons *)
    else match tree with
      | Leaf (_, l) -> ()    
      | Node n -> rec_gather_points n.l_tree alive;  
                  rec_gather_points n.r_tree alive 
      | Null -> failwith "Null node"
  in 
  let alive_list = 
    let rec do_list i l =
      match i with
        | -1 -> l
        | _ -> do_list (i-1) (i::l)
    in do_list (k-1) [] 
  in rec_gather_points tree alive_list;
  res_arr
;;


(* A main function which clusters the given set of points 
    @param k - a number of clusters : int
    @param dim - a dimension of points : int
    @param leaf_size - a size of life in a kd_tree, should be >=2 : int
    @param points - a set of points : PointSet.t 
    @param initFunc - a funcion that will initialize the centroids :
		    int -> int -> PointSet.t -> centroid array
    @return PointSet.t array * centroid array
*)
let k_means k dim leaf_size points initFunc = 
  let prototypes = initFunc k dim points in
  let kd_t = build_kd_tree points leaf_size dim in 
(* An int list of 1,...,k needed by traverse tree fuction *) 
  let alive = 
    let rec do_list i l =
      match i with
        | -1 -> l
        | _ -> do_list (i-1) (i::l)
    in do_list (k-1) [] 
  in 
  
  let rec do_cluster pr prev_distortion =
    let res_pr = traverse_tree kd_t alive dim (Array.copy pr) in
    (* Counts distortion value*)
    let distortion = 
      let rec count_it i sum =
        match i with 
	| -1 -> sum
	| _ -> 
	  let c = Array.get res_pr i in
	  match c.c_m with
	  | 0-> count_it (i-1) sum
	  | _-> 
	    let s = (Point.squareAdd c.c_ls 0. dim) in
	    match s with
	    | 0. -> count_it (i-1) sum;
	    | _ -> let s' = s/.(float_of_int(c.c_m)) in    
		   let x = c.c_ss -. s' 
	    in count_it (i-1) (sum+.x)
      in count_it (k-1) 0.
    in 
    (* If it's the same as the previous one then return*)
       match (compare prev_distortion distortion) with
	 | 0 -> Printf.printf "Distortion = %f\n" distortion;
		res_pr
	 | _ -> 
	 (* otherwise next iteration *) 
	   let new_pr =  
	   (* Get a new set of centroids of the previous one *)
             let rec recalculate_cent i pr =
               match i with
                 | -1 -> pr
	         | _ -> let c = Array.get pr i in
	                let new_me = if c.c_m = 0 then c.me
			             else Point.divide c.c_ls c.c_m dim in
	                let new_c = create_centroid new_me dim in 
			Array.set pr i new_c;
	                recalculate_cent (i-1) pr
            in recalculate_cent (k-1) (Array.copy res_pr) 
          in do_cluster new_pr distortion
  in let centers = do_cluster prototypes 0. in
  let p_arr = gather_points kd_t dim centers in
  (p_arr, centers)
;;

(* Return an array of k somehow chosen centroids 
    @param k - number of centoids to return : int
    @param dim - dimension of points : int
    @param points - set of points : PointSet.t
    @return - centroid array
*)
let simpleInitCentroids k dim points =
  let c_arr = Array.create k empty_centroid in
  let c = PointSet.cardinal points in
  let d = c/k in
  let p = if d > 1 then d/2 - 1 
          else 0
  in
  let p_list = PointSet.elements points in 
    let rec so_far i =
      match i with
        | 0 -> ()
	| _ -> let el = List.nth p_list (p + (k-i)*d) in 
	       Array.set c_arr (i-1) (create_centroid el dim);
	       so_far (i-1)  
    in so_far k;
       c_arr  
;;

(* A function more complex than above. Returns an array of k smartly chosen 
centroids by taking subsamples and so on. In fact doesn't work any better,
but perhaps will on a real data... 
    @param k - number of centoids to return : int
    @param dim - dimension of points : int
    @param points - set of points : PointSet.t
    @return - centroid array
*)
let initCentroids k dim points =
  let c = (PointSet.cardinal points) / 10 in (* Size of subsamples -10% *)
  if c < k (* No need to refine the simple algorithm *) 
    then simpleInitCentroids k dim points
  else let j = min (c/k) 10 in (* Number of subsamples *) 
 
  Printf.printf "c = %d, k = %d, j =%d\n" c k j ;
  Random.init (int_of_float (Unix.gettimeofday()));
  let s_arr = (* An array of j subsamples : PointSet.t array *)
    let p_list = PointSet.elements points in
    let rec choose_sub_samples i s_arr =
      match i with
      | -1 -> s_arr
      | _ -> let rec fill_set n set =
    	     let r = Random.int 10 in
    	       if (n+(r*j)) >= List.length p_list then Array.set s_arr i set
	       else let p = List.nth p_list (n+(r*j)) in
	       fill_set (n+(j*10)) (PointSet.add p set) 
	     in fill_set i PointSet.empty;
	     choose_sub_samples (i-1) s_arr
      in choose_sub_samples (j-1) (Array.create j PointSet.empty) in
(* An array of centroids which are solutions of clustering of each subsample,
  A set of all points which are centroids of each subsample *)      
  let (c_arr, c_set) =
    let c_arr = Array.create j (Array.create k empty_centroid) in
    let rec cluster_samples i c_set = 
      match i with
      | -1 -> (c_arr, c_set)
      | _ -> let smp_points = Array.get s_arr i in
    	     let (_, cl_arr) = k_means k dim 4 smp_points simpleInitCentroids in 
             (* cl_arr = centroid array *)
	     let c_set' = 
	       let rec clean_centroids n set =
	         match n with
	           | -1 -> Array.set c_arr i cl_arr;
		  	   set
		   | _ -> let cent = Array.get cl_arr n in 
		          Array.set cl_arr n (create_centroid cent.me dim);
			  clean_centroids (n-1) (PointSet.add cent.me set)
	       in clean_centroids (k-1) c_set
	     in cluster_samples (i-1) c_set'
     in cluster_samples (j-1) (PointSet.empty) in
  Printf.printf "|c_set| = %d\n" (PointSet.cardinal c_set); 
    
  let centroids =  (*Final best centroid array *)
    let rec cluster_again i best best_dist =
      match i with
      | -1 -> Printf.printf "Best dist = %f\n\n" best_dist;
              let rec clean_best n =
	        match n with
	        | -1 -> best
	        | _ -> let cent = Array.get best n in 
		       Array.set best n (create_centroid cent.me dim);
		       clean_best (n-1)
	      in clean_best (k-1);
      | _ ->
        let initCent k dim c_set = Array.get c_arr i in
        let (_, cent_arr) = k_means k dim 4 c_set initCent in 
        let dist =
	  let rec distortion n sum =
	    match n with
	    | -1 -> sum
	    | _ -> let c = Array.get cent_arr n in
	           match c.c_m with
		   | 0 -> distortion (n-1) sum 
		   | _ -> let s = Point.squareAdd c.c_ls 0. dim in
		          match s with
			  | 0. -> distortion (n-1) sum
			  | _ ->
		            let s' = s/.float_of_int(c.c_m) in
			    let x = c.c_ss -. s'
			    in distortion (n-1) (sum+.x)
	  in distortion (k-1) 0.
	in if (dist < best_dist) || (best_dist < 0.) 
	     then cluster_again (i-1) cent_arr dist 
	   else cluster_again (i-1) best best_dist
    in cluster_again (j-1) (Array.create k empty_centroid) (-1.) 
  in centroids
;;


(* Ponizej do testowania *)		 
let make_set dim n =
  Random.init (int_of_float (Unix.gettimeofday ()));
  let rec so_far i set=
    match i with
      | 0 -> set
      | _ ->  let rec fill_point j p =
		match j with
		  | -1 -> p
		  | _ -> let m = (Random.int 2) in
			 let x = Random.float 100. in
			 if ((int_of_float x) mod 2) <> m 
			   then fill_point (j-1) p
			 else fill_point (j-1) (Point.setVal p j x) 
	      in let point = fill_point (dim-1) (Point.create dim) in
	      so_far (i-1) (PointSet.add point set)
  in so_far n (PointSet.empty);; 

let main () =   
  let dim = 300
  and no_points = 100
  and k = 5
  and leaf_size = 16 in 
  let points = make_set dim no_points in
  Printf.printf "1: |set| = %d\n" (PointSet.cardinal points);
  let (p_arr, c_arr) = k_means k dim leaf_size points initCentroids in
  let rec wypisz i =
    match i with
    | 0 -> ()
    | _ -> let set = Array.get p_arr (i-1) in 
	   Printf.printf "%i -> %i\n" i (PointSet.cardinal set); 
	   wypisz (i-1)
  in wypisz k
;;

main ()
;;