module type PointType =
  sig
    type t
    (** The type representing point *)
    
    val create: int -> t
    (** Return a new point *)
    
    val getVal: t -> int -> float
    (** Return the value on the given coordinate of the point *)
    
    val setVal: t -> int -> float -> t  
    (** Set the given value on the given coordinate of the point and return the new point *)
    
    val copy : t -> t
    (** Return a copy of the given point *)
    
    val compare : t -> t -> int
    (** Compare two points *)    
  end
(** Input signature of the functor Point.Make *)    


module type P =
  sig 
    type t
    (** The type of the point representation *)

    val compare : t -> t -> int
    (** The compare function *)
    
    val create: int -> t
    (** Return an empty point with a given dimenstion *)

    val getVal: t -> int -> float
    (** Call getVal fuction from point representation *)
    
    val setVal: t -> int -> float -> t
    (** Set given value *)
    
    val linearAdd : t -> t -> int -> t
    (** Add two points *)
    
    val linearMinus : t -> t-> int -> t

    val squareAdd : t -> float -> int -> float
    (** Add squared values of all dimensions to a given float value *)

    val divide : t -> int -> int -> t 
    (** Divide all values on all dimensions of the given point with the given value *)    

    val dist : t -> t -> int -> float
    (** Return euclidean distance between the given points *)
    
    val inside : t -> t -> t -> int -> bool
    (** Check whether the given point is inside a given rectangle represented by two poins *)
    
    val empty : t 
    (** Return an empty point (with dimension 0)*)
    
    val is_empty : t -> bool
    (** Check whether a given point is the empty point *)
    
    val copy : t -> t
    (** Return a point copy*)
  end

module HashedPoint : PointType

module Point : P 

module PointSet : Set.S with type elt = Point.t

module Make (Pt : PointType) : P 

(** Functor building the implementation of listed above point operations 
    given a point type *)
    
