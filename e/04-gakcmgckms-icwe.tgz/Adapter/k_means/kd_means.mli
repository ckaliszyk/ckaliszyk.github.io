open Points;;

(** The type of node in kd_tree*)
type node = { 
    m: int; 		(** number of points in the node *) 
    ls: Point.t ; 	(** the linear sum of the points in the node *)
    ss: float;	 	(** the square sum of the points in the node *)
    min_point: Point.t; (** the minimal point in the node *)
    max_point: Point.t; (** the maximal point in the node *)
    split_dim : int;	(** the "widest" dimension *)
    l_tree: kd_tree; 	(** left son of the node *)
    r_tree: kd_tree 	(** right son of the node *)
    }
    
(** The kd_tree type*)
and kd_tree = 
 | Node of node			(** internal tree node *)
 | Leaf of node * PointSet.t	(** leaf consisting of node and Set of points *)
 | Null				(** Artificial value - sons of leafs *)
;;
  
type centroid = {
    me: Point.t; 	(** the centroid's point *)
    c_m: int; 		(** number of points assign to this centroid *)
    c_ls : Point.t; 	(** the linear sum of the points assigned to centroid *)
    c_ss: float;	(** the square sum of the points assigned to centroid *)
    loose : PointSet.t	(** the loose point that need to be clustered separately *)
    }
;;
 
(** Returns a list of a given set of points *)
val set_of_list : Point.t list -> PointSet.t

(** Returns a kd_tree of a given set of points, dimension and leaf size*)
val build_kd_tree : PointSet.t -> int -> int -> kd_tree

(** Returns a minimal distance between a point and node *) 
val min_dist : node -> Point.t -> int -> float 

(** Returns a maximal distance between a point and node *)  
val max_dist : node -> Point.t -> int -> float

(** Returns a nearest centroid for a given point *)
val nearest_cent : Point.t -> int list -> centroid array -> int -> int

(** Pruns out all the centroids that schould not be cosidered as the closest
    to the nodes of the given subtree, and returns a list of possible owners
    (centroids) *)
val pruning : kd_tree -> int list -> int -> centroid array -> int list 

(** One iteration of k_means algorithm *)
val traverse_tree : kd_tree -> int list -> int -> centroid array -> 
centroid array 

(** Gathers points that belong to each centroid and returns them into an array*)
val gather_points : kd_tree -> int -> centroid array -> PointSet.t array

(** Calls build_kd_tree then performs clustering by k_means and measuring
    distortion (clustering quality) after each iteration; if this value doesn't
    change call gather_points functions and returns *)
val k_means : int -> int -> int -> PointSet.t -> 
    (int -> int -> PointSet.t -> centroid array) -> 
    PointSet.t array * centroid array

(** Choses the initial centroid points of clustering *)
val simpleInitCentroids : int -> int -> PointSet.t -> centroid array

(** Choses the initial centroid points of clustering, more complex than
simpleInitCentroids *)
val initCentroids : int -> int -> PointSet.t -> centroid array