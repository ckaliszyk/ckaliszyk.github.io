(** Implementation of LOG2EPI module

    @author Janusz Dutkowski)
*)

open Types_ad


(* TBD: choosing between a couple of types of episodes*) 

(** calls function func for all strings in episode passing on par

    @param epi Episode
    @param lastUurl Last element of original episode
    @param epiLen length of episode
    @param maxLen max length of string
    @param func function to be called for each string
    @param parameters passed on to func
*) 


module Make : Log2epi.LOG2EPI =
struct

let processEpisodes func maxLen epi par =
  
  let rec write_epi epi =
    match epi with
	[] -> print_newline();
	| h::t -> let _ =match h with 
          Some(url) -> print_string (url ^ " ");
         | None -> print_string "None " in 
	write_epi t
    
  in
  
  let rec prEpiLn list lastUurl ln lst epiLen pos maxLen func par= 
    match list with
      []-> () |
      (h::t)-> if (ln <= maxLen) then 
                 let lst = (h::lst) in 
		 let lst = (List.rev lst) in
                 let _ = write_epi lst in
                 func lst lastUurl ln (*(epiLen-(pos+ln))*) par;
                 prEpiLn t lastUurl (ln+1) lst epiLen pos maxLen func par
            else ()
  in
    
  let rec prEpi list lastUurl epiLen pos maxLen func par= 
    match list with
      []-> ()|
      h::t-> 
        prEpiLn list lastUurl 1 [] epiLen pos maxLen func par;
        prEpi t lastUurl epiLen (pos+1) maxLen func par
  in
  
  match epi with
  | [] -> assert false
  | h::t ->(let lastUurl = h in 
	    let epi = List.rev t in 
  let epiLen = List.length epi in

prEpi epi lastUurl epiLen 1 maxLen func par)


(** calls processEpi for all episodes in session passing on maxLen, func, and par 
    
    @param session Session to be processed
*)
let processSession session func par= 
  
(*  Printf.printf "processSession\n";*)
  
  let rec prSess session epi epiLen = 
    match session with 
      Leaf-> ()| (*shouldn't happen*)
      Node(u, [])-> func (u::epi) par | 
      Node(u, (h::t))-> 
          prSess h (u::epi) (epiLen+1);
          match t with 
            []-> ()|  (*tu decyzja ze biezemy pod uwage tylko ostatni url w epizodzie*)
            h1::t1-> prSess (Node(u, t)) epi epiLen
  in
prSess session [] 1  


(** calls processSession for all sessions in log passing on maxLen, func, and par 
    
    @param log List of sessions
*)

let rec processLog log func maxLen par =
  List.iter (fun h -> ignore (processSession h (processEpisodes func maxLen) par)) log


end
