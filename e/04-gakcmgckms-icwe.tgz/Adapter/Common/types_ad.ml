open Unix;;

(** Date type *)
type date = { 
  d: int; (** day *)
  m: int; (** month *)
  y: int; (** year *)
};;

(** denotes a Resource in the site
 *)
type url = string option;;

(** a single episode
*)
type episode = url list;;

(** a tree of URLs visited
 *)
type session = 
  | Leaf (** leaf in the tree *)
  | Node of (url * session list);; (** a node in the tree: contains an URL and arbitrary many sons *)

(** a group of sessions (a forest) *)
type log = session list;;

let string_of_url url = 
  match url with 
  | None -> "empty_url"
(*  | None -> ""*)
  | Some (url) -> url
;;

(** print session tree on standard output

    @param ses session
 *)
let print_ses ses =
  
  let printnspaces n = print_string (String.make n ' ') in
  
  let rec print_node ses n =
    printnspaces n;
    match ses with
    | Leaf -> print_endline("Leaf");
    | Node (url, sons) -> (
      Printf.printf "Node(%s)\n" (string_of_url url);
      List.iter (fun ses -> print_node ses (n+1)) sons;
    )
  in
    
  print_node ses 0;
;;

let date_of_string str =
  let make_date day mon year = { d=day; m=mon; y=year; } in
  let ret = try Scanf.sscanf str "%i/%i/%i" make_date with 
  | Scanf.Scan_failure _ -> failwith "Illegal date format"
  | Failure _ -> failwith "Illegal date"
  | End_of_file -> failwith "Too short a date";
  in if ret.y < 1995 || ret.y > 2100 then failwith "Illegal year"
  else let feb_days = (match ret.y mod 4 with 
    | 0 -> (match ret.y mod 100 with
            | 0 -> (match ret.y mod 400 with | 0 -> 29 | _ -> 28)
            | _ -> 29
           )        
    | _ -> 28
  ) in if ret.m < 1 || ret.m > 12 then failwith "Illegal month"
  else if ret.d < 1 || ret.d > 
    (match ret.m with 
    | 1 -> 31
    | 2 -> feb_days
    | 3 -> 31
    | 4 -> 30
    | 5 -> 31
    | 6 -> 30
    | 7 -> 31
    | 8 -> 31
    | 9 -> 30
    | 10 -> 31
    | 11 -> 30
    | 12 -> 31
    | _ -> 31
    ) then failwith "Illegal day"
  else ret
;;

let string_of_date d =
  Printf.sprintf "%i/%i/%i" d.d d.m d.y
;;

let date_of_tm tm =
  { d = tm.tm_mday; m = tm.tm_mon+1; y = tm.tm_year+1900; }
;;

let compare_date d1 d2 =
  if d1.y < d2.y then -1
  else if d1.y > d2.y then 1
  else if d1.m < d2.m then -1
  else if d1.m > d2.m then 1
  else if d1.d < d2.d then -1
  else if d1.d > d2.d then 1
  else 0
;;

