(** A simple debugging library

    @author Marcin Gozdalik
*)

(** Controls execution of debug function
    Set to 1 if you want all debug functions executed
*)
val do_debug : int ;;

(** Guard function for your debug functions
    Rememeber that the parameter should be made {b lazy}
    Usage: [debug(lazy(your_function_here));]
*)
val debug : unit Lazy.t -> unit ;;
