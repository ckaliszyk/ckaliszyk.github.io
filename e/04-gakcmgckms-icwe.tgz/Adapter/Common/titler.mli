(** Specification of module which gives titles to plain URLs

    @author Marcin Gozdalik
 *)

open Types_ad;;

module type TITLER =
  sig
    type t

    val make: unit -> t
    (** [make] creates the titler (initially empty)
    *)
    
    val teach : t -> (string * string) list -> unit
    (** [teach model titles] teaches [model] (thus modifying it in-place) using
        pairs (URL, title) on [titles] list.
    *)
    
    val get_title : t -> Types_ad.url -> string
    (** [get_title model url] returns title inferred by the [model].
    *)

    val output_value: t -> out_channel -> unit
    (** [output_value titler output] outputs marshalled [titler] to [output]
        making it possible to save [titler] for future work (e.g. to use it in
        another application). Only objects which are necessary for proper
        functioning of [get_title] should be left before outputting [titler] (any
        temporary objects created during model teaching and validation phases
        should be discarded).
    *)

    val input_value: in_channel -> t
    (** [input_value input] reads marshalled titler from [input]. Read titler
        allows only to [get_title] ([teach] won't work and its behavior is undefined).
    *)
  end
