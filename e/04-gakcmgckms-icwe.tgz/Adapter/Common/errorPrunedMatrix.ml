(** Implementation of Error-Pruned Markov Matrix (with overall pruning)

    @author Marcin Gozdalik
 *)

open KeyVal;;
open Libdebug;;
open Types_ad;;

module Make =
  functor (K : KEYVAL) ->
  functor (V : KEYVAL) -> 
  (struct

    module OrderedValFloat =
      struct
        type t = (V.t * float)
        let compare (_, f1) (_, f2) =
          if (f1 < f2) then -1
          else if (f1 > f2) then 1
          else 0
      end;;

    module ValFloatSet = Set.Make (OrderedValFloat);;

    type key = K.t
    type value = V.t
    type table_off = ((key * value), int) Hashtbl.t
    type table_total = (key, int) Hashtbl.t
    type table_on = (key, ValFloatSet.t) Hashtbl.t
    type table_on_list = (key, OrderedValFloat.t list) Hashtbl.t
    type t = { 
      offline : table_off; 
      error : table_off;
      total_off : table_total;
      total_error : table_total;
      online : table_on;
      online_list : table_on_list;
      mutable got_online : bool;
      mutable got_online_list : bool;
      mutable grand_total : float;
      threshold : float;
    }

    let make t = {
      offline = Hashtbl.create 100;
      error = Hashtbl.create 100;
      total_error = Hashtbl.create 100;
      total_off = Hashtbl.create 100;
      online = Hashtbl.create 100;
      online_list = Hashtbl.create 100;
      got_online = false;
      got_online_list = false;
      grand_total = 0.0;
      threshold = t;
    }

    let get_from_table table k not_found =
      try Hashtbl.find table k
      with Not_found -> not_found

    let set_in_table table k v =
      Hashtbl.replace table k v

    let inc_elem table elem =
      let cur = get_from_table table elem 0
      in Hashtbl.replace table elem (cur+1)

    let add matrix k v = 
      inc_elem matrix.offline (k, v);
      matrix.grand_total <- (matrix.grand_total+.1.0);
      inc_elem matrix.total_off k

    let get_total matrix k =
      get_from_table matrix.total_off k 1

    let get_freq matrix k v =
      get_from_table matrix.offline (k, v) 0

    let get_grand_total matrix =
      matrix.grand_total
      
    let find_probab matrix k v =
      let total = get_total matrix k in
      let val_freq = get_freq matrix k v in
      ((float_of_int val_freq) /. (float_of_int total))

    let get_val_set matrix k =
      try Hashtbl.find matrix.online k 
      with Not_found -> ValFloatSet.empty
  
    let make_online matrix =
      let f (k, v) count = 
        (* we could use find_probab but we already have count given as parameter
         * to f, so we just grab total and do the division *)
        let count_float = (float_of_int count) in
        let total = get_total matrix k in
        let total_float = (float_of_int total) in
        let probab = count_float /. total_float in
        let grand_total = get_grand_total matrix in
        let support = count_float /. grand_total in
        debug ( lazy (
          Printf.printf "support==%f, probab==%f\n" support probab
        ));
        if support > matrix.threshold then (
          debug ( lazy (
            Printf.printf "going in (threshold==%f)\n" matrix.threshold;
          ));
          let val_set = get_val_set matrix k in
          let val_set2 = ValFloatSet.add (v, probab) val_set in
          Hashtbl.replace matrix.online k val_set2
        ) else (
          Hashtbl.remove matrix.offline (k, v)
        )
      in Hashtbl.iter f matrix.offline

    let make_online_list matrix =
      let f elem s =
        let rec add_lowest l s =
          try 
            let lowest = ValFloatSet.min_elt s in
            add_lowest (lowest::l) (ValFloatSet.remove lowest s)
          with Not_found -> l
        in Hashtbl.replace matrix.online_list elem (add_lowest [] s)
      in Hashtbl.iter f matrix.online

    let predict matrix k =
      let val_set = get_val_set matrix k in
      let max = ValFloatSet.max_elt val_set in
      fst max

    let inc_error matrix (k, v) =
      inc_elem matrix.error (k, v);
      inc_elem matrix.total_error k
      
    let check_online matrix =
      if not matrix.got_online then begin
        make_online matrix;
        matrix.got_online <- true;
      end

    let check_online_list matrix =
      check_online matrix;
      if not matrix.got_online_list then begin
        make_online_list matrix;
        matrix.got_online_list <- true;
      end

    let validate matrix k v =
      check_online matrix;
      try 
        inc_elem matrix.total_error k;
        let predicted = predict matrix k in
        if v <> predicted then (inc_error matrix (k, v))
      with 
        Not_found -> (inc_error matrix (k, v))

    let prune matrix k v =
      Hashtbl.remove matrix.offline (k, v)

    let error_rate matrix k v =
      let count = get_from_table matrix.error (k, v) 1 in
      let count_float = (float_of_int count) in
      let total = get_from_table matrix.total_error k 1 in
      let total_float = (float_of_int total) in
      count_float /. total_float

    let error_iter matrix f =
      let g (k, v) count =
        let total = get_from_table matrix.total_error k 1 in
        let total_float = (float_of_int total) in
        f (k, v) ((float_of_int count) /. total_float)
      in Hashtbl.iter g matrix.error 

    let iter matrix f =
      make_online_list matrix;
      Hashtbl.iter (fun k _ -> f k) matrix.online_list 

    let predict_all matrix k =
      check_online_list matrix;
      try Hashtbl.find matrix.online_list k 
      with Not_found -> []

    let output_value matrix out_channel =
      check_online_list matrix;
      output_value out_channel matrix.online_list

    let input_value in_channel = {
      offline = Hashtbl.create 1;
      error = Hashtbl.create 1;
      total_error = Hashtbl.create 1;
      total_off = Hashtbl.create 1;
      online = Hashtbl.create 1;
      online_list = input_value in_channel;
      got_online = false;
      got_online_list = true;
      grand_total = 0.0;
      threshold = 0.0;
    }

  end : Matrix.MATRIX with type key = K.t and type value = V.t
);;
