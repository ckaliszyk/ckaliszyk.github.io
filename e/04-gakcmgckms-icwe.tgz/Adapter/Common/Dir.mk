FILES:=types_ad libdebug libepi log2epi_1 log2epi_2 errorPrunedMatrix nullTitler majorityTitler markovModel usedModel predictor
DIR:=Adapter/Common
TARGET:=common.$(LIB_SUF)
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -a -o $@ $^
