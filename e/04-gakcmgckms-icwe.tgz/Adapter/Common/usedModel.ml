module L = Log2epi_1.Make;;

module Model = MarkovModel.Make(L) ;;

module Titler = MajorityTitler.Make ;;

