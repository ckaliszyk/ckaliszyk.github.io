(** Specification of one implementation of LOG2EPI *)

module Make : Log2epi.LOG2EPI