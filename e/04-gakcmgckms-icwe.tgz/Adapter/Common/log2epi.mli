(* module LOG2EPI interface *)

module type LOG2EPI =
    sig

    val processEpisodes :
    (Types_ad.url list -> Types_ad.url -> int -> 'a -> 'b) ->
		int -> Types_ad.url list -> 'a -> unit

    val processSession :Types_ad.session -> (Types_ad.url list -> 
		'a -> unit) -> 'a -> unit

    val processLog :Types_ad.session list ->
		(Types_ad.url list -> Types_ad.url -> int -> 'a -> 'b) -> int -> 'a -> unit
end

