(** Implementation of users' behavior model
    There are n distinct Markov models (one for each episode length, where
    maximum episode length is an input to the model) 

    @author Marcin Gozdalik
 *)

open Types_ad;;
open Libdebug;;

module Make (L: Log2epi.LOG2EPI) : Model.MODEL =
  struct

    module EpiVal =
      struct
        type t = episode
      end;;

    module UrlKey =
      struct
        type t = url
      end;;

    module EPMMatrix = ErrorPrunedMatrix.Make (EpiVal) (UrlKey);;

    type t = {
      matrices : EPMMatrix.t array;
      max_len : int;
    }
    
    let make maxlen threshold = 
      let f len = EPMMatrix.make threshold
      in
      {
        matrices = Array.init maxlen f;
        max_len = maxlen;
      }

    let cut_epi epi maxlen =
      let rec cut_epi_acc epi cur_len =
        match epi with
        | [] -> epi
        | h::t -> (
          if cur_len > maxlen then
            cut_epi_acc t (cur_len-1)
          else
            epi
        )
      in cut_epi_acc epi (List.length epi)

    let teach model log =
      let single_teach epi last len model =
        let matrix = model.matrices.(len-1) in
        EPMMatrix.add matrix epi last 
      in
      L.processLog log single_teach model.max_len model

    let validate model log =
      let single_validate epi last len model =

        let rec iter_subepi subepi len =
          let matrix = model.matrices.(len-1) in
          EPMMatrix.validate matrix subepi last;
          if (len > 1) then match subepi with
          | h::t -> iter_subepi t (len-1)
          | _ -> assert false
        in iter_subepi epi len
      in

      let iter_error (epi, last) error_rate =
        
        let rec iter_subepi subepi len =
          debug ( lazy ( 
            print_string "iter_error, iter_subepi: ";
            List.iter (fun url -> print_string ((string_of_url url) ^ " ")) subepi;
            Printf.printf "len == %i " len;
          ));
          let matrix = model.matrices.(len-1) in
          let subepi_error_rate = EPMMatrix.error_rate matrix subepi last in
          debug ( lazy ( Printf.printf "sub_er == %f\n" subepi_error_rate ));
          if (subepi_error_rate < error_rate) then (
            EPMMatrix.prune matrix epi last
          ) else if (len > 1) then match subepi with
          | h::t -> iter_subepi t (len-1)
          | _ -> assert false
        in
        debug ( lazy (
          print_string "iter_error: ";
          List.iter (fun url -> print_string ((string_of_url url) ^ " ")) epi;
          print_string ("last: " ^ (string_of_url last));
          Printf.printf " er == %f\n" error_rate;
        ));
        iter_subepi epi (List.length epi)
      in
      
      let iter_matrix index matrix =
        if (index >= 1) then EPMMatrix.error_iter matrix iter_error
      in
      
      L.processLog log single_validate model.max_len model;
      Array.iteri iter_matrix model.matrices

    let test model log =
      (* FIXME *)
      0.85

    let predict model episode =

      let rec iter_matrices subepi len =
        let matrix = model.matrices.(len-1) in
        let ret = EPMMatrix.predict_all matrix subepi in
        if ((List.length ret) > 0) then ret else if (len > 1) then begin
          match subepi with
          | h::t -> iter_matrices t (len-1)
          | _ -> assert false
        end else []
      in 
      if episode = [] then [] else
      let epi = cut_epi episode model.max_len in
      let ret = iter_matrices epi (List.length epi) in
      ret

    let output_value model out_channel =
      output_value out_channel model.max_len;
      Array.iter (fun mat -> EPMMatrix.output_value mat out_channel) model.matrices

    let input_value in_channel =
      let f len = EPMMatrix.input_value in_channel
      in
      let maxlen : int = input_value in_channel in
      {
        max_len = maxlen;
        matrices = Array.init maxlen f
      }

    let iter model f =
      Array.iter (fun mat -> EPMMatrix.iter mat f) model.matrices

    let maxlen model =
      model.max_len

  end;;
