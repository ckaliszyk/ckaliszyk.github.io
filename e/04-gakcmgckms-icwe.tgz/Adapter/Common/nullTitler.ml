open Types_ad;;

module Make : Titler.TITLER =
  struct
    type t = unit

    let teach _ _ = ()

    let get_title _ url = (string_of_url url)

    let make () = ()

    let output_value _ _ = ()

    let input_value _ = make()

  end;;
