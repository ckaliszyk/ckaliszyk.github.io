(** Specification of module which models a Matrix chain

    @author Marcin Gozdalik
 *)

open KeyVal;;

module type MATRIX =
  sig
    type key
    type value
    type t
    
    val make: float -> t
    (** [make threshold] creates a matrix with given support [threshold]
    *)

    val add: t -> key -> value -> unit
    (** [add matrix key value] adds to [matrix] observation that [value] happened after [key],
        thus modifying [matrix] in-place
    *)

    val validate: t -> key -> value -> unit
    (** [validate matrix key value] validates [matrix] (thus modifying it
        in-place) using observation that [value] happened after [key]. Validation
        here can be interpreted as matrix implementor desires (e.g.  for
        calculating error rate for given [value])
    *)

    val error_iter: t -> ((key * value) -> float -> unit) -> unit
    (** [error_iter matrix f] iterates through [matrix] calling [f]
        for every (key, value) together with its error rate
    *)

    val error_rate: t -> key -> value -> float
    (** [error_rate matrix key value] returns error rate for [value] (fraction of validation
        observations for [value] which didn't have [key] observed) 
    *)
    
    val prune: t -> key -> value -> unit
    (** [prune matrix key value] prunes from [model] all observations that [value]
        happened after [key]
    *)

    val predict: t -> key -> value
    (** [predict matrix key] returns the most probable destination for given
        [key] in [matrix] (head of list returned by [predict_all]). Raises
        [Not_found] when no such destination exists
    *)
    
    val predict_all: t -> key -> (value * float) list
    (** [predict_all matrix key] returns list of pairs [value * probability]
        (sorted by [probability]) which means that according to [matrix]
        [value] happens after [key] with [probability]
    *)

    val iter: t -> (key -> unit) -> unit
    (** [online_iter matrix] iterates through all keys stored in [matrix]
    *)

    val output_value: t -> out_channel -> unit
    (** [output_value matrix output] outputs marshalled [matrix] to [output]
        making it possible to save [matrix] for future work (e.g. to use it in
        another application). Only objects which are necessary for proper
        functioning of predict should be left befory outputting [matrix] (any
        temporary objects created during matrix teaching and validation phases
        should be discarded)
    *)
    
    val input_value: in_channel -> t
    (** [input_value input] reads marshalled [matrix] from [input]. Read matrix
        allows only for predict and predict_all operations (behavior of other is
        undefined)
    *)
end;;

module Make (K : KEYVAL) (V : KEYVAL) : MATRIX with type key = K.t and type value = V.t;;
