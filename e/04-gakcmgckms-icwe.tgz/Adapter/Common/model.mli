(** Specification of module which models users' behavior

    @author Marcin Gozdalik
 *)

open Types_ad;;

module type MODEL =
  sig
    type t
    
    val make: int -> float -> t
    (** [make maxlen threshold] creates model which considers episodes of maximum length
        [maxlen] and with support at least of [threshold]. Returns created (empty) model
    *)

    val maxlen: t -> int
    (** [maxlen model] returns model size (AKA as maximum sub-episode length).
    *)
    
    val teach: t -> log -> unit
    (** [teach model log] teaches [model] (thus modifying it in-place) using
        sessions stored in [log].
    *)
    
    val validate: t -> log -> unit
    (** [validate model log] validates [model] (thus modifying it in-place)
        using sessions stored in [log].  Validation here can be interpreted as
        model implementor desires. [log] can be considered an additional source of
        data model can learn from.
    *)
    
    val test: t -> log -> float
    (** [test model log] determines "quality" of [model] using [log]
        returned value should be in <0;1> - the bigger the model is better.
    *)
    
    val predict: t -> episode -> (url * float) list
    (** [predict model episode] returns list of pairs [url, probability]
        (sorted by [probability]) which means that according to model [t] user
        after visiting pages listed in [episode] will next visit URLs listed
        with given probabilities.
    *)

    val output_value: t -> out_channel -> unit
    (** [output_value model output] outputs marshalled [model] to [output]
        making it possible to save [model] for future work (e.g. to use it in
        another application). Only objects which are necessary for proper
        functioning of predict should be left before outputting [model] (any
        temporary objects created during model teaching and validation phases
        should be discarded).
    *)

    val input_value: in_channel -> t
    (** [input_value input] reads marshalled model from [input]. Read model
        allows only to predict (teach, validate and test won't work and their
        behavior is undefined).
    *)

    val iter: t -> (episode -> unit) -> unit
    (** [iter model f] iterates through all episodes stored in [model] and calls
        [f] for each episode.
     *)
end;;
