(** Types used throughout Adapter module
    Some types should be made global to all SIE modules (url, date?), some
    should be left here

    @author Marcin Gozdalik
 *)

(** Date type *)
type date = { 
  d: int; (** day *)
  m: int; (** month *)
  y: int; (** year *)
};;

(** denotes a Resource in the site
 *)
(*type url = int160;;*)
type url = string option;;

(** a single episode
*)
type episode = url list;;

(** a tree of UURLs visited
 *)
type session = 
  | Leaf (** leaf in the tree *)
  | Node of (url * session list);; (** a node in the tree: contains an UURL and arbitrary many sons *)

(** a group of sessions (a forest) *)
type log = session list;;

(** convert uul into string *)
val string_of_url : url -> string;;

(** print session tree on standard output *)
val print_ses : session -> unit;;

(** converts string into date *)
val date_of_string : string -> date;;

(** converts a date into string *)
val string_of_date : date -> string;;

(** converts tm into date *)
val date_of_tm : Unix.tm -> date;;

(** [compare_date d1 d2] returns -1, 0, 1, if, respectively, 
 * d1 is less than, equal or more than d2 *)
val compare_date : date -> date -> int;;


