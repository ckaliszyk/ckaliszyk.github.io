(** Specification of one implementation of LOG2EPI module *)

module Make : Log2epi.LOG2EPI
