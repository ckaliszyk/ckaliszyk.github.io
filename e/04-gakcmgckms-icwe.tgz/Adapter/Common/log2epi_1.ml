(** Implemantation of LOG2EPI module
  * extracting episodes from sessions and subepisodes from
  * episoded
  * Objective: do it in many flavors and test which one is best
    @author Marcin Gozdalik
 *)


open Types_ad;;
open Libdebug;;

(** invoke func for all subepisodes (of given maximum length) contained in the episode

    @param func Function to invoke (func : subepi -> last_url -> subepi_len -> param -> unit)
    @param max Maximum length of subepisodes
    @param epi Episode
    @param param Parameter to pass to func
*)

module Make : Log2epi.LOG2EPI =
struct

  let rec processEpisodes func max epi param =  

  let epilen = List.length epi in
  
  let invoke epi sublen =
    let rec doInvoke epi sublen n =
      match epi with
      | h::t -> (
        if n = sublen then ([], h)
        else let (subepi, last) = doInvoke t sublen (n+1) in
        let newSubepi = (h::subepi) in
        func newSubepi last (sublen-n) param;
        (newSubepi, last);
      )
      | _ -> failwith "Cannot happen (empty epi in invoke)!"
    in ignore (doInvoke epi sublen 1)
  in

  let rec slide epi curSubepiLen maxSubepiLen n =
    if (epilen-curSubepiLen+1) < n then () else
    invoke epi curSubepiLen;
    match epi with
    | h::t -> (
      let (newCurSubepiLen, newEpi, newN) = 
        if (curSubepiLen < maxSubepiLen) then 
          ((curSubepiLen+1), epi, n) 
        else
          (curSubepiLen, t, (n+1))
      in slide newEpi newCurSubepiLen maxSubepiLen newN
    )
    | _ -> ()
  in slide epi 2 max 1



(** invoke func for all episodes contained in a session

    @param ses Session	
    @param func Function to invoke (epi -> param -> unit)
    @param param Parameter to pass to func
*)

let processSession ses func param = 

  let rec descend epi node =
    match node with 
    | Leaf -> func (List.rev epi) param
    | Node (url, sons) -> (
      match sons with 
      | [] -> func (List.rev (url::epi)) param
      (* TODO: partial application here: can it be avoided? *)
      | _ -> List.iter (descend (url::epi)) sons
    )
  in descend [] ses


(** invoke func for all subepisodes in sessions containted in the log

    @param log Log
    @param func Callback function (subepi -> last -> subepi_len -> param -> unit)
    @param max Maximum length of subepisodes
    @param param Extra parameter to pass to function
  *)
let processLog log func max param =
  let processSes ses = processSession ses (processEpisodes func max) param in
  List.iter processSes log

end 
