open Lazy;;

let do_debug = 0;; (* 0 - printf off 1- printf on *)

let debug x = if do_debug=1 then (force_val x) else () ;;
