(** Implementation of users' behavior predictor

    @author Marcin Gozdalik
 *)

open Types_ad;;

module type PREDICTOR =
  sig
    type t
    
    val predict: t -> string -> episode -> (url * float) list
    (**
        [predict model user episode] returns list of pairs [url, probability]
        (sorted by [probability]) which means that according to model [t] [user]
        after visiting pages listed in [episode] will next visit URLs listed
        with given probabilities 
    *)
end;;

module Make =
  functor (M : Model.MODEL) ->
  (struct

    type t = M.t
      
    let create model : t = model
    
    let predict model user episode =
      Libdebug.debug ( lazy ( 
        let rec make_ret_str acc l = 
          match l with 
          | [] -> acc
          | url::t -> (
            let new_acc=acc^("("^(string_of_url url)^")") in
            make_ret_str new_acc t
          )
        in
        prerr_endline ("<Predictor.predict> for " ^ (make_ret_str "" episode));
      ));
      let ret = M.predict model episode in
      Libdebug.debug ( lazy ( 
        let rec make_ret_str acc l = 
          match l with 
          | [] -> acc
          | (url,prob)::t -> (
            let new_acc=acc^("("^(string_of_url url)^","^(string_of_float prob)^")") in
            make_ret_str new_acc t
          )
        in
        prerr_endline ("</Predictor.predict> returning " ^ (make_ret_str "" ret));
      ));
      ret

  end : PREDICTOR with type t = M.t
  );;
