(** Specification of signature holding only a type
    Necessary to parametrize MATRIX

    @author Marcin Gozdalik
 *)

module type KEYVAL =
  sig
    type t
 
  end;;  
