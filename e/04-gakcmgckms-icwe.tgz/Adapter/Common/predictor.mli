(** Specification of module which predicts user behavior

    @author Marcin Gozdalik
 *)

open Types_ad;;

module type PREDICTOR =
  sig
    type t
    
    val predict: t -> string -> episode -> (url * float) list
    (**
        [predict model user episode] returns list of pairs [url, probability]
        (sorted by [probability]) which means that according to model [t] [user]
        after visiting pages listed in [episode] will next visit URLs listed
        with given probabilities 
    *)
end;;

module Make (M : Model.MODEL) : PREDICTOR with type t = M.t;;
