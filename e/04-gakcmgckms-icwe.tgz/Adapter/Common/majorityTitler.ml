open Types_ad;;

module Make : Titler.TITLER =
  struct
    type offline_t = (string, ((string, int) Hashtbl.t)) Hashtbl.t
    type online_t = (string, string) Hashtbl.t

    type t = {
      offline : offline_t;
      online : online_t;
    }

    let teach titler titles =
      let f (url, title) =
        let cur = (try
          Hashtbl.find titler.offline url
        with Not_found ->
          Hashtbl.create 5
        ) 
        in let count = (try
          Hashtbl.find cur title
        with Not_found ->
          0
        )
        in 
        Hashtbl.replace cur title (count+1);
        Hashtbl.replace titler.offline url cur
      
      in List.iter f titles

    let convert titler =
      let f url titles =
        let g title count (max_title, max_count) =
          if (count > max_count) then
            (title, count)
          else
            (max_title, max_count)
        in 
        let (title, _) = Hashtbl.fold g titles (url, 0) in
        Hashtbl.add titler.online url title
      in
      Hashtbl.clear titler.online;
      Hashtbl.iter f titler.offline

    let get_title titler url =
      try 
        Hashtbl.find titler.online (string_of_url url)
      with Not_found ->
        (string_of_url url)

    let make () = {
      offline = Hashtbl.create 100;
      online = Hashtbl.create 100;
    }

    let output_value titler out_channel =
      output_value out_channel titler.online

    let input_value in_channel = {
      offline = Hashtbl.create 1;
      online = input_value in_channel;
    }

  end;;
