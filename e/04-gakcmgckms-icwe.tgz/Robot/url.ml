(* Dzia�a tylko dla dobrych link�w (ale tylko takie s� w logach) *)
let parse_url url =
  let len = String.length url in
  let rec parse acc pos =
    let i = String.index_from url pos '=' in
    try
      let j = String.index_from url i '&' in
      let param = String.sub url pos (i - pos)
      and aval = String.sub url (i + 1) (j - i - 1) in
      parse ((param, aval) :: acc) (j + 1)
    with
      Not_found ->
        let param = String.sub url pos (i - pos)
        and aval = String.sub url (i + 1) (len - i - 1) in
        List.rev ((param, aval) :: acc)
  in
  try
    let i = String.index url '?' in
    ((String.sub url 0 i), (parse [] (i + 1)))
  with Not_found -> (url, [])
;;

let deparse_url (link, params) =
  match params with
  | [] -> link
  | lst ->
      let rewrite (param, pval) = param ^ "=" ^ pval in
      let strlist = List.map rewrite lst in
      let rest = String.concat "&" strlist in
      link ^ "?" ^ rest
;;
