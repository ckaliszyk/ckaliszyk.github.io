exception Dead_link;;

let http_syntax =
  let required_syntax = Hashtbl.find Neturl.common_url_syntax "http" in
  Neturl.partial_url_syntax required_syntax
;;


(* throws Not_found *)
let rec get_base_from_parsed = function
  | [] -> raise Not_found
  | node::t ->
      try
        match node with
        | Nethtml.Element ("base", args, _) ->
            List.assoc "href" args
        | Nethtml.Element (_, _, subnodes) ->
            get_base_from_parsed subnodes
        | Nethtml.Data _ -> get_base_from_parsed t
      with 
      | Not_found -> get_base_from_parsed t
;;

let print_endline s =
  print_endline s;
  flush stdout
;;

(* TODO *)
let apply_base base link =
  let link_url = Neturl.url_of_string http_syntax link in
  let base_url = Neturl.url_of_string http_syntax base in
  let complete_url = Neturl.apply_relative_url base_url link_url in
  let path = Neturl.norm_path (Neturl.url_path complete_url) in
  let mapper p = Netencoding.Url.encode (Netencoding.Url.decode p) in
  let norm_path = List.map mapper path in
  Neturl.string_of_url (Neturl.modify_url ~path:norm_path complete_url)
;;  


let get_resources base body =
  let rec get_resources_aux base acc body =
    let folder acc elem = 
      let helper param ptype args sub =
        try
          let link = (apply_base base (List.assoc param args), ptype) in
          get_resources_aux base (link :: acc) sub
        with
        | Not_found -> get_resources_aux base acc sub
      in
      match elem with
      | Nethtml.Data _ -> acc
      | Nethtml.Element ("a", args, sub) -> helper "href" "href" args sub
      | Nethtml.Element ("img", args, sub) -> helper "src" "image" args sub
      | Nethtml.Element ("frame", args, sub) -> helper "src" "frame" args sub
      | Nethtml.Element ("base", args, sub) ->
          let new_base = List.assoc "href" args in
          get_resources_aux new_base acc sub
      | Nethtml.Element (_, _, sub) ->
          get_resources_aux base acc sub
    in
    List.fold_left folder acc body
  in
  get_resources_aux base [] body
;;
  
let get_content_type addr = 
  let message = new Http_client.head addr
  and pipeline = new Http_client.pipeline in
  pipeline#add message;
  let resp = 
    try 
      pipeline#run ();
      message#get_resp_header ()
    with
    | Failure s -> 
        print_endline s;
        raise Dead_link
    | _ -> 
        print_endline "Unknown Http_client bug";
        raise Dead_link
  in
  (*let message = Http_client.Convenience.http_head_message addr in*)
  try 
    let ret = List.assoc "content-type" resp in
    if String.length ret > 9 then (*text/html*)
      if String.sub ret 0 9 = "text/html" then "text/html" else ret
    else ret
  with
  | Not_found -> "unknown"
;;

let robot base addr =
  let message = new Http_client.get addr
  and pipeline = new Http_client.pipeline in
  pipeline#add message;
  begin try 
    pipeline#run ()
  with 
  | Failure s -> 
      print_endline s;
      raise Dead_link
  | _ -> 
      print_endline "Unknown Http_client bug";
      raise Dead_link
  end;
  if not (message#is_served) then raise Dead_link else
  let (_, code, _) = message#dest_status () in
  (* TODO *)
  if code <> 200 then raise Dead_link else
  let page = message#get_resp_body () in
  let dtd = Nethtml.relaxed_html40_dtd in
  let parsed = Nethtml.parse ~dtd (new Netchannels.input_string page) in
  let resources = get_resources addr parsed in
  let base_url = Neturl.url_of_string http_syntax base in
  let base_host = Neturl.url_host base_url in
  let filter (addr, ptype) =
    let addr_url = Neturl.url_of_string http_syntax addr in
    let addr_host = Neturl.url_host addr_url in
    (ptype = "href" || ptype = "frame") &&
    addr_host = base_host
  in
  let pages_pairs = List.filter filter resources in
  let pages = fst (List.split pages_pairs) in
  (parsed, resources, pages)
;;

let cut_base base =
  let len = (String.length base - 1) in
  let sub = String.sub base 0 len in
  let cut addr =
    if String.sub addr 0 len = sub then 
      String.sub addr len (String.length addr - len)
    else addr
  in cut
;;

let meta_robot () =
  let get_from_db = ref true in
  (* Kolejka stron do odwiedzenia bfs'em, stringi z adresem wzgle
   * dem katalogu root danego serwisu *)
  let queue = Queue.create () in
  (* TODO GET BASE FROM CONFIG OR DB OR PARAMS*)
  let base = "http://sio:8080/" in
  let cut_base = cut_base base in
  let visited = Hashtbl.create 100 in
  let add_to_queue page =
    let normalized = apply_base base page in
    Queue.add normalized queue;
    Hashtbl.replace visited normalized ()
  in
  let spec_lst = [
    "-e", Arg.Clear get_from_db, "Erase database list";
  ] in
  Arg.parse_argv Sys.argv spec_lst add_to_queue "usage: Robot [options] [page]...";
  (*TODO*);
  if !get_from_db then ();
  while not (Queue.is_empty queue) do
    let addr = Queue.pop queue in
    print_endline addr;
    try
      let content_type = get_content_type addr in
      print_endline content_type;
      if content_type = "text/html" then begin
        let (parsed, resources, new_pages) = robot base addr in
        let iterator page =
          let (addr, params) = Url.parse_url page in
          let filter (a,_) = a <> "uuu_file" && a <> "uuu_link" in
          let params = List.filter filter params in
          let loop = function
            | "m", "info" -> true
            | "m", "reply" -> true
            | _ -> false
          in
          if List.length (List.filter loop params) > 0 then () else
          let page = Url.deparse_url (addr, params) in
          if not (Hashtbl.mem visited page) then begin
            Queue.add page queue;
            Hashtbl.replace visited page ()
          end in
        List.iter iterator new_pages;
        (* TODO *)
        let parameters = [] in
        let addr = cut_base addr in
        Postgres_db.insert_page addr parameters parsed resources
      end else print_endline "Non text/html"
    with
    | Dead_link -> ()
    | Neturl.Malformed_URL -> ()
    | _ -> ()
  done
;;

try
  meta_robot ()
with
| Queue.Empty -> print_endline "Nothing to do";;
