let exec_res connection query = 
  connection#exec_expect query [Postgres.Result.Command_ok]
;;

let exec connection query =
  ignore (exec_res connection query)
;;

let connect () =
  let connection = new Postgres.connection "dbname=c" in
  exec connection "begin";
  connection
;;

let disconnect connection =
  exec connection "end";
  connection#close
;;

let output_object connection alpha =
  let oid = connection#lo_create in
  let lo = connection#lo_open oid in
  connection#lo_write_string lo (Marshal.to_string alpha []);
  connection#lo_close lo;
  oid
;;

let insert_page address parameters body resources =
  let connection = connect () in
  let oid = output_object connection body in
  exec connection ("INSERT INTO Pages (address, body) VALUES ('" ^ address ^ "', " ^ (string_of_int oid) ^ ");");
  let add_param (n, v) =
    exec connection ("INSERT INTO Parameters VALUES (currval('pages_page_id_seq'), "  ^ n ^ ", " ^ v ^ ");")
  in
  List.iter add_param parameters;
  let add_resource (uri, res_type) =
    exec connection ("INSERT INTO Resources VALUES (currval('pages_page_id_seq'), '" ^ uri ^ "', '" ^ res_type ^ "');")
  in
  List.iter add_resource resources;
  disconnect connection
;;

let tm_of_timestamp stamp =
  let convert yy mm dd h m s =
    snd (Unix.mktime {
	 Unix.tm_sec = int_of_float s;
	 Unix.tm_min = m;
	 Unix.tm_hour = h;
	 Unix.tm_mday = dd;
	 Unix.tm_mon = mm - 1;
	 Unix.tm_year = yy - 1900;
	 Unix.tm_wday = 0;
	 Unix.tm_yday = 0;
	 Unix.tm_isdst = false;
       } ) in
  print_endline stamp; flush stdout;
  Scanf.sscanf stamp "%d-%d-%d %d:%d:%f" convert
;;

let timestamp_of_tm tm =
  Printf.sprintf "%d-%d-%d %d:%d:%d"
    (tm.Unix.tm_year + 1900) (tm.Unix.tm_mon + 1) tm.Unix.tm_mday
    tm.Unix.tm_hour tm.Unix.tm_min tm.Unix.tm_sec
;;

let get_page connection id =
  (* mark as seen and get address, body oid and date *)
  let res = connection # exec
      ("UPDATE Pages SET seen = true WHERE page_id = " ^ id ^ "; "
    ^ "SELECT address, body, date FROM Pages WHERE page_id = " ^ id ^ ";") in
  let [addr; bid; date] = res#get_tuple_list 0 in(* czy 1sza krotka ma nr 0? *)
  let buf = Buffer.create 0
  and tmp = String.create 4096 in
  let lo = connection#lo_open (int_of_string bid) in
  (* read page body (large object) *)
  let rec read_aux () =
    match connection#lo_read lo tmp 0 4096 with
    | 0 -> Buffer.contents buf
    | n -> Buffer.add_substring buf tmp 0 n; read_aux () in
  let body = Marshal.from_string (read_aux ()) 0 in
  connection#lo_close lo;
  (* get page parameters *)
  let res_par = connection # exec
      ("SELECT name, value FROM Parameters WHERE page = " ^ id ^ ";") in
  let params = List.map (fun [n; v] -> (n, v)) res_par#get_list in
  addr, params, body, tm_of_timestamp date
;;

let get_new_parsed_html date =
  let connection = connect () in
  let query = ("SELECT page_id FROM Pages WHERE seen = false "
    ^ "AND date > timestamp '" ^ timestamp_of_tm date ^ "';") in
  let res = connection # exec query in
  let pages = List.flatten res#get_list in
  let res = List.map (get_page connection) pages in
  disconnect connection;
  res
;;
