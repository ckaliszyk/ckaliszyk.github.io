val connect : unit -> Postgres.connection;;
val exec : Postgres.connection -> string -> unit;;
val disconnect : Postgres.connection -> unit;;
val insert_page : string -> (string * string) list -> Nethtml.document list -> (string * string)  list -> unit;;

val output_object : Postgres.connection -> 'a -> int;;
val get_new_parsed_html : Unix.tm ->
  (string * (string * string) list * Nethtml.document list * Unix.tm) list
