
open W_overseer;;

let parse_query query (_and,_or,_not) =
let _ = Printf.printf "ParseQuery=%s\n" query in 
let query_hook,_ = Overseer_funs.get_pn () in
let re = Str.regexp (".*"^query_hook^"=\\([^&]*\\).*") in
let r = try Str.string_match re query 0 with _ -> false in
let querys = 
  if r then
    try Str.matched_group 1 query
    with
      Not_found -> ""
  else "" in
let re = Str.regexp "[ ]*\\([^ ]*\\)\\(.*\\)" in
let rec word_list queryrest =
  let r = Str.string_match re queryrest 0 in
    if r then let
      word = try Str.matched_group 1 queryrest
      with
        Not_found -> ""
      and
      rest = try Str.matched_group 2 queryrest
      with
        Not_found -> ""
      in match word with
          "" -> []
        | w -> word :: (word_list rest)
      
    else []
in let wlist = word_list querys in
let rec clean_word_list wl = match wl with
  [] -> []
| w :: t -> if w = _not then [] else
            if w = _and or w = _or then clean_word_list t
            else w :: (clean_word_list t)
in clean_word_list wlist
;;


