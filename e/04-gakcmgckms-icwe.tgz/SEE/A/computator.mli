(** Criteria module is responsible for computing page rank respecting
 * each criteria. One criterion at the time.
 *
 *  @author Radek Borecki
 *  @author Micha� Matusiak
 *)
 
open Types_see;;

(** Main computer function.
 * Makes a word list from page, filters uninteresting words, 
 * and evaluates page rank respecting every criterion
 * For each word produces a pair (url, value list) for
 *  each url (page) the word appears in. Exports data to file 'crits'.
 *
 *  @author Radek Borecki
 *  @author Micha� Matusiak
 *)
val link_deal: int list -> uninteresting_words_definition -> url_package
    -> out_channel -> unit
;;

val global_word_hash: ((string,(string*((int*int) list)) list ) Hashtbl.t ) ref;;
