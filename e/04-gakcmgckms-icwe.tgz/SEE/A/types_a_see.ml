type strint = (string * int)
;;



