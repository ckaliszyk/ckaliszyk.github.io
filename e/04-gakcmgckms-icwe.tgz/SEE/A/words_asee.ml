open Types_see;;
(*open W_postgres;;*)


let get_parsed_html () =
  (*
  let lst = Postgres_db.get_new_parsed_html (Unix.gmtime 0.) in
    let 
      mapper (url, words, page, time) = (url, page)
  in
  List.map mapper lst
  *)
  
  R_see.get_parsed_html ()
;;

let get_crit_uninteresting () = 
  let un = Overseer_funs.get_uwd()
  and crit = Overseer_funs.get_cri()
  in
  (crit, un)
;;

let words_deal () = 
  let url_p_new_list = ref (get_parsed_html ()) in
  if !url_p_new_list != [] then 
  begin
  let oc = open_out_bin "crits" in
  let (crit_list, uninteresting) = get_crit_uninteresting () in
    List.iter (fun url ->
    Computator.link_deal crit_list uninteresting url oc;
    ) !url_p_new_list;
    close_out oc
  end;

  let word_hash = !Computator.global_word_hash in
  let outc = open_out_bin "overseer_data" in
  let mapper word url_list = 
    let udata (url, unsorted_cri) = 
      let cmp (cri_id, _) (cri_id2, _) = compare cri_id cri_id2 in
      let cri = List.sort cmp unsorted_cri in
      (url,word,cri,0.)
    in let uurl_list = List.map udata url_list in
    output_value outc (word, uurl_list)
  in
  if (!url_p_new_list = []) then () else
  Hashtbl.iter mapper word_hash;
  close_out outc
;;
