(* main file *)

if (Array.length Sys.argv) = 3 then (
  let filename = Sys.argv.(1) in
  W_gatherer.url_prefix := Sys.argv.(2);
  Words_asee.words_deal (); 
  Weights_asee.weights_deal filename; )
else
  print_endline ("Usage:\t"^Sys.argv.(0)^" <log_file> <url_prefix>");
