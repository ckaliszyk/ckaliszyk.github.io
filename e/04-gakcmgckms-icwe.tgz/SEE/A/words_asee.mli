(** Module Words_asee is a first part of A-SEE.
 *  It computes criteria of words and is used in main A-SEE code.
 *
 *  @author Radek Borecki
 *  @author Micha� Matusiak
 *)

(**
 *  The function computes criteria for words gathered from site pages.
 *  It gets list of pages that must be analysed and for each page
 *  on the list performs following operations:
 *  - splits this page into separate words,
 *  - for each distinct word and the page computes criteria and stores
 *  them in databases.
 *  Two files are generated as a result of the function call: 
 *  'overseer_data' and 'crits'.
 * 
 *  This function is called from main A-SEE code.
 *
 *  @author Radek Borecki
 *  @author Micha� Matusiak
 *)
val words_deal: unit -> unit;;
