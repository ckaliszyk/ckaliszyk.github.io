open Db;;
open Types_see;;
(*open W_postgres;;*)
(*open Overseer_funs;;*)

let export_weights_to_overseer user word weightsList =
  if user = "" then begin Overseer_funs.set_ww word weightsList;(*put_weights_list_nouser word weightsList;*) end else
  begin Overseer_funs.set_uww (user,word) weightsList;(*put_weights_list user word weightsList;*) end
;;
