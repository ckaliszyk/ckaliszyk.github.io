
(** Module Weights_asee is a second part of A-SEE.
 *  It computes weights of criteria using values precomputed during
 *  the first stage (by words_deal).
 *  This module is used in main A-SEE code.
 *
 *  @author Micha� Matusiak
 *)

(** This function computes weights for a criteria set.
 *  It gets user list from database (PostgreSQL in this case) and
 *  for each user on the list performs following operations:
 *  - collects queries of this user and parses them into single words
 *  - links words with pages that were visited within search session
 *  - computes 'history of clicks'
 *  - computes set of weights (also called 'preferences')
 *  
 *  After weights_deal call computed data is stored in databases 
 *  (PostgreSQL and Overseer).
 *
 *  This function is called from main A-SEE code.
 *  
 *  @author Micha� Matusiak
 *)
val weights_deal: string -> unit;;
