
(*deprecated*)
let connectionString = "dbname=c";;

(** 
  Functions.
*)

let currentConnection = try new Postgres.connection connectionString
  with e -> Printf.printf "PostgresException::currentConnection\n"; raise e
;;

let clean_criteria url =
  let queryString = String.concat "" ["DELETE FROM urls_words_criteria WHERE url='";url;"'"] in
  try
    let _ = currentConnection#exec queryString in ()
  with Postgres.Error e -> Printf.printf "PostgresException::clean_criteria"; raise (Postgres.Error e)
;;

let put_context word url text =
  let queryString = String.concat "" ["INSERT INTO context VALUES ('";word;"','";url;"','";text;"')"] in
  try
    let _ = currentConnection#exec queryString in ()
  with Postgres.Error e -> Printf.printf "PostgresException::put_context"; raise (Postgres.Error e)
;;

let get_context word url =
  let queryString = String.concat "" ["SELECT text FROM context WHERE word ='";word;"' and url='";url;"'"] in
  try
    let queryResult = currentConnection#exec queryString in
    (queryResult#getvalue 0 0)
  with Postgres.Error e -> Printf.printf "PostgresException::get_context"; raise (Postgres.Error e)
;;


let get_user_list userList =
  let queryString = "SELECT DISTINCT user_id FROM sessions" in
  try
  let queryResult = currentConnection#exec queryString in
    for ti = 0 to (queryResult#ntuples-1) do        
      userList := (queryResult#getvalue ti 0) :: !userList;
    done;
  with Postgres.Error e -> Printf.printf "PostgresException::get_user_list"; raise (Postgres.Error e)
;;


let get_query_list user queryList =
  let queryString = String.concat "" ["SELECT DISTINCT url_from FROM uclicks WHERE user_id='";user;"'"] in
  try 
  let queryResult = currentConnection#exec queryString in
    for ti = 0 to (queryResult#ntuples-1) do
      queryList := (queryResult#getvalue ti 0) :: !queryList;
    done;
  with Postgres.Error e -> Printf.printf "PostgresException::get_query_list"; raise (Postgres.Error e)
;;

(*let url_prefix = ref "http://sio:8080";;*)
let url_prefix = ref "";;

let get_url_list user query urlList =
  let queryString = String.concat "" ["SELECT url_to FROM uclicks WHERE user_id='";user;"' and url_from='";query;"'"] in
  try 
  let queryResult = currentConnection#exec queryString in
    for ti = 0 to (queryResult#ntuples-1) do
      urlList := (!url_prefix^(queryResult#getvalue ti 0)) :: !urlList;
    done;
  with Postgres.Error e -> Printf.printf "PostgresException::get_url_list"; raise (Postgres.Error e)
;;

let postgres_init () =
  try
    let _ = currentConnection#exec "DELETE FROM user_words_weights" in 
    let _ = currentConnection#exec "DELETE FROM words_weights" in ()
  with Postgres.Error e -> Printf.printf "PostgresException::postgres_init"; raise (Postgres.Error e)
;;

let postgres_close () =
  try
    currentConnection#close
  with Postgres.Error e -> Printf.printf "PostgresException::postgres_close"; raise (Postgres.Error e)
;;

let put_weights_list user word clist = 
  List.iter (fun (cid,cval) ->
    let queryString = String.concat "" [
      "INSERT INTO user_words_weights VALUES ('";user;"','";word;
      "',";string_of_int(cid);",";string_of_float(cval);")"] in
    try 
      let _ = currentConnection#exec queryString in ()
    with Postgres.Error e -> Printf.printf "PostgresException::put_weights_list"; raise (Postgres.Error e)
  ) clist
;;

let put_weights_list_nouser word clist = 
  List.iter (fun (cid,cval) ->
    let queryString = String.concat "" [
      "INSERT INTO words_weights VALUES ('";word;
      "',";string_of_int(cid);",";string_of_float(cval);")"] in
    try 
      let _ = currentConnection#exec queryString in ()
    with Postgres.Error e -> Printf.printf "PostgresException::put_weights_list_nouser"; raise (Postgres.Error e)
  ) clist
;;

let save_title url title = 
  let queryString = String.concat "" ["INSERT INTO titles VALUES ('";url;"','";title;"')"] in
  try
    let _ = currentConnection#exec queryString in ()
  with Postgres.Error e -> Printf.printf "PostgresException::save_title"; raise (Postgres.Error e)
;;
