(** This module contains functions that parse queries to word-list.
 *
 *  @author Micha� Matusiak
 *)


(** This function parses given query using linking words definition tuple.
 *  Let's see the following example:
 *  we call parse_query "query=john and mary not kate" ("and","or","not").
 *  The definition of conjunction is "and", alternative is "or", exclusion is
 *  "not". The function returns ["john"; "mary"].
 * 
 *  @author Micha� Matusiak
 *)
val parse_query: string -> (string*string*string) -> string list;;
