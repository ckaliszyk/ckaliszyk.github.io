DIR:=SEE/A
TARGET:= a_see
FILES:= computator w_overseer w_parser w_gatherer weights_asee words_asee a_see
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Common/Pcre/pcre.$(LIB_SUF) out/Common/Netstring/netstring.$(LIB_SUF) out/BLogReader/blogreader.$(LIB_SUF) out/Api/api.$(LIB_SUF) out/SEE/Common/see.$(LIB_SUF) out/SEE/R/r_see.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES})
	${OCAML_COMP} unix.${LIB_SUF} str.$(LIB_SUF) threads.${LIB_SUF} $^ -o $@  
