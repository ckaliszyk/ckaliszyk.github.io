
(** This is a program which 1) computes criteria for each word on each
 *  page and 2) computes weights of the criteria. The criteria computed 
 *  are next stored in database called Overseer (used by E-SEE) and in 
 *  a temporary file (used for weights computation).
 *  This two tasks (1 & 2) are realized by two modules: Words and Weights. 
 *  Module Words computes criteria. Weights computes their weights. 
 *  It's simple, isn't it.
 *  A_see generates two data files: the first is named 'overseer_data' - 
 *  it contains data which is to be exported to Overseer (using w_see);
 *  the second one is 'crits' - it contains computed criteria used in off-line 
 *  analysis.
 *  If there are no new pages in the site, A_see doesn't compute criteria. 
 *  In this case only weigths are computed.
 *  Weights computation requires data stored in PostgreSQL
 *)
