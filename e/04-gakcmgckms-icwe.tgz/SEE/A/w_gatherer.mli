(* w_gatherer.mli
 *
 * 2003.06.17, Mateusz Srebrny, created
 *)

val url_prefix : string ref;;

(* [get_user_list filename ()] Returns list of known users *)
val get_user_list : string -> string list ref -> unit;;

(* [get_query_list filename user] Returns all queries made by user *)
val get_query_list : string -> string -> string list ref -> unit;; 

(* [get_url_list filename user url_from] Returns all clicks made by user from url_from *)
val get_url_list : string -> string -> string -> string list ref -> unit;;
