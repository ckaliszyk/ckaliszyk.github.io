open W_parser;;
open W_overseer;;
(*open W_postgres;;*)
(*open Overseer_funs;;*)

let listSum listOfPairs value =
  List.iter (fun (cId,cVal) -> value := !value + cVal) listOfPairs
;;

let concatLists oldList newList =
  let mapper (cId, cVal) =
    let newVal = cVal + try List.assoc cId newList with Not_found -> 0 in 
    (cId, newVal)
  in List.map mapper oldList
;;

let addListToHash newList user word globalHash =
  if (newList != []) then begin
  let oldList = try Hashtbl.find globalHash (user,word) with
                      Not_found -> []
    in let l = concatLists newList oldList in
    let _ = List.iter (fun (cid,cval) -> Printf.printf "AAA: %d %d\n" cid cval) l
    in Hashtbl.replace globalHash (user,word) l;
  end
;;

let critIds = Overseer_funs.get_cri ();;
  
let global_url_hash = ref (Hashtbl.create 10);;

let fill_global_hash () =
  let ic = open_in_bin "crits" in
  let rec get () =
    let x: (string*((string,((int*int) list))Hashtbl.t))
      = input_value ic in
    let (url_name,crit_hash) = x in
    Hashtbl.replace !global_url_hash url_name crit_hash; get ()
  in
    try
      get ()
    with End_of_file -> ()
;;

let get_crit_list url word critIds =
  Printf.printf "get_crit_list %s %s\n" url word;
  let url_info = try Hashtbl.find !global_url_hash url
    with Not_found -> (Hashtbl.create 10)
  in
  let clist = try Hashtbl.find url_info word with Not_found -> [] in
  let nclist = List.filter ( fun (c,v) ->
    List.mem c critIds
  ) clist in
  let _ = Printf.printf "END get %s %s\n" url word in
  nclist
;;
  
let computeTable filename user query globalHash word =
  Printf.printf "DEBUG:computeUserWordUrls:Query=%s Word=%s\n" query word;

  let urlList = ref [] in let _ = W_gatherer.get_url_list filename user query urlList in
  let urlHash = Hashtbl.create (List.length !urlList) in
  let _ = List.iter (fun url ->
                    let urlCounter = try Hashtbl.find urlHash url with
                      Not_found -> 0
                    in Hashtbl.replace urlHash url (urlCounter+1)
                  ) !urlList in
  let _ = Hashtbl.iter (fun url counter ->
      let origCrit = ref (get_crit_list url word critIds) in
      List.iter (fun (c,v) -> Printf.printf "origCrit: %d %d\n" c v ) !origCrit;
                       let mulCrit = List.map (fun (cId,cVal) ->
                           (cId,counter*cVal) 
                           ) !origCrit in
                       addListToHash mulCrit user word !globalHash;
                       addListToHash mulCrit user "" !globalHash;
                       addListToHash mulCrit "" word !globalHash;
                       addListToHash mulCrit "" "" !globalHash
                       ) urlHash in ()
;;

let wordsPerUser = 1000;;

let weights_deal filename =
(*  postgres_init ();*)
  let conjunctions = Overseer_funs.get_cd () in
  let _ = fill_global_hash () in 
  let userList = ref [] in
  let _ = W_gatherer.get_user_list filename userList in
  let globalHash = ref (Hashtbl.create ((List.length !userList)*wordsPerUser)) in
  List.iter (fun user ->
            Printf.printf "DEBUG:gathering info about user %s\n" user;
            let queryList = ref [] in let _ = W_gatherer.get_query_list filename user queryList in
            List.iter (fun query ->
                      let wList = parse_query query conjunctions in
                      let _ = List.map (computeTable filename user query globalHash) wList in ()
                      ) !queryList;
            Printf.printf "DEBUG:gathering finished for user %s\n" user
            ) !userList;

  (* computing&exporting criteria *)
  Hashtbl.iter (fun (user,word) critList ->
               Printf.printf "user:[%s] word:[%s]\n" user word;
               List.iter (fun (c,v) -> Printf.printf "%d %d\n" c v ) critList;

               let sum = ref 0 in let _ = listSum critList sum in
               let sum = float_of_int !sum in
               let weightsList = List.map (fun (cId,cVal) ->
                    (cId,float_of_int(cVal) /. sum)
                    ) critList in
               export_weights_to_overseer user word weightsList
               ) !globalHash;
(*  postgres_close ()*)
;;
