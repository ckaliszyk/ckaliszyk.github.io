open Nethtml;;
open Types_see;;
open Types_a_see;;
(*open W_postgres;;*)
  
let global_word_hash = ref (Hashtbl.create 10);;

let hash_word = ref (Hashtbl.create 10);;
let hash_ctags = ref (Hashtbl.create 10);;
let hash_crit = ref (Hashtbl.create 10);;

(* for title saving *)
let gozdal_cout = open_out_bin "titles";;

(* currently name is outdated... saves only to file... FIXME *)
let save_title_to_file_and_to_postgres url title =
  (*W_postgres.save_title url title;*)
  output_value gozdal_cout (url, title)
;;


let link_deal crit_list ((min, max, ex_list) as u_def) ((url_name,url_tree_list) as url_p) oc = 
  let ex_list = List.map (String.lowercase) ex_list in
  let global_word_count = ref 0 in
  let keyword_list = ref [] in
  let description_list = ref [] in
  
  let get_meta_info params =
    let name = try List.assoc "name" params with Not_found -> "" in 
    let name = String.lowercase name in
    let keywords = if (name = "keywords") then 
      try List.assoc "content" params with Not_found -> ""
      else ""
    in
    let word = Buffer.create 1 in
    let save_to_keyword_list () =
      if (Buffer.length word > 0) then
        keyword_list := (Buffer.contents word) :: !keyword_list
    in
    String.iter ( fun c ->
      match c with
      | ',' -> save_to_keyword_list ();Buffer.reset word
      | _ -> Buffer.add_char word c
    ) keywords;
    save_to_keyword_list (); Buffer.reset word;
    let description = if (name = "description") then 
      try List.assoc "content" params with Not_found -> ""
      else ""
    in
    let save_to_description_list () =
      if (Buffer.length word > 0) then
        description_list := (Buffer.contents word) :: !description_list
    in
    String.iter ( fun c ->
      match c with
      | ' ' -> save_to_description_list ();Buffer.reset word
      | _ -> Buffer.add_char word c
    ) description;
    save_to_description_list (); Buffer.reset word
  in

  let save_title v =
    match v with
    | Data s -> save_title_to_file_and_to_postgres url_name s
    | Element (_,_,_) -> save_title_to_file_and_to_postgres url_name "" 
  in

  let make_hash_word () = 
    let tag_stack = ref [] in
    let rec traverse_tree v =
      match v with
      | Data s -> begin
          let word_buffer = Buffer.create 3 in
          let save_word () =
            let compute_new_word_info ((counter,tlist) as w_info) = 
              let newtlist = ref [] in
              let _ = List.iter ( fun (tag,count) ->
                  if (List.mem tag !tag_stack) then
                    newtlist := (tag,count+1) :: !newtlist
                  else
                    newtlist := (tag,count) :: !newtlist
                ) tlist in
              let _ = List.iter ( fun tag ->
                  try let _ = List.assoc tag !newtlist in ()
                  with Not_found -> newtlist := (tag,1) :: !newtlist
                ) !tag_stack in (counter + 1, !newtlist)
            in if (Buffer.length word_buffer > 0) then begin
              let smallword = String.lowercase (Buffer.contents word_buffer) in
              if (((String.length smallword) >= min) && 
                 ((String.length smallword) <= max) && not
                   (List.mem smallword ex_list)) then
                  begin
                   let word_info = try Hashtbl.find !hash_word smallword
                     with Not_found -> (0,[])
                   in Hashtbl.replace !hash_word smallword
                     (compute_new_word_info word_info);
                     global_word_count := !global_word_count+1;
              end
            end in
          let parse_words () =
            String.iter (fun c -> 
                  match c with
                  | ' ' | '\n' | '!' | '.' | ',' | ')'
                  | '(' | '['  | ']' | ':' | ';' | '"'
                  | '?' | '\'' -> save_word ();Buffer.reset word_buffer
                  | _ -> Buffer.add_char word_buffer c
              ) s;
            save_word(); Buffer.reset word_buffer
          in parse_words ()
         end
      | Element (tag_name,params,children) -> begin
          let tag_name = String.lowercase tag_name in
          tag_stack := tag_name :: !tag_stack;

          let _ = if (tag_name = "meta") then
            get_meta_info params in
          let _ = if (tag_name = "title") then
            if (children != []) then save_title (List.hd children)
            else save_title (Data "") in 

          let c = try Hashtbl.find !hash_ctags tag_name
            with Not_found -> 0 in
          Hashtbl.replace !hash_ctags tag_name (c+1);
          
          List.iter (traverse_tree) children;
          tag_stack := List.tl !tag_stack;
  end
  in
      Printf.printf "Gathering info about %s page\n" url_name;
      List.iter (traverse_tree) url_tree_list
  in make_hash_word ();
  (* criteria computations *)
  let compute_criteria word word_info =
    (* criteria definitions *)

    (* (word_count * 25) / global_word_count *)
    let criterion_1 word ((count,tlist) as word_info) =
    let count = (count * 25) / !global_word_count in
    if count > 10 then 10 else count
    in

    (* (word_count + word_countin tags)* 50 / global_word_count *)
    let criterion_2 word ((count,tlist) as word_info) =
      let count = 
      try List.assoc "b" tlist with Not_found -> 0
      in let count = count + try List.assoc "i" tlist with Not_found -> 0
      in let count = count + try List.assoc "a" tlist with Not_found -> 0
      in let count = count + try List.assoc "h1" tlist with Not_found -> 0
      in let count = count + try List.assoc "h2" tlist with Not_found -> 0
      in let count = count + try List.assoc "h3" tlist with Not_found -> 0
      in let count = count + try List.assoc "h4" tlist with Not_found -> 0
      in let count = count + try List.assoc "h5" tlist with Not_found -> 0
      in let count = count + try List.assoc "h6" tlist with Not_found -> 0
      in let count = (count * 50) / !global_word_count in
      if count > 10 then 10 else count
    in

    (* (img_count * 50) / global_word_count *)
    let criterion_3 () =
      let count = try Hashtbl.find !hash_ctags "img" with Not_found -> 0
      in let count = (count * 50) / !global_word_count in
      if count > 10 then 10 else count
    in

    (* (a_count * 50) / global_word_count *)
    let criterion_4 () =
      let count = try Hashtbl.find !hash_ctags "a" with Not_found -> 0
      in let count = (count * 50) / !global_word_count in
      if count > 10 then 10 else count
    in

    (* word in title ? 10 : 0 *)
    let criterion_5 word ((count,tlist) as word_info) =
      if ((try List.assoc "title" tlist with Not_found -> 0) = 0) then 0
      else 10
    in

    (* word in keywords ? 5 : 0 *)
    let criterion_6 word =
      if (List.mem word !keyword_list) then 5 else 0
    in

    (* word in description ? 5 : 0 *)
    let criterion_7 word =
      if (List.mem word !description_list) then 5 else 0
    in
    let clist = List.map ( fun (cid, _) ->
      if (cid == 1) then (cid,criterion_1 word word_info)
      else if (cid == 2) then (cid,criterion_2 word word_info)
      else if (cid == 3) then (cid,criterion_3 ())
      else if (cid == 4) then (cid,criterion_4 ())
      else if (cid == 5) then (cid,criterion_5 word word_info)
      else if (cid == 6) then (cid,criterion_6 word)
      else if (cid == 7) then (cid,criterion_7 word)
      else (cid,0)
    ) (Overseer_funs.get_crid () (*[1;2;3;4;5;6;7]*)) in
    Hashtbl.replace !hash_crit word clist;
    let old_list = try Hashtbl.find !global_word_hash word with Not_found -> [] in
    Hashtbl.replace !global_word_hash word ((url_name,clist) :: old_list)
  in

  Hashtbl.iter ( fun word ((c,tlist) as w_info) -> 
    compute_criteria word w_info;
    (*Printf.printf "WORD:%s %d\n" word c;
    List.iter (fun (tag,count) ->
      Printf.printf "\tTAG:%s %d\n" tag count
    ) tlist*)
  ) !hash_word;
  output_value oc (url_name,!hash_crit);

  Hashtbl.clear !hash_word;
  Hashtbl.clear !hash_ctags;
  Hashtbl.clear !hash_crit;
;;

