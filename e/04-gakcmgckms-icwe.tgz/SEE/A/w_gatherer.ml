(* w_gatherer.ml
 *
 * 2004.06.01, Mateusz Srebrny, BLogReader truely used
 * 2004.05.29, Marcin Gozdalik, redesigned for new BLogReader
 * 2003.11.11, Marcin Gozdalik, small tweaks for new BLogIterator
 * 2003.06.20, Mateusz Srebrny, redesigned to use with BLogIterator
 * 2003.06.17, Mateusz Srebrny, created
 *)

(* from cmd line... don't remember the meaning *)
let url_prefix = ref "";;

(* ulr - user list reference *)
let user_iterator ulr (cli_no, _, _) =
  if not (List.mem cli_no !ulr) then
    ulr := cli_no :: !ulr;
;;

let get_user_list filename ulr = 
  ulr := [];
  let blog_list = Blogreader.read filename in
  List.iter (user_iterator ulr) blog_list;
;;

let query_iterator qlr user (cli_no, _, clicks) =

  let query_iterator_inner (_, url_from, _, _) = 
    if (not (List.mem url_from !qlr)) then
      qlr := url_from :: !qlr
  in
  
  if (user == cli_no) then
    List.iter query_iterator_inner clicks
;;


let get_query_list filename user qlr = 
  qlr := [];
  let blog_list = Blogreader.read filename in
  List.iter (query_iterator qlr user) blog_list;
;;

let url_iterator ulr user from (cli_no, _, clicks) =

  let url_iterator_inner (_, url_from, url_to, _) = 
  
    if (from = url_from) && (not (List.mem (!url_prefix ^ url_to) !ulr)) then
    ulr := (!url_prefix ^ url_to) :: !ulr;
  in
  
  if (user = cli_no) then 
    List.iter url_iterator_inner clicks;
;;

let get_url_list filename user from ulr = 
  ulr := [];
  let blog_list = Blogreader.read filename in
  List.iter (url_iterator ulr user from) blog_list;
;;

