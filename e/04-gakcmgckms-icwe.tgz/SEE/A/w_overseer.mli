(** This module contains functions we use to export computed weights
 *  to Overseer.
 *  
 *  @author Micha� Matusiak
 *)

(** This function exports list of weights to Overseer. It takes 
 *  three params: user, word and list mentioned. The element of the list is
 *  (integer, float) pair where integer stands for criterion number
 *  and float is this criterion weight.
 *
 *  @author Micha� Matusiak
 *)
val export_weights_to_overseer: string -> string -> (int*float) list -> unit;;
