(* types_see.mli
 * 
 *  2003.05.04, Mateusz Srebrny,  revised and ocamldoced
 *)
 
(** Module Types_see defines types shared by whole SEE module (i.e.
 *  by E-SEE, A-SEE and many others).
 *
 *  @author Mateusz Srebrny, Radek Borecki
 *)

(** Type of criteria values. List of pairs (criterion_id, criterion_value). *)
type criteria = (int * int) list;;

(** Resource id. *)
type uurl = string;;

(** Resource data (for word's point of view), string stands for description *)
type uurl_data = (uurl * string * criteria * float);;

(** Type of uninteresting words definition.
 *  (min_length, max_length, list of excluded words)
 *)
type uninteresting_words_definition = int * int * string list;;

(** Data kept with each word *)
type uurl_list = uurl_data list;;

(** Type of weights values. List of (criterion_id, criterion_weight). *)
type weights = (int * float) list;;

(* To moj pomys�, do uzgodnienia z eLeLem. Wywolujac ichni� funkcj�
 * get_parsed_xxx_html() chcia�bym dosta� list� takich obiekt�w
 *)
(*type url_package = { url      : string; (*adres do zaproponowania userowi*)
                     resource : Nethtml.document list;
};;
*)
type url_package = string * Nethtml.document list;;
