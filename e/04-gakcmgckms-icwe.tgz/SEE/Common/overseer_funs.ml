(* overseer_funs.ml
 *
 * 2003.01.12,  Mateusz Srebrny,  created 
 *)

open Db;;
open Types_see;;

let searchfile = ref "SEE";;
let query = ref "query";;
let page = ref "page";;
let links_per_page = ref 10;;
let global_share = ref 5;;
let _and = ref "and";;
let _or = ref "or";;
let _minus = ref "minus";;
let min_length = ref 3;;
let max_length = ref 12;;
let uninteresting = ref [];;
let criteria  = ref [1; 2; 3; 4; 5; 6; 7];;
let fixed_weights = ref None;;
let searchengine = ref "SEE";;
let adapter_links = ref 1;;
let host = ref "http://localhost:8080/"

(* FIXME *)
let tbl_config : (string, string) t = init "config" None;;

(* splits str into string list by pluss result stores on ans *)
let rec string_list_of_string str ans =
  if str = "" then ans else
  try
    (*TODO czy to zawsze sa spacje *)
    let first_space = String.index str ' ' in
    if first_space = 0 then
      string_list_of_string (String.sub str 1 (String.length str - 1)) ans
    else
      string_list_of_string
        (String.sub str (first_space + 1)(String.length str - 1 - first_space))
        ((String.lowercase (String.sub str 0 (first_space))) :: ans)
  with
    Not_found ->
      List.rev ((String.lowercase str) :: ans)
;;

let rec int_float_list_of_string_list strl ans = 
  match strl with 
  | [] | _ :: [] -> List.rev ans
  | i :: f :: t -> 
    int_float_list_of_string_list t 
      ((int_of_string i, float_of_string f) :: ans)
;;

let config_init () =
  ignore (searchfile := match get tbl_config "searchfile" with
                        | None -> "SEE"
                        | Some (s) -> s
         );
  ignore (query := match get tbl_config "query" with
                   | None -> "query"
                   | Some (q) -> q
         );
  ignore (page := match get tbl_config "page" with
                  | None -> "page"
                  | Some (p) -> p
         );
  ignore (links_per_page := match get tbl_config "links_per_page" with
                            | None -> 10
                            | Some (lpp) -> 
                              try 
                                int_of_string lpp
                              with
                              | Failure s -> assert false
         );
  ignore (global_share := match get tbl_config "global_share" with
                          | None -> 5
                          | Some (gs) -> 
                            try 
                              int_of_string gs
                            with
                            | Failure s -> assert false
         );
  ignore (_and := match get tbl_config "and" with
                  | None -> "and"
                  | Some (a) -> a
         );
  ignore (_or := match get tbl_config "or" with
                  | None -> "or"
                  | Some (o) -> o
         );
  ignore (_and := match get tbl_config "minus" with
                  | None -> "minus"
                  | Some (m) -> m
         );
  ignore (min_length := match get tbl_config "min_length" with
                        | None -> 3
                        | Some (m) -> 
                          try 
                            int_of_string m
                          with
                         | Failure s -> assert false
         );
  ignore (max_length := match get tbl_config "max_length" with
                        | None -> 12
                        | Some (m) -> 
                          try 
                            int_of_string m
                          with
                         | Failure s -> assert false
         );
  ignore (uninteresting := match get tbl_config "uninteresting" with
                           | None -> ["jednak"; "jest"]
                           | Some (wl) -> string_list_of_string wl []
         );
  ignore (criteria := match get tbl_config "criteria" with
                      | None -> [1; 2; 3; 4; 5; 6; 7]
                      | Some(cri) ->
                        try
                          List.map int_of_string (string_list_of_string cri [])
                        with
                        | Failure s -> assert false
         );
  ignore (fixed_weights := match get tbl_config "fixed_weights" with
                           | None -> None
                           | Some(fw) -> 
                             if (fw = "None") then
                               None
                             else
                               try
                                 let sl = string_list_of_string fw [] in
                                 Some (int_float_list_of_string_list sl [])
                               with
                               | _ -> assert false
         );
   ignore (searchengine := match get tbl_config "searchengine" with
                           | None -> "SEE"
                           | Some (s) -> s
          );
   ignore (adapter_links := match get tbl_config "adapter_links" with
                            | None -> 1
                            | Some (al) -> 
                              try
                                int_of_string al
                              with
                              | Failure _ -> assert false
         );
   ignore (host := match get tbl_config "host" with
                   | None -> "http://localhost:8080/"
                   | Some h -> h
          );
   ()
;;

(* retrieves name of search engine resources *)
let get_fn () = !searchfile;;

(* @param see_name name of searchengine file *)
let set_fn see_name = set tbl_config "searchfile" see_name;;

(* auxiliary function, gets query_string *)
let get_query () = !query;;

(* auxiliary function, gets page_string *)
let get_page () = !page;;

(* retrieves the above *)
let get_pn () = (get_query (), get_page ());;

(* 
 * @param query string to be used to denote query in requests to searchengine
 *  @param page string to be used to denote page in requests to searchengine 
 *)
let set_pn (query, page) = 
  set tbl_config "query" query;
  set tbl_config "page" page
;; 

(* auxiliary function, gets links_per_page *)
let get_lpp () = !links_per_page;;

(* auxiliary function, gets global_share *)
let get_gs () = !global_share;;

(* retrieves the above *)
let get_ps () = (get_lpp (), get_gs ());;

(* 
 * @param lpp number of links per page
 *  @param gs number of global links per page 
 *)
let set_ps (lpp, gs) = 
  set tbl_config "links_per_page" (string_of_int lpp); 
  set tbl_config "global_share" (string_of_int gs) 
;;

(* auxiliary function, gets and *)
let get_and () = !_and;;

(* auxiliary function, gets or *)
let get_or () = !_or;;

(* auxiliary function, gets minus *)
let get_minus () = !_minus;;

(* extracts conjunction strings from Overseer *)
let get_cd () = (get_and (), get_or (), get_minus ());;

(* 
 * @param _and string denoting and conjunction
 *  @param _or string denoting or conjunction
 *  @param _minus string denoting minus conjunction
 *)
let set_cd (_and, _or, _minus) =
  set tbl_config "and" _and;
  set tbl_config "or" _or;
  set tbl_config "minus" _minus
;;

let get_min () = !min_length;;

let get_max () = !max_length;; 

let get_uniw () = !uninteresting;;

let get_uwd () = (get_min (), get_max (), get_uniw ());;

(* 
 * @param min minumum length of interesting word
 *  @param max maximum length of interesting word
 *  @param uwl list of uninteresting word 
 *)
let set_uwd (min, max, uwl) = 
  set tbl_config "min_length" (string_of_int min);
  set tbl_config "max_length" (string_of_int max);
  set tbl_config "uninteresting" (String.concat " " uwl)
;;


let get_cri () = !criteria;;

(* @param criteria list of int criterion identifiers *) 
let set_cri cril = 
  set tbl_config "criteria" (String.concat " " (List.map string_of_int cril))
;;

let get_fw () = !fixed_weights;;
    
(* @param fixed_weights weights to be fixed *)
let set_fw fixed_weights = 
  match fixed_weights with 
  | None -> set tbl_config "fixed_weights" "None"
  | Some (fw) ->
    let mapper (i, f) = [string_of_int i; string_of_float f] in
    let sl = List.concat (List.map mapper fw) in
    set tbl_config "fixed_weights" (String.concat " " sl) 
;;

let get_se () = !searchengine;;
let get_al () = !adapter_links;;
let get_host () = !host;;

(* FIXME *)
(* prepares connection with Overseer in order to get words' weights *)
let tbl_ww : (string, weights) t = init "see-words-weights" None;;

(* gets the above *)
(* @param word the word, empty word denotes all words *)
let get_ww word = 
  match get tbl_ww word with
  | None -> []
  | Some(w) -> w
;;

(* 
 * @param word the word, empty word denotes all words 
 *  @param w weights to be set for [word]
 *)
let set_ww word w = set tbl_ww word w;;

(* prepares connection with Overseer in order to get user-words' weights *)
let tbl_uww : (string * string, weights) t = 
  init "see-users-words-weights" None
;;

(* gets the above *)
(* @param user_word the pair [(user, word)], empty word denotes all words *)
let get_uww (user_word) = 
  match get tbl_uww user_word with
  | None -> []
  | Some(w) -> w
;;

(* 
 * @param user_word the pair [(user, word)], empty word denotes all words 
 *  @param w weights to be set for [user] and [word]
 *)
let set_uww user_word w = set tbl_uww user_word w;;

(* prepares connection with Overseer in order to get info about 
 * urls containing particular word
 *)
let tbl_w :(string, uurl_list) t = init "see-words" None;;

(* retrieves the above *)
(* @param word the word *)
let get_w word = 
  match (get tbl_w word) with
  | None -> []
  | Some(ul) -> ul
;;

(* 
 * @param word word occurring in urls at [urllist]
 *  @param urllist list of tuples describing an url from the point of view
 *  @param urllist of [word]: (adress, context of [word] in url, list of 
 *  @param criteria values, float easing a bit further computations
 *)
let set_w word urllist = set tbl_w word urllist;; 

let get_crid () = 
    [(1, "(number of occurances of keyword * 25) / number of words"); 
     (2, "(number of occurances of keyword in specified tags * 50) / number of words"); 
     (3, "(numer of images * 50)/ number of words");
     (4, "(numer of a-tags * 50)/ number of words");
     (5, "keyword in title ? 10 : 0");
     (6, "keyword in keywords ? 5 : 0");
     (7, "keyword in description ? 5 : 0")
    ]
;;

let tbl_titles : (string, string) t = 
  init "see-urls-titles" None
;;

(* @param url url to sought title for *)
let get_title url = 
  match get tbl_titles url with
  | None -> "No title"
  | Some (title) -> title
;;

(* 
 * @param url url to set title for 
 *  @param title to be set for url
 *)
let set_title url title = set tbl_titles url title;;
