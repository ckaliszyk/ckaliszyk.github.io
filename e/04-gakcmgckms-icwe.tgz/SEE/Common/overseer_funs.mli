(* overseer_funs.mli
 *
 * 2003.06.22,  Mateusz Srebrny, functions set_p and get_p moved to Panel.panel
 * 2003.04.15,  Mateusz Srebrny,  created 
 *)

(** Overseer_funs module is useful interface to SEE's tables in 
 *  Overseer. 
 *  It defines function to both set and get value from 
 *  each of SEE's tables.
 *  It is used mainly by E-SEE and A-SEE, but G-SEE also benefits from it.
 *
 *  Overseer_funs module is used in three ways:
 *  - to get some cofiguration - {! Overseer_funs.config_init} gets all the
 *    configuration from Overseer and functions such as {! Overseer_funs.get_pn}
 *    gets data from the output of config_init and not from Overseer 
 *    again.
 *
 *)

(** [config_init ()] Gets all SEE configuration options from table "config"
 *  in Overseer. Parses them and stores them.
 *  SEE configuration consists of: searchfile, query, page, 
 *  links_per_page, global_share, and, or, minus, min_length, max_length,
 *  uninteresting, criteria and fixed_weights, searchengine, adapter_links.
 *
 *  It is called on load of Overseer_funs module.
 *
 * @author Mateusz Srebrny
 *)
val config_init : unit -> unit;;

(** Seeks name of the file used as action for searching (in Overseer).
 *  Looks fot it in table "config" under "searchfile" name.
 *
 * @return name of searchfile
 * @author Mateusz Srebrny
 *)
val get_fn : unit -> string;;

(** [set_fn see_name] 
 *  Exports name of the file used as action for searchnig (to Overseer).
 *  Sets it in table "config" under "searchfile" name.
 *
 * @param see_name name of searchengine file   
 * @author Mateusz Srebrny
 *)
val set_fn : string -> unit;;

(** Seeks names of parameters used to pass query and number of
 *  page with links through http (GET) (in Overseer).
 *  Looks for them in table "config" under the names "query" and "page".
 *
 * @return string pair consisting of described names
 * @author Mateusz Srebrny
 *)
val get_pn : unit -> (string * string);;

(** [set_pn (query, page)]
 *  Exports names of parameters used to pass query and number of
 *  page with links through http (GET) (to Overseer).
 *  Sets them in table "config" under the names "query" and "page".
 *
 * @param query string to be used to denote query in requests to searchengine
 * @param page string to be used to denote page in requests to searchengine 
 * @author Mateusz Srebrny
 *)
val set_pn : (string * string) -> unit;; 

(** Seeks number of links per page (with search results) and 
 *  number of global links per page (with search results) (in Overseer).
 *  Looks fot it in table "config" under "links_per_page" and "global_share"
 *  names.
 *
 * @author Mateusz Srebrny
 *)
val get_ps : unit -> (int * int);;

(** [set_ps lpp gs]
 *  Exports number of links per page (with search results) and 
 *  number of global links per page (with search results) (to Overseer).
 *  Sets them in table "config" under the names "links_per_page" and 
 *  "global_share".
 *
 * @param lpp number of links per page
 * @param gs number of global links per page 
 * @return described ints
 * @author Mateusz Srebrny
 *)
val set_ps : (int * int) -> unit;;

(** Seeks definitions of conjunctions used in queries, namely [and],
 *  [or] and [minus] (in Overseer).
 *  Looks for them in table "config" under the names "and" "or"  and "minus".
 *
 * @return triple of strings describing conjunctions
 * @author Mateusz Srebrny
 *)
val get_cd : unit -> (string * string * string);;

(** [set_cd _and _or _minus]
 *  Exports definitions of conjunctions used in queries, namely [and],
 *  [or] and [minus] (to Overseer).
 *  Sets them in table "config" under the names "and", "or" and "minus".
 *
 * @param _and string denoting and conjunction
 * @param _or string denoting or conjunction
 * @param _minus string denoting minus conjunction
 * @author Mateusz Srebrny
 *)
val set_cd : (string  * string * string) -> unit;;

(** Seeks uninteresting words definition (in Overseer).
 *  Uninteresting words definition consists of mininum and maximum lengths
 *  of interesting word and a list of uninteresting words matching lengths 
 *  constraints.
 *  Looks for them in table "config" under the names "min_length", 
 *  "max_length" and "uninteresting".
 * 
 * @return current uninteresting words definition
 * @author Mateusz Srebrny
 *)
val get_uwd : unit -> Types_see.uninteresting_words_definition;;

(** [set_uwd (min, max, uwl)]
 *  Exports uniteresting words definition to Overseer.
 *  Sets them in table "config" under the names "min_length", 
 *  "max_length" and "uninteresting".
 *
 * @param min minumum length of interesting word
 * @param max maximum length of interesting word
 * @param uwl list of uninteresting word 
 * @author Mateusz Srebrny
 *)
val set_uwd : Types_see.uninteresting_words_definition -> unit;;

(** Seeks list of criteria's id to use (in Overseer).
 *  Looks for them in table "config" under the names "criteria".
 *
 * @return list of criteria's int identifiers
 * @author Mateusz Srebrny
 *)
val get_cri : unit -> int list;;

(** [set_cri cri]
 *  Exports list of criteria's id to use (to Overseer).
 *  Sets them in table "config" under the names "criteria".
 *
 * @param criteria list of int criterion identifiers    
 * @return list of criteria's int identifiers
 * @author Mateusz Srebrny
 *)
val set_cri : int list -> unit;;

(** Seeks definition of fixed weights to use instead of weights computed
 *  by A-SEE (in Overseer).
 *  Looks for them in table "config" under the names "fixed_weights".
 *
 * @return fixed weights
 * @author Mateusz Srebrny
 *)
val get_fw : unit -> Types_see.weights option;;

(** [set_fw w]
 *  Exports definition of fixed weights to use instead of weights computed
 *  by A-SEE (in Overseer).
 *  Sets them in table "config" under the names "fixed_weights".
 *
 * @param fixed_weights weights to be fixed   
 * @author Mateusz Srebrny
 *)
val set_fw : Types_see.weights option -> unit;;

(** Seeks host name in Overseer (table "config", key "host"). *)
val get_host : unit -> string;;

(** [get_ww word] Seeks global weights computed for given word (in Overseer).
 *  Uses table "see-words-weights".
 *
 * @param word the word, empty word denotes all words   
 * @return global weights for word
 * @author Mateusz Srebrny
 *)
val get_ww : string  -> Types_see.weights;;

(** [set_ww word w] Exports global weights computed for given word 
 *  (to Overseer).
 *  Uses table "see-words-weights".
 *
 * @param word the word, empty word denotes all words 
 * @param w weights to be set for [word]
 * @author Mateusz Srebrny
 *)
val set_ww : string -> Types_see.weights -> unit;;

(** [get_uww (user, word)] Seeks personnal weights computed for user and word 
 *  (in Overseer).
 *  Uses table "see-users-words-weights".
 *
 * @param user_word the pair [(user, word)], empty word denotes all words   
 * @return weights for user and word
 * @author Mateusz Srebrny
 *)
val get_uww : (string * string) -> Types_see.weights;;

(** [set_uww (user, word) w] Exports personnal weights computed for given 
 *  user and word (to Overseer).
 *  Uses table "see-users-words-weights".
 *
 * @param user_word the pair [(user, word)], empty word denotes all words 
 * @param w weights to be set for [user] and [word]
 * @author Mateusz Srebrny
 *)
val set_uww : (string * string) -> Types_see.weights -> unit;;

(** [get_w word]
 *  Seeks info about urls containing particular word (in Overseer).
 *  Uses table "see-words".
 *
 * @param word the word   
 * @return list of url describing tuples
 * @author Mateusz Srebrny
 *)
val get_w : string -> Types_see.uurl_list;;

(** [set_w word urllist]
 *  Export info about urls containing particular word (to Overseer).
 *  Uses table "see-words".
 *
 * @param word word occurring in urls at [urllist]
 * @param urllist list of tuples describing an url from the point of view
 *        urllist of [word]: (adress, context of [word] in url, list of 
 *        criteria values, float easing a bit further computations
 * @author Mateusz Srebrny
 *)
val set_w : string -> Types_see.uurl_list -> unit;;

(** Returns list of criteria and their descriptions.
 *  The list is hardcoded.
 *
 * @return list of pairs (int identifier of criterion, criterion description)
 * @author Mateusz Srebrny
 *)
val get_crid : unit -> (int * string) list

(** [get_title url] Seeks title of an url in Overseer.
 *  Uses table "see-urls-titles".
 *
 * @param url url to sought title for   
 * @return title of [url]
 * @author Mateusz Srebrny
 *)
val get_title : string -> string;;

(** [set_title url title] Export title of an url to Overseer.
 *  Uses table "see-urls-titles".
 *
 * @param url url to set title for 
 * @param title to be set for url
 * @author Mateusz Srebrny
 *)
val set_title : string -> string -> unit;;
