(* gozdal_funs.mli
 *
 * 2003.06.17, Mateusz Srebrny,  save_title removed
 * 2003.05.04, Mateusz Srebrny,  revised and ocamldoced
 *)

(** Module Gozdal_funs is responsible for functions
 *  prepared by Mati. team for Gozdal team.
 *
 *  to be updated...
 *  These functions generally stores some data in "titles" file 
 *  during execution of A-SEE and retrieves the data 
 *  when Gozdal needs it.
 *
 *  @author Mateusz Srebrny, Micha� Matusiak
 *)

(** [get_title url] Retrieves title of url 
 *  (from "titles" file (read on load)).
 *
 * @param url url to get title for 
 * @return title of requested url
 *)
val get_title : string -> string;;

(** Retrieves list of (url, title) from 
 * 
 *  @return list of pairs : (url, title)
 *)
val get_urls_titles : unit -> (string * string) list;; 

val get_url_word_list : string -> (int * ((string,int) Hashtbl.t));;
