(* gozdal_funs.ml
 *
 * 2003.06.17, Mateusz Srebrny,  switched from postgreSQL to "titles" file
 * 2003.05.04, Mateusz Srebrny,  revised and ocamldoced
 *)


(* list of (url, title) pairs *)
let urls_titles = ref [];;

(* onload retrieval of url_titles from "titles" file *)
let gic = open_in_bin "titles" in
let rec titles () =
  let pair : (string * string) = input_value gic in
  urls_titles := pair :: !urls_titles;
  titles ()
in
try titles () with End_of_file -> ();;

let get_title url = 
  try
    List.assoc url !urls_titles
  with 
  | Not_found -> "No title"
;;

(* simple *)
let get_urls_titles () = !urls_titles;;

let global_url_hash = ref (Hashtbl.create 10);;

let fill_global_hash () =
  let ic = open_in_bin "crits" in
  let rec get () =
    let x: (string*((string,((int*int) list))Hashtbl.t))
      = input_value ic in
    let (url_name,crit_hash) = x in
    Hashtbl.replace !global_url_hash url_name crit_hash; get ()
  in
    try
      get ()
    with End_of_file -> ()
;;

let get_url_word_list url_name =
  fill_global_hash ();
  let word_hash = ref (Hashtbl.create 10) in
  let word_count = ref 0 in
  let crit_hash = Hashtbl.find !global_url_hash url_name in
  let _ = Hashtbl.iter ( fun word clist ->
    let this_word_count = try (List.assoc 1 clist) with Not_found -> 0 in
    word_count := !word_count + this_word_count;
    Hashtbl.replace !word_hash word this_word_count; 
  ) crit_hash in
  (!word_count,!word_hash)
;;
