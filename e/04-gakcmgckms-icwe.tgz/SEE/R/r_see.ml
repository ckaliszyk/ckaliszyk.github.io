(* r_see.ml
 *
 * 20.06.2003, Mateusz Srebrny, created
 *)

let read_filenames () = 
  try 
    let cin = open_in "filelist.txt" in
    let rec get filel = 
      try
        let file = input_line cin in
        get (file :: filel) 
      with 
      | End_of_file -> filel
    in
    get []
  with
  | Sys_error s -> 
    Printf.printf "R-SEE: reading of filelist.txt failed: %s" s; []
;;

let host = Overseer_funs.get_host ();;

let make_url filename = 
  let pat = Some "site" in
  let templ = Some host in 
  Pcre.replace_first ?pat ?templ filename
;;


let parse filename =
  let url = make_url filename in
  try
    let file = open_in filename in  
    let dtd = Nethtml.relaxed_html40_dtd in
    let page = Nethtml.parse ~dtd (new Netchannels.input_channel file) in
    url, page
  with
  | Sys_error _ -> Printf.printf "R-SEE: %s ignored\n" filename; url, []
  | _ -> failwith ("R_see.parse \""^filename^"\"")
;;

let rec printer e = 
  match e with 
  | Nethtml.Data s -> Printf.printf "( %s )" s
  | Nethtml.Element (n, a, c) -> 
    Printf.printf "<%s>" n;
    List.iter printer c;
    Printf.printf "</%s>" n
;;

let print_page = List.iter printer;;

let iterator name =
  Printf.printf "R-SEE: file: %s\n" name;
  let url, page = parse name in
  Printf.printf "R-SEE: url: %s\n" url;
  print_page page;
  print_newline ();
  url, page
;;
let parse_list = List.map iterator;;

let get_parsed_html () = parse_list (read_filenames ());; 
