(* r_see.mli
 *
 * 20.06.2003, Mateusz Srebrny, created
 *)

(** R(obot)_see 
 *
 *  @author Mateusz Srebrny 
 *)
(** [parse filename] parses filename to list of Nethtml.Document *)
val parse : string -> string * Nethtml.document list;;

val parse_list : string list -> (string * Nethtml.document list) list;;

val get_parsed_html : unit -> (string * Nethtml.document list) list;;
