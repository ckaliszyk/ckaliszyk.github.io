(* list_merger.mli
 * 
 * 2003.05.02,  Mateusz Srebrny,  ocamldoced
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
(** Module List_merger is responsible for construction of two lists of links
 *  from user's query. The first of two lists is lists of links in order
 *  obtained using user's preferences. The second has order obtained from
 *  global (all users') preferences.
 *
 *  The module divides work into two stages.
 *  The first stage consists of recording lists of links including 
 *  singular words. {! Overseer_interrogator} is responsible for invoking
 *  this stage.
 *
 *  The second stage merges recorded lists. It is invoked by {! Query}.
 *
 *  @author "Mateusz Srebrny"
 *)

(** [import_data (word, urllist)] Records list of links including a word.
 *  Called by {! Overseer_interrogator} to pass data got from OverSeer.
 *
 *  @param word a word 
 *  @param urllist list of links including [word] (and criteria values)
 *
 *  Implements the first stage of module work.
 *)
val import_data : string * Types_see.uurl_list -> unit;;

(** Implements the second stage of module work. 
 *  [merge_lists user query_tree] Constructs two lists of sorted links of
 *  lists of links supported by the first stage {! Overseer_interrogator}
 *
 *  @param user represents querying user
 *  @param query_tree tree constructed of query got from user
 *  @return pair of lists of links (personnal, global)
 *) 
val merge_lists : string -> Types_e_see.query_tree 
      -> (Types_see.uurl_data list * Types_see.uurl_data list)
;;
