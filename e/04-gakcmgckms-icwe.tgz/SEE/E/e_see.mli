(* e_see.mli
 *
 * 2003.04.13,  Mateusz Srebrny, ocamldoced
 * 2003.03.21,  Mateusz Srebrny, response_modifier has been told "farewell"
 * 2003.03.16,  Mateusz Srebrny, renamed from broker.mli
 * 2003.01.07,  Mateusz Srebrny, created & fully operational
 *)

(** Module E_see is a wrapper module for {! Query} and {! Panel} 
 * that deal with http requests on their way through the Box
 * to http server. It distributes requests to two mentioned modules.
 *
 * @author Mateusz Srebrny
 *)

val init : unit -> Types.sie_module_init;;
