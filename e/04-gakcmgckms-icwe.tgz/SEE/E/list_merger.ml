(* list_merger.ml
 * 
 * 2003.05.02,  Mateusz Srebrny,  ocamldoced
 * 2003.01.12,  Mateusz Srebrny,  overseer tables thrown to overseer_funs.ml
 * 2003.01.08,  Mateusz Srebrny,  operational (deprecated list_of_query_tree)
 * 2002.12.14,  Mateusz Srebrny, Czarek Kaliszyk,  revised
 *)
 
open Types_e_see;;
open Types_see;;
open List_ops;;


(* retrieves weights fixed by admin *)
let fixed_weights = Overseer_funs.get_fw ();;

(* retrieves global weights *)
let global_weights () = 
  match fixed_weights with
  | None -> Overseer_funs.get_ww ""
  | Some(fw) -> fw
;;

(* retrieves global word's weights *)
let global_words_weights word = 
  match fixed_weights with
  | None ->
    begin 
  match Overseer_funs.get_ww word with
  | [] -> global_weights ()
  | w -> w
    end
  | Some(fw) -> fw
;;

(* retrieves personal user's weights *)
let personal_users_weights user = 
  match fixed_weights with
  | None -> 
    begin
  match Overseer_funs.get_uww (user, "") with
  | [] -> global_weights ()
  | w -> w
    end
  | Some(fw) -> fw
;;

(* retrieves personal user-word's weights *)
let personal_users_words_weights user word = 
  match fixed_weights with
  | None -> 
    begin
  match Overseer_funs.get_uww (user, word) with
  | [] -> personal_users_weights user
  | w -> w
    end
  | Some(fw) -> fw
;;

(* global (for this module) variable for storing list of
 *  link lists got by overseer_interrogator from OverSeer 
 *)
let global_wl = ref [];;

(* called by overseer_interrogator to pass data got from OverSeer *)
(* @param wi word_info record containing a word and list of links
 *  @param wi including this word (and criteria values)
 *)
let import_data wi = 
  global_wl := wi :: !global_wl
;;

(* list of priorititiezed uurls *)
type decorated_url_list = (uurl_data * float) list;;

(* gets data linked with w on word_info list wl *)
let rec get_uurl_list_for_word_of_word_list wl w =
  try 
    List.assoc w wl
  with
  | Not_found -> assert false
;;

(* gets data linked with w on word_info list global_wl *)
let get_uurl_list_for_word w =
  get_uurl_list_for_word_of_word_list !global_wl w
;;

(*TODO nazwy kryteri�w 
 * oco tu chodzi ^^^ ?FIXME
 *)
(* computes priority of page characterized by list of criteria's values
 * (crit_list) and list of weights (weight_list).
 * elements on both lists are pairs (int, criterion/weight): 
 *)
let rec priority crit_list weight_list = 
  match crit_list with
  | [] -> 0.
  | (cri_id, cri_val) :: t ->
      try
        let w = List.assoc cri_id weight_list in
        let new_weight_list = List.remove_assoc cri_id weight_list in
        (w *. (float_of_int cri_val)) +. (priority t new_weight_list)
      with
      | _ -> priority t weight_list 
;;

(* to use with List.sort in priority_sort *)
let priority_comparer (u1,d1,c1,p1) (u2,d2,c2,p2) = compare p2 p1;;

(* sorts uurl_list considering priority field *)
let priority_sort ulist = List.sort priority_comparer ulist;;

(* returns list of links with computed priorities. 
 * the computations use weights retrieved by weights_retriever
 *)
let rec decorate_uurl_list weight_list ul = 
  match ul with
  | [] -> []
  | (u, d, crit, _) :: t ->
    let smaller_list = decorate_uurl_list weight_list t in
    (u, d, crit, (priority crit weight_list)) :: smaller_list
;;


(* returns list of links with computed priorities. 
 * the computations use personal weights
 *)
let personally_decorate_uurl_list user word ul = 
  decorate_uurl_list (personal_users_words_weights user word) ul
;;


(* returns sorted list of links. links are obtained from Overseer
 * for words from query tree (qt). lists are merged according
 * to conjunctions from inner nodes of qt. sorting uses weights
 * prepared by decorator
 *)
let rec list_of_query_tree decorator qt =
  match qt with
  | Null -> []
  | Leaf(w) -> decorator w (get_uurl_list_for_word w)
  | Node(qt1, c, qt2) ->
    let f = merge_fun_of_conjunction c in
    let l1 = list_of_query_tree decorator qt1 in
    let l2 = list_of_query_tree decorator qt2 in
    f l1 l2
;;

(* returns sorted list of links. links are obtained from Overseer
 * for words from query tree (qt). lists are merged according
 * to conjunctions from inner nodes of qt. sorting uses personal 
 * weights.
 *)
let personal_list_of_query_tree user qt =
  list_of_query_tree (personally_decorate_uurl_list user) qt
;;

(* returns list of links with computed priorities. 
 * the computations use global weights
 *)
let globally_decorate_uurl_list word ul = 
  decorate_uurl_list (global_words_weights word) ul
;;

(* returns sorted list of links. links are obtained from Overseer
 * for words from query tree (qt). lists are merged according
 * to conjunctions from inner nodes of qt. sorting uses global 
 * weights.
 *)
let global_list_of_query_tree qt = 
  list_of_query_tree globally_decorate_uurl_list qt
;;

(*  @param user represents querying user
 *  @param query_tree tree constructed of query got from user
 *)
let merge_lists user query_tree = 
  let personal_list = 
        priority_sort (personal_list_of_query_tree user query_tree) 
  in
  let global_list = priority_sort (global_list_of_query_tree query_tree) in
  (personal_list, global_list)
;;

