(* output_formatter.mli
 * 
 * 2003.05.03,  Mateusz Srebrny, ocamldoced
 * 2003.01.08,  Mateusz Srebrny, exported functions added
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
(** Module Output_formatter deals with construction of html-code
 *  presenting results of search.
 *
 *  It exports only one function that does all the job.
 *
 *  Module is used by {! Query}.
 *
 * @author Mateusz Srebrny
 *)

(** [generate_output request gl pl] Produces html code for the search results. 
 * Resulting page is stored in to_server field of [request].
 * Query is retrieved from [request] as well as information which 
 * page of links (which tenth) is to be presented.
 * Links on both personal and global lists are mixed so on each page
 * is certain amount of global links and of personal links.
 *
 * @param request http-request for query 
 * @param gl list of urls sorted using global weights
 * @param pl list of urls sorted using personal weights
 * @author Mateusz Srebrny
 *)
val generate_output : Types.request -> Types_see.uurl_list 
                        -> Types_see.uurl_list -> Types.response;;

(** [test_output gl pl] Produces text output similar to its html counterpart 
 *  produced by {! Output_formatter.generate_output}. Exported for T-SEE only.
 *
 * @param gl list of urls sorted using global weights
 * @param pl list of urls sorted using personal weights
 *)
val test_output : Types_see.uurl_list -> Types_see.uurl_list -> unit;;
