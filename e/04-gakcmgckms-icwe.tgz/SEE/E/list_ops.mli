(* list_ops.mli
 * 
 * 2002.05.03,  Mateusz Srebrny, ocamldoced
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
(** Module List_ops is lesser module.
 *  It provides functions operating on url lists.
 *
 *  Modules {! List_merger} and {! Output_formatter} use
 *  some of List_ops' functions
 *
 *  @author Mateusz Srebrny
 *)

(** [uurl_on_list udata url_data] Tests if url is on list of urls.
 *
 * @param udata describes url to be sought on url_list
 * @param url_list describes list of urls scanned for url
 * @return true iff url is on url_list 
 *)
val uurl_on_list : Types_see.uurl_data -> Types_see.uurl_list -> bool;;

(** [uniquify_list ulist] Removes repeated list elements.
 * 
 * @param ulist list of urls to uniquify *
 * @return list of urls without repeating elements
 *)
val uniquify_list : Types_see.uurl_list -> Types_see.uurl_list;;

(** [lists_and l1 l2] Intersects url lists and l1, l2.
 *
 * @param l1 the first input list
 * @param l2 the second input list
 * @return list of urls that was on both input lists
 *)
val list_and : 
      Types_see.uurl_list -> Types_see.uurl_list -> Types_see.uurl_list
;;

(** [lists_minus l1 l2] Subtracts url lists l1 and l2. 
 *
 * @param l1 the first input list
 * @param l2 the second input list
 * @return list of urls that are on the first input list and are NOT 
 * @return on the second input list 
 *)
val list_minus : 
      Types_see.uurl_list -> Types_see.uurl_list -> Types_see.uurl_list
;;

(** [lists_or l1 l2] Adds url lists l1 and l2.
 *
 * @param l1 the first input list
 * @param l2 the second input list
 * @return list of urls that are on one of input lists 
 *)
val list_or : Types_see.uurl_list -> Types_see.uurl_list -> Types_see.uurl_list;;

(** [merge_fun_of_conjunction c] Finds function that will correctly merge 
 * two lists linked by conjunction c
 *
 * @param c conjuntcion *  
 * @return function of type [uurl_list -> uurl_list -> uurl_list]
 *)
val merge_fun_of_conjunction : 
      Types_e_see.conjunction -> Types_see.uurl_list -> Types_see.uurl_list 
        -> Types_see.uurl_list
;;
