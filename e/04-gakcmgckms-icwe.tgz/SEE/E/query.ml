(* query.ml
 * 
 * 2003.04.13,  Mateusz Srebrny, ocamldoced
 * 2003.01.16,  Mateusz Srebrny, query_handle moved from Query_parser
 * 2003.01.08,  Mateusz Srebrny, operational
 * 2003.01.07,  Mateusz Srebrny, created
 *)


(* main function dealing with incoming to E-SEE request *)
let query_handle request = 
  
  (* user *)
  let cli_no = request.Types.cli_no in
  
  (* query tree, and list of words in query *)
  let (tree, word_list) = Query_parser.query_parse request in
  
  (* List_merger gets urls *)
  List.iter Overseer_interrogator.interrogate_overseer word_list;
  
  (* Two lists... *)
  let (personal, global) = List_merger.merge_lists cli_no tree in
  
  (* output *)
  Output_formatter.generate_output request global personal

;;


(* gets user preferences, and constructs request  or not *)
(* @param request http request to be modified *)
let query_deal request = 
  let cli_no = request.Types.cli_no in
  (* default options: (SEE, 3) *)
  let (searchengine, _) = Panel.get cli_no in
  if String.uppercase searchengine = "LOCAL" then
    None
  else 
    Some(query_handle request)
;;
