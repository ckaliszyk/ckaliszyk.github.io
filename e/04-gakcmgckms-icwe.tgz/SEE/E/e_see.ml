(* e_see.ml
 *
 * 2003.03.21,  Mateusz Srebrny, response_modifier has been told "farewell"
 * 2003.03.19,  Mateusz Srebrny, panelik adding response_modifier removed
 * 2003.03.16,  Mateusz Srebrny, renamed from broker.ml
 * 2003.02.04,  Mateusz Srebrny, disposed of insignificant rebel scum
 * 2003.01.24,  Mateusz Srebrny, rspns_mod updated
 * 2003.01.07,  Mateusz Srebrny, fully operational & commented
 * 2003.01.07,  Mateusz Srebrny, created
 *)

let config = Config.create "SEE/E/e_see";;

(** To be called on the request's way from user to server.
 * [e_see request] Passes [request] to {! Panel} or to {! Query} (these modules
 * modifies it) or leaves it unchanged.
 *
 * @param request http request to be modified
 * @return after the request is modified
 * @author Mateusz Srebrny
 *)
let e_see request =
  (* initialize small configuration... *)
  Overseer_funs.config_init ();
  (* retrieves the name of search file *)
  let search_file = Overseer_funs.get_fn () in
  let resource = request.Types.file in
  if resource = ("/"^search_file) then 
    Query.query_deal request
  else
    None
;;

let init()  = 
  try 
    let sie_mod = {
      Types.name = "E-SEE";
      Types.supported_content_types = ["text/html"];
      Types.needs_html_tree = true;
      Types.priority_before = (int_of_string (Config.get config "ESEE_PRIORITY"));
      Types.before = e_see;
      Types.priority_after = 0;
      Types.after = (fun _ _ -> ());
      Types.session_ended = (fun _ -> ());
    } in Types.Success(sie_mod)
  with
  | Failure (reason) -> 
      Types.Failed(reason)
;;
