(* types_e_see.mli
 *
 * 2003.05.03,  Mateusz Srebrny, ocamldoced
 * 2003.01.08,  Mateusz Srebrny, types format_options and weights added
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
(** Module Types_e_see is lesser module. It was created in order to
 *  share some types between other modules of {! E_see}.
 *  Many shared types are also defined in Types_see. Those types
 *  are common to {! E_see} and {! A_see} (and many others).
 *  
 *  @author Mateusz Srebrny
 *)

(** Type of conjunction *)
type conjunction = And | Or | Minus;;

(** Type of parsed query *)
type query_tree = 
  | Null
  | Leaf of string
  | Node of query_tree * conjunction * query_tree
;;

(** Type of formatting options.
 *  For now it includes only number of result page to be displayed.
 *)
type format_options = int;;


