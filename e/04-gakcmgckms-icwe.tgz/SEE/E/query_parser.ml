(* query_parser.ml
 * 
 * 2003.04.13,  Mateusz Srebrny, ocamldoced
 * 2003.01.16,  Mateusz Srebrny, query_handle moved to Query
 * 2003.01.10,  Mateusz Srebrny, tree maker made to ignore uninteresting words
 * 2002.12.14,  Mateusz Srebrny, revised
 *)

open Types_e_see;;

(* admin representation of conjunctions, to be got from OverSeer *)
let (_and, _or, _minus) = Overseer_funs.get_cd ();;

(* conjunction denoted as "" (default And) *)
let _null (a, o, m) =
  if o = "" then Or
  else if m = "" then Minus
  else And
;;

(* type used in the process of query parsing, represents either word, or
 * conjunction
 *)
type word_or_conjunction = Word of string | Con of conjunction;;

(* constructs instance of word_or_conjunction type of a string *)
let word_or_conjunction_of_string s =
  if s = _and then Con And
  else if s = _or then Con Or
  else if s = _minus then Con Minus
  else Word s
;;

(* constructs list of word_or_conjunctions of list of strings *)
let word_or_conjunction_list_of_string_list =
  List.map word_or_conjunction_of_string
;;

(* splits str into string list by pluss result stores on ans *)
let rec string_list_of_string str ans =
  if str = "" then ans else
  try
    (*TODO czy to zawsze sa spacje *)
    let first_space = String.index str ' ' in
    if first_space = 0 then
      string_list_of_string (String.sub str 1 (String.length str - 1)) ans
    else
      string_list_of_string
        (String.sub str (first_space + 1)(String.length str - 1 - first_space))
        ((String.lowercase (String.sub str 0 (first_space))) :: ans)
  with
    Not_found ->
      List.rev ((String.lowercase str) :: ans)
;;

(* filter to use with filter_words_out and word_is_interesting 
 * checks if a string has length >= min_length and length <= max_length
 *)
let word_has_adequate_length min_length max_length s =
  let length = String.length s in
  (length >= min_length) && (length <= max_length)
;;

(* tells wheter word is interesting *)
let word_is_interesting definition word = 
  let (min, max, uninteresting_wl) = definition in
  word_has_adequate_length min max word &&
  (not (List.mem word uninteresting_wl))
;;

(* throws out uninteresting words from a string list (wlist) *)
let filter_uninteresting_words_out definition wlist =
  let (min, max, uninteresting_wl) = definition in
  List.filter (word_is_interesting definition) wlist
;;

(* parses a list of words or conjunction into query_tree;
 * if no conjunction is between to words assumes _null(_and,_or,_minus),
 * if empty list is given returns Null
 * supresses leading conjunctions ('cause all of them are binary)
 * supresses uninteresting words ('cause all of them are uninteresting)
 *)
let rec query_tree_of_word_or_conjunction_list wcl =

  let def = Overseer_funs.get_uwd ()in

  match wcl with
  | [] -> Null
  | Word (w) :: tail -> (
    if word_is_interesting def w then
      match tail with
      | [] -> Leaf (w)
      | Con (c) :: small_tail ->
        let smaller_tree = query_tree_of_word_or_conjunction_list small_tail in
        if smaller_tree = Null then Leaf (w)
        else Node (Leaf (w), c, smaller_tree)
      | _ ->
        let smaller_tree = query_tree_of_word_or_conjunction_list tail in
        if smaller_tree = Null then Leaf (w)
        else Node (Leaf(w),_null (_and, _or, _minus), smaller_tree)
    else query_tree_of_word_or_conjunction_list tail 
  )
  | Con(c) :: tail -> query_tree_of_word_or_conjunction_list tail
;;

(* lists all leaves (words) in query_tree (DFS *)
let rec string_list_of_query_tree t =
  match t with
  | Null -> []
  | Leaf (w) -> [w]
  | Node (t1, c, t2) ->
      List.concat [(string_list_of_query_tree t1); 
                   (string_list_of_query_tree t2)]
;;

(* returns query_tree and list of words in it built on the basis
 * of string-formed query q
 * EXPORTED FOR TESTS 
 *)
(** @param query query to be parsed *)
let do_query_parse query =
  let sl = string_list_of_string query [] in
  let wcl = word_or_conjunction_list_of_string_list sl in
  let t = query_tree_of_word_or_conjunction_list wcl in
  let wl = string_list_of_query_tree t in
  let definition = Overseer_funs.get_uwd () in
  let filtered = filter_uninteresting_words_out definition wl in
  (t, filtered)
;;

(* retrieves name of query option *)
let (query_string, _) = Overseer_funs.get_pn ();;

(* Extracts user, query tree and list of words involved in query
 *  from Types.request. Called by {! Query}.
 *)
(** @param request http request that stores query *)
let query_parse request =
  let query = 
    try 
      List.assoc query_string request.Types.file_params 
    with
    | Not_found -> ""
  in
  let (tree, word_list) = do_query_parse query in
  (tree, word_list)
;;


