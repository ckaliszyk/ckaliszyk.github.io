(* overseer_interrogator.mli
 * 
 * 2003.05.03,  Mateusz Srebrny ocamldoced
 * 2002.12.11,  Mateusz Srebrny 
 *)
  
(** Module Overseer_interrogator provides only one function.
 *  This function is used by {! Query} to retrieve lists of links
 *  (including given word) from Overseer and passing them to
 *  {! List_merger}.
 *
 *  @author Mateusz Srebrny
 *)

(** [interrogate_overseer word] Retrieves data about word (list of urls 
 * containing the word) from OverSeer ({! Overseer_funs}).
  * Passes this data to {! List_merger} ({!List_merger.import_data})
  *
 * @param word the word to get links for 
  * @author Mateusz Srebrny
  *)
val interrogate_overseer : string -> unit;;

