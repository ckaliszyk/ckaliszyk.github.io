(* output_formatter.ml
 *
 * 2003.05.03,  Mateusz Srebrny, ocamldoced
 * 2003.01.12,  Mateusz Srebrny, output producing done 
 * 2003.01.08,  Mateusz Srebrny, exported functions added
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
open List_ops;;

(* how many links makes a result page
 * and how many global links should be on result page 
 *)
let (page_size, global_share) = Overseer_funs.get_ps ();;

(* local search_engine url *)
let search_engine = Overseer_funs.get_fn ();;

(* param names *)
let (query_string, page_string) = Overseer_funs.get_pn ();;

(* splits list l into two lists: first n elements of l are on first one
 * and the rest of l is on second one 
 *)
let rec head_n n l = 
  match l with
  | [] -> 
    ([], [])
  | h :: t -> 
      if n = 0 then 
        ([], l)
      else 
        let (l1, l2) = head_n (n-1) t in
        (h :: l1, l2)
;;

(* returns list consisting of nth ten of list l *)
let rec get_nth_ten_of_list n l = 
  let (l1, l2) = head_n page_size l in
  if n < 1 then failwith "output_formatter.get_nth_ten_of_list"
  else if n = 1 then l1
  else get_nth_ten_of_list (n-1) l2
;;

(* merges personal and global lists into one list so that
 * each page_size contains n entries from gl and page_size-n from pl
 *)
let rec merge_global_and_personal_lists gl pl n =
  let (l1, l2) = head_n n pl in
  let (l3, l4) = head_n (page_size-(List.length l1)) (list_minus gl l1) in
  if pl = [] then 
    gl
  else if gl = [] then 
    pl
  else 
    List.concat 
      [l1; l3; (merge_global_and_personal_lists (list_minus l2 l3) l4 n)]
;;

open Nethtml;;

(* handy <br> tag for use later *)
let br = Element("br", [], []);;
(* handy &nbsp; for use later *)
let sp = "&nbsp;"
  
(* index of url to be used with htmlize_links to enumerate links *)
let url_num = ref 0 
  
(* produces part of parsed html including an enumeration of links from 
 * uurl_list ulist
 *)
let rec htmlize_links ulist =
  match ulist with
  | [] -> [] 
  | (u, (*d*)_, _, _) :: t ->
      let d = Overseer_funs.get_title u in
      let num = Data ((string_of_int !url_num)^". "^sp) in
      let elt = Element ("a", [("href", u)], [Data (u^"\n"); br; 
                                              Data (" "^sp^sp^sp^d^"\n")]) 
      in
      url_num := !url_num + 1; 
      List.concat [[num; elt; br; br]; (htmlize_links t)]
;;

(* main function generating output page *)
(* 
 * @param request http-request for query 
 *  @param gl list of urls sorted using global weights
 *  @param pl list of urls sorted using personal weights
 *)
let generate_output request gl pl = 
  (* get query string *)
  let query =
    try
      List.assoc query_string request.Types.file_params
    with
    | Not_found -> ""
  in
  (* get paging information *)
  let fops = 
    try
      int_of_string 
        (List.assoc page_string request.Types.file_params)
    with
    | Not_found | Failure "int_of_string" -> 1
  in
  
  (* merge global and personal lists *)
  let merged = merge_global_and_personal_lists gl pl global_share in
  (* get proper page *)
  let paged = get_nth_ten_of_list fops merged in
 
  (* total amount of avaible pages *)
  let page_count = int_of_float (ceil ((float_of_int (List.length merged)) 
                                       /. (float_of_int page_size))) 
  in
  
  (* construction of actual result page *)
  (* query <input> field *)
  let q_input = Element("input", [("name", query_string); ("value", query)], []) in
  (* submit button *)
  let q_submit = 
    Element("input", [("type", "submit"); ("value", "szukaj")], []) 
  in
  (* form tag *)
  let form = Element ("form", [("action", "/"^search_engine); 
                               ("method", "get")], [q_input; q_submit]
                     )
  in

  (* construction of list of available pages *)
  (* at first the list is empty *)
  let next_pages = ref [] in
  
  (* for all available pages *)
  for i = 1 to page_count do
    (* reverse the list *)
    let page_no = string_of_int (page_count - i + 1) in
    
    (* isn't it the current page *)
    if int_of_string (page_no) <> fops then
      (* url getting the page *)
      let url = String.concat "" ["/"; search_engine; "?"; 
                                       query_string; "="; query; 
                                  "&"; page_string; "="; page_no
                                 ]
      in
      (* actual <a> tag *)
      let anchor = Element ("a", [("href", url)], [(Data (page_no))]) in
      (* add link *)
      next_pages := List.concat [[anchor; Data (sp^sp^"\n")]; !next_pages]
    else
       (* add page_no *)
      next_pages := Data (page_no^sp^sp^"\n") :: !next_pages
  done;
 
  (* link to panel *)
  let panel = Element ("a", [("href", "/panel")], [Data "panelik\n"]) in
  (* form and list of available pages *)
  let body_header = List.concat [[form; br; br]; !next_pages] in
  (* links list *)
  url_num := page_size * (fops - 1) + 1;
  let body_links = List.concat [[br; br]; (htmlize_links paged)] in
  (* actual <body> tag *)
  let body = Element ("body", [], List.concat [body_header; body_links]) in
  (* <head> tag *)
  let meta = Element ("meta",[("http-equiv","Content-type"); 
                              ("content","text/html; charset=iso-8859-2")],
                             []) 
  in
  let title = Element ("title", [], [Data "SEE\n"]) in
  let head = Element ("head", [], [meta; title]) in
  (* acutal <html> tag - document to be returned to user *)
  let document = Element ("html", [], [head; body]) in
  
  (* actual http response *)
  let response = { Types.server_ver = 0; 
                   Types.status_code = 200; 
                   Types.status_phrase = "OK";
                   Types.set_cookie = "";
                   Types.content_encoding = Types.Identity;
                   Types.transfer_coding = Types.Normal;
                   Types.content_language = "pl";
                   Types.content_length = 0; 
                   Types.html_tree = [document];
                   Types.response_params = [];
                   Types.panel = Nethtml.Data "";
                   Types.content_type = "text/html";
                   Types.server_keep_alive = false;
                   Types.location = "";
                   Types.content_location = "";
                 } 
  in
  response
;;

(*
 * @param gl list of urls sorted using global weights
 *  @param pl list of urls sorted using personal weights
 *)
let test_output gl pl = 
  let merged = merge_global_and_personal_lists gl pl global_share in
  let rec echo i l = 
    match l with
    | [] -> ()
    | (u, d, _, _) :: t ->
      print_int i;
      print_string (". "^u^"\n    "^d^"\n\n");
      echo (i+1) t
  in
  echo 1 merged
;;
