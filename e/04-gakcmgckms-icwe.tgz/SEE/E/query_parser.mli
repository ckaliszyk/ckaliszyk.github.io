(* query_parser.mli
 * 
 * 2003.04.13,  Mateusz Srebrny, ocamldoced
 * 2003.01.16,  Mateusz Srebrny, query_handle moved to Query
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
(** Module Query_parser is designed to be able to parse queries to
 *  search engines. 
 *
 *  For now it recognizes three binary conjuncions: and, or
 *  and not. Representation of these conuunctions in text can be defined
 *  by setting Conjunctions in TODO (default is "and", "or", "minus").
 *  An empty conjunction can be treated as any of the three, but the default
 *  is and. The other thing that can be configured is definition of
 *  uninteresting words. Maximum and minimum length can be set (Uninteresting
 *  Words). Set of words of adequate length but uninteresting also
 *  can be defined. The default is lenght between 1 and 12 characters and
 *  \{jest, jednak\}.
 *
 *  See {! Query_parser.query_parse} for details on how the parsing itself 
 *  is done. 
 *
 *  @author Mateusz Srebrny
 *)

(** Extracts user, query tree and list of words involved in query
 *  from http [request]. 
 *
 *  Called by {! Query}.
 *
 *  The parsing is done as follows:
 *  - query string is extracted from list of parameters of [request]
 *  - query string is split to list of lowercase words of query (including
 *    conjunctions (or, and, not)
 *  - string list is translated to list of words and conjunctions
 *  - the query tree is constructed (filters for words (length and 
 *    not belonging to set of uninteresting words) are aplied)
 *  - the query tree has leaves of words and other nodes of conjunctions
 *
 *  After the parsing is completed list of words is got by traversing 
 *  query tree with DFS.
 * 
 *  @return tuple consisting of requesting query tree and list of
 *          words of query
 *  @author Mateusz Srebrny
 *)
val query_parse : 
  Types.request -> Types_e_see.query_tree * string list;;


(** Functions exported for T-SEE (tests) purposes only.
 *  It parses given query.
 *
 *  @return tree describing query structure and list of interesting words
 *  @return in query
 *)
val do_query_parse : string -> Types_e_see.query_tree * string list;;

