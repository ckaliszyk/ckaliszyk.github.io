(* query.mli
 * 
 * 2003.04.13,  Mateusz Srebrny, ocamldoced
 * 2003.03.17,  Mateusz Srebrny, query_handle not exported
 * 2003.01.16,  Mateusz Srebrny, query_handle moved from Query_parser
 * 2003.01.07,  Mateusz Srebrny, created & fully operational
 *)
 
(** Module Query is responsible for construction of result html code for
 *  requests to searchengine. 
 *
 * This is done either by local (not-SEE)
 *  searchengine (if user want so) or by cooperative hard work of
 *  {! Query_parser}, {! Overseer_interrogator}, {! List_merger} and
 *  {! Output_formatter}.
 *
 *  Module is used by {! E_see}.
 *
 * @author Mateusz Srebrny
 *) 

(** [query_deal request] Constructs html code resulting from query 
 *  to searchengine represented by [request]. 
 *
 *  It is done in the following way:
 *  - decicision if user wants to use SEE or local searchengine is taken
 *  - {! Query_parser} parses the query taken from [request] into
 *    query tree and list of words of query
 *  - for each word {! Overseer_interrogator} passes list
 *    of urls containing the word to {! List_merger}
 *  - {! List_merger} applies proper weights to criteria and ranks pages
 *    returning two lists of urls: the one with global preferences considered
 *    and the one with user preferences considered
 *  - eventually {! Output_formatter} gets the two lists and produces
 *    resulting page.
 *
 * @param request http request to be modified 
 * @return after the request is answered or when the request 
 * @return is to local searchengine
 * @author Mateusz Srebrny
 *)
val query_deal : Types.request -> Types.response option;;
