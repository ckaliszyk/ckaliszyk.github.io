(* overseer_interrogator.ml
 *
 * 2003.04.24,  Mateusz Srebrny, ocamldoced
 * 2002.12.11,  Mateusz Srebrny, revised
 *)
 
open Types_e_see;;
open List_merger;;

(* @param word the word to get links for *)
let interrogate_overseer word = 
  let ulist = Overseer_funs.get_w word in
  import_data (word, ulist) 
;;

