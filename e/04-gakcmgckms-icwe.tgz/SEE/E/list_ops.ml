(* list_ops.ml
 * 
 * 2002.05.03,  Mateusz Srebrny, ocamldoced
 * 2003.01.10,  Mateusz Srebrny, lists decorated with priority
 * 2002.12.14,  Mateusz Srebrny, revised
 *)
 
open Types_e_see;;
open Types_see;;

(* returns true iff url is on url_list *)
(* @param udata describes url to be sought on url_list
 *  @param url_list describes list of urls scanned for url
 *)
let rec uurl_on_list ((url, _, _, _) as udata) (url_list : uurl_list) =
  let find_fun (u, o, c, p) = (u = url) in
  try
    ignore (List.find find_fun url_list);
    true
  with
  | Not_found -> false
;;

(* returns requested element thrown Not_found*)
let rec find_on_list (url, _, _, _) (url_list : uurl_list) =
  let find_fun (u, o, c, p) = (u = url) in
  List.find find_fun url_list
;;

(* list of elements that are on both l1 and l2 lists *)
(* doesn't destroy uniquification *)
(* @param l1 the first input list
 *  @param l2 the second input list
 *)
let rec list_and l1 l2 =
  match l1 with
  | [] -> []
  | h :: t ->
      let l3 = list_and t l2 in
      let (_, _, _, p1) = h in
      try 
        let (u2,d2,c2,p2) = find_on_list h l2 in
        if p1 < p2 then 
          ((u2, d2, c2, p2) :: l3)
        else 
          (h :: l3)
      with
      | Not_found -> l3
;;

(* list of elements that are on l1 list and are NOT on l2 list *)
(* doesn't destroy uniquification *)
(* @param l1 the first input list
 *  @param l2 the second input list
 *)
let rec list_minus l1 l2 =
  match l1 with
  | [] -> []
  | h :: t ->
      let l3 = list_minus t l2 in
      if (uurl_on_list h l2) then l3
      else h :: l3
;;

(* removes repeated list elements *)
(* @param ulist list of urls to uniquify *)
let rec uniquify_list ulist =
  match ulist with
    [] -> []
  | h :: t ->
      let (_,_,_,p) = h in
      let smaller_unique = uniquify_list t in
      if (uurl_on_list h smaller_unique) then 
        let (_,_,_,prior) = find_on_list h smaller_unique in
        if prior < p then
          h :: (list_minus smaller_unique [h])
        else
          smaller_unique
      else h :: smaller_unique
;;

(* list of elements that are on l1 list and are NOT on l2 list *)
(* doesn't destroy uniquification *)
(* 
 * @param l1 the first input list
 *  @param l2 the second input list
 *)
let list_or l1 l2 =
  let l3 = List.append l1 l2 in
  uniquify_list l3
;;

(* returns function that will correctly merge
 * to lists linked by conjunction c
 *)
(* @param c conjuntcion *) 
let merge_fun_of_conjunction c =
  match c with
    And -> list_and
  | Or -> list_or
  | Minus -> list_minus
;;

