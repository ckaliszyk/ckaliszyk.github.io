
let ic = open_in_bin "overseer_data";;

let rec main () =
  let pair : (string * Types_see.uurl_list) = input_value ic in
  let (word, uurl_list) = pair in
  let rec put () =
    try Overseer_funs.set_w word uurl_list
    with _ -> Unix.sleep 1; put ()
  in 
  put ();
  print_char '.';
  flush_all ();
  main ()
;;

let gic = open_in_bin "titles";;

let rec titles () =
  let pair : (string * string) = input_value gic in
  let (url, title) = pair in
  let rec put () = 
    try 
      Overseer_funs.set_title url title
    with
    | _ -> Unix.sleep 1; put ()
  in
  put ();
  print_char ':';
  flush_all ();
  titles ()
;;

print_endline "This is W(ord exporter)-SEE. You have been warned.";;
print_endline "W-SEE: exporting Words, Urls and Criteria.";;

try main () with End_of_file -> ();;

print_endline "\nW-SEE: Words, Urls and Criteria exported.";;
print_endline "W-SEE: exporting Urls and Titles.";;

(*export_urls_titles ();;*)
try titles () with End_of_file -> ();;

print_endline "\nW-SEE: Urls and Titles exported.";;
