(** W(ords)_see is program responsible for export of data computed by
 *  A-SEE to Overseer.
 *
 *  @author Czarek Kaliszyk
 *)
