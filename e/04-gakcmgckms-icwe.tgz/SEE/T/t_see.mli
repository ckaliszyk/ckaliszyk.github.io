(** T(ester)_see is helper program that is used to use E-SEE without Box and
 *  web browser.
 *
 *  It takes query and optionnaly user's id from command line.
 *
 *  @author Mateusz Srebrny
 * *)
