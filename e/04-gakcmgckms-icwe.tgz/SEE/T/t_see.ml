(* t_see.ml *)

(* initial things starts here *)

print_endline "This is T(ester)-SEE , Still no worries, mate...\n"
;;

let usage s = 
  print_string s;
  print_string (" Usage:\n\t"^Sys.argv.(0)^" [-u <user>] <query>\n");
  exit 1
;;

let argl = ref (List.tl (Array.to_list Sys.argv));;

if List.length !argl <= 0 then
  usage "Empty query\n"
;;  

let user =
  if List.hd !argl = "-u" then
        begin
    argl := List.tl !argl;
    match !argl with
    | [] ->
      usage "Missing -u argument\n"
    | u :: tail ->
      argl := tail;
      u
        end  
  else 
    ""
;;

if List.length !argl = 0 then
  usage "Empty query\n"
;;
  
let query = String.concat " " !argl;;

(* initialization ends here *)

print_endline ("T-SEE: user = "^user);;
print_endline ("T-SEE: query = "^query^"\n");;

(* 1. parsing *)
let (tree, wlist) = Query_parser.do_query_parse query;;
(* 2. retrieving matching urls *)
List.iter Overseer_interrogator.interrogate_overseer wlist;;
(* 3. merging lists *)
let (personal, global) = List_merger.merge_lists user tree;;
(* 4. final output *)
Output_formatter.test_output global personal;;
