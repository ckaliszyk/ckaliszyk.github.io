DIR:=SEE/T
TARGET:= t_see
FILES:= t_see
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Api/api.$(LIB_SUF) out/SEE/Common/see.$(LIB_SUF) out/SEE/E/e_see.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES})
	${OCAML_COMP} unix.${LIB_SUF} str.${LIB_SUF} threads.${LIB_SUF} $^ -o $@  
