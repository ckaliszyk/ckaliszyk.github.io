exception Error;;

let char_as_hex2int = function
  | '0' -> 0  
  | '1' -> 1
  | '2' -> 2
  | '3' -> 3
  | '4' -> 4
  | '5' -> 5 
  | '6' -> 6 
  | '7' -> 7 
  | '8' -> 8 
  | '9' -> 9 
  | 'a' -> 10 
  | 'A' -> 10 
  | 'b' -> 11 
  | 'B' -> 11 
  | 'c' -> 12
  | 'C' -> 12 
  | 'd' -> 13
  | 'D' -> 13
  | 'e' -> 14
  | 'E' -> 14
  | 'f' -> 15
  | 'F' -> 15
  | _ -> failwith "bad hex digit"
;;

let set_plus_to_space str =
  try
    while true do
      let i = String.index str '+' in
      str.[i] <- ' '
    done
  with Not_found -> ()
;;

let rec decode_percent str = 
  try
    let i = String.index str '%' in
    if String.length str <= i+2 then failwith "decode_percent"
    else
      let k = Char.chr ((char_as_hex2int(str.[i+1]))*16
    	    +char_as_hex2int(str.[i+2])) in
        (String.sub str 0 i) ^ (String.make 1 k) 
	^ (decode_percent (String.sub str (i+3) ((String.length str)-i-3)))
  with Not_found -> str
;;

let get_url_name str =
  if String.length str < 7 then ("", str) else 
  if String.lowercase (String.sub str 0 7) <> "http://" then ("", str) else
  let str = String.sub str 7 (String.length str - 7) in (* we removed "http://" *)
  try
    let i = String.index str ':' in
    if i = 0 then ("", str)
    else (String.sub str 0 i, String.sub str i ((String.length str) - i))
  with Not_found -> try
    let i = String.index str '/' in
    if i=0 then ("", str) else
    (String.sub str 0 i, String.sub str i ((String.length str) - i))
  with Not_found -> (str, "")
;;

let get_url_port str =
  if String.length str = 0 then (80, "") else
  if str.[0] <> ':' then (80, str) else
  try
    let i = String.index str '/' in
    if i = 1 then (80, String.sub str 1 ((String.length str) - 1)) else
    (int_of_string (String.sub str 1 (i-1))
       , String.sub str i ((String.length str) - i))
  with
  | Not_found -> (80, str)
  | Failure _ -> raise Error
;;

let get_url_file str =
  if String.length str = 0 then ("", "")
  else try
    let i = String.index str '?' in
      (String.sub str 0 i, String.sub str (i+1) ((String.length str) -i -1))
  with Not_found -> (str, "")
;;

let rec get_params_from_str c str =
  if String.length str = 0 then []
  else
    try
      let i = String.index str '=' in
      let pocz = String.sub str 0 i in
      let kon = String.sub str (i+1) ((String.length str) -i-1) in
      try
        let j = String.index kon c in
        (pocz, String.sub kon 0 j) ::
            (get_params_from_str c (String.sub kon (j + 1) ((String.length kon) -j-1)))
      with
        Not_found -> [(pocz, kon)]
    with Not_found -> failwith "get_params_from_string"
;;

let get_file_params str =
  let ret = get_params_from_str '&' str in
(*  List.iter
    (fun (param, value) -> Log.echo ("{" ^ param ^ "|" ^ value ^ "}"))
    ret; *)
  ret
;;

let parse_URL my_url =
  set_plus_to_space my_url;
  let (url, rest) = get_url_name my_url in
  let (port, rest) = get_url_port rest in
  let (file, rest) = get_url_file rest in
  let file_params = get_file_params rest in
  let decoded_file = decode_percent file in (* get rid of %E0, etc *)
  let decoder (a, b) = (decode_percent a, decode_percent b) in
  let decoded_file_params = List.map decoder file_params in
  (url, port, decoded_file, decoded_file_params)
;;

let deparse_URL (url, port, file, file_params) =
  let out_buff = Buffer.create 40 in
  let add_str = Buffer.add_string out_buff
  and add_char = Buffer.add_char out_buff in
  if url <> "" then begin
    add_str "http://";
    add_str url;
    if port <> 80 then begin
      add_char ':';
      add_str (string_of_int port);
    end else ();
  end else ();
  add_str file;
    
  (* file params: *)
  if file_params<>[] then begin
    add_char '?';
    let rec output_l list =
      match list with
        [] -> ()
      | [(param, value)] -> add_str param;
          add_char '=';
          add_str value;
      | (param, value)::ending ->add_str param;
          add_char '=';
          add_str value;
	  add_char '&';
	  output_l ending; 
        
    in
    output_l (List.rev file_params)
  end else ();
  Buffer.contents out_buff
;;
