exception Error of string;;

type ('a, 'b) t = (('a Serialize.t) * ('b Serialize.t) * Dbm.t);;

let opendb name a_ser b_ser =
  try (a_ser, b_ser, Dbm.opendbm "asd" [Dbm.Dbm_create; Dbm.Dbm_rdwr] 438)
  with Dbm.Dbm_error s -> raise (Error ("Dbm error: " ^ s))
;;

let set (((a_write, _) : 'a Serialize.t), (b_write, _), dbm) a b =
  try
    let a_buf, b_buf = (Buffer.create 0, Buffer.create 0) in
    a_write a_buf a; b_write b_buf b;
    Dbm.replace dbm (Buffer.contents a_buf) (Buffer.contents b_buf)
  with Dbm.Dbm_error s -> raise (Error ("Dbm error: " ^ s))
;;

let get ((a_write, _), (_, b_read), dbm) a =
  try
    let a_buf = Buffer.create 0 in
    a_write a_buf a;
    let a_str = Buffer.contents a_buf in
    let b_str = Dbm.find dbm a_str in
    snd (b_read b_str 0 (String.length b_str))
  with 
  | Dbm.Dbm_error s -> raise (Error ("Db: Dbm error: " ^ s))
  | Serialize.Too_short s -> raise (Error ("Db: serialize error: " ^ s))
;;

