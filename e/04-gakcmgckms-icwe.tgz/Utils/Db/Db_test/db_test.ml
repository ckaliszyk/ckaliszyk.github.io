open Db;;

let db = opendb "digits" Serialize.int Serialize.string;;
set db 1 "one";;
set db 2 "two";;
print_string (get db 1);;
print_string (get db 2);;
