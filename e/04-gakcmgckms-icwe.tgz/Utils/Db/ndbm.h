/*************************************************************************************************
 * Hashed key data base library
 *
 * Copyright (c) 1983 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 *
 *      @(#)ndbm.h      5.1 (Berkeley) 5/30/85
 *************************************************************************************************/

/*************************************************************************************************
 * Modernized by M.H.      Wed, 19 Feb 2003 07:59:40 +0900
 *  - changed style from K&R to C89.
 *  - rewrote some macros into functions.
 *  - deleted vain functions and macros.
 *  - replaced bzero, bcmp, bcopy to memset, memcmp, memcpy.
 *************************************************************************************************/


/* prohibit multiple includings */
#ifndef _NDBM_H
#define _NDBM_H


#include <sys/types.h>
#include <fcntl.h>

#define PBLKSIZ        1024
#define DBLKSIZ        4096



/*************************************************************************************************
 * API
 *************************************************************************************************/


#define DBM_INSERT     0
#define DBM_REPLACE    1


typedef struct {                         /* data base handle */
  int dbm_dirf;                          /* open directory file */
  int dbm_pagf;                          /* open page file */
  int dbm_flags;                         /* flags, see below */
  long dbm_maxbno;                       /* last ``bit'' in dir file */
  long dbm_bitno;                        /* current bit number */
  long dbm_hmask;                        /* hash mask */
  long dbm_blkptr;                       /* current block for dbm_nextkey */
  int dbm_keyptr;                        /* current key for dbm_nextkey */
  long dbm_blkno;                        /* current page to read/write */
  long dbm_pagbno;                       /* current page in pagbuf */
  char dbm_pagbuf[PBLKSIZ];              /* page file block buffer */
  long dbm_dirbno;                       /* current block in dirbuf */
  char dbm_dirbuf[DBLKSIZ];              /* directory file block buffer */
} DBM;

typedef struct {                         /* container of item */
  char *dptr;                            /* pointer to the region */
  int dsize;                             /* data size */
} datum;


/* open a database */
DBM *dbm_open(char *file, int flags, int mode);


/* close a database */
void dbm_close(DBM *db);


/* retrieve a record */
datum dbm_fetch(DBM *db, datum key);


/* delete a record */
int dbm_delete(DBM *db, datum key);


/* store a record */
int dbm_store(DBM *db, datum key, datum dat, int replace);


/* get the first key */
datum dbm_firstkey(DBM *db);


/* get the next key */
datum dbm_nextkey(DBM *db);


/* check read only */
int dbm_rdonly(DBM *db);


/* check error */
int dbm_error(DBM *db);


/* clear the error flag */
int dbm_clearerr(DBM *db);


/* get the file descriptor of dir file */
int dbm_dirfno(DBM *db);


/* get the file descriptor of pag file */
int dbm_pagfno(DBM *db);


/* check the block number in pag file */
long dbm_forder(DBM *db, datum key);



#endif /* end of inndef _NDBM_H */


/* END OF FILE */
