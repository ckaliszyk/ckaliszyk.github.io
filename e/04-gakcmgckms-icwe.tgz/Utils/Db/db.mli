(** Operations required to access the database stored in files *)

(** Exception raised if anythin goes wrong *)
exception Error of string;;

(** Type representing a database table with the given association types *)
type ('a, 'b) t;;

val opendb : string -> 'a Serialize.t -> 'b Serialize.t -> ('a, 'b) t;;

(** [set table id value] replaces value associeted with [id] in [table] *)
val set : ('a, 'b) t -> 'a -> 'b -> unit;;

(** [get table id] returns the value associated with [id] stored in [table]
  @raise Not_found if [id] is not found *)
val get : ('a, 'b) t -> 'a -> 'b;;

