DIR:=Utils
TARGET:=utils.cmxa
FILES:=url_utils

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: $(addsuffix .cmx,${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -a -o $@ $^
