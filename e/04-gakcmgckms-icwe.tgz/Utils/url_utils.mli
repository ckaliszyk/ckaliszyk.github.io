(** General URL operations *)

(** Parses the given url to (host, post, link, link_params) *)
val parse_URL : string -> string * int * string * (string * string) list;;

(** Makes the url out of host, port, link and it's params *)
val deparse_URL : string * int * string * (string * string) list -> string;;
