type time = int (* chwilowo *)
;;

(* kazdemu Nethtml.Element i Nethtml.Data odpowiada Time_node -
   w ten sposob nie bedziemy musieli ingerowac w Nethtml *)
type time_tree =
  | Time_node of time * time_tree list
;;

module OrderedString = struct
  type t = string
  let compare = compare
end

module StringSet = Set.Make (OrderedString)
;;

(* buduje zbior stringow zawarty na stronie w tagach Nethtml.Data *)
let rec extract_data strings nodes =
  List.fold_left extract_aux strings nodes
and extract_aux strings = function
  | Nethtml.Element (_, _, subnodes) -> extract_data strings subnodes
  | Nethtml.Data dat -> StringSet.add dat strings
;;

(* buduje drzewo czasowe strony (wszystkie tagi maja czas time) *)
let rec create_time_tree time nodes =
  List.map (create_aux time) nodes
and create_aux time = function
  | Nethtml.Element (_, _, subnodes) ->
      Time_node (time, create_time_tree time subnodes)
  | Nethtml.Data _ -> Time_node (time, [])
;;

(* bierze strone (nodes), jej drzewo czasowe (ttree) oraz zbior stringow
   ze starszej wersji tej strony (strings) i date sciagniecia starej wersji
   (time) strony; przechodzi rownolegle ttree i nodes wstawiajac do ttree
   czas time, jezeli odpowiedni Data string w nodes pojawil sie w zbiorze
   strings *)
let rec update_time_tree time strings ttree nodes =
  List.map2 (update_aux time strings) ttree nodes
and update_aux time strings (Time_node (tm, tsub)) = function
  | Nethtml.Element (_, _, sub) ->
      Time_node (tm, update_time_tree time strings tsub sub)
  | Nethtml.Data dat ->
      let new_tm =
	if StringSet.mem dat strings && time < tm then time else tm in
      Time_node (new_tm, tsub)
;;

(* bierze aktualna strone i czas jej sciagniecia (page, time) i strumien
   starych wersji tej strony (zeby mozna bylo je leniwie z bd wyciagac);
   konstruuje drzewo czasowe tej strony (tak na prawde wszystkie
   Nethtml.Element beda odatowane na time, bo zajmujemy sie jedynie
   Nethtml.Data *)
let time_html (time, page) olds =
  let ttree = create_time_tree time page in
  let rec fold_update ttree = function
    | Some (tm, old) ->
	let strings = extract_data StringSet.empty old in
	fold_update (update_time_tree tm strings ttree page) (Stream.peek olds)
    | None -> ttree in
  fold_update ttree (Stream.peek olds)
;;
