(** Main Overseer module 

   Main Overseer server loop, database and communication routines *)
