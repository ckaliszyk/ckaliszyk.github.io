DIR:=Overseer
TARGET:=Overseer
FILES:=overseer
CFILES:=

TARGETS+=${DIR}/${TARGET}
FILES:=$(addprefix out/${DIR}/,${FILES})
-include $(addsuffix .dm,${FILES})
-include $(addsuffix .di,${FILES})
CFILES:=$(addprefix out/${DIR}/,${CFILES})
out/${DIR}/${TARGET}: out/Config/config.$(LIB_SUF) out/Api/api.$(LIB_SUF) $(addsuffix .$(OBJ_SUF),${FILES}) $(addsuffix .o,${CFILES})
	${OCAML_COMP} -o $@ unix.$(LIB_SUF) str.$(LIB_SUF) threads.$(LIB_SUF) $^
