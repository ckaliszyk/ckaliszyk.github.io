let max_tables = 100;; (* Length of the table of tables *)

type config = {
  mutable ifaces: string list;  (** List of IPs to bind to **)
  mutable port: int;            (** Port to bins to **)
};;

let config = {
  ifaces = [ "127.0.0.1" ];
  port = 8000;
};;

(* Name -> id *)
let tables_names = Hashtbl.create 0;;

(* There is always at least one table - the config table *)
let tables_count = ref 1;;

let tables_mutex = Mutex.create ();;

let tables = 
  let creator _ = ((Hashtbl.create 0), []) in
  Array.init max_tables creator;;

(* Value of last received cookie *)
let last_cookie = ref Int64.zero;;

(* notify alls socks except sock that table id has changed *)
let rec notify id socks sock =
  Log.echo ("notify, socks len == " ^ (string_of_int (List.length socks)));
  match socks with
  | socket::rest -> begin
      if (not (socket == sock)) then begin
        Log.echo ("Outputing Resp_table_change with push cookie");
        AsyncSocket.output_value socket Overseer_api.push_cookie;
        AsyncSocket.output_value socket (Overseer_api.Resp_table_change(id));
        AsyncSocket.flush socket;
      end;
      notify id rest sock
  end
  | [] -> ()
;;

let remove_notify sock =
  Log.echo ("remove_notify");
  Mutex.lock tables_mutex;
  let remover name id =
    let remove_sock socks = List.filter (fun s -> not (s == sock)) socks in
    let (tbl, socks) = tables.(id) in
    let removed = remove_sock socks in
    Log.echo ("removed len: " ^ (string_of_int (List.length removed)) ^ 
        ", socks len: " ^ (string_of_int (List.length removed))); 
    tables.(id) <- (tbl, removed);
  in
  Hashtbl.iter remover tables_names;
  Mutex.unlock tables_mutex;
;;

(* Finds the id of the table with a given name*)
let init sock tbl_name tables =
  Log.echo ("Query_init " ^ tbl_name);
  
  Mutex.lock tables_mutex;
  let id =
    try 
      Hashtbl.find tables_names tbl_name
    with
      Not_found -> begin
        let new_val = (!tables_count - 1) in
        Hashtbl.add tables_names tbl_name new_val;
        incr tables_count;
        new_val
      end
  in
  let (tbl, socks) = tables.(id) in
  if (not (List.memq sock socks)) then begin
    tables.(id) <- (tbl, sock::socks);
  end;
  Mutex.unlock tables_mutex;
  
  AsyncSocket.output_value sock !last_cookie;
  AsyncSocket.output_value sock (Overseer_api.Resp_table_id(id));
  AsyncSocket.flush sock
;;

let read_config_file iterator =
  (* FIXME *)
  let filename = "sie.config" in
  ConfigPlainFile.iter filename iterator
;;

let read_config tables _ =
  Mutex.lock tables_mutex;
  Hashtbl.add tables_names Db.config_table_name (0);
  Mutex.unlock tables_mutex;

  let (tbl, _) = tables.(0) in
  let iterator (name, aval) = Hashtbl.replace tbl name aval in
  let printer (name, aval) = print_endline ("("^name^", "^aval^")\n") in
  read_config_file iterator;
  read_config_file printer;
  flush_all ()
;;

let dump_config tables _ =
  let (tbl, _) = tables.(0) in
  let folder name aval lst = (name, aval) :: lst in
  let lst = Hashtbl.fold folder tbl []; in
  let printer (name, aval) = print_endline ("("^name^", "^aval^")\n") in
  List.iter printer lst;
  flush_all ();
  (* FIXME: zmieni� tutaj *)
  (* Config.dump lst *)
;;

let find tbl key =
  try
    Some(Hashtbl.find tbl key)
  with
    Not_found -> None
;;

let get sock tbl_id key tables =
  Log.echo ("Query_get tbl_id: " ^ (string_of_int tbl_id)); (*^ "key = " ^ key);*)
  let (tbl, _) = tables.(tbl_id) in
  let v = find tbl key in
  AsyncSocket.output_value sock !last_cookie;
  AsyncSocket.output_value sock (Overseer_api.Resp_get(v));
  AsyncSocket.flush sock
;;

let set sock tbl_id key new_val tables =
  Log.echo ("Query_set tbl_id: " ^ (string_of_int tbl_id));
  let (tbl, socks) = tables.(tbl_id) in
  match new_val with
  | None -> Hashtbl.remove tbl key;
  | Some(new_val) -> Hashtbl.replace tbl key new_val;
  AsyncSocket.output_value sock !last_cookie;
  AsyncSocket.output_value sock (Overseer_api.Resp_set);
  AsyncSocket.flush sock;
  notify tbl_id socks sock
;;

let handle_connection addr =
  (* FIXME: Maybe implement TCP wrappers
  * For now always accept incoming connections *)
  true
;;

let handle_error sock error =
  remove_notify sock;
  match error with
  | AsyncSocket.CLOSED_OK -> (
    Log.echo ("Closing async socket");
    AsyncSocket.close sock;
  )
  | AsyncSocket.CLOSED_ERROR(error) -> (
    Log.echo ("Closing async socket - error");
    AsyncSocket.close sock;
  )
;;  

let handle_cookie tables sock =
  let cookie : Int64.t option = AsyncSocket.input_value sock in
  match cookie with
  | None -> false
  | Some(cookie) -> last_cookie := cookie; true
;;

let handle_real_query tables sock =
  let query : (('a, 'b) Overseer_api.db_t) option = AsyncSocket.input_value sock in
  match query with
  | None -> false
  | Some(query) -> (
    Log.echo ("Got a query");
    try 
      let _ = match query with
      | Overseer_api.Query_init(tbl_name) -> init sock tbl_name tables
      | Overseer_api.Query_get(tbl_id, key) -> get sock tbl_id key tables
      | Overseer_api.Query_set(tbl_id, key, new_val) -> set sock tbl_id key new_val tables
      | _ -> Log.echo ("Unknown query")
      in 
      last_cookie := Int64.zero;
      true
    with 
    | AsyncSocket.Exc(error) -> (
      handle_error sock error;
      true
    )
  )
;;

let rec handle_query tables sock =
  try 
    Log.echo ("Something to read");
    let read_cookie =
      if (!last_cookie = Int64.zero) then
        handle_cookie tables sock
      else
        true
    in let read_query =
      if read_cookie then
        handle_real_query tables sock
      else
        false
    in if read_query then 
      handle_query tables sock
  with 
  | AsyncSocket.Exc(error) -> handle_error sock error
;;

let set_ifaces ifaces =
  let iface_list = Str.split (Str.regexp ",") ifaces in
  if (List.length iface_list) = 0 then 
    raise (Arg.Bad ("No ifaces specified in: " ^ ifaces));
  let rec check iface_list = match iface_list with
  | iface::rest -> (
    let _ = try Unix.inet_addr_of_string iface
    with Failure(reason) -> raise (Arg.Bad ("Invalid IP of " ^ iface ^ ": " ^ reason)) 
    in check rest
  )
  | [] -> ()
  in check iface_list;
  config.ifaces <- iface_list
;;

let set_port port_str =
  try 
    let port = (int_of_string port_str) in
    if (port < 1) then failwith "Too small"
    else if (port > 65535) then failwith "Too big"
    else config.port <- port;
  with _ -> raise (Arg.Bad ("Invalid port number " ^ port_str))

(** Read the arguments. *)
let read_args () =
  let speclist =
    [("-iface", Arg.String set_ifaces, "Comma separated list of IP addresses to bind to");
     ("-port", Arg.String set_port, "Port to listen on");
    ] in 
  let usage_msg = "Usage: Overseer [-iface ip1,ip2,...] [-port port]" in
  Arg.parse speclist (fun x -> ()) usage_msg; 
;;

(* main function for Overseer *)
let main () =
  Sys.set_signal Sys.sigpipe Sys.Signal_ignore;
  read_args();
  
  Sys.set_signal Sys.sighup (Sys.Signal_handle (read_config tables));
  Sys.set_signal Sys.sigusr1 (Sys.Signal_handle (dump_config tables));

  flush_all ();
  read_config tables 0;

  let bind_all () =
    let rec bind_to_iface ifaces port =
      match ifaces with 
      | iface::rest -> (try
          Log.echo ("Binding to " ^ iface ^ ":" ^ (string_of_int port));
          AsyncSocket.bind iface port handle_connection (handle_query tables);
          bind_to_iface rest port
        with Unix.Unix_error(code, fun_name, param) -> (
          failwith ("Error in " ^ fun_name ^ ": " ^ (Unix.error_message code))
      ))
      | [] -> ()
    in bind_to_iface config.ifaces config.port
  in

  bind_all ();

  AsyncSocket.dispatch()
;;

main();;
