theory nat_nat
  imports "../mml/nat_1" beiso
begin

reserve m,n,k,p for Nat

notation
  times (infixl "*\<^sub>\<H>" 70) and
  plus (infixl "+\<^sub>\<H>" 65)

(*notation HOL.eq (infixl "=" 50)*)

text_raw {*\DefineSnippet{h2sn}{*}
fun h2sn :: "nat \<Rightarrow> Set" ("\<hh>2\<ss>\<^sub>\<nat>'(_')") where
  "\<hh>2\<ss>\<^sub>\<nat>(0::nat) =\<^sub>\<S> 0\<^sub>\<S>" | "\<hh>2\<ss>\<^sub>\<nat>(Suc(x)) =\<^sub>\<S> succ \<hh>2\<ss>\<^sub>\<nat>(x)"
text_raw {*}%EndSnippet*}

notation h2sn ("\<hh>2\<ss>\<^sub>\<nat>")

text_raw {*\DefineSnippet{s2hn}{*}
function s2hn :: "Set \<Rightarrow> nat" ("\<ss>2\<hh>\<^sub>\<nat>'(_')") where
  "\<not>x be Nat \<Longrightarrow> \<ss>2\<hh>\<^sub>\<nat>(x) =\<^sub>\<H> undefined" 
| "\<ss>2\<hh>\<^sub>\<nat>(0\<^sub>\<S>) =\<^sub>\<H> 0" 
| "x be Nat \<Longrightarrow> \<ss>2\<hh>\<^sub>\<nat>(succ(x)) =\<^sub>\<H> Suc(\<ss>2\<hh>\<^sub>\<nat>(x))"
  text_raw {*}%EndSnippet*}
proof(auto simp add: all_set,mauto)
  show "\<And>P x. (\<And>xa. \<not> xa be natural \<Longrightarrow> x = xa \<Longrightarrow> P) \<Longrightarrow> (x = {} \<Longrightarrow> P) \<Longrightarrow> (\<And>xa. xa be natural  \<Longrightarrow> x = succ xa \<Longrightarrow> P) \<Longrightarrow> P"
  proof-
    fix P x assume A1: "(\<And>xa. \<not> xa be natural \<Longrightarrow> x = xa \<Longrightarrow> P) "" (x = {} \<Longrightarrow> P) "" (\<And>xa. xa be natural  \<Longrightarrow> x = succ xa \<Longrightarrow> P)"
    show "P"
    proof(cases "x be natural & x \<noteq> {}")
      case False 
      then show P using A1 by auto 
    next 
      case T:True 
      hence "succ predecessor (x) = x" using NAT_1_5 all_set by mty auto
        then show P using A1(3)[of "predecessor (x)"] T predec_ty[of x] all_set by mty auto
    qed
  qed
  show "\<And>xa. \<not> (succ xa) be natural \<Longrightarrow> xa be natural \<Longrightarrow> undefined =\<^sub>\<H> Suc(s2hn_sumC(xa))"
  proof- 
    fix xa
    assume  A1: "\<not> (succ xa) be natural" "xa be natural"
    hence [ty]: "xa be Nat" using all_set by mauto
    hence "(succ xa) be Nat" by mauto
    then show "undefined =\<^sub>\<H> Suc(s2hn_sumC(xa))" using A1 by auto
  qed
  show "\<And>x xa. x be natural \<Longrightarrow> xa be natural \<Longrightarrow> succ x = succ xa \<Longrightarrow> s2hn_sumC(x) =\<^sub>\<H> s2hn_sumC(xa)" 
  proof- fix x y assume "succ x = succ y"
    hence "x=y" using ordinal1_succ all_set by mty auto
    then show "s2hn_sumC(x) =\<^sub>\<H> s2hn_sumC(y)" by auto
  qed
qed

notation s2hn ("\<ss>2\<hh>\<^sub>\<nat>")

lemma h1: "wf (Collect (\<lambda>(x, y). x is Nat \<and> y is Nat \<and> x c< y))"
  apply (rule wfI[of _ "Collect (\<lambda>x. x is Nat)" "Collect (\<lambda>x. x is Nat)"])
  apply auto
  using CompleteInduction[simplified] by metis


termination
  apply standard
  apply (rule h1)
proof-
  fix x assume [ty]: "x be Nat"
  have h1: "(succ x) be Nat" by mauto
  have "x \<subset> succ x" using ordinal1_th_2[of x,OF all_set] ordinal1_th_7a by mauto 
  then show "(x, succ x) \<in> {(x, y). x be Nat \<and> y be Nat \<and> x \<subset> y}" using h1 by mty auto
qed


theorem I2Mprop: 
  "\<hh>2\<ss>\<^sub>\<nat>(m) is Nat"
proof(induct m)
  case 0
    have "\<hh>2\<ss>\<^sub>\<nat>(0) = {}" by simp
    thus ?case by mauto
  next
    case [ty]: (Suc m)
    have "\<hh>2\<ss>\<^sub>\<nat>(Suc (m)) = succ \<hh>2\<ss>\<^sub>\<nat> (m)" by auto  
    thus "\<hh>2\<ss>\<^sub>\<nat>(Suc (m)) is Nat" by mty auto 
qed
  
mtheorem EqSuc:
 "\<ss>2\<hh>\<^sub>\<nat>(succ m) =\<^sub>\<H> Suc(\<ss>2\<hh>\<^sub>\<nat>(m))"
proof-
  let ?P="\<lambda>m. \<ss>2\<hh>\<^sub>\<nat>(succ m) =\<^sub>\<H> Suc(\<ss>2\<hh>\<^sub>\<nat>(m))"
  have "succ {}<> {}" "predecessor (succ {}) = {}" using NAT_1_6 by mty auto
  hence "\<ss>2\<hh>\<^sub>\<nat>(succ {}) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>({}))" using s2hn.simps by mty auto      
  hence P0: "?P({})" by auto
  have Pn: "for k st ?P(k) holds ?P(succ k)"
  proof(standard,standard)
    fix k assume [ty]:"k be Nat" and "?P(k)"
    have "predecessor (succ succ k) = succ k" using NAT_1_6 by mty auto  
    thus "\<ss>2\<hh>\<^sub>\<nat>(succ succ k) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>(succ k))" using s2hn.simps by mty auto        
   qed mauto    
   show ?thesis using  ordinal_2_sch_19[of m ?P,OF _ P0 Pn] by auto
 qed  


text_raw {*\DefineSnippet{MIMprop}{*}
mtheorem MIMprop:
  "m =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(m))"
text_raw {*}%EndSnippet*}
proof-
   let ?P="\<lambda>m. m = \<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(m))"
 have P0: "?P({})" by auto
  have Pn: "for k st ?P(k) holds ?P(succ k)"
  proof(standard,standard)
    fix k assume [ty]:"k be Nat" and A1: "?P(k)"
     have "\<ss>2\<hh>\<^sub>\<nat>(succ k) =\<^sub>\<H> Suc(\<ss>2\<hh>\<^sub>\<nat>(k))" using EqSuc by auto
     thus "succ k = \<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(succ k))" using A1 by mty auto        
 qed mauto    
 show ?thesis using  ordinal_2_sch_19[of m ?P,OF _ P0 Pn] by auto
qed 

text_raw {*\DefineSnippet{IMIprop}{*}
theorem IMIprop:
  "m =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m))"
text_raw {*}%EndSnippet*}
proof(induct m)    
  case 0
  show ?case by auto
      next
  next
    case (Suc m)
    hence A1: "Suc(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(succ (\<hh>2\<ss>\<^sub>\<nat>(m)))" using EqSuc[of "\<hh>2\<ss>\<^sub>\<nat>(m)"] I2Mprop by auto
    have  "succ (\<hh>2\<ss>\<^sub>\<nat>(m)) =\<^sub>\<H> \<hh>2\<ss>\<^sub>\<nat>(Suc(m))" by auto
    thus  "Suc(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(Suc(m)))" using A1 by simp
  qed 

theorem beIsoT_Nat: "beIsoT(\<hh>2\<ss>\<^sub>\<nat>,\<ss>2\<hh>\<^sub>\<nat>,Nat)"
  unfolding beIsoT_def 
proof(intro conjI)
  show "\<forall>\<^sub>Ly. \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(y)) =\<^sub>\<H> y" using IMIprop by auto
  show "\<forall>x:Nat. \<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(x)) = x" 
  proof(standard)
    fix x assume [ty]: "x be Nat"
    have "x is Nat" using ordinal1_def_12[of x] by mty auto
    then show "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(x)) = x" using MIMprop by mty auto
  qed simp_all
  show "\<forall>\<^sub>Ly. \<hh>2\<ss>\<^sub>\<nat>(y) be Nat" using I2Mprop by auto
qed

theorem beIsoS_NAT: 
  "beIsoS(\<hh>2\<ss>\<^sub>\<nat>,\<ss>2\<hh>\<^sub>\<nat>,NAT)"
  by(simp add: ordinal1_def_12 all_set beIsoS_Type_Set(1)[OF _ beIsoT_Nat])



text_raw {*\DefineSnippet{ZeroOne}{*}
theorem Zero_One:
  "0 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(0\<^sub>\<S>)" "1 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>)" 
  using s2hn.simps EqSuc[of "0\<^sub>\<S>"]  by mty auto
text_raw {*}%EndSnippet*}

theorem Two_Three_Four:
  "2 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(2\<^sub>\<S>)" "3 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(3\<^sub>\<S>)" "4 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(4\<^sub>\<S>)"
using s2hn.simps EqSuc[of "3\<^sub>\<S>"] EqSuc[of "2\<^sub>\<S>"] EqSuc[of "1\<^sub>\<S>"]
  Zero_One by mty auto

lemma natprop:
  "n be Nat & n \<noteq> {} implies not \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> 0"
proof
  next let ?p="predecessor n"   
  assume A1: "n be Nat & n \<noteq> {}"
  hence [ty]:"n be Nat" by mauto 
  hence [ty]: "?p is Nat" by mauto
  have A3: "succ ?p = n" using predec A1 by auto      
  have "\<ss>2\<hh>\<^sub>\<nat>(succ(?p)) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>(?p))" using s2hn.simps by mty auto
  hence "\<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>(?p))" using A3 by auto
  thus " not \<ss>2\<hh>\<^sub>\<nat>(n) =\<^sub>\<H> 0" by auto
qed

mtheorem EqM:
   "m =\<^sub>\<S> n iff \<ss>2\<hh>\<^sub>\<nat>(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
proof-
  let ?P="\<lambda>m. for n holds m = n iff \<ss>2\<hh>\<^sub>\<nat>(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
  have P0: "?P({})"
  proof(rule ballI,rule iffI3)
    fix n assume [ty]:"n be Nat"
    show "{} = n \<longrightarrow> \<ss>2\<hh>\<^sub>\<nat>({}) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)" by auto
    assume A0: "\<ss>2\<hh>\<^sub>\<nat>({}) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
    show "{}=n"  
    proof (cases "n={}")
      case True 
      thus ?thesis by auto
    next let ?p="predecessor n"
      have A2[ty]: "?p is Nat" by mauto
      case False
        thus ?thesis using A0 natprop by auto
    qed 
  qed mauto
  have Pm: "for m st ?P(m) holds ?P(succ m)"
   proof(standard,standard,standard)
     fix m n assume [ty]:"m be Nat" "n be Nat" and A1: "?P(m)"
     show "succ m = n iff \<ss>2\<hh>\<^sub>\<nat>(succ m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
     proof(cases "n={}")
       case True
       thus ?thesis using EqSuc by auto
     next
       case False
         hence A2: "succ (predecessor n) = n" using predec by auto
         hence A3: "succ m = n implies \<ss>2\<hh>\<^sub>\<nat>(succ m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)" 
           using ordinal1_succ[of m "predecessor n"] by mauto
         have "\<ss>2\<hh>\<^sub>\<nat>(succ m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n) implies succ m = n"
         proof
           assume "\<ss>2\<hh>\<^sub>\<nat>(succ m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
           hence "Suc (\<ss>2\<hh>\<^sub>\<nat>(m)) =\<^sub>\<H> Suc (\<ss>2\<hh>\<^sub>\<nat>(predecessor n))" using A2 EqSuc[of m] EqSuc[of "predecessor n"] 
             by mty auto 
           hence "\<ss>2\<hh>\<^sub>\<nat>(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(predecessor n)" by mty auto 
           hence "m=predecessor n" using A1 by mty auto 
           thus "succ m = n" using A1 A2 by mty auto    
         qed
       thus ?thesis using A3 by auto    
     qed
   qed mauto
  show ?thesis using  ordinal_2_sch_19[of m ?P,OF _ P0 Pm] by auto      
qed      
    
theorem EqI:
   "m =\<^sub>\<H> n iff \<hh>2\<ss>\<^sub>\<nat>(m) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(n)"
proof -
  have "m =\<^sub>\<H> n iff \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(n))" using IMIprop by auto
  thus ?thesis using EqM by auto
qed  
text_raw {*\DefineSnippet{AddM}{*}    
mtheorem AddM:
  "\<ss>2\<hh>\<^sub>\<nat>(m +\<^sub>\<S>\<^sup>\<nat> n) =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<nat>(m) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
text_raw {*}%EndSnippet*}
proof-
  let ?P="\<lambda>n. \<ss>2\<hh>\<^sub>\<nat>(m +\<^sub>\<S>\<^sup>\<nat> n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"    
  have "\<ss>2\<hh>\<^sub>\<nat> ({}) =\<^sub>\<H> 0" "m +\<^sub>\<S>\<^sup>\<nat> {} = m" using s2hn.simps Add_3 by mty auto      
  hence R0: "?P({})" by auto
  have Rn:"for k st ?P(k) holds ?P(succ k)"
  proof(standard,standard)
    fix k assume [ty]:"k be Nat" and P: "?P(k)"
    have "m +\<^sub>\<S>\<^sup>\<nat> succ k = succ(m+\<^sub>\<S>\<^sup>\<nat> k)" "succ(m+\<^sub>\<S>\<^sup>\<nat> k)<>{}" using Add_1 by auto
    hence A1: "\<ss>2\<hh>\<^sub>\<nat>(m +\<^sub>\<S>\<^sup>\<nat> succ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) +\<^sub>\<H> Suc(\<ss>2\<hh>\<^sub>\<nat>(k))" using P NAT_1_6 s2hn.simps by mty auto
    thus  "\<ss>2\<hh>\<^sub>\<nat>(m +\<^sub>\<S>\<^sup>\<nat> succ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(succ k)" using NAT_1_6 s2hn.simps by mty auto 
  qed mauto
  show ?thesis  using  ordinal_2_sch_19[of n ?P,OF _ R0 Rn] by auto      
qed  

text_raw {*\DefineSnippet{AddI}{*} 
theorem AddI:
  "\<hh>2\<ss>\<^sub>\<nat>(m +\<^sub>\<H> n) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(m) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n)"
text_raw {*}%EndSnippet*}
proof-
  have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(m +\<^sub>\<H> n) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(m) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(n) is Nat" 
    "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n))) is Nat"
    using I2Mprop by auto+
  have "\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m +\<^sub>\<H> n)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n))))" using AddM IMIprop by auto  
  hence "m +\<^sub>\<H> n =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n))" using EqI EqM by mty auto  
  thus "\<hh>2\<ss>\<^sub>\<nat>(m +\<^sub>\<H> n) = \<hh>2\<ss>\<^sub>\<nat>(m) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n)" using EqM IMIprop by mty auto  
qed  

text_raw {*\DefineSnippet{MultM}{*}
mtheorem MultM:
  "\<ss>2\<hh>\<^sub>\<nat>(m *\<^sub>\<S>\<^sup>\<nat> n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"
text_raw {*}%EndSnippet*}
proof-
   let ?P="\<lambda>n. \<ss>2\<hh>\<^sub>\<nat>(m *\<^sub>\<S>\<^sup>\<nat> n) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)"    
  have "\<ss>2\<hh>\<^sub>\<nat> ({}) =\<^sub>\<H> 0" "m *\<^sub>\<S>\<^sup>\<nat> {} = {}" using s2hn.simps Mult_2 by mty auto      
  hence R0: "?P({})" by auto
  have Rn:"for k st ?P(k) holds ?P(succ k)"
  proof(standard,standard)
    fix k assume [ty]:"k be Nat" and P: "?P(k)"
    have "m *\<^sub>\<S>\<^sup>\<nat> succ k = (m *\<^sub>\<S>\<^sup>\<nat> k)+\<^sub>\<S>\<^sup>\<nat> m" using Mult_3 by auto
    hence "\<ss>2\<hh>\<^sub>\<nat>(m *\<^sub>\<S>\<^sup>\<nat> succ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m *\<^sub>\<S>\<^sup>\<nat> k)+\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" using AddM by mty auto
    hence "\<ss>2\<hh>\<^sub>\<nat>(m *\<^sub>\<S>\<^sup>\<nat> succ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(k)+\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" using P by mty auto
    thus "\<ss>2\<hh>\<^sub>\<nat>(m *\<^sub>\<S>\<^sup>\<nat> succ k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m) *\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<nat>(succ k))" using EqSuc by auto   
  qed mauto
  show ?thesis  using  ordinal_2_sch_19[of n ?P,OF _ R0 Rn] by auto      
  have "Suc(\<ss>2\<hh>\<^sub>\<nat>(m)) *\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<nat>(n)) =\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<nat>(m)) *\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<nat>(n)) +\<^sub>\<H> (\<ss>2\<hh>\<^sub>\<nat>(n))" by auto
qed
text_raw {*\DefineSnippet{MultI}{*}
theorem MultI:
  "\<hh>2\<ss>\<^sub>\<nat>(m *\<^sub>\<H> n) = \<hh>2\<ss>\<^sub>\<nat>(m) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n)"
text_raw {*}%EndSnippet*}
proof-
  have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(m *\<^sub>\<H> n) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(m) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(n) is Nat" 
    "\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n))) is Nat"
    using I2Mprop by auto+
  have "\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m *\<^sub>\<H> n)) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n))))" using MultM IMIprop by auto  
  hence "m *\<^sub>\<H> n =\<^sub>\<H>  \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(m) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n))" using EqI EqM by mty auto  
  thus "\<hh>2\<ss>\<^sub>\<nat>(m *\<^sub>\<H> n) = \<hh>2\<ss>\<^sub>\<nat>(m) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(n)" using EqM IMIprop by mty auto  
qed  

mtheorem dividesM:
  "m divides n iff \<ss>2\<hh>\<^sub>\<nat>(m) dvd \<ss>2\<hh>\<^sub>\<nat>(n)" 
proof
  assume "m divides n"
  then obtain k where
     [ty]:"k be Nat" and "m *\<^sub>\<S>\<^sup>\<nat> k = n" using div by auto
  thus "\<ss>2\<hh>\<^sub>\<nat>(m) dvd \<ss>2\<hh>\<^sub>\<nat>(n)" using dvd_def MultM by auto
next
  assume "\<ss>2\<hh>\<^sub>\<nat>(m) dvd \<ss>2\<hh>\<^sub>\<nat>(n)"
  hence "Ex(\<lambda>k. \<ss>2\<hh>\<^sub>\<nat>(m) *\<^sub>\<H> k =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n))" using  dvd_def[of "\<ss>2\<hh>\<^sub>\<nat>(m)" "\<ss>2\<hh>\<^sub>\<nat>(n)"] by auto
  then obtain k where
    A1: "\<ss>2\<hh>\<^sub>\<nat>(m) *\<^sub>\<H> k =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)" by blast
  have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(k) is Nat" using I2Mprop by auto
  have "k =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(k))" using IMIprop by auto 
  hence  "m *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(k) = n" using A1 MultM EqM by mty auto
  thus  "m divides n" using divI bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(k)" Nat] by mty auto  
qed
  
theorem dividesI:
  "(m dvd n) iff \<hh>2\<ss>\<^sub>\<nat>(m) divides \<hh>2\<ss>\<^sub>\<nat>(n)" using I2Mprop IMIprop dividesM by auto
      
mtheorem lessM:
  "n in m iff \<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)"
proof
  assume "n in m"
  then obtain k where
     [ty]:"k be Nat" and "k<>{} & m = n +\<^sub>\<S>\<^sup>\<nat> k" using Add_8 by auto
  hence "not \<ss>2\<hh>\<^sub>\<nat>(k) =\<^sub>\<H> 0" "\<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" 
    using s2hn.simps AddM natprop by auto    
   hence "Ex(\<lambda>z. (z > 0 \<and>    \<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> z =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)))" by auto      
  thus "\<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)" by auto
next
  assume "\<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)"  
  then obtain z where
    A1: "z >0" and A2:"\<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> z =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" using less_imp_add_positive by auto
  have [ty]:"\<hh>2\<ss>\<^sub>\<nat>(z) is Nat" using I2Mprop by auto+
  have H: "\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(z)) =\<^sub>\<H> z" using IMIprop by mty auto    
  hence B1: "\<hh>2\<ss>\<^sub>\<nat>(z) <> {}" using A1 EqM by auto  
  have "\<ss>2\<hh>\<^sub>\<nat>(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n +\<^sub>\<S>\<^sup>\<nat>  \<hh>2\<ss>\<^sub>\<nat>(z))" using A2 H AddM by mty auto     
  hence "n +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(z) = m" using EqM by mty auto
  hence "ex k st k<>{} & m = n+\<^sub>\<S>\<^sup>\<nat> k" using B1 bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(z)" Nat] by mty auto    
  thus "n in m" using Add_8 by auto    
qed

mtheorem lessM1:
  "n \<subset> m iff \<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)"
proof
  assume "n \<subset> m"
  hence "n in m" using ordinal1_th_7[of n m,simplified] by mty auto
  then show "\<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)" using lessM[of m n] by mty auto
next 
  assume "\<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)"
  hence "n in m" using lessM[of m n] by mty auto
  then show "n \<subset> m"  using ordinal1_th_7a[of n m,simplified] by mty auto
qed

theorem lessI:
  "n < m iff \<hh>2\<ss>\<^sub>\<nat>(n) in \<hh>2\<ss>\<^sub>\<nat>(m)" using I2Mprop IMIprop lessM by auto

theorem lessI1:
  "n < m iff \<hh>2\<ss>\<^sub>\<nat>(n) \<subset> \<hh>2\<ss>\<^sub>\<nat>(m)" using I2Mprop IMIprop lessM1 by auto


mtheorem less_eqM:
  "n c= m iff \<ss>2\<hh>\<^sub>\<nat>(n) \<le> \<ss>2\<hh>\<^sub>\<nat>(m)"
proof
  assume "n c= m"
  then obtain k where
     [ty]:"k be Nat" and " m = n +\<^sub>\<S>\<^sup>\<nat> k" using Add_9 by auto
  hence "\<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(k) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" 
    using s2hn.simps AddM by auto    
   hence "Ex(\<lambda>z.  \<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> z =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m))" by auto      
  thus "\<ss>2\<hh>\<^sub>\<nat>(n) \<le> \<ss>2\<hh>\<^sub>\<nat>(m)" by auto
next
  assume "\<ss>2\<hh>\<^sub>\<nat>(n) \<le> \<ss>2\<hh>\<^sub>\<nat>(m)"  
  then obtain z where
    A1:"\<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> z =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)" using le_Suc_ex by metis
  have [ty]:"\<hh>2\<ss>\<^sub>\<nat>(z) is Nat" using I2Mprop by auto
  have H: "\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(z)) =\<^sub>\<H> z" using IMIprop by mty auto    
  hence "\<ss>2\<hh>\<^sub>\<nat>(m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n +\<^sub>\<S>\<^sup>\<nat>  \<hh>2\<ss>\<^sub>\<nat>(z))" using A1 AddM by mty auto     
  hence "n +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(z) = m" using EqM by mty auto
  hence "ex k st  m = n+\<^sub>\<S>\<^sup>\<nat> k" using bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(z)" Nat] by mty auto    
  thus "n c= m" using Add_9 by auto    
qed
  
theorem less_eqI:
  "n \<le> m iff \<hh>2\<ss>\<^sub>\<nat>(n) c= \<hh>2\<ss>\<^sub>\<nat>(m)" using I2Mprop IMIprop less_eqM by auto


mtheorem irreducible_M:
   "n is prime\<^sub>\<S> iff irreducible(\<ss>2\<hh>\<^sub>\<nat>(n))"
proof
  assume N: "n is prime\<^sub>\<S>"
  show "irreducible(\<ss>2\<hh>\<^sub>\<nat>(n))"
  unfolding irreducible_def
  proof(intro conjI, auto)
    have "n<>{}" using N prime_eq_irreducible by mty auto     
    thus "0 < \<ss>2\<hh>\<^sub>\<nat>(n)" using EqM dividesM natprop by auto
    have "not n divides 1\<^sub>\<S>" using N prime_eq_irreducible by mty auto    
    thus "HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(n),Suc(0)) \<Longrightarrow> False" using dividesM by mty auto
    fix a b
    have [ty]:"\<hh>2\<ss>\<^sub>\<nat>(a) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(b) is Nat" using I2Mprop by auto
    assume A1: "HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(n),a *\<^sub>\<H> b)" "not HOL.eq(b,Suc(0))"
    hence "n = \<hh>2\<ss>\<^sub>\<nat>(a)*\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(b)" using MultM EqM IMIprop by mty auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(a) divides 1\<^sub>\<S> \<or>  \<hh>2\<ss>\<^sub>\<nat>(b) divides 1\<^sub>\<S>" using N prime_eq_irreducible by mty auto 
    hence A2: "\<hh>2\<ss>\<^sub>\<nat>(a) = 1\<^sub>\<S> \<or>  \<hh>2\<ss>\<^sub>\<nat>(b) = 1\<^sub>\<S>" using div_one by auto 
    have A3: "HOL.eq(Suc(0),\<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>))" using s2hn.simps EqSuc[of "{}"] by mty auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(a) = 1\<^sub>\<S>" using A1(2) A2 EqM IMIprop by mty auto
    hence "HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(a)),Suc(0))" using A3 by mty auto 
    thus "HOL.eq(a,Suc(0))" using IMIprop by mty auto
  qed
next 
  assume I: "irreducible(\<ss>2\<hh>\<^sub>\<nat>(n))"
  show "n is prime\<^sub>\<S>"
  proof(standard,simp)
    have A1: "HOL.eq(1,\<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>))" "HOL.eq(0,\<ss>2\<hh>\<^sub>\<nat>({}))" using s2hn.simps EqSuc[of "{}"] by mty auto
    have [ty]: "1\<^sub>\<S> is Nat" by mauto
    have "not HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(n),0)" "not \<ss>2\<hh>\<^sub>\<nat>(n) dvd 1" using irreducible_def[of "\<ss>2\<hh>\<^sub>\<nat>(n)"] I by auto
    hence A2: "n <> {}" "n<> 1\<^sub>\<S>" using A1 EqM by auto
    hence "not n in 1\<^sub>\<S>" using one tarski_def_1 by auto
    thus "1\<^sub>\<S> in n" using ordinal1_th_10 A2 by mty auto
    show "for k be Nat st k divides n holds k = 1\<^sub>\<S> \<or> k = n"
    proof(standard,standard)
      fix k assume [ty]:"k be Nat" and A3:"k divides n"
  then obtain m where
      [ty]: "m be Nat" and
       A4:  "k *\<^sub>\<S>\<^sup>\<nat> m = n" using div by mty auto
      have "k<>1\<^sub>\<S> implies k=n"
      proof
        assume A5: "k<>1\<^sub>\<S>"
        have "HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(n),\<ss>2\<hh>\<^sub>\<nat>(k) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m))" using A4 MultM by mty auto
        hence "\<ss>2\<hh>\<^sub>\<nat>(k) dvd 1 or \<ss>2\<hh>\<^sub>\<nat>(m) dvd 1" using irreducible_def[of "\<ss>2\<hh>\<^sub>\<nat>(n)"] I by auto
        hence "k divides 1\<^sub>\<S> or m divides 1\<^sub>\<S>" using A1 dividesM[of "1\<^sub>\<S>",simplified] by mty auto
        hence "m = 1\<^sub>\<S>" using A5 div_one by mty auto
        thus "k=n" using A4 Mult_5 by mty auto  
      qed
      thus "k = 1\<^sub>\<S> \<or> k = n" by blast
    qed mauto
  qed
qed

theorem irreducible_I:
   "irreducible(n) iff \<hh>2\<ss>\<^sub>\<nat>(n) is prime\<^sub>\<S>" using I2Mprop IMIprop irreducible_M by auto

mtheorem prime_M:
  "p is prime\<^sub>\<S> iff prime(\<ss>2\<hh>\<^sub>\<nat>(p))"
proof
  have A1: "HOL.eq(Suc(0),\<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>))" using s2hn.simps EqSuc[of "{}"] by mty auto
  have [ty]: "1\<^sub>\<S> is Nat" by mauto
  assume P: "p is prime\<^sub>\<S>"
  hence "irreducible(\<ss>2\<hh>\<^sub>\<nat>(p))" using irreducible_M by auto
  show "prime(\<ss>2\<hh>\<^sub>\<nat>(p))" 
    unfolding prime_nat_iff
  proof(auto)
    have "1\<^sub>\<S> in p" using P primeS by auto
    thus "Suc(0) < \<ss>2\<hh>\<^sub>\<nat>(p)" using lessM A1 by auto
    fix m 
    have [ty]:"\<hh>2\<ss>\<^sub>\<nat>(m) is Nat" using I2Mprop by auto
    assume A2: "m dvd \<ss>2\<hh>\<^sub>\<nat>(p)" "not HOL.eq(m,\<ss>2\<hh>\<^sub>\<nat>(p))"
    hence "\<hh>2\<ss>\<^sub>\<nat>(m) divides p" using dividesM[of p "\<hh>2\<ss>\<^sub>\<nat>(m)"] IMIprop by mty auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(m) = 1\<^sub>\<S> or \<hh>2\<ss>\<^sub>\<nat>(m) = p" using P primeS by auto
    hence "\<hh>2\<ss>\<^sub>\<nat>(m) = 1\<^sub>\<S>" using A2(2) EqM[of p] IMIprop[of m] by auto
    thus "HOL.eq(m,Suc(0))" using A1 EqI by auto
  qed
next
   have [ty]: "1\<^sub>\<S> is Nat" by mauto
  have A1: "HOL.eq(Suc(0),\<ss>2\<hh>\<^sub>\<nat>(1\<^sub>\<S>))" using s2hn.simps EqSuc[of "{}"] by mty auto
  assume P: "prime(\<ss>2\<hh>\<^sub>\<nat>(p))"
  show "p is prime\<^sub>\<S>"
  proof(intro primeSI ballI impI)
    have "1 < \<ss>2\<hh>\<^sub>\<nat>(p)" using P  prime_nat_iff by mty auto
    thus "1\<^sub>\<S> in p" using A1 lessM by  auto
    fix n assume [ty]: "n be Nat" and A2: "n divides p"
    hence "\<ss>2\<hh>\<^sub>\<nat>(n) dvd \<ss>2\<hh>\<^sub>\<nat>(p)" using dividesM by auto
    hence "HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(n),1) or HOL.eq(\<ss>2\<hh>\<^sub>\<nat>(n),\<ss>2\<hh>\<^sub>\<nat>(p))" using  P  prime_nat_iff by auto 
    thus "n=1\<^sub>\<S> or n=p" using EqM A1 by auto
  qed mauto
qed

mtheorem prime_I:
  "prime(p) \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<nat>(p) is prime\<^sub>\<S>" using I2Mprop IMIprop prime_M by auto

text_raw {*\DefineSnippet{NatNatProp}{*}
theorem Nat_to_Nat:
  fixes x::nat and y::nat 
  assumes "n be Nat" and "m be Nat"
  shows "\<hh>2\<ss>\<^sub>\<nat>(x +\<^sub>\<H> y) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(x) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(y)"
        "\<ss>2\<hh>\<^sub>\<nat>(n +\<^sub>\<S>\<^sup>\<nat> m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n) +\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)"
        "\<hh>2\<ss>\<^sub>\<nat>(x *\<^sub>\<H> y) =\<^sub>\<S> \<hh>2\<ss>\<^sub>\<nat>(x) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(y)"
        "\<ss>2\<hh>\<^sub>\<nat>(n *\<^sub>\<S>\<^sup>\<nat> m) =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n) *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(m)"
        "x < y \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<nat>(x) \<subset> \<hh>2\<ss>\<^sub>\<nat>(y)"
        "n \<subset> m \<longleftrightarrow> \<ss>2\<hh>\<^sub>\<nat>(n) < \<ss>2\<hh>\<^sub>\<nat>(m)"
        "x dvd y \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<nat>(x) divides \<hh>2\<ss>\<^sub>\<nat>(y)" 
        "n divides m \<longleftrightarrow> \<ss>2\<hh>\<^sub>\<nat>(n) dvd \<ss>2\<hh>\<^sub>\<nat>(m)"
        "prime(x) \<longleftrightarrow> \<hh>2\<ss>\<^sub>\<nat>(x) is prime\<^sub>\<S>"
        "n is prime\<^sub>\<S> \<longleftrightarrow> prime(\<ss>2\<hh>\<^sub>\<nat>(n))"
text_raw {*}%EndSnippet*}
  using AddI[of x y] AddM[of m n]
        MultI[of x y] MultM[of m n]  prime_I[of x] prime_M[of n] 
        lessM1[of m n] lessI1[of x y] dividesI dividesM assms by auto  


text_raw {*\DefineSnippet{Bertrand}{*}
theorem Bertrand:
  "\<forall>n:Nat. 1\<^sub>\<S> \<subset> n \<longrightarrow>
     (\<exists>p:Nat. p be prime\<^sub>\<S> \<and> n \<subset> p \<and> p \<subset> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> n))" 
text_raw {*}%EndSnippet*}
proof(standard,standard)
  fix n assume [ty]: "n be Nat" and
  "1\<^sub>\<S> \<subset> n"
  hence "1\<^sub>\<S> in n" using ordinal1_th_7 by mty auto
  hence "1 < \<ss>2\<hh>\<^sub>\<nat>(n)" using ordinal1_th_7 lessM Two_Three_Four by mty auto
  then obtain p where
    A1: "p\<in>{ \<ss>2\<hh>\<^sub>\<nat>(n) <..< 2 *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)} &  prime(p)" 
    using bertrand[of "\<ss>2\<hh>\<^sub>\<nat>(n)"] by auto
  have [ty]:"\<hh>2\<ss>\<^sub>\<nat>(p) is Nat" using I2Mprop by auto
  have P:"\<ss>2\<hh>\<^sub>\<nat>(\<hh>2\<ss>\<^sub>\<nat>(p)) =\<^sub>\<H> p" using IMIprop by auto
  show "ex p be Nat st p is prime\<^sub>\<S> & n \<subset> p & p \<subset> (2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> n)"
  proof(rule bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(p)"],auto)
    show "\<hh>2\<ss>\<^sub>\<nat>(p) is prime\<^sub>\<S>" using prime_I A1 by auto
    have "n in \<hh>2\<ss>\<^sub>\<nat>(p)" using P lessM A1 by auto
    then show "n \<subset> \<hh>2\<ss>\<^sub>\<nat>(p)" using ordinal1_th_7a by mty auto
    have "\<hh>2\<ss>\<^sub>\<nat>(2 *\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)) = \<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(2\<^sub>\<S>)) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(\<ss>2\<hh>\<^sub>\<nat>(n))"
      using MultI Two_Three_Four by auto
    also have "... = 2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> n" 
      using MIMprop[of "2\<^sub>\<S>"] MIMprop[of n] by mty auto    
    finally show "\<hh>2\<ss>\<^sub>\<nat>(p) \<subset> 2\<^sub>\<S> *\<^sub>\<S>\<^sup>\<nat> n"
        using P lessI A1 ordinal1_th_7a by mty auto
  qed
qed mauto


theorem PowerM:
  "\<hh>2\<ss>\<^sub>\<nat>(a^2) = \<hh>2\<ss>\<^sub>\<nat>(a) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(a)"
proof-
  have "\<hh>2\<ss>\<^sub>\<nat>(a^2) = \<hh>2\<ss>\<^sub>\<nat>(a *\<^sub>\<H> a)" using power2_eq_square[of a] by auto
  then show "\<hh>2\<ss>\<^sub>\<nat>(a^2) = \<hh>2\<ss>\<^sub>\<nat>(a) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(a)" using MultI by auto
qed

text_raw{*\DefineSnippet{Lagrange}{*}
theorem LagrangeFourSquares:
  "\<forall>n:Nat. \<exists>a,b,c,d:Nat.
    a *\<^sub>\<S>\<^sup>\<nat> a +\<^sub>\<S>\<^sup>\<nat> b *\<^sub>\<S>\<^sup>\<nat> b +\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> c +\<^sub>\<S>\<^sup>\<nat> d *\<^sub>\<S>\<^sup>\<nat> d =\<^sub>\<S> n"
  text_raw {*}%EndSnippet*}
proof
  fix n assume [ty]:"n be Nat"
  obtain a b c d where
    A1: "a\<^sup>2 +\<^sub>\<H> b\<^sup>2 +\<^sub>\<H> c\<^sup>2 +\<^sub>\<H> d\<^sup>2 =\<^sub>\<H> \<ss>2\<hh>\<^sub>\<nat>(n)" using  sum_of_four_squares[of "\<ss>2\<hh>\<^sub>\<nat>(n)"]  by auto
  have [ty]: "\<hh>2\<ss>\<^sub>\<nat>(a) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(b) is Nat" 
             "\<hh>2\<ss>\<^sub>\<nat>(c) is Nat" "\<hh>2\<ss>\<^sub>\<nat>(d) is Nat" using I2Mprop by auto
  show "ex a,b,c,d be Nat st a *\<^sub>\<S>\<^sup>\<nat> a +\<^sub>\<S>\<^sup>\<nat> b *\<^sub>\<S>\<^sup>\<nat> b +\<^sub>\<S>\<^sup>\<nat> c *\<^sub>\<S>\<^sup>\<nat> c +\<^sub>\<S>\<^sup>\<nat> d *\<^sub>\<S>\<^sup>\<nat> d =n"
  proof(rule bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(a)"],rule bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(b)"],
        rule bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(c)"],rule bexI[of _ "\<hh>2\<ss>\<^sub>\<nat>(d)"])
    have "n =  \<hh>2\<ss>\<^sub>\<nat>(a\<^sup>2 +\<^sub>\<H> b\<^sup>2 +\<^sub>\<H> c\<^sup>2 +\<^sub>\<H> d\<^sup>2)" using A1 MIMprop by auto
    also have "... = \<hh>2\<ss>\<^sub>\<nat>(a\<^sup>2) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(b\<^sup>2) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(c\<^sup>2) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(d\<^sup>2)" using AddI by auto
    also have "... = \<hh>2\<ss>\<^sub>\<nat>(a) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(a) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(b) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(b) +\<^sub>\<S>\<^sup>\<nat> 
         \<hh>2\<ss>\<^sub>\<nat>(c) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(c) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(d) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(d)" using PowerM by auto
    finally show "\<hh>2\<ss>\<^sub>\<nat>(a) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(a) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(b) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(b) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(c) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(c) +\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(d) *\<^sub>\<S>\<^sup>\<nat> \<hh>2\<ss>\<^sub>\<nat>(d) = n" by auto
  qed mauto
qed mauto

end
